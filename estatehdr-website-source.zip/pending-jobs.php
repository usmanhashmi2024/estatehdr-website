<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
requireLogin();

$user = currentUser();
$orders = getPendingOrders($user['id']);

$searchKw   = strtolower(trim($_GET['q'] ?? ''));
$searchType = trim($_GET['type'] ?? '');
$dateStart  = trim($_GET['date_start'] ?? '');
$dateEnd    = trim($_GET['date_end'] ?? '');

$filtered = array_filter($orders, function($o) use ($searchKw, $searchType, $dateStart, $dateEnd) {
    if ($searchKw !== '') {
        $matches = str_contains(strtolower($o['property_name']), $searchKw) ||
                   str_contains(strtolower($o['id']), $searchKw);
        if (!$matches) return false;
    }
    if ($searchType !== '' && $o['service_type'] !== $searchType) return false;
    if ($dateStart !== '' && strtotime($o['created_at']) < strtotime($dateStart)) return false;
    if ($dateEnd !== '' && strtotime($o['created_at']) > strtotime($dateEnd . ' 23:59:59')) return false;
    return true;
});
$filtered = array_values($filtered);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pending Jobs — Estate HDR</title>
<meta name="robots" content="noindex">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/includes/portal-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8">
  <div class="mb-6">
    <div class="section-tag mb-1">Active Pipeline</div>
    <h1 class="text-2xl sm:text-3xl font-black text-white">PENDING JOBS</h1>
    <p class="text-gray-400 text-xs mt-1">Live status tracking of your submitted jobs currently being processed by our retouching team.</p>
  </div>

  <!-- Search Filter Bar -->
  <div class="glass-card rounded-2xl p-5 mb-8 border border-dark-border shadow-xl">
    <form method="GET" class="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
      <div class="sm:col-span-4">
        <label class="form-label text-xs">Search Job Title / Job ID (ORD-5001)</label>
        <input type="text" name="q" value="<?= htmlspecialchars($_GET['q'] ?? '') ?>" class="form-input text-xs py-2" placeholder="e.g. 7962 Frances Road or ORD-5001">
      </div>

      <div class="sm:col-span-3">
        <label class="form-label text-xs">Job Type</label>
        <select name="type" class="form-select text-xs py-2">
          <option value="">All Services</option>
          <option value="HDR Photo Editing" <?= $searchType === 'HDR Photo Editing' ? 'selected' : '' ?>>Photo Enhancement HDR</option>
          <option value="Virtual Staging" <?= $searchType === 'Virtual Staging' ? 'selected' : '' ?>>Virtual Staging</option>
          <option value="Floor Plans & 3D Tours" <?= $searchType === 'Floor Plans & 3D Tours' ? 'selected' : '' ?>>2D / 3D Floor Plans</option>
          <option value="Item Removal" <?= $searchType === 'Item Removal' ? 'selected' : '' ?>>Item Removal</option>
          <option value="Day to Dusk" <?= $searchType === 'Day to Dusk' ? 'selected' : '' ?>>Day to Dusk</option>
          <option value="Virtual Twilight" <?= $searchType === 'Virtual Twilight' ? 'selected' : '' ?>>Virtual Twilight</option>
        </select>
      </div>

      <div class="sm:col-span-2">
        <label class="form-label text-xs">Date Start</label>
        <input type="date" name="date_start" value="<?= htmlspecialchars($dateStart) ?>" class="form-input text-xs py-2 text-gray-300">
      </div>

      <div class="sm:col-span-2">
        <label class="form-label text-xs">Date End</label>
        <input type="date" name="date_end" value="<?= htmlspecialchars($dateEnd) ?>" class="form-input text-xs py-2 text-gray-300">
      </div>

      <div class="sm:col-span-1 flex gap-1">
        <button type="submit" class="btn-gold py-2 px-3 text-xs font-bold w-full">Search</button>
      </div>
    </form>
  </div>

  <!-- Job List Table -->
  <div class="glass-card rounded-2xl overflow-hidden border border-dark-border shadow-2xl">
    <div class="p-4 border-b border-dark-border flex items-center justify-between">
      <h3 class="text-xs font-bold text-white uppercase tracking-wider">JOB LIST</h3>
      <span class="text-xs text-gray-400 font-mono"><?= count($filtered) ?> active jobs</span>
    </div>

    <?php if (empty($filtered)): ?>
    <div class="p-16 text-center text-gray-500 text-sm">
      <div class="text-4xl mb-2">🎉</div>
      <p class="text-white font-bold mb-1">No pending jobs in queue</p>
      <p class="text-xs text-gray-400 mb-4">All your jobs have been completed or you haven't placed an order yet.</p>
      <a href="/order-new.php" class="btn-gold py-2 px-5 text-xs font-bold shadow-glow">+ Submit New Job</a>
    </div>
    <?php else: ?>
    <div class="overflow-x-auto">
      <table class="dashboard-table w-full text-left text-xs">
        <thead>
          <tr>
            <th>Job Title</th>
            <th>Job ID</th>
            <th>Created Date</th>
            <th>Job Type</th>
            <th class="text-center">Quantity</th>
            <th class="text-right">Amount</th>
            <th class="text-center">Status</th>
            <th class="text-center">Turnaround</th>
            <th class="text-right">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($filtered as $o): ?>
          <tr>
            <td class="font-bold text-white">
              <?= htmlspecialchars($o['property_name']) ?>
            </td>
            <td class="font-mono text-gold font-black">
              <?= strtoupper($o['id']) ?>
            </td>
            <td class="text-gray-400 font-mono">
              <?= date('M j, Y', strtotime($o['created_at'])) ?>
            </td>
            <td class="text-gray-300">
              <?= htmlspecialchars($o['service_type']) ?>
            </td>
            <td class="text-center font-mono text-gray-300">
              <?= $o['raw_images_count'] ?> photos
            </td>
            <td class="text-right font-mono font-bold text-gold">
              <?= $o['billed_amount'] > 0 ? '$' . number_format($o['billed_amount'], 2) : 'Pending' ?>
            </td>
            <td class="text-center">
              <span class="badge <?= statusClass($o['status']) ?>">
                <span class="w-1.5 h-1.5 rounded-full bg-current"></span>
                <?= statusLabel($o['status']) ?>
              </span>
            </td>
            <td class="text-center font-mono text-gray-400">
              24h Guarantee
            </td>
            <td class="text-right">
              <a href="/order-view.php?id=<?= urlencode($o['id']) ?>" class="btn-ghost py-1 px-3 text-xs font-bold text-gold hover:border-gold">
                [VIEW JOB]
              </a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>
</main>

<?php require_once __DIR__ . '/includes/chat-widgets.php'; ?>
</body>
</html>
