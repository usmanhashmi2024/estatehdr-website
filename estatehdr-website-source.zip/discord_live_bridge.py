import os
import json
import asyncio
import re
import requests
import discord
from discord.ext import commands

# ── CONFIGURATION ──────────────────────────────────────────────────
BOT_TOKEN = os.getenv("DISCORD_BOT_TOKEN", "your_discord_bot_token_here")
API_BASE_URL = "https://estatehdr.com/api/chat-live.php"
LOCAL_FALLBACK_URL = "http://127.0.0.1:8080/api/chat-live.php"

# Discord Intents
intents = discord.Intents.default()
intents.messages = True
intents.message_content = True
intents.guilds = True

bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)

# In-memory mapping from Discord message ID / Thread ID to Visitor ID
message_to_visitor = {}
last_active_visitor_id = None

def get_most_recent_active_visitor() -> str:
    """Fetch the latest active visitor from live_chats.json"""
    local_chats = os.path.join(os.path.dirname(__file__), "data", "live_chats.json")
    if os.path.exists(local_chats):
        try:
            with open(local_chats, "r", encoding="utf-8") as f:
                data = json.load(f)
                if data and isinstance(data, dict):
                    sorted_vids = sorted(data.keys(), key=lambda k: data[k].get("last_active_ts", 0), reverse=True)
                    if sorted_vids:
                        return sorted_vids[0]
        except Exception:
            pass
    return None

def forward_reply_to_website(visitor_id: str, agent_name: str, message_text: str) -> bool:
    """Send agent reply back to Estate HDR Live Chat API"""
    payload = {
        "action": "agent_send",
        "target_visitor_id": visitor_id,
        "agent_name": agent_name,
        "message": message_text
    }
    
    # Try Live Website first, fallback to localhost if offline
    for url in [API_BASE_URL, LOCAL_FALLBACK_URL]:
        try:
            res = requests.post(url, json=payload, timeout=6)
            if res.status_code == 200 and res.json().get("success"):
                return True
        except Exception as e:
            continue
    return False

@bot.event
async def on_ready():
    print("=" * 60)
    print(f"👑 Estate HDR 2-Way Discord Bridge Active!")
    print(f"Logged in as: {bot.user.name} (ID: {bot.user.id})")
    print(f"Connected to {len(bot.guilds)} Discord server(s).")
    print("=" * 60)
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="Estate HDR Live Visitors & Chat"))

@bot.event
async def on_message(message: discord.Message):
    global last_active_visitor_id

    # Ignore messages sent by bots
    if message.author.bot:
        # If a bot or webhook posted an embed, try to extract the visitor ID to track context
        if message.embeds:
            for emb in message.embeds:
                # Look in fields for Visitor ID
                for f in emb.fields:
                    if "Visitor ID" in f.name or "Client" in f.name:
                        m = re.search(r'`([a-zA-Z0-9_\-]+)`', f.value)
                        if m:
                            vid = m.group(1)
                            message_to_visitor[message.id] = vid
                            last_active_visitor_id = vid
                            print(f"[TRACKED] Registered Visitor ID {vid} to Message #{message.id}")
        return

    content = message.content.strip()
    if not content:
        return

    # Check if message is a command
    if content.startswith("!"):
        await bot.process_commands(message)
        return

    target_vid = None

    # Case A: User replied to a message in Discord (Discord Reply feature)
    if message.reference and message.reference.message_id:
        ref_id = message.reference.message_id
        if ref_id in message_to_visitor:
            target_vid = message_to_visitor[ref_id]
        else:
            # Fetch referenced message and parse embed
            try:
                ref_msg = await message.channel.fetch_message(ref_id)
                if ref_msg and ref_msg.embeds:
                    for emb in ref_msg.embeds:
                        for f in emb.fields:
                            m = re.search(r'`([a-zA-Z0-9_\-]+)`', f.value)
                            if m:
                                target_vid = m.group(1)
                                message_to_visitor[ref_id] = target_vid
                                break
            except Exception:
                pass

    # Case B: Fallback to last active visitor if no explicit reply
    if not target_vid:
        target_vid = last_active_visitor_id or get_most_recent_active_visitor()

    if target_vid:
        agent_name = f"{message.author.display_name} (Studio Manager)"
        success = forward_reply_to_website(target_vid, agent_name, content)
        
        if success:
            await message.add_reaction("✅")
            await message.reply(
                f"🚀 **Delivered to Visitor (`{target_vid}`) on EstateHDR.com!**\n> *\"{content}\"*",
                mention_author=False
            )
            print(f"[SUCCESS] Sent reply from Discord user '{message.author.name}' to Visitor '{target_vid}': {content}")
        else:
            await message.add_reaction("❌")
            await message.reply(
                f"⚠️ Could not deliver message to Visitor `{target_vid}`. Please ensure website API is reachable.",
                mention_author=False
            )
    else:
        # If no visitor ID is known yet, prompt user with help
        await bot.process_commands(message)

# ── COMMANDS ───────────────────────────────────────────────────────

@bot.command(name="reply")
async def cmd_reply(ctx, visitor_id: str, *, message_text: str):
    """Directly reply to any visitor by ID: !reply <visitor_id> <message>"""
    agent_name = f"{ctx.author.display_name} (Studio Manager)"
    success = forward_reply_to_website(visitor_id, agent_name, message_text)
    if success:
        await ctx.message.add_reaction("✅")
        await ctx.reply(f"✅ **Delivered to `{visitor_id}`:** {message_text}")
    else:
        await ctx.message.add_reaction("❌")
        await ctx.reply(f"⚠️ Failed to deliver reply to `{visitor_id}`.")

@bot.command(name="status")
async def cmd_status(ctx):
    """Check live status of the Estate HDR Platform"""
    embed = discord.Embed(
        title="👑 Estate HDR — System & Live Chat Status",
        description="Real-Time 2-Way Discord Bridge is **Active & Running**.",
        color=0xC9A84C
    )
    embed.add_field(name="🌐 Live Website", value="https://estatehdr.com", inline=True)
    embed.add_field(name="💬 Chat Engine", value="2-Way Live Bidirectional", inline=True)
    embed.add_field(name="⚡ Active Visitor ID", value=f"`{last_active_visitor_id or 'None'}`", inline=True)
    embed.add_field(name="💡 How to Reply", value="Simply **Reply to any visitor alert message** or use:\n`!reply <visitor_id> <message>`", inline=False)
    await ctx.reply(embed=embed)

@bot.command(name="report")
async def cmd_report(ctx):
    """Trigger the Executive Daily Analytics Digest immediately"""
    try:
        # Load visitors from local data directory
        data_dir = os.path.join(os.path.dirname(__file__), "data")
        visitors_file = os.path.join(data_dir, "visitors.json")
        visitors = {}
        if os.path.exists(visitors_file):
            with open(visitors_file, "r", encoding="utf-8") as f:
                visitors = json.load(f)

        embed = discord.Embed(
            title=f"📊 Estate HDR — On-Demand Executive Digest",
            description="Live aggregated visitor intelligence summary for **EstateHDR.com**.",
            color=0xC9A84C
        )
        embed.add_field(name="👥 Total Tracked Visitors", value=f"**{len(visitors)}** unique sessions", inline=True)
        embed.add_field(name="🟢 Live Bridge Status", value="Connected & Operational", inline=True)
        embed.add_field(name="🔗 Command Center", value="[Open Admin Dashboard](https://estatehdr.com/admin/live-visitors.php)", inline=False)
        await ctx.reply(embed=embed)
    except Exception as e:
        await ctx.reply(f"⚠️ Error generating report: {e}")

if __name__ == "__main__":
    bot.run(BOT_TOKEN)
