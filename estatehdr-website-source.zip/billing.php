<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
requireLogin();

if (function_exists('reconcileAllOrdersLedger')) {
    reconcileAllOrdersLedger();
}

$user = currentUser();
$balance = getUserBalance($user['id']);
$allLedger = getUserLedger($user['id']);

$searchKw   = strtolower(trim($_GET['q'] ?? ''));
$dateStart  = trim($_GET['date_start'] ?? '');
$dateEnd    = trim($_GET['date_end'] ?? '');

$filtered = array_filter($allLedger, function($item) use ($searchKw, $dateStart, $dateEnd) {
    if ($searchKw !== '') {
        $matches = str_contains(strtolower($item['id'] ?? ''), $searchKw) ||
                   str_contains(strtolower($item['order_id'] ?? ''), $searchKw) ||
                   str_contains(strtolower($item['notes'] ?? ''), $searchKw);
        if (!$matches) return false;
    }
    if ($dateStart !== '' && strtotime($item['created_at']) < strtotime($dateStart)) return false;
    if ($dateEnd !== '' && strtotime($item['created_at']) > strtotime($dateEnd . ' 23:59:59')) return false;
    return true;
});
$filtered = array_values($filtered);

// Handle CSV Export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="estatehdr_transactions_' . $user['id'] . '.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Transaction Code', 'Date', 'Amount', 'Payment Method', 'Description', 'Job ID']);
    foreach ($filtered as $row) {
        $sign = $row['type'] === 'billed' ? '-' : '+';
        fputcsv($out, [
            $row['id'],
            date('Y-m-d H:i', strtotime($row['created_at'])),
            $sign . '$' . number_format($row['amount'], 2),
            $row['payment_method'] ?? 'System Ledger',
            $row['notes'] ?? '',
            $row['order_id'] ?? ''
        ]);
    }
    fclose($out);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Transaction History — Estate HDR</title>
<meta name="robots" content="noindex">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/includes/portal-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8">
  <!-- Back Navigation -->
  <div class="mb-4">
    <a href="/dashboard.php" class="btn-ghost py-2 px-4 text-xs font-bold inline-flex items-center gap-2 border border-[#1E1E2E] hover:border-gold rounded-xl">
      <span>←</span> <span>Back to Dashboard</span>
    </a>
  </div>
  <?= renderFlash() ?>
  <div class="mb-6">
    <div class="section-tag mb-1">Account Statement</div>
    <h1 class="text-2xl sm:text-3xl font-black text-white">TRANSACTION HISTORY</h1>
    <p class="text-gray-400 text-xs mt-1">Audit log of all billed jobs, received external payments, and current outstanding balances.</p>
  </div>

  <!-- Search Filter & Export Bar -->
  <div class="glass-card rounded-2xl p-5 mb-8 border border-dark-border shadow-xl">
    <form method="GET" class="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
      <div class="sm:col-span-4">
        <label class="form-label text-xs">Search Job ID (ORD-5001) / Transaction Code</label>
        <input type="text" name="q" value="<?= htmlspecialchars($_GET['q'] ?? '') ?>" class="form-input text-xs py-2" placeholder="e.g. ORD-5001 or TXN...">
      </div>

      <div class="sm:col-span-3">
        <label class="form-label text-xs">Date Start</label>
        <input type="date" name="date_start" value="<?= htmlspecialchars($dateStart) ?>" class="form-input text-xs py-2 text-gray-300">
      </div>

      <div class="sm:col-span-3">
        <label class="form-label text-xs">Date End</label>
        <input type="date" name="date_end" value="<?= htmlspecialchars($dateEnd) ?>" class="form-input text-xs py-2 text-gray-300">
      </div>

      <div class="sm:col-span-2 flex gap-2">
        <button type="submit" class="btn-gold py-2 px-3 text-xs font-bold flex-1">Search</button>
        <a href="?export=csv<?= !empty($_SERVER['QUERY_STRING']) ? '&' . htmlspecialchars($_SERVER['QUERY_STRING']) : '' ?>" 
           class="btn-ghost py-2 px-3 text-xs font-bold text-gray-300 hover:text-white" title="Export to CSV">
          Export
        </a>
      </div>
    </form>
  </div>

  <!-- Transactions Table (Screenshot 4) -->
  <div class="glass-card rounded-2xl overflow-hidden border border-dark-border shadow-2xl">
    <div class="p-4 border-b border-dark-border flex items-center justify-between">
      <h3 class="text-xs font-bold text-white uppercase tracking-wider">STATEMENT AUDIT LOG</h3>
      <div class="flex items-center gap-4 text-xs">
        <span class="text-gray-400">Total Billed: <strong class="text-gold font-mono">$<?= number_format($balance['total_billed'], 2) ?></strong></span>
        <span class="text-gray-400">Paid: <strong class="text-green-400 font-mono">$<?= number_format($balance['total_paid'], 2) ?></strong></span>
        <span class="text-gray-400">Balance: <strong class="<?= $balance['outstanding_balance'] > 0 ? 'text-amber-400' : 'text-green-400' ?> font-mono font-bold">$<?= number_format($balance['outstanding_balance'], 2) ?></strong></span>
      </div>
    </div>

    <?php if (empty($filtered)): ?>
    <div class="p-16 text-center text-gray-500 text-sm">
      <div class="text-4xl mb-2">💳</div>
      <p class="text-white font-bold mb-1">No transaction records found</p>
      <p class="text-xs text-gray-400">Billed jobs and payment receipts will appear here.</p>
    </div>
    <?php else: ?>
    <div class="overflow-x-auto">
      <table class="dashboard-table w-full text-left text-xs">
        <thead>
          <tr>
            <th>Transaction Code</th>
            <th>Date</th>
            <th class="text-right">Amount</th>
            <th>Payment Method</th>
            <th>Description / Job ID</th>
            <th class="text-right">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($filtered as $item): ?>
          <tr>
            <td class="font-mono text-gray-300 font-semibold">
              #<?= strtoupper(substr($item['id'] ?? 'TXN', 0, 14)) ?>
            </td>
            <td class="text-gray-400 font-mono">
              <?= date('M j, Y - H:i', strtotime($item['created_at'])) ?>
            </td>
            <td class="text-right font-mono font-bold <?= $item['type'] === 'billed' ? 'text-amber-400' : 'text-green-400' ?>">
              <?= $item['type'] === 'billed' ? '-$' : '+$' ?><?= number_format($item['amount'], 2) ?>
            </td>
            <td class="text-gray-300 font-mono text-xs">
              <?= htmlspecialchars($item['payment_method'] ?? 'Balance (Credit)') ?>
            </td>
            <td class="text-gray-300">
              <?php if (!empty($item['order_id'])): ?>
                <span class="text-gold font-mono font-bold mr-1">[<?= strtoupper($item['order_id']) ?>]</span>
              <?php endif; ?>
              <?= htmlspecialchars($item['notes'] ?? 'Order Billed') ?>
            </td>
            <td class="text-right">
              <?php if (!empty($item['order_id'])): ?>
              <a href="/order-view.php?id=<?= urlencode($item['order_id']) ?>" class="btn-ghost py-1 px-2.5 text-xs font-bold text-gold hover:border-gold">
                [VIEW JOB]
              </a>
              <?php else: ?>
              <span class="text-gray-600 text-xs">—</span>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>
</main>

<?php require_once __DIR__ . '/includes/chat-widgets.php'; ?>
</body>
</html>
