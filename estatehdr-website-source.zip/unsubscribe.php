<?php
declare(strict_types=1);

/**
 * Estate HDR — One-Click Marketing Unsubscribe Handler
 * GDPR & CAN-SPAM compliant unsubscribe landing page.
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/services/EmailCrmService.php';

use EstateHDR\Services\EmailCrmService;

$campaignId = trim($_GET['c'] ?? '');
$contactId = trim($_GET['u'] ?? '');
$token = trim($_GET['t'] ?? '');

$contact = !empty($contactId) ? EmailCrmService::getContactById($contactId) : null;
$unsubscribed = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' || isset($_GET['confirm'])) {
    if (!empty($contactId)) {
        EmailCrmService::recordUnsubscribe($campaignId, $contactId);
        $unsubscribed = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unsubscribe Preferences — Estate HDR</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { background: #0A0A0F; color: #FFFFFF; font-family: 'Nunito', sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; padding: 20px; }
        .card { background: #12131C; border: 1px solid rgba(201,168,76,0.3); border-radius: 20px; padding: 40px; text-align: center; max-width: 480px; box-shadow: 0 25px 50px rgba(0,0,0,0.5); }
        .gold { color: #C9A84C; font-weight: 800; }
        .btn-unsub { background: #E11D48; color: #FFF; font-weight: 800; padding: 12px 28px; border-radius: 12px; border: none; cursor: pointer; font-size: 15px; margin-top: 20px; }
        .btn-home { display: inline-block; background: #C9A84C; color: #000; font-weight: 800; padding: 12px 28px; border-radius: 12px; text-decoration: none; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="card">
        <?php if ($unsubscribed || ($contact && ($contact['status'] ?? '') === 'unsubscribed')): ?>
            <div style="font-size: 48px; margin-bottom: 16px;">🔕</div>
            <h1 class="gold" style="font-size: 24px; margin: 0 0 10px;">You Have Been Unsubscribed</h1>
            <p style="color: #9CA3AF; line-height: 1.6; margin: 0 0 16px;">
                <strong><?= htmlspecialchars($contact['email'] ?? 'Your email') ?></strong> has been removed from our marketing and promotional email sequences.
            </p>
            <p style="color: #6B7280; font-size: 13px; margin: 0;">
                You may still receive critical transactional notifications regarding active photo editing orders.
            </p>
            <a href="/" class="btn-home">Return to Estate HDR ↗</a>
        <?php else: ?>
            <div style="font-size: 48px; margin-bottom: 16px;">✉️</div>
            <h1 class="gold" style="font-size: 24px; margin: 0 0 10px;">Email Subscription Preferences</h1>
            <p style="color: #9CA3AF; line-height: 1.6; margin: 0 0 20px;">
                Are you sure you want to stop receiving luxury property editing tips, discount offers, and digest emails for <strong><?= htmlspecialchars($contact['email'] ?? 'your email') ?></strong>?
            </p>
            <form method="POST" action="">
                <button type="submit" class="btn-unsub">Yes, Unsubscribe Me</button>
            </form>
            <p style="margin-top: 20px;">
                <a href="/" style="color: #9CA3AF; font-size: 13px; text-decoration: underline;">Cancel and return home</a>
            </p>
        <?php endif; ?>
    </div>
</body>
</html>
