<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
requireLogin();

$user    = currentUser();
$orderId = trim($_GET['id'] ?? '');
$order   = getOrder($orderId);

if (!$order || $order['user_id'] !== $user['id']) {
    setFlash('error', 'Order not found or access denied.');
    header('Location: /dashboard.php');
    exit;
}

// Handle amendment revision request or job approval
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    verifyCsrf();
    $action = $_POST['action'];

    if ($action === 'amendment') {
        $notes = trim($_POST['amendment_notes'] ?? '');
        if (strlen($notes) < 3) {
            setFlash('error', 'Please describe the changes needed for your revision.');
        } else {
            triggerAmendmentRequested($orderId, $notes);
            setFlash('success', "Amendment request submitted for Job #" . strtoupper($orderId) . "! Our retouching team and quality leads have been alerted.");
        }
    } elseif ($action === 'approve_order') {
        updateOrderStatus($orderId, 'completed');
        setFlash('success', "Job #" . strtoupper($orderId) . " marked as Approved & Completed! Thank you for working with Estate HDR.");
    }

    header('Location: /order-view.php?id=' . urlencode($orderId));
    exit;
}

$order = getOrder($orderId); // reload after POST
$canAmend = in_array($order['status'], ['delivered', 'amendment_requested', 'completed']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Job <?= strtoupper($order['id']) ?> — <?= htmlspecialchars($order['property_name']) ?> — Estate HDR</title>
<meta name="robots" content="noindex">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/includes/portal-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8">
  <!-- Back Navigation -->
  <div class="mb-4">
    <a href="/dashboard.php" class="btn-ghost py-2 px-4 text-xs font-bold inline-flex items-center gap-2 border border-[#1E1E2E] hover:border-gold rounded-xl">
      <span>←</span> <span>Back to Dashboard</span>
    </a>
  </div>
  <?= renderFlash() ?>
  <?= renderFlash() ?>

  <!-- Order Header & Identification -->
  <div class="glass-card rounded-2xl p-6 mb-6 border border-dark-border shadow-xl">
    <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
      <div>
        <div class="flex flex-wrap items-center gap-3 mb-3">
          <span class="text-sm font-mono font-black px-3.5 py-1.5 rounded-lg bg-gold text-dark shadow-glow flex items-center gap-1.5">
            <span>📦 ORDER ID:</span> <span><?= strtoupper($order['id']) ?></span>
          </span>
          <span class="text-xs text-gray-300 font-mono bg-dark px-3 py-1.5 rounded-lg border border-dark-border">
            👤 CID: <strong class="text-white"><?= strtoupper($user['id']) ?></strong>
          </span>
          <?php 
          $isOrderTrial = !empty($order['is_trial']) || (($order['order_type'] ?? '') === 'free_trial') || stripos($order['id'], 'TRIAL-') === 0;
          if ($isOrderTrial): ?>
            <span class="text-xs font-black px-3.5 py-1.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm flex items-center gap-1.5">
              <span>🎁 FREE TRIAL</span> <span>($0.00 COMPLIMENTARY)</span>
            </span>
          <?php endif; ?>
        </div>
        <h1 class="text-2xl sm:text-3xl font-black text-white"><?= htmlspecialchars($order['property_name']) ?></h1>
        <div class="flex items-center gap-4 mt-2 text-xs text-gray-400 flex-wrap">
          <span class="text-gray-300 font-medium bg-dark-card border border-dark-border px-2.5 py-1 rounded-lg">
            <?= htmlspecialchars($order['service_type']) ?>
          </span>
          <span>Submitted: <?= date('M j, Y \a\t g:i A', strtotime($order['created_at'])) ?></span>
        </div>
      </div>

      <div class="flex flex-col items-start sm:items-end gap-2">
        <span class="badge <?= statusClass($order['status']) ?> text-sm px-3.5 py-1.5">
          <span class="w-2 h-2 rounded-full bg-current"></span>
          <?= statusLabel($order['status']) ?>
        </span>
        <a href="/client/review.php?id=<?= urlencode($order['id']) ?>" class="px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-amber-500 to-gold text-black shadow-glow inline-flex items-center gap-1.5 hover:opacity-90 transition">
          <span>🔍</span> <span>Interactive Proofing &amp; Revisions &rarr;</span>
        </a>
        <?php if ($order['status'] === 'delivered'): ?>
        <form method="POST">
          <?= csrfField() ?>
          <input type="hidden" name="action" value="approve_order">
          <button type="submit" class="btn-gold text-xs py-1.5 px-4 font-bold shadow-glow">
            ✓ Approve &amp; Complete Job
          </button>
        </form>
        <?php endif; ?>
      </div>
    </div>

    <!-- Image Count & Financial Metrics Bar -->
    <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-6 pt-5 border-t border-dark-border">
      <div class="bg-dark/70 rounded-xl p-3 border border-dark-border">
        <div class="text-xs text-gray-400 uppercase font-semibold">Raw Images Submitted</div>
        <div class="text-lg font-bold text-white mt-0.5 font-mono"><?= $order['raw_images_count'] ?> photos</div>
      </div>
      <div class="bg-dark/70 rounded-xl p-3 border border-dark-border">
        <div class="text-xs text-gold uppercase font-semibold">Final Delivered Images</div>
        <div class="text-lg font-bold text-gold mt-0.5 font-mono">
          <?= $order['delivered_images_count'] > 0 ? $order['delivered_images_count'] . ' photos' : 'Pending' ?>
        </div>
      </div>
      <div class="bg-dark/70 rounded-xl p-3 border border-dark-border">
        <div class="text-xs text-gray-400 uppercase font-semibold">Billed Cost</div>
        <div class="text-lg font-bold mt-0.5 font-mono">
          <?php if ($isOrderTrial): ?>
            <span class="text-emerald-400 font-bold">$0.00 (100% Free Trial)</span>
          <?php else: ?>
            <span class="text-white"><?= $order['billed_amount'] > 0 ? '$' . number_format($order['billed_amount'], 2) : '—' ?></span>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <?php 
  $hasWatermark = !empty($order['watermark_url']);
  $hasFinal     = !empty($order['final_cloud_link']) || (!empty($order['delivery_url']) && in_array($order['status'], ['delivered', 'completed', 'sent_client']));
  $billedPrice  = (float)($order['billed_amount'] ?? 0);
  $paypalEmail  = defined('PAYPAL_EMAIL') ? PAYPAL_EMAIL : 'ashrafnadeem283@gmail.com';
  $paypalMeLink = defined('PAYPAL_ME_LINK') ? PAYPAL_ME_LINK : 'https://www.paypal.com/paypalme/ashrafnadeem283';
  ?>

  <!-- ── DUAL DELIVERABLES SHOWCASE CARD ── -->
  <?php if ($hasWatermark || $hasFinal): ?>
  <div class="glass-card rounded-2xl p-5 mb-6 border <?= $hasFinal ? 'border-emerald-500/40 bg-emerald-950/10' : 'border-amber-500/40 bg-amber-950/10' ?> shadow-xl space-y-4">
    <div class="flex items-center justify-between border-b border-white/5 pb-3">
      <div class="flex items-center gap-2">
        <span class="text-xl"><?= $hasFinal ? '✨' : '💧' ?></span>
        <h3 class="text-sm font-bold text-white uppercase tracking-wider">
          <?= $hasFinal ? 'Final Clean Deliverables Ready' : 'Watermarked Photo Proofs Ready for Review' ?>
        </h3>
      </div>
      <?php if ($hasWatermark && !$hasFinal): ?>
        <span class="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/40">Proofing Mode &bull; Awaiting Payment</span>
      <?php elseif ($hasFinal): ?>
        <span class="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">Clean Files Unlocked (No Watermark)</span>
      <?php endif; ?>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-<?= ($hasWatermark && $hasFinal) ? '2' : '1' ?> gap-3.5">
      <?php if ($hasWatermark): ?>
      <div class="p-4 rounded-xl bg-dark/80 border border-amber-500/30 space-y-2">
        <div class="flex items-center justify-between">
          <span class="text-xs font-bold text-amber-300 flex items-center gap-1.5">
            <span>💧</span> <span>Watermarked Photo Proofs</span>
          </span>
          <span class="text-[10px] text-gray-400">Review Quality</span>
        </div>
        <p class="text-[11px] text-gray-300 leading-relaxed">
          These preview photos contain a protective watermark for review. Inspect color tone, lighting, and window clarity.
        </p>
        <a href="<?= htmlspecialchars($order['watermark_url']) ?>" target="_blank" rel="noopener noreferrer"
           class="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 font-bold text-xs transition-all shadow-sm">
          <span>📥 Download &amp; Inspect Watermarked Proofs ↗</span>
        </a>
      </div>
      <?php endif; ?>

      <?php if ($hasFinal): ?>
      <div class="p-4 rounded-xl bg-dark/80 border border-emerald-500/40 space-y-2">
        <div class="flex items-center justify-between">
          <span class="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
            <span>✨</span> <span>Final Photos (Without Watermark)</span>
          </span>
          <span class="text-[10px] text-emerald-300 font-bold">MLS Ready</span>
        </div>
        <p class="text-[11px] text-gray-300 leading-relaxed">
          Clean, full-resolution deliverables without watermarks ready for immediate MLS listing and marketing publication.
        </p>
        <a href="<?= htmlspecialchars($order['final_cloud_link'] ?: $order['delivery_url']) ?>" target="_blank" rel="noopener noreferrer"
           class="btn-gold py-2 px-4 text-xs font-black inline-flex items-center gap-2 shadow-glow">
          <span>📥 Download Final Clean Photos (No Watermark) ↗</span>
        </a>
      </div>
      <?php endif; ?>
    </div>

    <!-- If watermark sent but final not unlocked yet and order not free trial, show PayPal payment prompt -->
    <?php if ($hasWatermark && !$hasFinal && !$isOrderTrial && $billedPrice > 0): ?>
    <div class="p-4 rounded-xl bg-[#0f111a] border border-gold/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
      <div>
        <div class="text-xs font-bold text-gold flex items-center gap-1.5">
          <span>💳</span> <span>Complete Payment of $<?= number_format($billedPrice, 2) ?> USD to Unlock Final Clean Photos</span>
        </div>
        <div class="text-[11px] text-gray-400 mt-0.5">
          Send payment to PayPal: <strong class="text-white font-mono"><?= htmlspecialchars($paypalEmail) ?></strong> (Ref: <span class="text-gold font-mono font-bold">INV-<?= strtoupper($order['id']) ?></span>)
        </div>
      </div>
      <a href="<?= htmlspecialchars($paypalMeLink) ?>" target="_blank" rel="noopener noreferrer"
         class="px-4 py-2 rounded-xl text-xs font-bold bg-[#0070BA] hover:bg-[#003087] text-white shadow-md inline-flex items-center gap-1.5 whitespace-nowrap self-start sm:self-auto transition-all">
        <span>💳 Pay via PayPal Online ↗</span>
      </a>
    </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <!-- Ticket Conversation Thread -->
  <div class="space-y-4 mb-6">
    <div class="flex items-center justify-between px-1">
      <h2 class="text-xs font-bold text-gray-400 uppercase tracking-wider">JOB AUDIT &amp; MESSAGE THREAD</h2>
      <span class="text-xs text-gold font-mono font-bold">Ref: #<?= strtoupper($order['id']) ?></span>
    </div>

    <?php foreach ($order['messages'] as $msg): ?>
    <?php 
      $isAdmin = ($msg['sender'] === 'admin'); 
      $isAmendment = ($msg['type'] === 'amendment');
      $isResolved = ($msg['type'] === 'amendment_resolved');
      $isWatermarkMsg = ($msg['type'] === 'watermark_proof');
    ?>
    <div class="flex <?= $isAdmin ? 'justify-start' : 'justify-end' ?>">
      <div class="message-bubble <?= $isAdmin ? 'admin' : 'client' ?> <?= $isAmendment ? 'border-2 border-amber-500/40 bg-amber-950/20' : '' ?> <?= $isResolved ? 'border-2 border-emerald-500/50 bg-emerald-950/25' : '' ?> <?= $isWatermarkMsg ? 'border-2 border-amber-500/50 bg-amber-950/30' : '' ?> max-w-[85%]">
        <div class="flex flex-wrap items-center gap-2.5 mb-2.5 pb-2 border-b border-white/5">
          <span class="px-2 py-0.5 rounded text-[11px] font-mono font-black bg-gold/20 text-gold border border-gold/40">
            <?= strtoupper($order['id']) ?>
          </span>
          <span class="text-xs font-bold <?= $isAdmin ? 'text-gold' : 'text-blue-400' ?>">
            <?= $isAdmin ? '✦ Estate HDR Admin' : '👤 You' ?>
          </span>
          <span class="message-type-badge type-<?= $msg['type'] ?> text-[10px] uppercase font-bold"><?= ucfirst(str_replace('_', ' ', $msg['type'])) ?></span>
          <span class="text-gray-400 text-xs ml-auto font-mono"><?= date('M j, g:i A', strtotime($msg['timestamp'])) ?></span>
        </div>

        <?php if (!empty($msg['content'])): ?>
        <p class="text-gray-200 text-sm leading-relaxed whitespace-pre-wrap font-sans"><?= htmlspecialchars($msg['content']) ?></p>
        <?php endif; ?>

        <?php if (!empty($msg['cloud_link'])): ?>
        <div class="mt-3 pt-3 border-t border-white/5">
          <?php if ($isWatermarkMsg): ?>
          <a href="<?= htmlspecialchars($msg['cloud_link']) ?>" target="_blank" rel="noopener noreferrer"
             class="py-2 px-5 text-xs font-bold inline-flex items-center gap-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 shadow-sm">
            <span>💧 Download Watermarked Proofs ↗</span>
          </a>
          <?php else: ?>
          <a href="<?= htmlspecialchars($msg['cloud_link']) ?>" target="_blank" rel="noopener noreferrer"
             class="btn-gold py-2 px-5 text-xs font-bold inline-flex items-center gap-2 shadow-glow">
            <svg class="w-4 h-4 text-dark" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
            <span><?= $isAdmin ? '📥 Download Delivered High-Res Photos' : '📁 Open Uploaded Raw Files' ?> ↗</span>
          </a>
          <?php endif; ?>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Amendment Form -->
  <?php if ($canAmend): ?>
  <div class="glass-card rounded-2xl p-6 border border-gold/30 shadow-xl bg-gradient-to-br from-dark-card to-dark">
    <div class="flex items-center justify-between mb-2">
      <h3 class="text-base font-bold text-white flex items-center gap-2">
        <span>🔄</span> <span>Request Free Amendments / Tweaks</span>
      </h3>
      <span class="text-xs font-mono font-bold text-gold bg-gold/10 px-2 py-0.5 rounded border border-gold/30">
        Job #<?= strtoupper($order['id']) ?>
      </span>
    </div>
    <p class="text-gray-400 text-xs mb-4">Specify the adjustments needed. Our retouching team will immediately receive this revision under Job #<?= strtoupper($order['id']) ?>.</p>
    
    <form method="POST" class="space-y-4">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="amendment">

      <div>
        <label class="form-label text-xs">Revision Instructions for Job #<?= strtoupper($order['id']) ?> <span class="text-red-400">*</span></label>
        <textarea name="amendment_notes" rows="4" class="form-input resize-y text-sm"
                  placeholder="e.g. In photo #4, please brighten ceiling shadow and enhance sunset sky in exterior pool shot..." required></textarea>
      </div>

      <button type="submit" class="btn-gold py-2.5 px-6 font-bold shadow-glow text-xs">
        Submit Amendment Request for Job #<?= strtoupper($order['id']) ?> &rarr;
      </button>
    </form>
  </div>
  <?php endif; ?>
</main>

<?php require_once __DIR__ . '/includes/chat-widgets.php'; ?>
</body>
</html>
