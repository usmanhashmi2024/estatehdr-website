# Video Assets

Hero background video (hero.mp4) was excluded to keep repository size under GitHub web upload limits (< 25MB).
