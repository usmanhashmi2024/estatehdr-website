/**
 * Estate HDR — WYSIWYG Pro Editor Engine
 * Notion-style Slash Commands (/), Rich Modals, Smart Table Paste, Drag & Drop Uploads, and Responsive Device Preview
 */

window.EstateEditor = (function() {
  let editorEl = null;
  let textareaEl = null;
  let savedRange = null;
  let slashPalette = null;
  let slashActiveIndex = 0;
  let slashSearchTerm = '';
  let slashRange = null;

  const slashCommands = [
    { id: 'fullscreen', icon: '⛶', label: 'Fullscreen Zen Mode', desc: 'Expand editor to distraction-free full screen', action: () => openFullscreenModal() },
    { id: 'upload_image', icon: '📸', label: 'Upload Image', desc: 'Upload photo directly from your computer', action: () => triggerImageUploadDirect() },
    { id: 'image_url', icon: '🖼️', label: 'Image via URL / Library', desc: 'Insert image with custom alt text & layout', action: () => openImageModal() },
    { id: 'h1', icon: '🏷️', label: 'Heading 1 (H1)', desc: 'Large section heading (2.25rem White)', action: () => applyHeading('h1') },
    { id: 'h2', icon: '📌', label: 'Heading 2 (H2)', desc: 'Medium section heading (1.75rem Gold)', action: () => applyHeading('h2') },
    { id: 'h3', icon: '🔖', label: 'Heading 3 (H3)', desc: 'Small subsection heading (1.4rem Yellow)', action: () => applyHeading('h3') },
    { id: 'bullet_list', icon: '•', label: 'Bullet List', desc: 'Unordered scannable bullet list', action: () => execCmd('insertUnorderedList') },
    { id: 'number_list', icon: '1.', label: 'Numbered List', desc: 'Sequential ordered list', action: () => execCmd('insertOrderedList') },
    { id: 'raw_html', icon: '</>', label: 'Raw HTML / Custom Code', desc: 'Embed custom HTML, iframes, widgets', action: () => openRawHtmlModal('html') },
    { id: 'schema_markup', icon: '✨', label: 'Schema Markup (JSON-LD)', desc: 'Insert SEO Structured Data schema', action: () => openRawHtmlModal('schema') },
    { id: 'comparison_grid', icon: '📊', label: 'Comparison Grid (Traditional vs Estate HDR)', desc: '2-Column comparison cards with pricing & turnaround', action: () => insertComparisonGrid() },
    { id: 'cta_banner', icon: '📢', label: '24h Turnaround CTA Banner', desc: 'High-converting free trial & 24h guarantee box', action: () => insertCtaBox() },
    { id: 'table', icon: '📊', label: 'Insert Table', desc: 'Customizable rows, columns & headers', action: () => openTableModal() },
    { id: 'quote', icon: '❝', label: 'Blockquote', desc: 'Gold highlighted quote callout', action: () => insertBlockquote() },
    { id: 'callout', icon: '💡', label: 'Callout Box / Alert', desc: 'Highlight important tips or key takeaways', action: () => insertCalloutBox() },
    { id: 'cta_button', icon: '🔘', label: 'CTA Button', desc: 'Insert high-converting action button', action: () => openCtaModal() },
    { id: 'divider', icon: '➖', label: 'Divider', desc: 'Horizontal separation line', action: () => insertHorizontalRule() },
    { id: 'video', icon: '🎥', label: 'Video Embed', desc: 'Embed YouTube or Vimeo player', action: () => openVideoModal() },
    { id: 'code', icon: '💻', label: 'Code Snippet', desc: 'Pre-formatted code block', action: () => insertCodeBlock() }
  ];

  function getActiveEditor() {
    const fsModal = document.getElementById('modalFullscreenEditor');
    if (fsModal && !fsModal.classList.contains('hidden')) {
      const fsVisual = document.getElementById('editorVisualFullscreen');
      if (fsVisual && !fsVisual.classList.contains('hidden')) return fsVisual;
    }
    return editorEl;
  }

  function init(options) {
    options = options || {};
    editorEl = document.getElementById(options.editorId || 'editorVisual');
    textareaEl = document.getElementById(options.textareaId || 'pageContent');

    if (!editorEl) return;

    createSlashPalette();
    createModals();
    bindEditorEvents();
    initFeaturedImageUploader();
  }

  function saveSelection() {
    const sel = window.getSelection();
    if (sel && sel.rangeCount > 0) {
      savedRange = sel.getRangeAt(0).cloneRange();
    }
    detectActiveHeading();
  }

  function restoreSelection() {
    if (savedRange) {
      const sel = window.getSelection();
      if (sel && typeof sel.removeAllRanges === 'function') {
        sel.removeAllRanges();
        sel.addRange(savedRange);
      }
    }
  }

  function detectActiveHeading() {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return;
    let node = sel.anchorNode;
    if (!node) return;
    if (node.nodeType === Node.TEXT_NODE) node = node.parentNode;

    let currentTag = 'p';
    let curr = node;
    const active = getActiveEditor() || editorEl;
    while (curr && curr !== active && curr !== document.body) {
      const tag = curr.tagName ? curr.tagName.toLowerCase() : '';
      if (['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'blockquote', 'pre'].includes(tag)) {
        currentTag = tag;
        break;
      }
      curr = curr.parentNode;
    }

    const selectMain = document.getElementById('editorHeadingSelect');
    const selectFs = document.getElementById('fullscreenHeadingSelect');
    if (selectMain) selectMain.value = currentTag;
    if (selectFs) selectFs.value = currentTag;

    const badgeMain = document.getElementById('editorActiveBlockBadge');
    const badgeFs = document.getElementById('fullscreenActiveBlockBadge');
    const tagNames = {
      p: 'Paragraph (P)',
      h1: 'Heading 1 (H1)',
      h2: 'Heading 2 (H2)',
      h3: 'Heading 3 (H3)',
      h4: 'Heading 4 (H4)',
      h5: 'Heading 5 (H5)',
      h6: 'Heading 6 (H6)',
      blockquote: 'Quote',
      pre: 'Code'
    };
    const label = tagNames[currentTag] || currentTag.toUpperCase();
    if (badgeMain) badgeMain.textContent = label;
    if (badgeFs) badgeFs.textContent = label;
  }

  function execCmd(command, value = null) {
    const active = getActiveEditor();
    if (active) active.focus();
    document.execCommand(command, false, value);
    if (active && active.id === 'editorVisualFullscreen') {
      syncFullscreenToMain();
    } else {
      syncVisualToTextarea();
    }
    detectActiveHeading();
  }

  function applyHeading(tag) {
    if (!tag) return;
    const active = getActiveEditor();
    if (active) active.focus();
    restoreSelection();
    const cleanTag = tag.toLowerCase().replace(/[<>]/g, '');
    let formatted = false;
    try {
      formatted = document.execCommand('formatBlock', false, `<${cleanTag}>`);
    } catch (e) {}
    if (!formatted) {
      try {
        document.execCommand('formatBlock', false, cleanTag);
      } catch (e) {}
    }
    if (active && active.id === 'editorVisualFullscreen') {
      syncFullscreenToMain();
    } else {
      syncVisualToTextarea();
    }
    detectActiveHeading();
  }

  function syncVisualToTextarea() {
    if (editorEl && textareaEl) {
      textareaEl.value = editorEl.innerHTML;
      if (typeof window.runReadabilityAudit === 'function') {
        window.runReadabilityAudit();
      }
    }
  }

  function syncTextareaToVisual() {
    if (editorEl && textareaEl) {
      editorEl.innerHTML = textareaEl.value;
      if (typeof window.runReadabilityAudit === 'function') {
        window.runReadabilityAudit();
      }
    }
  }

  function insertHtmlAtSelection(html) {
    const active = getActiveEditor();
    if (active) active.focus();
    restoreSelection();
    
    const sel = window.getSelection();
    if (sel && sel.rangeCount > 0) {
      const range = sel.getRangeAt(0);
      range.deleteContents();
      
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = html;
      const frag = document.createDocumentFragment();
      let node;
      let lastNode;
      while ((node = tempDiv.firstChild)) {
        lastNode = frag.appendChild(node);
      }
      range.insertNode(frag);
      
      if (lastNode) {
        range.setStartAfter(lastNode);
        range.collapse(true);
        sel.removeAllRanges();
        sel.addRange(range);
      }
    } else {
      document.execCommand('insertHTML', false, html);
    }

    if (active && active.id === 'editorVisualFullscreen') {
      syncFullscreenToMain();
    } else {
      syncVisualToTextarea();
    }
  }

  // ── Smart Table & Content Paste Handler ───────────────────────
  function cleanAndFormatPastedHtml(html) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');

    // Clean tables with explicit high-contrast styling (prevents white-on-white text)
    doc.querySelectorAll('table').forEach(tbl => {
      tbl.className = 'w-full my-5 border-collapse border border-[#2D2D3F] rounded-xl overflow-hidden shadow-xl bg-[#0E0E16] text-[#F1F5F9]';
      tbl.removeAttribute('style');
      tbl.removeAttribute('width');
      tbl.removeAttribute('cellspacing');
      tbl.removeAttribute('cellpadding');
    });

    doc.querySelectorAll('th').forEach(th => {
      th.className = 'bg-[#161622] text-[#C9A84C] p-3.5 border border-[#2D2D3F] font-black text-xs uppercase tracking-wider text-left';
      th.removeAttribute('style');
    });

    doc.querySelectorAll('td').forEach(td => {
      td.className = 'p-3.5 border border-[#2D2D3F] text-[#F1F5F9] text-xs bg-[#0E0E16] font-normal leading-relaxed';
      td.removeAttribute('style');
    });

    doc.querySelectorAll('tr').forEach((tr, i) => {
      tr.removeAttribute('style');
      if (i % 2 === 1) tr.classList.add('bg-[#14141F]');
    });

    // Clean lists
    doc.querySelectorAll('ul').forEach(ul => {
      ul.className = 'list-disc ml-6 my-3 space-y-1.5 text-gray-300 text-sm';
      ul.removeAttribute('style');
    });

    doc.querySelectorAll('ol').forEach(ol => {
      ol.className = 'list-decimal ml-6 my-3 space-y-1.5 text-gray-300 text-sm';
      ol.removeAttribute('style');
    });

    // Clean headings
    doc.querySelectorAll('h1').forEach(h => { h.className = 'text-2xl sm:text-3xl font-black text-white my-4'; h.removeAttribute('style'); });
    doc.querySelectorAll('h2').forEach(h => { h.className = 'text-xl sm:text-2xl font-black text-white my-3 border-b border-[#1E1E2E] pb-2'; h.removeAttribute('style'); });
    doc.querySelectorAll('h3').forEach(h => { h.className = 'text-lg sm:text-xl font-bold text-gold my-2.5'; h.removeAttribute('style'); });

    // Clean images
    doc.querySelectorAll('img').forEach(img => {
      img.className = 'my-4 rounded-xl border border-[#1E1E2E] shadow-xl max-w-full h-auto';
      img.removeAttribute('style');
    });

    // Clean links
    doc.querySelectorAll('a').forEach(a => {
      a.className = 'text-gold hover:underline font-bold';
      a.removeAttribute('style');
    });

    // Clean blockquotes
    doc.querySelectorAll('blockquote').forEach(bq => {
      bq.className = 'border-l-4 border-gold bg-[#161622]/40 p-4 my-4 rounded-r-xl italic text-gray-300 text-sm';
      bq.removeAttribute('style');
    });

    // Normalize paragraphs and remove messy external inline styles that disrupt line-height
    doc.querySelectorAll('p, span').forEach(el => {
      el.removeAttribute('style');
    });

    // Remove empty paragraphs
    doc.querySelectorAll('p').forEach(p => {
      if (!p.textContent.trim() && !p.querySelector('img, video, iframe, table')) {
        p.remove();
      }
    });

    // Remove unwanted Microsoft Word / meta tags
    doc.querySelectorAll('style, script, meta, link, xml, o\\:p').forEach(n => n.remove());

    return doc.body.innerHTML;
  }

  function formatPlainTextToHtml(text) {
    if (!text) return '';
    const normalized = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').trim();
    // Split into real paragraphs by double newlines
    const paragraphs = normalized.split(/\n{2,}/);
    return paragraphs.map(p => {
      // Flow lines within a paragraph together with a space so lines don't break awkwardly every few words
      const flowed = p.split('\n').map(l => l.trim()).filter(Boolean).join(' ');
      return `<p>${flowed}</p>`;
    }).join('');
  }

  function getCsrfToken() {
    if (window.CSRF_TOKEN) return window.CSRF_TOKEN;
    const meta = document.querySelector('meta[name="csrf-token"]');
    if (meta && meta.content) return meta.content;
    const input = document.querySelector('input[name="csrf_token"]');
    if (input && input.value) return input.value;
    return '';
  }

  function uploadAndInsertImageDirect(file) {
    if (!file || !file.type || !file.type.startsWith('image/')) return;
    if (window.EstateDialog) EstateDialog.toast('Uploading dropped image...', 'info');

    const formData = new FormData();
    formData.append('image', file);
    const csrf = getCsrfToken();
    if (csrf) formData.append('csrf_token', csrf);

    fetch('/api/upload-image.php', {
      method: 'POST',
      headers: csrf ? { 'X-CSRF-TOKEN': csrf } : {},
      body: formData
    })
    .then(r => r.json())
    .then(data => {
      if (data.success && data.url) {
        const alt = data.alt || file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
        const imgHtml = `<p><img src="${data.url}" alt="${alt}" class="my-4 rounded-xl border border-[#1E1E2E] shadow-xl max-w-full h-auto"></p><p></p>`;
        insertHtmlAtSelection(imgHtml);
        syncVisualToTextarea();
        if (window.EstateDialog) EstateDialog.toast('✅ Image uploaded and inserted!', 'success');
      } else {
        alert(data.error || 'Image upload failed.');
      }
    })
    .catch(err => {
      alert('Upload failed: ' + err.message);
    });
  }

  function bindEditorEvents() {
    const bindToEl = (el) => {
      if (!el) return;
      el.addEventListener('keyup', handleEditorKey);
      el.addEventListener('keydown', handleEditorKeyDown);
      el.addEventListener('mouseup', saveSelection);
      el.addEventListener('touchend', saveSelection);
      el.addEventListener('click', saveSelection);

      // Direct Drag & Drop image upload into Editor
      el.addEventListener('dragover', function(e) {
        e.preventDefault();
        el.classList.add('ring-2', 'ring-gold', 'bg-gold/5');
      });
      el.addEventListener('dragleave', function(e) {
        el.classList.remove('ring-2', 'ring-gold', 'bg-gold/5');
      });
      el.addEventListener('drop', function(e) {
        e.preventDefault();
        el.classList.remove('ring-2', 'ring-gold', 'bg-gold/5');
        if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
          saveSelection();
          for (let i = 0; i < e.dataTransfer.files.length; i++) {
            const f = e.dataTransfer.files[i];
            if (f.type.startsWith('image/')) {
              uploadAndInsertImageDirect(f);
            }
          }
        }
      });

      // Smart Paste & Continuous Sentence Flow Normalizer
      el.addEventListener('paste', function(e) {
        e.preventDefault();
        saveSelection();
        const html = e.clipboardData.getData('text/html');
        const text = e.clipboardData.getData('text/plain');

        if (html && (html.includes('<table') || html.includes('<ul') || html.includes('<ol') || html.includes('<h') || html.includes('<p') || html.includes('<div') || html.includes('<blockquote'))) {
          const cleaned = cleanAndFormatPastedHtml(html);
          insertHtmlAtSelection(cleaned);
        } else if (text) {
          const formatted = formatPlainTextToHtml(text);
          insertHtmlAtSelection(formatted);
        }
      });
      try { document.execCommand('defaultParagraphSeparator', false, 'p'); } catch(e) {}
    };

    bindToEl(editorEl);
    const fsEl = document.getElementById('editorVisualFullscreen');
    if (fsEl) bindToEl(fsEl);

    // Track active block / heading globally whenever cursor or selection changes
    document.addEventListener('selectionchange', () => {
      detectActiveHeading();
    });

    // Global Key Listener (e.g. Esc to exit fullscreen)
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') {
        const fsModal = document.getElementById('modalFullscreenEditor');
        if (fsModal && !fsModal.classList.contains('hidden')) {
          saveAndCloseFullscreen(true);
        }
      }
    });

    // Close slash palette on click outside
    document.addEventListener('click', function(e) {
      if (slashPalette && !slashPalette.contains(e.target) && e.target !== editorEl) {
        hideSlashPalette();
      }
    });
  }

  // ── Notion-Style Slash (/) Command Palette ────────────────────
  function createSlashPalette() {
    if (document.getElementById('slashPalette')) return;

    slashPalette = document.createElement('div');
    slashPalette.id = 'slashPalette';
    slashPalette.className = 'fixed hidden z-[9999] w-72 max-h-80 overflow-y-auto rounded-2xl bg-[#111118]/98 backdrop-blur-2xl border border-gold/40 shadow-2xl p-2 text-xs divide-y divide-[#1E1E2E]';
    document.body.appendChild(slashPalette);
  }

  function handleEditorKeyDown(e) {
    if (slashPalette && !slashPalette.classList.contains('hidden')) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        navigateSlash(1);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        navigateSlash(-1);
      } else if (e.key === 'Enter') {
        e.preventDefault();
        selectCurrentSlash();
      } else if (e.key === 'Escape') {
        hideSlashPalette();
      }
    }
  }

  function handleEditorKey(e) {
    saveSelection();
    syncVisualToTextarea();

    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return;

    const range = sel.getRangeAt(0);
    const node = range.startContainer;
    
    if (node && node.nodeType === Node.TEXT_NODE) {
      const textBeforeCursor = node.textContent.substring(0, range.startOffset);
      const lastSlashIdx = textBeforeCursor.lastIndexOf('/');
      
      if (lastSlashIdx !== -1 && (lastSlashIdx === 0 || /\s/.test(textBeforeCursor[lastSlashIdx - 1]))) {
        slashSearchTerm = textBeforeCursor.substring(lastSlashIdx + 1).toLowerCase();
        
        // Save slash range for text replacement
        slashRange = document.createRange();
        slashRange.setStart(node, lastSlashIdx);
        slashRange.setEnd(node, range.startOffset);

        showSlashPalette(range);
        return;
      }
    }

    if (slashPalette && !slashPalette.classList.contains('hidden')) {
      hideSlashPalette();
    }
  }

  function showSlashPalette(range) {
    const rect = range.getBoundingClientRect();
    const filtered = slashCommands.filter(c => 
      c.label.toLowerCase().includes(slashSearchTerm) || 
      c.desc.toLowerCase().includes(slashSearchTerm) ||
      c.id.toLowerCase().includes(slashSearchTerm)
    );

    if (filtered.length === 0) {
      hideSlashPalette();
      return;
    }

    slashActiveIndex = 0;
    renderSlashItems(filtered);

    slashPalette.style.top = `${Math.min(window.innerHeight - 340, rect.bottom + window.scrollY + 8)}px`;
    slashPalette.style.left = `${Math.min(window.innerWidth - 300, Math.max(16, rect.left + window.scrollX))}px`;
    slashPalette.classList.remove('hidden');
  }

  function renderSlashItems(items) {
    slashPalette.innerHTML = '';
    
    const header = document.createElement('div');
    header.className = 'px-3 py-1.5 text-[10px] font-black uppercase text-gold tracking-wider';
    header.textContent = '⚡ Insert Block Command';
    slashPalette.appendChild(header);

    const list = document.createElement('div');
    list.className = 'space-y-1 py-1';

    items.forEach((item, idx) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `w-full text-left p-2 rounded-xl flex items-center gap-3 transition-colors ${idx === slashActiveIndex ? 'bg-gold text-dark font-bold' : 'text-gray-300 hover:bg-[#1E1E2E] hover:text-white'}`;
      btn.innerHTML = `
        <span class="text-base w-6 text-center">${item.icon}</span>
        <div class="flex-1 min-w-0">
          <div class="font-black text-xs leading-tight">${item.label}</div>
          <div class="text-[10px] ${idx === slashActiveIndex ? 'text-dark/80' : 'text-gray-400'} truncate">${item.desc}</div>
        </div>
      `;
      btn.addEventListener('click', () => {
        executeSlashAction(item);
      });
      list.appendChild(btn);
    });

    slashPalette.appendChild(list);
  }

  function navigateSlash(direction) {
    const items = slashPalette.querySelectorAll('button');
    if (items.length === 0) return;
    slashActiveIndex = (slashActiveIndex + direction + items.length) % items.length;
    
    const filtered = slashCommands.filter(c => 
      c.label.toLowerCase().includes(slashSearchTerm) || 
      c.desc.toLowerCase().includes(slashSearchTerm) ||
      c.id.toLowerCase().includes(slashSearchTerm)
    );
    renderSlashItems(filtered);
  }

  function selectCurrentSlash() {
    const filtered = slashCommands.filter(c => 
      c.label.toLowerCase().includes(slashSearchTerm) || 
      c.desc.toLowerCase().includes(slashSearchTerm) ||
      c.id.toLowerCase().includes(slashSearchTerm)
    );
    if (filtered[slashActiveIndex]) {
      executeSlashAction(filtered[slashActiveIndex]);
    }
  }

  function executeSlashAction(item) {
    if (slashRange) {
      slashRange.deleteContents();
      slashRange = null;
    }
    hideSlashPalette();
    item.action();
  }

  function hideSlashPalette() {
    if (slashPalette) slashPalette.classList.add('hidden');
  }

  // ── Rich Modals (Link, Image, Video, Table, CTA, Preview) ─────
  function createModals() {
    if (document.getElementById('editorProModals')) return;

    const modalContainer = document.createElement('div');
    modalContainer.id = 'editorProModals';
    modalContainer.innerHTML = `
      <!-- 1. LINK MODAL -->
      <div id="modalLink" class="fixed inset-0 z-[10000] hidden bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" style="display: none;">
        <div class="bg-[#111118] border border-gold/40 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4">
          <div class="flex items-center justify-between border-b border-[#1E1E2E] pb-3">
            <h3 class="text-sm font-black text-white flex items-center gap-2"><span>🔗</span> <span>Insert / Edit Link</span></h3>
            <button type="button" onclick="EstateEditor.closeModal('modalLink')" class="text-gray-400 hover:text-white font-bold">&times;</button>
          </div>
          <div class="space-y-3 text-xs">
            <div>
              <label class="form-label text-xs">Destination URL <span class="text-red-400">*</span></label>
              <input type="url" id="linkUrlInput" class="form-input text-xs font-mono" placeholder="https://estatehdr.com/services/virtual-staging">
            </div>
            <div>
              <label class="form-label text-xs">Link Text</label>
              <input type="text" id="linkTextInput" class="form-input text-xs" placeholder="e.g. Explore Virtual Staging">
            </div>
            <div>
              <label class="form-label text-xs">Link Title Attribute (Hover text)</label>
              <input type="text" id="linkTitleInput" class="form-input text-xs" placeholder="e.g. Professional Real Estate Staging">
            </div>
            <div class="pt-2 space-y-2 border-t border-[#1E1E2E]">
              <label class="flex items-center gap-2 text-gray-300 cursor-pointer">
                <input type="checkbox" id="linkTargetBlank" class="w-4 h-4 text-gold rounded border-dark-border bg-dark">
                <span>Open link in a new tab (<code>target="_blank"</code>)</span>
              </label>
              <label class="flex items-center gap-2 text-gray-300 cursor-pointer">
                <input type="checkbox" id="linkRelNofollow" class="w-4 h-4 text-gold rounded border-dark-border bg-dark">
                <span>Add <code>rel="nofollow"</code> (Search Engine Directive)</span>
              </label>
              <label class="flex items-center gap-2 text-gray-300 cursor-pointer">
                <input type="checkbox" id="linkRelSponsored" class="w-4 h-4 text-gold rounded border-dark-border bg-dark">
                <span>Add <code>rel="sponsored"</code> (Paid / Partner Link)</span>
              </label>
            </div>
          </div>
          <div class="pt-3 border-t border-[#1E1E2E] flex justify-end gap-3">
            <button type="button" onclick="EstateEditor.closeModal('modalLink')" class="btn-ghost py-2 px-4 text-xs font-bold border-[#2A2A3A]">Cancel</button>
            <button type="button" onclick="EstateEditor.applyLink()" class="btn-gold py-2 px-6 text-xs font-black shadow-glow">Insert Link</button>
          </div>
        </div>
      </div>

      <!-- 2. IMAGE MODAL -->
      <div id="modalImage" class="fixed inset-0 z-[10000] hidden bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" style="display: none;">
        <div class="bg-[#111118] border border-gold/40 rounded-2xl w-full max-w-lg p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
          <div class="flex items-center justify-between border-b border-[#1E1E2E] pb-3">
            <h3 class="text-sm font-black text-white flex items-center gap-2"><span>🖼️</span> <span>Insert Image &amp; Media</span></h3>
            <button type="button" onclick="EstateEditor.closeModal('modalImage')" class="text-gray-400 hover:text-white font-bold">&times;</button>
          </div>
          
          <!-- Image Source Tabs -->
          <div class="flex rounded-xl bg-dark p-1 border border-[#1E1E2E] text-xs">
            <button type="button" onclick="EstateEditor.switchImageTab('upload')" id="imgTabBtnUpload" class="flex-1 py-1.5 font-bold rounded-lg bg-gold text-dark transition-all">📸 Upload</button>
            <button type="button" onclick="EstateEditor.switchImageTab('gallery')" id="imgTabBtnGallery" class="flex-1 py-1.5 font-bold rounded-lg text-gray-400 hover:text-white transition-all">🖼️ Studio Gallery</button>
            <button type="button" onclick="EstateEditor.switchImageTab('url')" id="imgTabBtnUrl" class="flex-1 py-1.5 font-bold rounded-lg text-gray-400 hover:text-white transition-all">🌐 Direct URL</button>
          </div>

          <!-- Upload Tab -->
          <div id="imgPanelUpload" class="space-y-3 text-xs">
            <div id="modalDropzone" class="border-2 border-dashed border-[#2A2A3A] hover:border-gold rounded-2xl p-6 text-center cursor-pointer transition-colors bg-dark/60">
              <div class="text-3xl mb-2">📁</div>
              <div class="font-bold text-white mb-1">Drag &amp; drop image here, or <span class="text-gold underline">browse files</span></div>
              <div class="text-[11px] text-gray-400">Supports JPG, PNG, WebP, GIF, SVG (Auto-optimized)</div>
              <input type="file" id="modalFileInput" accept="image/*" class="hidden">
            </div>
            <div>
              <label class="form-label text-xs">Custom File Name / Slug (Optional)</label>
              <input type="text" id="modalCustomName" class="form-input text-xs font-mono" placeholder="e.g. luxury-penthouse-twilight">
            </div>
            <div id="modalUploadProgress" class="hidden text-center py-2">
              <div class="inline-flex items-center gap-2 text-gold font-mono text-xs">
                <span class="animate-spin text-sm">⏳</span> Uploading to server...
              </div>
            </div>
          </div>

          <!-- Gallery Tab -->
          <div id="imgPanelGallery" class="hidden space-y-2 text-xs">
            <div class="text-gray-400 text-[11px]">Click any photo to select:</div>
            <div class="grid grid-cols-3 gap-2 max-h-48 overflow-y-auto pr-1" id="modalGalleryItems">
              <!-- Rendered via renderModalGalleryGrid -->
            </div>
          </div>

          <!-- URL Tab -->
          <div id="imgPanelUrl" class="hidden space-y-3 text-xs">
            <div>
              <label class="form-label text-xs">Image Path or URL</label>
              <input type="text" id="imgUrlInput" class="form-input text-xs font-mono" placeholder="/assets/images/blog/custom-image.jpg">
            </div>
          </div>

          <!-- Common Alt & Alignment -->
          <div class="space-y-3 text-xs pt-2 border-t border-[#1E1E2E]">
            <div>
              <label class="form-label text-xs">SEO Alt Text <span class="text-red-400">*</span></label>
              <input type="text" id="imgAltInput" class="form-input text-xs" placeholder="e.g. Luxury Real Estate Living Room Photo Enhancement">
            </div>
            <div>
              <label class="form-label text-xs">Image Alignment</label>
              <select id="imgAlignSelect" class="form-select text-xs">
                <option value="center">Centered (Full Width)</option>
                <option value="left">Float Left (Text wraps right)</option>
                <option value="right">Float Right (Text wraps left)</option>
              </select>
            </div>
            <div>
              <label class="form-label text-xs">Optional Caption</label>
              <input type="text" id="imgCaptionInput" class="form-input text-xs" placeholder="e.g. Before and After Twilight Retouching">
            </div>
          </div>

          <div class="pt-3 border-t border-[#1E1E2E] flex justify-end gap-3">
            <button type="button" onclick="EstateEditor.closeModal('modalImage')" class="btn-ghost py-2 px-4 text-xs font-bold border-[#2A2A3A]">Cancel</button>
            <button type="button" onclick="EstateEditor.applyImage()" class="btn-gold py-2 px-6 text-xs font-black shadow-glow">Insert Image</button>
          </div>
        </div>
      </div>

      <!-- 3. TABLE MODAL -->
      <div id="modalTable" class="fixed inset-0 z-[10000] hidden bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" style="display: none;">
        <div class="bg-[#111118] border border-gold/40 rounded-2xl w-full max-w-sm p-6 shadow-2xl space-y-4">
          <div class="flex items-center justify-between border-b border-[#1E1E2E] pb-3">
            <h3 class="text-sm font-black text-white flex items-center gap-2"><span>📊</span> <span>Insert Custom Table</span></h3>
            <button type="button" onclick="EstateEditor.closeModal('modalTable')" class="text-gray-400 hover:text-white font-bold">&times;</button>
          </div>
          <div class="grid grid-cols-2 gap-4 text-xs">
            <div>
              <label class="form-label text-xs">Rows</label>
              <input type="number" id="tableRowsInput" value="3" min="1" max="20" class="form-input text-xs font-mono">
            </div>
            <div>
              <label class="form-label text-xs">Columns</label>
              <input type="number" id="tableColsInput" value="3" min="1" max="10" class="form-input text-xs font-mono">
            </div>
          </div>
          <div class="text-xs pt-2 space-y-2 border-t border-[#1E1E2E]">
            <label class="flex items-center gap-2 text-gray-300 cursor-pointer">
              <input type="checkbox" id="tableHasHeader" checked class="w-4 h-4 text-gold rounded border-dark-border bg-dark">
              <span>Include Highlighted Header Row</span>
            </label>
            <label class="flex items-center gap-2 text-gray-300 cursor-pointer">
              <input type="checkbox" id="tableZebra" checked class="w-4 h-4 text-gold rounded border-dark-border bg-dark">
              <span>Apply Zebra Alternating Colors</span>
            </label>
          </div>
          <div class="pt-3 border-t border-[#1E1E2E] flex justify-end gap-3">
            <button type="button" onclick="EstateEditor.closeModal('modalTable')" class="btn-ghost py-2 px-4 text-xs font-bold border-[#2A2A3A]">Cancel</button>
            <button type="button" onclick="EstateEditor.applyTable()" class="btn-gold py-2 px-6 text-xs font-black shadow-glow">Create Table</button>
          </div>
        </div>
      </div>

      <!-- 4. CTA BUTTON MODAL -->
      <div id="modalCta" class="fixed inset-0 z-[10000] hidden bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" style="display: none;">
        <div class="bg-[#111118] border border-gold/40 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4">
          <div class="flex items-center justify-between border-b border-[#1E1E2E] pb-3">
            <h3 class="text-sm font-black text-white flex items-center gap-2"><span>🔘</span> <span>Insert CTA Button</span></h3>
            <button type="button" onclick="EstateEditor.closeModal('modalCta')" class="text-gray-400 hover:text-white font-bold">&times;</button>
          </div>
          <div class="space-y-3 text-xs">
            <div>
              <label class="form-label text-xs">Button Text <span class="text-red-400">*</span></label>
              <input type="text" id="ctaTextInput" class="form-input text-xs" placeholder="e.g. Start Your Free Trial Today">
            </div>
            <div>
              <label class="form-label text-xs">Destination URL <span class="text-red-400">*</span></label>
              <input type="text" id="ctaUrlInput" class="form-input text-xs font-mono" placeholder="/register.php or /#pricing">
            </div>
            <div>
              <label class="form-label text-xs">Button Style</label>
              <select id="ctaStyleSelect" class="form-select text-xs">
                <option value="btn-gold">Solid Gold Glow (Primary Action)</option>
                <option value="btn-outline">Gold Outline</option>
                <option value="btn-dark">Dark Charcoal</option>
              </select>
            </div>
          </div>
          <div class="pt-3 border-t border-[#1E1E2E] flex justify-end gap-3">
            <button type="button" onclick="EstateEditor.closeModal('modalCta')" class="btn-ghost py-2 px-4 text-xs font-bold border-[#2A2A3A]">Cancel</button>
            <button type="button" onclick="EstateEditor.applyCta()" class="btn-gold py-2 px-6 text-xs font-black shadow-glow">Insert Button</button>
          </div>
        </div>
      </div>

      <!-- 5. VIDEO MODAL -->
      <div id="modalVideo" class="fixed inset-0 z-[10000] hidden bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" style="display: none;">
        <div class="bg-[#111118] border border-gold/40 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4">
          <div class="flex items-center justify-between border-b border-[#1E1E2E] pb-3">
            <h3 class="text-sm font-black text-white flex items-center gap-2"><span>🎥</span> <span>Embed Video</span></h3>
            <button type="button" onclick="EstateEditor.closeModal('modalVideo')" class="text-gray-400 hover:text-white font-bold">&times;</button>
          </div>
          <div class="space-y-3 text-xs">
            <div>
              <label class="form-label text-xs">YouTube / Vimeo / MP4 URL <span class="text-red-400">*</span></label>
              <input type="url" id="videoUrlInput" class="form-input text-xs font-mono" placeholder="https://www.youtube.com/watch?v=...">
            </div>
          </div>
          <div class="pt-3 border-t border-[#1E1E2E] flex justify-end gap-3">
            <button type="button" onclick="EstateEditor.closeModal('modalVideo')" class="btn-ghost py-2 px-4 text-xs font-bold border-[#2A2A3A]">Cancel</button>
            <button type="button" onclick="EstateEditor.applyVideo()" class="btn-gold py-2 px-6 text-xs font-black shadow-glow">Embed Video</button>
          </div>
        </div>
      </div>

      <!-- 8. RAW HTML & SCHEMA MARKUP MODAL -->
      <div id="modalRawHtml" class="fixed inset-0 z-[10000] hidden bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" style="display: none;">
        <div class="bg-[#111118] border border-gold/40 rounded-3xl w-full max-w-2xl p-6 shadow-2xl space-y-4">
          <div class="flex items-center justify-between border-b border-[#1E1E2E] pb-3">
            <h3 class="text-sm font-black text-white flex items-center gap-2">
              <span class="text-gold font-mono font-bold">&lt;/&gt;</span> 
              <span>Insert Custom HTML / Schema Markup</span>
            </h3>
            <button type="button" onclick="EstateEditor.closeModal('modalRawHtml')" class="text-gray-400 hover:text-white font-bold">&times;</button>
          </div>
          
          <!-- Mode Tabs -->
          <div class="flex rounded-xl bg-dark p-1 border border-[#1E1E2E] text-xs">
            <button type="button" onclick="EstateEditor.switchRawHtmlTab('html')" id="rawTabBtnHtml" class="flex-1 py-1.5 font-bold rounded-lg bg-gold text-dark">📄 Custom HTML / Embed</button>
            <button type="button" onclick="EstateEditor.switchRawHtmlTab('schema')" id="rawTabBtnSchema" class="flex-1 py-1.5 font-bold rounded-lg text-gray-400 hover:text-white">✨ JSON-LD Schema Generator</button>
          </div>

          <!-- HTML Embed Panel -->
          <div id="rawPanelHtml" class="space-y-3 text-xs">
            <div>
              <label class="form-label text-xs">Paste HTML / Embed Code (iframe, widgets, custom tables, banners)</label>
              <textarea id="rawHtmlInput" rows="7" class="form-input text-xs font-mono text-emerald-400 bg-[#07070B] resize-y" placeholder="<div class=&quot;my-custom-box&quot;>...</div> or <iframe src=&quot;...&quot;></iframe>"></textarea>
            </div>
            <p class="text-[11px] text-gray-400">💡 Custom HTML will be rendered directly in the visual editor and live article.</p>
          </div>

          <!-- Schema JSON-LD Panel -->
          <div id="rawPanelSchema" class="hidden space-y-3 text-xs">
            <div>
              <label class="form-label text-xs">1-Click Schema Templates</label>
              <div class="flex flex-wrap gap-2">
                <button type="button" onclick="EstateEditor.loadSchemaTemplate('faq')" class="btn-ghost py-1 px-2.5 text-[11px] font-bold border-gold/40 text-gold hover:bg-gold/10">➕ FAQ Schema</button>
                <button type="button" onclick="EstateEditor.loadSchemaTemplate('article')" class="btn-ghost py-1 px-2.5 text-[11px] font-bold border-blue-500/40 text-blue-400 hover:bg-blue-500/10">➕ BlogPosting Schema</button>
                <button type="button" onclick="EstateEditor.loadSchemaTemplate('business')" class="btn-ghost py-1 px-2.5 text-[11px] font-bold border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/10">➕ Real Estate Agency</button>
                <button type="button" onclick="EstateEditor.loadSchemaTemplate('howto')" class="btn-ghost py-1 px-2.5 text-[11px] font-bold border-purple-500/40 text-purple-400 hover:bg-purple-500/10">➕ How-To Guide</button>
              </div>
            </div>
            <div>
              <label class="form-label text-xs">JSON-LD Structured Data Schema</label>
              <textarea id="rawSchemaInput" rows="7" class="form-input text-xs font-mono text-amber-300 bg-[#07070B] resize-y" placeholder='<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": []
}
</script>'></textarea>
            </div>
            <p class="text-[11px] text-gray-400">💡 Schema markup will be safely rendered as a manageable schema badge in the editor and injected into Google rich snippets.</p>
          </div>

          <div class="pt-3 border-t border-[#1E1E2E] flex justify-end gap-3">
            <button type="button" onclick="EstateEditor.closeModal('modalRawHtml')" class="btn-ghost py-2 px-4 text-xs font-bold border-[#2A2A3A]">Cancel</button>
            <button type="button" onclick="EstateEditor.applyRawHtml()" class="btn-gold py-2 px-6 text-xs font-black shadow-glow">Insert Code / Schema</button>
          </div>
        </div>
      </div>

      <!-- 6. LIVE RESPONSIVE PREVIEW MODAL -->
      <div id="modalLivePreview" class="fixed inset-0 z-[10001] hidden bg-black/90 backdrop-blur-md flex flex-col items-center justify-center p-4 sm:p-6" style="display: none;">
        <div class="bg-[#0A0A0F] border border-[#1E1E2E] rounded-3xl w-full max-w-6xl h-[92vh] flex flex-col shadow-2xl overflow-hidden">
          
          <!-- Top Bar -->
          <div class="p-4 border-b border-[#1E1E2E] bg-[#111118] flex flex-wrap items-center justify-between gap-4">
            <div class="flex items-center gap-3">
              <span class="text-lg">👁️</span>
              <div>
                <h3 class="text-sm font-black text-white" id="previewModalTitle">Live Preview</h3>
                <div class="text-[11px] text-gray-400">SSR rendering simulation with real Estate HDR styling</div>
              </div>
            </div>

            <!-- Viewport Switcher -->
            <div class="inline-flex rounded-xl bg-dark p-1 border border-[#1E1E2E] text-xs">
              <button type="button" onclick="EstateEditor.setPreviewDevice('desktop')" id="prevBtnDesk" class="py-1 px-3 rounded-lg font-bold bg-gold text-dark">🖥️ Desktop</button>
              <button type="button" onclick="EstateEditor.setPreviewDevice('tablet')" id="prevBtnTab" class="py-1 px-3 rounded-lg font-bold text-gray-400 hover:text-white">📟 Tablet</button>
              <button type="button" onclick="EstateEditor.setPreviewDevice('mobile')" id="prevBtnMob" class="py-1 px-3 rounded-lg font-bold text-gray-400 hover:text-white">📱 Mobile</button>
            </div>

            <!-- Actions -->
            <div class="flex items-center gap-2">
              <a id="previewExternalLink" href="#" target="_blank" class="btn-ghost py-1.5 px-3 text-xs font-mono text-gold border border-gold/40 hover:bg-gold/10 inline-flex items-center gap-1">
                <span>↗ Open in New Tab</span>
              </a>
              <button type="button" onclick="EstateEditor.closeModal('modalLivePreview')" class="btn-ghost py-1.5 px-3 text-xs font-bold border-[#2A2A3A] hover:text-white">&times; Close</button>
            </div>
          </div>

          <!-- Preview Frame Body -->
          <div class="flex-1 bg-[#050508] p-4 sm:p-6 overflow-y-auto flex justify-center items-start">
            <div id="previewFrameContainer" class="w-full max-w-4xl bg-[#0A0A0F] border border-[#1E1E2E] rounded-2xl p-6 sm:p-10 shadow-2xl text-white transition-all duration-300 space-y-6">
              <div id="previewHeaderBadge" class="section-tag inline-block">Preview Mode</div>
              <h1 id="previewHeading" class="text-2xl sm:text-4xl font-black text-white leading-tight">Page Title</h1>
              <div id="previewMetaLine" class="flex flex-wrap items-center gap-4 text-xs text-gray-400 font-mono border-b border-[#1E1E2E] pb-4">
                <span id="previewAuthor">By Estate HDR Team</span>
                <span id="previewDate">• Just now</span>
                <span id="previewCategoryBadge" class="px-2.5 py-0.5 rounded-full bg-gold/10 text-gold border border-gold/20 font-bold">Category</span>
              </div>
              <div id="previewCoverImgContainer" class="hidden rounded-2xl overflow-hidden border border-[#1E1E2E] max-h-96">
                <img id="previewCoverImg" src="" alt="Cover" class="w-full h-auto object-contain">
              </div>
              <div id="previewHtmlBody" class="prose prose-invert max-w-none text-gray-200 leading-relaxed space-y-4 text-sm sm:text-base">
                <!-- Injected Content -->
              </div>
            </div>
          </div>

        </div>
      </div>

      <!-- 7. FULLSCREEN EXPANDED ZEN EDITOR MODAL -->
      <div id="modalFullscreenEditor" class="fixed inset-0 z-[10002] hidden bg-black/95 backdrop-blur-md flex flex-col items-center justify-center p-2 sm:p-4" style="display: none;">
        <div class="bg-[#0A0A0F] border border-gold/40 rounded-3xl w-full h-full max-w-[98vw] max-h-[96vh] flex flex-col shadow-2xl overflow-hidden">
          
          <!-- Top Fullscreen Header -->
          <div class="p-3.5 px-6 border-b border-[#1E1E2E] bg-[#111118] flex flex-wrap items-center justify-between gap-4 flex-shrink-0">
            <div class="flex items-center gap-3">
              <div class="w-9 h-9 rounded-xl bg-gold/10 border border-gold/30 flex items-center justify-center text-base text-gold font-bold">⛶</div>
              <div>
                <h3 class="text-sm font-black text-white flex items-center gap-2">
                  <span>Fullscreen Content Studio</span>
                  <span class="text-[10px] text-gold font-mono px-2 py-0.5 rounded bg-gold/10 border border-gold/20 font-bold uppercase">Zen Mode</span>
                </h3>
                <div class="text-[11px] text-gray-400 truncate max-w-sm sm:max-w-md" id="fullscreenDocTitle">Writing article content</div>
              </div>
            </div>

            <!-- Middle Quick Stats & Mode -->
            <div class="flex items-center gap-3 text-xs font-mono">
              <span id="fullscreenWordCountBadge" class="px-3 py-1 rounded-xl bg-dark border border-[#1E1E2E] text-gray-300">Words: 0 | ~1 min read</span>
              <button type="button" onclick="EstateEditor.toggleFullscreenHtmlView()" id="fullscreenHtmlToggleBtn" class="btn-ghost py-1 px-3 text-xs font-mono text-gold border border-gold/40 hover:bg-gold/10 inline-flex items-center gap-1">
                <span>&lt;/&gt;</span> <span id="fullscreenHtmlToggleText">HTML View</span>
              </button>
            </div>

            <!-- Top Actions: Save & Back / Close -->
            <div class="flex items-center gap-3">
              <button type="button" onclick="EstateEditor.openLivePreview(window.EstateEditorMode || 'post')" class="btn-ghost py-1.5 px-3.5 text-xs font-bold text-gold border-gold/40 hover:bg-gold/10 inline-flex items-center gap-1.5">
                <span>👁️</span> <span>Preview</span>
              </button>
              <button type="button" onclick="EstateEditor.saveAndCloseFullscreen(true)" class="btn-gold py-1.5 px-5 text-xs font-black shadow-glow inline-flex items-center gap-1.5">
                <span>💾</span> <span>Save &amp; Back</span>
              </button>
              <button type="button" onclick="EstateEditor.saveAndCloseFullscreen(false)" class="btn-ghost py-1.5 px-3 text-xs font-bold border-[#2A2A3A] hover:text-white" title="Close (Esc)">
                <span>✕ Exit</span>
              </button>
            </div>
          </div>

          <!-- Full Rich Formatting Toolbar inside Fullscreen -->
          <div id="fullscreenToolbar" class="flex flex-wrap items-center gap-1.5 p-2.5 px-6 bg-[#07070B] border-b border-[#1E1E2E] text-xs flex-shrink-0">
            <div class="flex items-center gap-1 bg-[#161622] p-1 rounded-lg border border-[#2A2A3A]">
              <select id="fullscreenHeadingSelect" onchange="EstateEditor.applyHeading(this.value)" class="form-select text-xs py-1 px-2.5 font-bold bg-[#0D0D14] text-gold border-[#3A3A4E] rounded-md">
                <option value="p">Paragraph (Normal Text)</option>
                <option value="h1">Heading 1 (H1 - Main Title)</option>
                <option value="h2">Heading 2 (H2 - Main Section)</option>
                <option value="h3">Heading 3 (H3 - Sub-Section)</option>
                <option value="h4">Heading 4 (H4 - Minor Topic)</option>
                <option value="h5">Heading 5 (H5)</option>
                <option value="h6">Heading 6 (H6)</option>
              </select>
              <span id="fullscreenActiveBlockBadge" class="px-2 py-0.5 rounded bg-gold/20 text-gold border border-gold/40 font-mono font-black text-[11px]">P</span>
              <span class="w-[1px] h-4 bg-[#2A2A3A] mx-0.5"></span>
              <button type="button" onclick="EstateEditor.applyHeading('h1')" class="px-2 py-1 rounded bg-[#0D0D14] hover:bg-gold hover:text-dark font-black text-xs text-white border border-[#2A2A3A]" title="Quick Apply Heading 1">H1</button>
              <button type="button" onclick="EstateEditor.applyHeading('h2')" class="px-2 py-1 rounded bg-[#0D0D14] hover:bg-gold hover:text-dark font-black text-xs text-gold border border-gold/40" title="Quick Apply Heading 2">H2</button>
              <button type="button" onclick="EstateEditor.applyHeading('h3')" class="px-2 py-1 rounded bg-[#0D0D14] hover:bg-gold hover:text-dark font-black text-xs text-amber-300 border border-amber-500/30" title="Quick Apply Heading 3">H3</button>
              <button type="button" onclick="EstateEditor.applyHeading('p')" class="px-2 py-1 rounded bg-[#0D0D14] hover:bg-gold hover:text-dark font-bold text-xs text-gray-300 border border-[#2A2A3A]" title="Quick Apply Normal Paragraph">P</button>
            </div>

            <span class="w-[1px] h-5 bg-[#2A2A3A] mx-1"></span>

            <button type="button" onclick="EstateEditor.execCmd('bold')" class="p-1.5 px-2.5 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg font-bold" title="Bold (Ctrl+B)"><strong>B</strong></button>
            <button type="button" onclick="EstateEditor.execCmd('italic')" class="p-1.5 px-2.5 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg italic" title="Italic (Ctrl+I)"><em>I</em></button>
            <button type="button" onclick="EstateEditor.execCmd('underline')" class="p-1.5 px-2.5 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg underline" title="Underline (Ctrl+U)"><u>U</u></button>
            <button type="button" onclick="EstateEditor.execCmd('strikeThrough')" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg line-through" title="Strikethrough"><s>S</s></button>
            <button type="button" onclick="EstateEditor.execCmd('removeFormat')" class="p-1.5 px-2 bg-[#161622] hover:bg-red-500 hover:text-white rounded-lg" title="Clear Formatting">🧹</button>

            <span class="w-[1px] h-5 bg-[#2A2A3A] mx-1"></span>

            <button type="button" onclick="EstateEditor.execCmd('justifyLeft')" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Align Left">⬅️</button>
            <button type="button" onclick="EstateEditor.execCmd('justifyCenter')" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Align Center">↔️</button>
            <button type="button" onclick="EstateEditor.execCmd('justifyRight')" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Align Right">➡️</button>

            <span class="w-[1px] h-5 bg-[#2A2A3A] mx-1"></span>

            <button type="button" onclick="EstateEditor.execCmd('insertUnorderedList')" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Bullet List">• List</button>
            <button type="button" onclick="EstateEditor.execCmd('insertOrderedList')" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Numbered List">1. List</button>

            <span class="w-[1px] h-5 bg-[#2A2A3A] mx-1"></span>

            <button type="button" onclick="EstateEditor.openLinkModal()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg text-blue-400 font-bold" title="Insert Link">🔗 Link</button>
            <button type="button" onclick="EstateEditor.openImageModal()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Insert Image with Alt Text">🖼️ Image</button>
            <button type="button" onclick="EstateEditor.openVideoModal()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Embed YouTube/Video">🎥 Video</button>
            <button type="button" onclick="EstateEditor.openRawHtmlModal()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg text-emerald-400 font-mono font-bold" title="Insert Raw HTML / Schema Markup">&lt;/&gt; Code/Schema</button>
            <button type="button" onclick="EstateEditor.openTableModal()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg font-bold" title="Insert Table">📊 Table</button>
            <button type="button" onclick="EstateEditor.insertBlockquote()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Insert Blockquote">❝ Quote</button>
            <button type="button" onclick="EstateEditor.insertCalloutBox()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg text-amber-400 font-bold" title="Callout Tip Box">💡 Callout</button>
            <button type="button" onclick="EstateEditor.insertHorizontalRule()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Horizontal Divider">➖ Divider</button>
            <button type="button" onclick="EstateEditor.openCtaModal()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg text-gold font-bold" title="Insert Gold CTA Button">🔘 Button</button>
            <span class="w-[1px] h-5 bg-[#2A2A3A] mx-1"></span>
            <button type="button" onclick="EstateEditor.insertComparisonGrid()" class="p-1.5 px-2.5 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg text-emerald-400 font-bold border border-emerald-500/30" title="Insert 2-Column Comparison Grid">📊 Comparison</button>
            <button type="button" onclick="EstateEditor.insertCtaBox()" class="p-1.5 px-2.5 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg text-gold font-bold border border-gold/40" title="Insert 24h CTA Banner Box">📢 CTA Banner</button>
          </div>

          <!-- Distraction-Free Large Editor Surface -->
          <div class="flex-1 bg-[#050508] p-4 sm:p-8 overflow-y-auto flex justify-center items-start">
            <div class="w-full max-w-4xl min-h-full flex flex-col">
              <div id="editorVisualFullscreen" contenteditable="true" 
                   class="w-full flex-1 bg-[#0A0A0F] border border-[#1E1E2E] rounded-2xl p-6 sm:p-10 text-white text-base leading-relaxed focus:outline-none focus:border-gold shadow-2xl space-y-4" 
                   oninput="EstateEditor.syncFullscreenToMain()">
              </div>
              <textarea id="editorCodeFullscreen" class="hidden w-full flex-1 bg-[#0A0A0F] border border-[#1E1E2E] rounded-2xl p-6 sm:p-10 text-xs font-mono text-amber-300 leading-relaxed focus:outline-none focus:border-gold resize-none min-h-[480px]" 
                        oninput="EstateEditor.syncFullscreenCodeToVisual()"></textarea>
            </div>
          </div>

          <!-- Bottom Footer Bar -->
          <div class="p-2.5 px-6 border-t border-[#1E1E2E] bg-[#0C0C12] flex items-center justify-between text-xs text-gray-400 flex-shrink-0">
            <div class="flex items-center gap-3">
              <span class="text-gold font-bold">💡 Pro Tip:</span>
              <span>Type <kbd class="bg-dark px-1.5 py-0.5 rounded text-gold font-mono">/</kbd> anywhere on a new line to insert tables, images, callouts, or quotes.</span>
            </div>
            <div class="text-[11px] font-mono text-gray-500">
              Auto-synced with main editor • Press <kbd class="bg-dark px-1.5 py-0.5 rounded text-gray-300">Esc</kbd> to return
            </div>
          </div>

        </div>
      </div>
    `;

    document.body.appendChild(modalContainer);

    // Setup dropzone in modal
    const dz = document.getElementById('modalDropzone');
    const fileInput = document.getElementById('modalFileInput');
    if (dz && fileInput) {
      dz.addEventListener('click', () => fileInput.click());
      dz.addEventListener('dragover', (e) => { e.preventDefault(); dz.classList.add('border-gold', 'bg-gold/5'); });
      dz.addEventListener('dragleave', () => { dz.classList.remove('border-gold', 'bg-gold/5'); });
      dz.addEventListener('drop', (e) => {
        e.preventDefault();
        dz.classList.remove('border-gold', 'bg-gold/5');
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
          uploadModalImageFile(e.dataTransfer.files[0]);
        }
      });
      fileInput.addEventListener('change', () => {
        if (fileInput.files && fileInput.files[0]) {
          uploadModalImageFile(fileInput.files[0]);
        }
      });
    }

    // Bind events on fullscreen surface
    const fsVisual = document.getElementById('editorVisualFullscreen');
    if (fsVisual) {
      fsVisual.addEventListener('keyup', handleEditorKey);
      fsVisual.addEventListener('keydown', handleEditorKeyDown);
      fsVisual.addEventListener('mouseup', saveSelection);
      fsVisual.addEventListener('touchend', saveSelection);
      fsVisual.addEventListener('paste', function(e) {
        const html = e.clipboardData.getData('text/html');
        if (html && (html.includes('<table') || html.includes('<ul') || html.includes('<ol') || html.includes('<h') || html.includes('<p'))) {
          e.preventDefault();
          saveSelection();
          const cleaned = cleanAndFormatPastedHtml(html);
          insertHtmlAtSelection(cleaned);
        }
      });
    }
  }

  function closeModal(id) {
    const el = document.getElementById(id);
    if (el) {
      el.style.display = 'none';
      el.classList.add('hidden');
    }
  }

  function openModal(id) {
    const el = document.getElementById(id);
    if (el) {
      el.style.display = 'flex';
      el.classList.remove('hidden');
    }
  }

  // ── Modals Trigger Handlers ──────────────────────────────────
  function openLinkModal() {
    saveSelection();
    const selText = window.getSelection() ? window.getSelection().toString() : '';
    document.getElementById('linkTextInput').value = selText;
    document.getElementById('linkUrlInput').value = 'https://';
    document.getElementById('linkTitleInput').value = '';
    document.getElementById('linkTargetBlank').checked = true;
    document.getElementById('linkRelNofollow').checked = false;
    document.getElementById('linkRelSponsored').checked = false;
    openModal('modalLink');
    setTimeout(() => document.getElementById('linkUrlInput').focus(), 100);
  }

  function applyLink() {
    const url = document.getElementById('linkUrlInput').value.trim();
    const text = document.getElementById('linkTextInput').value.trim();
    const title = document.getElementById('linkTitleInput').value.trim();
    const isBlank = document.getElementById('linkTargetBlank').checked;
    const isNofollow = document.getElementById('linkRelNofollow').checked;
    const isSponsored = document.getElementById('linkRelSponsored').checked;

    if (!url || url === 'https://') {
      if (window.EstateDialog) EstateDialog.toast('Please enter a valid destination URL.', 'error');
      else alert('Please enter a valid destination URL.');
      return;
    }

    let rels = [];
    if (isBlank) rels.push('noopener');
    if (isNofollow) rels.push('nofollow');
    if (isSponsored) rels.push('sponsored');

    let relAttr = rels.length > 0 ? ` rel="${rels.join(' ')}"` : '';
    let targetAttr = isBlank ? ' target="_blank"' : '';
    let titleAttr = title ? ` title="${title}"` : '';

    const linkHtml = `<a href="${url}"${targetAttr}${relAttr}${titleAttr} class="text-gold hover:underline font-bold">${text || url}</a>`;
    
    closeModal('modalLink');
    insertHtmlAtSelection(linkHtml);
  }

  function openImageModal() {
    saveSelection();
    document.getElementById('imgUrlInput').value = '';
    document.getElementById('imgAltInput').value = '';
    document.getElementById('modalCustomName').value = '';
    switchImageTab('upload');
    openModal('modalImage');
  }

  function switchImageTab(tab) {
    const isUp = (tab === 'upload');
    const isGal = (tab === 'gallery');
    const isUrl = (tab === 'url');

    const btnUp = document.getElementById('imgTabBtnUpload');
    const btnGal = document.getElementById('imgTabBtnGallery');
    const btnUrl = document.getElementById('imgTabBtnUrl');

    if (btnUp) btnUp.className = `flex-1 py-1.5 font-bold rounded-lg ${isUp ? 'bg-gold text-dark' : 'text-gray-400 hover:text-white'}`;
    if (btnGal) btnGal.className = `flex-1 py-1.5 font-bold rounded-lg ${isGal ? 'bg-gold text-dark' : 'text-gray-400 hover:text-white'}`;
    if (btnUrl) btnUrl.className = `flex-1 py-1.5 font-bold rounded-lg ${isUrl ? 'bg-gold text-dark' : 'text-gray-400 hover:text-white'}`;

    const pUp = document.getElementById('imgPanelUpload');
    const pGal = document.getElementById('imgPanelGallery');
    const pUrl = document.getElementById('imgPanelUrl');

    if (pUp) pUp.classList.toggle('hidden', !isUp);
    if (pGal) pGal.classList.toggle('hidden', !isGal);
    if (pUrl) pUrl.classList.toggle('hidden', !isUrl);

    if (isGal) renderModalGalleryGrid();
  }

  function renderModalGalleryGrid() {
    const container = document.getElementById('modalGalleryItems');
    if (!container) return;
    const galleryItems = [
      { url: '/assets/images/portfolio/virtual-staging/1-after.jpg', title: 'Modern Staged Living Room' },
      { url: '/assets/images/portfolio/virtual-staging/2-after.jpg', title: 'Luxury Staged Master Suite' },
      { url: '/assets/images/portfolio/virtual-staging/3-after.jpg', title: 'Open Concept Staged Dining' },
      { url: '/assets/images/portfolio/virtual-staging/4-after.jpg', title: 'Minimalist Apartment Staging' },
      { url: '/assets/images/portfolio/hdr/1-after.jpg', title: 'HDR Great Room' },
      { url: '/assets/images/portfolio/hdr/10-after.jpg', title: 'Gourmet Kitchen HDR' },
      { url: '/assets/images/portfolio/day-to-dusk/1-after.jpg', title: 'Sunset Luxury Villa' },
      { url: '/assets/images/portfolio/day-to-dusk/2-after.jpg', title: 'Twilight Exterior' },
      { url: '/assets/images/blog/ai-commercial-real-estate-listings-optimization.jpg', title: 'Commercial Architecture' }
    ];

    container.innerHTML = '';
    galleryItems.forEach(item => {
      const div = document.createElement('div');
      div.className = 'group relative rounded-lg overflow-hidden border border-[#2A2A3A] hover:border-gold cursor-pointer bg-dark aspect-[16/9] shadow-sm';
      div.onclick = () => {
        document.getElementById('imgUrlInput').value = item.url;
        if (!document.getElementById('imgAltInput').value) {
          document.getElementById('imgAltInput').value = item.title;
        }
        switchImageTab('url');
        if (window.EstateDialog) EstateDialog.toast('Selected: ' + item.title, 'success');
      };
      div.innerHTML = `
        <img src="${item.url}" alt="${item.title}" class="w-full h-full object-cover group-hover:scale-105 transition-transform" loading="lazy">
        <div class="absolute inset-0 bg-gold/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <span class="bg-gold text-dark text-[10px] font-black px-2 py-0.5 rounded shadow">Select</span>
        </div>
      `;
      container.appendChild(div);
    });
  }

  function uploadModalImageFile(file) {
    const customName = document.getElementById('modalCustomName') ? document.getElementById('modalCustomName').value.trim() : '';
    const prog = document.getElementById('modalUploadProgress');
    if (prog) prog.classList.remove('hidden');

    const formData = new FormData();
    formData.append('image', file);
    if (customName) formData.append('custom_name', customName);
    const csrf = getCsrfToken();
    if (csrf) formData.append('csrf_token', csrf);

    fetch('/api/upload-image.php', {
      method: 'POST',
      headers: csrf ? { 'X-CSRF-TOKEN': csrf } : {},
      body: formData
    })
    .then(r => r.json())
    .then(data => {
      if (prog) prog.classList.add('hidden');
      if (data.success) {
        document.getElementById('imgUrlInput').value = data.url;
        if (!document.getElementById('imgAltInput').value) {
          document.getElementById('imgAltInput').value = data.alt || '';
        }
        if (window.EstateDialog) EstateDialog.toast('Image uploaded successfully!', 'success');
        switchImageTab('url');
      } else {
        if (window.EstateDialog) EstateDialog.toast(data.error || 'Upload failed.', 'error');
        else alert(data.error || 'Upload failed.');
      }
    })
    .catch(err => {
      if (prog) prog.classList.add('hidden');
      if (window.EstateDialog) EstateDialog.toast('Upload failed: ' + err.message, 'error');
      else alert('Upload failed: ' + err.message);
    });
  }

  function triggerImageUploadDirect() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = () => {
      if (input.files && input.files[0]) {
        const formData = new FormData();
        formData.append('image', input.files[0]);
        const csrf = getCsrfToken();
        if (csrf) formData.append('csrf_token', csrf);
        fetch('/api/upload-image.php', { 
          method: 'POST', 
          headers: csrf ? { 'X-CSRF-TOKEN': csrf } : {},
          body: formData 
        })
          .then(r => r.json())
          .then(data => {
            if (data.success) {
              const imgHtml = `<p><img src="${data.url}" alt="${data.alt || 'Estate HDR Photo'}" class="my-4 rounded-xl border border-[#1E1E2E] shadow-xl max-w-full h-auto"></p><p></p>`;
              insertHtmlAtSelection(imgHtml);
              syncVisualToTextarea();
              if (window.EstateDialog) EstateDialog.toast('Image inserted successfully!', 'success');
            } else {
              if (window.EstateDialog) EstateDialog.toast(data.error || 'Upload failed.', 'error');
              else alert(data.error || 'Upload failed.');
            }
          })
          .catch(e => {
            if (window.EstateDialog) EstateDialog.toast('Upload error: ' + e.message, 'error');
            else alert('Upload error: ' + e.message);
          });
      }
    };
    input.click();
  }

  function applyImage() {
    const url = document.getElementById('imgUrlInput').value.trim();
    const alt = document.getElementById('imgAltInput').value.trim() || 'Estate HDR Photo';
    const align = document.getElementById('imgAlignSelect').value;
    const caption = document.getElementById('imgCaptionInput').value.trim();

    if (!url) {
      if (window.EstateDialog) EstateDialog.toast('Please upload an image or provide an image URL.', 'error');
      else alert('Please upload an image or provide an image URL.');
      return;
    }

    let alignClass = 'my-5 rounded-2xl border border-[#1E1E2E] shadow-xl max-w-full h-auto';
    if (align === 'left') alignClass = 'float-left mr-6 mb-4 rounded-xl border border-[#1E1E2E] shadow-lg max-w-md';
    if (align === 'right') alignClass = 'float-right ml-6 mb-4 rounded-xl border border-[#1E1E2E] shadow-lg max-w-md';

    let html = `<p><img src="${url}" alt="${alt}" class="${alignClass}"></p>`;
    if (caption) {
      html += `<p class="text-center text-xs text-gray-400 italic mb-4">${caption}</p>`;
    }
    html += `<p></p>`;

    closeModal('modalImage');
    insertHtmlAtSelection(html);
  }

  function openTableModal() {
    saveSelection();
    openModal('modalTable');
  }

  function applyTable() {
    const rows = parseInt(document.getElementById('tableRowsInput').value) || 3;
    const cols = parseInt(document.getElementById('tableColsInput').value) || 3;
    const hasHeader = document.getElementById('tableHasHeader').checked;
    const isZebra = document.getElementById('tableZebra').checked;

    let html = '<table class="w-full my-5 border-collapse border border-[#2D2D3F] rounded-xl overflow-hidden shadow-xl bg-[#0E0E16] text-[#F1F5F9]">';
    
    if (hasHeader) {
      html += '<thead><tr>';
      for (let c = 1; c <= cols; c++) {
        html += `<th class="bg-[#161622] text-[#C9A84C] p-3.5 border border-[#2D2D3F] font-black text-xs uppercase tracking-wider text-left">Header ${c}</th>`;
      }
      html += '</tr></thead>';
    }

    html += '<tbody>';
    for (let r = 1; r <= rows; r++) {
      const rowBg = (isZebra && r % 2 === 0) ? 'bg-[#14141F]' : 'bg-[#0E0E16]';
      html += `<tr class="${rowBg}">`;
      for (let c = 1; c <= cols; c++) {
        html += `<td class="p-3.5 border border-[#2D2D3F] text-[#F1F5F9] text-xs bg-[#0E0E16] font-normal leading-relaxed">Cell ${r},${c}</td>`;
      }
      html += '</tr>';
    }
    html += '</tbody></table><p></p>';

    closeModal('modalTable');
    insertHtmlAtSelection(html);
  }

  function openCtaModal() {
    saveSelection();
    openModal('modalCta');
  }

  function applyCta() {
    const text = document.getElementById('ctaTextInput').value.trim();
    const url = document.getElementById('ctaUrlInput').value.trim();
    const style = document.getElementById('ctaStyleSelect').value;

    if (!text || !url) {
      if (window.EstateDialog) EstateDialog.toast('Please provide button text and link.', 'error');
      else alert('Please provide button text and link.');
      return;
    }

    let classNames = 'btn-gold inline-flex items-center gap-2 py-3 px-8 rounded-xl font-black text-xs shadow-glow no-underline my-4';
    if (style === 'btn-outline') {
      classNames = 'btn-ghost inline-flex items-center gap-2 py-3 px-8 rounded-xl font-bold text-xs text-gold border border-gold/60 hover:bg-gold hover:text-dark no-underline my-4';
    } else if (style === 'btn-dark') {
      classNames = 'btn-ghost inline-flex items-center gap-2 py-3 px-8 rounded-xl font-bold text-xs text-white border border-[#2A2A3A] hover:border-gold no-underline my-4';
    }

    const btnHtml = `<p class="my-4"><a href="${url}" class="${classNames}">${text} &rarr;</a></p><p></p>`;
    closeModal('modalCta');
    insertHtmlAtSelection(btnHtml);
  }

  function openVideoModal() {
    saveSelection();
    const input = document.getElementById('videoUrlInput');
    if (input) input.value = '';
    openModal('modalVideo');
    setTimeout(() => { if (input) input.focus(); }, 100);
  }

  function applyVideo() {
    const raw = (document.getElementById('videoUrlInput') ? document.getElementById('videoUrlInput').value : '').trim();
    if (!raw) {
      if (window.EstateDialog) EstateDialog.toast('Please enter a YouTube, Vimeo, or video URL.', 'error');
      else alert('Please enter a YouTube, Vimeo, or video URL.');
      return;
    }

    let videoHtml = '';

    // Check if raw iframe embed was pasted
    if (raw.toLowerCase().includes('<iframe') && raw.includes('</iframe>')) {
      videoHtml = `<div class="aspect-video w-full my-6 rounded-2xl overflow-hidden border border-[#1E1E2E] shadow-2xl bg-black">${raw}</div><p></p>`;
    } else if (raw.match(/\.(mp4|webm|ogg)($|\?)/i)) {
      videoHtml = `<div class="aspect-video w-full my-6 rounded-2xl overflow-hidden border border-[#1E1E2E] shadow-2xl bg-black"><video controls class="w-full h-full"><source src="${raw}" type="video/mp4">Your browser does not support HTML video.</video></div><p></p>`;
    } else {
      let embedUrl = raw;
      // YouTube regex matching watch?v=, youtu.be/, shorts/, embed/
      const ytMatch = raw.match(/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/i);
      if (ytMatch && ytMatch[1]) {
        embedUrl = `https://www.youtube.com/embed/${ytMatch[1]}`;
      } else {
        const vimeoMatch = raw.match(/vimeo\.com\/(?:video\/)?([0-9]+)/i);
        if (vimeoMatch && vimeoMatch[1]) {
          embedUrl = `https://player.vimeo.com/video/${vimeoMatch[1]}`;
        }
      }
      videoHtml = `<div class="aspect-video w-full my-6 rounded-2xl overflow-hidden border border-[#1E1E2E] shadow-2xl bg-black"><iframe src="${embedUrl}" class="w-full h-full" allowfullscreen frameborder="0"></iframe></div><p></p>`;
    }

    closeModal('modalVideo');
    insertHtmlAtSelection(videoHtml);
    syncVisualToTextarea();
    if (window.EstateDialog) EstateDialog.toast('✅ Video embedded successfully!', 'success');
  }

  function insertBlockquote() {
    saveSelection();
    const selText = window.getSelection() ? window.getSelection().toString() : 'High-impact visuals deliver 3x more qualified real estate inquiries.';
    const html = `<blockquote class="border-l-4 border-gold bg-[#161622]/40 p-5 my-5 rounded-r-2xl italic text-gray-200 text-sm font-medium leading-relaxed">"${selText}"</blockquote><p></p>`;
    insertHtmlAtSelection(html);
  }

  function insertCalloutBox() {
    saveSelection();
    const html = `
      <div class="my-5 p-5 rounded-2xl bg-gradient-to-r from-gold/10 via-[#161622] to-dark border border-gold/30 shadow-xl flex items-start gap-4">
        <span class="text-2xl">💡</span>
        <div class="space-y-1">
          <div class="text-xs font-black text-gold uppercase tracking-wider">Pro Editing Tip</div>
          <div class="text-xs text-gray-300 leading-relaxed">Ensure dynamic range brackets are captured at 2.0 EV intervals for optimal window pull sharpness.</div>
        </div>
      </div><p></p>
    `;
    insertHtmlAtSelection(html);
  }

  function insertComparisonGrid(category) {
    saveSelection();
    category = category || (document.getElementById('postCategory') ? document.getElementById('postCategory').value : '') || '';
    const catLower = category.toLowerCase();
    
    let tradTitle = 'Traditional Freelancers / In-House';
    let tradItems = [
      '<strong>Turnaround:</strong> 48 – 72+ hours with unreliable freelancer delays',
      '<strong>Cost Burden:</strong> $35 – $65/hr or steep overhead per property',
      '<strong>Inconsistency:</strong> Mismatched color grading and harsh window blowouts',
      '<strong>MLS Risk:</strong> Inconsistent white balance risks buyer swipe-bys'
    ];
    let ehdrTitle = 'Estate HDR Master Studio Retouching';
    let ehdrItems = [
      '<strong>Turnaround:</strong> Guaranteed 12 – 24 hours delivered to your portal',
      '<strong>Cost Advantage:</strong> From only $0.68 – $1.20 per photo (80% cost savings)',
      '<strong>Studio Perfection:</strong> 100% human-verified flambient blend, sky replacement & lawn repair',
      '<strong>ROI & Compliance:</strong> 100% MLS-compliant with zero risk & 3 free test edits'
    ];

    if (catLower.includes('staging') || catLower.includes('furniture')) {
      tradTitle = 'Physical Home Staging';
      tradItems = [
        '<strong>Cost:</strong> $3,000 – $7,500+ for standard 3-month rental periods',
        '<strong>Logistics:</strong> Heavy moving trucks, scuffed floors, scheduling delays',
        '<strong>Fixed Decor:</strong> Cannot change styles once furniture is loaded in',
        '<strong>Risk:</strong> Seller bears cost even if listing sits on market'
      ];
      ehdrTitle = 'Estate HDR Virtual Staging';
      ehdrItems = [
        '<strong>Cost:</strong> Only $8 – $10 per high-resolution photo',
        '<strong>Turnaround:</strong> Ready to publish online in 24 hours guaranteed',
        '<strong>Infinite Variety:</strong> Modern, Scandinavian, Farmhouse, Luxury styles',
        '<strong>ROI:</strong> 100x return on investment with zero moving hassles'
      ];
    } else if (catLower.includes('dusk') || catLower.includes('twilight')) {
      tradTitle = 'Physical Sunset / Dusk Shoots';
      tradItems = [
        '<strong>Weather Dependency:</strong> Ruined by overcast, rain, or bad timing',
        '<strong>High Cost:</strong> Requires second on-site photographer shoot ($200 – $400)',
        '<strong>Scheduling:</strong> Hard to coordinate sunset times with sellers & lighting',
        '<strong>Opportunity Loss:</strong> Delays listing while waiting for clear weather'
      ];
      ehdrTitle = 'Estate HDR Virtual Twilight';
      ehdrItems = [
        '<strong>Cost:</strong> Only $3 – $4 per photo conversion',
        '<strong>Reliability:</strong> Any daytime exterior converted into a glowing sunset twilight',
        '<strong>Speed:</strong> Delivered in 12 hours ready for MLS release',
        '<strong>Engagement:</strong> 3x higher click-through rate on Zillow & Redfin'
      ];
    } else if (catLower.includes('floor')) {
      tradTitle = 'Hand Sketches / 2D Tape Measures';
      tradItems = [
        '<strong>Slow Turnaround:</strong> Manual draftsman CAD delays of 3 – 5 days',
        '<strong>High Pricing:</strong> $80 – $150 per floor plan blueprint',
        '<strong>Flat & Lifeless:</strong> Buyers struggle to visualize wall heights and room flow',
        '<strong>Inaccuracy:</strong> Manual drafting mistakes cause square footage discrepancies'
      ];
      ehdrTitle = 'Estate HDR 2D & 3D Floor Plans';
      ehdrItems = [
        '<strong>Cost:</strong> Only $12 – $18 per complete schematic level',
        '<strong>Fast Turnaround:</strong> Accurate redraws delivered in 12 – 24 hours',
        '<strong>3D Immersion:</strong> Textured floorings, realistic fixtures & dimensional depth',
        '<strong>Buyer Retention:</strong> Increases time-on-listing by 52% across portals'
      ];
    } else if (catLower.includes('item') || catLower.includes('declutter')) {
      tradTitle = 'Physical Room Decluttering & Reshoots';
      tradItems = [
        '<strong>Awkward Conversations:</strong> Asking homeowners to move personal clutter',
        '<strong>Wasted Hours:</strong> Staging and moving heavy boxes and pet supplies',
        '<strong>Reshoot Expenses:</strong> Paying extra photographer visits if rooms weren\'t ready',
        '<strong>Listing Delays:</strong> Postpones MLS launch while waiting for cleaning'
      ];
      ehdrTitle = 'Estate HDR Digital Item Removal';
      ehdrItems = [
        '<strong>Cost:</strong> Only $2 – $4 per photo decluttering',
        '<strong>Seamless Results:</strong> Clean removal of cords, pet beds, trash cans & cars',
        '<strong>Fast Turnaround:</strong> Delivered in 12 hours ready for MLS release',
        '<strong>Zero Awkwardness:</strong> Clean up photos digitally without bothering sellers'
      ];
    }

    const gridHtml = `
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 my-8 not-prose">
        <div class="glass-card p-6 rounded-2xl border border-red-500/30 bg-red-500/5">
          <div class="text-red-400 font-bold text-lg mb-2">${tradTitle}</div>
          <ul class="text-xs text-gray-300 space-y-2.5">
            ${tradItems.map(i => `<li>• ${i}</li>`).join('')}
          </ul>
        </div>
        <div class="glass-card p-6 rounded-2xl border border-gold/40 bg-gold/10 shadow-glow">
          <div class="text-gold font-bold text-lg mb-2">${ehdrTitle}</div>
          <ul class="text-xs text-gray-200 space-y-2.5">
            ${ehdrItems.map(i => `<li>• ${i}</li>`).join('')}
          </ul>
        </div>
      </div><p></p>
    `;

    insertHtmlAtSelection(gridHtml);
    syncVisualToTextarea();
    if (window.EstateDialog) EstateDialog.toast('📊 2-Column Comparison Grid inserted!', 'success');
  }

  function insertCtaBox() {
    saveSelection();
    const ctaHtml = `
      <div class="my-10 p-8 glass-card rounded-2xl border border-gold/40 text-center bg-gradient-to-r from-gold/10 via-dark-card to-gold/10 shadow-2xl not-prose">
        <h3 class="text-2xl font-bold text-white mb-2">Elevate Your Real Estate Listings in 24 Hours</h3>
        <p class="text-gray-300 text-sm max-w-xl mx-auto mb-6">Experience 24-hour turnaround architectural photo editing, virtual staging, and day-to-dusk conversions with zero risk.</p>
        <a href="/register.php" class="btn-gold py-3.5 px-8 text-sm font-bold shadow-glow inline-block">Claim 3 Free Sample Edits &rarr;</a>
      </div><p></p>
    `;
    insertHtmlAtSelection(ctaHtml);
    syncVisualToTextarea();
    if (window.EstateDialog) EstateDialog.toast('📢 24h Turnaround CTA Banner inserted!', 'success');
  }

  function beautifyContent() {
    const active = getActiveEditor() || editorEl;
    if (!active) return;
    let html = active.innerHTML || '';
    if (!html.trim()) return;

    // 0. Self-healing: Repair any corrupted pricing strings
    const pricingFixes = {
      ',000 – ,500+': '$3,000 – $7,500+',
      ',000 - ,500+': '$3,000 – $7,500+',
      'Only – per': 'Only $8 – $10 per',
      'Only - per': 'Only $8 – $10 per',
      'Cost Burden: 35 – 65/hr': 'Cost Burden: $35 – $65/hr',
      'From only 0.68 – 1.20': 'From only $0.68 – $1.20',
      'Only 3 – 4 per': 'Only $3 – $4 per',
      'Only 12 – 18 per': 'Only $12 – $18 per',
      'Only 2 – 4 per': 'Only $2 – $4 per'
    };
    for (let [bad, good] of Object.entries(pricingFixes)) {
      if (html.includes(bad)) {
        html = html.replaceAll(bad, good);
      }
    }

    // 1. Fix malformed LLM tags like <strong Word:</strong>
    html = html.replace(/<strong\s+([^>]+):<\/strong>/gi, '<strong>$1:</strong>');
    html = html.replace(/<strong\s+([^>]+)>/gi, '<strong>$1</strong>');

    // 2. Convert markdown bold/italics
    html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/(^|[^*])\*([^*\n<]+)\*([^*]|$)/g, '$1<em>$2</em>$3');

    // 3. Headings conversion
    html = html.replace(/^###\s+(.+)$/gm, '<h3 class="text-xl font-bold text-white mt-8 mb-3">$1</h3>');
    html = html.replace(/^##\s+(.+)$/gm, '<h2 class="text-2xl font-black text-gold mt-10 mb-4">$1</h2>');
    html = html.replace(/^#\s+(.+)$/gm, '<h2 class="text-2xl font-black text-gold mt-10 mb-4">$1</h2>');

    // 3.5. Ensure H2 headings are cleanly numbered (1. Section, 2. Section...)
    let h2Idx = 1;
    html = html.replace(/<h2([^>]*)>(.*?)<\/h2>/gi, function(match, attrs, inner) {
      let cleanText = inner.replace(/^\d+[\.\:\-]\s*/, '').trim();
      let numbered = (h2Idx++) + '. ' + cleanText;
      return '<h2' + attrs + '>' + numbered + '</h2>';
    });

    // 4. Strip stray asterisks inside list items (e.g. <li>* Text</li>)
    html = html.replace(/<li>\s*[\*\-•]\s*/gi, '<li>');

    // 5. Convert markdown lists
    const lines = html.split('\n');
    let out = [];
    let inList = false;
    for (let l of lines) {
      let tr = l.trim();
      let m = tr.match(/^[\*\-•]\s+(.+)$/);
      if (m) {
        if (!inList) {
          out.push('<ul class="space-y-3 my-4 text-gray-300 list-disc pl-6">');
          inList = true;
        }
        out.push('  <li>' + m[1] + '</li>');
      } else {
        if (inList) {
          out.push('</ul>');
          inList = false;
        }
        out.push(l);
      }
    }
    if (inList) out.push('</ul>');
    html = out.join('\n');

    // 6. Check Comparison Grid
    const category = (document.getElementById('postCategory') ? document.getElementById('postCategory').value : '') || '';
    const title = (document.getElementById('postTitle') ? document.getElementById('postTitle').value : '') || '';
    if (!html.includes('grid-cols-1 sm:grid-cols-2') && !html.includes('Physical Home Staging')) {
      const catLower = (category + ' ' + title).toLowerCase();
      let tradTitle = 'Traditional Freelancers / In-House';
      let tradItems = [
        '<strong>Turnaround:</strong> 48 – 72+ hours with unreliable freelancer delays',
        '<strong>Cost Burden:</strong> $35 – $65/hr or steep overhead per property',
        '<strong>Inconsistency:</strong> Mismatched color grading and harsh window blowouts',
        '<strong>MLS Risk:</strong> Inconsistent white balance risks buyer swipe-bys'
      ];
      let ehdrTitle = 'Estate HDR Master Studio Retouching';
      let ehdrItems = [
        '<strong>Turnaround:</strong> Guaranteed 12 – 24 hours delivered to your portal',
        '<strong>Cost Advantage:</strong> From only $0.68 – $1.20 per photo (80% cost savings)',
        '<strong>Studio Perfection:</strong> 100% human-verified flambient blend, sky replacement & lawn repair',
        '<strong>ROI & Compliance:</strong> 100% MLS-compliant with zero risk & 3 free test edits'
      ];
      if (catLower.includes('staging') || catLower.includes('furniture')) {
        tradTitle = 'Physical Home Staging';
        tradItems = [
          '<strong>Cost:</strong> $3,000 – $7,500+ for standard 3-month rental periods',
          '<strong>Logistics:</strong> Heavy moving trucks, scuffed floors, scheduling delays',
          '<strong>Fixed Decor:</strong> Cannot change styles once furniture is loaded in',
          '<strong>Risk:</strong> Seller bears cost even if listing sits on market'
        ];
        ehdrTitle = 'Estate HDR Virtual Staging';
        ehdrItems = [
          '<strong>Cost:</strong> Only $8 – $10 per high-resolution photo',
          '<strong>Turnaround:</strong> Ready to publish online in 24 hours guaranteed',
          '<strong>Infinite Variety:</strong> Modern, Scandinavian, Farmhouse, Luxury styles',
          '<strong>ROI:</strong> 100x return on investment with zero moving hassles'
        ];
      } else if (catLower.includes('dusk') || catLower.includes('twilight')) {
        tradTitle = 'Physical Sunset / Dusk Shoots';
        tradItems = [
          '<strong>Weather Dependency:</strong> Ruined by overcast, rain, or bad timing',
          '<strong>High Cost:</strong> Requires second on-site photographer shoot ($200 – $400)',
          '<strong>Scheduling:</strong> Hard to coordinate sunset times with sellers & lighting',
          '<strong>Opportunity Loss:</strong> Delays listing while waiting for clear weather'
        ];
        ehdrTitle = 'Estate HDR Virtual Twilight';
        ehdrItems = [
          '<strong>Cost:</strong> Only $3 – $4 per photo conversion',
          '<strong>Reliability:</strong> Any daytime exterior converted into a glowing sunset twilight',
          '<strong>Speed:</strong> Delivered in 12 hours ready for MLS release',
          '<strong>Engagement:</strong> 3x higher click-through rate on Zillow & Redfin'
        ];
      } else if (catLower.includes('floor')) {
        tradTitle = 'Hand Sketches / 2D Tape Measures';
        tradItems = [
          '<strong>Slow Turnaround:</strong> Manual draftsman CAD delays of 3 – 5 days',
          '<strong>High Pricing:</strong> $80 – $150 per floor plan blueprint',
          '<strong>Flat & Lifeless:</strong> Buyers struggle to visualize wall heights and room flow',
          '<strong>Inaccuracy:</strong> Manual drafting mistakes cause square footage discrepancies'
        ];
        ehdrTitle = 'Estate HDR 2D & 3D Floor Plans';
        ehdrItems = [
          '<strong>Cost:</strong> Only $12 – $18 per complete schematic level',
          '<strong>Fast Turnaround:</strong> Accurate redraws delivered in 12 – 24 hours',
          '<strong>3D Immersion:</strong> Textured floorings, realistic fixtures & dimensional depth',
          '<strong>Buyer Retention:</strong> Increases time-on-listing by 52% across portals'
        ];
      } else if (catLower.includes('item') || catLower.includes('declutter')) {
        tradTitle = 'Physical Room Decluttering & Reshoots';
        tradItems = [
          '<strong>Awkward Conversations:</strong> Asking homeowners to move personal clutter',
          '<strong>Wasted Hours:</strong> Staging and moving heavy boxes and pet supplies',
          '<strong>Reshoot Expenses:</strong> Paying extra photographer visits if rooms weren\'t ready',
          '<strong>Listing Delays:</strong> Postpones MLS launch while waiting for cleaning'
        ];
        ehdrTitle = 'Estate HDR Digital Item Removal';
        ehdrItems = [
          '<strong>Cost:</strong> Only $2 – $4 per photo decluttering',
          '<strong>Seamless Results:</strong> Clean removal of cords, pet beds, trash cans & cars',
          '<strong>Fast Turnaround:</strong> Delivered in 12 hours ready for MLS release',
          '<strong>Zero Awkwardness:</strong> Clean up photos digitally without bothering sellers'
        ];
      }
      const gridHtml = `
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 my-8 not-prose">
          <div class="glass-card p-6 rounded-2xl border border-red-500/30 bg-red-500/5">
            <div class="text-red-400 font-bold text-lg mb-2">${tradTitle}</div>
            <ul class="text-xs text-gray-300 space-y-2.5">
              ${tradItems.map(i => `<li class="flex items-start gap-2"><span class="text-red-400 font-bold">•</span><span>${i}</span></li>`).join('')}
            </ul>
          </div>
          <div class="glass-card p-6 rounded-2xl border border-gold/40 bg-gold/10 shadow-glow">
            <div class="text-gold font-bold text-lg mb-2">${ehdrTitle}</div>
            <ul class="text-xs text-gray-200 space-y-2.5">
              ${ehdrItems.map(i => `<li class="flex items-start gap-2"><span class="text-gold font-bold">✓</span><span>${i}</span></li>`).join('')}
            </ul>
          </div>
        </div><p></p>
      `;
      if (html.includes('</h2>')) {
        html = html.replace(/(<\/h2>[\s\S]*?<\/p>)/, (match, p1) => p1 + '\n\n' + gridHtml);
      } else {
        html = gridHtml + '\n\n' + html;
      }
    }

    // 7. Check CTA Banner
    if (!html.includes('register.php') && !html.includes('Claim 3 Free Sample Edits') && !html.includes('Order Virtual Staging')) {
      const ctaHtml = `
        <div class="my-10 p-8 glass-card rounded-2xl border border-gold/40 text-center bg-gradient-to-r from-gold/10 via-dark-card to-gold/10 shadow-2xl not-prose">
          <h3 class="text-2xl font-bold text-white mb-2">Elevate Your Real Estate Listings in 24 Hours</h3>
          <p class="text-gray-300 text-sm max-w-xl mx-auto mb-6">Experience 24-hour turnaround architectural photo editing, virtual staging, and day-to-dusk conversions with zero risk.</p>
          <a href="/register.php" class="btn-gold py-3.5 px-8 text-sm font-bold shadow-glow inline-block">Claim 3 Free Sample Edits &rarr;</a>
        </div><p></p>
      `;
      if (html.includes('class="article-hashtags"')) {
        html = html.replace('<div class="article-hashtags"', ctaHtml + '\n\n<div class="article-hashtags"');
      } else {
        html += '\n\n' + ctaHtml;
      }
    }

    active.innerHTML = html;
    syncVisualToTextarea();
    if (window.EstateDialog) {
      EstateDialog.toast('✨ Article formatted to Benchmark Layout (Grid & CTA active)!', 'success');
    }
  }

  function insertHorizontalRule() {
    execCmd('insertHorizontalRule');
  }

  function insertCodeBlock() {
    openRawHtmlModal('html');
  }

  function openRawHtmlModal(tab = 'html') {
    saveSelection();
    switchRawHtmlTab(tab);
    openModal('modalRawHtml');
    setTimeout(() => {
      const target = tab === 'schema' ? document.getElementById('rawSchemaInput') : document.getElementById('rawHtmlInput');
      if (target) target.focus();
    }, 150);
  }

  function switchRawHtmlTab(tab) {
    const pnlHtml = document.getElementById('rawPanelHtml');
    const pnlSchema = document.getElementById('rawPanelSchema');
    const btnHtml = document.getElementById('rawTabBtnHtml');
    const btnSchema = document.getElementById('rawTabBtnSchema');

    if (tab === 'schema') {
      if (pnlHtml) pnlHtml.classList.add('hidden');
      if (pnlSchema) pnlSchema.classList.remove('hidden');
      if (btnHtml) btnHtml.className = 'flex-1 py-1.5 font-bold rounded-lg text-gray-400 hover:text-white';
      if (btnSchema) btnSchema.className = 'flex-1 py-1.5 font-bold rounded-lg bg-gold text-dark';
    } else {
      if (pnlHtml) pnlHtml.classList.remove('hidden');
      if (pnlSchema) pnlSchema.classList.add('hidden');
      if (btnHtml) btnHtml.className = 'flex-1 py-1.5 font-bold rounded-lg bg-gold text-dark';
      if (btnSchema) btnSchema.className = 'flex-1 py-1.5 font-bold rounded-lg text-gray-400 hover:text-white';
    }
  }

  function loadSchemaTemplate(type) {
    const schemaArea = document.getElementById('rawSchemaInput');
    if (!schemaArea) return;

    const pageTitle = (document.getElementById('postTitle') || document.getElementById('pageTitleInput') || {}).value || 'Estate HDR Professional Photo Editing';
    const author = (document.querySelector('input[name="author"]') || {}).value || 'Estate HDR Editorial Team';
    const dateStr = new Date().toISOString().split('T')[0];

    let schemaObj = {};
    if (type === 'faq') {
      schemaObj = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
          {
            "@type": "Question",
            "name": "What is the turnaround time for Estate HDR photo editing?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Our standard guaranteed delivery is under 12 to 24 hours, with urgent rush options available."
            }
          },
          {
            "@type": "Question",
            "name": "Do you provide window masking and sky replacements?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Yes, every photo includes flambient blending, pristine window pulls, realistic blue sky replacement, and lens perspective correction."
            }
          }
        ]
      };
    } else if (type === 'article') {
      schemaObj = {
        "@context": "https://schema.org",
        "@type": "BlogPosting",
        "headline": pageTitle,
        "description": "Comprehensive industry guide and expert real estate photography insights by Estate HDR.",
        "author": {
          "@type": "Organization",
          "name": author
        },
        "publisher": {
          "@type": "Organization",
          "name": "Estate HDR",
          "logo": {
            "@type": "ImageObject",
            "url": "https://estatehdr.com/assets/images/logo.png"
          }
        },
        "datePublished": dateStr,
        "dateModified": dateStr
      };
    } else if (type === 'business') {
      schemaObj = {
        "@context": "https://schema.org",
        "@type": "ProfessionalService",
        "name": "Estate HDR Photo Editing Studio",
        "image": "https://estatehdr.com/assets/images/portfolio/hdr/1-after.jpg",
        "url": "https://estatehdr.com",
        "telephone": "+44 770 606 8176",
        "priceRange": "$0.68 - $15.00",
        "address": {
          "@type": "PostalAddress",
          "addressCountry": "US"
        }
      };
    } else if (type === 'howto') {
      schemaObj = {
        "@context": "https://schema.org",
        "@type": "HowTo",
        "name": "How to Prepare Real Estate Photos for HDR Editing",
        "step": [
          {
            "@type": "HowToStep",
            "name": "Capture 3 to 5 EV Brackets",
            "text": "Use a sturdy tripod and capture bracketed exposures at -2, 0, +2 EV."
          },
          {
            "@type": "HowToStep",
            "name": "Upload RAW or High-Res JPEG",
            "text": "Send raw files via cloud storage link into the Estate HDR client portal."
          }
        ]
      };
    }

    schemaArea.value = `<script type="application/ld+json">\n${JSON.stringify(schemaObj, null, 2)}\n<\/script>`;
  }

  function applyRawHtml() {
    const isSchema = !document.getElementById('rawPanelSchema').classList.contains('hidden');
    let code = isSchema ? document.getElementById('rawSchemaInput').value.trim() : document.getElementById('rawHtmlInput').value.trim();

    if (!code) {
      if (window.EstateDialog) EstateDialog.toast('Please enter HTML or Schema code.', 'error');
      else alert('Please enter HTML or Schema code.');
      return;
    }

    closeModal('modalRawHtml');

    if (code.includes('<script type="application/ld+json">') || isSchema) {
      if (!code.startsWith('<script') && !code.endsWith('</script>')) {
        code = `<script type="application/ld+json">\n${code}\n<\/script>`;
      }
      const badgeHtml = `<div class="schema-embed-badge my-4 select-none" contenteditable="false"><span>✨ <strong>Schema Markup (JSON-LD) Embedded</strong></span><span class="text-gold font-bold text-xs">SSR Verified ✓</span></div>${code}<p></p>`;
      insertHtmlAtSelection(badgeHtml);
    } else {
      insertHtmlAtSelection(code + '<p></p>');
    }

    if (window.EstateDialog) EstateDialog.toast('Code / Schema inserted successfully!', 'success');
  }

  // ── Drag & Drop Featured Image / OG Card Uploader ─────────────
  function initFeaturedImageUploader() {
    if (window.EstateEditorMode === 'post') {
      // post-edit.php manages its own full-featured cover uploader
      return;
    }
    const dropzone = document.getElementById('featuredImgDropzone');
    const fileInput = document.getElementById('featuredImgFileInput');
    const urlInput = document.getElementById('featuredImgInput');
    const previewImg = document.getElementById('coverPreview');
    const customNameInput = document.getElementById('featuredImgCustomName');
    const progressEl = document.getElementById('featuredImgUploadProgress');

    if (!dropzone || !fileInput) return;

    dropzone.addEventListener('click', () => {
      fileInput.value = '';
      fileInput.click();
    });
    dropzone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropzone.classList.add('border-gold', 'bg-gold/5');
    });
    dropzone.addEventListener('dragleave', () => {
      dropzone.classList.remove('border-gold', 'bg-gold/5');
    });
    dropzone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropzone.classList.remove('border-gold', 'bg-gold/5');
      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        uploadFeaturedFile(e.dataTransfer.files[0]);
      }
    });

    fileInput.addEventListener('change', () => {
      if (fileInput.files && fileInput.files[0]) {
        uploadFeaturedFile(fileInput.files[0]);
      }
    });

    function uploadFeaturedFile(file) {
      if (progressEl) progressEl.classList.remove('hidden');
      const customName = customNameInput ? customNameInput.value.trim() : '';
      
      const formData = new FormData();
      formData.append('image', file);
      if (customName) formData.append('custom_name', customName);
      const csrfEl = document.querySelector('input[name="csrf_token"]') || document.querySelector('meta[name="csrf-token"]');
      const csrfVal = csrfEl ? (csrfEl.value || csrfEl.content) : '';
      if (csrfVal) formData.append('csrf_token', csrfVal);

      fetch('/api/upload-image.php', {
        method: 'POST',
        headers: csrfVal ? { 'X-CSRF-TOKEN': csrfVal } : {},
        body: formData
      })
      .then(r => r.json())
      .then(data => {
        if (progressEl) progressEl.classList.add('hidden');
        fileInput.value = '';
        if (data.success) {
          if (urlInput) urlInput.value = data.url;
          if (previewImg) previewImg.src = data.url;
          if (window.EstateDialog) EstateDialog.toast('Featured image uploaded successfully!', 'success');
        } else {
          if (window.EstateDialog) EstateDialog.toast(data.error || 'Featured image upload failed.', 'error');
          else alert(data.error || 'Featured image upload failed.');
        }
      })
      .catch(err => {
        if (progressEl) progressEl.classList.add('hidden');
        fileInput.value = '';
        if (window.EstateDialog) EstateDialog.toast('Upload failed: ' + err.message, 'error');
        else alert('Upload failed: ' + err.message);
      });
    }
  }

  // ── Retrieve Exact Active Content Across Visual & HTML Views ───────
  function getContent() {
    const fsModal = document.getElementById('modalFullscreenEditor');
    if (fsModal && !fsModal.classList.contains('hidden')) {
      const fsCode = document.getElementById('editorCodeFullscreen');
      if (fsCode && !fsCode.classList.contains('hidden')) {
        return fsCode.value;
      }
      const fsVisual = document.getElementById('editorVisualFullscreen');
      if (fsVisual) return fsVisual.innerHTML;
    }
    const code = document.getElementById('postContent') || document.getElementById('pageContent') || textareaEl;
    if (code && !code.classList.contains('hidden')) {
      return code.value;
    }
    const visual = document.getElementById('editorVisual') || editorEl;
    if (visual && !visual.classList.contains('hidden')) {
      return visual.innerHTML;
    }
    if (code) return code.value;
    if (visual) return visual.innerHTML;
    return '';
  }

  // ── Live Responsive Preview in Dedicated Tab ──────────────────────
  function openLivePreview(type = 'page') {
    const code = document.getElementById('postContent') || document.getElementById('pageContent') || textareaEl;
    const visual = document.getElementById('editorVisual') || editorEl;
    
    // Retrieve latest content from whichever view is currently active (HTML code or visual)
    const content = getContent() || '<p>No content written yet.</p>';

    // Synchronize both DOM elements seamlessly
    if (code) code.value = content;
    if (visual) visual.innerHTML = content;
    
    const title = (document.getElementById('pageTitleInput') || document.getElementById('postTitle') || {}).value || 'Untitled Preview';
    const coverUrl = (document.getElementById('featuredImgInput') || {}).value || '';
    const category = (document.getElementById('postCategorySelect') || document.getElementById('pageCategorySelect') || {}).value || 'HDR Photo Editing';
    const slug = (document.getElementById('pageSlugInput') || document.getElementById('postSlug') || {}).value || 'preview';
    const excerpt = (document.getElementById('postExcerpt') || document.getElementById('pageMetaDesc') || {}).value || '';
    const author = (document.querySelector('input[name="author"]') || {}).value || 'Estate HDR Editorial Team';
    const tags = (document.querySelector('input[name="tags"]') || {}).value || '';

    const previewData = {
      type: type,
      title: title,
      content: content,
      coverUrl: coverUrl,
      category: category,
      slug: slug,
      excerpt: excerpt,
      author: author,
      tags: tags,
      updated_at: new Date().toISOString()
    };

    try {
      localStorage.setItem('estatehdr_preview_data', JSON.stringify(previewData));
      sessionStorage.setItem('estatehdr_preview_data', JSON.stringify(previewData));
    } catch(e) {
      console.warn('LocalStorage preview quota exceeded', e);
    }

    // Open Live Preview in a NEW BROWSER TAB
    const previewUrl = `/admin/preview.php?type=${encodeURIComponent(type)}&slug=${encodeURIComponent(slug)}`;
    const previewWindow = window.open(previewUrl, '_blank');
    if (previewWindow) {
      previewWindow.focus();
      // Send postMessage as backup for instantaneous preview hydration
      setTimeout(() => {
        try {
          previewWindow.postMessage({ type: 'ESTATE_HDR_PREVIEW', data: previewData }, '*');
        } catch(e) {}
      }, 300);
      if (window.EstateDialog) EstateDialog.toast('🚀 Opening Live Preview in new tab...', 'info');
    } else {
      alert('Please allow popups/new tabs in your browser to view Live Preview.');
    }
  }

  function setPreviewDevice(device) {
    const container = document.getElementById('previewFrameContainer');
    const btnD = document.getElementById('prevBtnDesk');
    const btnT = document.getElementById('prevBtnTab');
    const btnM = document.getElementById('prevBtnMob');

    btnD.className = `py-1 px-3 rounded-lg font-bold ${device === 'desktop' ? 'bg-gold text-dark' : 'text-gray-400 hover:text-white'}`;
    btnT.className = `py-1 px-3 rounded-lg font-bold ${device === 'tablet' ? 'bg-gold text-dark' : 'text-gray-400 hover:text-white'}`;
    btnM.className = `py-1 px-3 rounded-lg font-bold ${device === 'mobile' ? 'bg-gold text-dark' : 'text-gray-400 hover:text-white'}`;

    if (device === 'mobile') {
      container.className = 'w-[375px] max-w-full bg-[#0A0A0F] border-2 border-gold/40 rounded-3xl p-5 shadow-2xl text-white transition-all duration-300 space-y-4';
    } else if (device === 'tablet') {
      container.className = 'w-[768px] max-w-full bg-[#0A0A0F] border border-[#1E1E2E] rounded-2xl p-8 shadow-2xl text-white transition-all duration-300 space-y-6';
    } else {
      container.className = 'w-full max-w-4xl bg-[#0A0A0F] border border-[#1E1E2E] rounded-2xl p-10 shadow-2xl text-white transition-all duration-300 space-y-6';
    }
  }

  // ── Fullscreen Zen Studio Handlers ───────────────────────────
  function openFullscreenModal() {
    syncVisualToTextarea();
    const fsModal = document.getElementById('modalFullscreenEditor');
    const fsVisual = document.getElementById('editorVisualFullscreen');
    const fsCode = document.getElementById('editorCodeFullscreen');
    const fsTitle = document.getElementById('fullscreenDocTitle');
    
    if (!fsModal || !fsVisual) return;

    const title = (document.getElementById('pageTitleInput') || document.getElementById('postTitle') || {}).value || 'Untitled Document';
    if (fsTitle) fsTitle.textContent = `Editing Document: "${title}"`;

    fsVisual.innerHTML = (editorEl ? editorEl.innerHTML : '') || '<p>Write your content here...</p>';
    if (fsCode) fsCode.value = fsVisual.innerHTML;

    fsVisual.classList.remove('hidden');
    if (fsCode) fsCode.classList.add('hidden');
    const htmlBtn = document.getElementById('fullscreenHtmlToggleText');
    if (htmlBtn) htmlBtn.textContent = 'HTML View';
    const toolbar = document.getElementById('fullscreenToolbar');
    if (toolbar) toolbar.classList.remove('opacity-40', 'pointer-events-none');

    updateFullscreenWordCount();
    openModal('modalFullscreenEditor');
    setTimeout(() => {
      fsVisual.focus();
    }, 150);
  }

  function syncFullscreenToMain() {
    const fsVisual = document.getElementById('editorVisualFullscreen');
    const fsCode = document.getElementById('editorCodeFullscreen');
    if (!fsVisual) return;

    let currentHtml = fsVisual.innerHTML;
    if (fsCode && !fsCode.classList.contains('hidden')) {
      currentHtml = fsCode.value;
      fsVisual.innerHTML = currentHtml;
    }

    if (editorEl) editorEl.innerHTML = currentHtml;
    if (textareaEl) textareaEl.value = currentHtml;

    updateFullscreenWordCount();
    if (typeof window.runReadabilityAudit === 'function') {
      window.runReadabilityAudit();
    }
  }

  function syncFullscreenCodeToVisual() {
    const fsVisual = document.getElementById('editorVisualFullscreen');
    const fsCode = document.getElementById('editorCodeFullscreen');
    if (!fsVisual || !fsCode) return;

    fsVisual.innerHTML = fsCode.value;
    if (editorEl) editorEl.innerHTML = fsCode.value;
    if (textareaEl) textareaEl.value = fsCode.value;

    updateFullscreenWordCount();
    if (typeof window.runReadabilityAudit === 'function') {
      window.runReadabilityAudit();
    }
  }

  function updateFullscreenWordCount() {
    const fsVisual = document.getElementById('editorVisualFullscreen');
    const badge = document.getElementById('fullscreenWordCountBadge');
    if (!fsVisual || !badge) return;

    const text = fsVisual.innerText || '';
    const words = text.trim() ? text.trim().split(/\s+/).length : 0;
    const chars = text.length;
    const readTime = Math.max(1, Math.ceil(words / 200));
    badge.textContent = `Words: ${words.toLocaleString()} | Characters: ${chars.toLocaleString()} | ~${readTime} min read`;
  }

  function toggleFullscreenHtmlView() {
    const fsVisual = document.getElementById('editorVisualFullscreen');
    const fsCode = document.getElementById('editorCodeFullscreen');
    const btnText = document.getElementById('fullscreenHtmlToggleText');
    const toolbar = document.getElementById('fullscreenToolbar');

    if (fsCode.classList.contains('hidden')) {
      fsCode.value = fsVisual.innerHTML;
      fsVisual.classList.add('hidden');
      fsCode.classList.remove('hidden');
      if (toolbar) toolbar.classList.add('opacity-40', 'pointer-events-none');
      if (btnText) btnText.textContent = 'Visual View';
    } else {
      syncFullscreenCodeToVisual();
      fsCode.classList.add('hidden');
      fsVisual.classList.remove('hidden');
      if (toolbar) toolbar.classList.remove('opacity-40', 'pointer-events-none');
      if (btnText) btnText.textContent = 'HTML View';
    }
    syncFullscreenToMain();
  }

  function saveAndCloseFullscreen(showToast = true) {
    syncFullscreenToMain();
    closeModal('modalFullscreenEditor');
    if (editorEl) editorEl.focus();
    if (showToast && window.EstateDialog) {
      EstateDialog.toast('✨ Content updated & synced to main editor!', 'success');
    }
  }

  return {
    init,
    getContent,
    execCmd,
    applyHeading,
    syncVisualToTextarea,
    syncTextareaToVisual,
    openLinkModal,
    applyLink,
    openImageModal,
    applyImage,
    switchImageTab,
    openTableModal,
    applyTable,
    openCtaModal,
    applyCta,
    openVideoModal,
    applyVideo,
    insertBlockquote,
    insertCalloutBox,
    insertComparisonGrid,
    insertCtaBox,
    beautifyContent,
    insertHorizontalRule,
    insertCodeBlock,
    openRawHtmlModal,
    switchRawHtmlTab,
    loadSchemaTemplate,
    applyRawHtml,
    detectActiveHeading,
    openModal,
    closeModal,
    openLivePreview,
    setPreviewDevice,
    openFullscreenModal,
    saveAndCloseFullscreen,
    syncFullscreenToMain,
    syncFullscreenCodeToVisual,
    toggleFullscreenHtmlView,
    selectCurrentSlash
  };
})();