/**
 * Estate HDR — Master 120Hz Ultra-Smooth Motion & Transition Engine
 * Calibrated for high-refresh displays (120Hz / 144Hz / ProMotion)
 * Features:
 * 1. Lenis 1.1.18 Momentum Scroll Physics (Desktop Wheel + Mobile Touch Sync with 120fps extrapolation)
 * 2. Instant Native-App Page Transitions (View Transitions API + Gold Nano-Progress Loader)
 * 3. Universal Zero-Reflow Before/After Slider Engine (PointerCapture + RAF throttled)
 * 4. Progressive Scroll Reveal Engine with GPU Layer Promotion
 * 5. High-Refresh Glassmorphic Navbar Scroll Physics
 * 6. Smooth Interactive Micro-Interactions (Damped 3D Card Tilt, Accordion Fluidity)
 */
(function () {
  'use strict';

  var isReducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var isTouchDevice = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);

  // ─── 1. TOP GOLD NANO-PROGRESS LOADER ──────────────────────────────────────
  var topLoader = null;
  var loaderTimer = null;

  function getOrCreateLoader() {
    if (topLoader) return topLoader;
    topLoader = document.getElementById('ehdr-top-progress');
    if (!topLoader) {
      topLoader = document.createElement('div');
      topLoader.id = 'ehdr-top-progress';
      topLoader.setAttribute('aria-hidden', 'true');
      document.documentElement.appendChild(topLoader);
    }
    return topLoader;
  }

  function startTopLoader() {
    var loader = getOrCreateLoader();
    if (!loader) return;
    if (loaderTimer) clearInterval(loaderTimer);

    loader.style.opacity = '1';
    loader.style.transform = 'scaleX(0.08)';

    var progress = 0.08;
    loaderTimer = setInterval(function () {
      if (progress < 0.72) {
        progress += (0.72 - progress) * 0.18;
        loader.style.transform = 'scaleX(' + progress.toFixed(3) + ')';
      } else if (progress < 0.90) {
        progress += 0.015;
        loader.style.transform = 'scaleX(' + progress.toFixed(3) + ')';
      }
    }, 40);
  }

  function finishTopLoader() {
    var loader = getOrCreateLoader();
    if (!loader) return;
    if (loaderTimer) clearInterval(loaderTimer);

    loader.style.transform = 'scaleX(1)';
    setTimeout(function () {
      loader.style.opacity = '0';
      setTimeout(function () {
        loader.style.transform = 'scaleX(0)';
      }, 250);
    }, 120);
  }

  // ─── 2. INSTANT 120HZ NATIVE-APP PAGE TRANSITIONS ─────────────────────────
  function initPageTransitions() {
    if (isReducedMotion) return;

    // Signal page entrance on mount
    document.body.classList.add('ehdr-page-entered');
    finishTopLoader();

    // Handle bfcache (back/forward cache navigation)
    window.addEventListener('pageshow', function (e) {
      document.documentElement.classList.remove('ehdr-navigating');
      document.body.classList.add('ehdr-page-entered');
      finishTopLoader();
    });

    // Intercept internal anchor clicks
    document.addEventListener('click', function (e) {
      var link = e.target.closest('a');
      if (!link) return;

      var href = link.getAttribute('href');
      if (!href) return;

      // Ignore anchor jumps, javascript:, tel:, mailto:, new tabs, external hosts, file downloads
      if (
        href.startsWith('#') ||
        href.startsWith('javascript:') ||
        href.startsWith('tel:') ||
        href.startsWith('mailto:') ||
        link.getAttribute('target') === '_blank' ||
        link.hasAttribute('download') ||
        e.ctrlKey || e.metaKey || e.shiftKey || e.altKey
      ) {
        return;
      }

      var currentOrigin = window.location.origin;
      var targetUrl = null;
      try {
        targetUrl = new URL(href, window.location.href);
      } catch (err) {
        return;
      }

      if (targetUrl.origin !== currentOrigin) return;

      // Ignore identical URL hash jumps
      if (targetUrl.pathname === window.location.pathname && targetUrl.search === window.location.search) {
        return;
      }

      // Ignore admin / logout / file downloads
      if (targetUrl.pathname.startsWith('/admin') || targetUrl.pathname.includes('logout') || targetUrl.pathname.match(/\.(pdf|zip|raw|png|jpg|jpeg|webp)$/i)) {
        return;
      }

      // Trigger 120Hz progressive page exit transition
      startTopLoader();
      document.documentElement.classList.add('ehdr-navigating');

      if ('startViewTransition' in document && typeof document.startViewTransition === 'function') {
        e.preventDefault();
        document.startViewTransition(function () {
          window.location.href = targetUrl.href;
        });
      }
    });
  }

  // ─── 3. 120HZ LENIS MOMENTUM SCROLL ENGINE ─────────────────────────────────
  var lenisInstance = null;

  function initLenis() {
    if (typeof Lenis === 'undefined' || isReducedMotion) return;

    try {
      lenisInstance = new Lenis({
        duration: isTouchDevice ? 0.95 : 1.05,
        easing: function (t) { return Math.min(1, 1.001 - Math.pow(2, -10 * t)); }, // Ultra-silky exponential curve
        orientation: 'vertical',
        gestureOrientation: 'vertical',
        smoothWheel: true,
        syncTouch: true, // Enables mobile & touchpad high-refresh momentum
        syncTouchLerp: 0.085,
        touchInertiaMultiplier: 42,
        touchMultiplier: 1.5,
        wheelMultiplier: 1.12,
        infinite: false,
        autoResize: true,
      });

      window.__ehdr_lenis = lenisInstance;

      // Sync with GSAP ticker if loaded
      if (typeof ScrollTrigger !== 'undefined' && typeof gsap !== 'undefined') {
        lenisInstance.on('scroll', ScrollTrigger.update);
        gsap.ticker.add(function (time) {
          lenisInstance.raf(time * 1000);
        });
        gsap.ticker.lagSmoothing(0);
      } else {
        // High-Refresh Native RAF Loop (adapts to 60Hz / 90Hz / 120Hz / 144Hz)
        var rafLoop = function (time) {
          lenisInstance.raf(time);
          requestAnimationFrame(rafLoop);
        };
        requestAnimationFrame(rafLoop);
      }
    } catch (err) {
      console.warn('[Estate HDR] Lenis 120Hz engine fallback:', err);
    }
  }

  // ─── 4. HIGH-PERFORMANCE PROGRESSIVE SCROLL REVEALS ───────────────────────
  function initReveals() {
    var reveals = document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale');
    if (!reveals.length) return;

    document.documentElement.classList.add('reveal-init');

    if ('IntersectionObserver' in window) {
      var revealObserver = new IntersectionObserver(function (entries, observer) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            var el = entry.target;
            el.classList.add('visible');
            observer.unobserve(el);
          }
        });
      }, {
        root: null,
        rootMargin: '0px 0px -40px 0px',
        threshold: 0.06
      });

      reveals.forEach(function (el, idx) {
        var rect = el.getBoundingClientRect();
        if (rect.top < window.innerHeight && rect.bottom > 0) {
          // Instant micro-stagger for initial above-the-fold content
          setTimeout(function () {
            el.classList.add('visible');
          }, Math.min(idx * 30, 240));
        } else {
          revealObserver.observe(el);
        }
      });
    } else {
      reveals.forEach(function (el) { el.classList.add('visible'); });
    }
  }

  // ─── 5. UNIVERSAL ZERO-REFLOW BEFORE/AFTER SLIDER ENGINE (120HZ POINTER) ──
  function initUniversalBeforeAfter(scope) {
    var root = scope || document;
    var containers = root.querySelectorAll('[data-ba]');
    if (!containers.length) return;

    containers.forEach(function (container) {
      if (container.hasAttribute('data-ba-120hz-ready')) return;
      container.setAttribute('data-ba-120hz-ready', 'true');

      var after = container.querySelector('.ba-after');
      var divider = container.querySelector('.ba-divider');
      if (!after || !divider) return;

      var isDragging = false;
      var cachedRect = null;
      var targetPct = 50;
      var rafId = null;

      function updateVisuals() {
        divider.style.left = targetPct + '%';
        after.style.clipPath = 'inset(0 ' + (100 - targetPct) + '% 0 0)';
        rafId = null;
      }

      function scheduleUpdate(pct) {
        targetPct = Math.min(Math.max(pct, 0), 100);
        if (!rafId) {
          rafId = requestAnimationFrame(updateVisuals);
        }
      }

      function onPointerDown(e) {
        isDragging = true;
        container.classList.add('is-dragging');
        cachedRect = container.getBoundingClientRect();
        divider.setPointerCapture?.(e.pointerId);

        var pct = ((e.clientX - cachedRect.left) / cachedRect.width) * 100;
        scheduleUpdate(pct);
      }

      function onPointerMove(e) {
        if (!isDragging || !cachedRect) return;
        var pct = ((e.clientX - cachedRect.left) / cachedRect.width) * 100;
        scheduleUpdate(pct);
      }

      function onPointerUp(e) {
        if (!isDragging) return;
        isDragging = false;
        container.classList.remove('is-dragging');
        cachedRect = null;
        divider.releasePointerCapture?.(e.pointerId);
      }

      // Pointer events support modern touch and high-polling mice seamlessly
      divider.addEventListener('pointerdown', onPointerDown, { passive: true });
      window.addEventListener('pointermove', onPointerMove, { passive: true });
      window.addEventListener('pointerup', onPointerUp, { passive: true });
      window.addEventListener('pointercancel', onPointerUp, { passive: true });

      // Click anywhere on container jumps slider smoothly
      container.addEventListener('click', function (e) {
        if (e.target === divider) return;
        var rect = container.getBoundingClientRect();
        if (rect.width > 0) {
          var pct = ((e.clientX - rect.left) / rect.width) * 100;
          scheduleUpdate(pct);
        }
      });

      // Keyboard accessibility (ArrowLeft / ArrowRight)
      divider.setAttribute('tabindex', '0');
      divider.setAttribute('role', 'slider');
      divider.setAttribute('aria-valuenow', '50');
      divider.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowLeft') {
          e.preventDefault();
          scheduleUpdate(targetPct - 3);
        } else if (e.key === 'ArrowRight') {
          e.preventDefault();
          scheduleUpdate(targetPct + 3);
        }
      });

      // Initial placement
      targetPct = 50;
      updateVisuals();
    });
  }

  // ─── 6. SILKY SMOOTH ANCHOR SCROLL (LENIS-AWARE) ───────────────────────────
  function initSmoothAnchorScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
      anchor.addEventListener('click', function (e) {
        var href = anchor.getAttribute('href');
        if (!href || href === '#' || href.length < 2) return;

        try {
          var target = document.querySelector(href);
          if (!target) return;
          e.preventDefault();

          if (lenisInstance) {
            lenisInstance.scrollTo(target, {
              offset: -85,
              duration: 1.05,
              easing: function (t) { return Math.min(1, 1.001 - Math.pow(2, -10 * t)); }
            });
          } else {
            var navOffset = 85;
            var elementPosition = target.getBoundingClientRect().top;
            var offsetPosition = elementPosition + window.pageYOffset - navOffset;
            window.scrollTo({
              top: offsetPosition,
              behavior: 'smooth'
            });
          }
        } catch (err) {}
      });
    });
  }

  // ─── 7. HIGH-REFRESH GLASSMORPHIC NAVBAR SCROLL ────────────────────────────
  function initNavbarScroll() {
    var navbar = document.getElementById('navbar');
    if (!navbar) return;

    var ticking = false;
    var updateNavbar = function () {
      var scrollY = window.pageYOffset || document.documentElement.scrollTop;
      navbar.classList.toggle('nav-scrolled', scrollY > 35);
      ticking = false;
    };

    window.addEventListener('scroll', function () {
      if (!ticking) {
        window.requestAnimationFrame(updateNavbar);
        ticking = true;
      }
    }, { passive: true });

    updateNavbar();
  }

  // ─── 8. GSAP LUXURY MICRO-INTERACTIONS (120FPS LERP DAMPED) ────────────────
  function initGsapEnhancements() {
    if (typeof gsap === 'undefined' || isReducedMotion) return;

    // Hero entrance timeline
    try {
      var tl = gsap.timeline({ delay: 0.04 });
      tl.fromTo('.hero-tag',
        { opacity: 0, y: 16 },
        { opacity: 1, y: 0, duration: 0.52, ease: 'power2.out' }
      )
      .fromTo('.hero-h1 span',
        { opacity: 0, y: 30 },
        { opacity: 1, y: 0, duration: 0.62, stagger: 0.08, ease: 'power2.out' },
        '-=0.22'
      )
      .fromTo('.hero-desc',
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 0.52, ease: 'power2.out' },
        '-=0.28'
      )
      .fromTo('.hero-cta a',
        { opacity: 0, y: 15 },
        { opacity: 1, y: 0, duration: 0.48, stagger: 0.06, ease: 'power2.out' },
        '-=0.22'
      );
    } catch (e) {}

    // Number counter animation with easing
    try {
      var counters = document.querySelectorAll('.hero-trust .text-gold');
      counters.forEach(function (counter) {
        var text = counter.textContent;
        var num = parseFloat(text.replace(/[^0-9.]/g, ''));
        var suffix = text.replace(/[0-9.]/g, '');
        if (isNaN(num)) return;

        gsap.fromTo({ val: 0 }, { val: num }, {
          duration: 1.5,
          ease: 'power2.out',
          delay: 0.35,
          onUpdate: function () {
            var v = Math.round(this.targets()[0].val);
            counter.textContent = v + suffix;
          },
        });
      });
    } catch (e) {}

    // 3D Magnetic Perspective Tilt (RAF Damped Lerp)
    if (!isTouchDevice) {
      document.querySelectorAll('.service-card, .tilt-card').forEach(function (card) {
        var currentX = 0, currentY = 0;
        var targetX = 0, targetY = 0;
        var isHovered = false;
        var rafTilt = null;

        function tiltLoop() {
          if (!isHovered && Math.abs(currentX) < 0.05 && Math.abs(currentY) < 0.05) {
            card.style.transform = '';
            rafTilt = null;
            return;
          }
          currentX += (targetX - currentX) * 0.14;
          currentY += (targetY - currentY) * 0.14;
          card.style.transform = 'perspective(900px) rotateX(' + currentY.toFixed(2) + 'deg) rotateY(' + currentX.toFixed(2) + 'deg)';
          rafTilt = requestAnimationFrame(tiltLoop);
        }

        card.addEventListener('mousemove', function (e) {
          isHovered = true;
          var rect = card.getBoundingClientRect();
          targetX = ((e.clientX - rect.left) / rect.width - 0.5) * 7;
          targetY = ((e.clientY - rect.top) / rect.height - 0.5) * -7;
          if (!rafTilt) rafTilt = requestAnimationFrame(tiltLoop);
        }, { passive: true });

        card.addEventListener('mouseleave', function () {
          isHovered = false;
          targetX = 0;
          targetY = 0;
        });
      });
    }
  }

  // ─── 9. MASTER INITIALIZATION ──────────────────────────────────────────────
  function initAll() {
    initPageTransitions();
    initLenis();
    initReveals();
    initUniversalBeforeAfter();
    initSmoothAnchorScroll();
    initNavbarScroll();
    initGsapEnhancements();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }

  window.addEventListener('load', function () {
    if (lenisInstance) lenisInstance.resize();
    initReveals();
    initUniversalBeforeAfter();
    finishTopLoader();
  });

  // Global exposure for dynamic components (modals, tabs, AJAX)
  window.initEstateHDR120Hz = initAll;
  window.initEstateHDRSliders = initUniversalBeforeAfter;
})();
