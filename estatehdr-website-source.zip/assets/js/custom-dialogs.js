/**
 * Estate HDR — Global Custom Dialog & Toast Engine
 * Replaces all native browser alert(), confirm(), prompt() dialogs
 * with custom sleek dark & gold themed Estate HDR modals and toast alerts.
 */

(function() {
  'use strict';

  // Inject Custom Dialog & Toast Styles
  const style = document.createElement('style');
  style.id = 'estate-dialog-styles';
  style.textContent = `
    .estate-dialog-backdrop {
      position: fixed;
      inset: 0;
      background: rgba(5, 5, 8, 0.82);
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      z-index: 999999;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 1.25rem;
      opacity: 0;
      visibility: hidden;
      transition: opacity 0.22s ease, visibility 0.22s ease;
    }
    .estate-dialog-backdrop.estate-active {
      opacity: 1;
      visibility: visible;
    }
    .estate-dialog-modal {
      background: #111118;
      border: 1px solid #C9A84C;
      border-radius: 1.25rem;
      width: 100%;
      max-width: 440px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.9), 0 0 25px rgba(201, 168, 76, 0.2);
      transform: scale(0.92) translateY(10px);
      transition: transform 0.22s cubic-bezier(0.16, 1, 0.3, 1);
      overflow: hidden;
      font-family: 'Inter', system-ui, -apple-system, sans-serif;
      color: #fff;
    }
    .estate-dialog-backdrop.estate-active .estate-dialog-modal {
      transform: scale(1) translateY(0);
    }
    .estate-toast-container {
      position: fixed;
      top: 1.5rem;
      right: 1.5rem;
      z-index: 9999999;
      display: flex;
      flex-direction: column;
      gap: 0.75rem;
      pointer-events: none;
      max-width: 380px;
      width: 100%;
    }
    .estate-toast {
      pointer-events: auto;
      background: #111118;
      border: 1px solid #1E1E2E;
      border-radius: 1rem;
      padding: 0.9rem 1.15rem;
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.7), 0 0 15px rgba(201, 168, 76, 0.15);
      display: flex;
      align-items: center;
      gap: 0.75rem;
      font-size: 0.8125rem;
      color: #F1F5F9;
      transform: translateX(110%);
      opacity: 0;
      transition: transform 0.28s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.28s ease;
    }
    .estate-toast.estate-toast-show {
      transform: translateX(0);
      opacity: 1;
    }
    .estate-toast.estate-toast-success { border-color: rgba(201, 168, 76, 0.5); }
    .estate-toast.estate-toast-error { border-color: rgba(239, 68, 68, 0.5); }
    .estate-toast.estate-toast-warning { border-color: rgba(245, 158, 11, 0.5); }
    .estate-toast.estate-toast-info { border-color: rgba(59, 130, 246, 0.5); }
  `;
  if (!document.getElementById('estate-dialog-styles')) {
    document.head.appendChild(style);
  }

  // Master EstateDialog Object
  window.EstateDialog = {
    // 1. Sleek Floating Toast Notification
    toast: function(message, type = 'success', duration = 3500) {
      let container = document.getElementById('estateToastContainer');
      if (!container) {
        container = document.createElement('div');
        container.id = 'estateToastContainer';
        container.className = 'estate-toast-container';
        document.body.appendChild(container);
      }

      const icons = {
        success: '✓',
        error: '✕',
        warning: '⚠️',
        info: 'ℹ️'
      };
      const icon = icons[type] || '✓';

      const toast = document.createElement('div');
      toast.className = `estate-toast estate-toast-${type}`;
      toast.innerHTML = `
        <span style="font-size:1.1rem;flex-shrink:0;font-weight:900;">${icon}</span>
        <span style="flex:1;line-height:1.4;font-weight:600;">${this.escapeHtml(message)}</span>
        <button type="button" onclick="this.parentElement.remove()" style="background:none;border:none;color:#94A3B8;cursor:pointer;font-size:0.85rem;padding:0 0 0 0.5rem;line-height:1;" title="Dismiss">✕</button>
      `;
      container.appendChild(toast);

      requestAnimationFrame(() => {
        toast.classList.add('estate-toast-show');
      });

      setTimeout(() => {
        toast.classList.remove('estate-toast-show');
        setTimeout(() => toast.remove(), 300);
      }, duration);
    },

    // 2. Custom Alert Modal
    alert: function(message, title = 'Notification', icon = '✨') {
      return new Promise((resolve) => {
        this.renderModal({
          title: title,
          message: message,
          icon: icon,
          showCancel: false,
          confirmText: 'Got It',
          onConfirm: () => resolve(true)
        });
      });
    },

    // 3. Custom Confirm Modal
    confirm: function(message, title = 'Confirm Action', options = {}) {
      return new Promise((resolve) => {
        this.renderModal({
          title: title,
          message: message,
          icon: options.icon || '⚠️',
          showCancel: true,
          cancelText: options.cancelText || 'Cancel',
          confirmText: options.confirmText || 'Confirm & Continue',
          danger: options.danger !== false,
          onConfirm: () => resolve(true),
          onCancel: () => resolve(false)
        });
      });
    },

    // 4. Custom Prompt Modal
    prompt: function(message, defaultValue = '', title = 'Input Required') {
      return new Promise((resolve) => {
        this.renderModal({
          title: title,
          message: message,
          icon: '✏️',
          showInput: true,
          defaultValue: defaultValue,
          showCancel: true,
          cancelText: 'Cancel',
          confirmText: 'Submit',
          onConfirm: (val) => resolve(val),
          onCancel: () => resolve(null)
        });
      });
    },

    // Internal Modal Renderer
    renderModal: function(opts) {
      let backdrop = document.getElementById('estateDialogBackdrop');
      if (!backdrop) {
        backdrop = document.createElement('div');
        backdrop.id = 'estateDialogBackdrop';
        backdrop.className = 'estate-dialog-backdrop';
        document.body.appendChild(backdrop);
      }

      const inputHtml = opts.showInput ? `
        <div style="margin-top:1rem;">
          <input type="text" id="estateDialogInput" value="${this.escapeHtml(opts.defaultValue || '')}" 
                 style="width:100%;padding:0.65rem 0.9rem;border-radius:0.75rem;background:#07070B;border:1px solid #1E1E2E;color:#fff;font-size:0.875rem;outline:none;box-sizing:border-box;"
                 onfocus="this.style.borderColor='#C9A84C'" onblur="this.style.borderColor='#1E1E2E'">
        </div>
      ` : '';

      const cancelBtn = opts.showCancel ? `
        <button type="button" id="estateDialogCancelBtn" 
                style="padding:0.6rem 1.25rem;border-radius:0.75rem;background:#161622;border:1px solid #2A2A3A;color:#94A3B8;font-size:0.8125rem;font-weight:700;cursor:pointer;transition:all 0.15s;">
          ${this.escapeHtml(opts.cancelText || 'Cancel')}
        </button>
      ` : '';

      const confirmBtnStyle = opts.danger ? 
        'background:#EF4444;color:#fff;border:none;' : 
        'background:#C9A84C;color:#0A0A0F;border:none;';

      backdrop.innerHTML = `
        <div class="estate-dialog-modal">
          <div style="padding:1.5rem 1.5rem 1.25rem;display:flex;align-items:flex-start;gap:1rem;">
            <div style="width:2.75rem;height:2.75rem;border-radius:0.875rem;background:#161622;border:1px solid rgba(201,168,76,0.3);display:flex;align-items:center;justify-content:center;font-size:1.35rem;flex-shrink:0;">
              ${opts.icon || '✨'}
            </div>
            <div style="flex:1;">
              <h3 style="margin:0 0 0.35rem;font-size:1rem;font-weight:800;color:#fff;">${this.escapeHtml(opts.title || 'Notification')}</h3>
              <div style="font-size:0.8125rem;color:#94A3B8;line-height:1.5;">${opts.message}</div>
              ${inputHtml}
            </div>
          </div>
          <div style="padding:0.9rem 1.5rem;background:#0A0A0F;border-top:1px solid #1E1E2E;display:flex;justify-content:flex-end;gap:0.75rem;">
            ${cancelBtn}
            <button type="button" id="estateDialogConfirmBtn" 
                    style="padding:0.6rem 1.35rem;border-radius:0.75rem;font-size:0.8125rem;font-weight:800;cursor:pointer;box-shadow:0 0 15px rgba(201,168,76,0.25);transition:all 0.15s;${confirmBtnStyle}">
              ${this.escapeHtml(opts.confirmText || 'OK')}
            </button>
          </div>
        </div>
      `;

      requestAnimationFrame(() => {
        backdrop.classList.add('estate-active');
        const input = document.getElementById('estateDialogInput');
        if (input) {
          input.focus();
          input.select();
        }
      });

      const closeModal = () => {
        backdrop.classList.remove('estate-active');
      };

      const confirmBtn = document.getElementById('estateDialogConfirmBtn');
      const cancelBtnElem = document.getElementById('estateDialogCancelBtn');

      if (confirmBtn) {
        confirmBtn.onclick = () => {
          closeModal();
          const input = document.getElementById('estateDialogInput');
          const val = input ? input.value : true;
          if (opts.onConfirm) opts.onConfirm(val);
        };
      }

      if (cancelBtnElem) {
        cancelBtnElem.onclick = () => {
          closeModal();
          if (opts.onCancel) opts.onCancel();
        };
      }

      backdrop.onclick = (e) => {
        if (e.target === backdrop) {
          closeModal();
          if (opts.onCancel) opts.onCancel();
        }
      };
    },

    escapeHtml: function(text) {
      if (!text) return '';
      return String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    }
  };

  // Override standard window.alert & window.confirm to eliminate Chrome native popups entirely
  window.alert = function(msg) {
    if (!msg) return;
    const s = String(msg).toLowerCase();
    if (s.includes('copied') || s.startsWith('✓') || s.includes('success') || s.includes('cleaned') || s.includes('saved')) {
      window.EstateDialog.toast(msg, 'success');
    } else if (s.includes('error') || s.includes('failed') || s.includes('warning') || s.startsWith('✕')) {
      window.EstateDialog.toast(msg, 'error');
    } else {
      window.EstateDialog.toast(msg, 'info');
    }
  };

  window.confirm = function(msg) {
    console.warn('[EstateDialog] Blocked native browser confirm. Message:', msg);
    window.EstateDialog.confirm(msg, 'Please Confirm');
    return false;
  };

  // Auto-convert any legacy inline onsubmit="return confirm(...)" / onclick="return confirm(...)"
  function sanitizeLegacyConfirms() {
    document.querySelectorAll('form[onsubmit*="confirm("], button[onclick*="confirm("], a[onclick*="confirm("]').forEach(el => {
      const isForm = el.tagName === 'FORM';
      const attr = isForm ? 'onsubmit' : 'onclick';
      const raw = el.getAttribute(attr) || '';
      const match = raw.match(/confirm\(\s*['"](.*?)['"]\s*\)/);
      if (match && match[1]) {
        el.removeAttribute(attr);
        el.setAttribute('data-confirm', match[1]);
        if (raw.toLowerCase().includes('delete') || raw.toLowerCase().includes('remove') || raw.toLowerCase().includes('purge')) {
          el.setAttribute('data-confirm-danger', 'true');
        }
      }
    });
  }

  // Helper to safely submit a form element avoiding name="submit" collisions
  function safeSubmitForm(form) {
    if (!form) return;
    try {
      HTMLFormElement.prototype.submit.call(form);
    } catch (e) {
      form.submit();
    }
  }

  // Intercept data-confirm clicks across the website
  document.addEventListener('click', function(e) {
    const confirmEl = e.target.closest('[data-confirm]');
    if (!confirmEl) return;

    let formToSubmit = null;
    let buttonToTrigger = null;

    if (confirmEl.tagName === 'FORM') {
      const submitBtn = e.target.closest('button[type="submit"], input[type="submit"], button:not([type])');
      if (!submitBtn) {
        return;
      }
      formToSubmit = confirmEl;
      buttonToTrigger = submitBtn;
    } else if (confirmEl.tagName === 'BUTTON' || confirmEl.tagName === 'INPUT') {
      if (confirmEl.form) {
        formToSubmit = confirmEl.form;
        buttonToTrigger = confirmEl;
      }
    }

    if (confirmEl._isConfirmed) {
      confirmEl._isConfirmed = false;
      return;
    }

    e.preventDefault();
    e.stopImmediatePropagation();

    const msg = confirmEl.getAttribute('data-confirm');
    const title = confirmEl.getAttribute('data-confirm-title') || 'Please Confirm';
    const icon = confirmEl.getAttribute('data-confirm-icon') || '⚠️';
    const confirmText = confirmEl.getAttribute('data-confirm-btn') || 'Confirm & Continue';
    const danger = confirmEl.getAttribute('data-confirm-danger') !== 'false';

    window.EstateDialog.confirm(msg, title, { icon, confirmText, danger }).then(confirmed => {
      if (confirmed) {
        confirmEl._isConfirmed = true;
        if (formToSubmit) {
          formToSubmit._isConfirmed = true;
          if (buttonToTrigger && buttonToTrigger.name) {
            let hidden = formToSubmit.querySelector(`input[type="hidden"][name="${buttonToTrigger.name}"]`);
            if (!hidden) {
              hidden = document.createElement('input');
              hidden.type = 'hidden';
              hidden.name = buttonToTrigger.name;
              formToSubmit.appendChild(hidden);
            }
            hidden.value = buttonToTrigger.value || '';
          }
          safeSubmitForm(formToSubmit);
        } else if (confirmEl.tagName === 'A') {
          window.location.href = confirmEl.href;
        } else {
          confirmEl.click();
        }
      }
    });
  }, true);

  // Intercept form submissions with data-confirm across the website
  document.addEventListener('submit', function(e) {
    const form = e.target;
    if (form && form.hasAttribute('data-confirm')) {
      if (form._isConfirmed) {
        form._isConfirmed = false;
        return;
      }
      e.preventDefault();
      e.stopImmediatePropagation();
      const msg = form.getAttribute('data-confirm');
      const title = form.getAttribute('data-confirm-title') || 'Please Confirm';
      const icon = form.getAttribute('data-confirm-icon') || '⚠️';
      const confirmText = form.getAttribute('data-confirm-btn') || 'Confirm & Continue';
      const danger = form.getAttribute('data-confirm-danger') !== 'false';

      window.EstateDialog.confirm(msg, title, { icon, confirmText, danger }).then(confirmed => {
        if (confirmed) {
          form._isConfirmed = true;
          safeSubmitForm(form);
        }
      });
    }
  }, true);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', sanitizeLegacyConfirms);
  } else {
    sanitizeLegacyConfirms();
  }

})();