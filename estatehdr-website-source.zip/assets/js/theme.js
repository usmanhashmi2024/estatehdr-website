/**
 * Estate HDR — Theme Engine (Permanent Luxury Dark Mode)
 */
(function() {
  document.documentElement.classList.remove('light');
  document.documentElement.classList.add('dark');
  try {
    localStorage.setItem('ehdr_theme', 'dark');
  } catch (e) {}
})();
