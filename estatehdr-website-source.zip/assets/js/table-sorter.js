/**
 * Estate HDR — Universal Dynamic Table Sorter Engine
 * Automatically attaches interactive sorting to all .dashboard-table headers across the CRM
 */
document.addEventListener('DOMContentLoaded', () => {
  initTableSorters();
});

function initTableSorters() {
  const tables = document.querySelectorAll('table.dashboard-table, table[data-sortable="true"]');
  
  tables.forEach((table) => {
    const thead = table.querySelector('thead');
    const tbody = table.querySelector('tbody');
    if (!thead || !tbody) return;

    const headers = thead.querySelectorAll('th');
    headers.forEach((th, colIdx) => {
      // Don't add sorter to 'Action' columns
      const text = th.innerText.trim().toLowerCase();
      if (text === 'action' || text === 'actions' || text === '') return;

      th.style.cursor = 'pointer';
      th.style.userSelect = 'none';
      th.classList.add('sortable-th');

      // Append sort indicator icon if not already present
      if (!th.querySelector('.sort-icon')) {
        const iconSpan = document.createElement('span');
        iconSpan.className = 'sort-icon ml-1.5 inline-block text-gray-500 text-[10px] transition-transform duration-200';
        iconSpan.innerHTML = '↕';
        th.appendChild(iconSpan);
      }

      th.addEventListener('click', () => {
        const currentOrder = th.getAttribute('data-sort-order');
        const newOrder = currentOrder === 'asc' ? 'desc' : 'asc';

        // Reset all other headers in this table
        headers.forEach(h => {
          h.removeAttribute('data-sort-order');
          h.classList.remove('text-gold', 'font-black');
          const ic = h.querySelector('.sort-icon');
          if (ic) {
            ic.innerHTML = '↕';
            ic.className = 'sort-icon ml-1.5 inline-block text-gray-500 text-[10px]';
          }
        });

        // Set active header
        th.setAttribute('data-sort-order', newOrder);
        th.classList.add('text-gold', 'font-black');
        const activeIcon = th.querySelector('.sort-icon');
        if (activeIcon) {
          activeIcon.innerHTML = newOrder === 'asc' ? '▲' : '▼';
          activeIcon.className = 'sort-icon ml-1.5 inline-block text-gold text-[10px] font-black';
        }

        // Sort table rows
        sortTableRows(tbody, colIdx, newOrder);
      });
    });
  });
}

function sortTableRows(tbody, colIdx, order) {
  const rows = Array.from(tbody.querySelectorAll('tr'));
  if (rows.length <= 1) return;

  rows.sort((rowA, rowB) => {
    const cellA = rowA.children[colIdx];
    const cellB = rowB.children[colIdx];
    if (!cellA || !cellB) return 0;

    let valA = cellA.innerText.trim();
    let valB = cellB.innerText.trim();

    // Check if numeric or currency
    const cleanNumA = valA.replace(/[^0-9.-]/g, '');
    const cleanNumB = valB.replace(/[^0-9.-]/g, '');
    const isNumA = cleanNumA !== '' && !isNaN(cleanNumA);
    const isNumB = cleanNumB !== '' && !isNaN(cleanNumB);

    if (isNumA && isNumB && !valA.includes(':') && !valA.includes('-') && !valA.toLowerCase().includes('aug') && !valA.toLowerCase().includes('sep')) {
      const numA = parseFloat(cleanNumA);
      const numB = parseFloat(cleanNumB);
      return order === 'asc' ? (numA - numB) : (numB - numA);
    }

    // Check if date or deadline (e.g. Aug 23, 18:00, 2026-08-22, etc.)
    const dateA = Date.parse(valA.replace(/(\d{1,2}):(\d{2})/, '$1:$2:00'));
    const dateB = Date.parse(valB.replace(/(\d{1,2}):(\d{2})/, '$1:$2:00'));
    if (!isNaN(dateA) && !isNaN(dateB)) {
      return order === 'asc' ? (dateA - dateB) : (dateB - dateA);
    }

    // Standard string alphabetical collation
    return order === 'asc' 
      ? valA.localeCompare(valB, undefined, { numeric: true, sensitivity: 'base' })
      : valB.localeCompare(valA, undefined, { numeric: true, sensitivity: 'base' });
  });

  // Re-append sorted rows to tbody
  rows.forEach(r => tbody.appendChild(r));
}

window.initTableSorters = initTableSorters;
