
/**
 * Estate HDR — Three.js Hero Scene
 * Procedural 3D scene with floating house geometry, particle field,
 * and scroll-driven day→dusk lighting transition.
 */

(function () {
  'use strict';

  const canvas = document.getElementById('heroCanvas');
  if (!canvas || typeof THREE === 'undefined') return;

  // ── Renderer ──────────────────────────────────────
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    alpha: true,
    powerPreference: 'high-performance',
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(canvas.clientWidth, canvas.clientHeight);
  renderer.outputEncoding = THREE.sRGBEncoding;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.2;

  // ── Scene & Camera ────────────────────────────────
  const scene  = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(60, canvas.clientWidth / canvas.clientHeight, 0.1, 200);
  camera.position.set(0, 2, 14);

  // ── Fog ────────────────────────────────────────────
  scene.fog = new THREE.FogExp2(0x0A0A0F, 0.035);

  // ── Lights ────────────────────────────────────────
  const ambientLight = new THREE.AmbientLight(0xffeedd, 0.4);
  scene.add(ambientLight);

  const sunLight = new THREE.DirectionalLight(0xffd700, 1.8);
  sunLight.position.set(8, 10, 6);
  scene.add(sunLight);

  const fillLight = new THREE.PointLight(0xC9A84C, 1.2, 30);
  fillLight.position.set(-6, 3, 4);
  scene.add(fillLight);

  const rimLight = new THREE.PointLight(0x4444ff, 0.5, 20);
  rimLight.position.set(0, 8, -8);
  scene.add(rimLight);

  // ── Procedural House ──────────────────────────────
  const houseGroup = new THREE.Group();
  scene.add(houseGroup);

  // Body
  const bodyGeo = new THREE.BoxGeometry(3, 2.2, 2.5);
  const bodyMat = new THREE.MeshStandardMaterial({
    color: 0x1a1a2e,
    metalness: 0.1,
    roughness: 0.8,
    emissive: 0x0a0a1a,
    emissiveIntensity: 0.3,
  });
  const body = new THREE.Mesh(bodyGeo, bodyMat);
  body.position.y = 0;
  houseGroup.add(body);

  // Roof (prism shape via CylinderGeometry)
  const roofGeo = new THREE.CylinderGeometry(0, 2.2, 1.5, 4, 1);
  const roofMat = new THREE.MeshStandardMaterial({
    color: 0x8B4513,
    metalness: 0.0,
    roughness: 0.9,
    emissive: 0x3a1a00,
    emissiveIntensity: 0.2,
  });
  const roof = new THREE.Mesh(roofGeo, roofMat);
  roof.position.y = 1.85;
  roof.rotation.y = Math.PI / 4;
  houseGroup.add(roof);

  // Windows (glowing planes)
  const winMat = new THREE.MeshStandardMaterial({
    color: 0xfff5cc,
    emissive: 0xffcc44,
    emissiveIntensity: 1.5,
    metalness: 0.0,
    roughness: 0.1,
  });
  const winGeo = new THREE.PlaneGeometry(0.55, 0.45);
  const winPositions = [
    [-0.85, 0.2, 1.26], [0.85, 0.2, 1.26],
    [-0.85, 0.2, -1.26], [0.85, 0.2, -1.26],
  ];
  winPositions.forEach(([x, y, z]) => {
    const win = new THREE.Mesh(winGeo, winMat);
    win.position.set(x, y, z);
    if (z < 0) win.rotation.y = Math.PI;
    houseGroup.add(win);
  });

  // Door
  const doorGeo = new THREE.PlaneGeometry(0.6, 0.9);
  const doorMat = new THREE.MeshStandardMaterial({
    color: 0x8B4513,
    emissive: 0x3a1500,
    emissiveIntensity: 0.3,
  });
  const door = new THREE.Mesh(doorGeo, doorMat);
  door.position.set(0, -0.65, 1.27);
  houseGroup.add(door);

  // Chimney
  const chimneyGeo = new THREE.BoxGeometry(0.4, 0.8, 0.4);
  const chimney    = new THREE.Mesh(chimneyGeo, bodyMat);
  chimney.position.set(0.9, 2.2, 0);
  houseGroup.add(chimney);

  houseGroup.position.set(0, -0.5, 0);
  houseGroup.rotation.y = -0.4;

  // ── Ground Plane ──────────────────────────────────
  const groundGeo = new THREE.PlaneGeometry(40, 40);
  const groundMat = new THREE.MeshStandardMaterial({
    color: 0x0a1020,
    metalness: 0.0,
    roughness: 1.0,
  });
  const ground = new THREE.Mesh(groundGeo, groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -1.6;
  scene.add(ground);

  // ── Floating Particles ────────────────────────────
  const particleCount = 600;
  const positions     = new Float32Array(particleCount * 3);
  for (let i = 0; i < particleCount; i++) {
    positions[i * 3]     = (Math.random() - 0.5) * 40;
    positions[i * 3 + 1] = (Math.random() - 0.5) * 20;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 30;
  }
  const particleGeo = new THREE.BufferGeometry();
  particleGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const particleMat = new THREE.PointsMaterial({
    color: 0xC9A84C,
    size: 0.06,
    transparent: true,
    opacity: 0.5,
    sizeAttenuation: true,
  });
  const particles = new THREE.Points(particleGeo, particleMat);
  scene.add(particles);

  // ── Small decorative spheres ──────────────────────
  const sphereGeo = new THREE.SphereGeometry(0.08, 8, 8);
  const sphereMat = new THREE.MeshStandardMaterial({
    color: 0xC9A84C,
    emissive: 0xC9A84C,
    emissiveIntensity: 0.8,
    metalness: 1.0,
    roughness: 0.1,
  });
  for (let i = 0; i < 12; i++) {
    const s = new THREE.Mesh(sphereGeo, sphereMat);
    s.position.set(
      (Math.random() - 0.5) * 12,
      (Math.random() - 0.5) * 6,
      (Math.random() - 0.5) * 8
    );
    scene.add(s);
  }

  // ── Mouse parallax ────────────────────────────────
  let mouseX = 0, mouseY = 0;
  let targetX = 0, targetY = 0;
  document.addEventListener('mousemove', (e) => {
    mouseX = (e.clientX / window.innerWidth - 0.5) * 2;
    mouseY = (e.clientY / window.innerHeight - 0.5) * 2;
  });

  // ── Scroll-driven dusk transition ─────────────────
  let scrollProgress = 0;
  window.addEventListener('scroll', () => {
    const hero = document.getElementById('hero');
    if (!hero) return;
    const h = hero.clientHeight;
    scrollProgress = Math.min(window.scrollY / (h * 0.8), 1);
  }, { passive: true });

  // Interpolate colors: day (warm gold) → dusk (deep purple-blue)
  const dayAmbient   = new THREE.Color(0xffeedd);
  const duskAmbient  = new THREE.Color(0x1a0a2e);
  const daySun       = new THREE.Color(0xffd700);
  const duskSun      = new THREE.Color(0xff6622);
  const tempColor    = new THREE.Color();

  // ── Clock ─────────────────────────────────────────
  const clock = new THREE.Clock();

  // ── Render Loop ───────────────────────────────────
  function animate() {
    requestAnimationFrame(animate);
    const t = clock.getElapsedTime();

    // Smooth mouse follow
    targetX += (mouseX - targetX) * 0.04;
    targetY += (mouseY - targetY) * 0.04;

    // Camera parallax
    camera.position.x = targetX * 1.5;
    camera.position.y = 2 - targetY * 0.8;
    camera.lookAt(0, 0.5, 0);

    // House gentle rotation + bob
    houseGroup.rotation.y = -0.4 + targetX * 0.15 + Math.sin(t * 0.3) * 0.04;
    houseGroup.position.y = -0.5 + Math.sin(t * 0.5) * 0.08;

    // Particle drift
    particles.rotation.y = t * 0.015;
    particles.rotation.x = t * 0.005;

    // Scroll-driven color shift
    tempColor.lerpColors(dayAmbient, duskAmbient, scrollProgress);
    ambientLight.color.copy(tempColor);
    tempColor.lerpColors(daySun, duskSun, scrollProgress);
    sunLight.color.copy(tempColor);
    ambientLight.intensity = 0.4 + scrollProgress * 0.4;
    fillLight.intensity    = 1.2 + scrollProgress * 1.5;
    scene.fog.color.lerpColors(new THREE.Color(0x0A0A0F), new THREE.Color(0x080010), scrollProgress);

    renderer.render(scene, camera);
  }

  // ── Resize ────────────────────────────────────────
  function onResize() {
    const w = window.innerWidth;
    const h = window.innerHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
  }
  window.addEventListener('resize', onResize, { passive: true });
  onResize();

  animate();
})();
