<?php
/**
 * Estate HDR — Public Client Invoice View & Payment Gateway
 * Displays pixel-perfect A4 invoice matching the official Estate HDR corporate letterhead.
 */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';

ehdr_rate_limit('api_default');

$invId = \EstateHDR\Security\Validator::sanitizeString(trim($_GET['id'] ?? ''), 50);
if (empty($invId)) {
    http_response_code(404);
    echo '<div style="font-family:sans-serif; text-align:center; padding:50px;"><h2>Invoice Not Found</h2><p>Please check the link provided.</p></div>';
    exit;
}

$invoicesFile = DATA_PATH . 'invoices.json';
$invoices = file_exists($invoicesFile) ? (json_decode(file_get_contents($invoicesFile), true) ?: []) : [];
$currentInvoice = null;

foreach ($invoices as $inv) {
    if (($inv['id'] ?? '') === $invId || ($inv['invoice_number'] ?? '') === $invId) {
        $currentInvoice = $inv;
        break;
    }
}

if (!$currentInvoice) {
    http_response_code(404);
    echo '<div style="font-family:sans-serif; text-align:center; padding:50px;"><h2>Invoice ' . htmlspecialchars($invId) . ' Not Found</h2><p>Please contact info@estatehdr.com for assistance.</p></div>';
    exit;
}

$curr = $currentInvoice['currency'] ?? '$';
$totalDue = number_format((float)($currentInvoice['total'] ?? 0), 2);
$subtotal = number_format((float)($currentInvoice['subtotal'] ?? 0), 2);
$tax = number_format((float)($currentInvoice['tax'] ?? 0), 2);
$payoneerLink = trim($currentInvoice['payoneer_link'] ?? '');
$refNumber = $currentInvoice['ref_number'] ?? ('REF: EH-INV-' . date('Ym') . '-C9D2E9');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Official Invoice <?= htmlspecialchars($currentInvoice['invoice_number'] ?? $invId) ?> — Estate HDR</title>
<link rel="icon" type="image/png" href="/assets/images/favicon.png">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<style nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
  body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; background-color: #0c0d14; color: #111827; }
  .doc-sheet {
    background: #ffffff;
    width: 100%;
    max-width: 850px;
    margin: 30px auto;
    border-radius: 16px;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
    padding: 45px 55px;
    position: relative;
    overflow: hidden;
  }
  .doc-watermark {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%) rotate(-25deg);
    opacity: 0.07;
    pointer-events: none;
    z-index: 1;
    width: 550px;
    text-align: center;
    user-select: none;
  }
  .doc-content {
    position: relative;
    z-index: 10;
  }
  @media print {
    body { background: #ffffff !important; margin: 0 !important; padding: 0 !important; font-size: 11pt !important; }
    .no-print { display: none !important; }
    .doc-sheet { box-shadow: none !important; border: none !important; margin: 0 !important; padding: 8mm 12mm !important; max-width: 100% !important; border-radius: 0 !important; }
    .doc-watermark { opacity: 0.10 !important; display: flex !important; }
    @page { size: A4 portrait; margin: 8mm 10mm; }
  }
</style>
</head>
<body class="min-h-screen py-6 px-4">

<!-- Top Action Bar (Hidden on print) -->
<div class="no-print max-w-[850px] mx-auto mb-6 flex flex-wrap items-center justify-between gap-4 bg-[#161622] p-4 rounded-2xl border border-[#242438] text-white shadow-xl">
  <div class="flex items-center gap-3">
    <a href="/" class="text-xs font-bold text-gray-400 hover:text-white flex items-center gap-1.5 transition-colors">
      <span>&larr;</span> <span>Home</span>
    </a>
    <span class="text-gray-600">|</span>
    <span class="text-xs font-bold text-gray-300">Invoice: <span class="font-mono text-amber-400 font-bold"><?= htmlspecialchars($currentInvoice['invoice_number'] ?? $invId) ?></span></span>
  </div>
  <div class="flex items-center gap-3">
    <button type="button" onclick="window.print()" class="px-4 py-2 rounded-xl bg-gray-800 hover:bg-gray-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-sm">
      <span>🖨️</span> <span>Print / Save as PDF</span>
    </button>
    <?php if (!empty($payoneerLink)): ?>
    <a href="<?= htmlspecialchars($payoneerLink) ?>" target="_blank" rel="noopener noreferrer" class="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-lg hover:shadow-emerald-500/25">
      <span>💳</span> <span>Pay Online via Payoneer</span>
    </a>
    <?php endif; ?>
  </div>
</div>

<!-- ── OFFICIAL DOCUMENT SHEET (A4) ──────────────────────────────────── -->
<div class="doc-sheet">

  <!-- 15% OPACITY ESTATE HDR WATERMARK -->
  <div class="doc-watermark flex flex-col items-center justify-center">
    <img src="/assets/images/Black.png" alt="Estate HDR" class="w-60 sm:w-64 h-auto object-contain mx-auto mb-2 opacity-90" onerror="this.style.display='none'">
    <div class="text-xs font-mono tracking-widest text-black font-black uppercase">Official Verified Corporate Document</div>
  </div>

  <div class="doc-content space-y-7">
    
    <!-- ── 1. CORPORATE LETTERHEAD HEADER ──────────────────────────── -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b-2 border-[#C9A84C] pb-6">
      <div>
        <div class="flex items-center gap-3">
          <img src="/assets/images/Black.png" alt="Estate HDR" class="h-9 sm:h-10 w-auto max-w-[190px] object-contain" onerror="this.outerHTML='<span class=\'font-black text-xl text-gray-900\'>Estate <span class=\'text-[#C9A84C]\'>HDR</span></span>'">
          <span class="text-[10px] uppercase font-black tracking-widest px-2.5 py-1 rounded bg-amber-100 text-amber-900 border border-amber-300">
            Commercial Billing Division
          </span>
        </div>
        <p class="text-[11px] text-gray-800 font-mono font-bold mt-1">Premium Real Estate Photo Retouching &amp; Virtual Media SaaS</p>
        <p class="text-[10px] text-gray-500 font-mono">UK Reg: EH-789021 • London &bull; Worldwide Delivery Hubs</p>
      </div>

      <div class="text-right text-[11px] font-mono text-gray-600 space-y-0.5">
        <div class="font-bold text-gray-900"><?= htmlspecialchars($refNumber) ?></div>
        <div>Date: <strong class="text-gray-900"><?= htmlspecialchars($currentInvoice['date'] ?? date('F j, Y')) ?></strong></div>
        <div>Contact: <span class="text-gray-900">billing@estatehdr.com</span></div>
        <div>Portal: <span class="text-gray-900">www.estatehdr.com</span></div>
      </div>
    </div>

    <!-- ── 2. DOCUMENT TITLE ──────────────────────────────────────── -->
    <div class="text-center space-y-1">
      <h2 class="text-xl font-black tracking-wide text-gray-900 uppercase">OFFICIAL COMMERCIAL INVOICE</h2>
      <p class="text-xs font-mono text-gray-600">
        Invoice #: <strong class="font-bold text-gray-900 font-mono"><?= htmlspecialchars($currentInvoice['invoice_number'] ?? $invId) ?></strong>
        &bull; Due Date: <strong class="text-gray-900"><?= htmlspecialchars($currentInvoice['due_date'] ?? 'Upon Receipt') ?></strong>
        &bull; Currency: <strong>USD ($)</strong>
      </p>
    </div>

    <!-- ── 3. CLIENT INFO GRID ────────────────────────────────────── -->
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-gray-50 border border-gray-200 text-xs font-mono">
      <div><span class="text-gray-500 block">Client ID:</span><strong class="text-gray-900">CL-<?= substr(md5($currentInvoice['client_email'] ?? 'client'), 0, 4) ?></strong></div>
      <div><span class="text-gray-500 block">Client Name:</span><strong class="text-gray-900"><?= htmlspecialchars($currentInvoice['client_name'] ?? '') ?></strong></div>
      <div><span class="text-gray-500 block">Company / Agency:</span><strong class="text-gray-900"><?= htmlspecialchars($currentInvoice['client_address'] ?? 'Independent Agency') ?></strong></div>
      <div><span class="text-gray-500 block">Client Contact:</span><strong class="text-gray-900"><?= htmlspecialchars($currentInvoice['client_email'] ?? '') ?></strong></div>
    </div>

    <!-- ── 4. LINE ITEMS TABLE ────────────────────────────────────── -->
    <div class="overflow-hidden rounded-xl border border-gray-200">
      <table class="w-full text-xs text-left">
        <thead class="bg-gray-100 text-gray-700 font-bold border-b border-gray-200">
          <tr>
            <th class="p-3">SERVICES &amp; DELIVERABLES DESCRIPTION</th>
            <th class="p-3 text-center w-20">QTY</th>
            <th class="p-3 text-right w-24">RATE ($)</th>
            <th class="p-3 text-right w-28">LINE TOTAL ($)</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-100 font-mono">
          <?php 
          $items = $currentInvoice['items'] ?? [];
          if (empty($items)) {
              $items = [['description' => 'HDR Photo Editing (Professional Blending)', 'qty' => 1, 'rate' => (float)$currentInvoice['total'], 'total' => (float)$currentInvoice['total']]];
          }
          foreach ($items as $item): 
          ?>
          <tr>
            <td class="p-3 font-bold text-gray-900"><?= htmlspecialchars($item['description'] ?? 'HDR Photo Editing') ?></td>
            <td class="p-3 text-center text-gray-800"><?= htmlspecialchars($item['qty'] ?? 1) ?></td>
            <td class="p-3 text-right text-gray-800"><?= $curr ?><?= number_format((float)($item['rate'] ?? 0), 2) ?></td>
            <td class="p-3 text-right font-bold text-gray-900"><?= $curr ?><?= number_format((float)($item['total'] ?? 0), 2) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot class="bg-gray-50 border-t-2 border-gray-300 font-bold font-mono">
          <tr>
            <td class="p-3 text-gray-800" colspan="3">SUBTOTAL:</td>
            <td class="p-3 text-right text-gray-900 font-mono"><?= $curr ?><?= $subtotal ?></td>
          </tr>
          <tr>
            <td class="p-3 text-gray-800" colspan="3">TAX / VAT:</td>
            <td class="p-3 text-right text-gray-900 font-mono"><?= $curr ?><?= $tax ?></td>
          </tr>
        </tfoot>
      </table>
    </div>

    <!-- ── 5. TOTAL NET PAYABLE CARD ──────────────────────────────── -->
    <div class="p-5 rounded-2xl bg-amber-50/70 border-2 border-[#C9A84C] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
      <div>
        <span class="text-xs text-amber-900 font-bold uppercase tracking-wider">TOTAL NET INVOICE AMOUNT DUE:</span>
        <p class="text-[11px] text-gray-600 font-mono mt-0.5">Please settle upon receipt via verified official payment channels.</p>
        <?php if (!empty($payoneerLink)): ?>
        <div class="mt-3">
          <a href="<?= htmlspecialchars($payoneerLink) ?>" target="_blank" rel="noopener noreferrer" class="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs inline-flex items-center gap-2 shadow-lg transition-all">
            <span>💳</span> <span>Click Here to Pay Online via Payoneer &rarr;</span>
          </a>
        </div>
        <?php endif; ?>
      </div>
      <div class="text-right">
        <div class="text-2xl sm:text-3xl font-black text-gray-900 font-mono"><?= $curr ?><?= $totalDue ?> USD</div>
        <span class="text-[10px] font-bold text-emerald-800 uppercase px-2 py-0.5 rounded bg-emerald-100 border border-emerald-300 inline-block mt-1">
          ✓ PAYMENT PENDING / APPROVED
        </span>
      </div>
    </div>

    <!-- ── 6. PAYMENT INSTRUCTIONS BOX ────────────────────────────── -->
    <div class="p-4 rounded-xl bg-gray-50 border border-gray-200 text-xs font-mono space-y-1">
      <div class="font-bold text-gray-900 uppercase text-[11px] text-[#C9A84C]">Payment Instructions &amp; Routing</div>
      <p class="text-gray-700 leading-relaxed">
        <?= nl2br(htmlspecialchars($currentInvoice['remarks'] ?? 'Please process your payment via Payoneer. Send payment to our official account.')) ?>
      </p>
    </div>

    <!-- ── 7. OFFICIAL SIGNATURES & CORPORATE STAMP ────────────────── -->
    <div class="pt-8 border-t-2 border-gray-200 grid grid-cols-3 gap-6 text-center text-xs font-mono">
      
      <!-- Accounts / Billing Signature -->
      <div class="space-y-2">
        <div class="h-14 flex items-end justify-center">
          <span class="font-serif italic text-base text-gray-800 font-bold border-b border-gray-400 pb-1 px-4">
            Usman Nadeem
          </span>
        </div>
        <div class="font-bold text-gray-900">Head of Client Billing</div>
        <div class="text-[10px] text-gray-500">Estate HDR Finance Division</div>
      </div>

      <!-- Official Seal -->
      <div class="flex flex-col items-center justify-center">
        <div class="w-20 h-20 rounded-full border-2 border-dashed border-[#C9A84C] flex flex-col items-center justify-center p-1 text-center bg-amber-50/50">
          <span class="text-[8px] font-black text-[#C9A84C] uppercase tracking-tighter">ESTATE HDR</span>
          <span class="text-[7px] text-gray-600 font-bold">OFFICIAL SEAL</span>
          <span class="text-[6px] text-gray-400">VERIFIED</span>
        </div>
        <span class="text-[9px] text-gray-400 mt-1">Official Corporate Stamp</span>
      </div>

      <!-- Client Acknowledgment -->
      <div class="space-y-2">
        <div class="h-14 flex items-end justify-center">
          <span class="border-b border-gray-400 w-32 inline-block"></span>
        </div>
        <div class="font-bold text-gray-900"><?= htmlspecialchars($currentInvoice['client_name'] ?? 'Client') ?></div>
        <div class="text-[10px] text-gray-500">Client Signature &amp; Date</div>
      </div>

    </div>

    <div class="text-right text-[11px] font-mono text-gray-400 pt-2">
      1/1
    </div>

  </div>

</div>

</body>
</html>
