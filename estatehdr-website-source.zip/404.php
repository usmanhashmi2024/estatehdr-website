<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';

http_response_code(404);

$pageTitle = '404 — Page Not Found | Estate HDR';
$pageDesc  = 'The page you requested could not be found. Explore Estate HDR photo editing services, portfolio gallery, and real estate photography guides.';
$canonUrl  = BASE_URL . '/404.php';
$ogImage   = BASE_URL . '/assets/images/portfolio/hdr/1-after.jpg';
$robots    = 'noindex, follow';
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?></title>
<meta name="description" content="<?= htmlspecialchars($pageDesc) ?>">
<meta name="robots" content="noindex, follow">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap">
<link rel="stylesheet" href="/assets/css/app.css">
<script src="https://cdn.tailwindcss.com" defer></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
window.addEventListener('DOMContentLoaded', () => {
  if (typeof tailwind !== 'undefined') {
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: '#C9A84C',
            'gold-light': '#E2C974',
            dark: '#0A0A0F',
            'dark-card': '#111118',
            'dark-border': '#1E1E2E'
          }
        }
      }
    };
  }
});
</script>
</head>
<body class="bg-dark text-gray-200 font-sans min-h-screen flex flex-col antialiased selection:bg-gold/30 selection:text-white">

<?php require_once __DIR__ . '/includes/public-header.php'; ?>

<main class="flex-1 flex items-center justify-center px-6 py-32 sm:py-40">
  <div class="max-w-2xl mx-auto text-center space-y-8 glass-card p-10 sm:p-16 rounded-3xl border border-gold/30 bg-gradient-to-b from-[#111118] to-dark shadow-2xl">
    
    <div class="w-20 h-20 rounded-2xl bg-gold/10 border border-gold/40 text-gold flex items-center justify-center font-black text-4xl mx-auto shadow-glow font-mono">
      404
    </div>

    <div class="space-y-3">
      <h1 class="text-3xl sm:text-4xl font-black text-white uppercase tracking-tight">
        Page <span class="text-gold">Not Found</span>
      </h1>
      <p class="text-sm sm:text-base text-gray-400 max-w-md mx-auto leading-relaxed">
        The link you followed may be broken, updated, or moved to a cleaner URL. Use the quick links below to find what you need.
      </p>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-bold pt-2">
      <a href="/" class="btn-gold py-3 px-5 rounded-xl text-dark uppercase tracking-wider font-extrabold shadow-glow">
        🏠 Return Home
      </a>
      <a href="/#services" class="btn-ghost py-3 px-5 rounded-xl uppercase tracking-wider hover:border-gold">
        📸 View Services
      </a>
      <a href="/portfolio.php" class="btn-ghost py-3 px-5 rounded-xl uppercase tracking-wider hover:border-gold">
        🖼️ Interactive Portfolio
      </a>
      <a href="/blog.php" class="btn-ghost py-3 px-5 rounded-xl uppercase tracking-wider hover:border-gold">
        📖 Photography Guides
      </a>
    </div>

    <div class="pt-6 border-t border-dark-border text-xs text-gray-500">
      Need urgent editing assistance? <a href="/contact.php" class="text-gold hover:underline">Contact our 24/7 team</a> or WhatsApp <a href="<?= WHATSAPP_LINK ?>" target="_blank" class="text-emerald-400 hover:underline" rel="noopener noreferrer">+44 770 606 8176</a>.
    </div>

  </div>
</main>

<footer class="border-t border-dark-border py-8 px-6 bg-dark text-center text-xs text-gray-500">
  &copy; <?= date('Y') ?> Estate HDR. All rights reserved. Professional Real Estate Media Retouching.
</footer>

</body>
</html>