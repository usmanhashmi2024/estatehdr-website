<?php
/**
 * Estate HDR — Master Commercial Pillar Landing Page
 * URL: /real-estate-photo-editing/
 * Primary Target: "real estate photo editing", "real estate photo editing services", "professional real estate photo editing"
 */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';

$pageTitle = 'Professional Real Estate Photo Editing Services | Estate HDR';
$pageDesc  = 'Award-winning real estate photo editing services for US, UK & global photographers. Hand-blended HDR, flambient retouching, virtual staging, 12-24h turnaround.';
$canonUrl  = rtrim(BASE_URL, '/') . '/real-estate-photo-editing';
$ogImage   = rtrim(BASE_URL, '/') . '/assets/images/portfolio/hdr/1-after.jpg';

// Schema.org Structured Data
$serviceSchema = [
    '@context'    => 'https://schema.org',
    '@type'       => 'Service',
    'name'        => 'Professional Real Estate Photo Editing Services',
    'provider'    => [
        '@type'   => 'Organization',
        'name'    => 'Estate HDR',
        'url'     => BASE_URL,
        'logo'    => rtrim(BASE_URL, '/') . '/assets/images/logo.png',
        'sameAs'  => [
            FACEBOOK_LINK,
            INSTAGRAM_LINK,
            LINKEDIN_LINK
        ]
    ],
    'serviceType' => 'Real Estate Photography Post-Production',
    'areaServed'  => ['United States', 'United Kingdom', 'Canada', 'Australia', 'Worldwide'],
    'description' => $pageDesc,
    'offers'      => [
        '@type'         => 'AggregateOffer',
        'priceCurrency' => 'USD',
        'lowPrice'      => '0.60',
        'highPrice'     => '35.00',
        'offerCount'    => '10'
    ],
    'aggregateRating' => [
        '@type'       => 'AggregateRating',
        'ratingValue' => '4.99',
        'reviewCount' => '480',
        'bestRating'  => '5',
        'worstRating' => '1'
    ]
];

$faqs = [
    [
        'q' => 'What real estate photo editing services does Estate HDR offer?',
        'a' => 'We offer a complete post-production ecosystem for real estate photographers and brokerages, including manual HDR exposure blending, flambient (flash + ambient) retouching, precision window pulls, 3D virtual staging, day-to-dusk and virtual twilight conversion, sky replacement, item removal and decluttering, 2D/3D floor plans, and cinematic property video editing.'
    ],
    [
        'q' => 'What is the turnaround time for real estate photo editing orders?',
        'a' => 'Our guaranteed standard turnaround time is 12 to 24 hours. For urgent listings and high-volume partner photographers, priority rush delivery within 6 to 12 hours is also available.'
    ],
    [
        'q' => 'Why is hand-blended photo editing better than automated AI tone-mapping?',
        'a' => 'Automated AI software compresses dynamic range globally, creating radioactive greens, dark halos around window mullions, muddy shadows, and unnatural yellow wall casts. Estate HDR uses master digital retouchers who hand-blend brackets and flash frames in Photoshop, ensuring straight vertical lines, true-to-life paint colors, crystal-clear exterior window views, and 100% MLS compliance.'
    ],
    [
        'q' => 'What file formats can I upload for editing?',
        'a' => 'We accept all camera RAW formats (Canon CR2/CR3, Sony ARW, Nikon NEF, Fujifilm RAF, Panasonic RW2, Adobe DNG) as well as full-resolution JPG and TIFF files. You can submit files via our client portal or shared links from Dropbox, Google Drive, and WeTransfer.'
    ],
    [
        'q' => 'Do you provide free revisions if adjustments are needed?',
        'a' => 'Yes! We provide 100% free unlimited revisions until you are completely thrilled with the final results. You can communicate directly with your assigned retoucher bay in our dashboard.'
    ],
    [
        'q' => 'Can I test your real estate photo editing services for free?',
        'a' => 'Absolutely. We invite all new photographers and real estate agencies to test our quality with 3 free bracket sets retouched with zero obligation.'
    ]
];

$faqSchema = [
    '@context'   => 'https://schema.org',
    '@type'      => 'FAQPage',
    'mainEntity' => array_map(fn($f) => [
        '@type'          => 'Question',
        'name'           => $f['q'],
        'acceptedAnswer' => [
            '@type' => 'Answer',
            'text'  => $f['a']
        ]
    ], $faqs)
];

$breadcrumbSchema = [
    '@context'        => 'https://schema.org',
    '@type'           => 'BreadcrumbList',
    'itemListElement' => [
        [
            '@type'    => 'ListItem',
            'position' => 1,
            'name'     => 'Home',
            'item'     => rtrim(BASE_URL, '/') . '/'
        ],
        [
            '@type'    => 'ListItem',
            'position' => 2,
            'name'     => 'Real Estate Photo Editing',
            'item'     => $canonUrl
        ]
    ]
];
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?></title>
<meta name="description" content="<?= htmlspecialchars($pageDesc) ?>">
<meta name="keywords" content="real estate photo editing, real estate photo editing services, professional real estate photo editing, flambient photo editing, real estate photography retouching, HDR blending, window pull">
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?= $canonUrl ?>">

<!-- Open Graph / Social -->
<meta property="og:type"        content="website">
<meta property="og:url"         content="<?= $canonUrl ?>">
<meta property="og:title"       content="<?= htmlspecialchars($pageTitle) ?>">
<meta property="og:description" content="<?= htmlspecialchars($pageDesc) ?>">
<meta property="og:image"       content="<?= $ogImage ?>">
<meta name="twitter:card"        content="summary_large_image">
<meta name="twitter:title"       content="<?= htmlspecialchars($pageTitle) ?>">
<meta name="twitter:description" content="<?= htmlspecialchars($pageDesc) ?>">
<meta name="twitter:image"       content="<?= $ogImage ?>">

<!-- Official Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">

<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap" onload="this.onload=null;this.rel='stylesheet'">
<noscript>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap">
</noscript>

<link rel="stylesheet" href="/assets/css/bundle.css?v=<?= file_exists(ROOT_PATH . '/assets/css/bundle.css') ? filemtime(ROOT_PATH . '/assets/css/bundle.css') : time() ?>">
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">

<!-- Structured Data Schemas -->
<script type="application/ld+json" nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>"><?= json_encode($serviceSchema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?></script>
<script type="application/ld+json" nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>"><?= json_encode($faqSchema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?></script>
<script type="application/ld+json" nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>"><?= json_encode($breadcrumbSchema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?></script>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col pt-24">

<?php require_once __DIR__ . '/includes/public-header.php'; ?>

<!-- ── HERO SECTION ──────────────────────────────────────────────── -->
<section class="relative py-16 sm:py-24 border-b border-dark-border overflow-hidden bg-gradient-to-b from-[#111118]/90 via-dark to-dark">
  <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-gold/15 via-transparent to-transparent pointer-events-none"></div>

  <div class="max-w-7xl mx-auto px-6 sm:px-10 relative z-10 text-center space-y-6">
    <!-- Pillar Badge -->
    <div class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gold/10 border border-gold/30 text-gold text-xs font-black uppercase tracking-widest">
      <span>✦</span> <span>PREMIER REAL ESTATE POST-PRODUCTION BAY</span> <span>✦</span>
    </div>

    <!-- H1 Header -->
    <h1 class="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight max-w-5xl mx-auto leading-tight">
      Professional <span class="text-gradient">Real Estate Photo Editing</span> Services
    </h1>

    <!-- Subtitle -->
    <p class="text-gray-300 text-base sm:text-lg lg:text-xl max-w-3xl mx-auto font-medium leading-relaxed">
      Hand-blended HDR, flambient retouching, crisp window pulls, and 3D virtual staging engineered for professional real estate photographers, luxury brokerages, and media teams. Delivered in 12–24 hours.
    </p>

    <!-- CTAs -->
    <div class="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
      <a href="/#trial" class="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-sm uppercase tracking-wider shadow-lg hover:shadow-gold/20 transition-all hover:scale-105">
        <span>Claim 3 Free Test Photos</span>
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
      </a>
      <a href="#services-grid" class="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl bg-dark-card border border-dark-border hover:border-gold/50 text-white font-bold text-sm tracking-wide transition-all">
        <span>Explore All Services &rarr;</span>
      </a>
    </div>

    <!-- Value Stats Strip -->
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto pt-8">
      <div class="glass-card rounded-2xl p-4 border border-dark-border text-center">
        <div class="text-2xl sm:text-3xl font-black text-gold font-mono">12–24h</div>
        <div class="text-xs text-gray-300 font-bold uppercase mt-1">Guaranteed SLA Turnaround</div>
      </div>
      <div class="glass-card rounded-2xl p-4 border border-dark-border text-center">
        <div class="text-2xl sm:text-3xl font-black text-emerald-400 font-mono">100%</div>
        <div class="text-xs text-gray-300 font-bold uppercase mt-1">Hand-Blended (No AI Blur)</div>
      </div>
      <div class="glass-card rounded-2xl p-4 border border-dark-border text-center">
        <div class="text-2xl sm:text-3xl font-black text-blue-400 font-mono">4.99 ★</div>
        <div class="text-xs text-gray-300 font-bold uppercase mt-1">480+ Agency Reviews</div>
      </div>
      <div class="glass-card rounded-2xl p-4 border border-dark-border text-center">
        <div class="text-2xl sm:text-3xl font-black text-purple-400 font-mono">Free</div>
        <div class="text-xs text-gray-300 font-bold uppercase mt-1">Unlimited Revisions</div>
      </div>
    </div>
  </div>
</section>

<!-- ── MAIN BODY CONTENT ─────────────────────────────────────────── -->
<main class="max-w-7xl mx-auto px-6 sm:px-10 py-16 space-y-24 flex-1">

  <!-- ── 1. ARCHITECTURAL RETOUCHING EXCELLENCE (The Core Difference) ── -->
  <section class="space-y-8">
    <div class="text-center max-w-3xl mx-auto space-y-3">
      <div class="text-xs font-black text-gold uppercase tracking-wider">Topical Authority &amp; Quality</div>
      <h2 class="text-2xl sm:text-4xl font-black text-white uppercase tracking-tight">
        Why Top Photographers Trust Our <span class="text-gradient">Hand-Blended</span> Process
      </h2>
      <p class="text-sm sm:text-base text-gray-300 leading-relaxed font-medium">
        In high-end real estate marketing, subtle details make or break a sale. Automated filters and generic one-click apps butcher subtle room dynamics. Estate HDR combines manual multi-exposure blending with strict architectural retouching principles.
      </p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div class="glass-card rounded-2xl p-6 border border-dark-border space-y-3 hover:border-gold/40 transition-all">
        <div class="w-12 h-12 rounded-xl bg-gold/10 border border-gold/30 flex items-center justify-center text-xl text-gold">📐</div>
        <h3 class="text-lg font-bold text-white">Perfect Verticals &amp; Lens Calibration</h3>
        <p class="text-xs sm:text-sm text-gray-300 leading-relaxed">
          Wide-angle architectural lenses naturally introduce barrel distortion and tilted walls. We correct keystoning, align vertical doorframes to 90 degrees, and restore natural proportions.
        </p>
      </div>
      <div class="glass-card rounded-2xl p-6 border border-dark-border space-y-3 hover:border-gold/40 transition-all">
        <div class="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-xl text-blue-400">🪟</div>
        <h3 class="text-lg font-bold text-white">Razor-Sharp Window Pull Recovery</h3>
        <p class="text-xs sm:text-sm text-gray-300 leading-relaxed">
          Never lose a multi-million-dollar golf course or ocean view to blown highlights. We hand-mask window panes with luminosity selections, preserving glass reflections with zero halos.
        </p>
      </div>
      <div class="glass-card rounded-2xl p-6 border border-dark-border space-y-3 hover:border-gold/40 transition-all">
        <div class="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-xl text-emerald-400">⚡</div>
        <h3 class="text-lg font-bold text-white">True Paint &amp; Texture Neutrality</h3>
        <p class="text-xs sm:text-sm text-gray-300 leading-relaxed">
          Mixed indoor lighting (LED can lights, warm tungsten lamps, daylight) creates murky yellow or blue casts. We isolate wall paint and drywall to deliver clean, true-to-life neutral whites.
        </p>
      </div>
    </div>
  </section>

  <!-- ── 2. HUMAN EXPERT VS AI COMPARISON TABLE ─────────────────────── -->
  <section class="space-y-8 bg-dark-card rounded-3xl p-8 sm:p-12 border border-dark-border">
    <div class="text-center max-w-3xl mx-auto space-y-3">
      <div class="text-xs font-black text-gold uppercase tracking-wider">Comparison Matrix</div>
      <h2 class="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight">
        Estate HDR Master Retouchers <span class="text-gold">vs.</span> Automated AI Apps
      </h2>
      <p class="text-sm text-gray-300 leading-relaxed">
        See why premier architectural studios choose certified digital artists over automated AI algorithms.
      </p>
    </div>

    <div class="overflow-x-auto">
      <table class="w-full text-left text-sm border-collapse">
        <thead>
          <tr class="border-b border-dark-border text-gray-400 text-xs uppercase tracking-wider">
            <th class="py-4 px-4 font-bold">Retouching Standard</th>
            <th class="py-4 px-4 font-bold text-gold">Estate HDR (Master Human Editors)</th>
            <th class="py-4 px-4 font-bold text-gray-400">Automated AI Tools (AutoHDR/Apps)</th>
            <th class="py-4 px-4 font-bold text-gray-400">Generic Outsourcing</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-dark-border text-gray-300">
          <tr>
            <td class="py-4 px-4 font-semibold text-white">Window View Clarity</td>
            <td class="py-4 px-4 text-emerald-400 font-bold">✓ Hand-masked brackets + natural reflections</td>
            <td class="py-4 px-4 text-red-400">✗ Smudged frames &amp; dark edge halos</td>
            <td class="py-4 px-4 text-yellow-400">⚠ Inconsistent, harsh cutouts</td>
          </tr>
          <tr>
            <td class="py-4 px-4 font-semibold text-white">Perspective &amp; Straight Verticals</td>
            <td class="py-4 px-4 text-emerald-400 font-bold">✓ Exact 90° architectural keystoning</td>
            <td class="py-4 px-4 text-red-400">✗ Warped doorframes &amp; bent ceilings</td>
            <td class="py-4 px-4 text-yellow-400">⚠ Manual only when explicitly requested</td>
          </tr>
          <tr>
            <td class="py-4 px-4 font-semibold text-white">Color Cast &amp; White Balance</td>
            <td class="py-4 px-4 text-emerald-400 font-bold">✓ Neutral whites calibrated with flash layers</td>
            <td class="py-4 px-4 text-red-400">✗ Muddy yellow casts &amp; neon grass</td>
            <td class="py-4 px-4 text-yellow-400">⚠ Global sliders, inconsistent tones</td>
          </tr>
          <tr>
            <td class="py-4 px-4 font-semibold text-white">Shadow &amp; Highlight Depth</td>
            <td class="py-4 px-4 text-emerald-400 font-bold">✓ 3D volumetric depth with natural gradient</td>
            <td class="py-4 px-4 text-red-400">✗ Flat, cartoonish HDR tone-mapping</td>
            <td class="py-4 px-4 text-yellow-400">⚠ Often noisy or over-darkened</td>
          </tr>
          <tr>
            <td class="py-4 px-4 font-semibold text-white">Revisions &amp; Communication</td>
            <td class="py-4 px-4 text-emerald-400 font-bold">✓ Free unlimited revisions + direct bay chat</td>
            <td class="py-4 px-4 text-red-400">✗ Zero custom human feedback loop</td>
            <td class="py-4 px-4 text-yellow-400">⚠ Extra charges per revision round</td>
          </tr>
          <tr>
            <td class="py-4 px-4 font-semibold text-white">Turnaround Guarantee</td>
            <td class="py-4 px-4 text-emerald-400 font-bold">✓ 12–24h strict SLA with 99.8% record</td>
            <td class="py-4 px-4 text-yellow-400">⚠ Instant but requires hours of manual fixing</td>
            <td class="py-4 px-4 text-red-400">✗ 36–72 hours average delay</td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="text-center pt-2">
      <a href="/alternatives" class="inline-flex items-center gap-2 text-xs font-bold text-gold hover:underline">
        <span>Read our in-depth comparison vs BoxBrownie, AutoHDR &amp; Phixer &rarr;</span>
      </a>
    </div>
  </section>

  <!-- ── 3. CORE SERVICES GRID (Topical Authority Hub) ──────────────── -->
  <section id="services-grid" class="space-y-8">
    <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-dark-border pb-4">
      <div>
        <div class="text-xs font-black text-gold uppercase tracking-wider mb-1">Our Service Catalog</div>
        <h2 class="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight">Full Real Estate Post-Production Suite</h2>
      </div>
      <p class="text-xs text-gray-400 max-w-md font-medium">Click any service to view specialized technical specs, before/after sliders, and starting rates.</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

      <!-- 1. HDR Real Estate Photo Editing -->
      <a href="/services/hdr-photo-editing" class="glass-card rounded-2xl p-6 border border-dark-border hover:border-gold/50 flex flex-col justify-between group transition-all">
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-2xl">📸</span>
            <span class="px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-400 text-xs font-bold font-mono"><span class="line-through text-gray-400 text-[10px]">$0.80</span> From $0.60</span>
          </div>
          <h3 class="text-lg font-bold text-white group-hover:text-gold transition-colors">HDR Real Estate Photo Editing</h3>
          <p class="text-xs text-gray-300 leading-relaxed">
            Multi-exposure bracket blending with manual brushwork. Perfect contrast, natural shadows, and balanced room illumination.
          </p>
        </div>
        <div class="pt-4 flex items-center gap-2 text-xs font-bold text-gold mt-2">
          <span>Learn More</span> <span>&rarr;</span>
        </div>
      </a>

      <!-- 2. Flambient Photo Editing -->
      <a href="/services/flambient-photo-editing" class="glass-card rounded-2xl p-6 border border-gold/40 bg-gold/5 hover:border-gold flex flex-col justify-between group transition-all">
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-2xl">⚡</span>
            <span class="px-2.5 py-1 rounded-full bg-gold text-dark text-xs font-bold font-mono">From $1.00</span>
          </div>
          <h3 class="text-lg font-bold text-white group-hover:text-gold transition-colors">Flambient Photo Editing</h3>
          <p class="text-xs text-gray-300 leading-relaxed">
            Flash + ambient layering. Lock in pure white walls, eliminate tungsten tints, and highlight luxury architectural finishes.
          </p>
        </div>
        <div class="pt-4 flex items-center gap-2 text-xs font-bold text-gold mt-2">
          <span>Explore Flambient</span> <span>&rarr;</span>
        </div>
      </a>

      <!-- 3. Window Pull & Glare Recovery -->
      <a href="/services/window-pull" class="glass-card rounded-2xl p-6 border border-dark-border hover:border-gold/50 flex flex-col justify-between group transition-all">
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-2xl">🪟</span>
            <span class="px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-400 text-xs font-bold font-mono"><span class="line-through text-gray-400 text-[10px]">$0.80</span> From $0.60</span>
          </div>
          <h3 class="text-lg font-bold text-white group-hover:text-gold transition-colors">Window Pull &amp; Glare Recovery</h3>
          <p class="text-xs text-gray-300 leading-relaxed">
            Precision pen-tool masking to recover outdoor views through windows with zero edge fringing or artificial cutouts.
          </p>
        </div>
        <div class="pt-4 flex items-center gap-2 text-xs font-bold text-gold mt-2">
          <span>Learn More</span> <span>&rarr;</span>
        </div>
      </a>

      <!-- 4. 3D Virtual Staging -->
      <a href="/services/virtual-staging" class="glass-card rounded-2xl p-6 border border-dark-border hover:border-gold/50 flex flex-col justify-between group transition-all">
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-2xl">🛋️</span>
            <span class="px-2.5 py-1 rounded-full bg-gold/10 text-gold text-xs font-bold font-mono">From $8.00</span>
          </div>
          <h3 class="text-lg font-bold text-white group-hover:text-gold transition-colors">3D Virtual Staging</h3>
          <p class="text-xs text-gray-300 leading-relaxed">
            Photorealistic 3D furniture placement with accurate ray-traced shadows for vacant living rooms, master suites, and patios.
          </p>
        </div>
        <div class="pt-4 flex items-center gap-2 text-xs font-bold text-gold mt-2">
          <span>Explore Staging</span> <span>&rarr;</span>
        </div>
      </a>

      <!-- 5. Day to Dusk Conversion -->
      <a href="/services/day-to-dusk" class="glass-card rounded-2xl p-6 border border-dark-border hover:border-gold/50 flex flex-col justify-between group transition-all">
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-2xl">🌅</span>
            <span class="px-2.5 py-1 rounded-full bg-gold/10 text-gold text-xs font-bold font-mono">From $4.00</span>
          </div>
          <h3 class="text-lg font-bold text-white group-hover:text-gold transition-colors">Day to Dusk Conversion</h3>
          <p class="text-xs text-gray-300 leading-relaxed">
            Convert daytime exteriors into warm, golden sunset scenes. We digitally illuminate lamps, lanterns, and pool reflections.
          </p>
        </div>
        <div class="pt-4 flex items-center gap-2 text-xs font-bold text-gold mt-2">
          <span>Learn More</span> <span>&rarr;</span>
        </div>
      </a>

      <!-- 6. Virtual Twilight -->
      <a href="/services/virtual-twilight" class="glass-card rounded-2xl p-6 border border-dark-border hover:border-gold/50 flex flex-col justify-between group transition-all">
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-2xl">🌄</span>
            <span class="px-2.5 py-1 rounded-full bg-gold/10 text-gold text-xs font-bold font-mono">From $6.00</span>
          </div>
          <h3 class="text-lg font-bold text-white group-hover:text-gold transition-colors">Virtual Twilight</h3>
          <p class="text-xs text-gray-300 leading-relaxed">
            Command 400% more clicks with deep indigo blue-hour skies, warm interior window illumination, and garden spotlighting.
          </p>
        </div>
        <div class="pt-4 flex items-center gap-2 text-xs font-bold text-gold mt-2">
          <span>Learn More</span> <span>&rarr;</span>
        </div>
      </a>

      <!-- 7. Sky Replacement -->
      <a href="/services/sky-replacement" class="glass-card rounded-2xl p-6 border border-dark-border hover:border-gold/50 flex flex-col justify-between group transition-all">
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-2xl">☁️</span>
            <span class="px-2.5 py-1 rounded-full bg-gold/10 text-gold text-xs font-bold font-mono">From $1.00</span>
          </div>
          <h3 class="text-lg font-bold text-white group-hover:text-gold transition-colors">Sky Replacement</h3>
          <p class="text-xs text-gray-300 leading-relaxed">
            Replace overcast clouds with crisp blue skies or vibrant sunsets. Perfect foliage edge masking with water reflection sync.
          </p>
        </div>
        <div class="pt-4 flex items-center gap-2 text-xs font-bold text-gold mt-2">
          <span>Learn More</span> <span>&rarr;</span>
        </div>
      </a>

      <!-- 8. Item Removal & Decluttering -->
      <a href="/services/item-removal" class="glass-card rounded-2xl p-6 border border-dark-border hover:border-gold/50 flex flex-col justify-between group transition-all">
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-2xl">✨</span>
            <span class="px-2.5 py-1 rounded-full bg-gold/10 text-gold text-xs font-bold font-mono">From $2.00</span>
          </div>
          <h3 class="text-lg font-bold text-white group-hover:text-gold transition-colors">Item Removal &amp; Decluttering</h3>
          <p class="text-xs text-gray-300 leading-relaxed">
            Erase parked cars, trash bins, messy cords, and personal items. We rebuild underlying tile, grass, and driveway concrete.
          </p>
        </div>
        <div class="pt-4 flex items-center gap-2 text-xs font-bold text-gold mt-2">
          <span>Learn More</span> <span>&rarr;</span>
        </div>
      </a>

      <!-- 9. 2D & 3D Floor Plans -->
      <a href="/services/floor-plans" class="glass-card rounded-2xl p-6 border border-dark-border hover:border-gold/50 flex flex-col justify-between group transition-all">
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-2xl">📐</span>
            <span class="px-2.5 py-1 rounded-full bg-gold/10 text-gold text-xs font-bold font-mono">From $15.00</span>
          </div>
          <h3 class="text-lg font-bold text-white group-hover:text-gold transition-colors">2D &amp; 3D Floor Plans</h3>
          <p class="text-xs text-gray-300 leading-relaxed">
            Detailed schematic architectural floor plans with precise measurements, square footage calculations, and brokerage branding.
          </p>
        </div>
        <div class="pt-4 flex items-center gap-2 text-xs font-bold text-gold mt-2">
          <span>Learn More</span> <span>&rarr;</span>
        </div>
      </a>

      <!-- 10. Real Estate Video Editing -->
      <a href="/services/real-estate-video-editing" class="glass-card rounded-2xl p-6 border border-dark-border hover:border-gold/50 flex flex-col justify-between group transition-all">
        <div class="space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-2xl">🎬</span>
            <span class="px-2.5 py-1 rounded-full bg-gold/10 text-gold text-xs font-bold font-mono">From $25.00</span>
          </div>
          <h3 class="text-lg font-bold text-white group-hover:text-gold transition-colors">Real Estate Video Editing</h3>
          <p class="text-xs text-gray-300 leading-relaxed">
            4K cinematic property walkthroughs, Instagram/TikTok reels, drone color grading, and licensed music synchronization.
          </p>
        </div>
        <div class="pt-4 flex items-center gap-2 text-xs font-bold text-gold mt-2">
          <span>Explore Video</span> <span>&rarr;</span>
        </div>
      </a>

    </div>
  </section>

  <!-- ── 4. PRODUCTION PROCESS (How It Works) ───────────────────────── -->
  <section class="space-y-8">
    <div class="text-center max-w-3xl mx-auto space-y-3">
      <div class="text-xs font-black text-gold uppercase tracking-wider">Streamlined Workflow</div>
      <h2 class="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight">How Our 24-Hour Production Engine Operates</h2>
      <p class="text-sm text-gray-300 leading-relaxed font-medium">
        Designed from the ground up for busy real estate photographers with packed daily shoot schedules.
      </p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
      <div class="glass-card rounded-2xl p-6 border border-dark-border space-y-3 text-center">
        <div class="w-10 h-10 rounded-full bg-gold text-dark font-black font-mono flex items-center justify-center mx-auto text-lg">1</div>
        <h3 class="text-base font-bold text-white">Upload Your Brackets</h3>
        <p class="text-xs text-gray-300 leading-relaxed">Upload RAW or JPG brackets through our secure portal, Dropbox, Google Drive, or WeTransfer.</p>
      </div>
      <div class="glass-card rounded-2xl p-6 border border-dark-border space-y-3 text-center">
        <div class="w-10 h-10 rounded-full bg-gold text-dark font-black font-mono flex items-center justify-center mx-auto text-lg">2</div>
        <h3 class="text-base font-bold text-white">Manual Hand-Blending</h3>
        <p class="text-xs text-gray-300 leading-relaxed">Assigned retouchers hand-blend exposures, pull exterior windows, align verticals, and fix colors.</p>
      </div>
      <div class="glass-card rounded-2xl p-6 border border-dark-border space-y-3 text-center">
        <div class="w-10 h-10 rounded-full bg-gold text-dark font-black font-mono flex items-center justify-center mx-auto text-lg">3</div>
        <h3 class="text-base font-bold text-white">2-Tier Quality Audit</h3>
        <p class="text-xs text-gray-300 leading-relaxed">Senior art supervisors inspect every image for edge halos, straight walls, and natural glass reflections.</p>
      </div>
      <div class="glass-card rounded-2xl p-6 border border-dark-border space-y-3 text-center">
        <div class="w-10 h-10 rounded-full bg-gold text-dark font-black font-mono flex items-center justify-center mx-auto text-lg">4</div>
        <h3 class="text-base font-bold text-white">Download in 12–24h</h3>
        <p class="text-xs text-gray-300 leading-relaxed">Receive print-ready 300 DPI high-res files plus MLS-optimized web copies ready for immediate client delivery.</p>
      </div>
    </div>
  </section>

  <!-- ── 5. FAQS ───────────────────────────────────────────────────── -->
  <section class="space-y-8">
    <div class="text-center max-w-3xl mx-auto space-y-3">
      <div class="text-xs font-black text-gold uppercase tracking-wider">Frequently Asked Questions</div>
      <h2 class="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight">Real Estate Photo Editing FAQs</h2>
    </div>

    <div class="max-w-4xl mx-auto space-y-4">
      <?php foreach ($faqs as $faq): ?>
      <div class="glass-card rounded-2xl p-6 border border-dark-border space-y-2">
        <h3 class="text-base sm:text-lg font-bold text-white flex items-center gap-2">
          <span class="text-gold">Q.</span> <?= htmlspecialchars($faq['q']) ?>
        </h3>
        <p class="text-xs sm:text-sm text-gray-300 leading-relaxed pl-6">
          <?= htmlspecialchars($faq['a']) ?>
        </p>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- ── 6. BOTTOM CTA BOX ─────────────────────────────────────────── -->
  <section class="glass-card rounded-3xl p-8 sm:p-14 border border-gold/40 bg-gradient-to-r from-gold/10 via-dark-card to-gold/10 text-center space-y-6">
    <div class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gold/20 border border-gold/40 text-gold text-xs font-black uppercase tracking-widest">
      <span>✦ ZERO RISK FREE TRIAL ✦</span>
    </div>
    <h2 class="text-3xl sm:text-4xl font-black text-white tracking-tight max-w-2xl mx-auto">
      Experience the Estate HDR Difference On Your Next Listing
    </h2>
    <p class="text-sm sm:text-base text-gray-300 max-w-xl mx-auto leading-relaxed">
      Send us 3 bracketed sets or single exposures today. Our master digital artists will retouch and return them within 24 hours at zero cost.
    </p>
    <div class="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
      <a href="/#trial" class="w-full sm:w-auto px-8 py-4 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-sm uppercase tracking-wider shadow-xl hover:scale-105 transition-all">
        Start Free Trial Now
      </a>
      <a href="<?= WHATSAPP_LINK ?>" target="_blank" class="w-full sm:w-auto px-8 py-4 rounded-xl bg-emerald-950/40 border border-emerald-800/40 hover:border-emerald-500 text-emerald-400 font-bold text-sm tracking-wide transition-all" rel="noopener noreferrer">
        Chat With Production Team
      </a>
    </div>
  </section>

</main>

<?php require_once __DIR__ . '/includes/public-footer.php'; ?>

</body>
</html>
