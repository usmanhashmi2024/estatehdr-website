<?php
/**
 * Estate HDR — HTML Sitemap
 * Provides human-navigable and search-crawler indexed access to all pages, services, guides, and legal policies
 */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';

$blogs = getPublishedBlogs();
$services = getServices();
$categories = getCategories();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HTML Sitemap — Estate HDR Architecture &amp; Photography Directory</title>
<meta name="description" content="Explore the comprehensive site index of Estate HDR. Access all real estate photo editing services, architectural photography guides, pricing, and company resources.">
<link rel="canonical" href="<?= rtrim(BASE_URL, '/') ?>/sitemap">
<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" onload="this.onload=null;this.rel='stylesheet'">
<noscript>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap">
</noscript>
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
tailwind.config = {
  theme: {
    extend: {
      colors: {
        gold: { DEFAULT: '#C9A84C', light: '#E8C97B', dark: '#9A7A2E' },
        dark: { DEFAULT: '#0A0A0F', card: '#111118', border: '#1E1E2E' },
      }
    }
  }
}
</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/includes/public-header.php'; ?>

<main class="flex-1 pt-36 pb-20 px-6 sm:px-10 max-w-6xl mx-auto w-full">
  <div class="text-center mb-12">
    <div class="section-tag mb-3">Directory &amp; Index</div>
    <h1 class="text-3xl sm:text-5xl font-black text-white leading-tight">Estate HDR HTML Sitemap</h1>
    <p class="text-gray-300 text-sm sm:text-base mt-4 max-w-2xl mx-auto leading-relaxed">
      A complete, hierarchical overview of all public pages, services, architectural post-production guides, and legal disclosures across estatehdr.com.
    </p>
    <div class="mt-4 inline-flex items-center gap-2 text-xs font-mono text-gold bg-gold/10 px-3 py-1.5 rounded-xl border border-gold/30">
      <span>Looking for search engines?</span>
      <a href="/sitemap.xml" target="_blank" class="underline font-bold hover:text-white">XML Sitemap ↗</a>
    </div>
  </div>

  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
    
    <!-- 1. Main Pages -->
    <div class="glass-card rounded-2xl p-6 border border-dark-border bg-[#111118] space-y-4">
      <h2 class="text-lg font-bold text-gold flex items-center gap-2 border-b border-dark-border pb-3">
        <span>🌐</span> <span>Core Pages</span>
      </h2>
      <ul class="space-y-2 text-sm text-gray-300">
        <li><a href="/" class="hover:text-gold transition-colors">Home Page</a></li>
        <li><a href="/about" class="hover:text-gold transition-colors">About Us &amp; Company Overview</a></li>
        <li><a href="/portfolio" class="hover:text-gold transition-colors">Interactive Before/After Portfolio</a></li>
        <li><a href="/team" class="hover:text-gold transition-colors">Our Creative Team &amp; Editors</a></li>
        <li><a href="/pricing" class="hover:text-gold transition-colors">Pricing &amp; Subscription Packages</a></li>
        <li><a href="/#how-it-works" class="hover:text-gold transition-colors">How It Works Workflow</a></li>
        <li><a href="/contact" class="hover:text-gold transition-colors">Contact Us &amp; Global Support</a></li>
        <li><a href="/register" class="hover:text-gold transition-colors">Client Portal Registration</a></li>
        <li><a href="/login" class="hover:text-gold transition-colors">Client Login</a></li>
        <li><a href="/alternatives" class="hover:text-gold transition-colors">Estate HDR vs Alternatives</a></li>
      </ul>
    </div>

    <!-- 2. Services -->
    <div class="glass-card rounded-2xl p-6 border border-dark-border bg-[#111118] space-y-4">
      <h2 class="text-lg font-bold text-gold flex items-center gap-2 border-b border-dark-border pb-3">
        <span>⚡</span> <span>Post-Production Services</span>
      </h2>
      <ul class="space-y-2 text-sm text-gray-300">
        <li><a href="/real-estate-photo-editing" class="hover:text-gold transition-colors font-bold text-white">All Photo Editing Services</a></li>
        <li><a href="/services/hdr-photo-editing" class="hover:text-gold transition-colors">HDR Bracket Blending</a></li>
        <li><a href="/services/flambient-photo-editing" class="hover:text-gold transition-colors">Flambient (Flash + Ambient) Editing</a></li>
        <li><a href="/services/window-pull" class="hover:text-gold transition-colors">Window Pull Highlight Recovery</a></li>
        <li><a href="/services/virtual-staging" class="hover:text-gold transition-colors">3D Virtual Staging &amp; Furniture</a></li>
        <li><a href="/services/floor-plans" class="hover:text-gold transition-colors">2D &amp; 3D Floor Plans Redraw</a></li>
        <li><a href="/services/day-to-dusk" class="hover:text-gold transition-colors">Day to Dusk Twilight Conversion</a></li>
        <li><a href="/services/item-removal" class="hover:text-gold transition-colors">Digital Item Removal &amp; Decluttering</a></li>
        <li><a href="/services/virtual-renovation" class="hover:text-gold transition-colors">Virtual Renovation Remodeling</a></li>
        <li><a href="/services/real-estate-video-editing" class="hover:text-gold transition-colors">4K Video Tours &amp; Drone Reels</a></li>
      </ul>
    </div>

    <!-- 3. Legal & Standards -->
    <div class="glass-card rounded-2xl p-6 border border-dark-border bg-[#111118] space-y-4">
      <h2 class="text-lg font-bold text-gold flex items-center gap-2 border-b border-dark-border pb-3">
        <span>⚖️</span> <span>Policies &amp; EEAT Standards</span>
      </h2>
      <ul class="space-y-2 text-sm text-gray-300">
        <li><a href="/terms" class="hover:text-gold transition-colors">Terms of Service</a></li>
        <li><a href="/privacy" class="hover:text-gold transition-colors">Privacy Policy</a></li>
        <li><a href="/editorial-guidelines" class="hover:text-gold transition-colors">Editorial Guidelines &amp; Quality Standards</a></li>
        <li><a href="/terms#dmca" class="hover:text-gold transition-colors">DMCA Copyright Policy</a></li>
        <li><a href="/rss.xml" target="_blank" class="hover:text-gold transition-colors">RSS Feed (XML) ↗</a></li>
        <li><a href="/sitemap.xml" target="_blank" class="hover:text-gold transition-colors">XML Sitemap Index ↗</a></li>
      </ul>
    </div>

  </div>

  <!-- Blog & Guides Section -->
  <div class="mt-12 glass-card rounded-2xl p-6 sm:p-8 border border-dark-border bg-[#111118] space-y-6">
    <div class="flex items-center justify-between border-b border-dark-border pb-4">
      <h2 class="text-xl font-bold text-white flex items-center gap-2">
        <span>📚</span> <span>Photography Guides &amp; Case Studies</span>
      </h2>
      <a href="/blog" class="text-xs font-bold text-gold hover:underline">View Blog Archive &rarr;</a>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <?php foreach ($blogs as $b): ?>
      <div class="p-3 rounded-xl bg-dark/60 border border-dark-border hover:border-gold/40 transition-colors">
        <a href="/blog/<?= htmlspecialchars($b['slug']) ?>" class="font-bold text-white hover:text-gold text-sm transition-colors block mb-1">
          <?= htmlspecialchars($b['title']) ?>
        </a>
        <div class="flex items-center gap-3 text-xs text-gray-400">
          <span class="text-gold"><?= htmlspecialchars($b['category'] ?? 'Guide') ?></span>
          <span>•</span>
          <span><?= date('M j, Y', strtotime($b['created_at'] ?? 'now')) ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</main>

<?php require_once __DIR__ . '/includes/public-footer.php'; ?>

</body>
</html>
