<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';

$pageTitle = 'Privacy Policy — Estate HDR Data Protection & GDPR Compliance';
$pageDesc  = 'Learn how Estate HDR collects, protects, and handles personal data and client media files in compliance with GDPR, UK Data Protection Act, and US privacy laws.';
$canonUrl  = rtrim(BASE_URL, '/') . '/privacy';
$ogImage   = BASE_URL . '/assets/images/portfolio/hdr/1-after.jpg';
$robots    = 'index, follow';
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?></title>
<meta name="description" content="<?= htmlspecialchars($pageDesc) ?>">
<meta name="robots" content="<?= $robots ?>">
<link rel="canonical" href="<?= $canonUrl ?>">

<meta property="og:type" content="website">
<meta property="og:url" content="<?= $canonUrl ?>">
<meta property="og:title" content="<?= htmlspecialchars($pageTitle) ?>">
<meta property="og:description" content="<?= htmlspecialchars($pageDesc) ?>">
<meta property="og:image" content="<?= $ogImage ?>">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap">
<link rel="stylesheet" href="/assets/css/bundle.css?v=<?= file_exists(ROOT_PATH . '/assets/css/bundle.css') ? filemtime(ROOT_PATH . '/assets/css/bundle.css') : time() ?>">
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">

<script type="application/ld+json" nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "name": "Privacy Policy",
  "url": "https://estatehdr.com/privacy.php",
  "description": "<?= htmlspecialchars($pageDesc) ?>",
  "publisher": {
    "@type": "Organization",
    "name": "Estate HDR",
    "url": "https://estatehdr.com",
    "logo": "https://estatehdr.com/assets/images/logo.png"
  }
}
</script>
</head>
<body class="bg-dark text-gray-200 font-sans min-h-screen flex flex-col antialiased selection:bg-gold/30 selection:text-white">

<?php require_once __DIR__ . '/includes/public-header.php'; ?>

<section class="relative pt-32 sm:pt-40 pb-16 px-6 overflow-hidden border-b border-dark-border bg-gradient-to-b from-dark-card to-dark">
  <div class="max-w-4xl mx-auto text-center relative z-10">
    <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-gold/10 border border-gold/30 text-gold text-xs font-bold uppercase tracking-widest mb-4">
      <span>🔒</span> <span>Data Protection &amp; Confidentiality</span>
    </div>
    <h1 class="text-3xl sm:text-5xl font-black text-white uppercase tracking-tight mb-4">
      Privacy <span class="text-gold">Policy</span>
    </h1>
    <p class="text-sm sm:text-base text-gray-400 max-w-2xl mx-auto leading-relaxed">
      How we safeguard your personal information, raw property media files, and ensure full compliance with GDPR and US Privacy Standards.
    </p>
    <div class="mt-4 text-xs font-mono text-gray-500">Effective Date: September 4, 2026 &bull; Compliant with UK &amp; EU GDPR</div>
  </div>
</section>

<main class="max-w-4xl mx-auto px-6 py-16 flex-1 space-y-12 text-sm leading-relaxed text-gray-300">
  <section class="glass-card p-8 rounded-2xl border border-dark-border space-y-4">
    <h2 class="text-xl font-bold text-white flex items-center gap-3">
      <span class="text-gold font-mono">01.</span> Overview &amp; Commitment
    </h2>
    <p>
      Estate HDR ("we", "us", "our") is dedicated to safeguarding the privacy and confidential media assets of our clients, photographers, and visitors. This Privacy Policy details how we collect, use, store, and disclose information when you visit <a href="https://estatehdr.com" class="text-gold underline">estatehdr.com</a> or use our photo editing fulfillment systems.
    </p>
  </section>

  <section class="glass-card p-8 rounded-2xl border border-dark-border space-y-4">
    <h2 class="text-xl font-bold text-white flex items-center gap-3">
      <span class="text-gold font-mono">02.</span> Information We Collect
    </h2>
    <ul class="list-disc list-inside space-y-2 pl-2">
      <li><strong>Account &amp; Contact Details:</strong> Your name, company name, email address, phone number, and billing details provided during registration or order submission.</li>
      <li><strong>Uploaded Media Assets:</strong> RAW bracketed files, JPEG/TIFF photos, floor plan sketches, and property descriptions submitted for post-processing.</li>
      <li><strong>Technical Log Data:</strong> IP address, browser type, device information, and pages visited, collected to maintain Cloudflare DDoS protection and platform performance.</li>
    </ul>
  </section>

  <section class="glass-card p-8 rounded-2xl border border-dark-border space-y-4">
    <h2 class="text-xl font-bold text-white flex items-center gap-3">
      <span class="text-gold font-mono">03.</span> How We Use Your Data &amp; Property Photos
    </h2>
    <p>
      Your data is used strictly for legitimate business and fulfillment purposes:
    </p>
    <ul class="list-disc list-inside space-y-2 pl-2">
      <li>To complete, retouch, and deliver your ordered architectural and real estate photo editing jobs.</li>
      <li>To process invoices and payments via secure encrypted payment gateways.</li>
      <li>To provide 24/7 client support via email, WhatsApp, and live chat.</li>
    </ul>
    <div class="p-4 rounded-xl bg-gold/10 border border-gold/30 text-xs text-gold-light mt-4">
      <strong>Zero Third-Party Media Reselling:</strong> We NEVER sell, license, rent, or distribute your raw or edited photographs to any third parties, stock agencies, or AI training datasets. Your media belongs solely to you.
    </div>
  </section>

  <section class="glass-card p-8 rounded-2xl border border-dark-border space-y-4">
    <h2 class="text-xl font-bold text-white flex items-center gap-3">
      <span class="text-gold font-mono">04.</span> Data Retention &amp; Right to Erasure
    </h2>
    <p>
      Completed client jobs and source files are retained on encrypted storage for 30 days to facilitate revision requests and client re-downloads. After 30 days, files may be archived or permanently purged. You may exercise your "Right to be Forgotten" (GDPR Article 17) at any time by emailing us to request immediate deletion of your files and account data.
    </p>
  </section>

  <section class="glass-card p-8 rounded-2xl border border-dark-border space-y-4">
    <h2 class="text-xl font-bold text-white flex items-center gap-3">
      <span class="text-gold font-mono">05.</span> Cookies &amp; Tracking Technologies
    </h2>
    <p>
      We use essential session cookies strictly required for secure authentication, CSRF protection, and user preferences. We do not use intrusive third-party cross-site advertising trackers.
    </p>
  </section>

  <section class="glass-card p-8 rounded-2xl border border-dark-border space-y-4">
    <h2 class="text-xl font-bold text-white flex items-center gap-3">
      <span class="text-gold font-mono">06.</span> Contact Our Data Protection Officer
    </h2>
    <p>
      For privacy inquiries, GDPR data requests, or information access:
    </p>
    <div class="flex flex-wrap gap-4 pt-2">
      <a href="mailto:info@estatehdr.com" class="text-gold hover:underline">✉️ info@estatehdr.com</a>
      <a href="tel:+447706068176" class="text-gold hover:underline">📞 +44 770 606 8176</a>
      <span class="text-gray-400">🏢 Estate HDR &bull; London &bull; United Kingdom</span>
    </div>
  </section>
</main>

<footer class="border-t border-dark-border py-12 px-6 bg-dark">
  <div class="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-400">
    <div>&copy; <?= date('Y') ?> Estate HDR. All rights reserved.</div>
    <div class="flex items-center gap-5">
      <a href="/" class="hover:text-gold transition-colors">Home</a>
      <a href="/terms" class="hover:text-gold transition-colors">Terms of Service</a>
      <a href="/privacy" class="text-gold font-bold">Privacy Policy</a>
      <a href="/contact" class="hover:text-gold transition-colors">Contact</a>
    </div>
  </div>
</footer>
</body>
</html>