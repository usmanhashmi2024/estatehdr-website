<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
requireLogin();

$user   = currentUser();
$prefs  = getUserPreferences($user['id']);
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $propertyName    = trim($_POST['property_name'] ?? '');
    $cloudLink       = trim($_POST['cloud_link']    ?? '');
    $notes           = trim($_POST['notes']         ?? '');
    $serviceType     = trim($_POST['service_type']  ?? '');
    $rawImagesCount  = (int)($_POST['raw_images_count'] ?? 0);

    $allowedServices = [
        'Virtual Staging',
        'HDR Photo Editing',
        'Floor Plans & 3D Tours',
        'Item Removal',
        'Virtual Twilight',
        'Day to Dusk',
        'Full Custom Package (Multiple Services)'
    ];

    $orderType       = trim($_POST['order_type'] ?? 'live_order');
    $isTrial         = ($orderType === 'free_trial') || !empty($_POST['is_trial']);

    if (strlen($propertyName) < 3)         $errors[] = 'Property name / address is required (min. 3 characters).';
    if (empty($cloudLink))                 $errors[] = 'Please provide a cloud storage link (Drive, Dropbox, WeTransfer).';
    if (!in_array($serviceType, $allowedServices)) $errors[] = 'Please select a valid service type.';
    if ($rawImagesCount < 1)               $errors[] = 'Please specify the number of raw images submitted (at least 1).';

    if (empty($errors)) {
        // Automatically append client's saved preferences to notes if present
        $fullNotes = $notes;
        if (!empty($prefs['default_notes'])) {
            $fullNotes .= "\n\n[Applied Style Preferences]:\n" . $prefs['default_notes'];
        }
        if (!empty($prefs['reference_links'])) {
            $fullNotes .= "\n[Style Reference Link]: " . $prefs['reference_links'];
        }

        $order = createOrder($user['id'], $propertyName, $cloudLink, $fullNotes, $serviceType, $rawImagesCount, 'client', $isTrial);
        $typeMsg = $isTrial ? ' [🎁 Free Trial]' : '';
        setFlash('success', 'Job #' . strtoupper(substr($order['id'], 0, 8)) . $typeMsg . ' submitted! Raw photos (' . $rawImagesCount . ' count) logged. Delivery within 24 hours.');
        header('Location: /order-view.php?id=' . urlencode($order['id']));
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Smart Order Submission — Estate HDR</title>
<meta name="robots" content="noindex">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-[#0A0A0F] text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/includes/portal-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8">
  <div class="mb-8">
    <div class="section-tag mb-2">Streamlined Job Flow</div>
    <h1 class="text-2xl sm:text-3xl font-bold text-white">Submit New Job</h1>
    <p class="text-gray-400 text-sm mt-1">Specify your property details and raw image count. Delivered in 24 hours.</p>
  </div>

  <?php if (!empty($errors)): ?>
  <div class="flash-msg flash-error mb-6">
    <?php foreach ($errors as $e): ?><div>&bull; <?= htmlspecialchars($e) ?></div><?php endforeach; ?>
  </div>
  <?php endif; ?>

    <?php
    $incomingService = $_POST['service_type'] ?? ($_GET['service'] ?? '');
    $incomingCount   = $_POST['raw_images_count'] ?? ($_GET['count'] ?? '');
    $incomingEst     = trim($_GET['est'] ?? '');
    $incomingCurr    = trim($_GET['curr'] ?? 'USD');
    ?>

    <?php if (!empty($incomingEst)): ?>
    <div class="mb-6 p-4 rounded-xl bg-gold/10 border border-gold/40 flex items-center justify-between text-xs">
      <div class="flex items-center gap-2 text-white">
        <span class="text-base">⚡</span>
        <span><strong>Interactive Estimate Applied:</strong> <?= htmlspecialchars($incomingService) ?> &bull; <strong><?= htmlspecialchars($incomingCount) ?> units</strong></span>
      </div>
      <div class="font-mono font-bold text-gold text-sm">
        Est: <?= htmlspecialchars($incomingCurr) ?> <?= htmlspecialchars($incomingEst) ?>
      </div>
    </div>
    <?php endif; ?>

    <div class="glass-card rounded-2xl p-8 border border-dark-border shadow-2xl">
    <form method="POST" class="space-y-6" onsubmit="if(this.dataset.submitted){return false;} this.dataset.submitted='true'; const btn=this.querySelector('button[type=submit]'); if(btn){ btn.style.pointerEvents='none'; btn.style.opacity='0.7'; btn.innerHTML='<span class=\'inline-block animate-spin mr-2\'>⏳</span> Submitting Order...'; } return true;">
      <?= csrfField() ?>

      <!-- Order Classification: Live Order vs Free Trial -->
      <div class="p-4 rounded-xl bg-[#141622] border border-amber-500/30 space-y-2">
        <label class="form-label font-bold text-amber-300 mb-0">Select Order Type <span class="text-red-400">*</span></label>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <label class="flex items-center gap-3 p-3 rounded-lg bg-[#0e1017] border border-dark-border cursor-pointer hover:border-gold transition-all">
            <input type="radio" name="order_type" value="live_order" <?= (($_POST['order_type'] ?? 'live_order') === 'live_order' && (($_GET['trial'] ?? '') !== '1')) ? 'checked' : '' ?> class="text-gold focus:ring-0">
            <div>
              <div class="font-bold text-white text-xs">⚡ Live Production Order</div>
              <div class="text-[11px] text-gray-400">Standard billable real-estate editing order.</div>
            </div>
          </label>
          <label class="flex items-center gap-3 p-3 rounded-lg bg-[#0e1017] border border-amber-500/40 cursor-pointer hover:border-gold transition-all">
            <input type="radio" name="order_type" value="free_trial" <?= (($_POST['order_type'] ?? '') === 'free_trial' || ($_GET['trial'] ?? '') === '1') ? 'checked' : '' ?> class="text-gold focus:ring-0">
            <div>
              <div class="font-bold text-amber-300 text-xs">🎁 Free Trial (Sample Photos)</div>
              <div class="text-[11px] text-gray-400">100% Free of Cost &bull; Test our quality ($0.00).</div>
            </div>
          </label>
        </div>
      </div>

      <!-- Property Name -->
      <div>
        <label class="form-label">Property Name / Address <span class="text-red-400">*</span></label>
        <input type="text" name="property_name" class="form-input text-sm"
               placeholder="e.g. 742 Evergreen Terrace, Springfield"
               value="<?= htmlspecialchars($_POST['property_name'] ?? '') ?>" required>
      </div>

      <!-- Service Type & Raw Count -->
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="form-label">Service Type <span class="text-red-400">*</span></label>
          <select name="service_type" class="form-select text-sm" required>
            <option value="">— Select required service —</option>
            <?php
            $services = [
              'Virtual Staging',
              'HDR Photo Editing',
              'Floor Plans & 3D Tours',
              'Item Removal',
              'Virtual Twilight',
              'Day to Dusk',
              'Full Custom Package (Multiple Services)'
            ];
            foreach ($services as $svc): 
              $isSel = (strcasecmp($incomingService, $svc) === 0 || str_contains(strtolower($incomingService), strtolower(explode(' ', $svc)[0])));
              $sel = $isSel ? 'selected' : ''; 
            ?>
            <option value="<?= $svc ?>" <?= $sel ?>><?= $svc ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div>
          <label class="form-label">Number of Raw Images Submitted <span class="text-red-400">*</span></label>
          <input type="number" name="raw_images_count" min="1" max="1000" class="form-input text-sm"
                 placeholder="e.g. 25"
                 value="<?= htmlspecialchars($incomingCount) ?>" required>
          <p class="text-gray-500 text-xs mt-1">Exact raw photo count submitted.</p>
        </div>
      </div>

      <!-- Cloud Link -->
      <div>
        <label class="form-label">Cloud Storage Link (Drive / Dropbox / WeTransfer) <span class="text-red-400">*</span></label>
        <input type="url" name="cloud_link" class="form-input text-sm"
               placeholder="https://drive.google.com/... or Dropbox / WeTransfer link"
               value="<?= htmlspecialchars($_POST['cloud_link'] ?? '') ?>" required>
        <p class="text-gray-500 text-xs mt-1">
          Make sure link sharing is set to "Anyone with the link can view &amp; download".
        </p>
      </div>

      <!-- Read-Only Notice for Final Delivered Images -->
      <div class="p-3.5 rounded-xl bg-dark border border-dark-border flex items-center justify-between text-xs">
        <span class="text-gray-400 font-medium">Final Delivered Images Count:</span>
        <span class="text-gold font-mono font-bold">Set by Admin upon delivery (Read-Only)</span>
      </div>

      <!-- Editing Notes -->
      <div>
        <label class="form-label">Job Specific Instructions &amp; Notes</label>
        <textarea name="notes" rows="4" class="form-input resize-y text-sm"
                  placeholder="e.g. Please brighten window pull in living room, remove the trash bin in driveway, keep warm sky..."><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
      </div>

      <!-- Style Preset Indicator -->
      <div class="rounded-xl border border-gold/20 bg-gold/5 p-4 flex items-start gap-3">
        <div class="text-lg">🎨</div>
        <div class="text-xs text-gray-300">
          <strong class="text-white block mb-0.5">Style Preferences Linked</strong>
          Your signature style (<?= ucfirst(str_replace('_', ' ', $prefs['color_style'])) ?> color, <?= ucfirst(str_replace('_', ' ', $prefs['sky_replacement'])) ?> sky) will automatically be followed. 
          <a href="/preferences.php" class="text-gold underline ml-1">Edit defaults</a>
        </div>
      </div>

      <div class="flex gap-4 pt-2">
        <button type="submit" class="btn-gold flex-1 py-3 text-sm font-bold shadow-glow">
          Submit Order &amp; Start 24h Clock
        </button>
        <a href="/dashboard.php" class="btn-ghost flex-none py-3 px-6 text-sm">Cancel</a>
      </div>
    </form>
  </div>
</main>
<?php require_once __DIR__ . '/includes/chat-widgets.php'; ?>
</body>
</html>

