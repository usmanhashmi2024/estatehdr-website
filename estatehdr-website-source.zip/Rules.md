# 📜 Estate HDR — Platform Rules, Standards & SOPs

> **Document Version:** 2.0  
> **Scope:** Core Business Logic, Operational SOPs, Role Constraints & Coding Standards  
> **Enforcement:** Strict system-level assertion & runtime validation  

---

## 📑 Table of Contents
1. [Rule 1: The Free Trial Immunity Rule](#rule-1-the-free-trial-immunity-rule)
2. [Rule 2: Live Order Billing & Invoicing Rule](#rule-2-live-order-billing--invoicing-rule)
3. [Rule 3: Privacy Shielding & Data Isolation Rule](#rule-3-privacy-shielding--data-isolation-rule)
4. [Rule 4: Quality Assurance & Unlimited Revision Guarantee](#rule-4-quality-assurance--unlimited-revision-guarantee)
5. [Rule 5: Role Authority & Page-Level Access Boundaries](#rule-5-role-authority--page-level-access-boundaries)
6. [Rule 6: Financial Ledger & Balance Integrity Rules](#rule-6-financial-ledger--balance-integrity-rules)
7. [Rule 7: Security, Coding & CSP Development Standards](#rule-7-security-coding--csp-development-standards)
8. [Rule 8: Production Turnaround SLA & Escalation Rules](#rule-8-production-turnaround-sla--escalation-rules)

---

## Rule 1: The Free Trial Immunity Rule

> [!IMPORTANT]
> **A Free Trial order must NEVER, under any circumstance, charge a client, post a debt to their ledger, or send PayPal payment demands.**

1. **Strict $0.00 Pricing:**
   - Any order flagged with `is_trial = true` or `order_type = 'free_trial'` must have its billed amount permanently forced to `0.00`.
   - Automated price calculators (`calculateServicePrice()`) are strictly forbidden from running against trial orders.
2. **Zero Ledger Debt:**
   - Free trials are immune from financial debit entries in `data/ledger.json`.
   - When an order is switched to `free_trial`, any existing debit entry in the ledger must be pruned immediately (`syncOrderBillingToLedger($orderId, 0.0)`).
3. **PayPal Exemption in Delivery Emails:**
   - The delivery email for a Free Trial must use the **Complimentary Delivery Template**.
   - It is strictly prohibited to include the PayPal email (`ashrafnadeem283@gmail.com`), PayPal payment buttons, or invoice amount due boxes in a trial delivery email.
4. **Visual Badging:**
   - All management interfaces (`orders.php`, `supervisor-dashboard.php`, `order-view.php`) must display the prominent **`🎁 FREE TRIAL ($0.00)`** badge.

---

## Rule 2: Live Order Billing & Invoicing Rule

1. **Delivery Triggered Invoicing:**
   - When a live order is marked `delivered` by a Supervisor or Admin, an official Estate HDR Luxury Invoice is generated automatically.
2. **Official Payment Channel:**
   - The designated corporate PayPal receiving address is strictly:
     ```
     ashrafnadeem283@gmail.com
     ```
   - Every invoice must provide the official direct payment link:
     ```
     https://www.paypal.com/paypalme/ashrafnadeem283
     ```
3. **Itemized Billing Calculation:**
   - HDR Photo Editing tiers:
     - 1–19 photos: **$0.80 / photo**
     - 20–49 photos: **$0.76 / photo**
     - 50–99 photos: **$0.72 / photo**
     - 100+ photos: **$0.68 / photo**
   - Virtual Staging: **$8.00 / photo**
   - Item Removal: **$2.00 / photo**
   - Virtual Twilight: **$6.00 / photo**
   - Floor Plans / 3D Tours: **$15.00 / unit**

---

## Rule 3: Privacy Shielding & Data Isolation Rule

> [!CAUTION]
> **Client contact information (Email, Phone, WhatsApp) and financial rates must NEVER be visible to Photo Editors or Team Leads.**

1. **Frontend Masking:**
   - `editor-dashboard.php`, `editor-order.php`, and `teamlead-dashboard.php` must render data filtered through `maskOrderForRole()`.
2. **Direct Contact Prohibition:**
   - Editors and Team Leads are strictly forbidden from contacting clients directly outside the CRM platform.
   - All client communication must route exclusively through the Supervisor or Admin ticket desk.
3. **Storage Sanitization:**
   - Raw files downloaded by editors must not contain client billing sheets or external proprietary client notes.

---

## Rule 4: Quality Assurance & Unlimited Revision Guarantee

1. **5-Point Mandatory QA Inspection:**
   Before approving any job for client delivery, the Team Lead must verify:
   - **Point 1 (Vertical & Horizontal Alignment):** 100% straight architectural walls and 2-point perspective.
   - **Point 2 (Window Pull Clarity):** Clear exterior views through windows without unnatural edge bleeding or halos.
   - **Point 3 (Color Cast Correction):** True white ceilings, accurate hardwood tones, and elimination of fluorescent / mixed color casts.
   - **Point 4 (Sky & Lawn Enhancement):** Natural blue sky replacement and lush, realistic turf color.
   - **Point 5 (Flash Reflection Removal):** Eradication of camera reflections in mirrors, TV screens, and polished appliances.
2. **100% Free Unlimited Amendments:**
   - Every client is entitled to unlimited free revisions on every project (both Live and Free Trial).
   - When a client clicks "Request Amendment", the ticket is immediately prioritized in the Team Lead's queue without additional fees.

---

## Rule 5: Role Authority & Page-Level Access Boundaries

System-level enforcement via `enforceRoleAccess()` in `includes/auth.php`:

```
┌──────────────────┬────────────────────────────────────────────────────────┐
│ Role             │ Permitted Workspace Endpoints                          │
├──────────────────┼────────────────────────────────────────────────────────┤
│ Owner / CEO      │ ALL pages (Unrestricted)                               │
│ Production Mgr   │ ALL pages EXCEPT: ledger, hr-dashboard, pages, posts   │
│ Supervisor       │ supervisor-dashboard, supervisor-teams, order-view,    │
│                  │ supervisor-performance, orders, roles-sop, profile     │
│ Team Lead        │ teamlead-dashboard, editor-order, orders, order-view,  │
│                  │ roles-sop, profile                                     │
│ Photo Editor     │ editor-dashboard, editor-order, roles-sop, profile     │
│ HR Officer       │ hr-dashboard, hr-documents, users, user-edit, profile  │
│ SEO Manager      │ pages, page-edit, posts, post-edit, categories, sitemap │
└──────────────────┴────────────────────────────────────────────────────────┘
```

- Any attempt by a staff member to navigate to an unauthorized endpoint will result in an immediate redirect to their authorized home dashboard accompanied by an **Access Denied** flash alert.

---

## Rule 6: Financial Ledger & Balance Integrity Rules

1. **Double-Entry Balance Formula:**
   $$\text{Balance} = \text{Total Payments Received (Credit)} - \text{Total Orders Delivered (Debit)}$$
2. **Purge Protection:**
   - Purging the financial ledger (`purge_all_ledger`) or deleting individual accounting records is an **Owner-Only** privilege.
3. **Reconciliation Invariance:**
   - Free Trial orders (`is_trial = true` or order ID starting with `TRIAL-`) must be explicitly skipped during any global ledger reconciliation.

---

## Rule 7: Security, Coding & CSP Development Standards

1. **Strict Content Security Policy (CSP):**
   - **NO INLINE JAVASCRIPT EVENT HANDLERS** (e.g., `onclick="..."`, `onchange="..."`).
   - Every `<script>` block must include the dynamic server-generated nonce:
     ```html
     <script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
     ```
   - UI interactions must use unobtrusive event listeners bound via `document.addEventListener('DOMContentLoaded', ...)` or event delegation.
2. **CSRF Protection on All POST Actions:**
   - Every form performing an update, deletion, or dispatch must include `<?= csrfField() ?>`.
   - Every POST handler must invoke `verifyCsrf()` prior to executing business logic.
3. **Atomic File Operations:**
   - All updates to JSON records must utilize `atomicWriteJson()` or `file_put_contents(..., LOCK_EX)`.
   - Never write to data files with unsecured non-locking file streams.

---

## Rule 8: Production Turnaround SLA & Escalation Rules

1. **Standard Turnaround:** Guaranteed **24 Hours** from placement to delivery.
2. **Rush Turnaround:** **12 Hours** (Priority badge displayed across all queues).
3. **Urgent Turnaround:** **6 Hours** (Immediate top-of-queue pinning in Supervisor and TL dashboards).
4. **Deadline Warning:**
   - Orders within 4 hours of SLA deadline are highlighted with flashing amber border indicators.
   - Overdue orders are automatically flagged in red and escalated to the Supervisor's priority banner.
