# ESTATE HDR WEBSITE SOURCE EXPORT MANIFEST

**Generated:** 2026-10-14
**Total Included Items:** 371
**Total Excluded Items Logged:** 156

## Included Files & Directories (Summary)

```text
.env.example
.htaccess
.htaccess.bak_20260921_030207
404.php
Architecture.md
CLIENT_APP_PRD.md
CLIENT_APP_TRD.md
ESTATE_HDR_MOBILE_PRD.md
ESTATE_HDR_MOBILE_TRD.md
PROJECT.md
README_FOR_CLAUDE.md
Rules.md
TEAM_APP_PRD.md
TEAM_APP_TRD.md
TEST_INFRA.md
TEST_READY.md
about.php
admin/.htaccess
admin/ai-brain.php
admin/amendments.php
admin/analytics.php
admin/categories.php
admin/client-chats.php
admin/client-new.php
admin/clients.php
admin/command-center.php
admin/crm.php
admin/editor-dashboard.php
admin/editor-order.php
admin/email-crm.php
admin/export-leads.php
admin/hr-dashboard.php
admin/hr-document.php
admin/hr-documents.php
admin/index.php
admin/integrations.php
admin/invoice.php
admin/leads.php
admin/ledger.php
admin/live-visitors.php
admin/login.php
admin/logout.php
admin/mail-test.php
admin/manager-dashboard.php
admin/mobile-app.php
admin/order-new.php
admin/order-view.php
admin/orders.php
admin/page-edit.php
admin/pages.php
admin/post-edit.php
admin/posts.php
admin/preview.php
admin/profile-save-avatar.php
admin/profile.php
admin/roles-sop.php
admin/seo-sitemap.php
admin/supervisor-dashboard.php
admin/teamlead-dashboard.php
admin/users.php
alternatives.php
api/admin-notifications.php
api/ai-processor.php
api/chat-bot.php
api/chat-live.php
api/client-chat.php
api/crm-form-submit.php
api/crm-track.php
api/email-verify.php
api/health.php
api/quote-calculator.php
api/seo-publish.php
api/server-images.php
api/session-ping.php
api/upload-avatar.php
api/upload-image.php
api/v1/index.php
api/visitor-ping.php
apple-touch-icon.png
assets/css/app.css
assets/css/app.css.unminified.bak
assets/css/bundle.css
assets/css/input.css
assets/images/Black.png
assets/images/apple-touch-icon.png
assets/images/avatars/.htaccess
assets/images/blog/3d-floor-plan-architectural-render.jpg
assets/images/blog/aerial-drone-photography-estate.jpg
assets/images/blog/ai-commercial-real-estate-listings-optimization.jpg
assets/images/blog/day-to-dusk-twilight-sunset.jpg
assets/images/blog/evening-patio-pool-twilight.jpg
assets/images/blog/hdr-real-estate-photography-guide.jpg
assets/images/blog/item-removal-declutter-real-estate.jpg
assets/images/blog/luxury-penthouse-virtual-staging.jpg
assets/images/blog/modern-kitchen-hdr-interior.jpg
assets/images/blog/virtual-staging-interior-luxury.jpg
assets/images/favicon-512.png
assets/images/favicon.png
assets/images/favicon.svg
assets/images/gravatar_logo_original.jpg
... and 271 more files.
```

## Excluded Categories & Files

| Item | Reason |
|---|---|
| `estatehdr-update.zip` | Excluded security credential / backup / zip |
| `estatehdr-website-source.zip` | Excluded security credential / backup / zip |
| `index.php.bak_audit` | Excluded security credential / backup / zip |
| `Passwords.xlsx` | Excluded security credential / backup / zip |
| `includes\pricing-calculator.php.bak_audit` | Backup file |
| `includes\public-footer.php.bak_audit` | Backup file |
| `includes\public-header.php.bak_audit` | Backup file |
| `scripts\social_automation\social_post_history.json` | Cache / state log |
| `assets/images/gravatar_profile_screenshot.png` | Heavy screenshot (>1.2MB) excluded for GitHub 25MB limit |
| `assets/images/portfolio/day-to-dusk/3-after.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/day-to-dusk/3-after.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/day-to-dusk/3-before.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/day-to-dusk/3-before.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/day-to-dusk/4-after.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/day-to-dusk/4-after.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/day-to-dusk/4-before.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/day-to-dusk/4-before.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/day-to-dusk/5-after.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/day-to-dusk/5-after.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/day-to-dusk/5-before.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/day-to-dusk/5-before.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/day-to-dusk/6-after.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/day-to-dusk/6-after.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/day-to-dusk/6-before.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/day-to-dusk/6-before.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/10-after.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/10-after.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/10-before.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/10-before.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/11-after.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/11-after.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/11-before.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/11-before.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/12-after.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/12-after.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/12-before.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/12-before.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/13-after.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/13-after.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/13-before.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/13-before.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/14-after.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/14-after.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/14-before.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/14-before.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/15-after.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/15-after.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/15-before.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/15-before.webp` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| `assets/images/portfolio/hdr/3-after.jpg` | Redundant high-res sample photo excluded for GitHub 25MB limit |
| *... and 106 more items* | Excluded according to security policy |
