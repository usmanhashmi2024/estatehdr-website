module.exports = {
  content: [
    './*.php',
    './admin/**/*.php',
    './client/**/*.php',
    './includes/**/*.php',
    './assets/js/**/*.js'
  ],
  theme: {
    extend: {
      colors: {
        gold: {
          light: '#E8C97B',
          DEFAULT: '#C9A84C',
          dark: '#9A7A2E'
        },
        dark: {
          DEFAULT: '#0A0A0F',
          card: '#111118',
          border: '#1E1E2E'
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Playfair Display', 'serif']
      }
    }
  },
  plugins: []
}
