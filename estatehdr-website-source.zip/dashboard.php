<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
requireLogin();

if (function_exists('reconcileAllOrdersLedger')) {
    reconcileAllOrdersLedger();
}

$user = currentUser();
$dbUser = getUserById($user['id']) ?? $user;
$allOrders = getAllOrders();
$myOrders = array_values(array_filter($allOrders, fn($o) => $o['user_id'] === $user['id']));

$balance = getUserBalance($user['id']);
$userBal = isset($dbUser['balance']) ? (float)$dbUser['balance'] : (float)($balance['net_balance'] ?? ($balance['outstanding_balance'] ?? 0.00));

// Calculate statistics by service type
$stats = [
    'Photo Enhancement HDR' => ['jobs' => 0, 'amount' => 0.0, 'photos' => 0],
    'Virtual Staging'       => ['jobs' => 0, 'amount' => 0.0, 'photos' => 0],
    '2D / 3D Floor Plans'   => ['jobs' => 0, 'amount' => 0.0, 'photos' => 0],
    'Item Removal'          => ['jobs' => 0, 'amount' => 0.0, 'photos' => 0],
    'Day to Dusk'           => ['jobs' => 0, 'amount' => 0.0, 'photos' => 0],
    'Virtual Twilight'      => ['jobs' => 0, 'amount' => 0.0, 'photos' => 0],
    'Video Editing'         => ['jobs' => 0, 'amount' => 0.0, 'photos' => 0],
    'Virtual Renovation'    => ['jobs' => 0, 'amount' => 0.0, 'photos' => 0]
];

$totalJobs = 0;
$totalAmount = 0.0;
$totalPhotos = 0;

foreach ($myOrders as $ord) {
    $svc = $ord['service'] ?? 'Photo Enhancement HDR';
    $foundKey = 'Photo Enhancement HDR';
    foreach (array_keys($stats) as $k) {
        if (stripos($svc, str_replace(' HDR', '', $k)) !== false || stripos($svc, $k) !== false) {
            $foundKey = $k;
            break;
        }
    }
    $qty = (int)($ord['quantity'] ?? 1);
    $price = (float)($ord['price'] ?? 0.0);
    $itemTotal = $price * $qty;

    $stats[$foundKey]['jobs'] += 1;
    $stats[$foundKey]['amount'] += $itemTotal;
    $stats[$foundKey]['photos'] += $qty;

    $totalJobs += 1;
    $totalAmount += $itemTotal;
    $totalPhotos += $qty;
}

// Service catalog with bold typography
$serviceCards = [
    [
        'title'    => 'VIRTUAL STAGING',
        'subtitle' => 'Full 3D realistic interior furniture placement & styling.',
        'badge'    => '24h Delivery',
        'badge_cls'=> 'bg-dark/80 text-gold border-gold/30',
        'price'    => 'US $10.00',
        'unit'     => '/img',
        'img'      => '/assets/images/portfolio/virtual-staging/1-after.jpg',
        'link'     => '/order-new.php?service=Virtual+Staging'
    ],
    [
        'title'    => 'PHOTO ENHANCEMENT HDR',
        'subtitle' => 'Bracketing, window pulls & flambient image processing.',
        'badge'    => 'MOST POPULAR',
        'badge_cls'=> 'bg-gold text-dark font-black shadow-sm',
        'price'    => 'From US $0.50',
        'unit'     => '/img',
        'img'      => '/assets/images/portfolio/hdr/1-after.jpg',
        'link'     => '/order-new.php?service=HDR+Photo+Editing'
    ],
    [
        'title'    => '2D / 3D FLOOR PLAN',
        'subtitle' => 'Architectural room dimensions & isometric 3D models.',
        'badge'    => 'Schematics',
        'badge_cls'=> 'bg-dark/80 text-gold border-gold/30',
        'price'    => 'US $10.00',
        'unit'     => '/plan',
        'img'      => '/assets/images/portfolio/virtual-staging/2-after.jpg',
        'link'     => '/order-new.php?service=Floor+Plans+%26+3D+Tours'
    ],
    [
        'title'    => 'ITEM REMOVAL',
        'subtitle' => 'Erase unwanted vehicles, trash bins & personal clutter.',
        'badge'    => 'Declutter',
        'badge_cls'=> 'bg-dark/80 text-gold border-gold/30',
        'price'    => 'US $2.00',
        'unit'     => '/img',
        'img'      => '/assets/images/portfolio/item-removal/1-after.jpg',
        'link'     => '/order-new.php?service=Item+Removal'
    ],
    [
        'title'    => 'DAY TO DUSK',
        'subtitle' => 'Convert flat daytime exterior photography to dusk.',
        'badge'    => 'Sunset Ambiance',
        'badge_cls'=> 'bg-dark/80 text-gold border-gold/30',
        'price'    => 'US $10.00',
        'unit'     => '/img',
        'img'      => '/assets/images/portfolio/day-to-dusk/1-after.jpg',
        'link'     => '/order-new.php?service=Day+to+Dusk'
    ],
    [
        'title'    => 'VIRTUAL TWILIGHT',
        'subtitle' => 'Glowing interior fixtures, sky blend & architectural light.',
        'badge'    => 'Luxury Lighting',
        'badge_cls'=> 'bg-dark/80 text-gold border-gold/30',
        'price'    => 'US $10.00',
        'unit'     => '/img',
        'img'      => '/assets/images/portfolio/twilight/1-after.jpg',
        'link'     => '/order-new.php?service=Virtual+Twilight'
    ],
    [
        'title'    => 'VIDEO EDITING & REELS',
        'subtitle' => 'Cinematic 4K property walkthroughs, drone & 9:16 reels.',
        'badge'    => '4K & Drone',
        'badge_cls'=> 'bg-dark/80 text-gold border-gold/30',
        'price'    => 'From US $15.00',
        'unit'     => '/vid',
        'img'      => '/assets/images/portfolio/hdr/2-after.jpg',
        'link'     => '/order-new.php?service=Real+Estate+Video+Editing',
        'is_video' => true
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Client Dashboard — Estate HDR</title>
<meta name="robots" content="noindex">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E',light:'#E8C97B'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-[#0A0A0F] text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . "/includes/portal-header.php"; ?>

<!-- ── MAIN CONTENT (Expansive Ultra-Wide 1720px Container) ── -->
<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8">
  <?= renderFlash() ?>

  <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
    
    <!-- LEFT COLUMN: MY PROFILE & JOB STATISTICS (4 Cols) -->
    <div class="lg:col-span-4 space-y-6">
      
      <!-- 1. MY PROFILE CARD -->
      <div class="glass-card rounded-2xl p-6 sm:p-7 border border-[#1E1E2E] shadow-xl space-y-5 bg-[#111118]">
        <div class="flex items-center justify-between">
          <span class="text-xs font-bold text-gray-400 uppercase tracking-wider">MY PROFILE</span>
          <span class="px-3 py-1 rounded-full text-xs font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
            $<?= number_format($totalAmount, 2) ?> Total
          </span>
        </div>

        <div class="flex items-center gap-4">
          <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-gold to-gold-dark flex items-center justify-center text-2xl font-black text-dark shadow-lg">
            <?= strtoupper(substr($user['name'], 0, 2)) ?>
          </div>
          <div>
            <h2 class="text-xl font-bold text-white"><?= htmlspecialchars($user['name']) ?></h2>
            <div class="text-sm font-mono text-gold font-bold mt-0.5">
              Customer ID (CID): <?= strtoupper($user['id']) ?>
            </div>
            <div class="text-xs text-gray-400 mt-1"><?= htmlspecialchars($user['company'] ?? 'Agency Studio') ?></div>
          </div>
        </div>

        <div class="pt-4 border-t border-[#1E1E2E] space-y-3 text-sm text-gray-300">
          <?php if (!empty($user['phone'])): ?>
          <div class="flex items-center gap-3">
            <span class="text-base text-pink-400">📞</span>
            <span class="font-mono text-gray-300">Phone: <?= htmlspecialchars($user['phone']) ?></span>
          </div>
          <?php endif; ?>

          <div class="flex items-center gap-3">
            <span class="text-base text-cyan-400">✉️</span>
            <span class="font-mono text-gray-300">Email: <?= htmlspecialchars($user['email']) ?></span>
          </div>

          <div class="flex items-center gap-3">
            <span class="text-base text-blue-400">💳</span>
            <span class="font-mono">Account Charges: 
              <?php if ($userBal > 0): ?>
                <strong class="text-red-400 font-black text-sm">US -$<?= number_format($userBal, 2) ?> (Due)</strong>
              <?php elseif ($userBal < 0): ?>
                <strong class="text-emerald-400 font-black text-sm">US +$<?= number_format(abs($userBal), 2) ?> (Credit)</strong>
              <?php else: ?>
                <strong class="text-blue-400 font-bold text-sm">US $0.00 (Clear)</strong>
              <?php endif; ?>
            </span>
          </div>
        </div>

        <a href="/profile.php" class="block w-full py-3 text-center text-xs font-bold text-gray-300 bg-[#1A1A24] hover:bg-[#242432] hover:text-white rounded-xl border border-[#2A2A3A] transition-colors uppercase tracking-wider">
          Edit Profile
        </a>
      </div>

      <!-- 2. JOB STATISTICS TABLE -->
      <div class="glass-card rounded-2xl p-6 sm:p-7 border border-[#1E1E2E] shadow-xl space-y-4 bg-[#111118]">
        <div class="flex items-center justify-between">
          <span class="text-xs font-bold text-gray-400 uppercase tracking-wider">JOB STATISTICS</span>
          <span class="text-xs font-mono text-gold font-bold"><?= $totalJobs ?> Total Jobs</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-sm">
            <thead>
              <tr class="text-gray-400 border-b border-[#1E1E2E] text-xs uppercase font-bold">
                <th class="pb-3">Type</th>
                <th class="pb-3 text-center">Jobs</th>
                <th class="pb-3 text-right">Amount</th>
                <th class="pb-3 text-center">Photos</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-[#1E1E2E]/60 text-xs font-mono">
              <?php foreach ($stats as $type => $data): ?>
              <tr class="hover:bg-white/[0.02]">
                <td class="py-2.5 font-sans font-semibold text-gray-300"><?= $type ?></td>
                <td class="py-2.5 text-center text-gray-400"><?= $data['jobs'] ?></td>
                <td class="py-2.5 text-right text-gold font-bold">$<?= number_format($data['amount'], 2) ?></td>
                <td class="py-2.5 text-center text-gray-400"><?= $data['photos'] ?></td>
              </tr>
              <?php endforeach; ?>
              <tr class="font-bold border-t-2 border-[#1E1E2E] text-white text-sm">
                <td class="pt-3.5 font-sans">Total</td>
                <td class="pt-3.5 text-center"><?= $totalJobs ?></td>
                <td class="pt-3.5 text-right text-gold font-mono">$<?= number_format($totalAmount, 2) ?></td>
                <td class="pt-3.5 text-center"><?= $totalPhotos ?></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

    </div>

    <!-- RIGHT COLUMN: NEW JOB (8 Cols - 3 Cards per Row) -->
    <div class="lg:col-span-8 space-y-6">
      <div>
        <div class="section-tag mb-1 text-xs">ORDER PLACEMENT</div>
        <h1 class="text-3xl sm:text-4xl font-black text-white">NEW JOB</h1>
        <p class="text-gray-400 text-sm mt-1">Select a service to create a job. Files are processed and delivered in 24 hours.</p>
      </div>

      <!-- 3-Column Luxury Cards Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        <?php foreach ($serviceCards as $svc): ?>
        <div class="glass-card rounded-2xl overflow-hidden border border-[#1E1E2E] hover:border-gold/50 transition-all flex flex-col group shadow-xl bg-[#111118]">
          <!-- Thumbnail Image with Badge -->
          <div class="relative aspect-[4/3] overflow-hidden bg-dark">
            <img loading="lazy" decoding="async" src="<?= $svc['img'] ?>" alt="<?= $svc['title'] ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" onerror="this.src='/assets/images/portfolio/hdr/1-after.jpg'">
            
            <span class="absolute top-3 left-3 px-2.5 py-0.5 rounded-md text-xs uppercase font-bold tracking-wider border <?= $svc['badge_cls'] ?>">
              <?= $svc['badge'] ?>
            </span>

            <?php if (!empty($svc['is_video'])): ?>
            <div class="absolute inset-0 bg-dark/20 flex items-center justify-center">
              <div class="w-11 h-11 rounded-full bg-white/90 shadow-xl flex items-center justify-center text-dark text-xl font-bold pl-0.5">
                ▶
              </div>
            </div>
            <?php endif; ?>
          </div>

          <!-- Card Body -->
          <div class="p-5 flex-1 flex flex-col justify-between space-y-4">
            <div>
              <h3 class="text-sm font-black text-white uppercase tracking-wider mb-2 group-hover:text-gold transition-colors">
                <?= $svc['title'] ?>
              </h3>
              <p class="text-xs text-gray-400 leading-relaxed">
                <?= $svc['subtitle'] ?>
              </p>
            </div>

            <!-- Price & Button -->
            <div class="pt-4 border-t border-[#1E1E2E] flex items-center justify-between">
              <span class="text-gold font-mono font-bold text-sm">
                <?= $svc['price'] ?> <span class="text-xs text-gray-500 font-normal"><?= $svc['unit'] ?></span>
              </span>

              <a href="<?= $svc['link'] ?>" class="btn-gold py-2 px-4 text-xs font-black shadow-glow rounded-xl uppercase tracking-wider">
                NEW JOB &rarr;
              </a>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

  </div>
</main>

<footer class="border-t border-[#1E1E2E] py-8 px-6 bg-[#0A0A0F] text-xs text-gray-500 text-center mt-16">
  <p>&copy; <?= date('Y') ?> Estate HDR. All rights reserved.</p>
</footer>
</body>
</html>
