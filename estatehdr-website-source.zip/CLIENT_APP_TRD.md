# Technical Requirements Document (TRD)
# Estate HDR — Client Mobile Application Architecture

**App Name:** Estate HDR Client App  
**Document Version:** 1.0.0  
**Status:** Approved for Engineering Implementation  
**Architecture:** Cross-Platform Native Mobile (Flutter / React Native)  
**Author:** Estate HDR Principal Mobile Architect  

---

## 1. Architecture & Technology Stack

```
┌────────────────────────────────────────────────────────┐
│               ESTATE HDR CLIENT APP (FLUTTER)          │
│ • UI Layer: Flutter 3.24+ (Impeller Rendering Engine)  │
│ • State Management: Flutter Riverpod 2.5               │
│ • Local Cache: Isar DB / SQLite (Encrypted)            │
│ • Secure Vault: flutter_secure_storage (Keychain)      │
│ • Network: Dio 5.5 + Retrofit REST Client              │
│ • Realtime: WebSockets (web_socket_channel)            │
│ • Push: Firebase Cloud Messaging (FCM) + APNs          │
└───────────────────────────┬────────────────────────────┘
                            │ HTTPS / WSS
                            ▼
┌────────────────────────────────────────────────────────┐
│               ESTATE HDR API GATEWAY & CLOUD           │
│ • REST API: PHP 8.3 / Node.js Engine                   │
│ • Media Storage: Cloudflare R2 / AWS S3 (Pre-signed)   │
│ • Push Hub: FCM Admin SDK + Apple Push HTTP/2          │
└────────────────────────────────────────────────────────┘
```

### 1.1 Recommended Technology Selection
- **Framework:** **Flutter 3.24+ (Dart 3.5)** for pixel-perfect cross-platform performance on iOS & Android. *(Alternative: React Native with Expo SDK 51+)*
- **State Management:** Riverpod 2.5 with code generation for immutable reactive state.
- **Image Rendering Engine:** Custom OpenGL / Metal shader for real-time split-screen Before/After image comparison.
- **Local Storage:** `Isar DB` for offline order metadata caching + `flutter_secure_storage` for biometric JWT storage.
- **Networking & Media:** `Dio 5.5` with interceptors for token auto-refresh and background chunked downloads.

---

## 2. Client Mobile REST API Specifications

### 2.1 Authentication & Profile Endpoints
```
POST /api/v1/client/auth/login
Request:  { "email": "agent@luxury.com", "password": "SecurePassword123", "device_type": "ios" }
Response: { "status": "success", "access_token": "eyJ...", "refresh_token": "dK9...", "user": { "id": 101, "name": "Sarah Jenkins", "wallet_balance": 350.00 } }

POST /api/v1/client/auth/biometric-login
Request:  { "device_token": "uuid-device-sig", "client_signature": "cryptographic_blob" }
Response: { "status": "success", "access_token": "eyJ..." }

POST /api/v1/client/user/device-token
Request:  { "fcm_token": "fcm_token_string...", "platform": "ios" }
Response: { "status": "success", "message": "Token registered" }
```

### 2.2 Order Lifecycle Endpoints
```
POST /api/v1/client/orders/create
Request: {
  "property_address": "742 Evergreen Terrace, Beverly Hills, CA",
  "service_type": "hdr_photo_editing",
  "photo_count": 25,
  "turnaround_tier": "standard_24h",
  "editing_preset": "natural_luxury",
  "raw_source_url": "https://www.dropbox.com/sh/abc123raws",
  "special_instructions": "Please brighten windows in living room and green front lawn.",
  "payment_method": "wallet"
}
Response: {
  "status": "success",
  "order_id": 4892,
  "order_number": "EHDR-2026-4892",
  "total_amount": 25.00,
  "sla_deadline_at": "2026-09-17T14:00:00Z"
}

GET /api/v1/client/orders/{id}
Response: {
  "order_id": 4892,
  "status": "ready_for_review",
  "sla_deadline_at": "2026-09-17T14:00:00Z",
  "deliverables": [
    {
      "id": 8901,
      "photo_index": 1,
      "title": "Front Exterior",
      "before_thumb": "https://cdn.estatehdr.com/deliverables/4892/1-before-thumb.webp",
      "after_thumb": "https://cdn.estatehdr.com/deliverables/4892/1-after-thumb.webp",
      "high_res_mls": "https://cdn.estatehdr.com/deliverables/4892/1-mls.webp",
      "high_res_print": "https://cdn.estatehdr.com/deliverables/4892/1-print.jpg"
    }
  ]
}
```

### 2.3 Visual Amendment Submission API
```
POST /api/v1/client/orders/{id}/amendments
Request: {
  "deliverable_id": 8901,
  "pin_x_percent": 42.50,
  "pin_y_percent": 68.20,
  "category_tag": "window_masking",
  "instruction_note": "Please remove glare on window reflection.",
  "voice_memo_base64": "data:audio/m4a;base64,..."
}
Response: {
  "status": "success",
  "amendment_id": 341,
  "status": "in_revision",
  "estimated_delivery": "2026-09-16T16:00:00Z"
}
```

---

## 3. Interactive Before/After Shader & Touch Architecture

The Before/After comparison tool uses a custom GPU fragment shader rendered via Flutter `CustomPainter` / React Native Skia.

```
Coordinate Normalization & Shader Pipeline:
[Touch Event (X, Y)] ──► [Normalize (0.0 to 1.0)] ──► [Shader Uniform: u_split_position]
                                                                  │
               ┌──────────────────────────────────────────────────┴────────────────────────────────┐
               ▼                                                                                   ▼
   [Fragment X < u_split_position]                                                     [Fragment X >= u_split_position]
   Render Before Texture (RAW Input)                                                   Render After Texture (HDR Deliverable)
```

- **Synchronized Matrix Transformations:** A single shared `TransformationController` drives both Before and After texture matrices so panning and zooming (up to 4.0x) remains 100% in lockstep with zero offset jitter.

---

## 4. Media Download & Camera Roll Pipeline

```
[Tap "Save All to Camera Roll"]
               │
               ▼
[Request Pre-Signed Download URLs] ──► [Dio Chunked Concurrent Downloader (3 Parallel Workers)]
                                                                  │
                                                                  ▼
[Write to Temp App Sandbox] ──► [gallery_saver / image_gallery_saver Plugin]
                                                                  │
                                                                  ▼
[Create Album: "Estate HDR - {Property Address}"] ──► [Write Photos + EXIF Tags]
```

---

## 5. Client Push Notification Schema (FCM v1 JSON)

```json
{
  "message": {
    "token": "dK9s_client_fcm_token...",
    "notification": {
      "title": "✨ Your Photos are Ready!",
      "body": "742 Evergreen Terrace (25 Photos) is ready for review. Tap to preview Before/After."
    },
    "data": {
      "click_action": "FLUTTER_NOTIFICATION_CLICK",
      "type": "ORDER_READY",
      "order_id": "4892",
      "property_address": "742 Evergreen Terrace",
      "thumbnail_url": "https://cdn.estatehdr.com/deliverables/4892/1-after-thumb.webp"
    },
    "apns": {
      "payload": {
        "aps": {
          "sound": "gold_chime.aiff",
          "badge": 1
        }
      }
    }
  }
}
```

---

## 6. Security & CI/CD Pipeline

- **Certificate Pinning:** Enforce SHA-256 fingerprint matching against `api.estatehdr.com`.
- **Biometric Security:** Cryptographic token signing stored in iOS Keychain (`kSecAttrAccessibleWhenUnlockedThisDeviceOnly`) and Android KeyStore.
- **Automated CI/CD:** GitHub Actions building `.ipa` via Fastlane to Apple TestFlight and `.aab` to Google Play Internal App Sharing on every release branch push.
