<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';

$sentSuccess = false;
$errorMsg    = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    
    $guardResult = ehdr_process_and_guard_lead($_POST, 'contact_form', false);
    if (!$guardResult['success']) {
        $errorMsg = $guardResult['error'];
    } else {
        $data = $guardResult['sanitized'];
        saveLead($data['name'], $data['email'], $data['phone'], $data['service'], $data['cloud_link'], $data['message']);
        $sentSuccess = true;
    }
}

$seo = getPageSeo('contact') ?: [
    'meta_title'       => 'Contact Us — Estate HDR Support & Inquiries',
    'meta_description' => 'Get in touch with the Estate HDR support team. 24-hour turnaround guaranteed. WhatsApp: +44 770 606 8176, Email: info@estatehdr.com',
    'canonical_url'    => rtrim(BASE_URL, '/') . '/contact',
    'og_image'         => BASE_URL . '/assets/images/portfolio/hdr/2-after.jpg',
    'robots'           => 'index, follow',
    'schema_json'      => ''
];

$pageTitle = htmlspecialchars($seo['meta_title'] ?? 'Contact Us — Estate HDR');
$pageDesc  = htmlspecialchars($seo['meta_description'] ?? '');
$canonUrl  = htmlspecialchars(!empty($seo['canonical_url']) && !str_ends_with($seo['canonical_url'], '.php') ? $seo['canonical_url'] : (rtrim(BASE_URL, '/') . '/contact'));
$ogImage   = htmlspecialchars(!empty($seo['og_image']) ? $seo['og_image'] : (BASE_URL . '/assets/images/portfolio/hdr/2-after.jpg'));
$robots    = htmlspecialchars($seo['robots'] ?? 'index, follow');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<meta name="description" content="<?= $pageDesc ?>">
<meta name="robots" content="<?= $robots ?>">
<link rel="canonical" href="<?= $canonUrl ?>">
<!-- Open Graph -->
<meta property="og:type"        content="website">
<meta property="og:url"         content="<?= $canonUrl ?>">
<meta property="og:title"       content="<?= $pageTitle ?>">
<meta property="og:description" content="<?= $pageDesc ?>">
<meta property="og:image"       content="<?= $ogImage ?>">
<?php if (!empty($seo['schema_json'])): ?>
<!-- Dynamic JSON-LD Schema -->
<script type="application/ld+json" nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
<?= $seo['schema_json'] ?>
</script>
<?php endif; ?>
<!-- Fonts -->
<?= renderSeoHeadTags() ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<?= renderSeoHeadTags() ?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap" onload="this.onload=null;this.rel='stylesheet'">
<noscript>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap">
</noscript>
<link rel="stylesheet" href="/assets/css/bundle.css?v=<?= file_exists(ROOT_PATH . '/assets/css/bundle.css') ? filemtime(ROOT_PATH . '/assets/css/bundle.css') : time() ?>">
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/includes/public-header.php'; ?>

<main class="flex-1 pt-32 pb-20 px-6 max-w-7xl mx-auto w-full">
  <div class="text-center max-w-2xl mx-auto mb-16">
    <div class="section-tag mb-3">24/7 Global Support</div>
    <h1 class="text-4xl sm:text-5xl font-black text-white tracking-tight">Let's Elevate Your Listings</h1>
    <p class="text-gray-400 text-sm mt-4">Have questions about our editing workflow, volume billing, or enterprise API? Reach out to our dedicated team anytime.</p>
  </div>

  <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
    
    <!-- Contact Info Cards (5 Cols) -->
    <div class="lg:col-span-5 space-y-6">
      
      <!-- Card 1: Direct Support -->
      <div class="glass-card rounded-2xl p-6 border border-dark-border shadow-xl space-y-4">
        <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider">Direct Channels</h3>
        
        <div class="space-y-3 text-xs">
          <a href="https://wa.me/447706068176" target="_blank" rel="noopener noreferrer" class="flex items-center gap-3.5 p-3 rounded-xl bg-dark/60 border border-dark-border hover:border-emerald-500/50 transition-all group">
            <div class="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-105 transition-transform text-lg">
              💬
            </div>
            <div>
              <div class="text-white font-bold">WhatsApp Direct Support</div>
              <div class="text-emerald-400 font-mono">+44 770 606 8176 <span class="text-gray-500">(Instant)</span></div>
            </div>
          </a>

          <a href="mailto:info@estatehdr.com" class="flex items-center gap-3.5 p-3 rounded-xl bg-dark/60 border border-dark-border hover:border-gold/50 transition-all group">
            <div class="w-10 h-10 rounded-xl bg-gold/10 border border-gold/30 flex items-center justify-center text-gold group-hover:scale-105 transition-transform text-lg">
              ✉️
            </div>
            <div>
              <div class="text-white font-bold">Official Email Support</div>
              <div class="text-gold font-mono">info@estatehdr.com</div>
            </div>
          </a>
        </div>
      </div>

      <!-- Card 2: Official Social Profiles -->
      <div class="glass-card rounded-2xl p-6 border border-dark-border shadow-xl space-y-4">
        <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider">Official Social Channels</h3>
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <!-- Facebook -->
          <a href="<?= FACEBOOK_LINK ?>" target="_blank" rel="noopener noreferrer" class="flex flex-col items-center justify-center p-3.5 rounded-xl bg-dark/60 border border-dark-border hover:border-blue-500/50 transition-all group text-center">
            <div class="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform mb-2">
              <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
            </div>
            <div class="text-white font-bold text-xs">Facebook</div>
            <div class="text-gray-500 text-[10px]">@estatehdr1</div>
          </a>

          <!-- Instagram -->
          <a href="<?= INSTAGRAM_LINK ?>" target="_blank" rel="noopener noreferrer" class="flex flex-col items-center justify-center p-3.5 rounded-xl bg-dark/60 border border-dark-border hover:border-pink-500/50 transition-all group text-center">
            <div class="w-10 h-10 rounded-xl bg-pink-500/10 border border-pink-500/30 flex items-center justify-center text-pink-400 group-hover:scale-110 transition-transform mb-2">
              <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
            </div>
            <div class="text-white font-bold text-xs">Instagram</div>
            <div class="text-gray-500 text-[10px]">@estate_hdr</div>
          </a>

          <!-- LinkedIn -->
          <a href="<?= LINKEDIN_LINK ?>" target="_blank" rel="noopener noreferrer" class="flex flex-col items-center justify-center p-3.5 rounded-xl bg-dark/60 border border-dark-border hover:border-blue-400/50 transition-all group text-center">
            <div class="w-10 h-10 rounded-xl bg-blue-400/10 border border-blue-400/30 flex items-center justify-center text-blue-300 group-hover:scale-110 transition-transform mb-2">
              <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
            </div>
            <div class="text-white font-bold text-xs">LinkedIn</div>
            <div class="text-gray-500 text-[10px]">Company Page</div>
          </a>
        </div>
      </div>

      <!-- Card 3: Guarantee Badges -->
      <div class="glass-card rounded-2xl p-6 border border-dark-border shadow-xl space-y-4">
        <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider">Production Guarantees</h3>
        <div class="space-y-2.5 text-xs text-gray-300">
          <div class="flex items-center gap-2.5">
            <span class="text-gold font-bold">✓</span> <span><strong>24-Hour Guaranteed Turnaround:</strong> On every residential HDR job.</span>
          </div>
          <div class="flex items-center gap-2.5">
            <span class="text-gold font-bold">✓</span> <span><strong>Unlimited Free Tweaks:</strong> Amendments processed within 2-4 hours.</span>
          </div>
          <div class="flex items-center gap-2.5">
            <span class="text-gold font-bold">✓</span> <span><strong>Enterprise Data Privacy:</strong> High-bandwidth secure cloud storage.</span>
          </div>
        </div>
      </div>

    </div>

    <!-- Inquiry Form (7 Cols) -->
    <div class="lg:col-span-7 glass-card rounded-2xl p-8 border border-dark-border shadow-2xl">
      <h2 class="text-xl font-bold text-white mb-2">Send Us an Inquiry</h2>
      <p class="text-gray-400 text-xs mb-6">Fill in your requirements below and our team will get back to you within 30 minutes.</p>

      <?php if ($sentSuccess): ?>
      <div class="p-6 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-center mb-6">
        <div class="text-3xl mb-2">🎉</div>
        <h4 class="text-base font-bold text-emerald-400">Inquiry Received Successfully!</h4>
        <p class="text-xs text-gray-300 mt-1">Thank you for reaching out. An Estate HDR retouching director will respond to your email shortly.</p>
      </div>
      <?php endif; ?>

      <?php if (!empty($errorMsg)): ?>
      <div class="p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs mb-6">
        <?= htmlspecialchars($errorMsg) ?>
      </div>
      <?php endif; ?>

      <form method="POST" class="space-y-4" onsubmit="if(this.dataset.submitted){return false;} this.dataset.submitted='true'; const btn=this.querySelector('button[type=submit]'); if(btn){ btn.style.pointerEvents='none'; btn.style.opacity='0.7'; btn.innerHTML='<span class=\'inline-block animate-spin mr-2\'>⏳</span> Sending Message...'; } return true;">
        <?= csrfField() ?>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label for="contact-name" class="form-label text-xs">Your Full Name <span class="text-red-400">*</span></label>
            <input type="text" id="contact-name" name="name" class="form-input text-xs" placeholder="e.g. Craig Westerman" required>
          </div>

          <div>
            <label for="contact-email" class="form-label text-xs">Email Address <span class="text-red-400">*</span></label>
            <input type="email" id="contact-email" name="email" class="form-input text-xs" placeholder="name@agency.com" required>
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label for="contact-phone" class="form-label text-xs">Phone / WhatsApp</label>
            <input type="text" id="contact-phone" name="phone" class="form-input text-xs" placeholder="+1 (555) 000-0000">
          </div>

          <div>
            <label for="contact-service" class="form-label text-xs">Service Needed</label>
            <select id="contact-service" name="service" class="form-select text-xs">
              <option value="HDR Photo Editing">HDR Photo Editing (From $0.50)</option>
              <option value="Virtual Staging">Virtual Staging ($10.00)</option>
              <option value="Floor Plans & 3D Tours">2D / 3D Floor Plans ($10.00)</option>
              <option value="Item Removal">Item Removal / Decluttering ($2.00)</option>
              <option value="Day to Dusk">Day to Dusk ($10.00)</option>
              <option value="Virtual Twilight">Virtual Twilight ($10.00)</option>
              <option value="Custom Enterprise Inquiry">Custom Enterprise Retouching</option>
            </select>
          </div>
        </div>

        <div>
          <label for="contact-cloud-link" class="form-label text-xs">Sample Photos / Cloud Storage Link (Optional)</label>
          <input type="url" id="contact-cloud-link" name="cloud_link" class="form-input text-xs" placeholder="https://www.dropbox.com/sh/... or WeTransfer link">
        </div>

        <div>
          <label for="contact-message" class="form-label text-xs">Message / Editing Instructions <span class="text-red-400">*</span></label>
          <textarea id="contact-message" name="message" rows="4" class="form-input text-xs resize-y" placeholder="Tell us about your volume, style preferences, or any specific requirements..." required></textarea>
        </div>

        <?= ehdr_render_honeypot() ?>
        <?= ehdr_render_turnstile('contact_form') ?>

        <button type="submit" class="btn-gold w-full py-3 text-xs font-bold shadow-glow">
          Submit Message &rarr;
        </button>
      </form>
    </div>

  </div>
</main>

<footer class="border-t border-dark-border bg-dark-card py-10 px-6 text-xs text-gray-400 text-center font-medium" role="contentinfo">
  <div class="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
    <div>&copy; <?= date('Y') ?> Estate HDR Retouching. All rights reserved.</div>
    <div class="flex items-center gap-6">
      <a href="/terms" class="hover:text-gold">Terms</a>
      <a href="/privacy" class="hover:text-gold">Privacy</a>
      <a href="/sitemap.xml" class="hover:text-gold">Sitemap.xml</a>
      <a href="/blog" class="hover:text-gold">Blog</a>
      <a href="/contact" class="hover:text-gold">Contact</a>
    </div>
  </div>
</footer>

<?php require_once __DIR__ . '/includes/chat-widgets.php'; ?>
</body>
</html>
