<?php
/**
 * Estate HDR - Client Knowledge Base & Technical Guides
 * Enterprise Layer: Knowledge Base & Documentation Portal
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
$currentUser = currentUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Knowledge Base &amp; Shooting Guides — Estate HDR</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/app.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-[#0B0E14] text-gray-200 min-h-screen">
    <!-- Header -->
    <header class="bg-[#121721] border-b border-gray-800 px-6 py-4 flex items-center justify-between">
        <div class="flex items-center gap-4">
            <a href="/client/app.php" class="text-gray-400 hover:text-gold transition text-xs font-semibold">
                <i class="fas fa-arrow-left"></i> Client Portal
            </a>
            <div class="h-5 w-px bg-gray-700"></div>
            <h1 class="text-base font-bold text-white flex items-center gap-2">
                <i class="fas fa-book-bookmark text-gold"></i> Estate HDR Knowledge Base &amp; Guides
            </h1>
        </div>
        <div class="text-xs text-gray-400">
            Enterprise Client Support
        </div>
    </header>

    <main class="max-w-[1850px] mx-auto px-4 sm:px-8 py-8 space-y-8">
        <!-- Search bar -->
        <div class="text-center py-6">
            <h2 class="text-2xl font-black text-white">How can we help your photography studio?</h2>
            <p class="text-xs text-gray-400 mt-1">Explore our bracketing guidelines, turnaround SLAs, and API documentation.</p>
            <div class="max-w-md mx-auto mt-4 relative">
                <input type="text" id="kbSearch" placeholder="Search guides, camera settings, turnaround times..." class="w-full bg-[#121721] border border-gray-700 rounded-xl px-4 py-2.5 text-xs text-white pl-10 focus:outline-none focus:border-gold">
                <i class="fas fa-search absolute left-3.5 top-3.5 text-gray-500 text-xs"></i>
            </div>
        </div>

        <!-- Topics Grid -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-[#121721] p-6 rounded-2xl border border-gray-800 space-y-3">
                <div class="w-10 h-10 rounded-xl bg-gold/10 text-gold flex items-center justify-center font-bold text-base">
                    📷
                </div>
                <h3 class="text-sm font-bold text-white">Bracketing Best Practices</h3>
                <p class="text-xs text-gray-400">Recommended 3 or 5 exposure brackets (-2, 0, +2 EV). Keep aperture at f/7.1 - f/9 for corner-to-corner architectural sharpness.</p>
                <a href="#bracketing" class="text-xs text-gold font-semibold inline-block hover:underline">Read Guide &rarr;</a>
            </div>

            <div class="bg-[#121721] p-6 rounded-2xl border border-gray-800 space-y-3">
                <div class="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center font-bold text-base">
                    ⏱️
                </div>
                <h3 class="text-sm font-bold text-white">Turnaround SLAs &amp; Schedules</h3>
                <p class="text-xs text-gray-400">All standard packages deliver within 24 hours. Rush 12h and Urgent 6h delivery options are available at order submission.</p>
                <a href="#turnaround" class="text-xs text-gold font-semibold inline-block hover:underline">View SLA Rules &rarr;</a>
            </div>

            <div class="bg-[#121721] p-6 rounded-2xl border border-gray-800 space-y-3">
                <div class="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold text-base">
                    🔌
                </div>
                <h3 class="text-sm font-bold text-white">Real Estate Media REST API</h3>
                <p class="text-xs text-gray-400">Connect your custom CRM or field app directly using our scoped Bearer API keys and webhook event dispatchers.</p>
                <a href="#api" class="text-xs text-gold font-semibold inline-block hover:underline">API Reference &rarr;</a>
            </div>
        </div>

        <!-- FAQ Accordion -->
        <div class="bg-[#121721] p-6 rounded-2xl border border-gray-800 space-y-4">
            <h3 class="text-sm font-black uppercase text-white tracking-wider">Frequently Asked Questions</h3>
            <div class="space-y-3 text-xs">
                <div class="p-3 bg-dark/60 rounded-xl border border-gray-800">
                    <div class="font-bold text-white">How do free trial orders work?</div>
                    <div class="text-gray-400 mt-1">First-time clients receive complimentary trial credits without requiring a credit card or incurring false dues on the ledger.</div>
                </div>
                <div class="p-3 bg-dark/60 rounded-xl border border-gray-800">
                    <div class="font-bold text-white">How do I request revisions or tweaks?</div>
                    <div class="text-gray-400 mt-1">Use our interactive Proofing portal (<span class="text-gold font-mono">client/review.php</span>) to drop pinpoint pins right onto windows, ceilings, or grass.</div>
                </div>
            </div>
        </div>
    </main>
</body>
</html>
