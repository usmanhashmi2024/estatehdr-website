<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$clientUser = $_SESSION['client_user'] ?? [
    'name'           => 'John Abraham',
    'company'        => 'LuxeApart (A-1)',
    'email'          => 'abraham@luxeapart.com',
    'phone'          => '555-0199',
    'role'           => 'Property manager',
    'active_shoots'  => 3,
    'total_delivered'=> 140,
    'sla_rate'       => '99.4%',
    'balance_due'    => 65.00,
    'avatar_initials'=> 'JA',
];

$orders = function_exists('getOrders') ? getOrders() : [];
$clientOrders = array_filter($orders, function($o) use ($clientUser) {
    return strtolower($o['client_email'] ?? '') === strtolower($clientUser['email'] ?? '');
});

if (empty($clientOrders)) {
    $clientOrders = [
        [
            'id'            => 'EH-7721',
            'property_name' => 'Whispering Pines House',
            'address'       => 'Brooklyn, NY 11209',
            'service'       => '5-Bracket HDR Fusion',
            'status'        => 'delivered',
            'created_at'    => '2026-09-15 14:30',
            'sla_remaining' => 'Delivered (12h SLA)',
            'photos_count'  => 28,
            'price'         => 25000,
            'beds'          => 6,
            'baths'         => 5,
            'sqft'          => 2660,
            'for_sale'      => true,
            'hero_img'      => 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=900',
            'before_img'    => 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=900',
            'after_img'     => 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=900'
        ],
        [
            'id'            => 'EH-7729',
            'property_name' => 'Penthouse 4B, Manhattan',
            'address'       => 'New York, NY 10001',
            'service'       => 'Day to Dusk + Sky Replacement',
            'status'        => 'editing',
            'created_at'    => '2026-09-16 02:15',
            'sla_remaining' => '04h 45m left on SLA',
            'photos_count'  => 14,
            'price'         => 12900,
            'beds'          => 4,
            'baths'         => 3,
            'sqft'          => 1820,
            'for_sale'      => true,
            'hero_img'      => 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=900',
            'before_img'    => 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=900',
            'after_img'     => 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=900'
        ],
        [
            'id'            => 'EH-7733',
            'property_name' => 'Sunset Ridge Villa',
            'address'       => 'Malibu, CA 90265',
            'service'       => 'Virtual Staging + HDR',
            'status'        => 'pending',
            'created_at'    => '2026-09-16 08:00',
            'sla_remaining' => '10h 00m left on SLA',
            'photos_count'  => 22,
            'price'         => 10000,
            'beds'          => 5,
            'baths'         => 4,
            'sqft'          => 3100,
            'for_sale'      => true,
            'hero_img'      => 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=900',
            'before_img'    => 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=900',
            'after_img'     => 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=900'
        ]
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
  <title>EstateHDR — Client Portal</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <style nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
    /* ── RESET & BASE ─────────────────────────────────────── */
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    :root {
      --bg:           #EDEEF7;
      --surface:      #FFFFFF;
      --surface2:     #F4F5FB;
      --border:       #E8E9F2;
      --primary:      #5B6BF8;
      --primary-dark: #4A5ADE;
      --accent-blue:  #5B6BF8;
      --accent-green: #A8D060;
      --text-h:       #14142B;
      --text-p:       #6E7191;
      --text-muted:   #A0A3BD;
      --shadow-sm:    0 2px 8px rgba(91,107,248,0.08);
      --shadow-md:    0 4px 24px rgba(91,107,248,0.12);
      --shadow-lg:    0 8px 40px rgba(91,107,248,0.18);
      --radius-sm:    10px;
      --radius-md:    16px;
      --radius-lg:    24px;
      --radius-xl:    32px;
      --nav-h:        72px;
    }
    html, body {
      height: 100%;
      font-family: 'Inter', sans-serif;
      background: var(--bg);
      color: var(--text-h);
      -webkit-font-smoothing: antialiased;
      overflow: hidden;
    }
    #app {
      display: flex;
      flex-direction: column;
      height: 100vh;
      max-width: 430px;
      margin: 0 auto;
      position: relative;
      overflow: hidden;
    }

    /* ── STATUS BAR SAFE AREA ─────────────────────────────── */
    .safe-top { height: env(safe-area-inset-top, 28px); background: var(--bg); }

    /* ── SCREEN CONTAINER ─────────────────────────────────── */
    .screen {
      display: none;
      flex-direction: column;
      flex: 1;
      overflow: hidden;
    }
    .screen.active { display: flex; }
    .scroll-area {
      flex: 1;
      overflow-y: auto;
      -webkit-overflow-scrolling: touch;
      padding-bottom: calc(var(--nav-h) + 24px);
    }
    .scroll-area::-webkit-scrollbar { display: none; }

    /* ── TOP APP BAR ──────────────────────────────────────── */
    .app-bar {
      display: flex;
      align-items: center;
      padding: 14px 20px 10px;
      background: var(--bg);
      gap: 12px;
      position: relative;
      z-index: 10;
    }
    .avatar-circle {
      width: 44px; height: 44px;
      border-radius: 50%;
      background: var(--primary);
      color: #fff;
      font-weight: 700;
      font-size: 15px;
      display: flex; align-items: center; justify-content: center;
      flex-shrink: 0;
      overflow: hidden;
    }
    .avatar-circle img { width: 100%; height: 100%; object-fit: cover; }
    .app-bar-info { flex: 1; }
    .app-bar-name { font-size: 17px; font-weight: 700; color: var(--text-h); line-height: 1.2; }
    .app-bar-role { font-size: 12px; color: var(--text-p); font-weight: 400; }
    .icon-btn {
      width: 38px; height: 38px;
      border-radius: 50%;
      background: var(--surface);
      border: none;
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
      box-shadow: var(--shadow-sm);
      transition: transform 0.15s;
    }
    .icon-btn:active { transform: scale(0.92); }
    .icon-btn svg { width: 18px; height: 18px; }

    /* ── SECTION HEADERS ──────────────────────────────────── */
    .section { padding: 0 20px; margin-top: 20px; }
    .section-header {
      display: flex; align-items: center; justify-content: space-between;
      margin-bottom: 14px;
    }
    .section-title { font-size: 18px; font-weight: 700; color: var(--text-h); }
    .view-all {
      font-size: 13px; font-weight: 500; color: var(--primary);
      display: flex; align-items: center; gap: 4px;
      text-decoration: none; cursor: pointer; background: none; border: none;
    }

    /* ── PROPERTY SUMMARY 2×2 MATRIX ─────────────────────── */
    .summary-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
    }
    .summary-card {
      background: var(--surface);
      border-radius: var(--radius-md);
      padding: 16px;
      box-shadow: var(--shadow-sm);
    }
    .summary-icon-box {
      width: 36px; height: 36px;
      border-radius: var(--radius-sm);
      display: flex; align-items: center; justify-content: center;
      margin-bottom: 10px;
    }
    .icon-blue   { background: #EEF0FE; }
    .icon-indigo { background: #EEEEFE; }
    .icon-green  { background: #EDFBF3; }
    .icon-amber  { background: #FEF9EC; }
    .summary-label { font-size: 12px; color: var(--text-p); font-weight: 500; margin-bottom: 4px; }
    .summary-value { font-size: 22px; font-weight: 800; color: var(--text-h); line-height: 1; }
    .summary-value .muted { color: var(--text-muted); font-weight: 500; font-size: 18px; }

    /* ── OCCUPANCY RATES CHART ────────────────────────────── */
    .chart-card {
      background: var(--surface);
      border-radius: var(--radius-md);
      padding: 18px;
      box-shadow: var(--shadow-sm);
    }
    .chart-header {
      display: flex; align-items: center; justify-content: space-between;
      margin-bottom: 16px;
    }
    .chart-title { font-size: 16px; font-weight: 700; color: var(--text-h); }
    .chart-dropdown {
      font-size: 13px; color: var(--text-p); font-weight: 500;
      display: flex; align-items: center; gap: 4px; cursor: pointer;
      background: none; border: none;
    }
    .bar-chart { display: flex; align-items: flex-end; gap: 10px; height: 100px; }
    .bar-group { display: flex; flex-direction: column; align-items: center; flex: 1; gap: 6px; }
    .bar-wrap { width: 100%; display: flex; align-items: flex-end; justify-content: center; height: 85px; }
    .bar {
      width: 26px;
      border-radius: 6px 6px 0 0;
      transition: height 0.6s cubic-bezier(.4,0,.2,1);
    }
    .bar-month { font-size: 11px; color: var(--text-muted); font-weight: 500; }
    .y-labels {
      display: flex; flex-direction: column; justify-content: space-between;
      height: 85px; margin-right: 6px;
      font-size: 11px; color: var(--text-muted); font-weight: 500;
    }

    /* ── RECENT ACTIVITY ──────────────────────────────────── */
    .activity-item {
      display: flex; align-items: center;
      background: var(--surface);
      border-radius: var(--radius-md);
      padding: 14px 16px;
      gap: 14px;
      box-shadow: var(--shadow-sm);
      margin-bottom: 10px;
    }
    .activity-icon {
      width: 42px; height: 42px;
      border-radius: var(--radius-sm);
      background: var(--surface2);
      display: flex; align-items: center; justify-content: center;
      flex-shrink: 0;
    }
    .activity-text { flex: 1; }
    .activity-title { font-size: 14px; font-weight: 600; color: var(--text-h); margin-bottom: 2px; }
    .activity-sub { font-size: 12px; color: var(--text-p); }
    .activity-arrow { color: var(--text-muted); }

    /* ── BOTTOM NAV ───────────────────────────────────────── */
    .bottom-nav {
      position: absolute;
      bottom: 0; left: 0; right: 0;
      height: calc(var(--nav-h) + env(safe-area-inset-bottom, 0px));
      padding-bottom: env(safe-area-inset-bottom, 0px);
      background: var(--surface);
      border-top: 1px solid var(--border);
      display: flex;
      align-items: center;
      justify-content: space-around;
      z-index: 100;
    }
    .nav-btn {
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      gap: 4px;
      padding: 10px 14px;
      cursor: pointer;
      background: none; border: none;
      transition: transform 0.15s;
    }
    .nav-btn:active { transform: scale(0.9); }
    .nav-icon {
      width: 24px; height: 24px;
      display: flex; align-items: center; justify-content: center;
    }
    .nav-label { font-size: 10px; font-weight: 600; }
    .nav-btn.active .nav-label, .nav-btn.active svg { color: var(--primary); }
    .nav-btn:not(.active) .nav-label, .nav-btn:not(.active) svg { color: var(--text-muted); }
    .nav-btn.active .nav-icon {
      background: #EEF0FE;
      border-radius: 12px;
    }

    /* ─── SEARCH SCREEN ───────────────────────────────────── */
    .search-bar-wrap {
      padding: 12px 20px 8px;
      background: var(--bg);
    }
    .search-bar {
      display: flex; align-items: center; gap: 10px;
      background: var(--surface);
      border-radius: var(--radius-md);
      padding: 12px 16px;
      box-shadow: var(--shadow-sm);
    }
    .search-bar input {
      border: none; outline: none; flex: 1;
      font-family: 'Inter', sans-serif;
      font-size: 14px; color: var(--text-h);
      background: transparent;
    }
    .search-bar input::placeholder { color: var(--text-muted); }
    .map-toggle-btn {
      width: 36px; height: 36px;
      border-radius: 10px;
      background: var(--surface);
      border: 1px solid var(--border);
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
    }

    /* Filter chips */
    .filter-chips {
      display: flex; gap: 8px;
      padding: 6px 20px 10px;
      overflow-x: auto;
    }
    .filter-chips::-webkit-scrollbar { display: none; }
    .chip {
      display: flex; align-items: center; gap: 6px;
      padding: 8px 14px;
      border-radius: 100px;
      font-size: 13px; font-weight: 600;
      white-space: nowrap;
      cursor: pointer;
      border: none;
      transition: background 0.2s, color 0.2s;
      flex-shrink: 0;
    }
    .chip.primary-chip {
      background: #14142B; color: #fff;
    }
    .chip.outline-chip {
      background: var(--surface); color: var(--text-h);
      border: 1px solid var(--border);
    }
    .chip.active-chip {
      background: var(--primary); color: #fff;
    }

    /* Results bar */
    .results-bar {
      display: flex; align-items: center; justify-content: space-between;
      padding: 4px 20px 8px;
    }
    .results-count { font-size: 13px; color: var(--text-p); font-weight: 500; }
    .results-actions { display: flex; gap: 12px; }
    .results-action {
      font-size: 13px; font-weight: 600; color: var(--text-h);
      display: flex; align-items: center; gap: 4px;
      cursor: pointer; background: none; border: none;
    }

    /* ── PROPERTY CARDS ───────────────────────────────────── */
    .prop-card {
      background: var(--surface);
      border-radius: var(--radius-lg);
      overflow: hidden;
      box-shadow: var(--shadow-md);
      margin: 0 20px 16px;
    }
    .prop-card-img {
      position: relative;
      width: 100%;
      height: 200px;
    }
    .prop-card-img img {
      width: 100%; height: 100%; object-fit: cover;
    }
    .for-sale-badge {
      position: absolute; top: 12px; left: 12px;
      background: var(--accent-green);
      color: #1a2e00;
      font-size: 11px; font-weight: 700;
      padding: 4px 10px;
      border-radius: 100px;
    }
    .heart-btn {
      position: absolute; top: 10px; right: 12px;
      width: 34px; height: 34px;
      border-radius: 50%;
      background: rgba(255,255,255,0.9);
      border: none;
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
    }
    .heart-btn.liked svg { fill: #E53E6B; color: #E53E6B; }
    .prop-card-body { padding: 14px 16px 18px; }
    .prop-address-row { display: flex; align-items: center; gap: 6px; margin-bottom: 4px; }
    .prop-address { font-size: 12px; color: var(--text-p); }
    .prop-name { font-size: 16px; font-weight: 700; color: var(--text-h); margin-bottom: 10px; }
    .prop-price { font-size: 22px; font-weight: 800; color: var(--text-h); float: right; }
    .prop-stats { display: flex; gap: 16px; margin-top: 4px; }
    .prop-stat { display: flex; align-items: center; gap: 5px; font-size: 13px; color: var(--text-p); }
    .prop-stat svg { width: 14px; height: 14px; color: var(--text-muted); }

    /* ── MAP VIEW ─────────────────────────────────────────── */
    .map-container {
      position: relative;
      height: 300px;
      background: #E8EDF2;
      overflow: hidden;
      margin: 0 20px 16px;
      border-radius: var(--radius-lg);
    }
    .map-bg {
      width: 100%; height: 100%;
      background: linear-gradient(135deg, #e0e6ef 0%, #c8d3e0 40%, #d8e1ea 100%);
      position: relative;
    }
    /* Pseudo map grid lines */
    .map-grid-h, .map-grid-v {
      position: absolute; background: rgba(255,255,255,0.4);
    }
    .map-grid-h { height: 1px; left: 0; right: 0; }
    .map-grid-v { width: 1px; top: 0; bottom: 0; }
    .map-bubble {
      position: absolute;
      background: var(--surface);
      border-radius: 100px;
      padding: 6px 12px;
      font-size: 13px; font-weight: 700; color: var(--text-h);
      box-shadow: var(--shadow-md);
      cursor: pointer;
      white-space: nowrap;
    }
    .map-bubble::after {
      content: '';
      position: absolute;
      bottom: -5px; left: 50%; transform: translateX(-50%);
      width: 0; height: 0;
      border-left: 5px solid transparent;
      border-right: 5px solid transparent;
      border-top: 6px solid var(--surface);
    }
    .map-bubble.selected {
      background: var(--primary);
      color: #fff;
    }
    .map-bubble.selected::after { border-top-color: var(--primary); }
    /* Map property card overlay */
    .map-prop-card {
      position: absolute;
      bottom: 12px; left: 12px; right: 12px;
      background: var(--surface);
      border-radius: var(--radius-md);
      display: flex; gap: 12px;
      padding: 12px;
      box-shadow: var(--shadow-lg);
    }
    .map-prop-img {
      width: 80px; height: 72px;
      border-radius: var(--radius-sm);
      object-fit: cover;
    }
    .map-prop-info { flex: 1; }
    .map-prop-badge {
      background: var(--accent-green);
      color: #1a2e00;
      font-size: 10px; font-weight: 700;
      padding: 2px 8px; border-radius: 100px;
      display: inline-block; margin-bottom: 4px;
    }
    .map-prop-price { font-size: 18px; font-weight: 800; color: var(--text-h); }
    .map-prop-name { font-size: 13px; font-weight: 600; color: var(--text-h); margin: 2px 0; }
    .map-prop-stats { font-size: 11px; color: var(--text-p); }
    .map-heart {
      width: 30px; height: 30px;
      border-radius: 50%;
      background: var(--surface2);
      border: none;
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
      align-self: flex-start;
    }

    /* ── TENANT PROFILE SCREEN ────────────────────────────── */
    .profile-header {
      display: flex; align-items: center; gap: 12px;
      padding: 14px 20px 10px;
      background: var(--bg);
    }
    .back-btn {
      width: 36px; height: 36px;
      border-radius: 50%;
      background: var(--surface);
      border: none;
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
      box-shadow: var(--shadow-sm);
    }
    .profile-title { font-size: 18px; font-weight: 700; flex: 1; }
    .profile-edit-btn {
      width: 36px; height: 36px;
      border-radius: 50%;
      background: var(--surface);
      border: none;
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
      box-shadow: var(--shadow-sm);
    }
    .profile-avatar-section {
      display: flex; flex-direction: column; align-items: center;
      padding: 20px;
    }
    .profile-avatar {
      width: 90px; height: 90px;
      border-radius: 50%;
      object-fit: cover;
      background: var(--primary);
      display: flex; align-items: center; justify-content: center;
      font-size: 28px; font-weight: 800; color: #fff;
      margin-bottom: 12px;
      overflow: hidden;
    }
    .profile-name { font-size: 20px; font-weight: 700; color: var(--text-h); text-align: center; }
    .profile-unit { font-size: 13px; color: var(--text-p); margin-top: 2px; text-align: center; }
    .profile-actions { display: flex; gap: 12px; margin-top: 16px; width: 100%; max-width: 260px; }
    .call-btn {
      flex: 1;
      background: var(--primary);
      color: #fff;
      border: none;
      border-radius: 100px;
      padding: 12px;
      font-size: 14px; font-weight: 700;
      display: flex; align-items: center; justify-content: center; gap: 8px;
      cursor: pointer;
    }
    .chat-btn {
      flex: 1;
      background: #14142B;
      color: #fff;
      border: none;
      border-radius: 100px;
      padding: 12px;
      font-size: 14px; font-weight: 700;
      display: flex; align-items: center; justify-content: center; gap: 8px;
      cursor: pointer;
    }
    .rent-card {
      background: var(--surface);
      border-radius: var(--radius-md);
      padding: 18px;
      box-shadow: var(--shadow-sm);
    }
    .rent-title { font-size: 16px; font-weight: 700; margin-bottom: 14px; }
    .rent-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
    .rent-field { }
    .rent-label { font-size: 12px; color: var(--text-p); margin-bottom: 4px; }
    .rent-value-box {
      background: var(--surface2);
      border-radius: var(--radius-sm);
      padding: 10px 12px;
      font-size: 14px; font-weight: 600; color: var(--text-h);
    }
    .info-card {
      background: var(--surface);
      border-radius: var(--radius-md);
      padding: 18px;
      box-shadow: var(--shadow-sm);
    }
    .info-title { font-size: 16px; font-weight: 700; margin-bottom: 14px; }
    .info-field { padding: 12px 0; border-bottom: 1px solid var(--border); }
    .info-field:last-child { border-bottom: none; }
    .info-field-label { font-size: 12px; color: var(--text-p); margin-bottom: 4px; }
    .info-field-value { font-size: 14px; font-weight: 500; color: var(--text-h); }

    /* ── BOTTOM SHEET ─────────────────────────────────────── */
    .sheet-overlay {
      position: fixed; inset: 0;
      background: rgba(0,0,0,0.4);
      z-index: 200;
      display: none;
      align-items: flex-end;
    }
    .sheet-overlay.open { display: flex; }
    .sheet {
      background: var(--surface);
      border-radius: var(--radius-xl) var(--radius-xl) 0 0;
      width: 100%; max-width: 430px;
      margin: 0 auto;
      padding: 0 20px 40px;
      animation: slideUp 0.3s cubic-bezier(.4,0,.2,1);
    }
    @keyframes slideUp {
      from { transform: translateY(100%); opacity: 0; }
      to   { transform: translateY(0);   opacity: 1; }
    }
    .sheet-handle {
      width: 40px; height: 4px;
      background: var(--border);
      border-radius: 100px;
      margin: 14px auto 20px;
    }
    .sheet-header {
      display: flex; align-items: center; justify-content: space-between;
      margin-bottom: 20px;
    }
    .sheet-title { font-size: 18px; font-weight: 700; }
    .sheet-close {
      width: 30px; height: 30px;
      border-radius: 50%;
      background: var(--surface2);
      border: none;
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
      font-size: 18px; color: var(--text-p);
    }

    /* Price Range Sheet */
    .price-histogram {
      height: 60px;
      display: flex; align-items: flex-end; gap: 3px;
      margin-bottom: 12px;
    }
    .hist-bar {
      flex: 1;
      background: var(--primary);
      border-radius: 3px 3px 0 0;
      opacity: 0.6;
    }
    .hist-bar.in-range { opacity: 1; }
    .price-slider-track {
      position: relative; height: 4px;
      background: var(--border);
      border-radius: 100px;
      margin: 0 10px 20px;
    }
    .price-slider-fill {
      position: absolute; height: 100%;
      background: var(--primary);
      border-radius: 100px;
      left: 20%; right: 30%;
    }
    .slider-thumb {
      position: absolute; top: 50%; transform: translateY(-50%);
      width: 22px; height: 22px;
      border-radius: 50%;
      background: var(--surface);
      border: 2px solid var(--primary);
      box-shadow: 0 2px 8px rgba(91,107,248,0.3);
    }
    .slider-thumb.left { left: 20%; margin-left: -11px; }
    .slider-thumb.right { right: 30%; margin-right: -11px; }
    .price-inputs { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 16px; }
    .price-input-box label { font-size: 11px; color: var(--text-muted); display: block; margin-bottom: 4px; }
    .price-input-box input {
      width: 100%;
      background: var(--surface2);
      border: none; outline: none;
      border-radius: var(--radius-sm);
      padding: 12px;
      font-family: 'Inter', sans-serif;
      font-size: 14px; font-weight: 600; color: var(--text-h);
    }
    .promo-toggle-row {
      display: flex; align-items: center; justify-content: space-between;
      margin-bottom: 20px;
    }
    .promo-toggle-label { font-size: 14px; color: var(--text-p); display: flex; align-items: center; gap: 6px; }
    .toggle {
      width: 46px; height: 26px;
      border-radius: 100px;
      background: var(--primary);
      position: relative; cursor: pointer;
    }
    .toggle::after {
      content: '';
      position: absolute; top: 3px; right: 3px;
      width: 20px; height: 20px;
      border-radius: 50%;
      background: #fff;
      transition: right 0.2s;
    }

    /* Property Type Sheet */
    .prop-type-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 24px; }
    .prop-type-btn {
      display: flex; flex-direction: column; align-items: center; gap: 8px;
      background: var(--surface2);
      border: 2px solid transparent;
      border-radius: var(--radius-md);
      padding: 16px 8px;
      cursor: pointer;
      transition: border-color 0.2s, background 0.2s;
    }
    .prop-type-btn.selected {
      border-color: var(--primary);
      background: #EEF0FE;
    }
    .prop-type-icon {
      width: 44px; height: 44px;
      border-radius: var(--radius-sm);
      display: flex; align-items: center; justify-content: center;
    }
    .prop-type-btn.selected .prop-type-icon { background: rgba(91,107,248,0.1); }
    .prop-type-name { font-size: 12px; font-weight: 600; color: var(--text-h); text-align: center; }

    /* See homes CTA */
    .see-homes-btn {
      width: 100%;
      background: #14142B;
      color: #fff;
      border: none;
      border-radius: 100px;
      padding: 16px;
      font-size: 15px; font-weight: 700;
      cursor: pointer;
      margin-top: 8px;
    }

    /* ── UPLOAD SCREEN ────────────────────────────────────── */
    .upload-zone {
      background: var(--surface);
      border-radius: var(--radius-lg);
      border: 2px dashed var(--primary);
      padding: 40px 20px;
      text-align: center;
      margin: 0 20px;
      cursor: pointer;
    }
    .upload-zone-icon { font-size: 48px; margin-bottom: 12px; }
    .upload-zone-title { font-size: 18px; font-weight: 700; margin-bottom: 6px; }
    .upload-zone-sub { font-size: 13px; color: var(--text-p); }
    .package-list { margin: 16px 20px 0; display: flex; flex-direction: column; gap: 10px; }
    .package-card {
      background: var(--surface);
      border-radius: var(--radius-md);
      padding: 16px;
      box-shadow: var(--shadow-sm);
      display: flex; align-items: center; gap: 14px;
      cursor: pointer;
      border: 2px solid transparent;
      transition: border-color 0.2s;
    }
    .package-card.selected { border-color: var(--primary); }
    .package-icon {
      width: 44px; height: 44px;
      border-radius: var(--radius-sm);
      display: flex; align-items: center; justify-content: center;
      font-size: 22px;
    }
    .package-info { flex: 1; }
    .package-name { font-size: 14px; font-weight: 700; color: var(--text-h); }
    .package-desc { font-size: 12px; color: var(--text-p); margin-top: 2px; }
    .package-price { font-size: 16px; font-weight: 800; color: var(--primary); }

    /* ── GALLERY / BEFORE-AFTER ───────────────────────────── */
    .ba-card {
      background: var(--surface);
      border-radius: var(--radius-lg);
      overflow: hidden;
      box-shadow: var(--shadow-md);
      margin: 0 20px 16px;
    }
    .ba-slider-wrap {
      position: relative;
      height: 220px;
      overflow: hidden;
      user-select: none;
    }
    .ba-slider-wrap img {
      position: absolute; inset: 0;
      width: 100%; height: 100%;
      object-fit: cover;
    }
    .ba-after { clip-path: inset(0 50% 0 0); transition: clip-path 0s; }
    .ba-divider {
      position: absolute; top: 0; bottom: 0;
      left: 50%;
      width: 3px;
      background: #fff;
      transform: translateX(-50%);
    }
    .ba-handle {
      position: absolute;
      top: 50%; left: 50%;
      transform: translate(-50%, -50%);
      width: 36px; height: 36px;
      border-radius: 50%;
      background: #fff;
      box-shadow: var(--shadow-md);
      display: flex; align-items: center; justify-content: center;
      font-size: 14px;
    }
    .ba-labels {
      position: absolute; top: 10px;
      display: flex; width: 100%; justify-content: space-between;
      padding: 0 12px;
    }
    .ba-label {
      background: rgba(0,0,0,0.5);
      color: #fff;
      font-size: 11px; font-weight: 700;
      padding: 3px 8px;
      border-radius: 6px;
    }
    .ba-card-body { padding: 14px 16px; }
    .ba-order-id { font-size: 12px; color: var(--text-p); margin-bottom: 2px; }
    .ba-prop-name { font-size: 15px; font-weight: 700; color: var(--text-h); margin-bottom: 6px; }
    .status-chip {
      display: inline-flex; align-items: center; gap: 5px;
      padding: 4px 10px;
      border-radius: 100px;
      font-size: 11px; font-weight: 600;
    }
    .status-delivered { background: #EDFBF3; color: #1A7048; }
    .status-editing   { background: #FEF9EC; color: #8A6800; }
    .status-pending   { background: #EEF0FE; color: var(--primary); }

    /* ── BILLING SCREEN ───────────────────────────────────── */
    .billing-summary-card {
      background: linear-gradient(135deg, var(--primary) 0%, #8B5CF6 100%);
      border-radius: var(--radius-lg);
      padding: 24px;
      color: #fff;
      margin: 0 20px 16px;
      box-shadow: var(--shadow-lg);
    }
    .billing-label { font-size: 13px; opacity: 0.8; margin-bottom: 6px; }
    .billing-amount { font-size: 36px; font-weight: 800; margin-bottom: 4px; }
    .billing-due { font-size: 12px; opacity: 0.7; }
    .billing-actions { display: flex; gap: 10px; margin-top: 18px; }
    .pay-btn {
      flex: 1; padding: 12px;
      background: rgba(255,255,255,0.15);
      border: 1px solid rgba(255,255,255,0.4);
      border-radius: 100px;
      color: #fff; font-size: 13px; font-weight: 700;
      cursor: pointer;
    }
    .invoice-list { margin: 0 20px; display: flex; flex-direction: column; gap: 10px; }
    .invoice-item {
      background: var(--surface);
      border-radius: var(--radius-md);
      padding: 14px 16px;
      box-shadow: var(--shadow-sm);
      display: flex; align-items: center; gap: 14px;
    }
    .inv-icon {
      width: 42px; height: 42px;
      border-radius: var(--radius-sm);
      background: #EEF0FE;
      display: flex; align-items: center; justify-content: center;
      flex-shrink: 0;
    }
    .inv-info { flex: 1; }
    .inv-name { font-size: 14px; font-weight: 600; color: var(--text-h); }
    .inv-date { font-size: 12px; color: var(--text-p); margin-top: 2px; }
    .inv-amount { font-size: 15px; font-weight: 800; color: var(--text-h); }
    .inv-status { font-size: 11px; font-weight: 600; }
    .inv-status.paid { color: #1A7048; }
    .inv-status.due  { color: #E53E6B; }

    /* ── MISC UTILITIES ───────────────────────────────────── */
    .mt8  { margin-top: 8px; }
    .mt12 { margin-top: 12px; }
    .mt16 { margin-top: 16px; }
    .mt20 { margin-top: 20px; }
    .flex-center { display: flex; align-items: center; justify-content: center; }
    .full-width { width: 100%; }
    .btn-primary {
      background: var(--primary); color: #fff;
      border: none; border-radius: 100px;
      padding: 14px 24px;
      font-size: 15px; font-weight: 700;
      cursor: pointer;
      width: 100%;
    }
    .pill-tag {
      display: inline-flex; align-items: center; gap: 4px;
      padding: 4px 10px;
      border-radius: 100px;
      font-size: 11px; font-weight: 600;
    }

    /* Vendor list */
    .vendor-card {
      background: var(--surface);
      border-radius: var(--radius-md);
      padding: 14px 16px;
      box-shadow: var(--shadow-sm);
      margin-bottom: 10px;
    }
    .vendor-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px; }
    .vendor-avail { font-size: 11px; font-weight: 600; color: #1A7048; display: flex; align-items: center; gap: 5px; }
    .vendor-avail::before { content: '●'; font-size: 8px; }
    .vendor-rating { font-size: 12px; font-weight: 700; color: #8A6800; display: flex; align-items: center; gap: 4px; }
    .vendor-name { font-size: 16px; font-weight: 700; margin-bottom: 2px; }
    .vendor-type { font-size: 12px; color: var(--text-p); float: right; }
    .vendor-addr { font-size: 12px; color: var(--text-p); margin-bottom: 12px; }
    .vendor-actions { display: flex; gap: 10px; align-items: center; }
    .vendor-chat-btn {
      width: 36px; height: 36px;
      border-radius: 50%;
      border: 1px solid var(--border);
      background: none;
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
    }
    .assign-btn {
      flex: 1; padding: 10px;
      background: var(--primary); color: #fff;
      border: none; border-radius: 100px;
      font-size: 13px; font-weight: 700;
      cursor: pointer;
    }
    .vendor-search-bar {
      display: flex; align-items: center; gap: 10px;
      background: var(--surface);
      border-radius: var(--radius-md);
      padding: 12px 16px;
      box-shadow: var(--shadow-sm);
      margin-bottom: 12px;
    }
    .vendor-search-bar input {
      border: none; outline: none; flex: 1;
      font-family: 'Inter', sans-serif;
      font-size: 14px; color: var(--text-h);
      background: transparent;
    }
    .filter-btn {
      width: 36px; height: 36px;
      border-radius: 10px;
      background: #14142B;
      border: none;
      display: flex; align-items: center; justify-content: center;
      cursor: pointer;
    }
    .category-chips { display: flex; gap: 8px; overflow-x: auto; margin-bottom: 12px; }
    .category-chips::-webkit-scrollbar { display: none; }
    .cat-chip {
      padding: 6px 14px;
      border-radius: 100px;
      font-size: 12px; font-weight: 600;
      white-space: nowrap;
      cursor: pointer; border: none;
      flex-shrink: 0;
    }
    .cat-chip.active { background: var(--primary); color: #fff; }
    .cat-chip:not(.active) { background: var(--surface); color: var(--text-h); border: 1px solid var(--border); }
  </style>
</head>
<body>
<div id="app">
  <div class="safe-top"></div>

  <!-- ══════════════════════════════════════════════════════
       HOME SCREEN
  ══════════════════════════════════════════════════════ -->
  <div class="screen active" id="screen-home">
    <!-- App Bar -->
    <div class="app-bar">
      <div class="avatar-circle">
        <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face" alt="Avatar" onerror="this.style.display='none'">
        <span style="position:absolute"><?= htmlspecialchars(substr($clientUser['avatar_initials'] ?? 'JA', 0, 2)) ?></span>
      </div>
      <div class="app-bar-info">
        <div class="app-bar-name"><?= htmlspecialchars($clientUser['name']) ?></div>
        <div class="app-bar-role"><?= htmlspecialchars($clientUser['role']) ?></div>
      </div>
      <button class="icon-btn" onclick="openUpload()">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
      </button>
      <button class="icon-btn" style="position:relative">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>
        <span style="position:absolute;top:7px;right:7px;width:8px;height:8px;background:#E53E6B;border-radius:50%;border:1.5px solid var(--bg)"></span>
      </button>
    </div>

    <div class="scroll-area" id="home-scroll">
      <!-- Property Summary -->
      <div class="section">
        <div class="section-header">
          <span class="section-title">Property Summery</span>
        </div>
        <div class="summary-grid">
          <div class="summary-card">
            <div class="summary-icon-box icon-blue">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#5B6BF8" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
            </div>
            <div class="summary-label">Properties</div>
            <div class="summary-value">02</div>
          </div>
          <div class="summary-card">
            <div class="summary-icon-box icon-indigo">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#7C3AED" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 3v18M15 3v18"/></svg>
            </div>
            <div class="summary-label">Occupied</div>
            <div class="summary-value">140<span class="muted">/150</span></div>
          </div>
          <div class="summary-card">
            <div class="summary-icon-box icon-green">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2"><path d="M12 1v22M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
            </div>
            <div class="summary-label">Rent Collected</div>
            <div class="summary-value">120<span class="muted">/140</span></div>
          </div>
          <div class="summary-card">
            <div class="summary-icon-box icon-amber">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#D97706" stroke-width="2"><path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z"/></svg>
            </div>
            <div class="summary-label">Maint. Request</div>
            <div class="summary-value">05</div>
          </div>
        </div>
      </div>

      <!-- Occupancy Rates Chart -->
      <div class="section mt20">
        <div class="chart-card">
          <div class="chart-header">
            <span class="chart-title">Occupancy Rates</span>
            <button class="chart-dropdown">Monthly
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg>
            </button>
          </div>
          <div style="display:flex;gap:6px">
            <div class="y-labels">
              <span>100%</span><span>70%</span><span>50%</span><span>10%</span>
            </div>
            <div class="bar-chart" style="flex:1">
              <?php
              $months = ['Feb','Mar','Apr','May','Jun','Jul'];
              $vals   = [65, 78, 70, 88, 95, 85];
              foreach ($months as $i => $m):
                  $h = $vals[$i];
                  $isLast = ($i === count($months)-1);
                  $grad = $isLast
                      ? 'linear-gradient(180deg,#5B6BF8 0%,#8B9BFF 100%)'
                      : 'linear-gradient(180deg,#A0AEFF 0%,#C8D0FF 100%)';
              ?>
              <div class="bar-group">
                <div class="bar-wrap">
                  <div class="bar" style="height:<?= $h ?>%;background:<?= $grad ?>"></div>
                </div>
                <span class="bar-month"><?= $m ?></span>
              </div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>
      </div>

      <!-- Recent Activity -->
      <div class="section mt20">
        <div class="section-header">
          <span class="section-title">Recent Activity</span>
          <button class="view-all" onclick="switchTab('gallery')">View all
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
          </button>
        </div>
        <?php foreach (array_slice($clientOrders, 0, 2) as $order): ?>
        <div class="activity-item" onclick="switchTab('gallery')">
          <div class="activity-icon">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
          </div>
          <div class="activity-text">
            <div class="activity-title"><?= htmlspecialchars($order['property_name']) ?></div>
            <div class="activity-sub"><?= htmlspecialchars($order['sla_remaining']) ?> · <?= $order['photos_count'] ?> photos</div>
          </div>
          <svg class="activity-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- Tenant Profile Quick Card -->
      <div class="section mt20" style="padding-bottom:10px">
        <div class="section-header">
          <span class="section-title">My Profile</span>
          <button class="view-all" onclick="switchTab('profile')">View all
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
          </button>
        </div>
        <div class="rent-card">
          <div class="rent-title">Rent details</div>
          <div class="rent-grid">
            <div class="rent-field">
              <div class="rent-label">Start date</div>
              <div class="rent-value-box">1/2/2024</div>
            </div>
            <div class="rent-field">
              <div class="rent-label">Monthly utility</div>
              <div class="rent-value-box">$90.00</div>
            </div>
            <div class="rent-field">
              <div class="rent-label">Monthly rent</div>
              <div class="rent-value-box">$200.00</div>
            </div>
            <div class="rent-field">
              <div class="rent-label">Security money</div>
              <div class="rent-value-box">$400.00</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══════════════════════════════════════════════════════
       SEARCH / LISTINGS SCREEN
  ══════════════════════════════════════════════════════ -->
  <div class="screen" id="screen-search">
    <!-- Search bar -->
    <div class="search-bar-wrap">
      <div style="display:flex;gap:10px;align-items:center">
        <div class="search-bar" style="flex:1">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" placeholder="New York, NY" id="search-input">
        </div>
        <button class="map-toggle-btn" id="map-toggle" onclick="toggleMapView()">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--text-h)" stroke-width="2"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/><line x1="8" y1="2" x2="8" y2="18"/><line x1="16" y1="6" x2="16" y2="22"/></svg>
        </button>
      </div>
    </div>

    <!-- Filter Chips -->
    <div class="filter-chips">
      <button class="chip primary-chip" onclick="openPropType()">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="14" y2="12"/><line x1="4" y1="18" x2="10" y2="18"/></svg>
        Filter
      </button>
      <button class="chip outline-chip" onclick="openPriceRange()">Price</button>
      <button class="chip outline-chip">Rooms</button>
      <button class="chip outline-chip" id="builder-chip">Builder P.</button>
    </div>

    <!-- Results bar -->
    <div class="results-bar">
      <span class="results-count">1245 results</span>
      <div class="results-actions">
        <button class="results-action">Save search</button>
        <button class="results-action">Relevance
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg>
        </button>
      </div>
    </div>

    <!-- List / Map view -->
    <div class="scroll-area" id="search-scroll">
      <!-- List view -->
      <div id="list-view">
        <?php foreach ($clientOrders as $order): ?>
        <div class="prop-card">
          <div class="prop-card-img">
            <img src="<?= htmlspecialchars($order['hero_img']) ?>" alt="<?= htmlspecialchars($order['property_name']) ?>"
                 onerror="this.src='https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=900'">
            <?php if (!empty($order['for_sale'])): ?>
            <span class="for-sale-badge">For Sale</span>
            <?php endif; ?>
            <button class="heart-btn" onclick="toggleHeart(this)">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#E53E6B" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
            </button>
          </div>
          <div class="prop-card-body">
            <div class="prop-address-row">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
              <span class="prop-address"><?= htmlspecialchars($order['address']) ?></span>
              <span class="prop-price">$<?= number_format($order['price'] ?? 0) ?></span>
            </div>
            <div class="prop-name"><?= htmlspecialchars($order['property_name']) ?></div>
            <div class="prop-stats">
              <div class="prop-stat">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>
                <?= $order['beds'] ?? 4 ?> Beds
              </div>
              <div class="prop-stat">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 12h16M4 6a2 2 0 012-2h12a2 2 0 012 2v6H4V6z"/></svg>
                <?= $order['baths'] ?? 3 ?> Baths
              </div>
              <div class="prop-stat">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/></svg>
                <?= number_format($order['sqft'] ?? 2000) ?> Sqft
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- Map view -->
      <div id="map-view" style="display:none">
        <div class="map-container" style="margin:0;border-radius:0;height:calc(100vh - 280px)">
          <div class="map-bg">
            <!-- Grid lines -->
            <div class="map-grid-h" style="top:25%"></div>
            <div class="map-grid-h" style="top:50%"></div>
            <div class="map-grid-h" style="top:75%"></div>
            <div class="map-grid-v" style="left:33%"></div>
            <div class="map-grid-v" style="left:66%"></div>
            <!-- Price bubbles -->
            <div class="map-bubble" style="top:18%;left:12%">$12,900</div>
            <div class="map-bubble selected" style="top:30%;left:52%">$25,000</div>
            <div class="map-bubble" style="top:45%;left:28%">$10,000</div>
            <div class="map-bubble" style="top:20%;right:10%">$18,500</div>
            <div class="map-bubble" style="top:55%;right:15%">$14,200</div>
          </div>
          <!-- Map property popup -->
          <div class="map-prop-card">
            <img class="map-prop-img" src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=400" alt="Property">
            <div class="map-prop-info">
              <span class="map-prop-badge">For Sale</span>
              <div class="map-prop-price">$25,000</div>
              <div class="map-prop-name">Whispering Pines House</div>
              <div class="map-prop-stats">6 Beds · 5 Baths · 2660 Sqft</div>
            </div>
            <button class="map-heart" onclick="toggleHeart(this)">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#E53E6B" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══════════════════════════════════════════════════════
       UPLOAD SCREEN
  ══════════════════════════════════════════════════════ -->
  <div class="screen" id="screen-upload">
    <div class="app-bar">
      <span style="font-size:20px;font-weight:800;flex:1">New Shoot</span>
      <button class="icon-btn" onclick="switchTab('home')">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div class="scroll-area">
      <div class="upload-zone" onclick="document.getElementById('file-picker').click()">
        <div class="upload-zone-icon">📁</div>
        <div class="upload-zone-title">Drop brackets here</div>
        <div class="upload-zone-sub">Tap to browse files — supports RAW, JPEG, TIFF</div>
        <input type="file" id="file-picker" multiple accept="image/*,.raw,.tiff,.tif,.arw,.cr2,.nef,.dng" style="display:none" onchange="filesSelected(this)">
      </div>
      <div class="package-list" style="margin-top:20px">
        <div class="package-card" onclick="selectPackage(this, 'HDR Fusion')">
          <div class="package-icon" style="background:#EEF0FE">⚡</div>
          <div class="package-info">
            <div class="package-name">HDR Fusion</div>
            <div class="package-desc">3-5-7 bracket blending, natural look</div>
          </div>
          <div class="package-price">$0.75</div>
        </div>
        <div class="package-card" onclick="selectPackage(this, 'Flambient')">
          <div class="package-icon" style="background:#EDFBF3">🔆</div>
          <div class="package-info">
            <div class="package-name">Flambient</div>
            <div class="package-desc">Flash + ambient blend for interiors</div>
          </div>
          <div class="package-price">$1.25</div>
        </div>
        <div class="package-card" onclick="selectPackage(this, 'Day to Dusk')">
          <div class="package-icon" style="background:#FEF9EC">🌅</div>
          <div class="package-info">
            <div class="package-name">Day to Dusk</div>
            <div class="package-desc">Twilight conversion + sky replacement</div>
          </div>
          <div class="package-price">$12.00</div>
        </div>
        <div class="package-card" onclick="selectPackage(this, 'Virtual Staging')">
          <div class="package-icon" style="background:#FEF0F0">🛋</div>
          <div class="package-info">
            <div class="package-name">Virtual Staging</div>
            <div class="package-desc">AI-powered furniture & decor placement</div>
          </div>
          <div class="package-price">$18.00</div>
        </div>
      </div>
      <div style="padding:20px">
        <button class="btn-primary" onclick="submitUpload()">Submit Order</button>
      </div>
    </div>
  </div>

  <!-- ══════════════════════════════════════════════════════
       GALLERY / BEFORE-AFTER SCREEN
  ══════════════════════════════════════════════════════ -->
  <div class="screen" id="screen-gallery">
    <div class="app-bar">
      <span style="font-size:20px;font-weight:800;flex:1">Deliveries</span>
    </div>
    <div class="scroll-area">
      <?php foreach ($clientOrders as $order): ?>
      <div class="ba-card">
        <div class="ba-slider-wrap" id="ba-<?= $order['id'] ?>" data-dragging="false">
          <img src="<?= htmlspecialchars($order['before_img']) ?>" class="ba-before" alt="Before">
          <img src="<?= htmlspecialchars($order['after_img']) ?>"  class="ba-after"  alt="After">
          <div class="ba-divider" id="div-<?= $order['id'] ?>"></div>
          <div class="ba-handle" id="hdl-<?= $order['id'] ?>">⇔</div>
          <div class="ba-labels">
            <span class="ba-label">BEFORE</span>
            <span class="ba-label">AFTER</span>
          </div>
        </div>
        <div class="ba-card-body">
          <div class="ba-order-id"><?= htmlspecialchars($order['id']) ?> · <?= $order['photos_count'] ?> photos</div>
          <div class="ba-prop-name"><?= htmlspecialchars($order['property_name']) ?></div>
          <span class="status-chip status-<?= $order['status'] ?>"><?= ucfirst($order['status']) ?></span>
          <span style="font-size:12px;color:var(--text-p);margin-left:8px"><?= htmlspecialchars($order['sla_remaining']) ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- ══════════════════════════════════════════════════════
       PROFILE / TENANT SCREEN
  ══════════════════════════════════════════════════════ -->
  <div class="screen" id="screen-profile">
    <div class="profile-header">
      <button class="back-btn" onclick="switchTab('home')">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>
      </button>
      <span class="profile-title">Tenant Profile</span>
      <button class="profile-edit-btn">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
      </button>
    </div>
    <div class="scroll-area">
      <div class="profile-avatar-section">
        <div class="profile-avatar">
          <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face" alt="Avatar"
               onerror="this.style.display='none'" style="width:100%;height:100%;object-fit:cover;border-radius:50%">
        </div>
        <div class="profile-name"><?= htmlspecialchars($clientUser['name']) ?></div>
        <div class="profile-unit"><?= htmlspecialchars($clientUser['company']) ?></div>
        <div class="profile-actions">
          <button class="call-btn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.11 19.79 19.79 0 01.22 .5 2 2 0 012.22 0h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 14.92v2z"/></svg>
            Call now
          </button>
          <button class="chat-btn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
            Chat
          </button>
        </div>
      </div>

      <!-- Rent Details -->
      <div class="section">
        <div class="rent-card">
          <div class="rent-title">Rent details</div>
          <div class="rent-grid">
            <div class="rent-field">
              <div class="rent-label">Start date</div>
              <div class="rent-value-box">1/2/2024</div>
            </div>
            <div class="rent-field">
              <div class="rent-label">Monthly utility</div>
              <div class="rent-value-box">$90.00</div>
            </div>
            <div class="rent-field">
              <div class="rent-label">Monthly rent</div>
              <div class="rent-value-box">$200.00</div>
            </div>
            <div class="rent-field">
              <div class="rent-label">Security money</div>
              <div class="rent-value-box">$400.00</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Personal Info -->
      <div class="section mt12" style="padding-bottom:16px">
        <div class="info-card">
          <div class="info-title">Personal information</div>
          <div class="info-field">
            <div class="info-field-label">Phone</div>
            <div class="info-field-value"><?= htmlspecialchars($clientUser['phone']) ?></div>
          </div>
          <div class="info-field">
            <div class="info-field-label">Email</div>
            <div class="info-field-value"><?= htmlspecialchars($clientUser['email']) ?></div>
          </div>
          <div class="info-field">
            <div class="info-field-label">Company</div>
            <div class="info-field-value"><?= htmlspecialchars($clientUser['company']) ?></div>
          </div>
          <div class="info-field">
            <div class="info-field-label">Emergency Contact</div>
            <div class="info-field-value">+1 (555) 999-0001</div>
          </div>
          <div class="info-field">
            <div class="info-field-label">SLA Rate</div>
            <div class="info-field-value"><?= htmlspecialchars($clientUser['sla_rate']) ?></div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══════════════════════════════════════════════════════
       BILLING SCREEN
  ══════════════════════════════════════════════════════ -->
  <div class="screen" id="screen-billing">
    <div class="app-bar">
      <span style="font-size:20px;font-weight:800;flex:1">Billing</span>
    </div>
    <div class="scroll-area">
      <div class="billing-summary-card" style="margin-top:8px">
        <div class="billing-label">Balance Due</div>
        <div class="billing-amount">$<?= number_format($clientUser['balance_due'], 2) ?></div>
        <div class="billing-due">Due by Sep 30, 2026</div>
        <div class="billing-actions">
          <button class="pay-btn">💳 Pay with Card</button>
          <button class="pay-btn">🏦 Payoneer</button>
        </div>
      </div>

      <div class="section">
        <div class="section-header">
          <span class="section-title">Invoice History</span>
        </div>
      </div>
      <div class="invoice-list">
        <?php foreach ($clientOrders as $order): ?>
        <div class="invoice-item">
          <div class="inv-icon">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
          </div>
          <div class="inv-info">
            <div class="inv-name"><?= htmlspecialchars($order['id']) ?> — <?= htmlspecialchars($order['service']) ?></div>
            <div class="inv-date"><?= htmlspecialchars($order['created_at']) ?></div>
          </div>
          <div style="text-align:right">
            <div class="inv-amount">$<?= number_format($order['price'] ?? 0) ?></div>
            <div class="inv-status <?= $order['status'] === 'delivered' ? 'paid' : 'due' ?>">
              <?= $order['status'] === 'delivered' ? '✓ Paid' : 'Pending' ?>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- ══════════════════════════════════════════════════════
       VENDOR LIST SCREEN  (Pipeline tab)
  ══════════════════════════════════════════════════════ -->
  <div class="screen" id="screen-pipeline">
    <div class="app-bar">
      <span style="font-size:20px;font-weight:800;flex:1">Vendor list</span>
      <button class="icon-btn">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
      </button>
      <button class="icon-btn">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      </button>
    </div>
    <div class="scroll-area" style="padding:0 20px">
      <!-- Search -->
      <div class="vendor-search-bar" style="margin-top:8px">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <input type="text" placeholder="Search here">
        <button class="filter-btn">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="14" y2="12"/><line x1="4" y1="18" x2="10" y2="18"/></svg>
        </button>
      </div>
      <!-- Category chips -->
      <div class="category-chips">
        <button class="cat-chip active">Plumbing</button>
        <button class="cat-chip">Electrical</button>
        <button class="cat-chip">Carpentry</button>
        <button class="cat-chip">Landscaping</button>
        <button class="cat-chip">Masonry</button>
      </div>
      <!-- Vendor cards -->
      <div class="vendor-card">
        <div class="vendor-header">
          <span class="vendor-avail">Available</span>
          <span class="vendor-rating">⭐ 4.9/5.0</span>
        </div>
        <div><span class="vendor-name">FixerHub</span><span class="vendor-type">Plumbing</span></div>
        <div class="vendor-addr">456 Oak Street, Los Angeles, CA 90001</div>
        <div class="vendor-actions">
          <button class="vendor-chat-btn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text-p)" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
          </button>
          <button class="assign-btn">Assign</button>
        </div>
      </div>
      <div class="vendor-card">
        <div class="vendor-header">
          <span class="vendor-avail">Available</span>
          <span class="vendor-rating">⭐ 4.7/5.0</span>
        </div>
        <div><span class="vendor-name">CleanSweep</span><span class="vendor-type">Cleaning</span></div>
        <div class="vendor-addr">789 Maple Avenue, Los Angeles, CA 90002</div>
        <div class="vendor-actions">
          <button class="vendor-chat-btn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text-p)" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
          </button>
          <button class="assign-btn">Assign</button>
        </div>
      </div>
      <div class="vendor-card" style="margin-bottom:16px">
        <div class="vendor-header">
          <span class="vendor-avail">Available</span>
          <span class="vendor-rating">⭐ 4.8/5.0</span>
        </div>
        <div><span class="vendor-name">TechPros</span><span class="vendor-type">IT Support</span></div>
        <div class="vendor-addr">321 Pine Road, Los Angeles, CA 90003</div>
        <div class="vendor-actions">
          <button class="vendor-chat-btn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text-p)" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
          </button>
          <button class="assign-btn">Assign</button>
        </div>
      </div>
    </div>
  </div>

  <!-- ══════════════════════════════════════════════════════
       BOTTOM NAVIGATION
  ══════════════════════════════════════════════════════ -->
  <nav class="bottom-nav">
    <button class="nav-btn active" id="nav-home" onclick="switchTab('home')">
      <div class="nav-icon">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
      </div>
      <span class="nav-label">Home</span>
    </button>
    <button class="nav-btn" id="nav-search" onclick="switchTab('search')">
      <div class="nav-icon">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      </div>
      <span class="nav-label">Search</span>
    </button>
    <button class="nav-btn" id="nav-upload" onclick="switchTab('upload')">
      <div class="nav-icon">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/><path d="M20.39 18.39A5 5 0 0018 9h-1.26A8 8 0 103 16.3"/></svg>
      </div>
      <span class="nav-label">Upload</span>
    </button>
    <button class="nav-btn" id="nav-pipeline" onclick="switchTab('pipeline')">
      <div class="nav-icon">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>
      </div>
      <span class="nav-label">Vendors</span>
    </button>
    <button class="nav-btn" id="nav-gallery" onclick="switchTab('gallery')">
      <div class="nav-icon">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
      </div>
      <span class="nav-label">Gallery</span>
    </button>
  </nav>

  <!-- ══════════════════════════════════════════════════════
       BOTTOM SHEETS
  ══════════════════════════════════════════════════════ -->
  <!-- Price Range Sheet -->
  <div class="sheet-overlay" id="price-sheet" onclick="closePriceRange(event)">
    <div class="sheet" onclick="event.stopPropagation()">
      <div class="sheet-handle"></div>
      <div class="sheet-header">
        <span class="sheet-title">Price Range (AED)</span>
        <button class="sheet-close" onclick="closePriceRange()">×</button>
      </div>
      <!-- Histogram -->
      <div class="price-histogram">
        <?php
        $histData = [20,35,45,55,60,80,90,85,70,65,50,40,35,25,20,15,10,8,12,18];
        $inRange  = [0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0];
        $maxH = max($histData);
        foreach ($histData as $k => $hv):
            $pct = round($hv / $maxH * 100);
        ?>
        <div class="hist-bar <?= $inRange[$k] ? 'in-range' : '' ?>" style="height:<?= $pct ?>%"></div>
        <?php endforeach; ?>
      </div>
      <!-- Range slider -->
      <div class="price-slider-track">
        <div class="price-slider-fill"></div>
        <div class="slider-thumb left"></div>
        <div class="slider-thumb right"></div>
      </div>
      <!-- Min/Max inputs -->
      <div class="price-inputs">
        <div class="price-input-box">
          <label>Minimum</label>
          <input type="text" value="AED 24,000">
        </div>
        <div class="price-input-box">
          <label>Maximum</label>
          <input type="text" value="AED 48,000">
        </div>
      </div>
      <!-- Builder promotions toggle -->
      <div class="promo-toggle-row">
        <span class="promo-toggle-label">
          Builder promotions
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        </span>
        <div class="toggle"></div>
      </div>
      <button class="see-homes-btn">See 4,671 homes</button>
    </div>
  </div>

  <!-- Property Type Sheet -->
  <div class="sheet-overlay" id="proptype-sheet" onclick="closePropType(event)">
    <div class="sheet" onclick="event.stopPropagation()">
      <div class="sheet-handle"></div>
      <div class="sheet-header">
        <span class="sheet-title">Property type</span>
        <button class="sheet-close" onclick="closePropType()">×</button>
      </div>
      <div class="prop-type-grid">
        <?php
        $types = [
          ['🏠','House',true],['🏢','Condo',false],['🏘','Townhome',false],
          ['🏗','Multi family',false],['🏚','Mobile',false],['🌾','Farm',false],
          ['🏞','Land',false],['🏛','Co-op',false],['🏙','Condop',false],
        ];
        foreach ($types as [$ico,$name,$sel]):
        ?>
        <button class="prop-type-btn <?= $sel ? 'selected' : '' ?>" onclick="selectPropType(this)">
          <div class="prop-type-icon" style="font-size:26px"><?= $ico ?></div>
          <span class="prop-type-name"><?= $name ?></span>
        </button>
        <?php endforeach; ?>
      </div>
      <button class="see-homes-btn">See 4,671 homes</button>
    </div>
  </div>

</div><!-- #app -->

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
/* ══════════════════════════════════════════════════════
   NAVIGATION
══════════════════════════════════════════════════════ */
const tabs = ['home','search','upload','pipeline','gallery','profile','billing'];

function switchTab(tab) {
  tabs.forEach(t => {
    const s = document.getElementById('screen-' + t);
    const n = document.getElementById('nav-' + t);
    if (s) s.classList.toggle('active', t === tab);
    if (n) n.classList.toggle('active', t === tab);
  });
  // scroll to top
  const scroll = document.querySelector('#screen-' + tab + ' .scroll-area');
  if (scroll) scroll.scrollTop = 0;
}

function openUpload() { switchTab('upload'); }

/* ══════════════════════════════════════════════════════
   BEFORE / AFTER SLIDER
══════════════════════════════════════════════════════ */
document.querySelectorAll('.ba-slider-wrap').forEach(wrap => {
  const id  = wrap.id.replace('ba-', '');
  const div = document.getElementById('div-' + id);
  const hdl = document.getElementById('hdl-' + id);
  const after = wrap.querySelector('.ba-after');
  let drag = false;

  function setPos(pct) {
    pct = Math.max(5, Math.min(95, pct));
    after.style.clipPath = `inset(0 ${100-pct}% 0 0)`;
    div.style.left = pct + '%';
    hdl.style.left = pct + '%';
  }
  setPos(50);

  function getPos(e) {
    const rect = wrap.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    return ((clientX - rect.left) / rect.width) * 100;
  }

  hdl.addEventListener('mousedown',  e => { drag = true; e.preventDefault(); });
  hdl.addEventListener('touchstart', e => { drag = true; }, {passive:true});
  wrap.addEventListener('mousemove',  e => { if (drag) setPos(getPos(e)); });
  wrap.addEventListener('touchmove',  e => { if (drag) setPos(getPos(e)); }, {passive:true});
  document.addEventListener('mouseup',  () => { drag = false; });
  document.addEventListener('touchend', () => { drag = false; });
});

/* ══════════════════════════════════════════════════════
   MAP TOGGLE
══════════════════════════════════════════════════════ */
let mapVisible = false;
function toggleMapView() {
  mapVisible = !mapVisible;
  document.getElementById('list-view').style.display = mapVisible ? 'none' : 'block';
  document.getElementById('map-view').style.display  = mapVisible ? 'block' : 'none';
  const btn = document.getElementById('map-toggle');
  btn.style.background = mapVisible ? 'var(--primary)' : 'var(--surface)';
  btn.querySelector('svg').style.stroke = mapVisible ? '#fff' : 'var(--text-h)';
}

/* ══════════════════════════════════════════════════════
   HEART / LIKE
══════════════════════════════════════════════════════ */
function toggleHeart(btn) {
  btn.classList.toggle('liked');
  const svg = btn.querySelector('svg');
  if (btn.classList.contains('liked')) {
    svg.setAttribute('fill', '#E53E6B');
  } else {
    svg.setAttribute('fill', 'none');
  }
}

/* ══════════════════════════════════════════════════════
   PRICE RANGE SHEET
══════════════════════════════════════════════════════ */
function openPriceRange() {
  document.getElementById('price-sheet').classList.add('open');
}
function closePriceRange(e) {
  if (!e || e.target === document.getElementById('price-sheet')) {
    document.getElementById('price-sheet').classList.remove('open');
  }
}

/* ══════════════════════════════════════════════════════
   PROPERTY TYPE SHEET
══════════════════════════════════════════════════════ */
function openPropType() {
  document.getElementById('proptype-sheet').classList.add('open');
}
function closePropType(e) {
  if (!e || e.target === document.getElementById('proptype-sheet')) {
    document.getElementById('proptype-sheet').classList.remove('open');
  }
}
function selectPropType(btn) {
  document.querySelectorAll('.prop-type-btn').forEach(b => b.classList.remove('selected'));
  btn.classList.add('selected');
}

/* ══════════════════════════════════════════════════════
   PACKAGE SELECTION
══════════════════════════════════════════════════════ */
function selectPackage(card, name) {
  document.querySelectorAll('.package-card').forEach(c => c.classList.remove('selected'));
  card.classList.add('selected');
}

/* ══════════════════════════════════════════════════════
   UPLOAD SUBMIT
══════════════════════════════════════════════════════ */
function filesSelected(input) {
  const count = input.files.length;
  if (count > 0) {
    const zone = input.closest('.upload-zone');
    zone.querySelector('.upload-zone-title').textContent = count + ' file(s) selected';
    zone.querySelector('.upload-zone-sub').textContent = 'Ready to submit — choose a package below';
  }
}

function submitUpload() {
  const selected = document.querySelector('.package-card.selected');
  if (!selected) {
    alert('Please select a service package first!');
    return;
  }
  const name = selected.querySelector('.package-name').textContent;
  const price = selected.querySelector('.package-price').textContent;
  // Show success feedback
  const btn = document.querySelector('#screen-upload .btn-primary');
  btn.textContent = '✓ Order Submitted!';
  btn.style.background = '#059669';
  setTimeout(() => {
    btn.textContent = 'Submit Order';
    btn.style.background = '';
    switchTab('gallery');
  }, 2000);
}

/* ══════════════════════════════════════════════════════
   CATEGORY CHIP TOGGLE (Vendor screen)
══════════════════════════════════════════════════════ */
document.querySelectorAll('.cat-chip').forEach(chip => {
  chip.addEventListener('click', () => {
    document.querySelectorAll('.cat-chip').forEach(c => c.classList.remove('active'));
    chip.classList.add('active');
  });
});
</script>
</body>
</html>
