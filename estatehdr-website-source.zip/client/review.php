<?php
/**
 * Estate HDR - Client Proofing & Visual Review Portal
 * Enterprise Layer: Before/After Slider, Pinpoint Visual Annotations & Approval Workflow
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/services/ClientRbacService.php';
require_once __DIR__ . '/../includes/services/AmendmentService.php';
require_once __DIR__ . '/../includes/services/AssetService.php';

requireLogin();
$currentUser = currentUser();

// Permission check: Can this user review deliveries?
ClientRbacService::enforce(ClientRbacService::PERM_REVIEW_DELIVERIES, $currentUser);

$orderId = trim($_GET['id'] ?? '');
if (empty($orderId)) {
    die("Error: Missing order ID for proofing.");
}

$order = getOrderById($orderId);
if (!$order) {
    die("Error: Order not found.");
}

// Client ownership validation
if (!isAdmin() && ($order['client_id'] ?? '') !== ($currentUser['id'] ?? '') && ($order['user_id'] ?? '') !== ($currentUser['id'] ?? '')) {
    die("Unauthorized: You do not have permission to view this order.");
}

$pageTitle = "Proofing & Review: " . htmlspecialchars($orderId);

// Handle POST: Approve Final or Request Amendment
$flashSuccess = '';
$flashError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'approve_final') {
        if (function_exists('updateOrderStatus')) {
            updateOrderStatus($orderId, 'approved', 'Client approved final delivery.');
        }
        $order['status'] = 'approved';
        $order['is_locked'] = true;
        if (function_exists('saveOrder')) {
            saveOrder($order);
        }
        $flashSuccess = "🎉 Final delivery successfully approved! The order has been locked and archived.";
    } elseif ($action === 'request_amendment') {
        $reason = trim($_POST['reason'] ?? 'Visual adjustments requested');
        $annotationsJson = $_POST['annotations_json'] ?? '[]';
        $annotations = json_decode($annotationsJson, true) ?: [];

        if (function_exists('triggerAmendmentRequested')) {
            $res = triggerAmendmentRequested($orderId, $reason, ['annotations' => $annotations]);
            $amendId = $res['amend_record']['id'] ?? 'AMEND';
        } else {
            $newAmend = AmendmentService::createAmendment([
                'order_id' => $orderId,
                'client_id' => $currentUser['id'] ?? 'CLIENT',
                'reason' => $reason,
                'annotations' => $annotations,
                'version' => 'v1'
            ]);
            $amendId = $newAmend['id'] ?? 'AMEND';
        }

        $flashSuccess = "Amendment request " . htmlspecialchars($amendId) . " has been submitted to your lead editor & management team!";
        $order['status'] = 'amendment_requested';
    }
}

// Gather sample / delivery images
$beforeImage = "/assets/images/before-sample.jpg";
$afterImage = "/assets/images/after-sample.jpg";

if (!empty($order['delivery_link']) && filter_var($order['delivery_link'], FILTER_VALIDATE_URL)) {
    // If delivery link provided
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - Estate HDR</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/app.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="/assets/js/custom-dialogs.js"></script>
    <style>
        .split-container {
            position: relative;
            overflow: hidden;
            user-select: none;
        }
        .split-before {
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            overflow: hidden;
            width: 50%;
            z-index: 10;
        }
        .split-slider {
            position: absolute;
            top: 0;
            bottom: 0;
            width: 4px;
            background: #C9A84C;
            left: 50%;
            cursor: ew-resize;
            z-index: 20;
            box-shadow: 0 0 10px rgba(201,168,76,0.8);
        }
        .split-handle {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 36px;
            height: 36px;
            background: #0B0E14;
            border: 2px solid #C9A84C;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #C9A84C;
            font-size: 13px;
        }
        .pin-marker {
            position: absolute;
            transform: translate(-50%, -100%);
            z-index: 30;
            cursor: pointer;
            transition: transform 0.15s ease;
        }
        .pin-marker:hover {
            transform: translate(-50%, -115%) scale(1.2);
        }
    </style>
</head>
<body class="bg-[#0B0E14] text-gray-200 min-h-screen">
    <!-- Header -->
    <header class="bg-[#121721] border-b border-gray-800 px-6 py-4 flex flex-wrap items-center justify-between gap-4">
        <div class="flex items-center gap-4">
            <a href="/client/app.php" class="text-gray-400 hover:text-gold transition">
                <i class="fas fa-arrow-left"></i> Back to Portal
            </a>
            <div class="h-6 w-px bg-gray-700"></div>
            <div>
                <h1 class="text-xl font-bold text-white flex items-center gap-2">
                    <span><?= htmlspecialchars($orderId) ?></span>
                    <span class="text-xs px-2.5 py-0.5 rounded-full bg-gold/10 text-gold border border-gold/30 uppercase tracking-wider font-semibold">
                        <?= htmlspecialchars(str_replace('_', ' ', $order['status'] ?? 'Delivered')) ?>
                    </span>
                </h1>
                <p class="text-xs text-gray-400 mt-0.5">
                    Property: <strong class="text-gray-300"><?= htmlspecialchars($order['property_address'] ?? 'Luxury Real Estate') ?></strong>
                </p>
            </div>
        </div>

        <div class="flex items-center gap-3">
            <button type="button" onclick="togglePinMode()" id="pinModeBtn" class="px-4 py-2 text-xs font-semibold rounded-lg bg-gray-800 border border-gray-700 hover:border-gold text-gray-300 transition flex items-center gap-2">
                <i class="fas fa-map-pin text-gold"></i>
                <span id="pinModeText">Add Pin Feedback</span>
            </button>
            <button type="button" onclick="openAmendmentModal()" class="px-4 py-2 text-xs font-semibold rounded-lg bg-amber-600/20 text-amber-400 border border-amber-500/40 hover:bg-amber-600/30 transition flex items-center gap-2">
                <i class="fas fa-edit"></i> Request Amendment
            </button>
            <form method="POST" data-confirm="Are you sure you want to approve this final delivery? This will lock the order as completed." data-confirm-title="Approve Final Delivery" data-confirm-icon="✅" data-confirm-btn="Approve Delivery" data-confirm-danger="false" class="inline">
                <input type="hidden" name="action" value="approve_final">
                <button type="submit" class="px-4 py-2 text-xs font-bold rounded-lg bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white transition shadow-lg shadow-emerald-900/30 flex items-center gap-2">
                    <i class="fas fa-check-double"></i> Approve Final
                </button>
            </form>
        </div>
    </header>

    <main class="max-w-[1850px] mx-auto px-4 sm:px-8 py-8">
        <?php if ($flashSuccess): ?>
            <div class="mb-6 p-4 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-sm flex items-center gap-3">
                <i class="fas fa-circle-check text-emerald-400 text-lg"></i>
                <span><?= $flashSuccess ?></span>
            </div>
        <?php endif; ?>

        <!-- Instructions Banner -->
        <div class="mb-6 p-4 rounded-xl bg-[#151B28] border border-gray-800 text-xs text-gray-300 flex items-center justify-between gap-4">
            <div class="flex items-center gap-3">
                <div class="w-8 h-8 rounded-lg bg-gold/10 text-gold flex items-center justify-center font-bold">
                    <i class="fas fa-sliders-h"></i>
                </div>
                <div>
                    <span class="font-bold text-white">Interactive Visual Proofing Engine:</span>
                    Drag the gold slider horizontally to compare RAW bracket vs Final HDR master. Click anywhere on the image to drop a pinpoint revision comment.
                </div>
            </div>
            <div class="text-right">
                <span class="text-gray-400">Annotations: </span>
                <span id="pinCountBadge" class="font-bold text-gold">0 Pins</span>
            </div>
        </div>

        <!-- Before / After Slider Canvas -->
        <div class="bg-[#121721] rounded-2xl border border-gray-800 p-4 shadow-2xl relative">
            <div id="splitViewer" class="split-container w-full h-[620px] rounded-xl relative cursor-crosshair overflow-hidden">
                <!-- After Image (Full Background) -->
                <img id="afterImg" src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=80" alt="Master HDR Delivery" class="w-full h-full object-cover pointer-events-none select-none">

                <!-- Before Image (Clipped Left Layer) -->
                <div id="beforeWrapper" class="split-before">
                    <img id="beforeImg" src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=20&sat=-60&con=-30" alt="RAW Exposure Bracket" class="w-full h-full object-cover pointer-events-none select-none max-w-none">
                </div>

                <!-- Slider Bar -->
                <div id="sliderBar" class="split-slider">
                    <div class="split-handle">
                        <i class="fas fa-arrows-alt-h"></i>
                    </div>
                </div>

                <!-- Overlay Pin Markers Layer -->
                <div id="pinOverlayLayer" class="absolute inset-0 pointer-events-auto"></div>
            </div>

            <!-- Bottom Control Bar -->
            <div class="mt-4 flex flex-wrap items-center justify-between gap-4 text-xs text-gray-400 border-t border-gray-800/80 pt-3">
                <div class="flex items-center gap-6">
                    <span class="flex items-center gap-2"><span class="w-3 h-3 rounded-full bg-gray-600"></span> Left: RAW Bracket</span>
                    <span class="flex items-center gap-2"><span class="w-3 h-3 rounded-full bg-gold"></span> Right: Retouched Master</span>
                </div>
                <div class="flex items-center gap-3">
                    <a href="#" class="hover:text-gold transition"><i class="fas fa-download mr-1"></i> Download High-Res (Print)</a>
                    <span>•</span>
                    <a href="#" class="hover:text-gold transition"><i class="fas fa-file-zipper mr-1"></i> Download Web-Ready ZIP</a>
                </div>
            </div>
        </div>

        <!-- Annotation List -->
        <div class="mt-8 bg-[#121721] rounded-2xl border border-gray-800 p-6">
            <h3 class="text-sm font-bold text-white uppercase tracking-wider mb-4 flex items-center justify-between">
                <span>📍 Pinned Feedback & Revisions</span>
                <span class="text-xs font-normal text-gray-400">Click a pin on the image to view or remove</span>
            </h3>
            <div id="pinsListContainer" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <p id="noPinsText" class="text-gray-500 text-xs italic col-span-full">No pins added yet. Turn on "Add Pin Feedback" and click anywhere on the image to pinpoint exact corrections.</p>
            </div>
        </div>
    </main>

    <!-- Pin Modal Dialog -->
    <div id="pinModal" class="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
        <div class="bg-[#151B28] border border-gray-700 rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <h3 class="text-base font-bold text-white mb-2 flex items-center gap-2">
                <i class="fas fa-map-pin text-gold"></i> Add Visual Feedback Note
            </h3>
            <p class="text-xs text-gray-400 mb-4">Coordinate: <span id="pinCoordsText" class="text-gold font-mono"></span></p>
            <div class="mb-4">
                <label class="block text-xs font-semibold text-gray-300 mb-1">Issue / Instruction for Editor:</label>
                <textarea id="pinCommentInput" rows="3" class="w-full bg-[#0B0E14] border border-gray-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-gold" placeholder="e.g. Please pull exposure on this window, it's slightly clipped."></textarea>
            </div>
            <div class="flex justify-end gap-3">
                <button type="button" onclick="closePinModal()" class="px-4 py-2 text-xs rounded-lg bg-gray-800 hover:bg-gray-700 text-gray-300">Cancel</button>
                <button type="button" onclick="saveActivePin()" class="px-4 py-2 text-xs font-bold rounded-lg bg-gold hover:bg-gold-light text-black">Save Pin</button>
            </div>
        </div>
    </div>

    <!-- Amendment Submission Modal -->
    <div id="amendmentModal" class="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
        <div class="bg-[#151B28] border border-gray-700 rounded-2xl max-w-lg w-full p-6 shadow-2xl">
            <h3 class="text-base font-bold text-white mb-2 flex items-center gap-2">
                <i class="fas fa-edit text-amber-400"></i> Submit Smart Amendment Request
            </h3>
            <p class="text-xs text-gray-400 mb-4">Your assigned lead editor will receive these exact coordinates and annotations.</p>
            <form method="POST">
                <input type="hidden" name="action" value="request_amendment">
                <input type="hidden" name="annotations_json" id="annotationsFormInput" value="[]">

                <div class="mb-4">
                    <label class="block text-xs font-semibold text-gray-300 mb-1">General Summary / Reason:</label>
                    <select name="reason" class="w-full bg-[#0B0E14] border border-gray-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-gold">
                        <option value="Window clipping / exposure pull">Window clipping / exposure pull</option>
                        <option value="Perspective / crooked verticals">Perspective / crooked verticals</option>
                        <option value="Color cast & white balance">Color cast & white balance</option>
                        <option value="Sky replacement change">Sky replacement change</option>
                        <option value="Other detailed adjustments">Other detailed adjustments</option>
                    </select>
                </div>

                <div class="p-3 bg-gray-900/60 rounded-lg border border-gray-800 text-xs text-gray-400 mb-4">
                    <span class="font-semibold text-white">Attached Pins:</span> <span id="modalPinCount" class="text-gold font-bold">0</span> annotations attached to this revision.
                </div>

                <div class="flex justify-end gap-3">
                    <button type="button" onclick="closeAmendmentModal()" class="px-4 py-2 text-xs rounded-lg bg-gray-800 hover:bg-gray-700 text-gray-300">Cancel</button>
                    <button type="submit" class="px-4 py-2 text-xs font-bold rounded-lg bg-amber-500 hover:bg-amber-400 text-black">Submit Amendment</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Split Slider Dragging Logic
        const viewer = document.getElementById('splitViewer');
        const beforeWrapper = document.getElementById('beforeWrapper');
        const sliderBar = document.getElementById('sliderBar');
        const beforeImg = document.getElementById('beforeImg');
        let isDragging = false;

        function setSliderPosition(x) {
            const rect = viewer.getBoundingClientRect();
            let pos = (x - rect.left) / rect.width;
            if (pos < 0) pos = 0;
            if (pos > 1) pos = 1;
            const pct = (pos * 100).toFixed(2) + '%';
            sliderBar.style.left = pct;
            beforeWrapper.style.width = pct;
            beforeImg.style.width = rect.width + 'px';
        }

        window.addEventListener('resize', () => {
            beforeImg.style.width = viewer.getBoundingClientRect().width + 'px';
        });
        beforeImg.style.width = viewer.getBoundingClientRect().width + 'px';

        sliderBar.addEventListener('mousedown', () => isDragging = true);
        window.addEventListener('mouseup', () => isDragging = false);
        window.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            setSliderPosition(e.clientX);
        });

        // Touch support
        sliderBar.addEventListener('touchstart', () => isDragging = true);
        window.addEventListener('touchend', () => isDragging = false);
        window.addEventListener('touchmove', (e) => {
            if (!isDragging || !e.touches[0]) return;
            setSliderPosition(e.touches[0].clientX);
        });

        // Pinpoint Annotation Logic
        let pinMode = false;
        let pendingPin = null;
        let pins = [];

        function togglePinMode() {
            pinMode = !pinMode;
            const btn = document.getElementById('pinModeBtn');
            const text = document.getElementById('pinModeText');
            if (pinMode) {
                btn.classList.add('bg-gold', 'text-black', 'border-gold');
                btn.classList.remove('bg-gray-800', 'text-gray-300');
                text.textContent = 'Click on image to drop pin';
            } else {
                btn.classList.remove('bg-gold', 'text-black', 'border-gold');
                btn.classList.add('bg-gray-800', 'text-gray-300');
                text.textContent = 'Add Pin Feedback';
            }
        }

        viewer.addEventListener('click', (e) => {
            if (!pinMode || isDragging) return;
            const rect = viewer.getBoundingClientRect();
            const xPct = ((e.clientX - rect.left) / rect.width * 100).toFixed(2);
            const yPct = ((e.clientY - rect.top) / rect.height * 100).toFixed(2);

            pendingPin = { x: xPct, y: yPct };
            document.getElementById('pinCoordsText').textContent = `X: ${xPct}%, Y: ${yPct}%`;
            document.getElementById('pinCommentInput').value = '';
            document.getElementById('pinModal').classList.remove('hidden');
        });

        function closePinModal() {
            pendingPin = null;
            document.getElementById('pinModal').classList.add('hidden');
        }

        function saveActivePin() {
            const comment = document.getElementById('pinCommentInput').value.trim();
            if (!comment || !pendingPin) return;

            const pinObj = {
                id: 'PIN-' + (pins.length + 1),
                x: pendingPin.x,
                y: pendingPin.y,
                comment: comment
            };
            pins.push(pinObj);
            renderPins();
            closePinModal();
            togglePinMode(); // Turn off after placing
        }

        function removePin(idx) {
            pins.splice(idx, 1);
            renderPins();
        }

        function renderPins() {
            const overlay = document.getElementById('pinOverlayLayer');
            const list = document.getElementById('pinsListContainer');
            const badge = document.getElementById('pinCountBadge');
            const modalPinCount = document.getElementById('modalPinCount');
            const formInput = document.getElementById('annotationsFormInput');

            overlay.innerHTML = '';
            badge.textContent = `${pins.length} Pin${pins.length === 1 ? '' : 's'}`;
            modalPinCount.textContent = pins.length;
            formInput.value = JSON.stringify(pins);

            if (pins.length === 0) {
                list.innerHTML = '<p id="noPinsText" class="text-gray-500 text-xs italic col-span-full">No pins added yet. Turn on "Add Pin Feedback" and click anywhere on the image to pinpoint exact corrections.</p>';
                return;
            }

            list.innerHTML = '';
            pins.forEach((pin, i) => {
                // Render marker on image
                const marker = document.createElement('div');
                marker.className = 'pin-marker text-gold text-2xl drop-shadow-md';
                marker.style.left = pin.x + '%';
                marker.style.top = pin.y + '%';
                marker.title = `${pin.id}: ${pin.comment}`;
                marker.innerHTML = `<i class="fas fa-map-marker-alt"></i><span class="absolute -top-1 -right-1 text-[10px] bg-black text-gold rounded-full px-1 font-bold border border-gold">${i+1}</span>`;
                overlay.appendChild(marker);

                // Render list card
                const card = document.createElement('div');
                card.className = 'bg-[#151B28] border border-gray-800 rounded-xl p-3 text-xs flex justify-between items-start gap-2';
                card.innerHTML = `
                    <div>
                        <div class="font-bold text-gold flex items-center gap-1.5 mb-1">
                            <i class="fas fa-map-pin"></i> Pin #${i+1} (${pin.x}%, ${pin.y}%)
                        </div>
                        <p class="text-gray-300">${pin.comment}</p>
                    </div>
                    <button type="button" onclick="removePin(${i})" class="text-gray-500 hover:text-red-400 transition">
                        <i class="fas fa-trash"></i>
                    </button>
                `;
                list.appendChild(card);
            });
        }

        function openAmendmentModal() {
            document.getElementById('amendmentModal').classList.remove('hidden');
        }

        function closeAmendmentModal() {
            document.getElementById('amendmentModal').classList.add('hidden');
        }
    </script>
</body>
</html>
