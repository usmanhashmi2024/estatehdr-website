<?php
/**
 * Estate HDR — Client Direct Management Live Chat & Multi-Order Tracking Hub
 * Allows authenticated clients to chat directly with Management in real time,
 * browse complete order history (processing vs cleared), tag specific orders dynamically,
 * and share screenshots/file attachments.
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/services/ClientChatService.php';

requireLogin();
$currentUser = currentUser();
$dbUser = getUserById($currentUser['id']) ?? $currentUser;
$clientId = $currentUser['id'];

// Fetch client order summary and categorized list
$orderSummary = ClientChatService::getClientOrderSummary($clientId);
$myOrders = $orderSummary['orders'];

// Load or initialize client live chat thread
$chatThread = ClientChatService::getClientThread($clientId, $currentUser);
ClientChatService::markReadForClient($clientId);

// Tickets handler (for formal dispute escalations)
$ticketsFile = defined('DATA_PATH') ? DATA_PATH . 'tickets.json' : (__DIR__ . '/../data/tickets.json');
$allTickets = file_exists($ticketsFile) ? (json_decode(@file_get_contents($ticketsFile), true) ?: []) : [];
$flash = '';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['action_new_ticket'])) {
    $subject = trim($_POST['subject'] ?? 'Support Inquiry');
    $category = trim($_POST['category'] ?? 'General');
    $priority = trim($_POST['priority'] ?? 'Normal');
    $message = trim($_POST['message'] ?? '');
    $orderRef = trim($_POST['order_ref'] ?? '');

    $slaHours = match ($priority) {
        'Critical' => 0.5,
        'High'     => 1,
        'Low'      => 24,
        default    => 4
    };

    $newTicket = [
        'id'            => 'TCK-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6)),
        'client_id'     => $clientId,
        'client_name'   => $currentUser['name'] ?? 'Client',
        'client_email'  => $currentUser['email'] ?? '',
        'subject'       => $subject,
        'category'      => $category,
        'priority'      => $priority,
        'sla_hours'     => $slaHours,
        'order_ref'     => $orderRef,
        'status'        => 'open',
        'created_at'    => date('Y-m-d H:i:s'),
        'target_sla_at' => date('Y-m-d H:i:s', time() + ($slaHours * 3600)),
        'messages'      => [
            [
                'sender'    => 'client',
                'name'      => $currentUser['name'] ?? 'Client',
                'message'   => $message,
                'timestamp' => date('Y-m-d H:i:s')
            ]
        ]
    ];

    $allTickets[] = $newTicket;
    @file_put_contents($ticketsFile, json_encode($allTickets, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX);
    $flash = "Support ticket #{$newTicket['id']} submitted successfully. Our production lead will review it within SLA.";
}

$myTickets = array_values(array_filter($allTickets, fn($t) => ($t['client_id'] ?? '') === $clientId));
usort($myTickets, fn($a, $b) => strtotime($b['created_at'] ?? 'now') <=> strtotime($a['created_at'] ?? 'now'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Management Live Chat &amp; Order Tracking — Estate HDR</title>
    <link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
        tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E',light:'#E5C05D'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}};
    </script>
    <link rel="stylesheet" href="/assets/css/app.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .chat-drag-over {
            border: 2px dashed #C9A84C !important;
            background-color: rgba(201, 168, 76, 0.08) !important;
        }
    </style>
</head>
<body class="bg-[#0A0A0F] text-gray-200 font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/portal-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-6 space-y-6">

    <!-- ── 1. BREADCRUMB & HEADER ──────────────────────────────────── -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#111118] p-5 sm:p-6 rounded-3xl border border-dark-border shadow-xl">
        <div>
            <div class="flex items-center gap-3 mb-1.5">
                <a href="/dashboard.php" class="text-gold hover:underline text-xs font-bold inline-flex items-center gap-1.5">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
                <span class="text-gray-600">•</span>
                <span class="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/40 text-emerald-400 text-xs font-bold">
                    <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                    Management Live Standby
                </span>
            </div>
            <h1 class="text-2xl sm:text-3xl font-black text-white flex items-center gap-2.5">
                <span>💬 Direct Management Chat &amp; Order Desk</span>
            </h1>
            <p class="text-xs sm:text-sm text-gray-400 mt-1 max-w-2xl leading-relaxed">
                Chat directly with our shift production director &amp; lead supervisors. Track live progress on your property photos, tag any specific order, or attach screenshots.
            </p>
        </div>

        <div class="flex flex-wrap items-center gap-3">
            <a href="https://wa.me/447706068176?text=Hi%20Estate%20HDR%20Management%2C%20I%20am%20chatting%20from%20my%20client%20portal%20account" target="_blank" class="px-4 py-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-400 text-xs font-bold transition flex items-center gap-2">
                <i class="fab fa-whatsapp text-sm"></i> <span>WhatsApp Live Support</span>
            </a>
            <button type="button" onclick="document.getElementById('ticketModal').classList.remove('hidden')" class="btn-ghost py-2 px-4 text-xs font-bold border border-gold/40 text-gold hover:bg-gold/10 rounded-xl flex items-center gap-1.5">
                <span>🎫</span> <span>Open Formal Ticket</span>
            </button>
        </div>
    </div>

    <!-- ── 2. ORDER METRICS KPI RIBBON ─────────────────────────────── -->
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <div class="bg-[#111118] border border-dark-border p-4 rounded-2xl flex items-center justify-between">
            <div>
                <p class="text-[11px] font-bold uppercase tracking-wider text-gray-400">Total Properties</p>
                <h4 class="text-xl sm:text-2xl font-black text-white mt-1"><?= (int)$orderSummary['total'] ?></h4>
            </div>
            <div class="w-10 h-10 rounded-xl bg-gray-800/80 border border-gray-700 flex items-center justify-center text-lg text-gray-300">
                📦
            </div>
        </div>

        <div class="bg-[#111118] border border-dark-border p-4 rounded-2xl flex items-center justify-between">
            <div>
                <p class="text-[11px] font-bold uppercase tracking-wider text-amber-400">In Retouching</p>
                <h4 class="text-xl sm:text-2xl font-black text-white mt-1"><?= (int)$orderSummary['processing'] ?></h4>
            </div>
            <div class="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-lg text-amber-400">
                🎨
            </div>
        </div>

        <div class="bg-[#111118] border border-dark-border p-4 rounded-2xl flex items-center justify-between">
            <div>
                <p class="text-[11px] font-bold uppercase tracking-wider text-purple-400">In QA Review</p>
                <h4 class="text-xl sm:text-2xl font-black text-white mt-1"><?= (int)$orderSummary['qa'] ?></h4>
            </div>
            <div class="w-10 h-10 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-lg text-purple-400">
                🛡️
            </div>
        </div>

        <div class="bg-[#111118] border border-dark-border p-4 rounded-2xl flex items-center justify-between">
            <div>
                <p class="text-[11px] font-bold uppercase tracking-wider text-emerald-400">Delivered &amp; Cleared</p>
                <h4 class="text-xl sm:text-2xl font-black text-white mt-1"><?= (int)$orderSummary['delivered'] ?></h4>
            </div>
            <div class="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-lg text-emerald-400">
                ✅
            </div>
        </div>
    </div>

    <?php if ($flash): ?>
        <div class="p-4 rounded-2xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
            <i class="fas fa-check-circle text-base"></i> <span><?= htmlspecialchars($flash) ?></span>
        </div>
    <?php endif; ?>

    <!-- ── 3. TWO-COLUMN WORKSPACE: LIVE CHAT (LEFT) & ORDER TRACKING (RIGHT) ── -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

        <!-- ════════════════════════════════════════════════════════════ -->
        <!-- ── LEFT: DIRECT 2-WAY LIVE CHAT CONSOLE (7 COLUMNS) ────── -->
        <!-- ════════════════════════════════════════════════════════════ -->
        <div id="chatConsoleWrapper" class="lg:col-span-7 bg-[#111118] rounded-3xl border border-dark-border shadow-2xl flex flex-col h-[780px] overflow-hidden transition-all">
            
            <!-- Chat Header -->
            <div class="p-4 sm:p-5 bg-[#141420] border-b border-dark-border flex flex-wrap items-center justify-between gap-3">
                <div class="flex items-center gap-3.5">
                    <div class="relative">
                        <div class="w-11 h-11 rounded-2xl bg-gold/20 text-gold border border-gold/50 flex items-center justify-center font-black text-base shadow-glow">
                            EH
                        </div>
                        <span class="w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-[#141420] absolute -bottom-0.5 -right-0.5"></span>
                    </div>
                    <div>
                        <div class="font-bold text-white text-sm flex items-center gap-2">
                            <span>Studio Management Desk</span>
                            <span class="text-[10px] px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-mono font-bold">24/7 Floor</span>
                        </div>
                        <p class="text-xs text-gray-400 mt-0.5">
                            Client: <strong class="text-white"><?= htmlspecialchars($currentUser['name'] ?? 'Client') ?></strong> &bull; Lead: <strong class="text-emerald-400">Sarah (Production Director)</strong>
                        </p>
                    </div>
                </div>

                <!-- Order Tag Indicator in Header -->
                <div class="flex items-center gap-2">
                    <span id="headerTagBadge" class="text-[11px] px-3 py-1 rounded-xl bg-gray-800/80 border border-gray-700 text-gray-300 font-mono font-bold flex items-center gap-1.5">
                        <span>💬 General Chat</span>
                    </span>
                </div>
            </div>

            <!-- Messages Stream -->
            <div id="chatMessagesContainer" class="flex-1 p-5 overflow-y-auto space-y-4 bg-[#0B0C12]/50">
                <?php foreach (($chatThread['messages'] ?? []) as $msg): 
                    $isClient = ($msg['sender'] ?? '') === 'client';
                    $att = $msg['attachment'] ?? null;
                ?>
                    <div class="flex flex-col <?= $isClient ? 'items-end' : 'items-start' ?> space-y-1">
                        <div class="flex items-center gap-2 text-[10px] text-gray-400">
                            <strong class="<?= $isClient ? 'text-gold' : 'text-blue-300' ?>">
                                <?= htmlspecialchars($msg['sender_name'] ?? ($isClient ? 'You' : 'Management')) ?>
                            </strong>
                            <span>•</span>
                            <span class="font-mono"><?= date('H:i', strtotime($msg['timestamp'] ?? 'now')) ?></span>
                            <?php if (!empty($msg['order_id'])): ?>
                                <span class="px-2 py-0.5 rounded bg-gold/15 text-gold border border-gold/30 font-mono font-bold">
                                    🏷️ #<?= htmlspecialchars($msg['order_id']) ?>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="max-w-[85%] sm:max-w-[75%] p-3.5 rounded-2xl text-xs leading-relaxed <?= $isClient 
                            ? 'bg-gradient-to-br from-[#1C180E] to-[#12110B] border border-gold/40 text-gray-100 rounded-br-sm shadow-md' 
                            : 'bg-[#161624] border border-gray-700/80 text-gray-200 rounded-bl-sm shadow-md' ?>">
                            
                            <?php if (!empty($msg['text'])): ?>
                                <p><?= nl2br(htmlspecialchars($msg['text'])) ?></p>
                            <?php endif; ?>

                            <!-- Attachment Display -->
                            <?php if (!empty($att)): ?>
                                <div class="mt-2 pt-2 border-t border-gray-700/50">
                                    <?php if (!empty($att['is_image'])): ?>
                                        <div class="relative group cursor-pointer" onclick="openLightbox('<?= htmlspecialchars($att['file_url'], ENT_QUOTES) ?>', '<?= htmlspecialchars($att['file_name'], ENT_QUOTES) ?>')">
                                            <img src="<?= htmlspecialchars($att['file_url']) ?>" alt="Attached image" class="max-h-48 max-w-full rounded-xl object-cover border border-gray-700 group-hover:border-gold transition">
                                            <div class="absolute inset-0 bg-black/40 rounded-xl opacity-0 group-hover:opacity-100 transition flex items-center justify-center text-white text-xs font-bold gap-1.5">
                                                <i class="fas fa-search-plus"></i> View Full Image
                                            </div>
                                        </div>
                                        <div class="text-[10px] text-gray-400 mt-1 flex items-center justify-between">
                                            <span class="truncate max-w-[180px]"><?= htmlspecialchars($att['file_name']) ?></span>
                                            <span class="font-mono"><?= round(($att['file_size'] ?? 0) / 1024) ?> KB</span>
                                        </div>
                                    <?php else: ?>
                                        <a href="<?= htmlspecialchars($att['file_url']) ?>" download class="flex items-center gap-2.5 p-2 rounded-xl bg-black/30 border border-gray-700/80 hover:border-gold/40 text-gray-200 transition">
                                            <span class="text-xl text-gold">📄</span>
                                            <div class="flex-1 min-w-0">
                                                <div class="font-bold text-xs truncate"><?= htmlspecialchars($att['file_name']) ?></div>
                                                <div class="text-[10px] text-gray-400 font-mono"><?= round(($att['file_size'] ?? 0) / 1024) ?> KB &bull; Click to download</div>
                                            </div>
                                            <i class="fas fa-download text-xs text-gold"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>

                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Quick Inquiry Pills -->
            <div class="px-4 py-2 bg-[#141420] border-t border-dark-border flex items-center gap-2 overflow-x-auto text-[11px] whitespace-nowrap">
                <span class="text-gray-500 font-bold text-[10px] uppercase tracking-wider">Quick Actions:</span>
                <button type="button" onclick="setQuickMessage('⚡ Please expedite this order as an urgent rush priority.')" class="px-2.5 py-1 rounded-lg bg-[#1D1D2D] hover:bg-gold/20 text-gray-300 hover:text-gold border border-gray-700 transition">
                    ⚡ Request Rush
                </button>
                <button type="button" onclick="setQuickMessage('🔍 When will my photos be ready for download?')" class="px-2.5 py-1 rounded-lg bg-[#1D1D2D] hover:bg-gold/20 text-gray-300 hover:text-gold border border-gray-700 transition">
                    🔍 Delivery Status
                </button>
                <button type="button" onclick="setQuickMessage('🎨 I have a revision note regarding the window exposure / lawn grass.')" class="px-2.5 py-1 rounded-lg bg-[#1D1D2D] hover:bg-gold/20 text-gray-300 hover:text-gold border border-gray-700 transition">
                    🎨 Revision Note
                </button>
                <button type="button" onclick="setQuickMessage('💰 Question regarding my latest billing invoice.')" class="px-2.5 py-1 rounded-lg bg-[#1D1D2D] hover:bg-gold/20 text-gray-300 hover:text-gold border border-gray-700 transition">
                    💰 Billing Question
                </button>
            </div>

            <!-- Dynamic Order Tag Selector Bar -->
            <div class="px-4 py-2 bg-[#10101A] border-t border-dark-border flex flex-wrap items-center justify-between gap-2 text-xs">
                <div class="flex items-center gap-2">
                    <span class="text-gray-400 font-bold text-[11px] flex items-center gap-1">
                        <i class="fas fa-tag text-gold"></i> Mention Order:
                    </span>
                    <select id="chatOrderSelect" onchange="onOrderSelectChange()" class="bg-[#0B0C12] border border-gray-700 rounded-xl px-2.5 py-1 text-xs text-white focus:border-gold focus:outline-none max-w-[240px]">
                        <option value="">💬 General Message (No Order Tag)</option>
                        <?php foreach ($myOrders as $ord): ?>
                            <option value="<?= htmlspecialchars($ord['id']) ?>">
                                #<?= htmlspecialchars($ord['id']) ?> — <?= htmlspecialchars(substr($ord['address'], 0, 24)) ?> (<?= htmlspecialchars($ord['status_label']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <div id="activeTagPill" class="hidden items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-gold/15 border border-gold/40 text-gold text-[11px] font-mono font-bold">
                        <span id="activeTagPillText"></span>
                        <button type="button" onclick="clearTaggedOrder()" class="hover:text-red-400 transition" title="Remove order tag">&times;</button>
                    </div>
                </div>

                <div class="text-[11px] text-gray-500">
                    Press <kbd class="px-1.5 py-0.5 bg-gray-800 rounded text-gray-300 font-mono text-[10px]">Enter</kbd> to send
                </div>
            </div>

            <!-- Selected Attachment Preview Chip -->
            <div id="attachmentPreviewBar" class="hidden px-4 py-2 bg-[#171726] border-t border-gray-800 flex items-center justify-between text-xs text-gray-300">
                <div class="flex items-center gap-2 truncate">
                    <span id="attPreviewIcon" class="text-gold text-base">📎</span>
                    <span id="attPreviewName" class="font-bold truncate max-w-[260px]"></span>
                    <span id="attPreviewDim" class="text-[11px] text-gray-400 font-mono"></span>
                </div>
                <button type="button" onclick="removeSelectedAttachment()" class="text-gray-400 hover:text-red-400 text-sm px-2 py-0.5 rounded transition">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <!-- Live Chat Input Bar -->
            <div class="p-4 bg-[#141420] border-t border-dark-border">
                <form id="chatSendForm" onsubmit="handleSendClientMessage(event)" class="flex items-end gap-3">
                    
                    <!-- Hidden File Input -->
                    <input 
                        type="file" 
                        id="chatFileInput" 
                        onchange="onFileSelected(this)" 
                        accept="image/jpeg,image/png,image/webp,application/pdf,application/zip" 
                        class="hidden"
                    >

                    <!-- Attachment Button -->
                    <button 
                        type="button" 
                        onclick="document.getElementById('chatFileInput').click()" 
                        class="p-3 rounded-2xl bg-[#0B0C12] hover:bg-gold/10 border border-gray-700 hover:border-gold/50 text-gray-300 hover:text-gold transition flex items-center justify-center shrink-0" 
                        title="Attach Photo or Document"
                    >
                        <i class="fas fa-paperclip text-base"></i>
                    </button>

                    <!-- Text Area -->
                    <textarea 
                        id="chatInputText" 
                        rows="2" 
                        placeholder="Write a message to Management or describe an issue with a property... (Press Enter to send)" 
                        class="flex-1 bg-[#0B0C12] border border-gray-700 rounded-2xl p-3 text-xs text-white focus:border-gold focus:outline-none resize-none leading-relaxed"
                        onkeydown="if(event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); handleSendClientMessage(event); }"
                    ></textarea>
                    
                    <!-- Send Button -->
                    <button type="submit" id="chatSendBtn" class="btn-gold px-5 py-3 rounded-2xl font-black text-xs shadow-glow flex flex-col items-center justify-center gap-1 shrink-0">
                        <i class="fas fa-paper-plane text-sm"></i>
                        <span>Send</span>
                    </button>
                </form>
            </div>

        </div>

        <!-- ════════════════════════════════════════════════════════════ -->
        <!-- ── RIGHT: COMPREHENSIVE ORDER LIST & TRACKER (5 COLUMNS) ── -->
        <!-- ════════════════════════════════════════════════════════════ -->
        <div class="lg:col-span-5 space-y-6">

            <!-- 📋 ORDER HISTORY & PRODUCTION TRACKER CARD -->
            <div class="bg-[#111118] rounded-3xl border border-dark-border p-6 shadow-2xl space-y-4">
                
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-dark-border pb-3">
                    <div>
                        <h3 class="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                            <span>📋 Your Property Orders</span>
                        </h3>
                        <p class="text-[11px] text-gray-400 mt-0.5">Click "Tag in Chat" to discuss any specific order.</p>
                    </div>
                    <span class="text-xs text-gold font-mono font-bold"><?= count($myOrders) ?> Properties</span>
                </div>

                <!-- Filter Tabs & Search -->
                <div class="space-y-2.5">
                    <div class="flex items-center gap-1.5 p-1 bg-[#0B0C12] rounded-xl border border-gray-800 text-[11px] font-bold">
                        <button type="button" onclick="filterOrderList('all')" id="tab_all" class="flex-1 py-1 px-2 rounded-lg bg-gold/20 text-gold transition order-filter-tab">
                            All (<?= count($myOrders) ?>)
                        </button>
                        <button type="button" onclick="filterOrderList('processing')" id="tab_processing" class="flex-1 py-1 px-2 rounded-lg text-gray-400 hover:text-white transition order-filter-tab">
                            Retouching (<?= (int)$orderSummary['processing'] ?>)
                        </button>
                        <button type="button" onclick="filterOrderList('qa')" id="tab_qa" class="flex-1 py-1 px-2 rounded-lg text-gray-400 hover:text-white transition order-filter-tab">
                            QA (<?= (int)$orderSummary['qa'] ?>)
                        </button>
                        <button type="button" onclick="filterOrderList('delivered')" id="tab_delivered" class="flex-1 py-1 px-2 rounded-lg text-gray-400 hover:text-white transition order-filter-tab">
                            Delivered (<?= (int)$orderSummary['delivered'] ?>)
                        </button>
                    </div>

                    <div class="relative">
                        <i class="fas fa-search absolute left-3 top-2.5 text-xs text-gray-500"></i>
                        <input 
                            type="text" 
                            id="orderSearchInput" 
                            oninput="searchOrderList()" 
                            placeholder="Search by order ID or property address..." 
                            class="w-full bg-[#0B0C12] border border-gray-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white focus:border-gold focus:outline-none"
                        >
                    </div>
                </div>

                <?php if (empty($myOrders)): ?>
                    <div class="py-12 text-center text-gray-500 text-xs">
                        <i class="fas fa-camera text-3xl mb-2 text-gray-600"></i>
                        <p class="text-gray-300 font-bold">No Property Orders Placed</p>
                        <p class="mt-1">When you place an order, its real-time 4-step progress and retoucher status will appear here.</p>
                        <a href="/order-new.php" class="btn-gold py-1.5 px-4 text-xs font-bold rounded-xl shadow-glow inline-block mt-3">
                            + Start New Order
                        </a>
                    </div>
                <?php else: ?>
                    <div id="orderCardsContainer" class="space-y-3 max-h-[500px] overflow-y-auto pr-1">
                        <?php foreach ($myOrders as $ord): 
                            $st = $ord['status'];
                            $stage = $ord['stage'];
                            
                            $step = match($stage) {
                                'processing' => 2,
                                'qa'         => 3,
                                'delivered'  => 4,
                                default      => 1
                            };
                            $stepLabel = match($stage) {
                                'processing' => 'Retouching & Sky Replacement',
                                'qa'         => 'Team Lead QA Inspection',
                                'delivered'  => 'Delivered & Cleared',
                                default      => 'Order Received'
                            };
                        ?>
                            <div 
                                class="order-card-item p-4 rounded-2xl bg-[#161622] border border-gray-800 space-y-3 hover:border-gold/40 transition"
                                data-stage="<?= htmlspecialchars($stage) ?>"
                                data-search="<?= htmlspecialchars(strtolower($ord['id'] . ' ' . $ord['address'] . ' ' . $ord['service'])) ?>"
                            >
                                <div class="flex items-start justify-between gap-2">
                                    <div>
                                        <div class="font-bold text-white text-xs flex items-center gap-2">
                                            <span class="font-mono text-gold">#<?= htmlspecialchars($ord['id']) ?></span>
                                            <span class="truncate max-w-[210px]"><?= htmlspecialchars($ord['address']) ?></span>
                                        </div>
                                        <div class="text-[11px] text-gray-400 mt-0.5">
                                            <?= htmlspecialchars($ord['service']) ?> &bull; <?= (int)$ord['photos_count'] ?> Photos
                                        </div>
                                    </div>
                                    <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold border <?= $ord['badge_class'] ?>">
                                        <?= htmlspecialchars($ord['status_label']) ?>
                                    </span>
                                </div>

                                <!-- 4-Step Visual Progress Bar -->
                                <div>
                                    <div class="flex justify-between text-[10px] font-mono text-gray-400 mb-1">
                                        <span>Current: <strong class="text-white"><?= $stepLabel ?></strong></span>
                                        <span class="text-gold font-bold">Step <?= $step ?> / 4</span>
                                    </div>
                                    <div class="grid grid-cols-4 gap-1.5">
                                        <div class="h-1.5 rounded-full <?= $step >= 1 ? 'bg-gold' : 'bg-gray-800' ?>"></div>
                                        <div class="h-1.5 rounded-full <?= $step >= 2 ? 'bg-amber-400' : 'bg-gray-800' ?>"></div>
                                        <div class="h-1.5 rounded-full <?= $step >= 3 ? 'bg-purple-400' : 'bg-gray-800' ?>"></div>
                                        <div class="h-1.5 rounded-full <?= $step >= 4 ? 'bg-emerald-400' : 'bg-gray-800' ?>"></div>
                                    </div>
                                </div>

                                <div class="flex items-center justify-between pt-1 border-t border-gray-800/80 text-[11px]">
                                    <span class="text-gray-400 font-mono text-[10px]">
                                        Placed: <?= date('M j, Y', strtotime($ord['created_at'])) ?>
                                    </span>
                                    
                                    <div class="flex items-center gap-2">
                                        <?php if ($stage === 'delivered'): ?>
                                            <a href="/client/review.php?order_id=<?= urlencode($ord['id']) ?>" class="text-[11px] text-emerald-400 hover:underline font-bold inline-flex items-center gap-1">
                                                <i class="fas fa-eye"></i> View Master
                                            </a>
                                            <span class="text-gray-600">&bull;</span>
                                        <?php endif; ?>
                                        <button 
                                            type="button" 
                                            onclick="tagOrderInChat('<?= htmlspecialchars($ord['id'], ENT_QUOTES) ?>', '<?= htmlspecialchars($ord['address'], ENT_QUOTES) ?>')" 
                                            class="text-xs text-gold hover:underline font-bold inline-flex items-center gap-1"
                                        >
                                            <i class="fas fa-tag"></i> <span>Tag in Chat</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- 🎫 RECENT FORMAL TICKETS SUMMARY -->
            <div class="bg-[#111118] rounded-3xl border border-dark-border p-6 shadow-2xl space-y-4">
                <div class="flex items-center justify-between border-b border-dark-border pb-3">
                    <h3 class="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                        <span>🎫 Formal Support Tickets</span>
                    </h3>
                    <button type="button" onclick="document.getElementById('ticketModal').classList.remove('hidden')" class="text-xs text-gold hover:underline font-bold">
                        + New Ticket
                    </button>
                </div>

                <?php if (empty($myTickets)): ?>
                    <p class="text-xs text-gray-500 py-1">
                        No formal disputes or tickets opened. You can chat directly in the live console on the left for immediate assistance!
                    </p>
                <?php else: ?>
                    <div class="divide-y divide-gray-800/80 text-xs">
                        <?php foreach (array_slice($myTickets, 0, 3) as $t): ?>
                            <div class="py-2.5 flex items-center justify-between">
                                <div>
                                    <strong class="text-white font-mono"><?= htmlspecialchars($t['id']) ?></strong>
                                    <div class="text-[11px] text-gray-400"><?= htmlspecialchars($t['subject']) ?></div>
                                </div>
                                <span class="px-2 py-0.5 rounded text-[10px] font-bold <?= ($t['status'] === 'resolved') ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400' ?>">
                                    <?= strtoupper($t['status']) ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

        </div>

    </div>

</main>

<!-- ── LIGHTBOX MODAL FOR ATTACHED SCREENSHOTS ────────────────────── -->
<div id="imageLightboxModal" class="fixed inset-0 bg-black/90 backdrop-blur-md z-50 hidden flex flex-col items-center justify-center p-4">
    <div class="max-w-4xl w-full flex items-center justify-between text-white pb-3">
        <span id="lightboxFilename" class="text-xs font-mono text-gray-300"></span>
        <div class="flex items-center gap-3">
            <a id="lightboxDownloadBtn" href="#" download class="text-xs text-gold hover:underline flex items-center gap-1.5 font-bold">
                <i class="fas fa-download"></i> Download Full Size
            </a>
            <button type="button" onclick="closeLightbox()" class="text-gray-400 hover:text-white text-2xl font-bold px-2">&times;</button>
        </div>
    </div>
    <div class="max-w-4xl max-h-[80vh] flex items-center justify-center overflow-hidden">
        <img id="lightboxImg" src="" alt="Enlarged screenshot" class="max-w-full max-h-[80vh] object-contain rounded-2xl border border-gray-700">
    </div>
</div>

<!-- ── FORMAL TICKET SUBMISSION MODAL ────────────────────────────── -->
<div id="ticketModal" class="fixed inset-0 bg-dark/80 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
    <div class="glass-card rounded-3xl border border-gold/40 max-w-lg w-full p-6 sm:p-7 shadow-2xl space-y-4">
        <div class="flex items-center justify-between border-b border-gray-800 pb-3">
            <h3 class="text-base font-black text-white flex items-center gap-2">
                <span>🎫</span> <span>Open Enterprise Support Ticket</span>
            </h3>
            <button type="button" onclick="document.getElementById('ticketModal').classList.add('hidden')" class="text-gray-400 hover:text-white text-xl">&times;</button>
        </div>

        <form method="POST" class="space-y-3.5 text-xs">
            <input type="hidden" name="action_new_ticket" value="1">
            
            <div>
                <label class="block text-gray-300 font-bold mb-1">Subject / Issue Summary</label>
                <input type="text" name="subject" required class="w-full bg-[#0B0C12] border border-gray-700 rounded-xl p-2.5 text-white focus:border-gold focus:outline-none" placeholder="e.g. Urgent rush inquiry for listing ORD-5012">
            </div>

            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-gray-300 font-bold mb-1">Link Property Order (Optional)</label>
                    <select name="order_ref" class="w-full bg-[#0B0C12] border border-gray-700 rounded-xl p-2.5 text-white focus:border-gold focus:outline-none">
                        <option value="">None / General</option>
                        <?php foreach ($myOrders as $ord): ?>
                            <option value="<?= htmlspecialchars($ord['id']) ?>">#<?= htmlspecialchars($ord['id']) ?> — <?= htmlspecialchars(substr($ord['address'], 0, 18)) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-gray-300 font-bold mb-1">Priority SLA</label>
                    <select name="priority" class="w-full bg-[#0B0C12] border border-gray-700 rounded-xl p-2.5 text-white focus:border-gold focus:outline-none">
                        <option value="Critical">Critical (30 min SLA)</option>
                        <option value="High">High (1h SLA)</option>
                        <option value="Normal" selected>Normal (4h SLA)</option>
                        <option value="Low">Low (24h SLA)</option>
                    </select>
                </div>
            </div>

            <div>
                <label class="block text-gray-300 font-bold mb-1">Category</label>
                <select name="category" class="w-full bg-[#0B0C12] border border-gray-700 rounded-xl p-2.5 text-white focus:border-gold focus:outline-none">
                    <option value="Production Rush">Production Rush &amp; Expedite</option>
                    <option value="Quality &amp; Revisions">Quality &amp; Revisions Inspection</option>
                    <option value="Billing &amp; Invoice">Billing &amp; Invoice Adjustment</option>
                    <option value="Style Calibration">Custom Style DNA Calibration</option>
                </select>
            </div>

            <div>
                <label class="block text-gray-300 font-bold mb-1">Detailed Inquiry Description</label>
                <textarea name="message" rows="4" required class="w-full bg-[#0B0C12] border border-gray-700 rounded-xl p-2.5 text-white focus:border-gold focus:outline-none leading-relaxed" placeholder="Provide full details or bracket cloud links..."></textarea>
            </div>

            <div class="pt-2 flex justify-end gap-3">
                <button type="button" onclick="document.getElementById('ticketModal').classList.add('hidden')" class="btn-ghost py-2 px-4 rounded-xl text-xs font-bold text-gray-300">
                    Cancel
                </button>
                <button type="submit" class="btn-gold py-2 px-6 rounded-xl text-xs font-black shadow-glow">
                    Submit Formal Ticket
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ── LIVE CHAT JAVASCRIPT CONTROLLER ─────────────────────────── -->
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
const CHAT_API = '/api/client-chat.php';
let lastMessageCount = <?= count($chatThread['messages'] ?? []) ?>;
let selectedFile = null;

function scrollChatToBottom() {
    const box = document.getElementById('chatMessagesContainer');
    if (box) box.scrollTop = box.scrollHeight;
}
window.addEventListener('DOMContentLoaded', scrollChatToBottom);

function setQuickMessage(text) {
    const input = document.getElementById('chatInputText');
    if (input) {
        input.value = text;
        input.focus();
    }
}

// ── Tagging Order in Chat ──────────────────────────────────────
function tagOrderInChat(orderId, propAddress) {
    const select = document.getElementById('chatOrderSelect');
    if (select) {
        select.value = orderId;
    }
    updateTagUI(orderId, propAddress);
    
    const input = document.getElementById('chatInputText');
    if (input) {
        input.focus();
    }
    
    // Smooth scroll to chat console on mobile
    if (window.innerWidth < 1024) {
        document.getElementById('chatConsoleWrapper').scrollIntoView({ behavior: 'smooth' });
    }
}

function onOrderSelectChange() {
    const select = document.getElementById('chatOrderSelect');
    const orderId = select.value;
    if (!orderId) {
        clearTaggedOrder();
    } else {
        const optionText = select.options[select.selectedIndex].text;
        updateTagUI(orderId, optionText);
    }
}

function updateTagUI(orderId, label) {
    const pill = document.getElementById('activeTagPill');
    const pillText = document.getElementById('activeTagPillText');
    const headerBadge = document.getElementById('headerTagBadge');

    if (pill && pillText) {
        pillText.textContent = `🏷️ #${orderId}`;
        pill.classList.remove('hidden');
        pill.classList.add('inline-flex');
    }

    if (headerBadge) {
        headerBadge.innerHTML = `<span class="text-gold font-mono">🏷️ Tagged: #${escapeHtml(orderId)}</span>`;
        headerBadge.classList.add('border-gold/40', 'bg-gold/10');
    }
}

function clearTaggedOrder() {
    const select = document.getElementById('chatOrderSelect');
    if (select) select.value = '';
    
    const pill = document.getElementById('activeTagPill');
    if (pill) {
        pill.classList.add('hidden');
        pill.classList.remove('inline-flex');
    }

    const headerBadge = document.getElementById('headerTagBadge');
    if (headerBadge) {
        headerBadge.innerHTML = `<span>💬 General Chat</span>`;
        headerBadge.classList.remove('border-gold/40', 'bg-gold/10');
    }
}

// ── Attachment Handling ─────────────────────────────────────────
function onFileSelected(input) {
    if (input.files && input.files[0]) {
        setAttachment(input.files[0]);
    }
}

function setAttachment(file) {
    if (file.size > 25 * 1024 * 1024) {
        alert('File size exceeds 25MB limit.');
        return;
    }
    selectedFile = file;

    const bar = document.getElementById('attachmentPreviewBar');
    const nameEl = document.getElementById('attPreviewName');
    const dimEl = document.getElementById('attPreviewDim');
    const iconEl = document.getElementById('attPreviewIcon');

    if (bar && nameEl) {
        nameEl.textContent = file.name;
        const sizeKb = Math.round(file.size / 1024);
        const sizeStr = sizeKb > 1024 ? (sizeKb / 1024).toFixed(1) + ' MB' : sizeKb + ' KB';
        dimEl.textContent = `(${sizeStr})`;

        if (file.type.startsWith('image/')) {
            iconEl.textContent = '🖼️';
        } else if (file.type.includes('pdf')) {
            iconEl.textContent = '📄';
        } else {
            iconEl.textContent = '📦';
        }

        bar.classList.remove('hidden');
    }
}

function removeSelectedAttachment() {
    selectedFile = null;
    const fileInput = document.getElementById('chatFileInput');
    if (fileInput) fileInput.value = '';
    const bar = document.getElementById('attachmentPreviewBar');
    if (bar) bar.classList.add('hidden');
}

// Drag & Drop onto chat
const dropZone = document.getElementById('chatConsoleWrapper');
if (dropZone) {
    ['dragenter', 'dragover'].forEach(name => {
        dropZone.addEventListener(name, (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropZone.classList.add('chat-drag-over');
        });
    });
    ['dragleave', 'drop'].forEach(name => {
        dropZone.addEventListener(name, (e) => {
            e.preventDefault();
            e.stopPropagation();
            dropZone.classList.remove('chat-drag-over');
        });
    });
    dropZone.addEventListener('drop', (e) => {
        if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            setAttachment(e.dataTransfer.files[0]);
        }
    });
}

// ── Sending Messages ───────────────────────────────────────────
async function handleSendClientMessage(e) {
    if (e) e.preventDefault();
    const input = document.getElementById('chatInputText');
    const orderSelect = document.getElementById('chatOrderSelect');
    const btn = document.getElementById('chatSendBtn');

    const text = input.value.trim();
    if (!text && !selectedFile) return;

    const orderId = orderSelect ? orderSelect.value : null;

    btn.disabled = true;
    btn.classList.add('opacity-50');

    try {
        const formData = new FormData();
        formData.append('action', 'send');
        formData.append('text', text);
        if (orderId) formData.append('order_id', orderId);
        if (selectedFile) formData.append('attachment', selectedFile);

        const res = await fetch(CHAT_API, {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        if (data.success && data.messages) {
            renderChatMessages(data.messages);
            input.value = '';
            removeSelectedAttachment();
            scrollChatToBottom();
        } else if (data.error) {
            alert('Error sending message: ' + data.error);
        }
    } catch (err) {
        console.error('Chat send error:', err);
    } finally {
        btn.disabled = false;
        btn.classList.remove('opacity-50');
    }
}

// ── Polling & Rendering ────────────────────────────────────────
async function pollChatMessages() {
    try {
        const res = await fetch(`${CHAT_API}?action=poll&mark_read=1`);
        const data = await res.json();
        if (data.success && data.messages) {
            if (data.messages.length !== lastMessageCount) {
                renderChatMessages(data.messages);
                scrollChatToBottom();
            }
        }
    } catch (err) {
        console.error('Poll error:', err);
    }
}

function renderChatMessages(messages) {
    lastMessageCount = messages.length;
    const container = document.getElementById('chatMessagesContainer');
    if (!container) return;

    let html = '';
    messages.forEach(msg => {
        const isClient = msg.sender === 'client';
        const senderName = msg.sender_name || (isClient ? 'You' : 'Management');
        const timeStr = msg.timestamp ? msg.timestamp.substring(11, 16) : 'Now';
        const orderBadge = msg.order_id 
            ? `<span class="px-2 py-0.5 rounded bg-gold/15 text-gold border border-gold/30 font-mono font-bold">🏷️ #${escapeHtml(msg.order_id)}</span>` 
            : '';

        const bubbleCls = isClient
            ? 'bg-gradient-to-br from-[#1C180E] to-[#12110B] border border-gold/40 text-gray-100 rounded-br-sm shadow-md'
            : 'bg-[#161624] border border-gray-700/80 text-gray-200 rounded-bl-sm shadow-md';

        let attHtml = '';
        if (msg.attachment) {
            const att = msg.attachment;
            if (att.is_image) {
                attHtml = `
                    <div class="mt-2 pt-2 border-t border-gray-700/50">
                        <div class="relative group cursor-pointer" onclick="openLightbox('${escapeHtml(att.file_url)}', '${escapeHtml(att.file_name)}')">
                            <img src="${escapeHtml(att.file_url)}" alt="Attached image" class="max-h-48 max-w-full rounded-xl object-cover border border-gray-700 group-hover:border-gold transition">
                            <div class="absolute inset-0 bg-black/40 rounded-xl opacity-0 group-hover:opacity-100 transition flex items-center justify-center text-white text-xs font-bold gap-1.5">
                                <i class="fas fa-search-plus"></i> View Full Image
                            </div>
                        </div>
                        <div class="text-[10px] text-gray-400 mt-1 flex items-center justify-between">
                            <span class="truncate max-w-[180px]">${escapeHtml(att.file_name)}</span>
                            <span class="font-mono">${Math.round((att.file_size || 0)/1024)} KB</span>
                        </div>
                    </div>
                `;
            } else {
                attHtml = `
                    <div class="mt-2 pt-2 border-t border-gray-700/50">
                        <a href="${escapeHtml(att.file_url)}" download class="flex items-center gap-2.5 p-2 rounded-xl bg-black/30 border border-gray-700/80 hover:border-gold/40 text-gray-200 transition">
                            <span class="text-xl text-gold">📄</span>
                            <div class="flex-1 min-w-0">
                                <div class="font-bold text-xs truncate">${escapeHtml(att.file_name)}</div>
                                <div class="text-[10px] text-gray-400 font-mono">${Math.round((att.file_size || 0)/1024)} KB &bull; Click to download</div>
                            </div>
                            <i class="fas fa-download text-xs text-gold"></i>
                        </a>
                    </div>
                `;
            }
        }

        html += `
            <div class="flex flex-col ${isClient ? 'items-end' : 'items-start'} space-y-1">
                <div class="flex items-center gap-2 text-[10px] text-gray-400">
                    <strong class="${isClient ? 'text-gold' : 'text-blue-300'}">${escapeHtml(senderName)}</strong>
                    <span>•</span>
                    <span class="font-mono">${escapeHtml(timeStr)}</span>
                    ${orderBadge}
                </div>
                <div class="max-w-[85%] sm:max-w-[75%] p-3.5 rounded-2xl text-xs leading-relaxed ${bubbleCls}">
                    ${msg.text ? `<p>${nl2br(escapeHtml(msg.text))}</p>` : ''}
                    ${attHtml}
                </div>
            </div>
        `;
    });

    container.innerHTML = html;
}

// ── Lightbox Functions ─────────────────────────────────────────
function openLightbox(url, filename) {
    const modal = document.getElementById('imageLightboxModal');
    const img = document.getElementById('lightboxImg');
    const nameEl = document.getElementById('lightboxFilename');
    const dlBtn = document.getElementById('lightboxDownloadBtn');

    if (modal && img) {
        img.src = url;
        if (nameEl) nameEl.textContent = filename;
        if (dlBtn) dlBtn.href = url;
        modal.classList.remove('hidden');
    }
}

function closeLightbox() {
    const modal = document.getElementById('imageLightboxModal');
    if (modal) modal.classList.add('hidden');
}

// ── Order List Filter & Search ─────────────────────────────────
let activeStageFilter = 'all';

function filterOrderList(stage) {
    activeStageFilter = stage;
    
    // Update active tab buttons
    document.querySelectorAll('.order-filter-tab').forEach(b => {
        b.classList.remove('bg-gold/20', 'text-gold');
        b.classList.add('text-gray-400');
    });
    const activeBtn = document.getElementById('tab_' + stage);
    if (activeBtn) {
        activeBtn.classList.add('bg-gold/20', 'text-gold');
        activeBtn.classList.remove('text-gray-400');
    }

    applyOrderFilters();
}

function searchOrderList() {
    applyOrderFilters();
}

function applyOrderFilters() {
    const searchVal = (document.getElementById('orderSearchInput')?.value || '').toLowerCase().trim();
    const cards = document.querySelectorAll('.order-card-item');

    cards.forEach(card => {
        const cardStage = card.getAttribute('data-stage') || '';
        const searchData = card.getAttribute('data-search') || '';

        const stageMatches = (activeStageFilter === 'all' || cardStage === activeStageFilter);
        const searchMatches = (!searchVal || searchData.includes(searchVal));

        if (stageMatches && searchMatches) {
            card.classList.remove('hidden');
        } else {
            card.classList.add('hidden');
        }
    });
}

function escapeHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function nl2br(str) {
    return str.replace(/\n/g, '<br>');
}

// Poll every 3 seconds for live 2-way management responses
setInterval(pollChatMessages, 3000);
</script>

</body>
</html>
