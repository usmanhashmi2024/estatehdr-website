<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
requireLogin();

$user  = currentUser();
$prefs = getUserPreferences($user['id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $data = [
        'color_style'           => trim($_POST['color_style'] ?? 'natural'),
        'sky_replacement'       => trim($_POST['sky_replacement'] ?? 'blue_sunny'),
        'window_treatment'      => trim($_POST['window_treatment'] ?? 'full_window_pull'),
        'grass_greening'        => isset($_POST['grass_greening']),
        'tv_screen_replacement' => isset($_POST['tv_screen_replacement']),
        'fire_in_fireplace'     => isset($_POST['fire_in_fireplace']),
        'default_notes'         => trim($_POST['default_notes'] ?? ''),
        'reference_links'       => trim($_POST['reference_links'] ?? ''),
    ];
    saveUserPreferences($user['id'], $data);
    setFlash('success', 'Your Style Preferences have been saved! They will automatically apply to all future orders.');
    header('Location: /preferences.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Style Preferences Center — Estate HDR</title>
<meta name="robots" content="noindex">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-[#0A0A0F] text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/includes/portal-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8">
  <?= renderFlash() ?>

  <div class="mb-8">
    <div class="section-tag mb-2">Preset Profiles</div>
    <h1 class="text-2xl sm:text-3xl font-bold text-white">Style Preferences Center</h1>
    <p class="text-gray-400 text-sm mt-1">Save your signature editing style. Our editors will automatically follow these presets on every job you submit.</p>
  </div>

  <div class="glass-card rounded-2xl p-8 border border-dark-border shadow-2xl">
    <form method="POST" class="space-y-8">
      <?= csrfField() ?>

      <!-- 1. Color Grading Style -->
      <div>
        <label class="form-label text-white text-sm mb-3 block font-bold">1. Signature Color Grading &amp; Temperature</label>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <?php
          $colorOptions = [
            ['id' => 'natural', 'title' => 'Natural True-to-Life', 'desc' => 'Accurate wall colors, balanced neutral whites, lifelike tone.'],
            ['id' => 'vibrant', 'title' => 'Vibrant & Punchy', 'desc' => 'Slightly boosted saturation, bright cheerful contrast.'],
            ['id' => 'moody_warm', 'title' => 'Warm & Cozy Ambiance', 'desc' => 'Warm golden tones, cozy interior lighting, soft contrast.'],
            ['id' => 'airy_crisp', 'title' => 'High-Key Airy & Crisp', 'desc' => 'Ultra-bright ceilings, clean Scandinavian white balance.'],
          ];
          foreach ($colorOptions as $opt):
            $checked = ($prefs['color_style'] === $opt['id']) ? 'checked' : '';
          ?>
          <label class="glass-card p-4 rounded-xl cursor-pointer border border-dark-border hover:border-gold/40 flex items-start gap-3 transition-all">
            <input type="radio" name="color_style" value="<?= $opt['id'] ?>" <?= $checked ?> class="mt-1 accent-[#C9A84C]">
            <div>
              <div class="font-bold text-white text-sm"><?= $opt['title'] ?></div>
              <div class="text-xs text-gray-400 mt-1"><?= $opt['desc'] ?></div>
            </div>
          </label>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- 2. Sky Replacement -->
      <div>
        <label class="form-label text-white text-sm mb-3 block font-bold">2. Default Sky Replacement Style</label>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <?php
          $skyOptions = [
            ['id' => 'blue_sunny', 'title' => '☀️ Crisp Blue Sunny Sky', 'desc' => 'Clear blue sky with light fluffy clouds.'],
            ['id' => 'sunset_dusk', 'title' => '🌅 Golden Sunset Glow', 'desc' => 'Warm orange & purple gradient sunset sky.'],
            ['id' => 'soft_clouds', 'title' => '☁️ Soft Cloud Diffused', 'desc' => 'Natural overcast sky replacement.'],
            ['id' => 'keep_original', 'title' => '📷 Keep Original Sky', 'desc' => 'Enhance original exposure without replacing.'],
          ];
          foreach ($skyOptions as $opt):
            $checked = ($prefs['sky_replacement'] === $opt['id']) ? 'checked' : '';
          ?>
          <label class="glass-card p-4 rounded-xl cursor-pointer border border-dark-border hover:border-gold/40 flex items-start gap-3 transition-all">
            <input type="radio" name="sky_replacement" value="<?= $opt['id'] ?>" <?= $checked ?> class="mt-1 accent-[#C9A84C]">
            <div>
              <div class="font-bold text-white text-sm"><?= $opt['title'] ?></div>
              <div class="text-xs text-gray-400 mt-1"><?= $opt['desc'] ?></div>
            </div>
          </label>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- 3. Window Pull Style -->
      <div>
        <label class="form-label text-white text-sm mb-3 block font-bold">3. Window Exposure &amp; Glare Handling</label>
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <?php
          $windowOptions = [
            ['id' => 'full_window_pull', 'title' => 'Crystal Window Pull', 'desc' => '100% sharp exterior views with zero blown glare.'],
            ['id' => 'soft_ambient_pull', 'title' => 'Soft Ambient Pull', 'desc' => 'Natural slight glow with balanced exterior.'],
            ['id' => 'standard', 'title' => 'Standard HDR Pull', 'desc' => 'Balanced exposure based on room lighting.'],
          ];
          foreach ($windowOptions as $opt):
            $checked = ($prefs['window_treatment'] === $opt['id']) ? 'checked' : '';
          ?>
          <label class="glass-card p-4 rounded-xl cursor-pointer border border-dark-border hover:border-gold/40 flex items-start gap-2.5 transition-all">
            <input type="radio" name="window_treatment" value="<?= $opt['id'] ?>" <?= $checked ?> class="mt-1 accent-[#C9A84C]">
            <div>
              <div class="font-bold text-white text-xs"><?= $opt['title'] ?></div>
              <div class="text-xs text-gray-400 mt-1 leading-tight"><?= $opt['desc'] ?></div>
            </div>
          </label>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- 4. Default Enhancements Checklist -->
      <div>
        <label class="form-label text-white text-sm mb-3 block font-bold">4. Automatic Default Enhancements</label>
        <div class="space-y-3">
          <label class="flex items-center gap-3 cursor-pointer">
            <input type="checkbox" name="grass_greening" value="1" <?= $prefs['grass_greening'] ? 'checked' : '' ?> class="w-4 h-4 rounded accent-[#C9A84C]">
            <span class="text-sm text-gray-200">Automatically green and enhance patchy lawns / yards</span>
          </label>
          <label class="flex items-center gap-3 cursor-pointer">
            <input type="checkbox" name="tv_screen_replacement" value="1" <?= $prefs['tv_screen_replacement'] ? 'checked' : '' ?> class="w-4 h-4 rounded accent-[#C9A84C]">
            <span class="text-sm text-gray-200">Replace blank TV screens with tasteful architectural / art images</span>
          </label>
          <label class="flex items-center gap-3 cursor-pointer">
            <input type="checkbox" name="fire_in_fireplace" value="1" <?= $prefs['fire_in_fireplace'] ? 'checked' : '' ?> class="w-4 h-4 rounded accent-[#C9A84C]">
            <span class="text-sm text-gray-200">Add warm flames into empty fireplaces</span>
          </label>
        </div>
      </div>

      <!-- 5. Default Permanent Notes -->
      <div>
        <label class="form-label text-white text-sm mb-2 block font-bold">5. Permanent Default Notes</label>
        <textarea name="default_notes" rows="3" class="form-input resize-y text-sm" placeholder="e.g. Always remove electrical cords near the TV, preserve true hardwood floor color, never oversaturate yellow walls..."><?= htmlspecialchars($prefs['default_notes']) ?></textarea>
        <p class="text-gray-500 text-xs mt-1.5">These notes will be automatically appended to every new order you place.</p>
      </div>

      <!-- 6. Style Reference Links -->
      <div>
        <label class="form-label text-white text-sm mb-2 block font-bold">6. Reference Portfolio / Sample Links</label>
        <input type="url" name="reference_links" value="<?= htmlspecialchars($prefs['reference_links']) ?>" class="form-input text-sm" placeholder="https://drive.google.com/... (Link to examples of how you like your photos edited)">
        <p class="text-gray-500 text-xs mt-1.5">Paste a Dropbox or Google Drive link containing 2-5 photos representing your ideal editing style.</p>
      </div>

      <div class="pt-4 flex gap-4">
        <button type="submit" class="btn-gold flex-1 py-3 font-bold shadow-glow">
          Save Style Preferences
        </button>
        <a href="/dashboard.php" class="btn-ghost py-3 px-6 text-sm">Cancel</a>
      </div>
    </form>
  </div>
</main>
</body>
</html>
