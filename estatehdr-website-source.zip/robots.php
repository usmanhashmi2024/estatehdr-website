<?php
/**
 * Estate HDR — Real-Time Live robots.txt Output Engine
 * Ensures 0-cache real-time synchronization between Admin Editor and Public /robots.txt
 */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';

// Force NO-CACHE headers across all browsers, Cloudflare, and Hostinger CDN (hcdn)
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0, s-maxage=0');
header('Pragma: no-cache');
header('Expires: 0');
header('Surrogate-Control: no-store');
header('X-Accel-Expires: 0');

$seoSettings = getSeoSettings();
$robotsFile = defined('ROOT_PATH') ? (rtrim(ROOT_PATH, '/') . '/robots.txt') : (__DIR__ . '/robots.txt');

if (isset($seoSettings['robots_txt'])) {
    echo $seoSettings['robots_txt'];
} elseif (file_exists($robotsFile)) {
    echo file_get_contents($robotsFile);
} else {
    echo "User-agent: *\nAllow: /\nDisallow: /admin/\nDisallow: /api/\nDisallow: /data/\nDisallow: /cron/\n\nSitemap: https://estatehdr.com/sitemap.xml\n";
}
exit;
