# TEST_INFRA.md — Estate HDR Visitor Intelligence Hub E2E Testing Infrastructure

## 1. Overview & Architecture
This document specifies the end-to-end testing infrastructure, automated opaque-box test runner, and verification matrices for the **Estate HDR Visitor Intelligence Hub** transformation (`admin/live-visitors.php`, `includes/db.php`, `api/visitor-ping.php`, `api/chat-live.php`, `api/crm-tickets.php`, `includes/chat-widgets.php`).

The test suite is built natively in PHP CLI without external vendor dependencies (no Composer or third-party test runners required), ensuring high execution speed, zero configuration overhead, and deterministic execution across Windows, Linux, and macOS environments.

---

## 2. Test Directory & File Layout

```
Estate HDR Site/
├── TEST_INFRA.md                       # Comprehensive Test Architecture & Specifications
├── TEST_READY.md                       # Test Verification Certification & Execution Sign-off
├── tests/
│   └── e2e/
│       ├── test_framework.php          # Native Assertion Engine, Sandboxing & Request Simulator
│       ├── run_tests.php               # Master Test Runner CLI (Summary, Timing, Exit Codes)
│       ├── test_tier1_features.php     # Tier 1: Isolation Tests (Features 1–24, >=5 tests each)
│       ├── test_tier2_boundaries.php   # Tier 2: Boundary, Edge Cases, Stress & Sanitization
│       ├── test_tier3_combinations.php # Tier 3: Cross-Feature Integration & Concurrency
│       └── test_tier4_scenarios.php    # Tier 4: Real-World End-to-End Operational Workflows
```

---

## 3. Test Runner Specifications

### 3.1 Execution Commands
The test suite can be run using either standard system `php` (if in PATH) or the full path to PHP CLI:

```powershell
# Run entire E2E test suite (Tiers 1–4)
php tests/e2e/run_tests.php
# Or on Windows XAMPP environment:
& "C:\xampp\php\php.exe" tests/e2e/run_tests.php

# Run individual tiers
php tests/e2e/run_tests.php --tier=1
php tests/e2e/run_tests.php --tier=2
php tests/e2e/run_tests.php --tier=3
php tests/e2e/run_tests.php --tier=4

# Filter tests by feature or name
php tests/e2e/run_tests.php --filter="Lead Scoring"
```

### 3.2 Runner Output Format
- Real-time ANSI colored terminal output (`[PASS]` in green, `[FAIL]` in red, `[SKIP]` in yellow).
- Per-test assertion counters, elapsed execution time (ms), and failure diagnostics (expected vs actual, line number, payload diff).
- Clean summary table detailing total tests executed, passed, failed, skipped, and total elapsed duration.
- Exit code `0` on 100% success; Exit code `1` on any failure.

---

## 4. Test Sandbox & Isolation Architecture

Every test run executes within an isolated, sandboxed environment:
1. **Isolated Data Directory (`TestEnvironment::setupSandbox()`):**
   - Automatically provisions a temporary test data directory (`data/test_sandbox_<id>/`).
   - Copies clean base fixtures (`visitors.json`, `live_chats.json`, `leads.json`, `contacts.json`, `tickets.json`, `chat_automations.json`, `widget_settings.json`, `knowledge_base.json`).
   - Restores original state and cleans up temporary sandboxes upon completion (`TestEnvironment::teardownSandbox()`).
2. **Subprocess & Superglobal Request Simulation (`RequestSimulator`):**
   - Simulates HTTP POST, GET, JSON request bodies (`php://input`), and session/cookie parameters.
   - Captures HTTP response status codes, header outputs, JSON payloads, and rendered HTML buffers.
   - Prevents script termination (`exit`/`die`) from halting the master runner.

---

## 5. Comprehensive Feature Coverage Matrix (Tiers 1–4)

| # | Feature Name | Tier 1 (Isolation) | Tier 2 (Boundary) | Tier 3 (Combination) | Tier 4 (Scenario) |
|---|--------------|--------------------|-------------------|----------------------|-------------------|
| 1 | Flat-File JSON Concurrency & Atomic Writes | 5 Tests | Stress & File Lock | Concurrency Pings | Multi-user I/O |
| 2 | Command Center Tab Navigation & Layout | 5 Tests | Missing params/RBAC | Tab State Persistence | Admin Navigation |
| 3 | Executive KPI Summary Dashboard | 5 Tests | Zero data / Max load | Live Aggregation | Management Report |
| 4 | 3-State Live Presence Engine | 5 Tests | Edge timestamps | State Transitions | Real-time Lifecycle |
| 5 | Interactive Visitor Radar & Geo-Map | 5 Tests | Malformed IP / Private | Geo Aggregation | Global Visitors |
| 6 | Slide-over Visitor Drawer & Journey | 5 Tests | Huge journey stack | Dwell & Scoring Link | Deep Session Audit |
| 7 | 2-Way Real-Time Live Chat Console | 5 Tests | Long strings / Unicode | Chat + CSR Bridge | Full Inquiry Flow |
| 8 | Real-Time Typing Sneak-Peek Sync | 5 Tests | 6s Expiration / Empty | Keystroke Sync Flow | Agent Preview |
| 9 | Canned Quick Replies & Slash Commands | 5 Tests | Special chars / chips | Slash Expansion | Fast Agent Reply |
| 10 | Synthesized Web Audio Notification | 5 Tests | Suppressed prefs | Unread Signal Chime | Alert Triggering |
| 11 | Omnichannel Multi-Channel Filter | 5 Tests | Unknown channels | Multi-channel stream | WhatsApp/Email Hand-off |
| 12 | Internal Private Agent Notes | 5 Tests | Visitor leak check | Notes in Transcripts | Team Escalation |
| 13 | Multi-Role Team Assignment | 5 Tests | Role reassignments | Inbox Role Filter | Department Routing |
| 14 | Dynamic Lead Scoring Engine (0–100) | 5 Tests | Bounds (0, 100, -1) | Multi-event Scoring | Lead Progression |
| 15 | Lead Temperature Tiers | 5 Tests | Tier Thresholds | Auto-Tier Updates | Lead Triage |
| 16 | Visitor-to-Lead Promotion & Pipeline | 5 Tests | Duplicate Leads | Stage Transitions | Deal Pipeline |
| 17 | 360° Unified Contact Profile Dossier | 5 Tests | Missing links | 360° Data Stitching | Contact Audit |
| 18 | Behavioral Trigger & Proactive Rules | 5 Tests | Overlapping rules | Rule Match -> Prompt | Proactive Engagement |
| 19 | Customizable Chat Widget Studio | 5 Tests | Hex validation / XSS | Settings Persistence | Studio Config |
| 20 | Real-Time Widget Preview Frame | 5 Tests | CSS injection | Live Preview Sync | Visual Customizer |
| 21 | 1-Click Conversation-to-Ticket | 5 Tests | Truncated chats | Chat -> Ticket Bridge | Support Conversion |
| 22 | SLA Priority Matrix & Management | 5 Tests | SLA Breach bounds | Timers & Priority | High-Urgency SLA |
| 23 | Embedded Searchable Knowledge Base | 5 Tests | Search sanitization | KB Query & Category | Self-Service KB |
| 24 | Dual-Surface KB Search (Widget/Admin)| 5 Tests | Empty/partial query | In-Chat KB Insertion | Article Delivery |

**Total Test Count:** 200+ Assertions across 4 distinct test tiers.
