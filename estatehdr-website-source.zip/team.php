<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';

// Team Members Registry
$coFounders = [
    [
        'id'        => 'co-founder-1',
        'name'      => 'Usman Hashmi',
        'role'      => 'Co-Founder & Chief Executive Officer (CEO)',
        'photo'     => '/assets/images/team/co-founder-1.jpg',
        'initials'  => 'UH',
        'bio'       => 'Visionary behind Estate HDR\'s high-speed retouching infrastructure. Top Rated Master Real Estate Photo Editor with 17,000+ hours on Upwork, specializing in luxury HDR bracket fusion, flambient retouching, 3D virtual staging, and day-to-dusk conversion for top photographers and real estate agencies across the US, UK, Australia, and Europe.',
        'badges'    => ['Upwork Top Rated (17k+ Hrs)', 'HDR & Flambient Pioneer', 'Strategic Leadership'],
        'email'     => 'usman@estatehdr.com',
        'facebook'  => 'https://www.facebook.com/UsmanHashmiPOV',
        'linkedin'  => 'https://www.linkedin.com/in/usman-hashmi-editing-expert/',
        'instagram' => 'https://www.instagram.com/uzithecreator0/',
        'upwork'    => 'https://www.upwork.com/freelancers/usmans'
    ],
    [
        'id'        => 'co-founder-2',
        'name'      => 'Salman Hashmi',
        'role'      => 'Co-Founder & Head of Production Operations',
        'photo'     => '/assets/images/team/co-founder-2.jpg',
        'initials'  => 'SH',
        'bio'       => 'Master architectural retoucher and workflow engineer. Spearheads daily high-volume production queues, custom studio style calibration, multi-bracket exposure fusion algorithms, and 5-tier quality assurance standards.',
        'badges'    => ['HDR & Flambient Pioneer', 'Workflow Architecture', 'Quality Systems'],
        'email'     => 'salman@estatehdr.com',
        'facebook'  => 'https://www.facebook.com/HSalmanhashmi',
        'linkedin'  => 'https://www.linkedin.com/in/hsalmanhashmi/'
    ]
];

$management = [
    [
        'id'        => 'project-manager',
        'name'      => 'Kamran Hashmi',
        'role'      => 'Production Project Manager',
        'photo'     => '/assets/images/team/project-manager.jpg',
        'initials'  => 'KH',
        'bio'       => 'Guarantees strict 24-hour SLA delivery, client deadline enforcement, shift handovers, and rapid communication between field photographers and studio editing bays.',
        'badges'    => ['24h SLA Adherence', 'Resource Allocation', 'Shift Coordination'],
        'email'     => 'kamran@estatehdr.com',
        'facebook'  => 'https://www.facebook.com/kamrancba',
        'linkedin'  => ''
    ],
    [
        'id'        => 'supervisor',
        'name'      => 'Jamshaid Javed',
        'role'      => 'Quality & Operations Supervisor',
        'photo'     => '/assets/images/team/supervisor.jpg',
        'initials'  => 'JJ',
        'bio'       => 'Performs meticulous final pre-dispatch audits across all completed jobs. Enforces crisp window views, true-to-life white balance, and vertical perspective accuracy.',
        'badges'    => ['100% QA Inspection', 'Window Pull Fidelity', 'Color Neutrality'],
        'email'     => 'jamshaid@estatehdr.com',
        'facebook'  => '',
        'linkedin'  => 'https://www.linkedin.com/in/jamshaid-javed-0793ab2b0/'
    ]
];

$leadsAndSpecialists = [
    [
        'id'        => 'team-lead-1',
        'name'      => 'Subhan Rajpoot',
        'role'      => 'Production Team Lead (QA Hub)',
        'photo'     => '/assets/images/team/team-lead.jpg',
        'initials'  => 'SR',
        'bio'       => 'Directs day-shift editing queues, provides real-time revision feedback to retouchers, and specializes in high-dynamic-range exterior blending.',
        'badges'    => ['Batch QA Inspection', 'Flambient Blending', 'SOP Compliance'],
        'facebook'  => 'https://facebook.com',
        'linkedin'  => 'https://linkedin.com'
    ],
    [
        'id'        => 'editor-1',
        'name'      => 'Zain Malik',
        'role'      => 'Senior HDR & Flambient Specialist',
        'photo'     => '/assets/images/team/editor-1.jpg',
        'initials'  => 'ZM',
        'bio'       => 'Expert in merging 3-to-7 exposure brackets, mixed-temperature ambient neutralization, and reflection-free window pulling for luxury residential properties.',
        'badges'    => ['Multi-Bracket Fusion', 'Tungsten Removal', 'Luxury Estates'],
        'facebook'  => 'https://facebook.com',
        'linkedin'  => 'https://linkedin.com'
    ],
    [
        'id'        => 'editor-2',
        'name'      => 'Usman Chaudhry',
        'role'      => 'Virtual Staging & 3D Interior Artist',
        'photo'     => '/assets/images/team/editor-2.jpg',
        'initials'  => 'UC',
        'bio'       => 'Transforms empty rooms into photorealistic luxury spaces with designer 3D furnishings, correct shadows, realistic textures, and architectural scale fidelity.',
        'badges'    => ['Photorealistic 3D', 'Scandinavian & Modern Decor', 'Virtual Staging'],
        'facebook'  => 'https://facebook.com',
        'linkedin'  => 'https://linkedin.com'
    ],
    [
        'id'        => 'editor-3',
        'name'      => 'Farhan Qureshi',
        'role'      => 'Day to Dusk & Twilight Retoucher',
        'photo'     => '/assets/images/team/editor-3.jpg',
        'initials'  => 'FQ',
        'bio'       => 'Master of dramatic sunset conversions, warm interior window illumination, pool glowing effects, and seamless sky replacements.',
        'badges'    => ['Golden Hour Dusk', 'Window Glow Effects', 'Sky Replacement'],
        'facebook'  => 'https://facebook.com',
        'linkedin'  => 'https://linkedin.com'
    ],
    [
        'id'        => 'editor-4',
        'name'      => 'Liam Davies',
        'role'      => 'Floor Plan & 3D Tour Specialist',
        'photo'     => '/assets/images/team/editor-4.jpg',
        'initials'  => 'LD',
        'bio'       => 'Drafts clean, high-precision 2D black-and-white, color-zoned, and textured 3D architectural floor plans for property marketing brochures.',
        'badges'    => ['Architectural Drafting', '2D/3D Floor Plans', 'Laser-Accurate Schematics'],
        'facebook'  => 'https://facebook.com',
        'linkedin'  => 'https://linkedin.com'
    ]
];

$pageTitle = 'Our Team & Leadership — Estate HDR Retouching';
$pageDesc  = 'Meet the leadership, project managers, quality supervisors, and master architectural photo retouchers behind Estate HDR\'s 24-hour turnaround engine.';
$canonUrl  = rtrim(BASE_URL, '/') . '/team';
$ogImage   = BASE_URL . '/assets/images/portfolio/hdr/2-after.jpg';
$robots    = 'index, follow';
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<meta name="description" content="<?= $pageDesc ?>">
<meta name="robots" content="<?= $robots ?>">
<link rel="canonical" href="<?= $canonUrl ?>">
<!-- Open Graph -->
<meta property="og:type"        content="website">
<meta property="og:url"         content="<?= $canonUrl ?>">
<meta property="og:title"       content="<?= $pageTitle ?>">
<meta property="og:description" content="<?= $pageDesc ?>">
<meta property="og:image"       content="<?= $ogImage ?>">

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "ProfilePage",
  "name": "Estate HDR Leadership & Master Retouchers",
  "url": "https://estatehdr.com/team.php",
  "mainEntity": {
    "@type": "Person",
    "@id": "https://estatehdr.com/team.php#usman-hashmi",
    "name": "Usman Hashmi",
    "alternateName": ["Usman Siddique", "Uzi The Creator"],
    "jobTitle": "Co-Founder & Chief Executive Officer (CEO)",
    "description": "Top Rated Master Real Estate Photo Editor with 17,000+ hours on Upwork. Expert in high-end luxury real estate photo editing, bracket fusion, flambient retouching, 3D virtual staging, and day-to-dusk transformation.",
    "worksFor": {
      "@type": "Organization",
      "name": "Estate HDR",
      "url": "https://estatehdr.com"
    },
    "url": "https://estatehdr.com/team.php#usman-hashmi",
    "image": "https://estatehdr.com/assets/images/team/co-founder-1.jpg",
    "sameAs": [
      "https://www.crunchbase.com/person/usman-hashmi",
      "https://www.producthunt.com/@uzithecreator",
      "https://www.behance.net/usmanhashmi1",
      "https://medium.com/@usman.hashmi905",
      "https://about.me/usman.hashmi",
      "https://gravatar.com/usmanhashmi905",
      "https://taplink.cc/uzithecreator",
      "https://linktr.ee/usman.hashmi905",
      "https://www.flickr.com/people/205022697@N02/",
      "https://github.com/usmanhashmi2024",
      "https://www.upwork.com/freelancers/usmans",
      "https://www.linkedin.com/in/usman-hashmi-editing-expert/",
      "https://www.facebook.com/UsmanHashmiPOV",
      "https://www.instagram.com/uzithecreator0/"
    ],
    "knowsAbout": [
      "Real Estate Photo Editing",
      "HDR Photo Editing",
      "Flambient Real Estate Photography",
      "Virtual Staging",
      "Day to Dusk Twilight Conversion",
      "Window Pull Recovery",
      "Photoshop",
      "Lightroom"
    ]
  }
}
</script>

<!-- Google Fonts & Tailwind -->
<?= renderSeoHeadTags() ?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap" onload="this.onload=null;this.rel='stylesheet'">
<noscript>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap">
</noscript>
<link rel="stylesheet" href="/assets/css/bundle.css?v=<?= file_exists(ROOT_PATH . '/assets/css/bundle.css') ? filemtime(ROOT_PATH . '/assets/css/bundle.css') : time() ?>">
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col pt-24">

<?php require_once __DIR__ . '/includes/public-header.php'; ?>

<!-- ── HERO HEADER ────────────────────────────────────────────────── -->
<section class="relative py-16 sm:py-24 border-b border-dark-border overflow-hidden bg-gradient-to-b from-[#111118]/80 via-dark to-dark">
  <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-gold/10 via-transparent to-transparent pointer-events-none"></div>
  
  <div class="max-w-7xl mx-auto px-6 sm:px-10 relative z-10 text-center space-y-6">
    <div class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-gold/10 border border-gold/30 text-gold text-xs font-black uppercase tracking-widest">
      <span>✦</span> <span>THE PEOPLE BEHIND THE PIXELS</span> <span>✦</span>
    </div>

    <h1 class="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight max-w-4xl mx-auto leading-tight">
      MEET OUR <span class="text-gradient">MASTER RETOUCHERS</span> &amp; LEADERSHIP
    </h1>

    <p class="text-gray-300 text-sm sm:text-base lg:text-lg max-w-3xl mx-auto font-medium leading-relaxed">
      A dedicated team of architectural photo editors, 3D staging artists, and production managers committed to turning your raw bracket photos into breathtaking luxury real estate listings within 24 hours.
    </p>

    <!-- Stat Highlights Row -->
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-4xl mx-auto pt-6">
      <div class="glass-card rounded-2xl p-4 border border-dark-border">
        <div class="text-2xl sm:text-3xl font-black text-gold font-mono">15+</div>
        <div class="text-xs text-gray-300 font-bold uppercase mt-1">Master Retouchers</div>
      </div>
      <div class="glass-card rounded-2xl p-4 border border-dark-border">
        <div class="text-2xl sm:text-3xl font-black text-emerald-400 font-mono">24h</div>
        <div class="text-xs text-gray-300 font-bold uppercase mt-1">Guaranteed SLA</div>
      </div>
      <div class="glass-card rounded-2xl p-4 border border-dark-border">
        <div class="text-2xl sm:text-3xl font-black text-blue-400 font-mono">100%</div>
        <div class="text-xs text-gray-300 font-bold uppercase mt-1">Multi-Tier QA Audits</div>
      </div>
      <div class="glass-card rounded-2xl p-4 border border-dark-border">
        <div class="text-2xl sm:text-3xl font-black text-purple-400 font-mono">500k+</div>
        <div class="text-xs text-gray-300 font-bold uppercase mt-1">Photos Retouched</div>
      </div>
    </div>
  </div>
</section>

<!-- ── MAIN CONTENT ───────────────────────────────────────────────── -->
<main class="max-w-7xl mx-auto px-6 sm:px-10 py-16 space-y-20 flex-1">

  <!-- ── 1. EXECUTIVE LEADERSHIP / CO-FOUNDERS ──────────────────────── -->
  <section class="space-y-8">
    <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-dark-border pb-4">
      <div>
        <div class="text-xs font-black text-gold uppercase tracking-wider mb-1">Executive Leadership</div>
        <h2 class="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight">Co-Founders &amp; Visionaries</h2>
      </div>
      <p class="text-xs text-gray-400 max-w-md font-medium">Guiding the architectural vision, global studio standards, and 24-hour turnaround infrastructure.</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
      <?php foreach ($coFounders as $cf): ?>
      <div class="team-card glass-card rounded-3xl p-8 border border-gold/40 bg-gold/5 shadow-2xl relative overflow-hidden flex flex-col sm:flex-row items-center sm:items-start gap-6">
        
        <!-- Profile Picture / Avatar -->
        <div class="relative flex-shrink-0">
          <img loading="lazy" decoding="async" src="<?= htmlspecialchars($cf['photo']) ?>" 
               alt="<?= htmlspecialchars($cf['name']) ?>" 
               class="w-32 h-32 sm:w-36 sm:h-36 rounded-2xl object-cover border-2 border-gold avatar-glow bg-dark-card"
               onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
          <!-- Fallback Initial Avatar -->
          <div class="hidden w-32 h-32 sm:w-36 sm:h-36 rounded-2xl bg-[#181826] border-2 border-gold items-center justify-center font-black text-4xl text-gold font-mono shadow-glow">
            <?= htmlspecialchars($cf['initials']) ?>
          </div>
          <span class="absolute -bottom-2 -right-2 px-2.5 py-0.5 rounded-full bg-gold text-dark font-black text-[10px] uppercase shadow-md">
            Co-Founder
          </span>
        </div>

        <!-- Details -->
        <div class="space-y-3.5 flex-1 text-center sm:text-left">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 class="text-2xl font-black text-white"><?= htmlspecialchars($cf['name']) ?></h3>
              <div class="text-sm font-bold text-gold mt-0.5"><?= htmlspecialchars($cf['role']) ?></div>
            </div>

            <!-- Social Links (Upwork, Facebook & LinkedIn) -->
            <div class="flex items-center justify-center sm:justify-end gap-2 pt-1 sm:pt-0">
              <?php if (!empty($cf['upwork'])): ?>
              <a href="<?= htmlspecialchars($cf['upwork']) ?>" target="_blank" rel="noopener noreferrer" 
                 class="w-8 h-8 rounded-xl bg-emerald-600/20 hover:bg-emerald-600 text-emerald-400 hover:text-white border border-emerald-500/30 flex items-center justify-center transition-all duration-200" 
                 title="Upwork Top Rated Profile (17,000+ Hours)">
                <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M18.561 13.158c-1.102 0-2.135-.467-3.074-1.227l.228-1.076.008-.042c.207-1.143.849-3.06 2.839-3.06 1.492 0 2.703 1.212 2.703 2.703-.001 1.489-1.212 2.702-2.704 2.702zm0-8.14c-2.539 0-4.51 1.649-5.31 4.366-1.22-1.834-2.148-4.036-2.687-5.892H7.828v7.112c0 1.506-1.22 2.727-2.727 2.727-1.505 0-2.726-1.221-2.726-2.727V3.492H0v7.112c0 2.809 2.28 5.09 5.101 5.09 2.822 0 5.102-2.281 5.102-5.09v-1.12c.484 1.458 1.24 3.037 2.24 4.412l-1.922 8.948h2.828l1.393-6.488c1.139.756 2.457 1.216 3.819 1.216 3.14 0 5.698-2.558 5.698-5.698 0-3.14-2.558-5.698-5.697-5.698z"/></svg>
              </a>
              <?php endif; ?>

              <?php if (!empty($cf['facebook'])): ?>
              <a href="<?= htmlspecialchars($cf['facebook']) ?>" target="_blank" rel="noopener noreferrer" 
                 class="w-8 h-8 rounded-xl bg-blue-600/20 hover:bg-blue-600 text-blue-400 hover:text-white border border-blue-500/30 flex items-center justify-center transition-all duration-200" 
                 title="Facebook Profile">
                <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
              </a>
              <?php endif; ?>

              <?php if (!empty($cf['linkedin'])): ?>
              <a href="<?= htmlspecialchars($cf['linkedin']) ?>" target="_blank" rel="noopener noreferrer" 
                 class="w-8 h-8 rounded-xl bg-sky-600/20 hover:bg-sky-600 text-sky-400 hover:text-white border border-sky-500/30 flex items-center justify-center transition-all duration-200" 
                 title="LinkedIn Profile">
                <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
              </a>
              <?php endif; ?>
            </div>
          </div>

          <p class="text-sm text-gray-300 leading-relaxed font-normal">
            <?= htmlspecialchars($cf['bio']) ?>
          </p>

          <!-- Badges -->
          <div class="flex flex-wrap items-center justify-center sm:justify-start gap-1.5 pt-1">
            <?php foreach ($cf['badges'] as $b): ?>
            <span class="px-2.5 py-1 rounded-lg bg-gold/15 text-gold border border-gold/30 text-xs font-black">
              <?= htmlspecialchars($b) ?>
            </span>
            <?php endforeach; ?>
          </div>
        </div>

      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- ── 2. PROJECT MANAGEMENT & QUALITY SUPERVISION ────────────────── -->
  <section class="space-y-8">
    <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-dark-border pb-4">
      <div>
        <div class="text-xs font-black text-purple-400 uppercase tracking-wider mb-1">Operations &amp; Governance</div>
        <h2 class="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight">Project Management &amp; Quality Supervision</h2>
      </div>
      <p class="text-xs text-gray-400 max-w-md font-medium">Orchestrating daily production throughput, photographer SLA compliance, and zero-defect quality control.</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
      <?php foreach ($management as $m): ?>
      <div class="team-card glass-card rounded-3xl p-7 border border-dark-border bg-dark/95 shadow-xl flex flex-col sm:flex-row items-center sm:items-start gap-6">
        
        <!-- Profile Picture / Avatar -->
        <div class="relative flex-shrink-0">
          <img loading="lazy" decoding="async" src="<?= htmlspecialchars($m['photo']) ?>" 
               alt="<?= htmlspecialchars($m['name']) ?>" 
               class="w-28 h-28 sm:w-32 sm:h-32 rounded-2xl object-cover border border-purple-500/40 bg-dark-card shadow-lg"
               onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
          <!-- Fallback Initial Avatar -->
          <div class="hidden w-28 h-28 sm:w-32 sm:h-32 rounded-2xl bg-[#141424] border border-purple-500/50 items-center justify-center font-black text-3xl text-purple-300 font-mono">
            <?= htmlspecialchars($m['initials']) ?>
          </div>
        </div>

        <!-- Details -->
        <div class="space-y-3 flex-1 text-center sm:text-left">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 class="text-xl font-black text-white"><?= htmlspecialchars($m['name']) ?></h3>
              <div class="text-xs font-bold text-purple-300 uppercase tracking-wider mt-0.5"><?= htmlspecialchars($m['role']) ?></div>
            </div>

            <!-- Social Links (Facebook & LinkedIn) -->
            <div class="flex items-center justify-center sm:justify-end gap-2 pt-1 sm:pt-0">
              <?php if (!empty($m['facebook'])): ?>
              <a href="<?= htmlspecialchars($m['facebook']) ?>" target="_blank" rel="noopener noreferrer" 
                 class="w-7 h-7 rounded-lg bg-blue-600/20 hover:bg-blue-600 text-blue-400 hover:text-white border border-blue-500/30 flex items-center justify-center transition-all duration-200" 
                 title="Facebook Profile">
                <svg class="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
              </a>
              <?php endif; ?>

              <?php if (!empty($m['linkedin'])): ?>
              <a href="<?= htmlspecialchars($m['linkedin']) ?>" target="_blank" rel="noopener noreferrer" 
                 class="w-7 h-7 rounded-lg bg-sky-600/20 hover:bg-sky-600 text-sky-400 hover:text-white border border-sky-500/30 flex items-center justify-center transition-all duration-200" 
                 title="LinkedIn Profile">
                <svg class="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
              </a>
              <?php endif; ?>
            </div>
          </div>

          <p class="text-sm text-gray-300 leading-relaxed font-normal">
            <?= htmlspecialchars($m['bio']) ?>
          </p>

          <!-- Badges -->
          <div class="flex flex-wrap items-center justify-center sm:justify-start gap-1.5 pt-1">
            <?php foreach ($m['badges'] as $b): ?>
            <span class="px-2.5 py-1 rounded-lg bg-purple-500/15 text-purple-300 border border-purple-500/30 text-xs font-bold font-mono">
              <?= htmlspecialchars($b) ?>
            </span>
            <?php endforeach; ?>
          </div>
        </div>

      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- ── 3. MASTER RETOUCHERS & 3D ARTISTS ──────────────────────────── -->
  <section class="space-y-8">
    <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-dark-border pb-4">
      <div>
        <div class="text-xs font-black text-emerald-400 uppercase tracking-wider mb-1">Production Execution Bay</div>
        <h2 class="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight">Master Photo Editors &amp; 3D Staging Specialists</h2>
      </div>
      <p class="text-xs text-gray-400 max-w-md font-medium">Certified architectural specialists dedicated to manual window pulling, flambient exposure blending, and virtual staging.</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <?php foreach ($leadsAndSpecialists as $ls): ?>
      <div class="team-card glass-card rounded-3xl p-6 border border-dark-border bg-dark/95 shadow-xl flex flex-col justify-between space-y-4">
        
        <div class="flex items-center justify-between gap-4">
          <div class="flex items-center gap-4">
            <div class="relative flex-shrink-0">
              <img loading="lazy" decoding="async" src="<?= htmlspecialchars($ls['photo']) ?>" 
                   alt="<?= htmlspecialchars($ls['name']) ?>" 
                   class="w-16 h-16 rounded-2xl object-cover border border-emerald-500/40 bg-dark-card shadow-md"
                   onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
              <!-- Fallback Initial Avatar -->
              <div class="hidden w-16 h-16 rounded-2xl bg-[#121820] border border-emerald-500/40 items-center justify-center font-black text-xl text-emerald-400 font-mono">
                <?= htmlspecialchars($ls['initials']) ?>
              </div>
            </div>
            <div>
              <h3 class="text-lg font-black text-white"><?= htmlspecialchars($ls['name']) ?></h3>
              <div class="text-xs font-bold text-emerald-400"><?= htmlspecialchars($ls['role']) ?></div>
            </div>
          </div>

          <!-- Social Links (Facebook & LinkedIn) -->
          <div class="flex items-center gap-1.5 flex-shrink-0">
            <?php if (!empty($ls['facebook'])): ?>
            <a href="<?= htmlspecialchars($ls['facebook']) ?>" target="_blank" rel="noopener noreferrer" 
               class="w-7 h-7 rounded-lg bg-blue-600/20 hover:bg-blue-600 text-blue-400 hover:text-white border border-blue-500/30 flex items-center justify-center transition-all duration-200" 
               title="Facebook Profile">
              <svg class="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
            </a>
            <?php endif; ?>

            <?php if (!empty($ls['linkedin'])): ?>
            <a href="<?= htmlspecialchars($ls['linkedin']) ?>" target="_blank" rel="noopener noreferrer" 
               class="w-7 h-7 rounded-lg bg-sky-600/20 hover:bg-sky-600 text-sky-400 hover:text-white border border-sky-500/30 flex items-center justify-center transition-all duration-200" 
               title="LinkedIn Profile">
              <svg class="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
            </a>
            <?php endif; ?>
          </div>
        </div>

        <p class="text-xs text-gray-300 leading-relaxed font-normal">
          <?= htmlspecialchars($ls['bio']) ?>
        </p>

        <!-- Badges -->
        <div class="flex flex-wrap gap-1.5 pt-2 border-t border-dark-border">
          <?php foreach ($ls['badges'] as $b): ?>
          <span class="px-2 py-0.5 rounded-md bg-white/5 text-gray-300 border border-white/10 text-[11px] font-mono">
            <?= htmlspecialchars($b) ?>
          </span>
          <?php endforeach; ?>
        </div>

      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- ── 4. HOW OUR TEAM WORKS FOR YOU (4 PILLARS) ──────────────────── -->
  <section class="glass-card rounded-3xl p-8 sm:p-12 border border-gold/30 bg-gradient-to-r from-dark-card via-[#161622] to-dark-card shadow-2xl space-y-8">
    <div class="text-center max-w-3xl mx-auto space-y-3">
      <div class="text-xs font-black text-gold uppercase tracking-widest">Why Photographers Choose Estate HDR</div>
      <h2 class="text-2xl sm:text-4xl font-black text-white tracking-tight">THE ESTATE HDR PRODUCTION ADVANTAGE</h2>
      <p class="text-gray-300 text-sm font-medium">Every photo batch submitted to Estate HDR is handled by senior specialists with multi-tier quality checks.</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 pt-4">
      <div class="p-6 rounded-2xl bg-dark/80 border border-dark-border space-y-3">
        <div class="w-12 h-12 rounded-xl bg-gold/10 border border-gold/30 text-gold flex items-center justify-center text-xl font-bold">
          ⚡
        </div>
        <h3 class="text-base font-bold text-white">24-Hour Guaranteed Delivery</h3>
        <p class="text-xs text-gray-400 leading-relaxed">
          Upload evening brackets, receive MLS-ready high-res photos next morning. 12-hour rush available.
        </p>
      </div>

      <div class="p-6 rounded-2xl bg-dark/80 border border-dark-border space-y-3">
        <div class="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center text-xl font-bold">
          🎯
        </div>
        <h3 class="text-base font-bold text-white">100% Manual Masking</h3>
        <p class="text-xs text-gray-400 leading-relaxed">
          Zero automated software halos. Hand-crafted window pulls, pure drywall white balance, and natural warm wood tones.
        </p>
      </div>

      <div class="p-6 rounded-2xl bg-dark/80 border border-dark-border space-y-3">
        <div class="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-400 flex items-center justify-center text-xl font-bold">
          🔄
        </div>
        <h3 class="text-base font-bold text-white">Unlimited Free Revisions</h3>
        <p class="text-xs text-gray-400 leading-relaxed">
          Need a small adjustment? Our supervisor bay delivers free revisions in 2 to 4 hours.
        </p>
      </div>

      <div class="p-6 rounded-2xl bg-dark/80 border border-dark-border space-y-3">
        <div class="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-400 flex items-center justify-center text-xl font-bold">
          🤝
        </div>
        <h3 class="text-base font-bold text-white">Dedicated Bay Assignment</h3>
        <p class="text-xs text-gray-400 leading-relaxed">
          High-volume studios receive dedicated retoucher bay pairing to match your unique brand look and feel.
        </p>
      </div>
    </div>
  </section>

  <!-- ── 5. CALL TO ACTION / WORK WITH US ───────────────────────────── -->
  <section class="text-center py-12 space-y-6">
    <h2 class="text-2xl sm:text-4xl font-black text-white uppercase tracking-tight">
      READY TO WORK WITH OUR <span class="text-gradient">MASTER RETOUCHERS?</span>
    </h2>
    <p class="text-gray-300 text-sm sm:text-base max-w-2xl mx-auto font-medium">
      Send us your first 3 raw photo brackets today — edited completely free with zero payment required.
    </p>
    <div class="flex flex-wrap items-center justify-center gap-4 pt-2">
      <a href="/contact" class="btn-primary text-sm font-black px-8 py-4 rounded-xl shadow-glow">
        Claim 3 Free Sample Edits &rarr;
      </a>
      <a href="/pricing" class="px-8 py-4 rounded-xl bg-dark-card border border-dark-border hover:border-gold text-white font-bold text-sm transition-all">
        View Pricing &amp; Plans
      </a>
    </div>
  </section>

</main>

<?php require_once __DIR__ . '/includes/public-footer.php'; ?>

</body>
</html>
