<?php
/**
 * Estate HDR — Official Blog RSS 2.0 Feed Generator
 */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';

header('Content-Type: application/rss+xml; charset=utf-8');
header('Cache-Control: public, max-age=3600');

$blogs = getPublishedBlogs();
usort($blogs, function($a, $b) {
    return strtotime($b['created_at'] ?? 'now') - strtotime($a['created_at'] ?? 'now');
});

$latestBuild = !empty($blogs[0]['created_at']) ? date(DATE_RSS, strtotime($blogs[0]['created_at'])) : date(DATE_RSS);

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom" xmlns:dc="http://purl.org/dc/elements/1.1/">
  <channel>
    <title>Estate HDR — Real Estate Photo Editing &amp; Retouching Guides</title>
    <link><?= BASE_URL ?>/blog.php</link>
    <description>Expert architectural post-production guides, HDR bracket blending tutorials, virtual staging benchmarks, and daylight-to-dusk conversion case studies.</description>
    <language>en-US</language>
    <lastBuildDate><?= $latestBuild ?></lastBuildDate>
    <atom:link href="<?= BASE_URL ?>/rss.xml" rel="self" type="application/rss+xml" />
    <image>
      <url><?= BASE_URL ?>/assets/images/logo.png</url>
      <title>Estate HDR</title>
      <link><?= BASE_URL ?></link>
    </image>

    <?php foreach (array_slice($blogs, 0, 30) as $b): 
      $itemUrl = BASE_URL . '/blog/' . htmlspecialchars($b['slug'] ?? '');
      $pubDate = !empty($b['created_at']) ? date(DATE_RSS, strtotime($b['created_at'])) : date(DATE_RSS);
      $excerpt = !empty($b['excerpt']) ? $b['excerpt'] : (!empty($b['meta_description']) ? $b['meta_description'] : mb_substr(strip_tags($b['content'] ?? ''), 0, 200));
    ?>
    <item>
      <title><![CDATA[<?= htmlspecialchars_decode($b['title'] ?? '', ENT_QUOTES) ?>]]></title>
      <link><?= $itemUrl ?></link>
      <guid isPermaLink="true"><?= $itemUrl ?></guid>
      <pubDate><?= $pubDate ?></pubDate>
      <dc:creator><![CDATA[<?= htmlspecialchars_decode($b['author'] ?? 'Estate HDR Editorial Team', ENT_QUOTES) ?>]]></dc:creator>
      <category><![CDATA[<?= htmlspecialchars_decode($b['category'] ?? 'Real Estate Photo Editing', ENT_QUOTES) ?>]]></category>
      <description><![CDATA[<?= htmlspecialchars_decode($excerpt, ENT_QUOTES) ?>]]></description>
    </item>
    <?php endforeach; ?>
  </channel>
</rss>
