# Product Requirements Document (PRD)
# Estate HDR — Client Mobile Application

**App Name:** Estate HDR Client App  
**Document Version:** 1.0.0  
**Status:** Approved for Design & Engineering  
**Target Platforms:** iOS (Apple App Store) & Android (Google Play Store)  
**Author:** Estate HDR Product Management Group  
**Target Audience:** Real Estate Photographers, Realtors, Luxury Brokers & Media Agencies  

---

## 1. Executive Summary & Product Vision

The **Estate HDR Client App** is a luxury mobile concierge designed for real estate photographers, commercial brokers, and marketing agencies. It transforms how clients place retouching orders, review architectural proofs, request precision amendments, and download MLS-ready deliverables on-the-go.

### Key Value Propositions
- **<60-Second Order Placement:** Paste cloud links (Google Drive, Dropbox, WeTransfer, iCloud) directly between photo shoots without opening a laptop.
- **Touch-Interactive Proofing:** Review completed HDR photos with an ultra-smooth 120Hz Before/After comparison slider and synchronized 400% zoom.
- **Pin-Point Visual Amendments:** Tap directly on any photo, drop a pin, record a voice memo, and request unlimited free revisions with zero ambiguity.
- **1-Tap Camera Roll & MLS Delivery:** Instant download of 2048px MLS WebP images and 300 DPI full-resolution print assets directly to mobile storage.
- **24/7 Concierge Chat & WhatsApp:** Direct instant messaging with retouching directors and live customer support.

---

## 2. User Personas

| Attribute | Persona 1: Solo Pro Photographer | Persona 2: Luxury Real Estate Broker | Persona 3: Media Production Agency |
| :--- | :--- | :--- | :--- |
| **Typical User** | Shoots 3–5 properties per day; drives between shoots. | Top-producing agent listing multimillion-dollar estates. | Multi-photographer team processing 100+ properties/month. |
| **Primary Need** | Rapid bracketed RAW offloading and fast 24h/12h turnaround. | Quick virtual staging and twilight transformations for MLS. | Volume discounts, centralized order tracking, and invoice exports. |
| **Mobile Use Case** | Places orders from the car via Dropbox links; reviews proofs on phone. | Approves staging iterations while on-site with homeowners. | Monitors team spending, downloads high-res batches to agency drives. |

---

## 3. Information Architecture & Navigation

```
Client Mobile App (Bottom Tab Navigation)
├── 1. Dashboard (Home)
│   ├── User Greeting & Studio Profile
│   ├── Quick Stat Cards (Active Jobs, In Review, Completed, Wallet Balance)
│   ├── "New Order" Action FAB (Floating Action Button)
│   ├── Live SLA Progress Tracker for Active Orders
│   ├── Recent Deliverables Carousel (Tap to open B/A slider)
│   └── 1-Tap Free Trial Banner (for unverified accounts)
├── 2. Orders Hub
│   ├── Status Filter Tabs: All (0) | In Progress | In Review | Completed | Amendments
│   ├── Search & Filter Bar (Address, Date, Service Type)
│   └── Order Detail Screen:
│       ├── Status Progression Stepper (Submitted ➔ Editing ➔ QC Passed ➔ Ready)
│       ├── Live Turnaround SLA Countdown
│       ├── Deliverables Grid with Before/After Slider View
│       ├── Visual Pin Amendment Tool
│       ├── Download Hub (Web MLS, Print 300 DPI, Complete ZIP)
│       └── Dedicated Order Chat Channel
├── 3. Create Order Flow (6-Step Express Wizard)
│   ├── Step 1: Property Address & Order Name
│   ├── Step 2: Service Configurator (HDR, Staging, Twilight, Floor Plans, Declutter)
│   ├── Step 3: Style Presets (Natural, Bright & Airy, Luxury Warm, Scandinavian)
│   ├── Step 4: Asset Upload (Cloud URL or Mobile File Picker)
│   ├── Step 5: Turnaround Speed (Standard 24h, Express 12h, Rush 6h)
│   └── Step 6: Instant Checkout (Apple Pay, Google Pay, Card, Wallet)
├── 4. Concierge & Live Chat
│   ├── Active Order Chat Channels
│   ├── General Support & Retouching Director Desk
│   ├── 1-Tap WhatsApp Direct Bridge
│   └── Self-Service Knowledge Base & FAQs
└── 5. Account & Billing
    ├── Studio Profile & Brand Watermark Settings
    ├── Default Editing Style Presets
    ├── In-App Wallet & Auto-Recharge Settings
    ├── Invoices & VAT Receipts (PDF Download)
    ├── Biometric Login (Face ID / Fingerprint)
    └── Push Notification Preferences
```

---

## 4. Detailed Feature Specifications

### Epic 1: Onboarding, Biometrics & Profile
- **Registration & Social Auth:** Sign up via Email, Apple Sign-In, or Google Sign-In.
- **Biometric Authentication:** Face ID / Touch ID / Android Biometric unlock for instant access.
- **Studio Profile:** Save photographer business name, contact number, and default copyright watermark.
- **Default Style Preferences:** Pre-select preferred sky replacement styles, grass greening levels, and interior warmth presets applied automatically to all new orders.

### Epic 2: 60-Second Order Placement Wizard
- **Cloud Link Integration:** Direct paste support for Google Drive, Dropbox, WeTransfer, OneDrive, Box, or iCloud shared folders.
- **Service Selection Matrix:**
  - *HDR Photo Editing:* 3/5/7 Bracket Blending, Window Masking, Sky Replacement, Lawn Greening ($0.80 - $1.50/photo).
  - *Virtual Staging:* 3D Furniture Placement (Living Room, Bedroom, Dining, Patio, Modern/Scandinavian/Luxury styles) ($15.00/photo).
  - *Virtual Twilight / Day to Dusk:* Golden hour conversion, interior light glow, sky replacement ($4.00/photo).
  - *Item Removal / Decluttering:* Removing cars, bins, cords, clutter ($3.00/photo).
  - *2D/3D Floor Plans:* Dimensioned architectural schematics ($12.00 - $25.00/floor).
- **Turnaround Tier Selection:** Standard (24 Hours), Express (12 Hours), Rush (6 Hours).
- **Instant Payment:** Pay using in-app Wallet Balance, Apple Pay, Google Pay, or saved credit card.

### Epic 3: Touch-Interactive Before/After Proofing Viewer
- **Interactive Split Slider:** Horizontal GPU-accelerated drag handle comparing original RAW and final HDR deliverable.
- **Synchronized Pinch-to-Zoom:** Zoom in up to 400% on fine architectural details; both Before and After images pan and zoom in perfect sync.
- **Comparison Modes:** Toggle between Split Slider, Side-by-Side Dual View, and Tap-and-Hold Quick Compare.
- **Metadata Inspection:** View applied sky replacement ID, exposure count, and QC approval timestamp.

### Epic 4: Pin-Point Visual Amendment Tool
- **Drop-a-Pin Coordinate Marking:** Tap anywhere on the image deliverable to place a red numbered pin (records exact normalized `x, y` coordinates).
- **Multi-Modal Notes:**
  - Text description of requested change.
  - 60-second voice memo audio recording.
  - Quick action chips ("Brighten Window", "Fix Sky Color", "Remove Glare", "Greener Grass", "Straighten Lines").
- **Free Unlimited Revisions:** $0 charge guarantee on all amendment requests.
- **Amendment Status Tracking:** Real-time updates (`Pending` ➔ `In Revision` ➔ `Re-Delivered`).

### Epic 5: High-Res Export & MLS Direct Sharing
- **Multi-Format Downloads:**
  - *Web MLS Optimized:* 2048px width, 72 DPI WebP/JPEG (<2MB) formatted for MLS and real estate portals (Zillow, Realtor.com, Rightmove).
  - *Full Print Master:* Original resolution, 300 DPI uncompressed JPEG/TIFF for print brochures.
- **1-Tap Camera Roll Export:** Downloads photos directly to the mobile device gallery into a dedicated album named after the property address.
- **Native OS Share Sheet:** Share directly to Instagram, WhatsApp, AirDrop, or cloud storage.

### Epic 6: In-App Wallet, Invoices & Credits
- **Tiered Deposit Bonuses:** Top-up wallet and receive automatic bonus credits (e.g. Deposit $500 ➔ Get $550).
- **Auto-Recharge:** Automatically reload wallet when balance drops below a user-selected threshold.
- **PDF Invoice Generation:** Download itemized VAT receipts and commercial invoices directly within the app.

### Epic 7: 24/7 Concierge Chat & Notifications
- **Real-Time Order Chat:** Dedicated messaging thread per order to communicate directly with the retouching team.
- **Voice Memos & Photo Attachments:** Send voice notes and reference photos within chat.
- **Push Notification Matrix:** Alerts for `ORDER_STARTED`, `DELIVERABLES_READY`, `AMENDMENT_RESOLVED`, and `WALLET_LOW`.

---

## 5. Non-Functional Requirements & KPIs

- **Performance:** App launch cold start < 1.5s; Before/After slider renders at continuous 60 FPS (120 FPS on ProMotion screens).
- **Offline Caching:** View existing orders, cached thumbnails, and invoices even without internet connectivity.
- **Security:** TLS 1.3 encryption, biometric keychain storage, and time-limited pre-signed S3 download URLs.
- **Success Metrics:** >50% mobile order adoption rate; average review-to-approval turnaround under 45 minutes; CSAT > 4.8/5.0.
