<?php
/**
 * Estate HDR — Blog Articles XML Sitemap
 */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';

header('Content-Type: application/xml; charset=utf-8');
header('Cache-Control: public, max-age=3600');

$blogs = getPublishedBlogs();
$now = date('Y-m-d\TH:i:s+00:00');

echo '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
<?php foreach ($blogs as $b): 
    $slug = $b['slug'] ?? '';
    if (empty($slug)) continue;
    if (!empty($b['exclude_sitemap'])) continue;
    if (str_contains(strtolower($b['robots'] ?? ''), 'noindex')) continue;
    $url = rtrim(BASE_URL, '/') . '/blog/' . urlencode($slug);
    $mod = !empty($b['updated_at']) ? date('Y-m-d\TH:i:s+00:00', strtotime($b['updated_at'])) : $now;
    $title = htmlspecialchars($b['title'] ?? '', ENT_QUOTES, 'UTF-8');
    $img = $b['featured_image'] ?? '';
    $imgUrl = !empty($img) ? (str_starts_with($img, 'http') ? $img : rtrim(BASE_URL, '/') . '/' . ltrim($img, '/')) : '';
?>
    <url>
        <loc><?= $url ?></loc>
        <lastmod><?= $mod ?></lastmod>
        <changefreq>monthly</changefreq>
        <priority>0.80</priority>
        <?php if (!empty($imgUrl)): ?>
        <image:image>
            <image:loc><?= $imgUrl ?></image:loc>
            <image:title><?= $title ?></image:title>
        </image:image>
        <?php endif; ?>
    </url>
<?php endforeach; ?>
</urlset>
