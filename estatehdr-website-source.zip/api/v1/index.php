<?php
/**
 * Estate HDR - Real Estate Media REST API v1
 * Enterprise Layer: Real Estate Media API Platform & Idempotency
 * 
 * Routes:
 * POST /api/v1/orders          (Scope: orders:create, Supports Idempotency-Key)
 * GET  /api/v1/orders/{id}     (Scope: orders:read)
 * POST /api/v1/assets          (Scope: assets:upload)
 * POST /api/v1/amendments      (Scope: amendments:create)
 * GET  /api/v1/deliveries      (Scope: orders:read)
 */

header('Content-Type: application/json; charset=UTF-8');

require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/services/ApiKeyService.php';
require_once __DIR__ . '/../../includes/services/TenantService.php';
require_once __DIR__ . '/../../includes/services/PropertyService.php';
require_once __DIR__ . '/../../includes/services/AssetService.php';
require_once __DIR__ . '/../../includes/services/AmendmentService.php';
require_once __DIR__ . '/../../includes/services/WebhookService.php';

// Extract Authorization Header
$headers = getallheaders();
$authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';
$token = '';
if (preg_match('/Bearer\s+(\S+)/i', $authHeader, $matches)) {
    $token = $matches[1];
}

if (empty($token)) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Missing Bearer API token.']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$pathInfo = $_SERVER['PATH_INFO'] ?? ($_GET['endpoint'] ?? '/');
$pathParts = explode('/', trim($pathInfo, '/'));
$resource = $pathParts[0] ?? '';
$resourceId = $pathParts[1] ?? ($_GET['id'] ?? null);

// ── ROUTE 1: POST /orders (Create Order with Idempotency) ────────────────────
if ($resource === 'orders' && $method === 'POST') {
    $auth = ApiKeyService::authenticate($token, 'orders:create');
    if (!$auth['authenticated']) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => $auth['error']]);
        exit;
    }

    // Check Idempotency-Key
    $idempotencyKey = $headers['Idempotency-Key'] ?? $headers['idempotency-key'] ?? null;
    if ($idempotencyKey) {
        $cached = ApiKeyService::getIdempotentResponse($idempotencyKey);
        if ($cached) {
            http_response_code(200);
            header('X-Cache-Lookup: IDEMPOTENT_HIT');
            echo json_encode($cached['response']);
            exit;
        }
    }

    $rawInput = file_get_contents('php://input');
    $data = json_decode($rawInput, true);
    if (!is_array($data) || empty($data['property_address'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid order payload. Property address is required.']);
        exit;
    }

    $keyData = $auth['key_data'];
    $clientId = $keyData['client_id'];
    $orgId = $keyData['organization_id'] ?? TenantService::DEFAULT_ORG_ID;

    // Link or create Property entity
    $prop = PropertyService::findOrCreateProperty($data['property_address'], $clientId, $orgId, [
        'mls_id' => $data['mls_id'] ?? '',
        'bedrooms' => $data['bedrooms'] ?? 0,
        'bathrooms' => $data['bathrooms'] ?? 0,
        'sqft' => $data['sqft'] ?? 0
    ]);

    // Create Order Record
    $orderId = 'ORD-' . strtoupper(substr(md5(uniqid('', true)), 0, 8));
    $newOrder = [
        'id' => $orderId,
        'organization_id' => $orgId,
        'workspace_id' => TenantService::DEFAULT_WORKSPACE_ID,
        'client_id' => $clientId,
        'client_name' => $keyData['client_name'] ?? 'API Client',
        'property_id' => $prop['id'],
        'property_address' => $data['property_address'],
        'service' => $data['service'] ?? 'hdr_standard',
        'photo_count' => (int)($data['photo_count'] ?? 15),
        'status' => 'pending',
        'source' => 'rest_api_v1',
        'created_at' => date('Y-m-d H:i:s')
    ];

    if (function_exists('saveOrder')) {
        saveOrder($newOrder);
    }
    PropertyService::linkOrderToProperty($prop['id'], $orderId);

    // Dispatch webhook event
    WebhookService::dispatch('order.created', $newOrder, $orgId);

    $response = [
        'success' => true,
        'order_id' => $orderId,
        'property_id' => $prop['id'],
        'status' => 'pending',
        'sla_target_hours' => 24,
        'created_at' => $newOrder['created_at']
    ];

    if ($idempotencyKey) {
        ApiKeyService::saveIdempotentResponse($idempotencyKey, $response);
    }

    http_response_code(201);
    echo json_encode($response);
    exit;
}

// ── ROUTE 2: GET /orders/{id} ────────────────────────────────────────────────
if ($resource === 'orders' && $method === 'GET') {
    $auth = ApiKeyService::authenticate($token, 'orders:read');
    if (!$auth['authenticated']) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => $auth['error']]);
        exit;
    }

    if (empty($resourceId)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Order ID is required.']);
        exit;
    }

    $order = getOrderById($resourceId);
    if (!$order) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Order not found.']);
        exit;
    }

    echo json_encode(['success' => true, 'order' => $order]);
    exit;
}

// ── ROUTE 3: POST /assets ───────────────────────────────────────────────────
if ($resource === 'assets' && $method === 'POST') {
    $auth = ApiKeyService::authenticate($token, 'assets:upload');
    if (!$auth['authenticated']) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => $auth['error']]);
        exit;
    }

    $data = json_decode(file_get_contents('php://input'), true);
    $asset = AssetService::registerAsset($data ?: []);
    echo json_encode(['success' => true, 'asset' => $asset]);
    exit;
}

// ── ROUTE 4: POST /amendments ────────────────────────────────────────────────
if ($resource === 'amendments' && $method === 'POST') {
    $auth = ApiKeyService::authenticate($token, 'amendments:create');
    if (!$auth['authenticated']) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => $auth['error']]);
        exit;
    }

    $data = json_decode(file_get_contents('php://input'), true);
    $amendment = AmendmentService::createAmendment($data ?: []);
    echo json_encode(['success' => true, 'amendment' => $amendment]);
    exit;
}

// ── Fallback 404 ─────────────────────────────────────────────────────────────
http_response_code(404);
echo json_encode([
    'success' => false,
    'error' => 'Endpoint not found.',
    'supported_routes' => ['POST /api/v1/orders', 'GET /api/v1/orders/{id}', 'POST /api/v1/assets', 'POST /api/v1/amendments']
]);
