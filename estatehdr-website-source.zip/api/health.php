<?php
/**
 * Estate HDR — System Health & Observability Endpoint
 * Provides liveness, readiness, storage metrics, and operational health status.
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');

require_once __DIR__ . '/../includes/config.php';

$checks = [];
$status = 'ok';

// 1. Data Directory Writability
$dataWritable = is_writable(DATA_PATH);
$checks['storage_data_writable'] = $dataWritable;
if (!$dataWritable) $status = 'degraded';

// 2. Avatars Directory Check
$avatarDir = ROOT_PATH . '/assets/images/avatars';
$avatarWritable = is_dir($avatarDir) && is_writable($avatarDir);
$checks['storage_avatars_writable'] = $avatarWritable;
if (!$avatarWritable) $status = 'degraded';

// 3. User Databases Check
$adminUsersFile = DATA_PATH . '/admin_users.json';
$usersFile = DATA_PATH . '/users.json';
$checks['admin_users_present'] = file_exists($adminUsersFile);
$checks['users_present'] = file_exists($usersFile);

// 4. Order System Check
$ordersDir = DATA_PATH . '/orders';
$ordersDirWritable = is_dir($ordersDir) && is_writable($ordersDir);
$checks['orders_dir_ready'] = $ordersDirWritable;

// 5. Memory & System Info
$memUsage = memory_get_usage(true);
$peakMem = memory_get_peak_usage(true);

$response = [
    'status'      => $status,
    'timestamp'   => date('c'),
    'environment' => defined('APP_ENV') ? APP_ENV : 'production',
    'php_version' => PHP_VERSION,
    'memory'      => [
        'usage_bytes' => $memUsage,
        'peak_bytes'  => $peakMem,
        'formatted'   => round($memUsage / 1024 / 1024, 2) . ' MB'
    ],
    'tenancy'     => [
        'mode'          => 'multi-tenant-ready',
        'active_tenant' => 'ehdr_main'
    ],
    'checks'      => $checks
];

http_response_code($status === 'ok' ? 200 : 503);
echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
exit;
