<?php
/**
 * Estate HDR — Real-Time Admin Notification Engine API
 * Supports polling, audio chime trigger signaling, badge counts, and marking read.
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

// Verify Admin authentication (Web Session OR Verified Mobile App Security Key)
$appKey = trim($_SERVER['HTTP_X_ESTATEHDR_APP_KEY'] ?? ($_GET['app_key'] ?? ''));
$isAppAuthorized = ($appKey === 'EH_APP_SEC_8829471920');

if (!isAdminLoggedIn() && !$isAppAuthorized) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// Release session lock early for high-frequency polling
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

$action = trim($_GET['action'] ?? ($_POST['action'] ?? 'poll'));

if ($action === 'mark_read') {
    markAdminNotificationsRead();
    echo json_encode(['success' => true, 'unread_count' => 0]);
    exit;
}

if ($action === 'clear_all') {
    clearAdminNotifications();
    echo json_encode(['success' => true, 'unread_count' => 0, 'notifications' => []]);
    exit;
}

if ($action === 'test_alert') {
    $sample = addAdminNotification(
        'order',
        '🛍️ Test Order Placed: 100 Wilshire Blvd (INV-8801)',
        'Sample notification to verify real-time audio chime and desktop push alerts.',
        '/admin/orders.php',
        ['test' => true]
    );
    echo json_encode(['success' => true, 'sample' => $sample]);
    exit;
}

// Default action: 'poll'
$notifications = getAdminNotifications(25);
$unreadCount = getUnreadAdminNotificationsCount();

// Check if any unread notification was generated within the last 18 seconds
$playChime = false;
$now = time();
foreach ($notifications as $n) {
    if (empty($n['read']) && ($now - ($n['created_at_ts'] ?? 0) <= 18)) {
        $playChime = true;
        break;
    }
}

echo json_encode([
    'success'       => true,
    'unread_count'  => $unreadCount,
    'play_chime'    => $playChime,
    'notifications' => $notifications,
    'timestamp'     => $now
]);
