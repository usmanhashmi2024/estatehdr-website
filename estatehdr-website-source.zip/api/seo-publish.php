<?php
/**
 * Estate HDR — Automated SEO & Article Ingestion REST API
 * Designed for n8n workflows, programmatic SEO, and automated content publishing.
 * Supports: Post Creation (Draft/Scheduled/Live), Page Creation, Auto-Categorization,
 * Schema Ingestion, and Site Inventory lookups for contextual Internal Linking.
 */

header('Content-Type: application/json; charset=utf-8');
header('X-Robots-Tag: noindex, nofollow', true);

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

// ── 1. API Security & Authentication ──────────────────────────
$apiKeyHeader = $_SERVER['HTTP_X_API_KEY'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';
if (stripos($apiKeyHeader, 'Bearer ') === 0) {
    $apiKeyHeader = substr($apiKeyHeader, 7);
}

// Master API Key for n8n & Automated Ingestion
$seoSettings = getSeoSettings();
$validApiKey = $seoSettings['n8n_api_key'] ?? 'your_n8n_api_key_here';

// Read Incoming JSON Payload
$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true) ?: [];

$providedKey = trim($apiKeyHeader ?: ($data['api_key'] ?? $_GET['api_key'] ?? ''));

if (empty($providedKey) || !hash_equals($validApiKey, $providedKey)) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error'   => 'Unauthorized: Invalid or missing API Key.',
        'hint'    => 'Pass X-API-KEY header or api_key in JSON body.'
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

// ── 2. Action Routing ─────────────────────────────────────────
$action = strtolower(trim($data['action'] ?? $_GET['action'] ?? 'create_post'));

// ACTION A: SITE INVENTORY (For n8n automated Internal Linking)
if ($action === 'get_site_inventory' || $action === 'inventory') {
    $publishedPosts = getPublishedBlogs();
    $pages = getPagesSeo();

    $postInventory = array_map(function($p) {
        return [
            'type'            => 'blog_post',
            'id'              => $p['id'] ?? '',
            'title'           => $p['title'] ?? '',
            'slug'            => $p['slug'] ?? '',
            'url'             => 'https://estatehdr.com/blog-post.php?slug=' . urlencode($p['slug'] ?? ''),
            'category'        => $p['category'] ?? '',
            'meta_title'      => $p['meta_title'] ?? $p['title'] ?? '',
            'meta_description'=> $p['meta_description'] ?? ''
        ];
    }, $publishedPosts);

    $pageInventory = array_map(function($pg) {
        return [
            'type'            => 'service_or_page',
            'id'              => $pg['id'] ?? '',
            'title'           => $pg['title'] ?? $pg['page_name'] ?? '',
            'slug'            => $pg['slug'] ?? '',
            'url'             => 'https://estatehdr.com/page.php?slug=' . urlencode($pg['slug'] ?? ''),
            'category'        => $pg['category'] ?? '',
            'meta_title'      => $pg['meta_title'] ?? '',
            'meta_description'=> $pg['meta_description'] ?? ''
        ];
    }, $pages);

    $coreServices = [
        ['type' => 'core_service', 'title' => 'HDR Real Estate Photo Editing', 'url' => 'https://estatehdr.com/services/hdr-photo-editing'],
        ['type' => 'core_service', 'title' => 'Virtual Staging & Furniture Insertion', 'url' => 'https://estatehdr.com/services/virtual-staging'],
        ['type' => 'core_service', 'title' => 'Day to Dusk Twilight Conversion', 'url' => 'https://estatehdr.com/services/day-to-dusk'],
        ['type' => 'core_service', 'title' => 'Item Removal & Decluttering', 'url' => 'https://estatehdr.com/services/item-removal'],
        ['type' => 'core_service', 'title' => 'Virtual Renovation & Remodeling', 'url' => 'https://estatehdr.com/services/virtual-renovation'],
        ['type' => 'core_service', 'title' => '2D & 3D Floor Plan Redrawing', 'url' => 'https://estatehdr.com/services/floor-plans'],
        ['type' => 'core_page',    'title' => 'Real Estate Media Portfolio', 'url' => 'https://estatehdr.com/portfolio.php'],
        ['type' => 'core_page',    'title' => 'Pricing & Turnaround Rates', 'url' => 'https://estatehdr.com/#pricing'],
        ['type' => 'core_page',    'title' => 'FAQ & Service Guide', 'url' => 'https://estatehdr.com/#faq']
    ];

    echo json_encode([
        'success'       => true,
        'message'       => 'Site inventory retrieved for contextual internal linking.',
        'total_targets' => count($postInventory) + count($pageInventory) + count($coreServices),
        'core_services' => $coreServices,
        'pages'         => $pageInventory,
        'blog_posts'    => $postInventory
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

// ACTION B: LIST CATEGORIES
if ($action === 'list_categories') {
    $postCats = function_exists('getPostCategories') ? getPostCategories() : [];
    $pageCats = function_exists('getPageCategories') ? getPageCategories() : [];

    echo json_encode([
        'success'         => true,
        'post_categories' => $postCats,
        'page_categories' => $pageCats
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

// ACTION B.2: FORMAT / BEAUTIFY CONTENT TO BENCHMARK STANDARD
if ($action === 'beautify' || $action === 'format_benchmark') {
    $rawContent = $data['content'] ?? '';
    $bTitle = $data['title'] ?? '';
    $bCat = $data['category'] ?? '';
    $formatted = formatArticleHtmlBenchmark($rawContent, $bTitle, $bCat);
    echo json_encode([
        'success'   => true,
        'formatted' => $formatted
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

// ACTION C: CREATE / UPDATE BLOG ARTICLE (Default for n8n)
if ($action === 'create_post' || $action === 'publish_post') {
    $title = trim($data['title'] ?? '');
    $content = trim($data['content'] ?? '');

    if (empty($title)) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'Validation error: "title" is required.'], JSON_PRETTY_PRINT);
        exit;
    }

    if (empty($content)) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'Validation error: "content" (HTML body) is required.'], JSON_PRETTY_PRINT);
        exit;
    }

    $slug = trim($data['slug'] ?? '');
    if (empty($slug)) {
        $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $title));
        $slug = trim($slug, '-');
    }

    $categoryName = trim($data['category'] ?? 'HDR Photo Editing');
    $categoryId = '';
    if (function_exists('getPostCategories') && function_exists('savePostCategory')) {
        $postCats = getPostCategories();
        $catFound = false;
        foreach ($postCats as $c) {
            if (strcasecmp($c['name'] ?? '', $categoryName) === 0 || strcasecmp($c['slug'] ?? '', $categoryName) === 0) {
                $categoryId = $c['id'] ?? '';
                $categoryName = $c['name'] ?? $categoryName;
                $catFound = true;
                break;
            }
        }
        if (!$catFound) {
            $newCat = savePostCategory([
                'name'        => $categoryName,
                'slug'        => strtolower(preg_replace('/[^a-z0-9]+/i', '-', $categoryName)),
                'description' => 'Automated SEO article cluster for ' . $categoryName
            ]);
            $categoryId = $newCat['id'] ?? '';
        }
    }

    // Status: Default is 'published' for instant live indexation, but supports 'draft' and 'scheduled'
    $status = strtolower(trim($data['status'] ?? 'published'));
    if (!in_array($status, ['published', 'draft', 'scheduled'])) {
        $status = 'published';
    }

    $scheduledAt = trim($data['scheduled_at'] ?? '');
    if ($status === 'scheduled' && empty($scheduledAt)) {
        $scheduledAt = date('Y-m-d H:i:s', time() + 86400);
    }

    $excerpt = trim($data['excerpt'] ?? '');
    if (empty($excerpt)) {
        $plainText = strip_tags($content);
        $excerpt = mb_substr($plainText, 0, 160) . '...';
    }

    // Ensure contextual internal link to a previous blog if not present
    if (!str_contains($content, '/blog/')) {
        $existingBlogs = function_exists('getPublishedBlogs') ? getPublishedBlogs() : [];
        $candidate = null;
        foreach ($existingBlogs as $eb) {
            if (!empty($eb['slug']) && $eb['slug'] !== $slug) {
                if (($eb['category'] ?? '') === $categoryName) {
                    $candidate = $eb;
                    break;
                }
                if ($candidate === null) $candidate = $eb;
            }
        }
        if ($candidate) {
            $prevLinkHtml = '<div class="glass-card p-5 rounded-2xl border border-gold/30 my-8 bg-gold/5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-lg">';
            $prevLinkHtml .= '<div class="flex items-center gap-3">';
            $prevLinkHtml .= '<span class="text-xl">📖</span>';
            $prevLinkHtml .= '<div><div class="text-xs text-gold font-bold uppercase tracking-wider">Related Reading</div>';
            $prevLinkHtml .= '<a href="/blog/' . urlencode($candidate['slug']) . '" class="text-sm font-bold text-white underline hover:text-gold transition-colors">' . htmlspecialchars($candidate['title']) . ' &rarr;</a>';
            $prevLinkHtml .= '</div></div>';
            $prevLinkHtml .= '<span class="text-xs font-mono text-gray-400">' . htmlspecialchars($candidate['read_time'] ?? '5 min read') . '</span>';
            $prevLinkHtml .= '</div>';
            $content .= "\n\n" . $prevLinkHtml;
        }
    }

    // Append Hashtags UI to content if tags provided
    $tags = $data['tags'] ?? ['Real Estate Photography', 'HDR Editing', $categoryName];
    if (is_string($tags)) {
        $tags = array_map('trim', explode(',', $tags));
    }
    if (!empty($tags) && !str_contains($content, 'class="article-hashtags"')) {
        $tagHtml = '<div class="article-hashtags flex flex-wrap items-center gap-2 pt-8 border-t border-dark-border mt-10">';
        $tagHtml .= '<span class="text-xs text-gold font-bold uppercase tracking-wider mr-2">Topic Tags:</span>';
        foreach ($tags as $t) {
            $cleanedTag = ltrim(trim($t), '#');
            if (empty($cleanedTag)) continue;
            $tagHtml .= '<span class="px-3 py-1 rounded-lg bg-gold/10 text-gold text-xs font-mono font-medium border border-gold/20 hover:border-gold/50 transition-colors">#' . htmlspecialchars($cleanedTag) . '</span>';
        }
        $tagHtml .= '</div>';
        $content .= "\n\n" . $tagHtml;
    }

    // Image resolution: If featured_image is a remote URL, download and save locally
    $featuredImg = trim($data['featured_image'] ?? '');
    if (!empty($featuredImg) && (str_starts_with($featuredImg, 'http://') || str_starts_with($featuredImg, 'https://'))) {
        $blogImgDir = ROOT_PATH . '/assets/images/blog';
        if (!is_dir($blogImgDir)) {
            @mkdir($blogImgDir, 0755, true);
        }
        $localFileName = 'ai-' . $slug . '-' . substr(md5($featuredImg), 0, 6) . '.jpg';
        $localFilePath = $blogImgDir . '/' . $localFileName;
        
        $ctx = stream_context_create([
            'http' => [
                'timeout' => 15,
                'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)\r\n"
            ]
        ]);
        $imgData = @file_get_contents($featuredImg, false, $ctx);
        if ($imgData !== false && strlen($imgData) > 1000) {
            file_put_contents($localFilePath, $imgData);
            $featuredImg = '/assets/images/blog/' . $localFileName;
        }
    }
    if (empty($featuredImg)) {
        $featuredImg = '/assets/images/blog/ai-commercial-real-estate-listings-optimization.jpg';
    }

    $content = formatArticleHtmlBenchmark($content, $title, $categoryName);
    $wordCount = str_word_count(strip_tags($content));
    $readTime = max(1, (int)ceil($wordCount / 200)) . ' min read';

    $postData = [
        'id'               => trim($data['id'] ?? ''),
        'title'            => $title,
        'slug'             => $slug,
        'excerpt'          => $excerpt,
        'content'          => $content,
        'category'         => $categoryName,
        'category_id'      => $categoryId,
        'tags'             => $tags,
        'featured_image'   => $featuredImg,
        'author'           => 'Estate HDR Team',
        'author_id'        => 'adm-senior-seo',
        'created_by'       => 'adm-senior-seo',
        'read_time'        => $readTime,
        'status'           => $status,
        'scheduled_at'     => $scheduledAt,
        'meta_title'       => trim($data['meta_title'] ?? ($title . ' | Estate HDR')),
        'meta_description' => trim($data['meta_description'] ?? $excerpt),
        'canonical_url'    => trim($data['canonical_url'] ?? ('https://estatehdr.com/blog/' . urlencode($slug))),
        'robots'           => trim($data['robots'] ?? 'index, follow'),
        'exclude_sitemap'  => !empty($data['exclude_sitemap']),
        'schema_json'      => trim($data['schema_json'] ?? '')
    ];

    $saved = saveBlog($postData);

    // Refresh Physical Sitemaps immediately on disk
    if (function_exists('generatePhysicalSitemaps')) {
        generatePhysicalSitemaps();
    }

    echo json_encode([
        'success'      => true,
        'message'      => 'Blog article saved successfully.',
        'id'           => $saved['id'] ?? '',
        'slug'         => $saved['slug'] ?? '',
        'status'       => $saved['status'] ?? 'draft',
        'category'     => $saved['category'] ?? '',
        'word_count'   => $wordCount,
        'read_time'    => $readTime,
        'url'          => 'https://estatehdr.com/blog/' . urlencode($saved['slug'] ?? ''),
        'admin_url'    => 'https://estatehdr.com/admin/post-edit.php?id=' . urlencode($saved['id'] ?? '')
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

// ACTION D: CREATE / UPDATE STATIC PAGE
if ($action === 'create_page' || $action === 'publish_page') {
    $title = trim($data['title'] ?? $data['page_name'] ?? '');
    $content = trim($data['content'] ?? '');

    if (empty($title)) {
        http_response_code(422);
        echo json_encode(['success' => false, 'error' => 'Validation error: "title" is required.'], JSON_PRETTY_PRINT);
        exit;
    }

    $slug = trim($data['slug'] ?? '');
    if (empty($slug)) {
        $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $title));
        $slug = trim($slug, '-');
    }

    $categoryName = trim($data['category'] ?? 'Services & Solutions');
    if (function_exists('getPageCategories') && function_exists('savePageCategory')) {
        $pageCats = getPageCategories();
        $catFound = false;
        foreach ($pageCats as $c) {
            if (strcasecmp($c['name'] ?? '', $categoryName) === 0) {
                $catFound = true;
                break;
            }
        }
        if (!$catFound) {
            savePageCategory([
                'name'        => $categoryName,
                'slug'        => strtolower(preg_replace('/[^a-z0-9]+/i', '-', $categoryName)),
                'description' => 'Automated page category for ' . $categoryName
            ]);
        }
    }

    $status = strtolower(trim($data['status'] ?? 'draft'));
    if (!in_array($status, ['published', 'draft'])) {
        $status = 'draft';
    }

    $pageData = [
        'id'               => trim($data['id'] ?? ''),
        'title'            => $title,
        'page_name'        => $title,
        'slug'             => $slug,
        'url_path'         => '/page.php?slug=' . urlencode($slug),
        'template'         => $data['template'] ?? 'default',
        'category'         => $categoryName,
        'author'           => trim($data['author'] ?? 'Senior SEO Content Team'),
        'status'           => $status,
        'content'          => $content,
        'featured_image'   => trim($data['featured_image'] ?? ''),
        'focus_keyword'    => trim($data['focus_keyword'] ?? ''),
        'meta_title'       => trim($data['meta_title'] ?? ($title . ' | Estate HDR')),
        'meta_description' => trim($data['meta_description'] ?? ''),
        'canonical_url'    => trim($data['canonical_url'] ?? ('https://estatehdr.com/page.php?slug=' . urlencode($slug))),
        'robots'           => trim($data['robots'] ?? 'index, follow'),
        'exclude_sitemap'  => !empty($data['exclude_sitemap']),
        'schema_json'      => trim($data['schema_json'] ?? '')
    ];

    $saved = savePage($pageData);

    if (function_exists('generatePhysicalSitemaps')) {
        generatePhysicalSitemaps();
    }

    echo json_encode([
        'success'   => true,
        'message'   => 'Static page saved successfully.',
        'id'        => $saved['id'] ?? '',
        'slug'      => $saved['slug'] ?? '',
        'status'    => $saved['status'] ?? 'draft',
        'url'       => 'https://estatehdr.com/page.php?slug=' . urlencode($saved['slug'] ?? ''),
        'admin_url' => 'https://estatehdr.com/admin/page-edit.php?id=' . urlencode($saved['id'] ?? '')
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

http_response_code(400);
echo json_encode([
    'success' => false,
    'error'   => 'Invalid action specified. Supported actions: create_post, create_page, get_site_inventory, list_categories.'
], JSON_PRETTY_PRINT);
