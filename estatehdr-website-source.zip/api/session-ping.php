<?php
/**
 * Estate HDR — Admin Session Keep-Alive & CSRF Token Refresher API
 * Prevents session expiry during long content editing sessions.
 * Returns valid CSRF token and authentication state.
 */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json; charset=utf-8');

// Check authentication
$isLoggedIn = isAdminLoggedIn();
$user = currentAdminUser();
$token = csrfToken();

// Release session lock immediately so other concurrent AJAX / page requests don't block
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

echo json_encode([
    'ok'         => $isLoggedIn,
    'csrf_token' => $token,
    'user'       => $user ? ($user['name'] ?? $user['email'] ?? 'Admin') : null,
    'timestamp'  => time()
]);
exit;
