<?php
/**
 * Estate HDR — Real-Time Live Chat AI Studio Brain API
 * Features Dynamic Knowledge Base Retrieval (RAG), Word-Boundary Matching & Natural Human Representative Persona
 */
error_reporting(0);
@ini_set('display_errors', '0');
ob_start();

@include_once __DIR__ . '/../includes/config.php';
@include_once __DIR__ . '/../includes/db.php';
@include_once __DIR__ . '/../includes/pricing-engine.php';
@include_once __DIR__ . '/../includes/routing-engine.php';
@include_once __DIR__ . '/../includes/services/AiChatAgent.php';

use EstateHDR\Services\AiChatAgent;

\EstateHDR\Security\SecurityHeaders::setSecureCors();

// Release session lock so chat polling never blocks visitor page navigation
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_clean();
    http_response_code(200);
    exit;
}

$dataPath = defined('DATA_PATH') ? DATA_PATH : (dirname(__DIR__) . '/data/');
$chatsFile = $dataPath . 'live_chats.json';
$visitorsFile = $dataPath . 'visitors.json';
$cannedFile = $dataPath . 'canned_responses.json';
$kbFile = $dataPath . 'knowledge_base.json';

function getChatsArray($file) {
    if (!file_exists($file)) return [];
    $data = @json_decode(@file_get_contents($file), true);
    return is_array($data) ? $data : [];
}

function saveChatsArray($file, $data) {
    $dir = dirname($file);
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return (bool)@file_put_contents($file, $json, LOCK_EX);
}

// ─── DYNAMIC RAG MEMORY RETRIEVAL WITH WORD-BOUNDARY MATCHING ──────
function searchKnowledgeBase($text, $kbFile) {
    if (!file_exists($kbFile)) return null;
    $kb = @json_decode(@file_get_contents($kbFile), true);
    if (!is_array($kb) || empty($kb)) return null;

    $lower = strtolower(trim($text));
    $bestMatch = null;
    $bestScore = 0;

    foreach ($kb as $chunk) {
        $score = 0;
        $keywords = $chunk['keywords'] ?? [];
        if (!is_array($keywords)) {
            $keywords = array_map('trim', explode(',', $keywords));
        }

        foreach ($keywords as $kw) {
            $kwLower = strtolower(trim($kw));
            if (empty($kwLower)) continue;

            // Multi-word phrase or single word boundary match
            if (str_contains($kwLower, ' ')) {
                if (str_contains($lower, $kwLower)) {
                    $score += 6; // Exact multi-word match gets highest priority
                }
            } else {
                if (preg_match('/\b' . preg_quote($kwLower, '/') . '\b/i', $lower)) {
                    $score += (strlen($kwLower) >= 5) ? 3 : 2;
                }
            }
        }

        if ($score > $bestScore) {
            $bestScore = $score;
            $bestMatch = $chunk;
        }
    }

    return ($bestScore >= 2) ? $bestMatch : null;
}

// ─── ENTERPRISE AI BRAIN & MEMORY REASONING ────────────────────────
function generateAiStudioReply($text, $visitorContext = [], $kbFile = '', $chatHistory = []) {
    $raw = trim($text);
    $lower = strtolower($raw);
    $cleanPhone = '447706068176';

    // 1. SPECIFIC ULTRA-RUSH / DEADLINE INQUIRIES (e.g. "6 hours", "4h", "8 hours", "tonight", "asap", "morning")
    if (preg_match('/\b(\d+)\s*(hours?|hrs?|h)\b/i', $lower, $m)) {
        $hours = intval($m[1]);
        return "Yes, we can absolutely prioritize your batch for a <strong>{$hours}-Hour Expedited Rush delivery</strong>! 🚀<br><br>" .
               "Our retouching supervisor is on live standby. Please paste your RAW bracket folder link (Google Drive, Dropbox, or WeTransfer) right here in this chat, or email <a href=\"mailto:team@estatehdr.com\" class=\"text-gold font-bold underline\">team@estatehdr.com</a> with your deadline so our team can fast-track your queue immediately!";
    }

    if (preg_match('/\b(asap|tonight|today|urgent|emergency|tight deadline|tomorrow morning)\b/i', $lower)) {
        return "Understood! We can expedite and fast-track your order on demand. ⚡<br><br>" .
               "Please share your bracket folder link right now, or message us on WhatsApp: <a href=\"https://wa.me/{$cleanPhone}?text=Hi%20Estate%20HDR%2C%20I%20have%20an%20urgent%20batch\" target=\"_blank\" class=\"text-emerald-400 font-bold underline\">+44 770 606 8176</a> so our lead supervisor can lock in your delivery time!";
    }

    // 2. CHECK DYNAMIC KNOWLEDGE BASE MEMORY CHUNKS
    if (!empty($kbFile)) {
        $kbMatch = searchKnowledgeBase($text, $kbFile);
        if ($kbMatch && !empty($kbMatch['response'])) {
            return $kbMatch['response'];
        }
    }

    // 3. DETERMINISTIC PRICING FORMULA (e.g. "25 photos", "15 pics", "30 images", "5 rooms")
    if (preg_match('/(\d+)\s*(photos?|pics?|images?|pictures?|angles?|brackets?|shots?|rooms?)/i', $lower, $m)) {
        $count = intval($m[1]);
        $isStaging = str_contains($lower, 'staging') || str_contains($lower, 'stage') || str_contains($m[2], 'room');
        $isRush = str_contains($lower, 'rush') || str_contains($lower, 'urgent') || str_contains($lower, '12h') || str_contains($lower, '12 hour');

        if (class_exists('PricingEngine')) {
            $quote = PricingEngine::calculateQuote($isStaging ? 'staging' : 'hdr', $count, 'USD', $isRush);
            $totalStr = $quote['formatted_total'];
            $quoteId = $quote['quote_id'];
            $sla = $quote['turnaround_sla'];
        } else {
            $unit = $isStaging ? 8.00 : 0.60; // Promo base rate (was 0.80)
            $disc = ($count >= 50) ? 0.90 : (($count >= 20) ? 0.95 : 1.0);
            $tot = number_format(($count * $unit * $disc) * ($isRush ? 1.25 : 1.0), 2);
            $totalStr = "$" . $tot;
            $quoteId = 'QTE-' . date('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(2)), 0, 4));
            $sla = $isRush ? 'Guaranteed 12-Hour Urgent Rush' : 'Guaranteed 24-Hour Standard Delivery';
        }

        if ($isStaging) {
            return "For <strong>{$count} rooms</strong> of 3D Virtual Staging, your deterministic quote is <strong>{$totalStr}</strong> with photorealistic designer furniture.<br><br>• Quote ID: <strong class=\"text-gold font-mono\">{$quoteId}</strong><br>• Turnaround: {$sla}<br>• Includes Unlimited Free Revisions (2-4h)<br><br>Would you like to start with 1 room as a test or share your vacant room photos?";
        }

        $camNote = '';
        if (preg_match('/(nikon|sony|canon|fuji|panasonic|leica|dng)/i', $lower, $cm)) {
            $camName = ucfirst($cm[1]);
            $camNote = " (Full {$camName} RAW bracket support included)";
        }

        return "For a listing batch of <strong>{$count} photos</strong>{$camNote}, standard hand-blended HDR retouching is <strong>{$totalStr}</strong>.<br><br>• Quote ID: <strong class=\"text-gold font-mono\">{$quoteId}</strong><br>• Turnaround: <strong>{$sla}</strong><br>• 100% manual layer window masking (no dark halos)<br>• Blue sky replacement, lawn greening &amp; TV/fire enhancement included<br><br>Would you like us to edit <strong>3 of these photos for free</strong> first so you can inspect our quality before placing a full order?";
    }

    // 4. CLOUD BRACKET STORAGE LINK UPLOADS
    if (preg_match('/(https?:\/\/[^\s]+|dropbox|drive\.google|wetransfer|onedrive|box\.com)/i', $lower)) {
        return "Thank you so much! I have securely recorded your cloud storage bracket link. Our retouching director is reviewing the exposures now.<br><br>Would you like us to proceed with your <strong>3 Free Sample Trial</strong> or process the full batch?";
    }

    // 5. EMAIL CAPTURED
    if (preg_match('/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i', $lower, $em)) {
        return "Got your email (<strong>{$em[0]}</strong>), thank you! I've linked your contact profile to our production queue. Would you like us to set up your free trial account right away?";
    }

    // 6. NATURAL COURTEOUS FOLLOW-UPS (e.g. "ok", "great", "thank you", "sounds good")
    if (preg_match('/\b(ok|okay|great|awesome|perfect|sounds good|thanks|thank you|cool|got it|sure|alright)\b/i', $lower)) {
        return "You're very welcome! Feel free to share your photo links whenever you're ready, or message us anytime. We're here 24/7 on live standby!";
    }

    // 7. GREETINGS
    if (preg_match('/^(hi|hello|hey|good\s+morning|good\s+evening|good\s+afternoon|salam|hola|bonjour|hallo)\b/i', $lower) || $lower === 'hi' || $lower === 'hello' || $lower === 'hey') {
        return "Hi there! I'm Alice at Estate HDR. 👋 How's your day going? How can I assist you with your real estate photography, floor plans, or 3D staging today?";
    }

    // 8. CONVERSATIONAL FALLBACK
    return "Thank you for reaching out to Estate HDR! We are an architectural retouching studio delivering guaranteed 24-hour turnaround HDR blending, 3D virtual staging, and day-to-dusk conversions for real estate photographers worldwide.<br><br>You can reach our production team directly at <a href=\"mailto:team@estatehdr.com\" class=\"text-gold font-bold underline\">team@estatehdr.com</a> or WhatsApp <a href=\"https://wa.me/{$cleanPhone}\" target=\"_blank\" class=\"text-emerald-400 font-bold underline\">+44 770 606 8176</a>.<br><br>Could you tell me how many photos you have or what specific editing style you need?";
}

// ─── REQUEST PARSING ────────────────────────────────────────────────
$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true) ?: $_POST;

$action = trim($input['action'] ?? ($_GET['action'] ?? 'poll_visitor'));
$visitorId = trim($input['visitor_id'] ?? ($_COOKIE['ehdr_vid'] ?? ''));

if (empty($visitorId)) {
    $visitorId = 'V-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
    @setcookie('ehdr_vid', $visitorId, time() + (86400 * 365), '/');
}

$chats = getChatsArray($chatsFile);
$now = date('Y-m-d H:i:s');
$nowTs = time();

// Auto session initialization
if (!isset($chats[$visitorId])) {
    $chats[$visitorId] = [
        'session_id'            => 'CHAT-' . strtoupper(substr($visitorId, 2, 8)),
        'visitor_id'            => $visitorId,
        'country'               => 'United Kingdom',
        'city'                  => 'London',
        'flag'                  => '🇬🇧',
        'ip'                    => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
        'device'                => 'Desktop',
        'assigned_agent'        => 'Alice (Retouching Director)',
        'routed_team'           => 'UK Executive Studio Team',
        'started_at'            => $now,
        'last_active'           => $now,
        'last_active_ts'        => $nowTs,
        'visitor_typing'        => '',
        'typing_ts'             => 0,
        'has_unread_for_agent'  => false,
        'has_unread_for_client' => false,
        'messages'              => []
    ];
}

// ACTION: PRE-CHAT LEAD GATE REGISTRATION
if ($action === 'prechat_register') {
    $res = AiChatAgent::registerPreChatLead($visitorId, $input);
    ob_clean();
    echo json_encode($res);
    exit;
}

// ACTION: GET SESSION STATUS
if ($action === 'get_session') {
    $hasPreChat = !empty($chats[$visitorId]['visitor_email']) && !empty($chats[$visitorId]['visitor_name']);
    ob_clean();
    echo json_encode([
        'success'       => true,
        'visitor_id'    => $visitorId,
        'has_prechat'   => $hasPreChat,
        'visitor_name'  => $chats[$visitorId]['visitor_name'] ?? '',
        'visitor_email' => $chats[$visitorId]['visitor_email'] ?? '',
        'messages'      => $chats[$visitorId]['messages'] ?? []
    ]);
    exit;
}

// ACTION: END CHAT & DISPATCH TRANSCRIPT
if ($action === 'end_chat') {
    AiChatAgent::dispatchDiscordTranscriptAlert($visitorId, 'Visitor Concluded Chat');
    ob_clean();
    echo json_encode(['success' => true]);
    exit;
}

// ACTION: VISITOR TYPING SYNC
if ($action === 'typing_update') {
    $text = trim($input['text'] ?? '');
    $chats[$visitorId]['visitor_typing'] = $text;
    $chats[$visitorId]['typing_ts'] = !empty($text) ? $nowTs : 0;
    saveChatsArray($chatsFile, $chats);

    ob_clean();
    echo json_encode(['success' => true]);
    exit;
}

// ACTION: VISITOR SENDS MESSAGE
if ($action === 'visitor_send') {
    // Generous rate limit on message posting only
    ehdr_rate_limit('chat_message', true);

    $message = trim($input['message'] ?? '');
    $visitorName = trim($input['visitor_name'] ?? ($chats[$visitorId]['visitor_name'] ?? ''));
    $visitorEmail = trim($input['visitor_email'] ?? ($chats[$visitorId]['visitor_email'] ?? ''));
    $visitorPhone = trim($input['visitor_phone'] ?? ($chats[$visitorId]['visitor_phone'] ?? ''));
    $pageUrl = trim($input['page_url'] ?? ($_SERVER['HTTP_REFERER'] ?? '/'));

    $humanReply = '';
    $agentName = 'Alice | Senior Retouching Director';
    $delayMs = 700;

    if (!empty($message)) {
        $chats[$visitorId]['last_active'] = $now;
        $chats[$visitorId]['last_active_ts'] = $nowTs;
        $chats[$visitorId]['visitor_typing'] = '';
        $chats[$visitorId]['typing_ts'] = 0;
        $chats[$visitorId]['has_unread_for_agent'] = true;
        if (!empty($visitorName)) $chats[$visitorId]['visitor_name'] = $visitorName;
        if (!empty($visitorEmail)) $chats[$visitorId]['visitor_email'] = $visitorEmail;
        if (!empty($visitorPhone)) $chats[$visitorId]['visitor_phone'] = $visitorPhone;

        // Append user message
        $chats[$visitorId]['messages'][] = [
            'id'        => 'msg_' . substr(bin2hex(random_bytes(4)), 0, 8),
            'sender'    => 'user',
            'text'      => htmlspecialchars($message, ENT_QUOTES, 'UTF-8'),
            'timestamp' => $now,
            'ts'        => $nowTs
        ];

        // Process through AiChatAgent
        try {
            $res = AiChatAgent::processMessage($visitorId, $message, [
                'name'     => $visitorName,
                'email'    => $visitorEmail,
                'phone'    => $visitorPhone,
                'page_url' => $pageUrl
            ]);

            $humanReply = $res['reply'] ?? '';
            $agentName  = $res['agent_name'] ?? $agentName;
            $delayMs    = $res['typing_delay_ms'] ?? 700;
        } catch (\Throwable $e) {
            $humanReply = "I'm right here with you! You can email your inquiry or RAW bracket links directly to <a href=\"mailto:order@estatehdr.com\" class=\"text-gold font-bold underline\">order@estatehdr.com</a>, or message our production bay instantly on WhatsApp: <a href=\"https://wa.me/447706068176\" target=\"_blank\" class=\"text-emerald-400 font-bold underline\">+44 770 606 8176</a>.";
        }

        // Append agent response
        $chats[$visitorId]['messages'][] = [
            'id'         => 'msg_' . substr(bin2hex(random_bytes(4)), 0, 8),
            'sender'     => 'agent',
            'agent_name' => $agentName,
            'text'       => $humanReply,
            'timestamp'  => $now,
            'ts'         => $nowTs + 1
        ];

        saveChatsArray($chatsFile, $chats);
    }

    $responseJson = json_encode([
        'success'         => true,
        'visitor_id'      => $visitorId,
        'messages'        => $chats[$visitorId]['messages'],
        'latest_reply'    => $humanReply,
        'agent_name'      => $agentName,
        'typing_delay_ms' => $delayMs
    ]);

    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
    }
    while (ob_get_level()) {
        ob_end_clean();
    }
    echo $responseJson;

    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    } else {
        @ob_flush();
        @flush();
    }

    // Dispatch Discord Live alert non-blocking
    if (!empty($message)) {
        try {
            @AiChatAgent::dispatchDiscordTranscriptAlert($visitorId, 'Live Visitor Chat');
        } catch (\Throwable $e) {}
    }
    exit;
}

// ACTION: LIVE AGENT SENDS REPLY
if ($action === 'agent_send') {
    $targetVid = trim($input['target_visitor_id'] ?? $visitorId);
    $agentName = trim($input['agent_name'] ?? 'Alice (Retouching Director)');
    $replyText = trim($input['message'] ?? '');

    if (!empty($replyText) && !empty($targetVid)) {
        if (!isset($chats[$targetVid])) {
            $chats[$targetVid] = [
                'session_id'            => 'CHAT-' . strtoupper(substr(md5($targetVid), 0, 8)),
                'visitor_id'            => $targetVid,
                'country'               => 'United States',
                'city'                  => 'New York',
                'flag'                  => '🇺🇸',
                'ip'                    => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
                'device'                => 'Desktop',
                'started_at'            => $now,
                'last_active'           => $now,
                'last_active_ts'        => $nowTs,
                'visitor_typing'        => '',
                'typing_ts'             => 0,
                'has_unread_for_agent'  => false,
                'has_unread_for_client' => true,
                'messages'              => []
            ];
        }

        $chats[$targetVid]['last_active'] = $now;
        $chats[$targetVid]['last_active_ts'] = $nowTs;
        $chats[$targetVid]['has_unread_for_agent'] = false;
        $chats[$targetVid]['has_unread_for_client'] = true;

        $chats[$targetVid]['messages'][] = [
            'id'         => 'msg_' . substr(bin2hex(random_bytes(4)), 0, 8),
            'sender'     => 'agent',
            'agent_name' => $agentName,
            'text'       => $replyText,
            'timestamp'  => $now,
            'ts'         => $nowTs
        ];

        saveChatsArray($chatsFile, $chats);

        ob_clean();
        echo json_encode([
            'success'  => true,
            'messages' => $chats[$targetVid]['messages']
        ]);
        exit;
    }

    ob_clean();
    echo json_encode(['success' => false, 'error' => 'Invalid message or recipient']);
    exit;
}

// ACTION: AI SUGGEST REPLY (For Admin Co-Pilot)
if ($action === 'ai_suggest_reply') {
    $targetVid = trim($input['target_visitor_id'] ?? '');
    $lastUserMsg = '';

    if (!empty($targetVid) && isset($chats[$targetVid]['messages'])) {
        $msgs = $chats[$targetVid]['messages'];
        for ($i = count($msgs) - 1; $i >= 0; $i--) {
            if (($msgs[$i]['sender'] ?? '') === 'user') {
                $lastUserMsg = $msgs[$i]['text'] ?? '';
                break;
            }
        }
    }

    if (empty($lastUserMsg)) {
        $lastUserMsg = trim($input['custom_query'] ?? 'pricing and free trial');
    }

    $rawHtml = generateAiStudioReply($lastUserMsg, [], $kbFile);
    $aiDraft = strip_tags(str_replace(['<br>', '<br/>', '<br />', '• '], ["\n", "\n", "\n", "\n• "], $rawHtml));

    ob_clean();
    echo json_encode([
        'success'      => true,
        'ai_draft'     => trim($aiDraft),
        'source_query' => $lastUserMsg
    ]);
    exit;
}

// ACTION: GET CANNED RESPONSES
if ($action === 'get_canned_responses') {
    $canned = file_exists($cannedFile) ? (json_decode(file_get_contents($cannedFile), true) ?: []) : [];
    ob_clean();
    echo json_encode(['success' => true, 'canned' => $canned]);
    exit;
}

// ACTION: POLL VISITOR
if ($action === 'poll_visitor') {
    $chats[$visitorId]['has_unread_for_client'] = false;
    saveChatsArray($chatsFile, $chats);

    ob_clean();
    echo json_encode([
        'success'    => true,
        'visitor_id' => $visitorId,
        'messages'   => $chats[$visitorId]['messages'] ?? []
    ]);
    exit;
}

// ACTION: POLL ADMIN
if ($action === 'poll_admin') {
    $selectedVid = trim($input['selected_vid'] ?? '');

    $hasUnreadAlert = false;
    foreach ($chats as $c) {
        if (!empty($c['has_unread_for_agent'])) {
            $hasUnreadAlert = true;
            break;
        }
    }

    $activeTyping = '';
    if (!empty($selectedVid) && isset($chats[$selectedVid])) {
        if (($nowTs - ($chats[$selectedVid]['typing_ts'] ?? 0)) <= 6) {
            $activeTyping = $chats[$selectedVid]['visitor_typing'] ?? '';
        }
    }

    ob_clean();
    echo json_encode([
        'success'          => true,
        'unread_alert'     => $hasUnreadAlert,
        'typing_preview'   => $activeTyping,
        'chats'            => $chats,
        'current_messages' => !empty($selectedVid) ? ($chats[$selectedVid]['messages'] ?? []) : []
    ]);
    exit;
}

ob_clean();
echo json_encode(['success' => true]);
