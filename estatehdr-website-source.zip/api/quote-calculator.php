<?php
/**
 * Estate HDR — Server-Side Deterministic Quote Calculator API
 * Public & Admin endpoint for instant quote generation.
 */
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/../includes/pricing-engine.php';

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

$service  = trim($input['service'] ?? 'hdr');
$quantity = intval($input['quantity'] ?? 1);
$currency = trim($input['currency'] ?? 'USD');
$isRush   = !empty($input['is_rush']);

$quote = PricingEngine::calculateQuote($service, $quantity, $currency, $isRush);

echo json_encode([
    'success' => true,
    'quote'   => $quote
]);
