<?php
/**
 * Estate HDR — AutoHDR AI Platform Bridge API
 * Connects the PHP Website Admin/Client Portal directly with the local Python AutoHDR Engine
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

if (!isAdminLoggedIn()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$action = $_GET['action'] ?? ($_POST['action'] ?? '');
$aiServerUrl = 'http://127.0.0.1:8000/api';

if ($action === 'check_status') {
    $jobId = intval($_GET['job_id'] ?? 0);
    if (!$jobId) {
        echo json_encode(['success' => false, 'error' => 'Missing job_id']);
        exit;
    }

    $ch = curl_init("{$aiServerUrl}/bridge/order-status/{$jobId}");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    $res = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200 && $res) {
        $data = json_decode($res, true);
        echo json_encode(['success' => true, 'data' => $data]);
    } else {
        echo json_encode(['success' => false, 'status' => 'offline', 'error' => 'AutoHDR Local GPU Engine not responding on http://127.0.0.1:8000']);
    }
    exit;
}

if ($action === 'start_processing') {
    verifyCsrf();
    $orderId = trim($_POST['order_id'] ?? '');
    $order = getOrder($orderId);
    if (!$order) {
        echo json_encode(['success' => false, 'error' => 'Order not found']);
        exit;
    }

    $style = trim($_POST['style'] ?? 'lisa');
    $twilight = !empty($_POST['enable_twilight']) ? 'true' : 'false';
    $lawn = !empty($_POST['enable_lawn']) ? 'true' : 'false';
    $sky = !empty($_POST['enable_sky']) ? 'true' : 'false';

    $postData = [
        'order_id'        => $orderId,
        'property_name'   => $order['property_name'] ?? 'Real Estate Property',
        'style'           => $style,
        'enable_twilight' => $twilight,
        'enable_lawn'     => $lawn,
        'enable_sky'      => $sky
    ];

    $ch = curl_init("{$aiServerUrl}/bridge/process-order");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $res = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200 && $res) {
        $json = json_decode($res, true);
        // Mark order in progress
        updateOrderStatus($orderId, 'in_progress');
        echo json_encode(['success' => true, 'job' => $json]);
    } else {
        echo json_encode([
            'success' => false,
            'error'   => 'Cannot connect to AutoHDR GPU Engine. Make sure run_server.bat and run_worker.bat are running on your PC.'
        ]);
    }
    exit;
}

echo json_encode(['success' => false, 'error' => 'Invalid action']);
