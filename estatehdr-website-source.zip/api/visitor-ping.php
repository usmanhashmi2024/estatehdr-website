<?php
/**
 * Estate HDR — Real-Time Visitor Telemetry & Lead Intelligence API
 * Captures visitor IP, Country, City, Device, OS, Browser, Visited Page, Lead Scoring & Heartbeats
 * Supports both high-speed MySQL and atomic JSON storage.
 */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/lead-scoring.php';
require_once __DIR__ . '/../includes/routing-engine.php';

\EstateHDR\Security\SecurityHeaders::setSecureCors();
ehdr_rate_limit('visitor_ping', true);

// Release session lock immediately so visitor telemetry never blocks concurrent page requests
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

header('Content-Type: application/json; charset=utf-8');

if (file_exists(__DIR__ . '/../includes/discord-bot.php')) {
    require_once __DIR__ . '/../includes/discord-bot.php';
}

function getClientIp() {
    $headers = [
        'HTTP_CF_CONNECTING_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_REAL_IP',
        'HTTP_CLIENT_IP',
        'REMOTE_ADDR'
    ];
    foreach ($headers as $header) {
        if (!empty($_SERVER[$header])) {
            $ips = explode(',', $_SERVER[$header]);
            $ip = trim($ips[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }
    return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
}

function parseUserAgent($ua) {
    $device = 'Desktop';
    if (preg_match('/(tablet|ipad|playbook)|(android(?!.*(mobi|opera mini)))/i', $ua)) {
        $device = 'Tablet';
    } elseif (preg_match('/(up.browser|up.link|mmp|symbian|smartphone|midp|wap|phone|android|iemobile|mobile)/i', $ua)) {
        $device = 'Mobile';
    }

    $os = 'Windows';
    if (preg_match('/windows|win32/i', $ua)) $os = 'Windows';
    elseif (preg_match('/iphone|ipad|ipod/i', $ua)) $os = 'iOS';
    elseif (preg_match('/macintosh|mac os x/i', $ua)) $os = 'macOS';
    elseif (preg_match('/android/i', $ua)) $os = 'Android';
    elseif (preg_match('/linux/i', $ua)) $os = 'Linux';

    $browser = 'Chrome';
    if (preg_match('/edg/i', $ua)) $browser = 'Edge';
    elseif (preg_match('/chrome|crios/i', $ua)) $browser = 'Chrome';
    elseif (preg_match('/firefox|fxios/i', $ua)) $browser = 'Firefox';
    elseif (preg_match('/safari/i', $ua)) $browser = 'Safari';
    elseif (preg_match('/opera|opr/i', $ua)) $browser = 'Opera';

    return ['device' => $device, 'os' => $os, 'browser' => $browser];
}

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;

$visitorId = trim($input['visitor_id'] ?? '');
if (empty($visitorId)) {
    $visitorId = 'V-' . substr(bin2hex(random_bytes(6)), 0, 10);
}

$pageUrl   = trim($input['page_url'] ?? '/');
$pageTitle = trim($input['page_title'] ?? 'Estate HDR — Home');
$referrer  = trim($input['referrer'] ?? 'Direct Visit');
$timeSpent = intval($input['time_spent'] ?? 0);
$eventType = trim($input['event_type'] ?? 'page_view');
$ip        = getClientIp();
$ua        = $_SERVER['HTTP_USER_AGENT'] ?? '';
$parsedUa  = parseUserAgent($ua);
$now       = date('Y-m-d H:i:s');
$nowTs     = time();

$dataPath = defined('DATA_PATH') ? DATA_PATH : (dirname(__DIR__) . '/data/');
$visitorsFile = $dataPath . 'visitors.json';

$visitors = function_exists('readJson') ? readJson($visitorsFile) : (file_exists($visitorsFile) ? (json_decode(file_get_contents($visitorsFile), true) ?: []) : []);

$isNew = !isset($visitors[$visitorId]);

$country = 'United Kingdom';
$city = 'London';
$countryCode = 'GB';
$flag = '🇬🇧';

if (isset($_SERVER['HTTP_CF_IPCOUNTRY'])) {
    $cc = strtoupper($_SERVER['HTTP_CF_IPCOUNTRY']);
    $meta = RoutingEngine::COUNTRY_REGIONS[$cc] ?? null;
    if ($meta) {
        $country = $meta['name'];
        $countryCode = $cc;
        $flag = $meta['flag'];
    }
}

$route = RoutingEngine::routeVisitor([
    'country_code' => $countryCode,
    'country'      => $country
]);

$currentScore = $visitors[$visitorId]['lead_score'] ?? 0;

$scoreEvent = 'page_view';
if (str_contains($pageUrl, 'pricing')) {
    $scoreEvent = 'pricing_viewed';
} elseif (str_contains($pageUrl, 'portfolio')) {
    $scoreEvent = 'portfolio_viewed';
} elseif ($timeSpent >= 180) {
    $scoreEvent = 'active_3min';
}

if ($eventType !== 'page_view') {
    $scoreEvent = $eventType;
}

$scoreRes = LeadScoringEngine::calculateScore($currentScore, $scoreEvent);

if ($isNew) {
    $visitors[$visitorId] = [
        'id'             => $visitorId,
        'ip'             => $ip,
        'country'        => $country,
        'city'           => $city,
        'country_code'   => $countryCode,
        'flag'           => $flag,
        'device'         => $parsedUa['device'],
        'browser'        => $parsedUa['browser'],
        'os'             => $parsedUa['os'],
        'landing_page'   => $pageUrl,
        'current_page'   => $pageUrl,
        'page_title'     => $pageTitle,
        'referrer'       => $referrer,
        'first_seen'     => $now,
        'last_seen'      => $now,
        'last_seen_ts'   => $nowTs,
        'time_spent'     => $timeSpent,
        'page_views'     => 1,
        'hits'           => 1,
        'lead_score'     => $scoreRes['new_score'],
        'lead_band'      => $scoreRes['lead_band'],
        'assigned_agent' => $route['assigned_agent'],
        'routed_team'    => $route['routed_team'],
        'is_online'      => true
    ];

    try {
        if (function_exists('notifyDiscordNewVisitor')) {
            notifyDiscordNewVisitor($visitorId, $country, $city, $flag, $pageUrl, $parsedUa['device']);
        }
    } catch (Throwable $e) {}
} else {
    $visitors[$visitorId]['last_seen']      = $now;
    $visitors[$visitorId]['last_seen_ts']   = $nowTs;
    $visitors[$visitorId]['current_page']   = $pageUrl;
    $visitors[$visitorId]['page_title']     = $pageTitle;
    $visitors[$visitorId]['time_spent']     = max($visitors[$visitorId]['time_spent'] ?? 0, $timeSpent);
    $visitors[$visitorId]['page_views']     = ($visitors[$visitorId]['page_views'] ?? 1) + 1;
    $visitors[$visitorId]['hits']           = ($visitors[$visitorId]['hits'] ?? $visitors[$visitorId]['page_views'] ?? 1) + 1;
    $visitors[$visitorId]['lead_score']     = $scoreRes['new_score'];
    $visitors[$visitorId]['lead_band']      = $scoreRes['lead_band'];
    $visitors[$visitorId]['is_online']      = true;
}

if (function_exists('atomicWriteJson')) {
    atomicWriteJson($visitorsFile, $visitors);
}

$pdo = Database::getConnection();
if ($pdo) {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO visitors (visitor_uuid, ip, country, city, country_code, flag, device, browser, os, referrer, landing_page, lead_score, lead_band, is_online, first_seen_at, last_seen_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
            ON DUPLICATE KEY UPDATE
                lead_score = VALUES(lead_score),
                lead_band = VALUES(lead_band),
                is_online = 1,
                last_seen_at = VALUES(last_seen_at)
        ");
        $stmt->execute([
            $visitorId, $ip, $country, $city, $countryCode, $flag,
            $parsedUa['device'], $parsedUa['browser'], $parsedUa['os'],
            $referrer, $pageUrl, $scoreRes['new_score'], $scoreRes['lead_band'],
            $now, $now
        ]);
    } catch (Throwable $e) {}
}

echo json_encode([
    'success'     => true,
    'visitor_id'  => $visitorId,
    'country'     => $country,
    'city'        => $city,
    'flag'        => $flag,
    'lead_score'  => $scoreRes['new_score'],
    'lead_band'   => $scoreRes['lead_band'],
    'routed_team' => $route['routed_team']
]);
