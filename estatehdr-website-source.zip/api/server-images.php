<?php
/**
 * Estate HDR — Server Media Images API
 * Returns list of all available images on server (Blog folder, Uploads, Studio Portfolio)
 */
error_reporting(0);
@ini_set('display_errors', '0');
ob_start();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

if (!isAdminLoggedIn()) {
    ob_clean();
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Admin authentication required.']);
    exit;
}

$images = getServerMediaImages();

ob_clean();
echo json_encode([
    'success' => true,
    'total'   => count($images),
    'images'  => $images
], JSON_UNESCAPED_SLASHES);
exit;