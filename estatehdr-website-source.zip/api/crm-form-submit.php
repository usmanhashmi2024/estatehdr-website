<?php
declare(strict_types=1);

/**
 * Estate HDR — Email Automation CRM Public Form Submission Handler
 * Receives lead form submissions, enrolls contacts, and triggers automations.
 */

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/services/EmailCrmService.php';

use EstateHDR\Services\EmailCrmService;

$rawInput = file_get_contents('php://input');
$postData = $_POST;

if (!empty($rawInput)) {
    $jsonData = json_decode($rawInput, true);
    if (is_array($jsonData)) {
        $postData = array_merge($postData, $jsonData);
    }
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($postData)) {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method Not Allowed']);
    exit;
}

try {
    $result = EmailCrmService::handleFormSubmission($postData);

    $isAjax = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
        || (isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false)
        || (!empty($rawInput) && !empty($jsonData));

    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($result);
        exit;
    }

    if (!empty($result['success']) && !empty($result['redirect_url'])) {
        header('Location: ' . $result['redirect_url'], true, 303);
        exit;
    }

    // Fallback HTML response
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Thank You — Estate HDR</title>
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
        <style>
            body { background: #0A0A0F; color: #FFFFFF; font-family: 'Nunito', sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; padding: 20px; }
            .card { background: #12131C; border: 1px solid rgba(201,168,76,0.3); border-radius: 20px; padding: 40px; text-align: center; max-width: 460px; box-shadow: 0 25px 50px rgba(0,0,0,0.5); }
            .gold { color: #C9A84C; font-weight: 800; }
            .btn { display: inline-block; background: #C9A84C; color: #000; font-weight: 800; padding: 12px 28px; border-radius: 12px; text-decoration: none; margin-top: 24px; transition: transform 0.2s; }
            .btn:hover { transform: translateY(-2px); }
        </style>
    </head>
    <body>
        <div class="card">
            <div style="font-size: 48px; margin-bottom: 16px;">✨</div>
            <h1 class="gold" style="font-size: 26px; margin: 0 0 10px;">Subscription Confirmed!</h1>
            <p style="color: #9CA3AF; line-height: 1.6; margin: 0;">Thank you for connecting with Estate HDR. You have been successfully added to our studio priority list.</p>
            <a href="/" class="btn">Return to Homepage ↗</a>
        </div>
    </body>
    </html>
    <?php
    exit;

} catch (Throwable $e) {
    http_response_code(400);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    exit;
}
