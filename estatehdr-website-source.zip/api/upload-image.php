<?php
/**
 * Estate HDR — Image Upload API for WYSIWYG Editor & Featured Media
 * Handles drag & drop, file uploads, base64 payloads, and custom filename slugging.
 */
error_reporting(0);
@ini_set('display_errors', '0');
ob_start();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

if (!isAdminLoggedIn()) {
    ob_clean();
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Admin or SEO Manager authentication required.']);
    exit;
}

$rawInput = file_get_contents('php://input');
$jsonInput = json_decode($rawInput, true) ?: [];

// CSRF check (can be sent via header, POST, GET, or JSON)
$csrfToken = $_POST['csrf_token'] 
    ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] 
    ?? ($_SERVER['HTTP_CSRF_TOKEN'] 
    ?? ($_GET['csrf_token'] 
    ?? ($jsonInput['csrf_token'] ?? ''))));

if (!empty($_SESSION['csrf_token'])) {
    if (empty($csrfToken) || !hash_equals($_SESSION['csrf_token'], $csrfToken)) {
        ob_clean();
        http_response_code(403);
        echo json_encode([
            'success' => false, 
            'error' => 'Invalid CSRF security token. Please refresh the page and try again.'
        ]);
        exit;
    }
}

ehdr_rate_limit('file_upload', true);

$uploadedFile = $_FILES['image'] ?? ($_FILES['file'] ?? null);
$base64Image = $_POST['image_base64'] ?? ($jsonInput['image_base64'] ?? ($jsonInput['image_data'] ?? ''));

$customName = trim($_POST['custom_name'] ?? ($jsonInput['custom_name'] ?? ''));
$altText = trim($_POST['alt'] ?? ($jsonInput['alt'] ?? ''));

$uploadSubDir = '/assets/uploads/images/' . date('Y/m');
$targetDir = rtrim(ROOT_PATH, '/') . $uploadSubDir;
if (!is_dir($targetDir)) {
    @mkdir($targetDir, 0755, true);
}

$allowedExts = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg'];
$finalFileName = '';
$ext = 'jpg';

if ($uploadedFile && !empty($uploadedFile['tmp_name'])) {
    $guardCheck = \EstateHDR\Security\FileUploadGuard::validateUploadedFile($uploadedFile, $allowedExts);
    if (!$guardCheck['valid']) {
        ob_clean();
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => $guardCheck['error']]);
        exit;
    }

    $ext = $guardCheck['ext'];
    $finalFileName = \EstateHDR\Security\FileUploadGuard::generateSafeFilename(!empty($customName) ? "{$customName}.{$ext}" : $uploadedFile['name'], 'img');
    $targetFilePath = $targetDir . '/' . $finalFileName;

    if ($ext === 'svg') {
        $svgContent = @file_get_contents($uploadedFile['tmp_name']);
        $sanitizedSvg = \EstateHDR\Security\FileUploadGuard::sanitizeSvg($svgContent ?: '');
        if (@file_put_contents($targetFilePath, $sanitizedSvg, LOCK_EX) === false) {
            ob_clean();
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Failed to write sanitized SVG to storage.']);
            exit;
        }
    } else {
        if (!@move_uploaded_file($uploadedFile['tmp_name'], $targetFilePath)) {
            ob_clean();
            http_response_code(500);
            echo json_encode(['success' => false, 'error' => 'Failed to save uploaded file to storage.']);
            exit;
        }
    }

} elseif (!empty($base64Image)) {
    if (preg_match('/^data:image\/(\w+);base64,/', $base64Image, $type)) {
        $base64Image = substr($base64Image, strpos($base64Image, ',') + 1);
        $ext = strtolower($type[1]);
        if ($ext === 'jpeg') $ext = 'jpg';
    }

    if (!in_array($ext, $allowedExts, true)) {
        $ext = 'jpg';
    }

    $imageData = base64_decode($base64Image);
    if ($imageData === false || strlen($imageData) < 50) {
        ob_clean();
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid or corrupted image data.']);
        exit;
    }

    $finalFileName = \EstateHDR\Security\FileUploadGuard::generateSafeFilename(!empty($customName) ? "{$customName}.{$ext}" : 'estate-hdr-upload.jpg', 'b64');
    $targetFilePath = $targetDir . '/' . $finalFileName;

    if ($ext === 'svg') {
        $imageData = \EstateHDR\Security\FileUploadGuard::sanitizeSvg($imageData);
    }

    if (@file_put_contents($targetFilePath, $imageData, LOCK_EX) === false) {
        ob_clean();
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Failed to write image data to storage.']);
        exit;
    }
} else {
    ob_clean();
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'No file or image data provided.']);
    exit;
}

$publicUrl = $uploadSubDir . '/' . $finalFileName;
$fileSize = @filesize($targetFilePath) ?: 0;
$dimensions = @getimagesize($targetFilePath) ?: [0, 0];

ob_clean();
echo json_encode([
    'success' => true,
    'url'     => $publicUrl,
    'name'    => $finalFileName,
    'size'    => $fileSize,
    'width'   => $dimensions[0] ?? 0,
    'height'  => $dimensions[1] ?? 0,
    'alt'     => $altText ?: ucwords(str_replace(['-', '_'], ' ', pathinfo($finalFileName, PATHINFO_FILENAME)))
], JSON_UNESCAPED_SLASHES);
exit;
