<?php
declare(strict_types=1);

/**
 * Estate HDR — Email Verification Engine API Endpoint
 * Handles single email live audits, bulk batch verification for CRM contacts, and deliverability stats.
 */

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/services/EmailVerifierService.php';

use EstateHDR\Services\EmailVerifierService;

// Ensure admin authentication
if (!function_exists('isAdminLoggedIn') || !isAdminLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized. Admin access required.']);
    exit;
}

$action = trim($_REQUEST['action'] ?? 'verify_single');

try {
    switch ($action) {
        // ── 1. Single Email Real-Time Verification ──────────────────────────
        case 'verify_single':
            $email = trim($_REQUEST['email'] ?? '');
            if (empty($email)) {
                echo json_encode(['success' => false, 'error' => 'Please provide a valid email address.']);
                exit;
            }

            $deepSmtp = isset($_REQUEST['deep_smtp']) ? (bool)(int)$_REQUEST['deep_smtp'] : true;
            $result = EmailVerifierService::verifyEmail($email, $deepSmtp);

            $mxRecords = [];
            foreach ($result['domain']['mx_records'] ?? [] as $mxHost) {
                $mxRecords[] = ['host' => $mxHost, 'priority' => 10];
            }

            echo json_encode([
                'success' => true,
                'email' => $result['email'],
                'verdict' => strtolower($result['status']),
                'status' => $result['status'],
                'score' => $result['score'],
                'quality' => $result['quality'] ?? 'good',
                'details' => [$result['verdict_summary']],
                'stages' => [
                    'syntax' => [
                        'valid' => $result['syntax']['valid'],
                        'normalized' => $result['normalized'],
                        'reason' => $result['syntax']['reason']
                    ],
                    'domain_mx' => [
                        'has_dns' => $result['domain']['valid'],
                        'has_mx' => $result['domain']['mx_found'],
                        'mx_records' => $mxRecords
                    ],
                    'disposable' => [
                        'is_disposable' => $result['risk']['disposable']
                    ],
                    'role_based' => [
                        'is_role' => $result['risk']['role_based']
                    ],
                    'typo' => [
                        'has_typo' => $result['typo']['detected'],
                        'suggestion' => $result['typo']['suggestion']
                    ],
                    'smtp' => [
                        'connected' => $result['smtp']['reachable'],
                        'mailbox_exists' => $result['mailbox']['accepted'],
                        'code' => $result['smtp']['code'],
                        'response' => $result['smtp']['response']
                    ],
                    'catch_all' => [
                        'is_catch_all' => $result['risk']['catch_all']
                    ]
                ],
                'data' => $result
            ]);
            break;

        // ── 2. Batch Verification for Contacts ─────────────────────────────
        case 'verify_batch':
            $limit = max(1, min(250, (int)($_REQUEST['batch_size'] ?? $_REQUEST['limit'] ?? 50)));
            $onlyUnverified = !isset($_REQUEST['unverified_only']) || $_REQUEST['unverified_only'] === '1' || $_REQUEST['unverified_only'] === 1;
            if (isset($_REQUEST['all']) && $_REQUEST['all'] === '1') {
                $onlyUnverified = false;
            }
            $deepSmtp = isset($_REQUEST['deep_smtp']) && ($_REQUEST['deep_smtp'] === '1' || $_REQUEST['deep_smtp'] === true || $_REQUEST['deep_smtp'] === 'true');

            $specificIds = [];
            if (!empty($_REQUEST['ids'])) {
                $specificIds = is_array($_REQUEST['ids']) ? $_REQUEST['ids'] : array_filter(array_map('trim', explode(',', (string)$_REQUEST['ids'])));
            }

            $batch = EmailVerifierService::bulkVerifyContacts($limit, $onlyUnverified, $specificIds, $deepSmtp);
            $stats = EmailVerifierService::getVerificationStats();

            $formattedResults = [];
            foreach ($batch['batch_results'] as $r) {
                $formattedResults[] = [
                    'id' => $r['id'],
                    'email' => $r['email'],
                    'verdict' => strtolower($r['status']),
                    'status' => $r['status'],
                    'score' => $r['score'],
                    'summary' => $r['summary']
                ];
            }

            echo json_encode([
                'success' => true,
                'processed_count' => $batch['processed'],
                'has_more' => $batch['remaining_unverified'] > 0,
                'remaining' => $batch['remaining_unverified'],
                'stats' => $stats,
                'results' => $formattedResults,
                'data' => $batch
            ]);
            break;

        // ── 3. Single Contact Verify & Save ─────────────────────────────────
        case 'verify_contact':
            $contactId = trim($_REQUEST['id'] ?? $_REQUEST['contact_id'] ?? '');
            if (empty($contactId)) {
                echo json_encode(['success' => false, 'error' => 'Missing contact ID.']);
                exit;
            }

            $deepSmtp = isset($_REQUEST['deep_smtp']) ? (bool)(int)$_REQUEST['deep_smtp'] : true;
            $batch = EmailVerifierService::bulkVerifyContacts(1, false, [$contactId], $deepSmtp);
            $res = $batch['batch_results'][0] ?? null;

            if (!$res) {
                echo json_encode(['success' => false, 'error' => 'Contact not found or unable to verify.']);
                exit;
            }

            echo json_encode([
                'success' => true,
                'id' => $res['id'],
                'email' => $res['email'],
                'verdict' => strtolower($res['status']),
                'status' => $res['status'],
                'score' => $res['score'],
                'summary' => $res['summary'],
                'data' => $res
            ]);
            break;

        // ── 4. Get Current Verification Statistics ──────────────────────────
        case 'stats':
        case 'get_stats':
            $stats = EmailVerifierService::getVerificationStats();
            echo json_encode([
                'success' => true,
                'stats' => $stats,
                'data' => $stats
            ]);
            break;

        // ── 5. Purge / Delete Verified Contacts (Invalid, Risky, Unhealthy, Selected) ──
        case 'purge_contacts':
        case 'delete_contacts':
            $target = strtolower(trim($_REQUEST['target'] ?? 'invalid'));
            if (!in_array($target, ['invalid', 'risky', 'unhealthy', 'selected'], true)) {
                $target = 'invalid';
            }

            $specificIds = [];
            if (!empty($_REQUEST['ids'])) {
                $specificIds = is_array($_REQUEST['ids']) ? $_REQUEST['ids'] : array_filter(array_map('trim', explode(',', (string)$_REQUEST['ids'])));
                if (!empty($specificIds)) {
                    $target = 'selected';
                }
            }

            $purgeRes = EmailVerifierService::purgeContacts($target, $specificIds);

            echo json_encode([
                'success' => true,
                'target' => $purgeRes['target'],
                'removed_count' => $purgeRes['removed_count'],
                'remaining_count' => $purgeRes['remaining_count'],
                'stats' => $purgeRes['stats'],
                'data' => $purgeRes,
                'message' => "Successfully removed {$purgeRes['removed_count']} {$purgeRes['target']} contacts."
            ]);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action specified.']);
            break;
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Internal verification error: ' . $e->getMessage()
    ]);
}
