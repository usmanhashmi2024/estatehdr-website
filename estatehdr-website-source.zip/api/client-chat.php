<?php
/**
 * Estate HDR — Client-to-Management Live Chat API
 * Provides fast AJAX endpoints for real-time messaging, per-message order context tagging,
 * file & screenshot attachments, and management replies.
 */

error_reporting(0);
@ini_set('display_errors', '0');
ob_start();

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/services/ClientChatService.php';

header('Content-Type: application/json; charset=utf-8');
\EstateHDR\Security\SecurityHeaders::setSecureCors();

$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true) ?: $_POST;
$action = trim($input['action'] ?? ($_GET['action'] ?? 'poll'));

$currentClient = currentUser();
$isAdmin = isAdminLoggedIn();
$currentAdmin = $isAdmin ? currentAdminUser() : null;

/**
 * Handle secure file attachment upload for chat
 */
function handleChatAttachmentUpload(string $uploaderId): ?array {
    if (empty($_FILES['attachment']) || !is_uploaded_file($_FILES['attachment']['tmp_name'])) {
        return null;
    }

    $file = $_FILES['attachment'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['error' => 'File upload error code: ' . $file['error']];
    }

    $maxBytes = 25 * 1024 * 1024; // 25MB
    if ($file['size'] > $maxBytes) {
        return ['error' => 'Attachment exceeds maximum allowed size of 25MB.'];
    }

    $originalName = basename($file['name']);
    $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    $allowedExts = ['jpg', 'jpeg', 'png', 'webp', 'pdf', 'zip'];
    if (!in_array($ext, $allowedExts)) {
        return ['error' => 'Invalid file format. Allowed: JPG, PNG, WEBP, PDF, ZIP.'];
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    $allowedMimes = [
        'image/jpeg', 'image/png', 'image/webp',
        'application/pdf', 'application/zip', 'application/x-zip-compressed', 'application/octet-stream'
    ];
    if (!in_array($mime, $allowedMimes)) {
        return ['error' => 'File content type mismatch (' . htmlspecialchars($mime) . ').'];
    }

    $uploadDir = dirname(__DIR__) . '/uploads/chat_attachments/';
    if (!is_dir($uploadDir)) {
        @mkdir($uploadDir, 0755, true);
        @file_put_contents($uploadDir . '.htaccess', "Options -Indexes\n<FilesMatch \"\.(php|php5|phtml|phar)\$\">\nOrder Deny,Allow\nDeny from all\n</FilesMatch>\n");
    }

    $cleanUploader = preg_replace('/[^a-zA-Z0-9_-]/', '', $uploaderId);
    $storedName = 'att_' . $cleanUploader . '_' . date('Ymd_His') . '_' . substr(bin2hex(random_bytes(4)), 0, 8) . '.' . $ext;
    $targetPath = $uploadDir . $storedName;

    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        return ['error' => 'Failed to save attachment to storage.'];
    }

    return [
        'file_name' => $originalName,
        'file_url'  => '/uploads/chat_attachments/' . $storedName,
        'file_type' => $mime,
        'file_size' => (int)$file['size'],
        'is_image'  => str_starts_with($mime, 'image/')
    ];
}

// ── 1. CLIENT ACTION: POLL MESSAGES ──────────────────────────────
if ($action === 'poll') {
    if (!$currentClient) {
        ob_clean();
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Authentication required']);
        exit;
    }

    $clientId = $currentClient['id'];
    $thread = ClientChatService::getClientThread($clientId, $currentClient);
    
    // Mark as read by client if specified
    if (!empty($input['mark_read']) || !empty($_GET['mark_read'])) {
        ClientChatService::markReadForClient($clientId);
        $thread['unread_client'] = 0;
    }

    ob_clean();
    echo json_encode([
        'success'       => true,
        'client_id'     => $clientId,
        'messages'      => $thread['messages'] ?? [],
        'unread_client' => (int)($thread['unread_client'] ?? 0),
        'assigned_lead' => $thread['assigned_lead'] ?? 'Production Management Desk',
        'status'        => $thread['status'] ?? 'open'
    ]);
    exit;
}

// ── 2. CLIENT ACTION: SEND MESSAGE ───────────────────────────────
if ($action === 'send') {
    if (!$currentClient) {
        ob_clean();
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Authentication required']);
        exit;
    }

    $clientId = $currentClient['id'];
    $attachment = null;

    if (!empty($_FILES['attachment'])) {
        $attResult = handleChatAttachmentUpload($clientId);
        if (isset($attResult['error'])) {
            ob_clean();
            echo json_encode(['success' => false, 'error' => $attResult['error']]);
            exit;
        }
        $attachment = $attResult;
    }

    $text = trim($input['text'] ?? ($_POST['text'] ?? ''));
    if (empty($text) && empty($attachment)) {
        ob_clean();
        echo json_encode(['success' => false, 'error' => 'Please enter a message or attach a file.']);
        exit;
    }

    $orderId = !empty($input['order_id']) ? trim($input['order_id']) : (!empty($_POST['order_id']) ? trim($_POST['order_id']) : null);
    if ($orderId === 'none' || $orderId === 'general' || empty($orderId)) {
        $orderId = null;
    }

    $thread = ClientChatService::postClientMessage($clientId, $text, $orderId, $currentClient, $attachment);

    ob_clean();
    echo json_encode([
        'success'       => true,
        'client_id'     => $clientId,
        'messages'      => $thread['messages'] ?? [],
        'unread_client' => (int)($thread['unread_client'] ?? 0),
        'assigned_lead' => $thread['assigned_lead'] ?? 'Production Management Desk'
    ]);
    exit;
}

// ── 3. CLIENT ACTION: GET ORDER SUMMARY ───────────────────────────
if ($action === 'client_orders') {
    if (!$currentClient) {
        ob_clean();
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Authentication required']);
        exit;
    }

    $summary = ClientChatService::getClientOrderSummary($currentClient['id']);
    ob_clean();
    echo json_encode([
        'success' => true,
        'summary' => $summary
    ]);
    exit;
}

// ── 4. ADMIN ACTION: LIST ALL CLIENT CHATS ───────────────────────
if ($action === 'admin_list') {
    if (!$isAdmin) {
        ob_clean();
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Admin authorization required']);
        exit;
    }

    $allChats = ClientChatService::getAllChats();
    uasort($allChats, fn($a, $b) => ($b['last_active_ts'] ?? 0) <=> ($a['last_active_ts'] ?? 0));

    ob_clean();
    echo json_encode([
        'success'      => true,
        'chats'        => array_values($allChats),
        'total_unread' => ClientChatService::getTotalAdminUnreadCount()
    ]);
    exit;
}

// ── 5. ADMIN ACTION: POLL SINGLE CLIENT THREAD ───────────────────
if ($action === 'admin_poll') {
    if (!$isAdmin) {
        ob_clean();
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Admin authorization required']);
        exit;
    }

    $clientId = trim($input['client_id'] ?? ($_GET['client_id'] ?? ''));
    if (empty($clientId)) {
        ob_clean();
        echo json_encode(['success' => false, 'error' => 'Client ID missing']);
        exit;
    }

    $thread = ClientChatService::getClientThread($clientId);
    ClientChatService::markReadForAdmin($clientId);
    $thread['unread_admin'] = 0;

    $orderSummary = ClientChatService::getClientOrderSummary($clientId);

    ob_clean();
    echo json_encode([
        'success'       => true,
        'thread'        => $thread,
        'messages'      => $thread['messages'] ?? [],
        'order_summary' => $orderSummary
    ]);
    exit;
}

// ── 6. ADMIN ACTION: SEND MANAGEMENT REPLY ───────────────────────
if ($action === 'admin_send') {
    if (!$isAdmin) {
        ob_clean();
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Admin authorization required']);
        exit;
    }

    $clientId = trim($input['client_id'] ?? ($_POST['client_id'] ?? ''));
    if (empty($clientId)) {
        ob_clean();
        echo json_encode(['success' => false, 'error' => 'Client ID is required']);
        exit;
    }

    $attachment = null;
    if (!empty($_FILES['attachment'])) {
        $attResult = handleChatAttachmentUpload($currentAdmin['id'] ?? 'admin');
        if (isset($attResult['error'])) {
            ob_clean();
            echo json_encode(['success' => false, 'error' => $attResult['error']]);
            exit;
        }
        $attachment = $attResult;
    }

    $text = trim($input['text'] ?? ($_POST['text'] ?? ''));
    if (empty($text) && empty($attachment)) {
        ob_clean();
        echo json_encode(['success' => false, 'error' => 'Please enter reply text or attach a file.']);
        exit;
    }

    $orderId = !empty($input['order_id']) ? trim($input['order_id']) : (!empty($_POST['order_id']) ? trim($_POST['order_id']) : null);
    if ($orderId === 'none' || $orderId === 'general' || empty($orderId)) {
        $orderId = null;
    }

    $agentName = $currentAdmin['name'] ?? 'Production Director';
    $agentRole = 'Management';
    $roles = $currentAdmin['roles'] ?? [];
    if (in_array('owner', $roles) || in_array('super_admin', $roles)) {
        $agentRole = 'Executive Director';
    } elseif (in_array('manager', $roles)) {
        $agentRole = 'Production Manager';
    } elseif (in_array('team_lead', $roles)) {
        $agentRole = 'Lead QA Supervisor';
    }

    $thread = ClientChatService::postManagementReply($clientId, $agentName, $agentRole, $text, $orderId, $attachment);

    ob_clean();
    echo json_encode([
        'success'  => true,
        'thread'   => $thread,
        'messages' => $thread['messages'] ?? []
    ]);
    exit;
}

ob_clean();
echo json_encode(['success' => false, 'error' => 'Invalid action']);
exit;
