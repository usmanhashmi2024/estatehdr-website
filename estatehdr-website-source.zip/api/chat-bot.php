<?php
/**
 * Estate HDR — Native AI Concierge & Chat Processing API
 * Handles real-time customer conversations, intent matching, transcript logging & lead capture
 */
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';

$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$visitorId = trim($input['visitor_id'] ?? ($_COOKIE['ehdr_vid'] ?? ''));
$message = trim($input['message'] ?? '');
$email = trim($input['email'] ?? '');
$phone = trim($input['phone'] ?? '');

if (empty($visitorId)) {
    $visitorId = 'V-' . substr(bin2hex(random_bytes(6)), 0, 10);
    setcookie('ehdr_vid', $visitorId, time() + (86400 * 365), '/');
}

$cleanPhoneWhatsApp = preg_replace('/[^0-9]/', '', WHATSAPP_NUMBER);
if (empty($cleanPhoneWhatsApp)) $cleanPhoneWhatsApp = '447706068176';

// Master Estate HDR Knowledge Base
function matchBotResponse($text, $cleanPhone) {
    $lower = strtolower($text);

    // 1. Free Trial & Samples
    if (str_contains($lower, 'trial') || str_contains($lower, 'free') || str_contains($lower, 'sample') || str_contains($lower, 'test')) {
        return [
            'reply' => "🎉 You can claim <strong>3 Free Sample Edits</strong> with zero upfront payment and no credit card required! Simply send us your RAW bracket files via Google Drive, Dropbox, or WeTransfer, and we'll deliver your edited photos within 24 hours.",
            'cta'   => '<div class="mt-2.5 flex flex-wrap gap-2"><a href="/#trial" class="px-3.5 py-1.5 rounded-xl bg-gold text-dark font-bold text-xs shadow-glow">Claim Free Trial (No Signup) &rarr;</a> <a href="https://wa.me/' . $cleanPhone . '?text=Hi%20Estate%20HDR%2C%20I%20want%20to%20send%20my%203%20free%20trial%20photos" target="_blank" class="px-3 py-1.5 rounded-xl bg-emerald-600/80 text-white font-semibold text-xs">Send on WhatsApp ↗</a></div>'
        ];
    }

    // 2. Pricing & Cost
    if (str_contains($lower, 'price') || str_contains($lower, 'cost') || str_contains($lower, 'rate') || str_contains($lower, 'discount') || str_contains($lower, 'how much')) {
        return [
            'reply' => "💰 Our volume commercial pricing is transparent and highly affordable:<br><br>" .
                       "• <strong>HDR Photo Editing:</strong> Was <span style="text-decoration:line-through;">$0.80</span> <strong>$0.60 / photo</strong> (Limited Time Promo + 1 FREE Day-to-Dusk Hero Photo!)<br>" .
                       "• <strong>3D Virtual Staging:</strong> From $8.00 / photo<br>" .
                       "• <strong>Day to Dusk Conversion:</strong> From $4.00 / photo<br>" .
                       "• <strong>Virtual Twilight:</strong> From $4.00 / photo<br>" .
                       "• <strong>Item Removal & Declutter:</strong> From $2.00 / photo<br>" .
                       "• <strong>2D/3D Floor Plans:</strong> From $12.00 / plan<br><br>" .
                       "<em>*Volume discounts available for photographers shooting 20+ properties/month!</em>",
            'cta'   => '<div class="mt-2.5 flex flex-wrap gap-2"><a href="/#pricing" class="px-3.5 py-1.5 rounded-xl bg-gold text-dark font-bold text-xs shadow-glow">View Pricing Table &rarr;</a> <a href="https://wa.me/' . $cleanPhone . '?text=Hi%20Estate%20HDR%2C%20I%20shoot%20high%20volume%2C%20can%20I%20get%20a%20bulk%20discount%3F" target="_blank" class="px-3 py-1.5 rounded-xl bg-emerald-600/80 text-white font-semibold text-xs">Ask for Volume Discount ↗</a></div>'
        ];
    }

    // 3. Turnaround Time & Rush Delivery
    if (str_contains($lower, 'time') || str_contains($lower, 'hour') || str_contains($lower, 'turnaround') || str_contains($lower, 'fast') || str_contains($lower, 'rush') || str_contains($lower, 'speed')) {
        return [
            'reply' => "⏱️ Our guaranteed turnaround times:<br><br>" .
                       "• <strong>Standard Delivery:</strong> Within <strong>24 Hours</strong> guaranteed for all residential HDR orders.<br>" .
                       "• <strong>Rush 12h Delivery:</strong> Available on demand for urgent morning MLS listings.<br>" .
                       "• <strong>Amendments & Tweaks:</strong> Free revisions processed within <strong>2 to 4 hours</strong>!",
            'cta'   => '<div class="mt-2.5"><a href="https://wa.me/' . $cleanPhone . '?text=Hi%20Estate%20HDR%2C%20I%20have%20an%20urgent%2012h%20rush%20delivery%20order" target="_blank" class="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs inline-flex items-center gap-1.5"><span>⚡ Request Urgent 12h Rush Order</span> ↗</a></div>'
        ];
    }

    // 4. RAW formats, cameras, window pulls
    if (str_contains($lower, 'raw') || str_contains($lower, 'format') || str_contains($lower, 'sony') || str_contains($lower, 'canon') || str_contains($lower, 'nikon') || str_contains($lower, 'dng') || str_contains($lower, 'bracket') || str_contains($lower, 'window')) {
        return [
            'reply' => "📸 We support all professional camera RAW brackets and formats:<br><br>" .
                       "• <strong>Sony:</strong> .ARW (A7R series, A7IV, etc.)<br>" .
                       "• <strong>Canon:</strong> .CR2 & .CR3 (R5, R6, 5D series)<br>" .
                       "• <strong>Nikon:</strong> .NEF (Z series, D850)<br>" .
                       "• <strong>Adobe / Other:</strong> .DNG, .RAF, .RW2, JPG, 16-bit TIFF.<br><br>" .
                       "We perform 100% manual layer masking in Photoshop with flawless window pulls, sky replacement, TV screens, and fireplace flame insertion included for free!",
            'cta'   => '<div class="mt-2.5"><a href="/portfolio.php" class="px-3.5 py-1.5 rounded-xl bg-gold text-dark font-bold text-xs shadow-glow">View Interactive Portfolio &rarr;</a></div>'
        ];
    }

    // 5. Contact / Human Escalation / WhatsApp / Phone
    if (str_contains($lower, 'human') || str_contains($lower, 'agent') || str_contains($lower, 'talk') || str_contains($lower, 'whatsapp') || str_contains($lower, 'call') || str_contains($lower, 'phone') || str_contains($lower, 'email')) {
        return [
            'reply' => "💬 Our senior retouching director and client success team are available 24/7 on WhatsApp! You can message us right now for instant assistance:",
            'cta'   => '<div class="mt-2.5"><a href="https://wa.me/' . $cleanPhone . '?text=Hi%20Estate%20HDR%20Team%2C%20I%20would%20like%20to%20speak%20with%20a%20manager" target="_blank" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs inline-flex items-center gap-2 shadow-lg"><span>💬 Chat with Live Manager (+44 770 606 8176)</span> ↗</a></div>'
        ];
    }

    // 6. Default Smart Fallback
    return [
        'reply' => "Thank you for reaching out! Our architectural retouching directors have received your inquiry. We specialize in 24-hour turnaround HDR blending, 3D virtual staging, and day-to-dusk conversions for real estate professionals worldwide.",
        'cta'   => '<div class="mt-2.5 flex flex-wrap gap-2"><a href="https://wa.me/' . $cleanPhone . '?text=' . urlencode('Hi Estate HDR, Inquiry: ' . $text) . '" target="_blank" class="px-3.5 py-1.5 rounded-xl bg-emerald-600 text-white font-bold text-xs"><span>💬 Continue on WhatsApp</span> ↗</a> <a href="/#trial" class="px-3 py-1.5 rounded-xl bg-gold text-dark font-bold text-xs">Start Free Trial &rarr;</a></div>'
    ];
}

$botResult = matchBotResponse($message, $cleanPhoneWhatsApp);

// ── Log Transcript to data/live_chats.json ───────────────────────
$chatsFile = DATA_PATH . 'live_chats.json';
$chats = readJson($chatsFile);

$now = date('Y-m-d H:i:s');

if (!isset($chats[$visitorId])) {
    $visitorsFile = DATA_PATH . 'visitors.json';
    $visitors = readJson($visitorsFile);
    $vis = $visitors[$visitorId] ?? [];

    $chats[$visitorId] = [
        'session_id'   => 'CHAT-' . strtoupper(substr($visitorId, 2, 8)),
        'visitor_id'   => $visitorId,
        'country'      => $vis['country'] ?? 'United Kingdom',
        'city'         => $vis['city'] ?? 'London',
        'flag'         => $vis['flag'] ?? '🇬🇧',
        'ip'           => $vis['ip'] ?? '127.0.0.1',
        'device'       => $vis['device'] ?? 'Desktop',
        'started_at'   => $now,
        'last_active'  => $now,
        'messages'     => [],
        'lead_email'   => $email,
        'lead_phone'   => $phone,
        'status'       => 'active'
    ];
}

$chats[$visitorId]['last_active'] = $now;
if (!empty($email)) $chats[$visitorId]['lead_email'] = $email;
if (!empty($phone)) $chats[$visitorId]['lead_phone'] = $phone;

// Append User message
$chats[$visitorId]['messages'][] = [
    'sender'    => 'user',
    'text'      => $message,
    'timestamp' => $now
];

// Append Bot reply
$chats[$visitorId]['messages'][] = [
    'sender'    => 'bot',
    'text'      => $botResult['reply'],
    'cta'       => $botResult['cta'],
    'timestamp' => $now
];

atomicWriteJson($chatsFile, $chats);

// If email or phone provided, or message contains email, bridge into data/leads.json
if (!empty($email) || preg_match('/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i', $message, $m)) {
    $leadEmail = !empty($email) ? $email : ($m[0] ?? '');
    if (function_exists('saveLead')) {
        saveLead([
            'name'       => 'Live Chat Visitor (' . ($chats[$visitorId]['city'] ?? 'Web') . ')',
            'email'      => $leadEmail,
            'whatsapp'   => $phone,
            'notes'      => 'Inquiry via Live AI Concierge: ' . $message,
            'source'     => 'live_chat_concierge',
            'cloud_link' => ''
        ]);
    }
}

echo json_encode([
    'success' => true,
    'reply'   => $botResult['reply'],
    'cta'     => $botResult['cta'],
    'session' => $chats[$visitorId]['session_id']
]);
