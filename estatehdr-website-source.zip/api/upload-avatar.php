<?php
/**
 * Estate HDR — Profile Avatar Upload & Base64 Image Processor
 * Securely saves cropped avatars, updates session and user database
 */
error_reporting(0);
@ini_set('display_errors', '0');
ob_start();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

require_once __DIR__ . '/../includes/audit.php';

if (!isAdminLoggedIn() && !isLoggedIn()) {
    ob_clean();
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Authentication required.']);
    exit;
}

ehdr_rate_limit('file_upload', true);

$rawInput = file_get_contents('php://input');
$input = json_decode($rawInput, true) ?: $_POST;

$base64Image = $input['image_data'] ?? ($input['avatar_data'] ?? '');
$csrfToken   = $input['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');

// CSRF check
if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $csrfToken)) {
    ob_clean();
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Invalid CSRF security token.']);
    exit;
}

if (empty($base64Image)) {
    ob_clean();
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'No image data received.']);
    exit;
}

// Clean and decode base64 image data
$allowedAvatarExts = ['jpg', 'jpeg', 'png', 'webp'];
if (preg_match('/^data:image\/(\w+);base64,/', $base64Image, $type)) {
    $base64Image = substr($base64Image, strpos($base64Image, ',') + 1);
    $ext = strtolower($type[1]); // jpg, png, webp
    if ($ext === 'jpeg') $ext = 'jpg';
} else {
    $ext = 'jpg';
}

if (!in_array($ext, $allowedAvatarExts, true)) {
    $ext = 'jpg';
}

$imageData = base64_decode($base64Image);
if ($imageData === false || strlen($imageData) < 50 || strlen($imageData) > \EstateHDR\Security\FileUploadGuard::MAX_IMAGE_SIZE_BYTES) {
    ob_clean();
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Corrupted, invalid, or oversized image data.']);
    exit;
}

// Target folder
$avatarDir = ROOT_PATH . '/assets/images/avatars/';
if (!is_dir($avatarDir)) {
    @mkdir($avatarDir, 0755, true);
}

$isAdmin = isAdminLoggedIn();
$currentAdmin = currentAdminUser();
$currentUser  = currentUser();

$userId = $isAdmin ? ($currentAdmin['id'] ?? 'adm-1') : ($currentUser['id'] ?? 'CL-1001');
$cleanUserId = preg_replace('/[^a-zA-Z0-9_-]/', '', $userId);
$filename = 'avatar_' . $cleanUserId . '_' . substr(bin2hex(random_bytes(4)), 0, 6) . '.' . $ext;
$targetPath = $avatarDir . $filename;
$webUrl = '/assets/images/avatars/' . $filename;

// Save file securely
if (@file_put_contents($targetPath, $imageData, LOCK_EX) === false) {
    ob_clean();
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to save avatar image on server disk.']);
    exit;
}

// Update Admin storage
if ($isAdmin) {
    $adminUsersFile = DATA_PATH . '/admin_users.json';
    if (file_exists($adminUsersFile)) {
        $admins = json_decode(file_get_contents($adminUsersFile), true) ?: [];
        foreach ($admins as &$a) {
            if (($a['id'] ?? '') === $userId || strtolower($a['email'] ?? '') === strtolower($currentAdmin['email'] ?? '')) {
                $a['photo'] = $webUrl;
                break;
            }
        }
        @file_put_contents($adminUsersFile, json_encode($admins, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX);
    }
    $_SESSION['admin_user']['photo'] = $webUrl;
} else {
    // Update Client User storage
    $usersFile = DATA_PATH . '/users.json';
    if (file_exists($usersFile)) {
        $users = json_decode(file_get_contents($usersFile), true) ?: [];
        foreach ($users as &$u) {
            if (($u['id'] ?? '') === $userId || strtolower($u['email'] ?? '') === strtolower($currentUser['email'] ?? '')) {
                $u['photo'] = $webUrl;
                break;
            }
        }
        @file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX);
    }
    $_SESSION['client_user']['photo'] = $webUrl;
}

logAuditEvent('profile.avatar_update', $userId, ['photo_url' => $webUrl], $userId);

ob_clean();
echo json_encode([
    'success'   => true,
    'message'   => 'Profile photo successfully updated and cropped!',
    'photo_url' => $webUrl
]);
exit;
