<?php
declare(strict_types=1);

/**
 * Estate HDR — Email Automation CRM Tracking Endpoint
 * Handles 1x1 transparent GIF open pixel tracking and link-click redirect wrapping.
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/services/EmailCrmService.php';

use EstateHDR\Services\EmailCrmService;

$action = $_GET['t'] ?? 'open';
$campaignId = trim($_GET['c'] ?? '');
$contactId = trim($_GET['u'] ?? '');

if ($action === 'open') {
    if (!empty($campaignId) && !empty($contactId)) {
        try {
            EmailCrmService::recordOpen($campaignId, $contactId);
        } catch (Throwable $e) {
            error_log('[CRM Track] Open error: ' . $e->getMessage());
        }
    }

    // 43-byte transparent 1x1 GIF
    header('Content-Type: image/gif');
    header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    echo base64_decode('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');
    exit;
}

if ($action === 'click') {
    $destination = trim($_GET['url'] ?? '');
    if (!empty($campaignId) && !empty($contactId) && !empty($destination)) {
        try {
            EmailCrmService::recordClick($campaignId, $contactId, $destination);
        } catch (Throwable $e) {
            error_log('[CRM Track] Click error: ' . $e->getMessage());
        }
    }

    // Validate redirect URL safety
    if (!empty($destination) && filter_var($destination, FILTER_VALIDATE_URL)) {
        $scheme = parse_url($destination, PHP_URL_SCHEME);
        if (in_array(strtolower($scheme ?: ''), ['http', 'https'], true)) {
            header('Location: ' . $destination, true, 302);
            exit;
        }
    }

    header('Location: https://estatehdr.com', true, 302);
    exit;
}

header('HTTP/1.1 400 Bad Request');
echo 'Invalid tracking request.';
exit;
