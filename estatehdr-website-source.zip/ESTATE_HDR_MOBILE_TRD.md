# Technical Requirements Document (TRD)
# Estate HDR Mobile Ecosystem: Client App & Team App Architecture

**Document Version:** 1.0.0  
**Status:** Approved for Engineering & Backend Implementation  
**Target Architecture:** Cross-Platform Native Mobile + Microservices Cloud Backend  
**Author:** Estate HDR Principal Systems Architect  
**Confidentiality:** Proprietary — Estate HDR Studio Ltd.  

---

## 1. System Architecture Overview

The Estate HDR mobile ecosystem is architected using a decoupled, reactive client-server model. A single unified backend API layer powers both the **Client Mobile App** and the **Team Mobile App**, integrating with high-performance object storage, WebSocket real-time gateways, and push notification distributors.

```
┌──────────────────────────────┐         ┌──────────────────────────────┐
│    ESTATE HDR CLIENT APP     │         │      ESTATE HDR TEAM APP     │
│ (Flutter / React Native)     │         │ (Flutter / React Native)     │
│ • State: Riverpod / Bloc     │         │ • State: Riverpod / Bloc     │
│ • Cache: SQLite / Hive       │         │ • Cache: SQLite / Hive       │
└──────────────┬───────────────┘         └──────────────┬───────────────┘
               │ HTTPS (REST API)                       │ HTTPS (REST API)
               │ WSS (WebSockets)                       │ WSS (WebSockets)
               ▼                                        ▼
┌───────────────────────────────────────────────────────────────────────┐
│                 ESTATE HDR API GATEWAY & LOAD BALANCER                │
│                 (Nginx / Cloudflare WAF + SSL Termination)            │
└───────────────────────────────────┬───────────────────────────────────┘
                                    │
    ┌───────────────────────────────┼───────────────────────────────┐
    ▼                               ▼                               ▼
┌───────────────────────┐ ┌───────────────────┐ ┌───────────────────────┐
│ AUTH & USER SERVICE   │ │ ORDER & SLA ENGINE│ │ REAL-TIME CHAT & PUSH │
│ • JWT / OAuth2 Auth   │ │ • State Machine   │ │ • WebSocket Server    │
│ • Role-Based RBAC     │ │ • SLA Timers (6h) │ │ • FCM / APNs Hub      │
│ • Biometrics Bridge   │ │ • QC Pipeline     │ │ • WhatsApp Gateway    │
└───────────┬───────────┘ └─────────┬─────────┘ └───────────┬───────────┘
            │                       │                       │
            ▼                       ▼                       ▼
┌───────────────────────────────────────────────────────────────────────┐
│                      DATA & OBJECT STORAGE LAYER                      │
│ • Primary DB: MySQL 8.0 / PostgreSQL 16 (ACID Relational Core)        │
│ • Telemetry Cache: Redis 7.2 (Real-Time Presence, Locks, Rate Limits) │
│ • Asset Store: AWS S3 / Cloudflare R2 (Pre-Signed RAW & High-Res DL) │
│ • CDN: Cloudflare Enterprise (Edge Caching for Proofing WebP/AVIF)    │
└───────────────────────────────────────────────────────────────────────┘
```

---

## 2. Technology Stack Selection

### 2.1 Mobile Application Stack (Recommended: Flutter)
| Layer | Technology | Selection Rationale |
| :--- | :--- | :--- |
| **Framework** | **Flutter 3.24+ (Dart 3.5)** | 120 FPS Impeller rendering engine; single codebase for iOS & Android with identical UI pixel fidelity; native custom shader support for real-time Before/After image comparison sliders. *(Alt: React Native with Expo SDK 51+)* |
| **State Management** | **Flutter Riverpod 2.5 / Bloc 8.1** | Unidirectional data flow, reactive state sharing, testability, and strict isolation between business logic and UI layer. |
| **Local Storage & Cache** | **Isar DB / Hive + flutter_secure_storage** | High-performance local NoSQL database for caching orders and thumbnails; iOS Keychain & Android KeyStore for encrypting JWT tokens. |
| **Networking** | **Dio 5.5 + Retrofit** | Interceptors for auto JWT token refresh, pre-signed S3 chunked uploads, and download progress streams. |
| **Real-Time Layer** | **web_socket_channel / Socket.io Client** | Sub-300ms bidirectional message delivery and typing sneak-peek sync. |
| **Push Notifications** | **Firebase Cloud Messaging (FCM) + APNs** | Unified cross-platform push notifications with background action handling. |

### 2.2 Backend & Infrastructure Stack
| Layer | Technology |
| :--- | :--- |
| **Core API** | PHP 8.3 / Node.js (Express/NestJS) REST API |
| **Relational Database** | MySQL 8.0+ / PostgreSQL 16 with InnoDB / ACID transactional safety |
| **In-Memory Cache** | Redis 7.2 (Session stores, job locking, presence telemetry) |
| **Media Processing** | ImageMagick + libvips + FFmpeg (Auto WebP 2048px MLS generation, EXIF stripping, watermarking) |
| **Cloud Object Storage** | AWS S3 / Cloudflare R2 (Multi-part upload for RAWs and 300DPI deliverable packages) |
| **Push & Webhooks** | Google Firebase Admin SDK + Apple Push Notification Service (HTTP/2 APNs) + Meta WhatsApp Cloud API |

---

## 3. Database Schema Design (Relational Core)

```
┌──────────────────┐       ┌──────────────────┐       ┌──────────────────┐
│      users       │1     *│      orders      │1     *│   deliverables   │
├──────────────────┤───────├──────────────────┤───────├──────────────────┤
│ id (PK)          │       │ id (PK)          │       │ id (PK)          │
│ email            │       │ client_id (FK)   │       │ order_id (FK)    │
│ password_hash    │       │ editor_id (FK)   │       │ photo_title      │
│ role             │       │ service_type     │       │ raw_input_url    │
│ wallet_balance   │       │ status           │       │ before_thumb_url │
│ default_preset   │       │ sla_hours (24/12)│       │ after_thumb_url  │
│ fcm_device_token │       │ sla_deadline_at  │       │ high_res_mls_url │
│ created_at       │       │ total_amount     │       │ high_res_prt_url │
└──────────────────┘       └────────┬─────────┘       │ version (v1,v2)  │
                                    │                 └──────────────────┘
                           ┌────────┴─────────┐
                          1│                 1│
                           ▼ *                ▼ *
                  ┌──────────────────┐ ┌──────────────────┐
                  │   amendments     │ │  chat_messages   │
                  ├──────────────────┤ ├──────────────────┤
                  │ id (PK)          │ │ id (PK)          │
                  │ order_id (FK)    │ │ order_id (FK)    │
                  │ deliverable_id   │ │ sender_id (FK)   │
                  │ pin_x_pct        │ │ sender_role      │
                  │ pin_y_pct        │ │ message_text     │
                  │ note_text        │ │ attachment_url   │
                  │ voice_memo_url   │ │ is_private_note  │
                  │ status           │ │ created_at       │
                  └──────────────────┘ └──────────────────┘
```

### 3.1 DDL Schema Definitions (MySQL / PostgreSQL Compatible)

```sql
-- 1. Users Table
CREATE TABLE users (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(50) NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('client', 'photo_editor', 'team_lead', 'supervisor', 'manager', 'admin', 'owner') NOT NULL DEFAULT 'client',
    company_name VARCHAR(255) NULL,
    wallet_balance DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    loyalty_credits DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    default_preferences JSON NULL,
    fcm_device_token VARCHAR(512) NULL,
    device_platform ENUM('ios', 'android', 'web') NULL,
    status ENUM('active', 'suspended', 'pending') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_role (role),
    INDEX idx_user_email (email)
);

-- 2. Orders Table
CREATE TABLE orders (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(64) NOT NULL UNIQUE,
    client_id BIGINT UNSIGNED NOT NULL,
    editor_id BIGINT UNSIGNED NULL,
    supervisor_id BIGINT UNSIGNED NULL,
    property_address VARCHAR(500) NOT NULL,
    service_type ENUM('hdr_photo_editing', 'virtual_staging', 'virtual_twilight', 'day_to_dusk', 'floor_plan', 'item_removal', 'combo_package') NOT NULL,
    photo_count INT UNSIGNED NOT NULL DEFAULT 1,
    turnaround_tier ENUM('standard_24h', 'express_12h', 'rush_6h') NOT NULL DEFAULT 'standard_24h',
    editing_preset VARCHAR(100) DEFAULT 'natural_luxury',
    raw_source_url TEXT NOT NULL,
    special_instructions TEXT NULL,
    status ENUM('submitted', 'claimed', 'in_progress', 'pending_qc', 'qc_rejected', 'ready_for_review', 'amendment_requested', 'completed', 'cancelled') NOT NULL DEFAULT 'submitted',
    sla_deadline_at DATETIME NOT NULL,
    claimed_at DATETIME NULL,
    submitted_to_qc_at DATETIME NULL,
    completed_at DATETIME NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    discount_amount DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    total_amount DECIMAL(10, 2) NOT NULL,
    payment_status ENUM('paid_wallet', 'paid_card', 'pending', 'refunded') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (client_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (editor_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_order_status (status),
    INDEX idx_order_sla (sla_deadline_at)
);

-- 3. Deliverables Table
CREATE TABLE deliverables (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id BIGINT UNSIGNED NOT NULL,
    photo_index INT UNSIGNED NOT NULL,
    photo_title VARCHAR(255) NOT NULL,
    before_image_url TEXT NOT NULL,
    after_image_url TEXT NOT NULL,
    high_res_mls_url TEXT NOT NULL,
    high_res_print_url TEXT NOT NULL,
    version INT UNSIGNED NOT NULL DEFAULT 1,
    qc_approved_by BIGINT UNSIGNED NULL,
    qc_rating INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- 4. Amendments Table
CREATE TABLE amendments (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id BIGINT UNSIGNED NOT NULL,
    deliverable_id BIGINT UNSIGNED NOT NULL,
    pin_x_percent DECIMAL(5, 2) NOT NULL,
    pin_y_percent DECIMAL(5, 2) NOT NULL,
    category_tag VARCHAR(100) DEFAULT 'general_fix',
    instruction_note TEXT NOT NULL,
    voice_memo_url TEXT NULL,
    status ENUM('pending', 'in_revision', 'resolved', 'dismissed') NOT NULL DEFAULT 'pending',
    resolved_by BIGINT UNSIGNED NULL,
    resolved_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (deliverable_id) REFERENCES deliverables(id) ON DELETE CASCADE
);

-- 5. Chat Messages Table
CREATE TABLE chat_messages (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id BIGINT UNSIGNED NULL,
    conversation_id VARCHAR(128) NOT NULL,
    sender_id BIGINT UNSIGNED NOT NULL,
    sender_role ENUM('client', 'photo_editor', 'supervisor', 'admin', 'system') NOT NULL,
    message_type ENUM('text', 'image', 'audio', 'document', 'system_event') NOT NULL DEFAULT 'text',
    message_body TEXT NOT NULL,
    attachment_url TEXT NULL,
    is_private_note BOOLEAN NOT NULL DEFAULT FALSE,
    read_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_chat_conv (conversation_id),
    INDEX idx_chat_order (order_id)
);
```

---

## 4. REST API Endpoints Specification

### 4.1 Authentication & Profile APIs
| Method | Endpoint | Description | Auth Required |
| :--- | :--- | :--- | :---: |
| `POST` | `/api/v1/auth/register` | Client registration (Name, Email, Password, Studio) | No |
| `POST` | `/api/v1/auth/login` | Login with Email/Password ➔ Returns Access JWT + Refresh Token | No |
| `POST` | `/api/v1/auth/refresh-token` | Exchange valid refresh token for new access token | No |
| `POST` | `/api/v1/auth/biometric-verify` | Verify device cryptographic biometric signature | Yes (Key) |
| `GET` | `/api/v1/user/profile` | Retrieve authenticated user profile, wallet & preferences | Yes |
| `POST` | `/api/v1/user/device-token` | Register/update FCM & APNs device push token | Yes |

### 4.2 Client Order Management APIs
| Method | Endpoint | Description | Role |
| :--- | :--- | :--- | :---: |
| `POST` | `/api/v1/orders/create` | Submit new order payload with service config & RAW URLs | Client |
| `GET` | `/api/v1/orders/list` | Fetch paginated orders with status filters | Client |
| `GET` | `/api/v1/orders/{id}` | Get full order details, SLA progress, and deliverables | Client / Team |
| `POST` | `/api/v1/orders/{id}/amendments` | File pin-point visual amendment on specific deliverable | Client |
| `POST` | `/api/v1/orders/{id}/approve` | Approve order deliverables and release 5-star rating | Client |

### 4.3 Team & Retoucher Workspace APIs
| Method | Endpoint | Description | Role |
| :--- | :--- | :--- | :---: |
| `GET` | `/api/v1/team/queue` | Fetch unassigned orders matching editor permissions | Team / Editor |
| `POST` | `/api/v1/team/orders/{id}/claim` | Atomically claim order into editor's personal queue | Editor |
| `POST` | `/api/v1/team/orders/{id}/upload` | Upload processed Before/After proofs & high-res links | Editor |
| `POST` | `/api/v1/team/orders/{id}/submit-qc` | Submit completed job to Supervisor QC queue | Editor |
| `POST` | `/api/v1/team/qc/review` | Supervisor approve or reject deliverable package | Supervisor |
| `GET` | `/api/v1/team/earnings` | Retrieve personal shift work logs & pay ledger | Editor |

### 4.4 Real-Time Chat & Telemetry APIs
| Method | Endpoint | Description | Role |
| :--- | :--- | :--- | :---: |
| `GET` | `/api/v1/chat/{conversation_id}/history`| Fetch message history with pagination | Any Authed |
| `POST` | `/api/v1/chat/send` | Send message (Text, Image, Audio Voice Memo) | Any Authed |
| `POST` | `/api/v1/chat/typing` | Emit typing preview update (300ms throttle) | Any Authed |
| `GET` | `/api/v1/chat/canned-responses` | Fetch slash command canned replies (`/pricing`, etc.) | Team / Admin |

---

## 5. Media Pipeline & Cloudflare R2 / AWS S3 Integration

```
┌──────────────┐ 1. Request Pre-Signed URL  ┌──────────────────────┐
│  Mobile App  ├───────────────────────────►│ Estate HDR API Core  │
│ (Client/Team)│◄───────────────────────────┤ (Generates S3 Token) │
└──────┬───────┘ 2. Pre-Signed PUT URL (15m)└──────────────────────┘
       │
       │ 3. Direct Multi-Part Chunked Binary Upload
       ▼
┌──────────────────────────────────────────────────────────────────┐
│            AWS S3 / Cloudflare R2 Object Storage Bucket          │
│            • RAW Brackets Folder (/raws/{order_id}/)             │
│            • High-Res Deliverables (/deliverables/{order_id}/)   │
└──────────────────────────────┬───────────────────────────────────┘
                               │
                               │ 4. S3 Event / Webhook Trigger
                               ▼
┌──────────────────────────────────────────────────────────────────┐
│                MEDIA OPTIMIZATION WORKER (libvips)               │
│ • Generates WebP 2048px (MLS compliant, quality 85)              │
│ • Generates 400px Low-Quality Image Placeholder (LQIP)           │
│ • Strips sensitive GPS/Camera metadata (preserves Color Profile) │
│ • Flushes Cloudflare Edge CDN Cache for instant proofing         │
└──────────────────────────────────────────────────────────────────┘
```

---

## 6. Push Notification Architecture (FCM + APNs)

```
┌──────────────────────────────────────────────────────────────────┐
│                   ESTATE HDR NOTIFICATION HUB                    │
└──────────────────────────────┬───────────────────────────────────┘
                               │ Dispatches Event Payload
            ┌──────────────────┴──────────────────┐
            ▼                                     ▼
┌───────────────────────┐             ┌─────────────────────────┐
│     APPLE APNs        │             │   FIREBASE FCM (v1)     │
│ (iOS Native Push)     │             │ (Android Native Push)   │
│ • Custom Sound Chimes │             │ • High Priority Channel │
│ • Rich Media Proofs   │             │ • Heads-Up Alert Popup  │
│ • Interactive Actions │             │ • Badge Count Updates   │
└───────────┬───────────┘             └────────────┬────────────┘
            │                                      │
            ▼                                      ▼
┌───────────────────────┐             ┌─────────────────────────┐
│  Client / Team iPhone │             │ Client / Team Android   │
└───────────────────────┘             └─────────────────────────┘
```

### 6.1 Sample Push Notification Payloads (FCM v1 JSON)

**Client Deliverable Ready Event:**
```json
{
  "message": {
    "token": "dK9s_f9xS0...client_fcm_token...",
    "notification": {
      "title": "✨ Your Photos are Ready!",
      "body": "142 Ocean Avenue (25 HDR Photos) has passed QC. Tap to review Before/After proofs."
    },
    "data": {
      "click_action": "FLUTTER_NOTIFICATION_CLICK",
      "type": "ORDER_READY",
      "order_id": "4812",
      "property_address": "142 Ocean Avenue",
      "thumbnail_url": "https://cdn.estatehdr.com/deliverables/4812/1-thumb.webp"
    },
    "apns": {
      "payload": {
        "aps": {
          "sound": "gold_chime.aiff",
          "badge": 1,
          "category": "DELIVERABLE_REVIEW"
        }
      }
    }
  }
}
```

**Team Rush Job Available Event:**
```json
{
  "message": {
    "token": "eX8m_v7yT1...editor_fcm_token...",
    "notification": {
      "title": "⚡ Urgent Rush Job Available (6h SLA)",
      "body": "30 Photos - Virtual Staging + HDR ($45.00 Payout). Tap to claim immediately."
    },
    "data": {
      "type": "NEW_JOB_AVAILABLE",
      "order_id": "4819",
      "urgency": "rush_6h",
      "payout_amount": "45.00"
    },
    "android": {
      "priority": "HIGH",
      "notification": {
        "channel_id": "urgent_jobs_channel",
        "sound": "rush_alert.mp3"
      }
    }
  }
}
```

---

## 7. Security, Offline Caching & CI/CD Strategy

### 7.1 Security & Compliance
- **TLS 1.3 & Certificate Pinning:** Mobile clients enforce SHA-256 certificate public key pinning against `api.estatehdr.com` to prevent Man-in-the-Middle (MitM) attacks.
- **Biometric Keychain Vault:** JWT refresh tokens are protected using `kSecAccessControlBiometryAny` on iOS and `MasterKeyProvider` on Android.
- **Rate Limiting:** IP and user-level token bucket limits (120 req/min for general API, 10 req/min for authentication).

### 7.2 Offline Cache & Synchronizer
- Mobile apps persist orders and recent chat transcripts in encrypted local storage.
- If a client drafts an amendment or sends a message while offline, actions are queued in a local FIFO SQLite synchronization queue and dispatched automatically with exponential backoff upon network restoration.

### 7.3 Automated CI/CD Pipeline
- **Continuous Integration (GitHub Actions):**
  - Linting (`flutter analyze` / `eslint`), Unit Tests (`flutter test`), and Integration Tests.
  - Automated Android `.aab` compilation signed with Google Play App Signing key.
  - Automated iOS `.ipa` compilation signed via Fastlane & Apple Developer Enterprise certificate.
- **Continuous Deployment:**
  - Automated distribution to **Apple TestFlight** (Internal Beta) and **Google Play Console Internal Track** on every merge to `main`.
