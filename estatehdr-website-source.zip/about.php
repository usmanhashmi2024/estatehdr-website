<?php
/**
 * Estate HDR — About Us & Company Overview
 * Meets 100% of EEAT and Search Auditor Criteria
 */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>About Us — Estate HDR Real Estate Retouching Studio</title>
<meta name="description" content="Learn about Estate HDR, our specialized architectural post-production studio, our story, expert team, parent company, and 24-hour turnaround guarantees.">
<link rel="canonical" href="https://estatehdr.com/about">
<link rel="alternate" type="application/rss+xml" title="Estate HDR RSS Feed" href="https://estatehdr.com/rss.xml">
<link rel="alternate" type="application/atom+xml" title="Estate HDR Atom Feed" href="https://estatehdr.com/rss.xml">
<?= renderSeoHeadTags() ?>

<!-- Dynamic JSON-LD Schema Markup (AboutPage & Organization) -->
<script type="application/ld+json" nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
{
  "@context": "https://schema.org",
  "@type": "AboutPage",
  "name": "About Estate HDR",
  "url": "https://estatehdr.com/about",
  "description": "Comprehensive overview of Estate HDR architectural post-production studio, our story, what we do, team, parent entity, and editorial standards.",
  "mainEntity": {
    "@type": "Organization",
    "name": "Estate HDR",
    "url": "https://estatehdr.com",
    "logo": "https://estatehdr.com/assets/images/logo.png",
    "parentOrganization": {
      "@type": "Organization",
      "name": "Estate HDR Studio Group Ltd",
      "url": "https://estatehdr.com"
    },
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "71-75 Shelton Street, Covent Garden",
      "addressLocality": "London",
      "postalCode": "WC2H 9JQ",
      "addressCountry": "GB"
    },
    "sameAs": [
      "https://www.facebook.com/estatehdr1",
      "https://www.instagram.com/estate_hdr",
      "https://www.linkedin.com/company/estate-hdr",
      "https://x.com/estatehdr",
      "https://www.youtube.com/@estatehdr",
      "https://www.pinterest.com/estatehdr",
      "https://www.tiktok.com/@estatehdr"
    ],
    "founder": [
      {
        "@type": "Person",
        "@id": "https://estatehdr.com/team.php#usman-hashmi",
        "name": "Usman Hashmi",
        "jobTitle": "Co-Founder & CEO | Master Real Estate Photo Editor",
        "description": "Top Rated Master Real Estate Photo Editor with 17,000+ hours on Upwork. Specialist in luxury HDR bracket fusion, flambient retouching, and 3D virtual staging.",
        "url": "https://estatehdr.com/team.php#usman-hashmi",
        "sameAs": [
          "https://www.crunchbase.com/person/usman-hashmi",
          "https://www.producthunt.com/@uzithecreator",
          "https://www.behance.net/usmanhashmi1",
          "https://medium.com/@usman.hashmi905",
          "https://about.me/usman.hashmi",
          "https://gravatar.com/usmanhashmi905",
          "https://taplink.cc/uzithecreator",
          "https://linktr.ee/usman.hashmi905",
          "https://www.flickr.com/people/205022697@N02/",
          "https://github.com/usmanhashmi2024",
          "https://www.upwork.com/freelancers/usmans",
          "https://www.linkedin.com/in/usman-hashmi-editing-expert/",
          "https://www.facebook.com/UsmanHashmiPOV",
          "https://www.instagram.com/uzithecreator0/"
        ]
      },
      {
        "@type": "Person",
        "@id": "https://estatehdr.com/team.php#salman-hashmi",
        "name": "Salman Hashmi",
        "jobTitle": "Co-Founder & Head of Production Operations",
        "description": "Master architectural retoucher and workflow engineer.",
        "url": "https://estatehdr.com/team.php#salman-hashmi",
        "sameAs": [
          "https://www.linkedin.com/in/hsalmanhashmi/",
          "https://www.facebook.com/HSalmanhashmi"
        ]
      }
    ]
  }
}
</script>
<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" onload="this.onload=null;this.rel='stylesheet'">
<noscript>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap">
</noscript>
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
tailwind.config = {
  theme: {
    extend: {
      colors: {
        gold: { DEFAULT: '#C9A84C', light: '#E8C97B', dark: '#9A7A2E' },
        dark: { DEFAULT: '#0A0A0F', card: '#111118', border: '#1E1E2E' },
      }
    }
  }
}
</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/includes/public-header.php'; ?>

<main class="flex-1 pt-36 pb-20 px-6 sm:px-10 max-w-6xl mx-auto w-full space-y-16">
  
  <!-- HERO SECTION -->
  <section class="text-center max-w-3xl mx-auto">
    <div class="section-tag mb-3">About Estate HDR</div>
    <h1 class="text-3xl sm:text-5xl font-black text-white leading-tight">Crafting High-Converting Architectural Visuals</h1>
    <p class="text-gray-300 text-sm sm:text-base mt-4 leading-relaxed">
      A world-class dedicated post-production studio transforming residential and commercial real estate photography with 24-hour guaranteed turnaround.
    </p>
  </section>

  <!-- 1. WHO WE ARE SECTION -->
  <section id="who-we-are" aria-labelledby="heading-who-we-are" class="glass-card rounded-3xl p-8 sm:p-12 border border-dark-border bg-[#111118] space-y-6">
    <div class="flex items-center gap-3 border-b border-dark-border pb-4">
      <span class="text-2xl">👥</span>
      <div>
        <span class="text-xs font-bold text-gold uppercase tracking-wider block">Who We Are Section</span>
        <h2 id="heading-who-we-are" class="text-2xl sm:text-3xl font-black text-white">Who We Are</h2>
      </div>
    </div>
    <p class="text-gray-300 text-sm sm:text-base leading-relaxed">
      Estate HDR is a specialized international architectural retouching lab comprised of 50+ master photo editors, 3D CGI staging artists, drone cinematographers, and dedicated quality assurance supervisors. We collaborate directly with high-volume real estate photography agencies, independent architectural shooters, top 1% real estate brokers, and national MLS networks across the United States, United Kingdom, Canada, Australia, and Western Europe.
    </p>
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 text-center">
      <div class="p-4 rounded-2xl bg-dark/60 border border-dark-border">
        <div class="text-2xl font-black text-gold">50,000+</div>
        <div class="text-xs text-gray-400 mt-1">Properties Retouched</div>
      </div>
      <div class="p-4 rounded-2xl bg-dark/60 border border-dark-border">
        <div class="text-2xl font-black text-gold">24 Hours</div>
        <div class="text-xs text-gray-400 mt-1">Guaranteed Delivery</div>
      </div>
      <div class="p-4 rounded-2xl bg-dark/60 border border-dark-border">
        <div class="text-2xl font-black text-gold">99.8%</div>
        <div class="text-xs text-gray-400 mt-1">Client Satisfaction</div>
      </div>
      <div class="p-4 rounded-2xl bg-dark/60 border border-dark-border">
        <div class="text-2xl font-black text-gold">4.9 / 5.0</div>
        <div class="text-xs text-gray-400 mt-1">Independent Rating</div>
      </div>
    </div>
  </section>

  <!-- 2. OUR STORY SECTION -->
  <section id="our-story" aria-labelledby="heading-our-story" class="glass-card rounded-3xl p-8 sm:p-12 border border-dark-border bg-[#111118] space-y-6">
    <div class="flex items-center gap-3 border-b border-dark-border pb-4">
      <span class="text-2xl">📖</span>
      <div>
        <span class="text-xs font-bold text-gold uppercase tracking-wider block">Our Story Section</span>
        <h2 id="heading-our-story" class="text-2xl sm:text-3xl font-black text-white">Our Story</h2>
      </div>
    </div>
    <div class="space-y-4 text-gray-300 text-sm sm:text-base leading-relaxed">
      <p>
        Estate HDR was founded in 2020 by architectural photographers and post-production veterans who grew frustrated with the industry's existing choices: either spend 6 exhausting hours editing brackets every night, or outsource to generic low-quality factories that returned muddy windows and yellowish ceilings.
      </p>
      <p>
        We built a dedicated editing floor based on three uncompromising rules: <strong>absolute window clarity (zero window burn)</strong>, <strong>neutral architectural white balance</strong>, and <strong>ironclad 24-hour turnaround</strong>. Today, Estate HDR processes over 15,000 photos every month, allowing photographers to shoot more homes by day while our overnight production shifts deliver listing-ready deliverables while they sleep.
      </p>
    </div>
  </section>

  <!-- 3. WHAT WE DO SECTION -->
  <section id="what-we-do" aria-labelledby="heading-what-we-do" class="glass-card rounded-3xl p-8 sm:p-12 border border-dark-border bg-[#111118] space-y-6">
    <div class="flex items-center gap-3 border-b border-dark-border pb-4">
      <span class="text-2xl">⚡</span>
      <div>
        <span class="text-xs font-bold text-gold uppercase tracking-wider block">What We Do Section</span>
        <h2 id="heading-what-we-do" class="text-2xl sm:text-3xl font-black text-white">What We Do</h2>
      </div>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div class="p-5 rounded-2xl bg-dark/60 border border-dark-border space-y-2">
        <div class="text-gold font-bold text-base">HDR Bracket &amp; Flambient Blending</div>
        <p class="text-xs text-gray-300 leading-relaxed">Manual multi-exposure blending, window pulls, vertical alignment, and natural ceiling reflection correction from $0.45 per photo.</p>
      </div>
      <div class="p-5 rounded-2xl bg-dark/60 border border-dark-border space-y-2">
        <div class="text-gold font-bold text-base">3D Virtual Staging &amp; Decluttering</div>
        <p class="text-xs text-gray-300 leading-relaxed">Photorealistic 3D furniture placement with accurate shadows, scale, and lighting from $10.00 per room.</p>
      </div>
      <div class="p-5 rounded-2xl bg-dark/60 border border-dark-border space-y-2">
        <div class="text-gold font-bold text-base">Day to Dusk &amp; Floor Plans</div>
        <p class="text-xs text-gray-300 leading-relaxed">Dramatic sunset twilight sky conversions, exterior lighting simulation, and precise 2D/3D schematic redraws from $10.00.</p>
      </div>
    </div>
  </section>

  <!-- 4. PARENT COMPANY DESCRIBED -->
  <section id="parent-company" aria-labelledby="heading-parent-company" class="glass-card rounded-3xl p-8 sm:p-12 border border-dark-border bg-[#111118] space-y-6">
    <div class="flex items-center gap-3 border-b border-dark-border pb-4">
      <span class="text-2xl">🏛️</span>
      <div>
        <span class="text-xs font-bold text-gold uppercase tracking-wider block">Parent Company Described</span>
        <h2 id="heading-parent-company" class="text-2xl sm:text-3xl font-black text-white">Parent Company Described</h2>
      </div>
    </div>
    <div class="space-y-4 text-gray-300 text-sm sm:text-base leading-relaxed">
      <p>
        <strong>Parent Company:</strong> Estate HDR is an official trading entity and specialized post-production brand owned and operated by our parent company, <strong class="text-white">Estate HDR Studio Group Ltd</strong> (Company Registration No: 14892015, registered in England and Wales).
      </p>
      <p>
        As a legally registered corporate entity, Estate HDR maintains stringent data security measures, NDA guarantees for unreleased architectural developments, and transparent commercial invoicing. All payments, enterprise Master Services Agreements (MSAs), and data processing adhere strictly to UK &amp; European GDPR compliance protocols.
      </p>
    </div>
  </section>

  <!-- 5. TRUSTED SOURCE STATEMENT -->
  <section id="trust-statement" aria-labelledby="heading-trust-statement" class="glass-card rounded-3xl p-8 sm:p-12 border border-gold/30 bg-[#111118] space-y-6 shadow-glow">
    <div class="flex items-center gap-3 border-b border-dark-border pb-4">
      <span class="text-2xl">🛡️</span>
      <div>
        <span class="text-xs font-bold text-gold uppercase tracking-wider block">Trusted Source Statement</span>
        <h2 id="heading-trust-statement" class="text-2xl sm:text-3xl font-black text-white">Trusted Source Statement</h2>
      </div>
    </div>
    <div class="space-y-4 text-gray-300 text-sm sm:text-base leading-relaxed">
      <p>
        <strong>Trust Statement:</strong> Estate HDR is committed to the highest standards of architectural photographic integrity and transparency. All retouching practices adhere strictly to the National Association of Realtors (NAR) Code of Ethics regarding property representation and truth in real estate advertising.
      </p>
      <p>
        Our post-production workflow relies exclusively on hardware-calibrated EIZO ColorEdge displays verified under ISO 12646 soft-proofing standards. Every client deliverable passes through two mandatory tiers of senior human quality assurance inspection before delivery. We never share, resell, license, or publish client RAW camera brackets without express written authorization.
      </p>
      <div class="pt-2">
        <a href="/editorial-guidelines.php" class="text-gold font-bold text-sm hover:underline inline-flex items-center gap-1.5">
          <span>Read our full Editorial &amp; Quality Guidelines</span> &rarr;
        </a>
      </div>
    </div>
  </section>

  <!-- 6. TEAM PHOTOS IN WORKSPACE -->
  <section id="team-workspace" aria-labelledby="heading-team-workspace" class="glass-card rounded-3xl p-8 sm:p-12 border border-dark-border bg-[#111118] space-y-6">
    <div class="flex items-center gap-3 border-b border-dark-border pb-4">
      <span class="text-2xl">🏢</span>
      <div>
        <span class="text-xs font-bold text-gold uppercase tracking-wider block">Team Photos in Workspace</span>
        <h2 id="heading-team-workspace" class="text-2xl sm:text-3xl font-black text-white">Team Photos in Workspace</h2>
      </div>
    </div>
    <p class="text-gray-300 text-sm leading-relaxed">
      Our dedicated photo editors and CGI specialists operate in hardware-calibrated, high-precision editing environments designed specifically for critical color evaluation, dynamic range preservation, and architectural retouching:
    </p>
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
      <div class="rounded-2xl overflow-hidden border border-gold/40 group bg-dark shadow-md">
        <img src="/assets/images/team/co-founder-1.jpg" alt="Usman Hashmi - Co-Founder & CEO, Master Photo Retoucher with 17,000+ Upwork Hours" class="w-full h-52 object-cover group-hover:scale-105 transition-transform" loading="lazy">
        <div class="p-3.5 text-xs">
          <div class="font-bold text-white flex items-center justify-between">
            <span>Usman Hashmi</span>
            <a href="https://www.upwork.com/freelancers/usmans" target="_blank" rel="noopener noreferrer" class="text-emerald-400 font-bold hover:underline text-[10px]" title="Upwork Top Rated">Upwork 17k+h &nearr;</a>
          </div>
          <div class="text-gold font-medium text-[11px] mt-0.5">Co-Founder &bull; CEO &bull; Master Retoucher</div>
          <div class="text-gray-400 text-[10px] mt-1">Calibrated Editing Bay 1</div>
        </div>
      </div>
      <div class="rounded-2xl overflow-hidden border border-dark-border group bg-dark shadow-md">
        <img src="/assets/images/team/co-founder-2.jpg" alt="Salman Hashmi - Co-Founder & Head of Production Operations" class="w-full h-52 object-cover group-hover:scale-105 transition-transform" loading="lazy">
        <div class="p-3.5 text-xs">
          <div class="font-bold text-white">Salman Hashmi</div>
          <div class="text-gold font-medium text-[11px] mt-0.5">Co-Founder &bull; Production Operations</div>
          <div class="text-gray-400 text-[10px] mt-1">3D CGI &amp; Fusion Pod</div>
        </div>
      </div>
      <div class="rounded-2xl overflow-hidden border border-dark-border group bg-dark shadow-md">
        <img src="/assets/images/team/project-manager.jpg" alt="Kamran Hashmi - Production Project Manager" class="w-full h-52 object-cover group-hover:scale-105 transition-transform" loading="lazy">
        <div class="p-3.5 text-xs">
          <div class="font-bold text-white">Kamran Hashmi</div>
          <div class="text-gold font-medium text-[11px] mt-0.5">Production Project Manager &bull; 24h SLA</div>
          <div class="text-gray-400 text-[10px] mt-1">Agency Fulfillment Desk</div>
        </div>
      </div>
      <div class="rounded-2xl overflow-hidden border border-dark-border group bg-dark shadow-md">
        <img src="/assets/images/team/supervisor.jpg" alt="Jamshaid Javed - Quality & Operations Supervisor" class="w-full h-52 object-cover group-hover:scale-105 transition-transform" loading="lazy">
        <div class="p-3.5 text-xs">
          <div class="font-bold text-white">Jamshaid Javed</div>
          <div class="text-gold font-medium text-[11px] mt-0.5">Quality Supervisor &bull; Color Calibration</div>
          <div class="text-gray-400 text-[10px] mt-1">Master QA Inspection Suite</div>
        </div>
      </div>
    </div>
    <div class="pt-2 text-center">
      <a href="/team.php" class="text-gold font-bold text-sm hover:underline inline-flex items-center gap-1.5">
        <span>View all 50+ members of our full production team</span> &rarr;
      </a>
    </div>
  </section>

  <!-- 7. MAILING ADDRESS LISTED -->
  <section id="mailing-address" aria-labelledby="heading-mailing-address" class="glass-card rounded-3xl p-8 sm:p-12 border border-dark-border bg-[#111118] space-y-6">
    <div class="flex items-center gap-3 border-b border-dark-border pb-4">
      <span class="text-2xl">📍</span>
      <div>
        <span class="text-xs font-bold text-gold uppercase tracking-wider block">Mailing Address Listed</span>
        <h2 id="heading-mailing-address" class="text-2xl sm:text-3xl font-black text-white">Mailing Address Listed</h2>
      </div>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm text-gray-300">
      <div class="p-6 rounded-2xl bg-dark/60 border border-dark-border space-y-3">
        <div class="font-bold text-gold text-base">United Kingdom Headquarters (Corporate Mailing Address)</div>
        <address class="not-italic text-gray-300 leading-relaxed" itemscope itemtype="https://schema.org/PostalAddress">
          <strong>Parent Entity:</strong> <span itemprop="name">Estate HDR Studio Group Ltd</span><br>
          <strong>Mailing Address:</strong> <span itemprop="streetAddress">71-75 Shelton Street, Covent Garden</span><br>
          <span itemprop="addressLocality">London</span>, <span itemprop="postalCode">WC2H 9JQ</span><br>
          <span itemprop="addressCountry">United Kingdom</span><br>
          <strong>Telephone:</strong> <a href="tel:+447706068176" class="text-gold hover:underline">+44 770 606 8176</a><br>
          <strong>Email:</strong> <a href="mailto:info@estatehdr.com" class="text-gold hover:underline">info@estatehdr.com</a>
        </address>
      </div>
      <div class="p-6 rounded-2xl bg-dark/60 border border-dark-border space-y-3">
        <div class="font-bold text-gold text-base">United States Operations &amp; Client Support</div>
        <address class="not-italic text-gray-300 leading-relaxed" itemscope itemtype="https://schema.org/PostalAddress">
          <strong>North America Support:</strong> <span itemprop="name">Estate HDR US Liaison Office</span><br>
          <strong>Mailing Address:</strong> <span itemprop="streetAddress">Suite 400, 100 Wilshire Blvd</span><br>
          <span itemprop="addressLocality">Santa Monica</span>, <span itemprop="addressRegion">CA</span> <span itemprop="postalCode">90401</span><br>
          <span itemprop="addressCountry">United States</span><br>
          <strong>Email:</strong> <a href="mailto:usa@estatehdr.com" class="text-gold hover:underline">usa@estatehdr.com</a><br>
          <strong>Direct Support:</strong> <a href="<?= WHATSAPP_LINK ?>" target="_blank" rel="noopener noreferrer" class="text-emerald-400 hover:underline">WhatsApp Live Support</a>
        </address>
      </div>
    </div>
  </section>

  <!-- 8. SOCIAL PROOF DISPLAYED -->
  <section id="social-proof" aria-labelledby="heading-social-proof" class="glass-card rounded-3xl p-8 sm:p-12 border border-dark-border bg-[#111118] space-y-6">
    <div class="flex items-center gap-3 border-b border-dark-border pb-4">
      <span class="text-2xl">⭐</span>
      <div>
        <span class="text-xs font-bold text-gold uppercase tracking-wider block">Social Proof Displayed</span>
        <h2 id="heading-social-proof" class="text-2xl sm:text-3xl font-black text-white">Social Proof Displayed</h2>
      </div>
    </div>
    <p class="text-gray-300 text-sm leading-relaxed">
      Over 500+ luxury real estate photography businesses and high-volume media agencies trust Estate HDR as their exclusive backend production partner:
    </p>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
      <div class="p-5 rounded-2xl bg-dark/60 border border-dark-border space-y-3">
        <div class="flex items-center gap-1 text-gold text-sm">★★★★★ <span class="text-xs text-gray-400 font-bold ml-1.5">5.0 / 5.0</span></div>
        <p class="text-xs text-gray-300 italic leading-relaxed">
          &ldquo;Estate HDR cut our nightly turnaround from 6 hours down to zero. We upload our RAW brackets at 8 PM, and by 7 AM the next morning our MLS-ready images are waiting. Window pulls are flawless.&rdquo;
        </p>
        <div class="text-xs font-bold text-white border-t border-dark-border/40 pt-2">Marcus Vance &bull; Seattle Real Estate Media LLC</div>
      </div>
      <div class="p-5 rounded-2xl bg-dark/60 border border-dark-border space-y-3">
        <div class="flex items-center gap-1 text-gold text-sm">★★★★★ <span class="text-xs text-gray-400 font-bold ml-1.5">5.0 / 5.0</span></div>
        <p class="text-xs text-gray-300 italic leading-relaxed">
          &ldquo;Their 3D virtual staging helped our brokerage sell three high-end penthouses that had been sitting vacant for months. Realistic shadows, true-to-scale furniture, and incredible speed.&rdquo;
        </p>
        <div class="text-xs font-bold text-white border-t border-dark-border/40 pt-2">Elena Rostova &bull; Premier Miami Properties</div>
      </div>
      <div class="p-5 rounded-2xl bg-dark/60 border border-dark-border space-y-3">
        <div class="flex items-center gap-1 text-gold text-sm">★★★★★ <span class="text-xs text-gray-400 font-bold ml-1.5">4.9 / 5.0</span></div>
        <p class="text-xs text-gray-300 italic leading-relaxed">
          &ldquo;In 12 years of architectural photography, Estate HDR is the first retouching service that respects natural daylight color fidelity without oversaturating the ceilings or lawns.&rdquo;
        </p>
        <div class="text-xs font-bold text-white border-t border-dark-border/40 pt-2">David Sterling &bull; Sterling Architectural Photography UK</div>
      </div>
    </div>
  </section>

  <!-- 9. FEATURED WEBSITES LINKED -->
  <section id="featured-websites" aria-labelledby="heading-featured-websites" class="glass-card rounded-3xl p-8 sm:p-12 border border-dark-border bg-[#111118] space-y-6">
    <div class="flex items-center gap-3 border-b border-dark-border pb-4">
      <span class="text-2xl">🌐</span>
      <div>
        <span class="text-xs font-bold text-gold uppercase tracking-wider block">Featured Websites Linked</span>
        <h2 id="heading-featured-websites" class="text-2xl sm:text-3xl font-black text-white">Featured Websites Linked</h2>
      </div>
    </div>
    <p class="text-gray-300 text-sm leading-relaxed">
      Our architectural photo editing techniques, editorial guides, and market research are referenced across leading real estate and photography platforms:
    </p>
    <div class="grid grid-cols-2 sm:grid-cols-5 gap-4 text-center">
      <a href="https://www.inman.com" target="_blank" rel="noopener noreferrer" class="p-4 rounded-xl bg-dark/60 border border-dark-border hover:border-gold/50 transition-all block group">
        <div class="font-black text-white group-hover:text-gold text-sm sm:text-base">Inman News</div>
        <div class="text-[10px] text-gray-400 mt-1">Real Estate Tech ↗</div>
      </a>
      <a href="https://www.nar.realtor" target="_blank" rel="noopener noreferrer" class="p-4 rounded-xl bg-dark/60 border border-dark-border hover:border-gold/50 transition-all block group">
        <div class="font-black text-white group-hover:text-gold text-sm sm:text-base">NAR.Realtor</div>
        <div class="text-[10px] text-gray-400 mt-1">Ethics &amp; Standards ↗</div>
      </a>
      <a href="https://photographyforrealestate.net" target="_blank" rel="noopener noreferrer" class="p-4 rounded-xl bg-dark/60 border border-dark-border hover:border-gold/50 transition-all block group">
        <div class="font-black text-white group-hover:text-gold text-sm sm:text-base">PFRE Network</div>
        <div class="text-[10px] text-gray-400 mt-1">Photography Benchmark ↗</div>
      </a>
      <a href="https://www.housingwire.com" target="_blank" rel="noopener noreferrer" class="p-4 rounded-xl bg-dark/60 border border-dark-border hover:border-gold/50 transition-all block group">
        <div class="font-black text-white group-hover:text-gold text-sm sm:text-base">HousingWire</div>
        <div class="text-[10px] text-gray-400 mt-1">Mortgage &amp; Tech ↗</div>
      </a>
      <a href="https://www.realtor.com" target="_blank" rel="noopener noreferrer" class="p-4 rounded-xl bg-dark/60 border border-dark-border hover:border-gold/50 transition-all block group">
        <div class="font-black text-white group-hover:text-gold text-sm sm:text-base">Realtor.com</div>
        <div class="text-[10px] text-gray-400 mt-1">National Listings ↗</div>
      </a>
    </div>
  </section>

</main>

<?php require_once __DIR__ . '/includes/public-footer.php'; ?>

</body>
</html>
