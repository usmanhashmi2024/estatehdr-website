<?php
/**
 * Estate HDR — Dedicated High-Converting Service Landing Page Engine
 * URL: /services/{slug} (e.g. /services/hdr-photo-editing)
 */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';

$slug = trim($_GET['slug'] ?? '');
$service = getServiceBySlug($slug);

if (!$service) {
    // If not found, redirect to main services section or 404
    header('Location: /#services');
    exit;
}

$pageTitle = htmlspecialchars($service['meta_title']);
$pageDesc  = htmlspecialchars($service['meta_description']);
$canonUrl  = BASE_URL . '/services/' . urlencode($service['slug']);
$ogImage   = BASE_URL . ($service['hero_image'] ?? '/assets/images/portfolio/hdr/1-after.jpg');

// Prepare FAQ Schema
$faqSchema = [];
if (!empty($service['faqs'])) {
    $mainEntities = [];
    foreach ($service['faqs'] as $faq) {
        $mainEntities[] = [
            '@type' => 'Question',
            'name'  => $faq['question'],
            'acceptedAnswer' => [
                '@type' => 'Answer',
                'text'  => $faq['answer']
            ]
        ];
    }
    $faqSchema = [
        '@context'   => 'https://schema.org',
        '@type'      => 'FAQPage',
        'mainEntity' => $mainEntities
    ];
}

// Prepare Product / Service Schema compliant with Google Review Snippets Rich Results
$cleanPrice = preg_replace('/[^0-9.]/', '', $service['starting_price'] ?? '1.00');
$serviceImg = !empty($service['hero_image']) ? (str_starts_with($service['hero_image'], 'http') ? $service['hero_image'] : (BASE_URL . $service['hero_image'])) : (BASE_URL . '/assets/images/portfolio/hdr/1-after.jpg');

$serviceSchema = [
    '@context'    => 'https://schema.org',
    '@type'       => 'Product',
    'name'        => $service['name'] . ' Services',
    'image'       => $serviceImg,
    'description' => $service['meta_description'],
    'brand'       => [
        '@type' => 'Brand',
        'name'  => 'Estate HDR'
    ],
    'offers'      => [
        '@type'         => 'Offer',
        'price'         => !empty($cleanPrice) ? $cleanPrice : '1.00',
        'priceCurrency' => 'USD',
        'availability'  => 'https://schema.org/InStock',
        'url'           => $canonUrl
    ],
    'aggregateRating' => [
        '@type'       => 'AggregateRating',
        'ratingValue' => (string)($service['rating'] ?? '4.98'),
        'reviewCount' => (string)($service['review_count'] ?? '250'),
        'bestRating'  => '5',
        'worstRating' => '1'
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<meta name="description" content="<?= $pageDesc ?>">
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?= $canonUrl ?>">

<!-- Open Graph / Social -->
<meta property="og:type"        content="website">
<meta property="og:url"         content="<?= $canonUrl ?>">
<meta property="og:title"       content="<?= $pageTitle ?>">
<meta property="og:description" content="<?= $pageDesc ?>">
<meta property="og:image"       content="<?= $ogImage ?>">
<meta name="twitter:card"        content="summary_large_image">
<meta name="twitter:title"       content="<?= $pageTitle ?>">
<meta name="twitter:description" content="<?= $pageDesc ?>">
<meta name="twitter:image"       content="<?= $ogImage ?>">

<!-- Favicon -->
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">

<!-- Structured Data Schemas -->
<script type="application/ld+json" nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
<?= json_encode($serviceSchema, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) ?>
</script>
<?php if (!empty($faqSchema)): ?>
<script type="application/ld+json" nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
<?= json_encode($faqSchema, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) ?>
</script>
<?php endif; ?>

<!-- Tailwind & Fonts -->
<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap" onload="this.onload=null;this.rel='stylesheet'">
<noscript>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap">
</noscript>
<link rel="stylesheet" href="/assets/css/bundle.css?v=<?= file_exists(ROOT_PATH . '/assets/css/bundle.css') ? filemtime(ROOT_PATH . '/assets/css/bundle.css') : time() ?>">
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col overflow-x-hidden">

<?php require_once __DIR__ . '/includes/public-header.php'; ?>

<!-- ── HERO & BREADCRUMBS ──────────────────────────────────────── -->
<header class="pt-36 pb-16 px-6 bg-gradient-to-b from-dark-card/80 via-dark to-dark border-b border-dark-border/40 relative">
  <div class="max-w-7xl mx-auto">
    <!-- Breadcrumbs -->
    <nav class="flex items-center gap-2 text-xs text-gray-400 font-mono mb-8" aria-label="Breadcrumb">
      <a href="/" class="hover:text-gold transition-colors">Home</a>
      <span>/</span>
      <a href="/#services" class="hover:text-gold transition-colors">Services</a>
      <span>/</span>
      <span class="text-gold font-bold"><?= htmlspecialchars($service['name']) ?></span>
    </nav>

    <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
      <!-- Left Hero Text -->
      <div class="lg:col-span-7 space-y-6">
        <div class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-gold/40 bg-gold/10 text-gold text-xs font-black uppercase tracking-widest shadow-glow">
          <span><?= $service['icon'] ?></span>
          <span>Official Real Estate Retouching Service</span>
        </div>

        <h1 class="text-4xl sm:text-5xl lg:text-6xl font-black text-white leading-[1.1] tracking-tight">
          <?= htmlspecialchars($service['name']) ?>
        </h1>

        <p class="text-xl sm:text-2xl text-gold font-medium leading-snug">
          <?= htmlspecialchars($service['tagline']) ?>
        </p>

        <p class="text-base sm:text-lg text-gray-300 leading-relaxed max-w-2xl">
          <?= autoLinkKeywords(htmlspecialchars($service['overview']), $canonUrl) ?>
        </p>

        <!-- Value Stats Pills -->
        <div class="flex flex-wrap items-center gap-4 pt-2">
          <div class="px-4 py-2.5 rounded-xl bg-dark-card border border-dark-border flex items-center gap-3">
            <span class="text-gold text-xl">⚡</span>
            <div>
              <div class="text-[10px] text-gray-400 uppercase tracking-widest">Turnaround</div>
              <div class="text-sm font-bold text-white"><?= htmlspecialchars($service['turnaround']) ?></div>
            </div>
          </div>

          <div class="px-4 py-2.5 rounded-xl bg-dark-card border border-dark-border flex items-center gap-3">
            <span class="text-gold text-xl">💎</span>
            <div>
              <div class="text-[10px] text-gray-400 uppercase tracking-widest">Starting Price</div>
              <div class="text-sm font-black text-gold"><?= htmlspecialchars($service['starting_price']) ?> <span class="text-xs text-gray-400 font-normal"><?= htmlspecialchars($service['price_unit']) ?></span></div>
            </div>
          </div>

          <div class="px-4 py-2.5 rounded-xl bg-dark-card border border-dark-border flex items-center gap-3">
            <span class="text-amber-400 text-xl">★</span>
            <div>
              <div class="text-[10px] text-gray-400 uppercase tracking-widest">Rating</div>
              <div class="text-sm font-bold text-white"><?= $service['rating'] ?>/5.0 <span class="text-xs text-gray-400 font-normal">(<?= $service['review_count'] ?>+ Reviews)</span></div>
            </div>
          </div>
        </div>

        <!-- Action CTAs -->
        <div class="flex flex-col sm:flex-row gap-4 pt-4">
          <a href="/register.php" class="btn-gold text-base px-8 py-4 shadow-glow inline-flex items-center justify-center gap-2">
            Start Free Trial Order &rarr;
          </a>
          <a href="/login.php" class="btn-ghost text-base px-8 py-4 inline-flex items-center justify-center gap-2">
            Client Portal Sign In
          </a>
        </div>
      </div>

      <!-- Right: Interactive Before/After Comparison Demo -->
      <div class="lg:col-span-5">
        <div class="relative rounded-3xl overflow-hidden aspect-[4/3] glass-card border border-gold/30 shadow-2xl cursor-ew-resize select-none" data-ba>
          <!-- Before Layer -->
          <div class="ba-before absolute inset-0 flex items-center justify-center bg-dark">
            <img loading="lazy" decoding="async" src="<?= htmlspecialchars($service['before_image']) ?>" alt="<?= htmlspecialchars($service['name']) ?> Before" class="w-full h-full object-cover pointer-events-none">
          </div>

          <!-- After Layer -->
          <div class="ba-after absolute inset-0 flex items-center justify-center bg-dark" style="clip-path: inset(0 50% 0 0)">
            <img loading="lazy" decoding="async" src="<?= htmlspecialchars($service['after_image']) ?>" alt="<?= htmlspecialchars($service['name']) ?> After" class="w-full h-full object-cover pointer-events-none">
          </div>

          <!-- Divider Handle -->
          <div class="ba-divider absolute inset-y-0 flex items-center" style="left:50%">
            <div class="w-0.5 h-full bg-white shadow-xl"></div>
            <div class="absolute w-8 h-8 rounded-full bg-white shadow-2xl flex items-center justify-center -translate-x-1/2 border border-dark/10">
              <svg class="w-3.5 h-3.5 text-dark" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M8 9l-4 3 4 3M16 9l4 3-4 3"/>
              </svg>
            </div>
          </div>

          <!-- Badges -->
          <div class="absolute top-3 left-3 px-2.5 py-1 bg-black/80 backdrop-blur-md rounded text-xs font-black text-gray-300 pointer-events-none uppercase tracking-wider">
            BEFORE
          </div>
          <div class="absolute top-3 right-3 px-2.5 py-1 bg-gold/90 backdrop-blur-md rounded text-xs font-black text-dark pointer-events-none uppercase tracking-wider">
            AFTER
          </div>
          <div class="absolute bottom-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-black/80 backdrop-blur-md rounded-full text-[11px] font-bold text-gray-300 pointer-events-none shadow-md">
            ↔ Drag Slider to Compare
          </div>
        </div>
      </div>
    </div>
  </div>
</header>

<!-- ── DETAILED FEATURES & CAPABILITIES ──────────────────────── -->
<section class="py-24 px-6 relative bg-dark">
  <div class="max-w-7xl mx-auto">
    <div class="text-center max-w-3xl mx-auto mb-16">
      <div class="inline-flex items-center gap-2 px-3.5 py-1 rounded-full border border-gold/30 bg-gold/5 text-gold text-xs font-bold uppercase tracking-wider mb-4">
        Professional Precision
      </div>
      <h2 class="text-3xl sm:text-4xl font-bold text-white">
        What's Included with <span class="text-gold"><?= htmlspecialchars($service['name']) ?></span>
      </h2>
      <p class="text-gray-400 text-sm sm:text-base mt-3">
        Every edit is reviewed through our rigorous 3-tier Quality Assurance pipeline before client delivery.
      </p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <?php foreach ($service['key_features'] as $idx => $feat): ?>
      <div class="glass-card p-6 rounded-2xl border border-dark-border hover:border-gold/40 transition-all flex flex-col justify-between space-y-4 group">
        <div class="flex items-center gap-3">
          <div class="w-8 h-8 rounded-xl bg-gold/10 text-gold flex items-center justify-center font-bold text-xs border border-gold/20 group-hover:bg-gold group-hover:text-dark transition-colors">
            ✓
          </div>
          <span class="text-xs font-mono text-gray-500 uppercase tracking-widest">Feature <?= $idx + 1 ?></span>
        </div>
        <p class="text-sm font-semibold text-white leading-relaxed">
          <?= htmlspecialchars($feat) ?>
        </p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ── TECHNICAL SPECIFICATIONS & CAMERA SETTINGS ────────────── -->
<?php if (!empty($service['tech_specs'])): ?>
<section class="py-16 px-6 bg-dark-card/50 border-y border-dark-border/40">
  <div class="max-w-4xl mx-auto">
    <div class="text-center mb-10">
      <h3 class="text-2xl font-bold text-white">Technical Specifications &amp; File Compatibility</h3>
      <p class="text-xs text-gray-400 mt-1">Engineered to integrate seamlessly with your existing photography shoot workflow.</p>
    </div>

    <div class="glass-card rounded-2xl overflow-hidden border border-dark-border">
      <table class="w-full text-left text-xs sm:text-sm">
        <tbody class="divide-y divide-dark-border">
          <?php foreach ($service['tech_specs'] as $spec): ?>
          <tr class="hover:bg-white/[0.02] transition-colors">
            <td class="py-4 px-6 font-bold text-gray-400 w-1/3 bg-dark/40"><?= htmlspecialchars($spec['label']) ?></td>
            <td class="py-4 px-6 font-mono font-semibold text-gold"><?= htmlspecialchars($spec['value']) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ── SERVICE FAQS ─────────────────────────────────────────── -->
<?php if (!empty($service['faqs'])): ?>
<section class="py-24 px-6 max-w-4xl mx-auto">
  <div class="text-center mb-14">
    <div class="inline-flex items-center gap-2 px-3.5 py-1 rounded-full border border-gold/30 bg-gold/5 text-gold text-xs font-bold uppercase tracking-wider mb-4">
      Frequently Asked Questions
    </div>
    <h2 class="text-3xl font-bold text-white">Questions About <?= htmlspecialchars($service['name']) ?></h2>
    <p class="text-gray-400 text-sm mt-2">Find quick answers to common camera bracket setups and retouching workflows.</p>
  </div>

  <div class="space-y-4">
    <?php foreach ($service['faqs'] as $idx => $faq): ?>
    <div class="glass-card rounded-2xl border border-dark-border overflow-hidden">
      <button onclick="toggleFaq(this)" class="w-full text-left p-6 flex items-center justify-between gap-4 font-bold text-base text-white hover:text-gold transition-colors">
        <span><?= htmlspecialchars($faq['question']) ?></span>
        <svg class="faq-icon w-5 h-5 text-gold flex-shrink-0 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
        </svg>
      </button>
      <div class="faq-answer hidden px-6 pb-6 text-sm text-gray-300 leading-relaxed border-t border-dark-border/40 pt-4">
        <?= htmlspecialchars($faq['answer']) ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<!-- ── BOTTOM CONVERSION BANNER ──────────────────────────────── -->
<section class="py-20 px-6 bg-gradient-to-t from-gold/10 via-dark-card to-dark border-t border-gold/20 text-center">
  <div class="max-w-3xl mx-auto space-y-6">
    <h2 class="text-3xl sm:text-5xl font-black text-white">
      Ready for Flawless <span class="text-gold"><?= htmlspecialchars($service['name']) ?></span>?
    </h2>
    <p class="text-gray-300 text-base sm:text-lg">
      Join hundreds of real estate photographers and agencies who trust Estate HDR for overnight 24-hour turnaround.
    </p>
    <div class="flex flex-col sm:flex-row gap-4 justify-center pt-4">
      <a href="/register.php" class="btn-gold text-base px-10 py-4 shadow-glow inline-flex items-center justify-center gap-2">
        Start Free Trial Order &rarr;
      </a>
      <a href="/#pricing" class="btn-ghost text-base px-8 py-4">
        View All Pricing Plans
      </a>
    </div>
  </div>
</section>

<!-- Footer -->
<footer class="py-12 border-t border-dark-border/60 bg-dark text-center text-xs text-gray-500 font-mono space-y-3">
  <div class="flex items-center justify-center gap-6 text-sm text-gray-400 flex-wrap">
    <a href="<?= FACEBOOK_LINK ?>" target="_blank" class="hover:text-blue-400 transition-colors" rel="noopener noreferrer">Facebook</a>
    <a href="<?= INSTAGRAM_LINK ?>" target="_blank" class="hover:text-pink-400 transition-colors" rel="noopener noreferrer">Instagram</a>
    <a href="<?= LINKEDIN_LINK ?>" target="_blank" class="hover:text-blue-300 transition-colors" rel="noopener noreferrer">LinkedIn</a>
    <a href="<?= WHATSAPP_LINK ?>" target="_blank" class="hover:text-emerald-400 transition-colors" rel="noopener noreferrer">WhatsApp</a>
    <a href="/terms" class="hover:text-gold transition-colors">Terms</a>
    <a href="/privacy" class="hover:text-gold transition-colors">Privacy</a>
    <a href="/sitemap.xml" class="hover:text-gold transition-colors">Sitemap.xml</a>
    <a href="/contact" class="hover:text-gold transition-colors">Contact</a>
  </div>
  <p>&copy; <?= date('Y') ?> Estate HDR. All Rights Reserved. Master Real Estate Retouching &amp; 3D Staging Solutions.</p>
</footer>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
// Before/After interactive slider
document.querySelectorAll('[data-ba]').forEach(container => {
  const after   = container.querySelector('.ba-after');
  const divider = container.querySelector('.ba-divider');
  let dragging  = false;
  const move = (x) => {
    const rect = container.getBoundingClientRect();
    if (rect.width === 0) return;
    const pct  = Math.min(Math.max(((x - rect.left) / rect.width) * 100, 0), 100);
    divider.style.left = pct + '%';
    after.style.clipPath = `inset(0 ${100 - pct}% 0 0)`;
  };
  divider.addEventListener('mousedown',  (e) => { e.preventDefault(); dragging = true; });
  divider.addEventListener('touchstart', () => { dragging = true; }, {passive: true});
  window.addEventListener('mouseup',   () => { dragging = false; });
  window.addEventListener('touchend',  () => { dragging = false; });
  window.addEventListener('mousemove', e => { if (dragging) move(e.clientX); });
  window.addEventListener('touchmove', e => { if (dragging) move(e.touches[0].clientX); }, {passive:true});
});

// FAQ toggle
function toggleFaq(btn) {
  const answer = btn.nextElementSibling;
  const icon   = btn.querySelector('.faq-icon');
  const isOpen = !answer.classList.contains('hidden');
  document.querySelectorAll('.faq-answer').forEach(a => a.classList.add('hidden'));
  document.querySelectorAll('.faq-icon').forEach(i => i.style.transform = '');
  if (!isOpen) {
    answer.classList.remove('hidden');
    if (icon) icon.style.transform = 'rotate(180deg)';
  }
}
</script>
<?php require_once __DIR__ . '/includes/chat-widgets.php'; ?>
</body>
</html>