<?php
/**
 * Estate HDR — Dynamic XML Sitemap Index Generator
 * Outputs valid XML Sitemap Index containing sub-sitemaps for Pages, Services, Posts, and Images
 */
require_once __DIR__ . '/includes/config.php';

header('Content-Type: application/xml; charset=utf-8');
header('Cache-Control: public, max-age=3600');

$now = date('Y-m-d\TH:i:s+00:00');
echo '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;
?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <sitemap>
        <loc><?= BASE_URL ?>/sitemap-pages.xml</loc>
        <lastmod><?= $now ?></lastmod>
    </sitemap>
    <sitemap>
        <loc><?= BASE_URL ?>/sitemap-services.xml</loc>
        <lastmod><?= $now ?></lastmod>
    </sitemap>
    <sitemap>
        <loc><?= BASE_URL ?>/sitemap-posts.xml</loc>
        <lastmod><?= $now ?></lastmod>
    </sitemap>
    <sitemap>
        <loc><?= BASE_URL ?>/sitemap-images.xml</loc>
        <lastmod><?= $now ?></lastmod>
    </sitemap>
</sitemapindex>
