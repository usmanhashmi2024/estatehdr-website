<?php
/**
 * Estate HDR — Candidate Digital Signing Portal (Offer Letters & Role-Specific NDAs)
 * Allows hired candidates and external contractors to review terms, compensation, and execute legally binding signatures.
 */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/saas-db.php';
require_once __DIR__ . '/includes/mail.php';

$token = trim($_GET['token'] ?? '');
if (empty($token)) {
    http_response_code(404);
    echo '<div style="font-family:sans-serif; text-align:center; padding:50px;"><h2>Invalid Access Token</h2><p>Please use the personalized signing link sent to your email.</p></div>';
    exit;
}

$contract = getHRContractByToken($token);
if (!$contract) {
    http_response_code(404);
    echo '<div style="font-family:sans-serif; text-align:center; padding:50px;"><h2>Document Not Found</h2><p>This signing link is invalid or has expired. Please contact hr@estatehdr.com for assistance.</p></div>';
    exit;
}

$error = '';
$success = '';

// Handle Digital Signature Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_sign_contract'])) {
    if (($contract['status'] ?? '') === 'signed') {
        $error = 'This document has already been digitally executed.';
    } else {
        $signerName = trim($_POST['signer_name'] ?? '');
        $signerCnic = trim($_POST['signer_cnic'] ?? '');
        $sigData    = trim($_POST['signature_data'] ?? '');
        $termsAgreed= isset($_POST['terms_agreed']);

        if (empty($signerName)) {
            $error = 'Please enter your full legal name to execute the signature.';
        } elseif (!$termsAgreed) {
            $error = 'You must confirm that you have read and accepted the contract terms.';
        } elseif (empty($sigData)) {
            $error = 'Please provide your digital signature using the signature pad or type signature field.';
        } else {
            $contract['status']            = 'signed';
            $contract['signed_at']         = date('c');
            $contract['signed_at_formatted']= date('F j, Y \a\t g:i A T');
            $contract['signer_name']       = $signerName;
            $contract['signer_cnic']       = $signerCnic;
            $contract['signature_data']    = $sigData;
            $contract['signer_ip']         = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
            $contract['signer_user_agent'] = $_SERVER['HTTP_USER_AGENT'] ?? 'Web';

            // Save dedicated signed file per user/contract and update index
            saveHRSignedDocument($contract);

            // Send notification to HR and candidate
            sendHRSignedNotificationEmail($contract);

            $success = 'Thank you! Your agreement has been successfully signed and recorded with Estate HDR.';
        }
    }
}

$isSigned      = ($contract['status'] ?? '') === 'signed';
$candidateName = htmlspecialchars($contract['candidate_name'] ?? '');
$candidateEmail= htmlspecialchars($contract['candidate_email'] ?? '');
$candidatePhone= htmlspecialchars($contract['candidate_phone'] ?? '');
$role          = htmlspecialchars($contract['role'] ?? 'Photo Editor');
$dept          = htmlspecialchars($contract['department'] ?? 'Production');
$shift         = htmlspecialchars($contract['shift'] ?? 'Standard Production Shift');
$joiningDate   = htmlspecialchars($contract['joining_date'] ?? date('F j, Y'));
$probation     = htmlspecialchars($contract['probation_period'] ?? '3 Months');
$currency      = htmlspecialchars($contract['currency'] ?? 'USD ($)');
$totalSalary   = number_format((float)($contract['total_salary'] ?? 0), 2);
$compType      = htmlspecialchars($contract['compensation_type'] ?? 'Monthly Salary');
$docType       = $contract['doc_type'] ?? 'offer_and_nda';

// Role-specific clauses
$ndaData = function_exists('getRoleSpecificNDAClauses') ? getRoleSpecificNDAClauses($contract['role'] ?? '') : [];
$roleDuties = $contract['role_duties'] ?? ($ndaData['duties'] ?? 'Carry out professional duties in line with Estate HDR SOPs.');
$roleClauses = !empty($contract['custom_clauses']) ? $contract['custom_clauses'] : ($ndaData['clauses'] ?? []);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($contract['candidate_name']) ?> — Official <?= ($docType === 'nda' ? 'NDA' : 'Offer Letter') ?> — Estate HDR</title>
<link rel="icon" type="image/png" href="/assets/images/favicon.png">
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<style nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
  body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; background-color: #0c0d14; color: #111827; }
  .doc-sheet {
    background: #ffffff;
    width: 100%;
    max-width: 860px;
    margin: 24px auto;
    border-radius: 16px;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
    padding: 45px 55px;
    position: relative;
    overflow: hidden;
  }
  .doc-watermark {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%) rotate(-25deg);
    opacity: 0.07;
    pointer-events: none;
    z-index: 1;
    width: 550px;
    text-align: center;
    user-select: none;
  }
  .doc-content { position: relative; z-index: 10; }
  .script-font { font-family: 'Dancing Script', cursive; }
  @media print {
    body { background: #ffffff !important; margin: 0 !important; padding: 0 !important; font-size: 10pt !important; }
    .no-print { display: none !important; }
    .doc-sheet { box-shadow: none !important; border: none !important; margin: 0 !important; padding: 6mm 10mm !important; max-width: 100% !important; border-radius: 0 !important; }
    .doc-watermark { opacity: 0.08 !important; display: flex !important; }
    @page { size: A4 portrait; margin: 6mm 10mm; }
  }
</style>
</head>
<body class="min-h-screen py-6 px-4">

<!-- Top Action Header (No Print) -->
<div class="no-print max-w-[860px] mx-auto mb-6 flex flex-wrap items-center justify-between gap-4 bg-[#161622] p-4 rounded-2xl border border-[#242438] text-white shadow-xl">
  <div class="flex items-center gap-3">
    <span class="text-xs font-bold text-gray-400">Estate HDR HR Portal</span>
    <span class="text-gray-600">•</span>
    <span class="text-xs font-bold text-gray-300">Contract Ref: <span class="font-mono text-amber-400 font-bold"><?= htmlspecialchars($contract['id']) ?></span></span>
  </div>
  <div class="flex items-center gap-3">
    <button type="button" onclick="window.print()" class="px-4 py-2 rounded-xl bg-gray-800 hover:bg-gray-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all">
      <span>🖨️</span> <span>Print / Save Copy</span>
    </button>
    <?php if ($isSigned): ?>
      <span class="px-4 py-2 rounded-xl bg-emerald-600/30 text-emerald-400 border border-emerald-500/40 text-xs font-bold flex items-center gap-1.5">
        <span>✓</span> <span>Signed &amp; Verified</span>
      </span>
    <?php else: ?>
      <a href="#signingBlock" class="px-5 py-2 rounded-xl bg-[#C9A84C] hover:bg-amber-400 text-black font-black text-xs flex items-center gap-1.5 transition-all shadow-lg">
        <span>✍️</span> <span>Proceed to Sign</span>
      </a>
    <?php endif; ?>
  </div>
</div>

<?php if ($success): ?>
<div class="max-w-[860px] mx-auto mb-6 p-4 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-sm font-bold text-center flex items-center justify-center gap-2">
  <span>✓</span> <span><?= htmlspecialchars($success) ?></span>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="max-w-[860px] mx-auto mb-6 p-4 rounded-2xl bg-red-500/20 border border-red-500/40 text-red-300 text-sm font-bold text-center flex items-center justify-center gap-2">
  <span>⚠️</span> <span><?= htmlspecialchars($error) ?></span>
</div>
<?php endif; ?>

<!-- ── OFFICIAL CORPORATE DOCUMENT SHEET ───────────────────────────── -->
<div class="doc-sheet">

  <!-- 15% Watermark -->
  <div class="doc-watermark flex flex-col items-center justify-center">
    <img src="/assets/images/Black.png" alt="Estate HDR" class="w-64 h-auto object-contain mx-auto mb-2 opacity-90" onerror="this.style.display='none'">
    <div class="text-xs font-mono tracking-widest text-black font-black uppercase">Official Verified Corporate Document</div>
  </div>

  <div class="doc-content space-y-7">
    
    <!-- ── 1. CORPORATE LETTERHEAD HEADER ──────────────────────────── -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b-2 border-[#C9A84C] pb-6">
      <div>
        <div class="flex items-center gap-3">
          <img src="/assets/images/Black.png" alt="Estate HDR" class="h-9 sm:h-10 w-auto max-w-[190px] object-contain" onerror="this.outerHTML='<span class=\'font-black text-xl text-gray-900\'>Estate <span class=\'text-[#C9A84C]\'>HDR</span></span>'">
          <span class="text-[10px] uppercase font-black tracking-widest px-2.5 py-1 rounded bg-amber-100 text-amber-900 border border-amber-300">
            Human Resources &amp; Legal Operations
          </span>
        </div>
        <p class="text-[11px] text-gray-800 font-mono font-bold mt-1">Premium Real Estate Photo Retouching &amp; Virtual Media SaaS</p>
        <p class="text-[10px] text-gray-500 font-mono">UK Reg: EH-789021 • London &bull; Worldwide Delivery Hubs</p>
      </div>

      <div class="text-right text-[11px] font-mono text-gray-600 space-y-0.5">
        <div class="font-bold text-gray-900"><?= htmlspecialchars($contract['id']) ?></div>
        <div>Date: <strong class="text-gray-900"><?= htmlspecialchars($contract['date'] ?? date('F j, Y')) ?></strong></div>
        <div>HR Desk: <span class="text-gray-900">hr@estatehdr.com</span></div>
        <div>Portal: <span class="text-gray-900">www.estatehdr.com</span></div>
      </div>
    </div>

    <!-- ── 2. DOCUMENT TITLE ──────────────────────────────────────── -->
    <div class="text-center space-y-1">
      <h2 class="text-xl font-black tracking-wide text-gray-900 uppercase">
        <?php if ($docType === 'offer_letter'): ?>
          OFFICIAL EMPLOYMENT APPOINTMENT &amp; OFFER LETTER
        <?php elseif ($docType === 'nda'): ?>
          CONFIDENTIALITY &amp; NON-DISCLOSURE AGREEMENT (NDA)
        <?php else: ?>
          APPOINTMENT OFFER LETTER &amp; NON-DISCLOSURE AGREEMENT
        <?php endif; ?>
      </h2>
      <p class="text-xs font-mono text-gray-600">
        Designation: <strong class="text-gray-900 font-bold"><?= $role ?></strong>
        &bull; Department: <strong><?= $dept ?></strong>
        &bull; Effective Date: <strong><?= $joiningDate ?></strong>
      </p>
    </div>

    <!-- ── 3. CANDIDATE & APPOINTEE DETAILS GRID ──────────────────── -->
    <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-gray-50 border border-gray-200 text-xs font-mono">
      <div><span class="text-gray-500 block">Candidate Name:</span><strong class="text-gray-900"><?= $candidateName ?></strong></div>
      <div><span class="text-gray-500 block">Email Address:</span><strong class="text-gray-900"><?= $candidateEmail ?></strong></div>
      <div><span class="text-gray-500 block">Contact Phone:</span><strong class="text-gray-900"><?= $candidatePhone ?: '+44 770 606 8176' ?></strong></div>
      <div><span class="text-gray-500 block">National ID / Passport:</span><strong class="text-gray-900"><?= htmlspecialchars($contract['candidate_id_number'] ?? 'Verified') ?></strong></div>
    </div>

    <!-- ── 4. OFFER & TERMS SECTION ────────────────────────────────── -->
    <?php if ($docType !== 'nda'): ?>
    <div class="space-y-3 text-xs leading-relaxed text-gray-800">
      <h3 class="text-sm font-black text-gray-900 uppercase border-b border-gray-200 pb-1">1. Appointment &amp; Responsibilities</h3>
      <p>
        On behalf of <strong>Estate HDR</strong>, we are delighted to offer you the position of <strong><?= $role ?></strong>.
        In this role, you will report to the <?= ($dept === 'Production' ? 'Production Team Lead & Operations Supervisor' : 'Human Resources & General Management') ?>.
      </p>
      <div class="p-3.5 rounded-xl bg-amber-50/50 border border-amber-200 text-xs">
        <strong class="text-amber-900 block mb-1">Key Duties &amp; Scope of Responsibilities:</strong>
        <p class="text-gray-700 leading-relaxed"><?= htmlspecialchars($roleDuties) ?></p>
      </div>

      <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 p-3.5 rounded-xl bg-gray-50 border border-gray-200 font-mono text-[11px]">
        <div><span class="text-gray-500 block">Expected Joining Date:</span><strong class="text-gray-900"><?= $joiningDate ?></strong></div>
        <div><span class="text-gray-500 block">Assigned Work Shift:</span><strong class="text-gray-900"><?= $shift ?></strong></div>
        <div><span class="text-gray-500 block">Evaluation &amp; Probation:</span><strong class="text-gray-900"><?= $probation ?></strong></div>
      </div>
    </div>

    <!-- ── 5. COMPENSATION & SALARY BOX ──────────────────────────── -->
    <div class="p-5 rounded-2xl bg-amber-50/70 border-2 border-[#C9A84C] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
      <div>
        <span class="text-xs text-amber-900 font-bold uppercase tracking-wider">AGREED COMPENSATION &amp; SALARY STRUCTURE:</span>
        <div class="text-sm font-bold text-gray-900 mt-1"><?= $currency ?> <?= $totalSalary ?> <span class="text-xs font-normal text-gray-600 font-mono">(<?= $compType ?>)</span></div>
        <p class="text-[11px] text-gray-600 font-mono mt-0.5">
          <?= htmlspecialchars($contract['salary_notes'] ?? 'Disbursed via automated monthly direct transfer upon SLA performance completion.') ?>
        </p>
      </div>
      <div class="text-right font-mono">
        <div class="text-xl sm:text-2xl font-black text-gray-900"><?= $currency ?> <?= $totalSalary ?></div>
        <span class="text-[10px] font-bold text-emerald-800 uppercase px-2 py-0.5 rounded bg-emerald-100 border border-emerald-300 inline-block mt-1">
          ✓ APPROVED COMPENSATION
        </span>
      </div>
    </div>
    <?php endif; ?>

    <!-- ── 6. ROLE-SPECIFIC NON-DISCLOSURE CLAUSES ───────────────── -->
    <?php if ($docType !== 'offer_letter'): ?>
    <div class="space-y-3 text-xs leading-relaxed text-gray-800 pt-2">
      <div class="border-b border-gray-200 pb-1 flex items-center justify-between">
        <h3 class="text-sm font-black text-gray-900 uppercase">
          <?= ($docType === 'offer_and_nda' ? '2. Confidentiality & Non-Disclosure Obligations' : 'Contract Terms & Non-Disclosure Obligations') ?>
        </h3>
        <span class="text-[10px] font-mono text-[#9A7A2E] font-bold uppercase">Protocol: <?= htmlspecialchars($ndaData['title'] ?? 'Confidentiality Shield') ?></span>
      </div>

      <p>
        The Recipient agrees that throughout their engagement with Estate HDR and perpetually thereafter, they shall hold in the strictest confidence all proprietary data, raw multi-bracket media, client property directories, and operational systems.
      </p>

      <div class="space-y-2.5">
        <?php foreach ($roleClauses as $idx => $clause): 
          $parts = explode(':', $clause, 2);
        ?>
        <div class="p-3 rounded-lg bg-gray-50 border border-gray-200">
          <strong class="text-gray-900 font-mono"><?= ($idx + 1) ?>. <?= htmlspecialchars($parts[0]) ?>:</strong>
          <p class="text-gray-700 mt-0.5"><?= htmlspecialchars($parts[1] ?? '') ?></p>
        </div>
        <?php endforeach; ?>

        <div class="p-3 rounded-lg bg-gray-50 border border-gray-200">
          <strong class="text-gray-900 font-mono">Final Binding Term: Non-Circumvention &amp; Governing Law:</strong>
          <p class="text-gray-700 mt-0.5">
            The appointee agrees not to directly contact, solicit, or provide private services to Estate HDR clients. Breaches will result in immediate forfeiture of accrued compensation and formal legal action.
          </p>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <!-- ── 7. SIGNATURES BLOCK ───────────────────────────────────── -->
    <div class="pt-8 border-t-2 border-gray-200 grid grid-cols-3 gap-6 text-center text-xs font-mono" id="signingBlock">
      
      <!-- Company HR Authorized Signature -->
      <div class="space-y-2">
        <div class="h-16 flex items-end justify-center">
          <span class="font-serif italic text-base text-gray-800 font-bold border-b border-gray-400 pb-1 px-4">
            Sarah Jenkins
          </span>
        </div>
        <div class="font-bold text-gray-900">Sarah Jenkins</div>
        <div class="text-[10px] text-gray-500">Head of Human Resources &bull; Estate HDR</div>
      </div>

      <!-- Corporate Seal Stamp -->
      <div class="flex flex-col items-center justify-center">
        <div class="w-20 h-20 rounded-full border-2 border-dashed border-[#C9A84C] flex flex-col items-center justify-center p-1 text-center bg-amber-50/50 shadow-sm">
          <span class="text-[8px] font-black text-[#C9A84C] uppercase tracking-tighter">ESTATE HDR</span>
          <span class="text-[7px] text-gray-600 font-bold">OFFICIAL SEAL</span>
          <span class="text-[6px] text-gray-400">VERIFIED</span>
        </div>
        <span class="text-[9px] text-gray-400 mt-1">Official Corporate Stamp</span>
      </div>

      <!-- Candidate Signature Section -->
      <div class="space-y-2">
        <div class="h-16 flex items-end justify-center">
          <?php if ($isSigned): ?>
            <?php if (str_starts_with($contract['signature_data'] ?? '', 'data:image')): ?>
              <img src="<?= htmlspecialchars($contract['signature_data']) ?>" alt="Signature" class="max-h-14 max-w-[140px] object-contain border-b border-gray-400 pb-0.5">
            <?php else: ?>
              <span class="script-font text-2xl text-blue-900 border-b border-gray-400 pb-0.5 px-2">
                <?= htmlspecialchars($contract['signature_data'] ?: $contract['signer_name']) ?>
              </span>
            <?php endif; ?>
          <?php else: ?>
            <span class="border-b-2 border-dashed border-gray-400 w-36 inline-block text-[10px] text-gray-400 pb-1">
              (Awaiting Digital Signature)
            </span>
          <?php endif; ?>
        </div>
        <div class="font-bold text-gray-900"><?= $isSigned ? htmlspecialchars($contract['signer_name']) : $candidateName ?></div>
        <div class="text-[10px] text-gray-500">
          <?= $isSigned ? 'Digitally Signed on ' . htmlspecialchars(date('d M Y', strtotime($contract['signed_at']))) : 'Candidate Signature & Date' ?>
        </div>
      </div>

    </div>

    <?php if ($isSigned): ?>
    <!-- ── SIGNED AUDIT CERTIFICATE CARD ──────────────────────────── -->
    <div class="p-4 rounded-xl bg-emerald-50 border border-emerald-300 text-xs font-mono text-emerald-900 space-y-1">
      <div class="flex items-center justify-between">
        <span class="font-bold uppercase tracking-wider flex items-center gap-1.5 text-emerald-800">
          <span>✓</span> <span>Certified Legally Binding Digital Execution</span>
        </span>
        <span class="text-[10px] text-emerald-700">Audit ID: <?= strtoupper(substr(md5($contract['signed_at'] . $contract['token']), 0, 10)) ?></span>
      </div>
      <div class="text-[11px] text-emerald-800 pt-1 space-y-0.5">
        <div>Signer: <strong><?= htmlspecialchars($contract['signer_name']) ?></strong> (CNIC/ID: <?= htmlspecialchars($contract['signer_cnic'] ?: 'Verified') ?>)</div>
        <div>Timestamp: <strong><?= htmlspecialchars($contract['signed_at_formatted'] ?? $contract['signed_at']) ?></strong></div>
        <div>IP Record: <strong><?= htmlspecialchars($contract['signer_ip'] ?? '127.0.0.1') ?></strong></div>
        <div>Document Archive: <strong><?= htmlspecialchars($contract['signed_file'] ?? 'hr_signed_docs/' . $contract['id'] . '.json') ?></strong></div>
      </div>
    </div>
    <?php endif; ?>

    <div class="text-right text-[11px] font-mono text-gray-400 pt-2">
      1/1
    </div>

  </div>

</div>

<!-- ── 8. INTERACTIVE DIGITAL SIGNING MODAL / FORM (ONLY IF NOT SIGNED) ─ -->
<?php if (!$isSigned): ?>
<div class="no-print max-w-[860px] mx-auto mt-6 bg-[#161622] rounded-3xl p-6 sm:p-8 border border-gold/40 shadow-2xl text-white space-y-6">
  <div class="border-b border-gray-700 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
    <div>
      <span class="text-xs uppercase font-black tracking-wider text-amber-400">Step 2 of 2: Candidate Execution</span>
      <h3 class="text-xl font-black text-white">Execute Your Digital Signature</h3>
      <p class="text-xs text-gray-400 mt-0.5">Draw your signature with touch/mouse or type your legal name to complete hiring.</p>
    </div>
    <div class="flex items-center gap-2 bg-dark p-1 rounded-xl border border-gray-700 text-xs font-bold">
      <button type="button" onclick="switchSigMode('draw')" id="tabDraw" class="px-3 py-1.5 rounded-lg bg-gold text-dark font-black transition-all">Draw Signature</button>
      <button type="button" onclick="switchSigMode('type')" id="tabType" class="px-3 py-1.5 rounded-lg text-gray-400 hover:text-white transition-all">Type Name</button>
    </div>
  </div>

  <form method="POST" id="candidateSignForm" onsubmit="return validateAndSubmitSig()" class="space-y-6">
    <input type="hidden" name="action_sign_contract" value="1">
    <input type="hidden" name="signature_data" id="sigDataInput">

    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
      <div>
        <label class="block text-xs font-bold text-gray-300 mb-1">Full Legal Name *</label>
        <input type="text" name="signer_name" id="fSignerName" value="<?= $candidateName ?>" required class="w-full bg-[#111118] border border-gray-700 rounded-xl p-3 text-sm text-white font-bold focus:border-gold outline-none">
      </div>
      <div>
        <label class="block text-xs font-bold text-gray-300 mb-1">National ID / CNIC / Passport *</label>
        <input type="text" name="signer_cnic" id="fSignerCnic" value="<?= htmlspecialchars($contract['candidate_id_number'] ?? '') ?>" placeholder="e.g. 35201-XXXXXXX-X or Passport" required class="w-full bg-[#111118] border border-gray-700 rounded-xl p-3 text-sm text-white font-mono focus:border-gold outline-none">
      </div>
    </div>

    <!-- Mode 1: Canvas Drawing -->
    <div id="drawSigSection" class="space-y-2">
      <div class="flex items-center justify-between text-xs">
        <span class="font-bold text-gray-300">Draw Signature on Screen (Mouse / Touchpad / Mobile Touch):</span>
        <button type="button" onclick="clearCanvas()" class="text-xs text-amber-400 hover:underline">🧹 Clear Signature</button>
      </div>
      <div class="bg-white rounded-2xl p-2 border-2 border-dashed border-gold overflow-hidden">
        <canvas id="sigCanvas" width="760" height="160" class="w-full h-40 bg-white cursor-crosshair touch-none rounded-xl"></canvas>
      </div>
    </div>

    <!-- Mode 2: Typed Signature -->
    <div id="typeSigSection" class="hidden space-y-2">
      <label class="block text-xs font-bold text-gray-300">Type Your Legal Name (Renders Digital Cursive Signature):</label>
      <input type="text" id="typedSigInput" oninput="updateTypedPreview()" placeholder="Type your full name..." class="w-full bg-[#111118] border border-gray-700 rounded-xl p-3 text-sm text-white font-bold focus:border-gold outline-none">
      <div class="bg-white rounded-2xl p-4 text-center border-2 border-dashed border-gold">
        <span id="typedSigPreview" class="script-font text-4xl text-blue-900"><?= $candidateName ?></span>
      </div>
    </div>

    <!-- Declaration Checkbox -->
    <div class="p-4 rounded-2xl bg-[#111118] border border-gray-800 flex items-start gap-3">
      <input type="checkbox" name="terms_agreed" id="fTermsAgreed" required class="w-4 h-4 mt-1 rounded bg-dark border-gray-600 text-gold focus:ring-gold">
      <label for="fTermsAgreed" class="text-xs text-gray-300 leading-relaxed cursor-pointer select-none">
        I, <strong class="text-white"><?= $candidateName ?></strong>, hereby declare that I have thoroughly reviewed the terms of this
        <strong><?= $docType === 'nda' ? 'Non-Disclosure Agreement' : 'Employment Offer Letter & NDA' ?></strong>.
        I understand that my digital signature constitutes a legally binding agreement under applicable electronic transactions law.
      </label>
    </div>

    <div class="pt-2">
      <button type="submit" class="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-500 to-yellow-600 hover:from-amber-400 hover:to-yellow-500 text-dark font-black text-sm uppercase tracking-wider shadow-2xl shadow-gold/30 transition-all flex items-center justify-center gap-2">
        <span>✍️</span> <span>Confirm &amp; Execute Legally Binding Signature</span>
      </button>
    </div>
  </form>
</div>

<!-- Signature Canvas Engine Script -->
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
let currentMode = 'draw';
const canvas = document.getElementById('sigCanvas');
let ctx = canvas ? canvas.getContext('2d') : null;
let isDrawing = false;
let hasDrawn = false;

if (ctx) {
  ctx.strokeStyle = '#1e3a8a'; // Deep navy blue ink
  ctx.lineWidth = 2.8;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  function getPos(e) {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY
    };
  }

  function startDraw(e) {
    e.preventDefault();
    isDrawing = true;
    hasDrawn = true;
    const pos = getPos(e);
    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
  }

  function drawMove(e) {
    if (!isDrawing) return;
    e.preventDefault();
    const pos = getPos(e);
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
  }

  function stopDraw(e) {
    if (!isDrawing) return;
    e.preventDefault();
    isDrawing = false;
  }

  canvas.addEventListener('mousedown', startDraw);
  canvas.addEventListener('mousemove', drawMove);
  window.addEventListener('mouseup', stopDraw);

  canvas.addEventListener('touchstart', startDraw, { passive: false });
  canvas.addEventListener('touchmove', drawMove, { passive: false });
  window.addEventListener('touchend', stopDraw, { passive: false });
}

function clearCanvas() {
  if (!ctx) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  hasDrawn = false;
}

function switchSigMode(mode) {
  currentMode = mode;
  const drawSec = document.getElementById('drawSigSection');
  const typeSec = document.getElementById('typeSigSection');
  const tabDraw = document.getElementById('tabDraw');
  const tabType = document.getElementById('tabType');

  if (mode === 'draw') {
    drawSec.classList.remove('hidden');
    typeSec.classList.add('hidden');
    tabDraw.className = 'px-3 py-1.5 rounded-lg bg-gold text-dark font-black transition-all';
    tabType.className = 'px-3 py-1.5 rounded-lg text-gray-400 hover:text-white transition-all';
  } else {
    drawSec.classList.add('hidden');
    typeSec.classList.remove('hidden');
    tabType.className = 'px-3 py-1.5 rounded-lg bg-gold text-dark font-black transition-all';
    tabDraw.className = 'px-3 py-1.5 rounded-lg text-gray-400 hover:text-white transition-all';
  }
}

function updateTypedPreview() {
  const val = document.getElementById('typedSigInput').value.trim();
  document.getElementById('typedSigPreview').textContent = val || 'Your Signature';
}

function validateAndSubmitSig() {
  const input = document.getElementById('sigDataInput');
  if (currentMode === 'draw') {
    if (!hasDrawn) {
      alert('Please draw your signature on the signature pad before submitting.');
      return false;
    }
    input.value = canvas.toDataURL('image/png');
  } else {
    const typed = document.getElementById('typedSigInput').value.trim() || document.getElementById('fSignerName').value.trim();
    if (!typed) {
      alert('Please type your legal name to generate your signature.');
      return false;
    }
    input.value = typed;
  }
  return true;
}
</script>
<?php endif; ?>

<footer class="no-print max-w-[860px] mx-auto mt-10 text-center text-xs text-gray-500 pb-10">
  Estate HDR &bull; Professional Architectural Media &bull; UK Reg: EH-789021 &bull; <a href="mailto:hr@estatehdr.com" class="text-gold">hr@estatehdr.com</a>
</footer>

</body>
</html>
