# Product Requirements Document (PRD)
# Estate HDR Mobile Ecosystem: Client App & Team App

**Document Version:** 1.0.0  
**Status:** Approved for Architecture & Development  
**Target Platforms:** iOS (Apple App Store) & Android (Google Play Store)  
**Author:** Estate HDR Product & Engineering Group  
**Confidentiality:** Proprietary — Estate HDR Studio Ltd.  

---

## 1. Executive Summary & Vision

### 1.1 Product Vision
Estate HDR is the world's premier architectural retouching and 3D virtual staging studio. To scale operational throughput and empower our global client network of real estate photographers, commercial brokers, and luxury agencies, we are deploying a unified **Dual-Mobile App Ecosystem**:

1. **Estate HDR Client App**: A luxury concierge portal enabling photographers and brokers to place orders in <60 seconds, stream live Before/After retouching proofs with touch-interactive comparison sliders, annotate amendment requests with pixel precision, chat 24/7 with retouching directors, and download high-resolution MLS/Print media on-the-go.
2. **Estate HDR Team App**: A high-velocity production and quality control workstation for photo editors, team leads, quality supervisors, and production managers to claim job queues, review RAW bracket inputs, monitor SLA countdown timers (24h/12h/6h rush), upload processed HDR/Twilight/Staging deliverables, resolve client amendment tickets, and coordinate across shifts.

```
                  ┌────────────────────────────────────────┐
                  │          ESTATE HDR CLOUD CORE         │
                  │   REST API + WebSockets + Cloud Storage│
                  └───────────────┬────────────────────────┘
                                  │
                 ┌────────────────┴────────────────┐
                 ▼                                 ▼
   ┌───────────────────────────┐     ┌───────────────────────────┐
   │    ESTATE HDR CLIENT APP  │     │     ESTATE HDR TEAM APP   │
   │  (iOS / Android Native)   │     │   (iOS / Android Native)  │
   ├───────────────────────────┤     ├───────────────────────────┤
   │ • 60-Sec Order Placement  │     │ • Queue & Order Claiming  │
   │ • Touch B/A Slider Proofs │     │ • SLA Countdown & Routing │
   │ • Interactive Pin Markup  │     │ • QC Review & Approvals   │
   │ • 2-Way Concierge Chat    │     │ • Deliverable Uploader    │
   │ • Wallet & Instant MLS DL │     │ • Direct Client Chat Desk │
   └───────────────────────────┘     └───────────────────────────┘
```

### 1.2 Core Business Objectives
- **Reduce Order Placement Friction:** Cut job submission time from 4 minutes on web to under 60 seconds on mobile via cloud drive sync (Google Drive, Dropbox, iCloud).
- **Accelerate Turnaround & QA Cycles:** Speed up client review-and-approval cycles by 65% via instant Push Notifications and native touch Before/After comparison sliders.
- **Eliminate SLA Breaches:** Provide real-time audio-visual push warnings to photo editors and supervisors before jobs breach their 24h, 12h, or 6h deadlines.
- **Boost Customer Retention:** Increase recurring monthly volume through built-in loyalty credits, wallet autofill, and frictionless 1-tap WhatsApp/In-App concierge support.

---

## 2. User Personas & Target Audiences

### 2.1 Persona Matrix

| Attribute | Persona A: The Pro Photographer | Persona B: Luxury Broker / Agency | Persona C: Senior Photo Retoucher | Persona D: Production Supervisor |
| :--- | :--- | :--- | :--- | :--- |
| **App Used** | **Client App** | **Client App** | **Team App** | **Team App** |
| **Primary Goal** | Offload bracketed RAW editing in the field between property shoots. | Rapidly stage empty luxury listings to launch MLS campaigns. | Claim orders, edit RAWs to strict style presets, meet 24h SLA. | Audit QC scores, assign rush jobs, prevent bottlenecks. |
| **Pain Points** | Waiting until getting back to desktop to review proofs & submit revisions. | Complex communication loops; slow turnaround on staging amendments. | Missing client notes; lack of mobile visibility when away from desk. | Lack of real-time visibility into editor capacity and urgent amendments. |
| **Key Mobile Needs** | Fast cloud link paste, touch B/A zoom inspection, 1-tap MLS export. | High-res image downloads to camera roll, instant invoice generation. | Instant notifications for claimed jobs & revisions, timer alerts. | Order reassignment, 1-tap revision approvals, staff work log audits. |

---

## 3. Information Architecture & Navigation

### 3.1 Estate HDR Client App — Sitemap
```
Client App Root (Bottom Navigation Bar)
├── 1. Dashboard (Home)
│   ├── Quick Stat Cards (Active Jobs, In Review, Completed, Wallet Balance)
│   ├── "New Order" Action FAB (Floating Action Button)
│   ├── Active Orders Live Progress Carousel
│   ├── Recent Deliverables Quick Preview
│   └── 1-Tap Free Trial Banner (for new users)
├── 2. Orders Hub
│   ├── Tabs: All | In Progress | In Review | Completed | Amendments
│   ├── Order Search & Filter (Date, Service Type, Property Address)
│   └── Order Detail View:
│       ├── Status Stepper (Submitted ➔ Assigned ➔ Editing ➔ QC Passed ➔ Ready)
│       ├── Live SLA Timer Remaining
│       ├── Interactive Before / After Proofing Slider
│       ├── Pin-Point Amendment Tool
│       ├── High-Res Download Hub (Web MLS, Print 300DPI, Full Archive)
│       └── Order Dedicated Chat Channel
├── 3. Create Order (Multi-Step Flow)
│   ├── Step 1: Property Info & Job Title
│   ├── Step 2: Service Selection (HDR, Staging, Twilight, Day-to-Dusk, Floor Plan, Item Removal)
│   ├── Step 3: Style Preferences & Presets (Natural, Bright & Airy, Luxury Warm, Custom)
│   ├── Step 4: Asset Upload (Cloud URL or Direct Camera Roll / Files Pick)
│   ├── Step 5: Turnaround Speed (Standard 24h, Express 12h, Rush 6h)
│   └── Step 6: Review & Instant Wallet / Stripe Checkout
├── 4. Concierge (Live Chat & Support)
│   ├── Active Order Chat Channels
│   ├── General Support & Retouching Director Desk
│   ├── WhatsApp 1-Tap Integration Bridge
│   └── Self-Service Knowledge Base & FAQs
└── 5. Account & Settings
    ├── Profile & Studio Info
    ├── Default Retouching Style Preferences
    ├── Wallet, Loyalty Credits & Auto-Recharge
    ├── Invoices & VAT Receipts (PDF Export)
    ├── Notification Preferences (Push, Email, WhatsApp)
    ├── Biometric Login (Face ID / Fingerprint)
    └── Dark / Luxury Theme Settings
```

### 3.2 Estate HDR Team App — Sitemap
```
Team App Root (Bottom Navigation Bar)
├── 1. Production Hub (Dashboard)
│   ├── Shift Status Toggle (Available / On Shift / Break / Off Shift)
│   ├── SLA Critical Warning Alert Banner
│   ├── Real-Time KPI Cards (Claimed, Pending QC, Completed Today, Daily Earnings)
│   └── Active Job Cards with Live Countdown Timers
├── 2. Job Queue (Unassigned Orders)
│   ├── Filter by Service (HDR, Virtual Staging, Twilight, Declutter, Floor Plan)
│   ├── Filter by Urgency (Rush 6h, Express 12h, Standard 24h, Amendments)
│   └── 1-Tap "Claim Order" Workflow with Auto-Assignment Lock
├── 3. Workstation (Active Job Manager)
│   ├── Client Brief & Style Requirements Matrix
│   ├── Cloud RAW Download Link & Asset Viewer
│   ├── Deliverable Uploader (Before & After Pairs, High-Res ZIPs)
│   ├── Internal QC Self-Checklist Verification
│   └── "Submit to QC Supervisor" Action
├── 4. Amendments Desk
│   ├── Revision Ticket Queue (Ordered by Priority)
│   ├── Client Annotation Overlay Viewer (Visual Pins & Coordinates)
│   ├── Revision History & Iteration Versioning (v1, v2, v3)
│   └── 1-Tap "Re-Deliver Amendment" Workflow
├── 5. Team Communication & QC Center
│   ├── Supervisor / Lead Internal Channels
│   ├── Direct Client Chat Channels (Order-specific)
│   ├── Canned Responses & Quick Knowledge Base Snippets
│   └── SOP & Quality Guidelines Handbook
└── 6. Editor Profile & Earnings
    ├── Performance Rating & QC Acceptance Rate (%)
    ├── Per-Image / Per-Job Ledger & Weekly Payout Tracker
    └── Shift Scheduling & Attendance Log
```

---

## 4. Feature Specifications: Client Mobile App

### 4.1 Feature Epic 1: Ultra-Fast Order Submission (<60 Seconds)
- **User Story:** As a real estate photographer finishing a shoot, I want to submit bracketed photos directly from my phone using a cloud link so my retouchers can start working immediately while I drive to my next shoot.
- **Functional Requirements:**
  - Support pasting cloud links from Google Drive, Dropbox, WeTransfer, OneDrive, Box, or direct file upload.
  - Dynamic service configurator:
    - *HDR Photo Editing* ($0.80 - $1.50/photo) — 3/5/7 Bracket Blending, Window Masking, Sky Replacement, Lawn Greening.
    - *Virtual Staging* ($15.00/photo) — Living Room, Bedroom, Dining, Patio, Home Office, Modern/Scandinavian/Luxury style.
    - *Day to Dusk / Virtual Twilight* ($4.00/photo) — Golden Hour, Warm Interior Lighting, Fireplace Glow.
    - *Item Removal / Decluttering* ($3.00/photo) — Cars, Trash Bins, Wires, Personal Items.
    - *2D/3D Floor Plans* ($12.00 - $25.00/floor) — Colored, Textured, Dimensions.
  - Turnaround SLA Selector: Standard (24h), Express (12h +25%), Rush (6h +50%).
  - Pre-saved Style Presets: Load user's default preferences (e.g. "Warm Interior + Crisp Window View + Blue Sky #3").
  - Instant One-Touch Checkout via Apple Pay, Google Pay, Saved Credit Card, or Wallet Balance.

### 4.2 Feature Epic 2: Touch-Interactive Before/After Proofing Viewer
- **User Story:** As an agent reviewing completed photos, I want an interactive touch slider that lets me compare the original RAW and the edited HDR photo side-by-side on mobile.
- **Functional Requirements:**
  - High-performance GPU-accelerated horizontal touch slider.
  - Split-screen comparison with real-time pinch-to-zoom (up to 400%) keeping both Before and After images synchronized at the exact same zoom coordinate.
  - Toggle between split slider view, side-by-side view, and quick-tap hold-to-compare view.
  - Metadata overlay (Exposure brackets used, Sky ID applied, Editor ID, QC Timestamp).

### 4.3 Feature Epic 3: Pin-Point Visual Amendment Tool
- **User Story:** As a client noticing a small reflection in a window, I want to tap directly on the photo, drop a pin, and add a quick voice or text note so the editor knows exactly what to fix without confusion.
- **Functional Requirements:**
  - Tap-to-drop pin on image deliverable (saves exact `x, y` normalized percentage coordinates).
  - Add text note, audio voice memo (up to 60s), or quick category chip (e.g. "Brighten Here", "Remove Object", "Fix Window View", "Greener Grass").
  - Unlimited Free Amendments policy enforcement ($0 charge).
  - Live status tracking of amendment ticket (`Pending` ➔ `In Revision` ➔ `Re-Delivered`).

### 4.4 Feature Epic 4: 1-Tap High-Res Delivery & MLS Direct Sharing
- **User Story:** As a broker ready to post a listing, I want to save optimized photos directly to my camera roll or share them to my MLS/Instagram app in one tap.
- **Functional Requirements:**
  - Dual-Format Export:
    - **Web MLS Optimized:** 2048px width, 72 DPI, WebP/JPEG, under 2MB (MLS compliant).
    - **Full Print Master:** Original resolution, 300 DPI, uncompressed TIFF/JPEG.
  - 1-Tap "Save All to Camera Roll" (creates dedicated album named after Property Address).
  - Native iOS/Android Share Sheet integration (Airdrop, WhatsApp, Email, Google Drive).

### 4.5 Feature Epic 5: In-App Client Wallet & Billing Center
- **User Story:** As an agency owner placing 50 orders a month, I want an in-app wallet with volume bonuses and instant VAT invoices.
- **Functional Requirements:**
  - Wallet top-up with Tiered Bonus Credits (e.g., Deposit $500 ➔ Get $550 Credits).
  - Auto-reload when balance falls below user-defined threshold ($50).
  - PDF Invoice and VAT receipt download directly from app.
  - Complete transaction ledger with itemized job breakdown.

---

## 5. Feature Specifications: Team / Retoucher Mobile App

### 5.1 Feature Epic 1: Real-Time Job Queue & 1-Tap Order Claiming
- **User Story:** As a retoucher on shift, I want to see incoming unassigned orders in real-time and claim them with 1 tap so I can maximize my daily output.
- **Functional Requirements:**
  - Push notification alerts for new available jobs matching editor specialization (e.g. "New 25-Photo Luxury Staging Order Available").
  - Filter queue by service category, difficulty rating, turnaround urgency, and property size.
  - 1-Tap "Claim Job" with atomic server-side locking (prevents race conditions between editors).
  - Automatic timer initialization upon claim (e.g. 24h countdown).

### 5.2 Feature Epic 2: Workstation & Deliverable Verification
- **User Story:** As an editor completing a job on desktop or mobile, I want to upload the finished deliverables, verify them against the client's brief, and submit for QC approval.
- **Functional Requirements:**
  - Full display of client instructions, reference images, and custom style profile.
  - Cloud Drive RAW viewer & quick copy link.
  - Deliverables Uploader supporting Before/After image pairing.
  - Mandatory Self-QC Checklist before submission:
    - [ ] Vertical & Horizontal lines straightened (2-point perspective).
    - [ ] Window views pulled & balanced (no blown-out highlights).
    - [ ] Color cast neutralized on ceilings and white walls.
    - [ ] Sky replacement realistic with matching interior ambient temperature.
    - [ ] Dust spots and camera sensor blemishes removed.

### 5.3 Feature Epic 3: Visual Amendment Resolution Desk
- **User Story:** As an editor receiving a revision request, I want to see the client's exact pins and audio notes on my screen so I can fix the issue within 2 hours.
- **Functional Requirements:**
  - Amendment priority badge (Urgent SLA: 2h turnaround).
  - Visual pin overlay mapping client notes directly onto the image canvas.
  - Audio playback for client voice memos.
  - Side-by-side comparison of v1 delivery vs. new revision before submitting back to client.

### 5.4 Feature Epic 4: Shift Management, SOPs & Performance Analytics
- **User Story:** As a retoucher, I want to track my daily earnings, acceptance rate, and view standard operating procedures (SOPs) on my phone.
- **Functional Requirements:**
  - Shift Clock In / Clock Out with availability toggle.
  - Daily & Weekly earnings dashboard (Breakdown per service type).
  - Real-time Quality Score (% first-time pass rate, client 5-star ratings).
  - Embedded SOP Handbook with video tutorials for HDR blending, flambient, and 3D furniture placement.

---

## 6. Shared Capabilities (Both Apps)

### 6.1 Omnichannel Real-Time Chat & Concierge
- **2-Way Real-Time Messaging:** Powered by WebSockets with sub-300ms latency.
- **Channel Hierarchy:**
  - *Order-Specific Chat:* Direct communication tied to a specific job ID.
  - *General Concierge Desk:* 24/7 client support for billing and technical inquiries.
  - *Internal Team Channel:* Private editor-to-supervisor notes hidden from clients.
- **Rich Media Support:** Send photos, voice memos, PDF floor plans, and annotations in chat.
- **Typing Indicators & Read Receipts:** Full visual indicators for active typing.

### 6.2 Smart Push Notification System
- **Client Notifications:**
  - `ORDER_STARTED`: "🎨 Your retoucher has begun working on 142 Ocean Ave."
  - `ORDER_READY`: "✨ Your HDR photos are ready for review! Tap to preview Before/After."
  - `AMENDMENT_UPDATED`: "🚀 Revision v2 has been delivered for your approval."
  - `WALLET_LOW`: "💳 Your wallet balance is low ($12.00). Top up for auto-discounts."
- **Team Notifications:**
  - `NEW_JOB_AVAILABLE`: "⚡ New 12h Rush Order available: 32 photos (HDR + Twilight)."
  - `AMENDMENT_FILED`: "🚨 Client requested an amendment on Order #4821 (SLA: 2h)."
  - `SLA_WARNING`: "⚠️ Warning: Order #4790 has 2 hours remaining before SLA breach!"
  - `QC_APPROVED`: "🎉 Order #4802 passed supervisor QC with 5-star rating."

---

## 7. Non-Functional Requirements (NFRs)

### 7.1 Performance & Latency
- **App Launch Time:** Cold start < 1.5s, Warm start < 500ms on modern iOS/Android devices.
- **Image Proofing Fluidity:** 60 FPS smooth 120Hz ProMotion touch dragging on Before/After slider.
- **Image Loading:** Progressive WebP rendering with instant low-res blurred placeholder (LQIP) within 200ms.
- **Offline Mode:** Cached read access to recent orders, completed photos, and chat transcripts when connection is lost.

### 7.2 Security & Data Protection
- **Biometric Authentication:** FaceID / TouchID / Android Biometrics integration with secure biometric keychain token storage.
- **Data in Transit:** TLS 1.3 encryption across all REST and WebSocket connections with Certificate Pinning.
- **Data at Rest:** AES-256 encrypted SQLite / Hive local database storage for cached assets.
- **Asset Protection:** Time-limited pre-signed URLs (15-minute expiration) for high-resolution RAW and deliverable downloads.

### 7.3 Battery & Network Optimization
- Automatic chunked background upload/download pausing on cellular data (user-configurable "Wi-Fi Only" toggle for multi-gigabyte RAW transfers).
- Intelligent memory management disposing off-screen high-res textures to prevent Out-Of-Memory (OOM) crashes on low-end Android devices.

---

## 8. Success Metrics & KPIs

```
┌────────────────────────────────────────────────────────────────────────┐
│                        KEY SUCCESS METRICS                             │
├────────────────────────────────────────────────────────────────────────┤
│  Metric 1: Mobile Order Adoption Rate       ➔ Target: > 55% of all orders│
│  Metric 2: Average Proofing Approval Time   ➔ Target: < 45 minutes     │
│  Metric 3: First-Time QC Acceptance Rate    ➔ Target: > 94.5%          │
│  Metric 4: Team SLA Compliance Rate         ➔ Target: > 99.2% on-time  │
│  Metric 5: Client CSAT / App Store Rating   ➔ Target: > 4.8 / 5.0 Stars│
└────────────────────────────────────────────────────────────────────────┘
```
