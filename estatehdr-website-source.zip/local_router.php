<?php
/**
 * Estate HDR - Local PHP Development Server Router
 * Emulates .htaccess URL rewriting for localhost testing.
 */

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$file = __DIR__ . $uri;

// 1. If static file or directory exists, serve directly
if ($uri !== '/' && file_exists($file)) {
    if (is_dir($file)) {
        if (file_exists($file . '/index.php')) {
            require $file . '/index.php';
            return true;
        }
        return false;
    }
    return false; // Built-in web server serves static files directly
}

// 2. Extensionless PHP routing (e.g. /dashboard -> /dashboard.php)
if (file_exists($file . '.php')) {
    require $file . '.php';
    return true;
}

// 3. REST API v1 routing (/api/v1/...)
if (str_starts_with($uri, '/api/v1/')) {
    $_GET['endpoint'] = substr($uri, strlen('/api/v1/'));
    require __DIR__ . '/api/v1/index.php';
    return true;
}

// 4. Default homepage
if ($uri === '/' || $uri === '') {
    require __DIR__ . '/index.php';
    return true;
}

// 5. 404 Fallback
if (file_exists(__DIR__ . '/404.php')) {
    require __DIR__ . '/404.php';
    return true;
}

return false;
