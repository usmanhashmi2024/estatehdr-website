<?php
/**
 * Estate HDR — Flat-File Database Layer & CRM Core
 * All data is stored as JSON files in /data/
 * File locking (LOCK_EX) prevents race conditions on concurrent writes.
 */

require_once __DIR__ . '/config.php';
if (file_exists(__DIR__ . '/mail.php')) {
    require_once __DIR__ . '/mail.php';
}

// ══════════════════════════════════════════════════════════
//  HELPERS & CONCURRENCY-SAFE STORAGE ENGINE
// ══════════════════════════════════════════════════════════

/**
 * Atomic JSON File Writer with Exclusive Locking & Swap-File Rename
 * Guarantees zero-byte window prevention and crash-safe persistence across concurrent requests.
 *
 * @param string $path Target absolute or relative file path
 * @param array $data Data array to encode and persist
 * @return bool True on successful atomic persistence, false on failure
 */
function atomicWriteJson(string $path, array $data): bool {
    $dir = dirname($path);
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }

    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    if ($json === false) {
        error_log("atomicWriteJson: Failed to json_encode data for {$path}");
        return false;
    }

    $tmpPath = $path . '.' . bin2hex(random_bytes(6)) . '.tmp';
    $fp = @fopen($tmpPath, 'wb');
    if (!$fp) {
        error_log("atomicWriteJson: Unable to open temp file {$tmpPath}");
        return false;
    }

    flock($fp, LOCK_EX);
    $written = fwrite($fp, $json);
    fflush($fp);
    flock($fp, LOCK_UN);
    fclose($fp);

    if ($written === false || $written < strlen($json)) {
        @unlink($tmpPath);
        return false;
    }

    // Atomic replacement of target file
    if (!@rename($tmpPath, $path)) {
        // On Windows NTFS, if target is momentarily locked or exists, back off briefly
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            usleep(5000); // 5ms backoff
            if (!@rename($tmpPath, $path)) {
                if (file_exists($path)) {
                    @unlink($path);
                }
                if (!@rename($tmpPath, $path)) {
                    if (@copy($tmpPath, $path)) {
                        @unlink($tmpPath);
                        return true;
                    }
                    @unlink($tmpPath);
                    error_log("atomicWriteJson: Atomic rename failed from {$tmpPath} to {$path}");
                    return false;
                }
            }
        } else {
            @unlink($tmpPath);
            error_log("atomicWriteJson: Atomic rename failed from {$tmpPath} to {$path}");
            return false;
        }
    }

    return true;
}

/**
 * Concurrency-safe JSON File Reader (Lock-Free)
 * Atomic rename in atomicWriteJson guarantees reading is safe without blocking locks.
 */
function atomicReadJson(string $path): array {
    if (!file_exists($path)) return [];
    $content = @file_get_contents($path);
    if ($content === false || $content === '') return [];

    $decoded = json_decode($content, true);
    return is_array($decoded) ? $decoded : [];
}

function readJson(string $path): array {
    return atomicReadJson($path);
}

function writeJson(string $path, array $data): bool {
    return atomicWriteJson($path, $data);
}

function generateId(): string {
    return bin2hex(random_bytes(8));
}

function generateClientId(): string {
    $users = getUsers();
    $maxNum = 1000;
    foreach ($users as $u) {
        if (preg_match('/^CL-(\d+)$/i', $u['id'], $m)) {
            $maxNum = max($maxNum, (int)$m[1]);
        }
    }
    return 'CL-' . ($maxNum + 1);
}

function generateOrderId(): string {
    $orders = getAllOrders();
    $maxNum = 5000;
    foreach ($orders as $o) {
        if (preg_match('/^ORD-(\d+)$/i', $o['id'], $m)) {
            $maxNum = max($maxNum, (int)$m[1]);
        }
    }
    $saasFile = defined('DATA_PATH') ? (rtrim(DATA_PATH, '/\\') . '/saas_orders.json') : '';
    if (!empty($saasFile) && file_exists($saasFile)) {
        $saasOrders = json_decode(@file_get_contents($saasFile), true) ?: [];
        foreach ($saasOrders as $so) {
            if (preg_match('/^ORD-(\d+)$/i', $so['id'] ?? '', $m)) {
                $maxNum = max($maxNum, (int)$m[1]);
            }
        }
    }
    return 'ORD-' . ($maxNum + 1);
}

// ══════════════════════════════════════════════════════════
//  USERS & CLIENTS
// ══════════════════════════════════════════════════════════

function getUsers(): array {
    return readJson(USERS_FILE);
}

function saveUsers(array $users): bool {
    return writeJson(USERS_FILE, $users);
}

function getUserByEmail(string $email): ?array {
    $target = strtolower(trim($email));
    if (empty($target)) return null;
    foreach (getUsers() as $u) {
        if (strtolower(trim($u['email'] ?? '')) === $target) return $u;
        if (strtolower(trim($u['username'] ?? '')) === $target) return $u;
    }
    return null;
}

function findUserByEmail(string $email): ?array {
    return getUserByEmail($email);
}

function getUserById(string $id): ?array {
    $trimmed = trim($id);
    if (empty($trimmed)) return null;
    $users = getUsers();
    // Direct ID match
    foreach ($users as $u) {
        if (($u['id'] ?? '') === $trimmed) return $u;
    }
    // Case-insensitive ID match
    foreach ($users as $u) {
        if (strcasecmp($u['id'] ?? '', $trimmed) === 0) return $u;
    }
    // Fallback: match by email or username
    foreach ($users as $u) {
        if (strcasecmp($u['email'] ?? '', $trimmed) === 0) return $u;
        if (strcasecmp($u['username'] ?? '', $trimmed) === 0) return $u;
    }
    return null;
}

function createUser(string $name, string $email, string $password, string $company = '', string $phone = '', string $country = '', string $notes = '', string $createdBy = 'client'): array {
    $users = getUsers();
    $user  = [
        'id'         => generateClientId(),
        'name'       => trim($name),
        'email'      => strtolower(trim($email)),
        'password'   => password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]),
        'company'    => trim($company),
        'phone'      => trim($phone),
        'country'    => trim($country),
        'notes'      => trim($notes),
        'created_by' => $createdBy, // 'client' or 'admin'
        'created_at' => date('c'),
    ];
    $users[] = $user;
    saveUsers($users);

    // Real-Time Admin Notification
    if (function_exists('addAdminNotification')) {
        addAdminNotification(
            'client',
            '👤 New Client: ' . $user['name'],
            'New client ' . $user['name'] . ' (' . $user['email'] . ') registered.' . (!empty($company) ? " Company: {$company}." : ''),
            '/admin/clients.php',
            ['user_id' => $user['id'], 'email' => $user['email'], 'company' => $user['company']]
        );
    }

    // Trigger Discord Bot Alert if available
    if (file_exists(__DIR__ . '/discord-bot.php')) {
        require_once __DIR__ . '/discord-bot.php';
        if (function_exists('notifyDiscordNewClient')) {
            notifyDiscordNewClient($user);
        }
    }

    return $user;
}

function updateUserPassword(string $userId, string $newPassword): bool {
    $users = getUsers();
    foreach ($users as &$u) {
        if ($u['id'] === $userId) {
            $u['password'] = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => 12]);
            return saveUsers($users);
        }
    }
    return false;
}

function deleteUser(string $userId): bool {
    $users = getUsers();
    $filtered = array_values(array_filter($users, fn($u) => ($u['id'] ?? '') !== $userId));
    if (count($filtered) === count($users)) return false;
    saveUsers($filtered);
    
    // 1. Clean preferences
    $prefPath = getPreferencesPath($userId);
    if (file_exists($prefPath)) @unlink($prefPath);
    
    // 2. Wipe all orders
    $orders = getAllOrders();
    foreach ($orders as $o) {
        if (($o['user_id'] ?? '') === $userId && !empty($o['id'])) {
            deleteOrder($o['id']);
        }
    }
    
    // 3. Wipe ledger entries
    $ledgerFile = DATA_PATH . 'ledger.json';
    if (file_exists($ledgerFile)) {
        $ledger = readJson($ledgerFile) ?: [];
        $filteredLedger = array_values(array_filter($ledger, fn($l) => ($l['client_id'] ?? '') !== $userId));
        writeJson($ledgerFile, $filteredLedger);
    }
    return true;
}

function updateUserProfile(string $userId, string $name, string $phone = '', string $company = '', string $country = '', string $notes = '', string $dialCode = ''): bool {
    $users = getUsers();
    foreach ($users as &$u) {
        if ($u['id'] === $userId) {
            $u['name']    = trim($name);
            $u['phone']   = trim($phone);
            if ($company !== '') $u['company'] = trim($company);
            if ($country !== '') $u['country'] = trim($country);
            if ($notes !== '')   $u['notes']   = trim($notes);
            if ($dialCode !== '') $u['dial_code'] = trim($dialCode);
            return saveUsers($users);
        }
    }
    return false;
}

// ══════════════════════════════════════════════════════════
//  STYLE PREFERENCES CENTER
// ══════════════════════════════════════════════════════════

function getPreferencesPath(string $userId): string {
    return PREFERENCES_PATH . $userId . '.json';
}

function getUserPreferences(string $userId): array {
    $path = getPreferencesPath($userId);
    $defaults = [
        'color_style'           => 'natural',        // 'natural' | 'vibrant' | 'moody_warm' | 'airy_crisp'
        'sky_replacement'       => 'blue_sunny',     // 'blue_sunny' | 'sunset_dusk' | 'soft_clouds' | 'keep_original'
        'window_treatment'      => 'full_window_pull', // 'full_window_pull' | 'soft_ambient_pull' | 'standard'
        'grass_greening'        => true,
        'tv_screen_replacement' => true,
        'fire_in_fireplace'     => true,
        'default_notes'         => '',
        'reference_links'       => '',
        'updated_at'            => date('c'),
    ];
    if (!file_exists($path)) return $defaults;
    return array_merge($defaults, readJson($path));
}

function saveUserPreferences(string $userId, array $data): bool {
    $current = getUserPreferences($userId);
    $updated = array_merge($current, $data, ['updated_at' => date('c')]);
    return writeJson(getPreferencesPath($userId), $updated);
}

// ══════════════════════════════════════════════════════════
//  ORDERS / TICKETS / AUDIT TRAIL
// ══════════════════════════════════════════════════════════

function getOrderPath(string $orderId): string {
    return ORDERS_PATH . $orderId . '.json';
}

function getOrder(string $orderId): ?array {
    $orderId = trim($orderId);
    if (empty($orderId)) return null;

    $path = getOrderPath($orderId);
    if (file_exists($path)) {
        $order = readJson($path);
        if (!empty($order)) {
            $order['raw_images_count']       = (int)($order['raw_images_count'] ?? 0);
            $order['delivered_images_count'] = (int)($order['delivered_images_count'] ?? 0);
            $order['created_by']             = $order['created_by'] ?? 'client';
            $order['annotations']            = $order['annotations'] ?? [];
            $isTrial = !empty($order['is_trial']) || (($order['order_type'] ?? '') === 'free_trial') || str_starts_with(strtoupper($order['id'] ?? $orderId), 'TRIAL-');
            $order['is_trial']               = $isTrial;
            $order['order_type']             = $isTrial ? 'free_trial' : ($order['order_type'] ?? 'live_order');
            $order['billed_amount']          = $isTrial ? 0.0 : (float)($order['billed_amount'] ?? 0.0);
            return $order;
        }
    }

    // Fallback: Check saas_orders.json for orders bridged into production
    $saasFile = defined('DATA_PATH') ? (rtrim(DATA_PATH, '/\\') . '/saas_orders.json') : '';
    if (!empty($saasFile) && file_exists($saasFile)) {
        $saasOrders = json_decode(@file_get_contents($saasFile), true) ?: [];
        foreach ($saasOrders as $so) {
            if (strcasecmp($so['id'] ?? '', $orderId) === 0) {
                $isTrial = !empty($so['is_trial']) || (($so['order_type'] ?? '') === 'free_trial') || str_starts_with(strtoupper($so['id'] ?? $orderId), 'TRIAL-');
                return [
                    'id'                     => $so['id'],
                    'user_id'                => $so['client_id'] ?? ($so['user_id'] ?? 'CL-1001'),
                    'client_name'            => $so['client_name'] ?? 'Client',
                    'client_email'           => $so['client_email'] ?? '',
                    'client_phone'           => $so['client_phone'] ?? '',
                    'client_company'         => $so['client_company'] ?? '',
                    'property_name'          => $so['property_name'] ?? 'Property',
                    'service_type'           => $so['editing_type'] ?? ($so['service_type'] ?? 'HDR Photo Editing'),
                    'cloud_link'             => $so['input_storage_path'] ?? ($so['cloud_link'] ?? ''),
                    'final_cloud_link'       => $so['delivery_url'] ?? ($so['output_storage_path'] ?? ''),
                    'notes'                  => $so['instructions'] ?? ($so['notes'] ?? ''),
                    'raw_images_count'       => (int)($so['photo_count'] ?? ($so['raw_images_count'] ?? 0)),
                    'delivered_images_count' => (int)($so['final_image_count'] ?? 0),
                    'billed_amount'          => $isTrial ? 0.0 : (float)($so['price_amount'] ?? ($so['billed_amount'] ?? 0.0)),
                    'is_trial'               => $isTrial,
                    'order_type'             => $isTrial ? 'free_trial' : ($so['order_type'] ?? 'live_order'),
                    'created_by'             => 'client',
                    'status'                 => $so['status'] ?? 'pending',
                    'annotations'            => [],
                    'messages'               => [],
                    'created_at'             => $so['created_at'] ?? date('c'),
                    'updated_at'             => $so['updated_at'] ?? date('c'),
                ];
            }
        }
    }

    return null;
}

function saveOrder(array $order): bool {
    $id = $order['id'] ?? '';
    if (empty($id)) return false;

    $written = writeJson(getOrderPath($id), $order);

    // Synchronize to saas_orders.json pipeline
    $saasFile = defined('DATA_PATH') ? (rtrim(DATA_PATH, '/\\') . '/saas_orders.json') : '';
    if (!empty($saasFile) && file_exists($saasFile)) {
        $saasOrders = json_decode(@file_get_contents($saasFile), true) ?: [];
        $changed = false;
        foreach ($saasOrders as &$so) {
            if (strcasecmp($so['id'] ?? '', $id) === 0) {
                if (isset($order['status'])) $so['status'] = $order['status'];
                if (isset($order['property_name'])) $so['property_name'] = $order['property_name'];
                if (isset($order['service_type'])) $so['editing_type'] = $order['service_type'];
                if (isset($order['cloud_link'])) $so['input_storage_path'] = $order['cloud_link'];
                if (isset($order['final_cloud_link'])) $so['delivery_url'] = $order['final_cloud_link'];
                if (isset($order['raw_images_count'])) $so['photo_count'] = (int)$order['raw_images_count'];
                if (isset($order['delivered_images_count'])) $so['final_image_count'] = (int)$order['delivered_images_count'];
                if (isset($order['billed_amount'])) $so['price_amount'] = (float)$order['billed_amount'];
                if (isset($order['is_trial'])) $so['is_trial'] = (bool)$order['is_trial'];
                if (isset($order['order_type'])) $so['order_type'] = $order['order_type'];
                if (in_array(strtolower($order['status'] ?? ''), ['delivered', 'completed', 'sent_client'])) {
                    if (empty($so['delivered_at'])) $so['delivered_at'] = date('c');
                }
                $so['updated_at'] = date('c');
                $changed = true;
                break;
            }
        }
        if ($changed) {
            @file_put_contents($saasFile, json_encode($saasOrders, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
        }
    }

    return $written;
}

function setOrderType(string $orderId, string $type): bool {
    $orderId = trim($orderId);
    if (empty($orderId)) return false;
    $type = ($type === 'free_trial' || $type === 'trial') ? 'free_trial' : 'live_order';
    $isTrial = ($type === 'free_trial');
    $updated = false;

    // 1. Update physical JSON order file if exists
    $path = getOrderPath($orderId);
    if (file_exists($path)) {
        $order = readJson($path);
        if (!empty($order)) {
            $order['is_trial']   = $isTrial;
            $order['order_type'] = $type;
            if ($isTrial) {
                $order['billed_amount'] = 0.0;
            }
            $order['updated_at'] = date('c');
            saveOrder($order);
            $updated = true;
        }
    }

    // 2. Update saas_orders.json
    $saasFile = defined('SAAS_ORDERS_FILE') ? SAAS_ORDERS_FILE : (DATA_PATH . 'saas_orders.json');
    if (file_exists($saasFile)) {
        $saasOrders = readJson($saasFile) ?: [];
        foreach ($saasOrders as &$so) {
            if (strcasecmp($so['id'] ?? '', $orderId) === 0) {
                $so['is_trial']   = $isTrial;
                $so['order_type'] = $type;
                if ($isTrial) {
                    $so['price_amount']  = 0.0;
                    $so['billed_amount'] = 0.0;
                }
                $so['updated_at'] = date('c');
                $updated = true;
                break;
            }
        }
        if ($updated) {
            writeJson($saasFile, $saasOrders);
        }
    }

    // 3. Ledger synchronization
    if ($isTrial) {
        // Free trial: purge any billed ledger transaction and recalculate balance
        syncOrderBillingToLedger($orderId, 0.0);
    }

    return $updated;
}

function getAllOrders(): array {
    $orders = [];
    $seenIds = [];

    if (is_dir(ORDERS_PATH)) {
        $files = glob(ORDERS_PATH . '*.json');
        foreach ($files as $f) {
            $o = readJson($f);
            if (!empty($o) && !empty($o['id'])) {
                $isTrial = !empty($o['is_trial']) || (($o['order_type'] ?? '') === 'free_trial') || str_starts_with(strtoupper($o['id']), 'TRIAL-');
                $o['is_trial']               = $isTrial;
                $o['order_type']             = $isTrial ? 'free_trial' : ($o['order_type'] ?? 'live_order');
                $o['raw_images_count']       = (int)($o['raw_images_count'] ?? 0);
                $o['delivered_images_count'] = (int)($o['delivered_images_count'] ?? 0);
                $o['billed_amount']          = $isTrial ? 0.0 : (float)($o['billed_amount'] ?? 0.0);
                $o['created_by']             = $o['created_by'] ?? 'client';
                $o['annotations']            = $o['annotations'] ?? [];
                $orders[] = $o;
                $seenIds[strtoupper($o['id'])] = true;
            }
        }
    }

    // Also include SaaS and Free Trial orders that don't have separate JSON files
    $saasFile = defined('DATA_PATH') ? (rtrim(DATA_PATH, '/\\') . '/saas_orders.json') : '';
    if (!empty($saasFile) && file_exists($saasFile)) {
        $saasOrders = json_decode(@file_get_contents($saasFile), true) ?: [];
        foreach ($saasOrders as $so) {
            $sid = strtoupper($so['id'] ?? '');
            if (!empty($sid) && !isset($seenIds[$sid])) {
                $isTrial = !empty($so['is_trial']) || (($so['order_type'] ?? '') === 'free_trial') || str_starts_with($sid, 'TRIAL-');
                $orders[] = [
                    'id'                     => $so['id'],
                    'user_id'                => $so['client_id'] ?? ($so['user_id'] ?? 'CL-1001'),
                    'client_name'            => $so['client_name'] ?? 'Client',
                    'client_email'           => $so['client_email'] ?? '',
                    'client_phone'           => $so['client_phone'] ?? '',
                    'client_company'         => $so['client_company'] ?? '',
                    'property_name'          => $so['property_name'] ?? 'Property',
                    'service_type'           => $so['editing_type'] ?? ($so['service_type'] ?? 'HDR Photo Editing'),
                    'cloud_link'             => $so['input_storage_path'] ?? ($so['cloud_link'] ?? ''),
                    'final_cloud_link'       => $so['delivery_url'] ?? ($so['output_storage_path'] ?? ''),
                    'notes'                  => $so['instructions'] ?? ($so['notes'] ?? ''),
                    'raw_images_count'       => (int)($so['photo_count'] ?? ($so['raw_images_count'] ?? 0)),
                    'delivered_images_count' => (int)($so['final_image_count'] ?? 0),
                    'billed_amount'          => $isTrial ? 0.0 : (float)($so['price_amount'] ?? ($so['billed_amount'] ?? 0.0)),
                    'is_trial'               => $isTrial,
                    'order_type'             => $isTrial ? 'free_trial' : ($so['order_type'] ?? 'live_order'),
                    'created_by'             => 'client',
                    'status'                 => $so['status'] ?? 'pending',
                    'annotations'            => [],
                    'messages'               => [],
                    'created_at'             => $so['created_at'] ?? date('c'),
                    'updated_at'             => $so['updated_at'] ?? date('c'),
                ];
                $seenIds[$sid] = true;
            }
        }
    }

    // Sort by created_at DESC
    usort($orders, fn($a, $b) => strcmp($b['created_at'] ?? '', $a['created_at'] ?? ''));
    return $orders;
}

function getOrdersByUser(string $userId): array {
    $all = getAllOrders();
    return array_values(array_filter($all, fn($o) => $o['user_id'] === $userId));
}

function createOrder(
    string $userId, 
    string $propertyName, 
    string $cloudLink, 
    string $notes, 
    string $serviceType, 
    int $rawImagesCount = 0, 
    string $createdBy = 'client',
    bool $isTrial = false
): array {
    // ── Idempotency / Double-Submit Protection ────────────────────────
    // If an identical order from this user was created within the last 60 seconds,
    // return that existing order immediately instead of creating a duplicate.
    $existingOrders = getOrdersByUser($userId);
    $now = time();
    $pNorm = strtolower(trim($propertyName));
    $cNorm = strtolower(trim($cloudLink));
    foreach ($existingOrders as $eo) {
        $createdAt = strtotime($eo['created_at'] ?? '1970-01-01');
        if (($now - $createdAt) < 60) {
            $existingPNorm = strtolower(trim($eo['property_name'] ?? ''));
            $existingCNorm = strtolower(trim($eo['cloud_link'] ?? ''));
            if ($existingPNorm === $pNorm && $existingCNorm === $cNorm) {
                error_log("Prevented duplicate order submission for user {$userId}. Returning existing order {$eo['id']}.");
                return $eo;
            }
        }
    }

    $clientUser = function_exists('getUserById') ? getUserById($userId) : null;
    $sessUser   = function_exists('currentUser') ? currentUser() : null;
    $order = [
        'id'                     => generateOrderId(),
        'user_id'                => $userId,
        'client_name'            => $clientUser['name'] ?? ($sessUser['name'] ?? 'Client'),
        'client_email'           => !empty($clientUser['email']) ? $clientUser['email'] : (!empty($clientUser['username']) ? $clientUser['username'] : ($sessUser['email'] ?? '')),
        'client_phone'           => $clientUser['phone'] ?? ($sessUser['phone'] ?? ''),
        'client_company'         => $clientUser['company'] ?? ($sessUser['company'] ?? ''),
        'property_name'          => trim($propertyName),
        'service_type'           => $serviceType,
        'cloud_link'             => trim($cloudLink),
        'notes'                  => trim($notes),
        'raw_images_count'       => max(0, $rawImagesCount),
        'delivered_images_count' => 0, // Client cannot edit; set by Admin on delivery
        'billed_amount'          => 0.0,
        'is_trial'               => (bool)$isTrial,
        'order_type'             => $isTrial ? 'free_trial' : 'live_order',
        'created_by'             => $createdBy, // 'client' or 'admin'
        'status'                 => 'pending',
        'annotations'            => [],
        'created_at'             => date('c'),
        'updated_at'             => date('c'),
        'messages'               => [
            [
                'id'         => generateId(),
                'sender'     => $createdBy,
                'type'       => 'order',
                'content'    => trim($notes),
                'cloud_link' => trim($cloudLink),
                'timestamp'  => date('c'),
            ]
        ],
    ];
    saveOrder($order);

    // Automatically bridge into SaaS Production Queue for Supervisor & Team Leads
    if (file_exists(__DIR__ . '/saas-db.php')) {
        require_once __DIR__ . '/saas-db.php';
        if (function_exists('syncLegacyOrdersToSaaS')) {
            syncLegacyOrdersToSaaS();
        }
    }

    // Trigger Real-Time Admin Notification
    if (function_exists('addAdminNotification')) {
        addAdminNotification(
            'order',
            '🛍️ New Order Placed: ' . ($order['property_name'] ?: 'Property Photos'),
            'Order #' . $order['id'] . ' placed by ' . $createdBy . ' for ' . $serviceType . ' (' . $rawImagesCount . ' images).',
            '/admin/order-view.php?id=' . $order['id'],
            ['order_id' => $order['id'], 'property' => $order['property_name'], 'service' => $serviceType]
        );
    }

    // Trigger Discord Bot Alert if available
    if (file_exists(__DIR__ . '/discord-bot.php')) {
        require_once __DIR__ . '/discord-bot.php';
        if (function_exists('notifyDiscordOrderPlaced')) {
            notifyDiscordOrderPlaced($order);
        }
    }

    // Trigger Detailed Email Notification to Admin & Client
    if (function_exists('sendNewOrderNotification')) {
        sendNewOrderNotification($order);
    }

    return $order;
}

function appendMessage(string $orderId, string $sender, string $type, string $content, string $cloudLink = ''): bool {
    $order = getOrder($orderId);
    if (!$order) return false;
    $msg = [
        'id'         => generateId(),
        'sender'     => $sender,   // 'client' | 'admin'
        'type'       => $type,     // 'order' | 'delivery' | 'amendment' | 'reply'
        'content'    => trim($content),
        'cloud_link' => trim($cloudLink),
        'timestamp'  => date('c'),
    ];
    $order['messages'][]  = $msg;
    $order['updated_at']  = date('c');

    // Auto-update status
    if ($type === 'delivery') $order['status'] = 'delivered';
    if ($type === 'amendment') $order['status'] = 'amendment_requested';
    if ($type === 'reply') $order['status'] = 'in_progress';

    return saveOrder($order);
}

function deliverOrderWithTracking(
    string $orderId, 
    string $cloudLink, 
    int $deliveredImagesCount, 
    float $billedAmount = 0.0, 
    string $content = ''
): bool {
    $order = getOrder($orderId);
    if (!$order) return false;

    // Resolve client details if missing on legacy order
    if (empty($order['client_email']) && !empty($order['user_id']) && function_exists('getUserById')) {
        $u = getUserById($order['user_id']);
        if ($u) {
            $order['client_name']    = $u['name'] ?? ($order['client_name'] ?? 'Client');
            $order['client_email']   = $u['email'] ?? ($u['username'] ?? '');
            $order['client_phone']   = $u['phone'] ?? ($order['client_phone'] ?? '');
            $order['client_company'] = $u['company'] ?? ($order['client_company'] ?? '');
        }
    }

    $order['delivered_images_count'] = max(0, $deliveredImagesCount);
    if ($billedAmount > 0) {
        $order['billed_amount'] = $billedAmount;
    }
    $order['status']           = 'delivered';
    $order['final_cloud_link'] = trim($cloudLink);
    $order['updated_at']       = date('c');

    $msg = [
        'id'         => generateId(),
        'sender'     => 'admin',
        'type'       => 'delivery',
        'content'    => $content ?: "Your edited images are ready! Total delivered: {$deliveredImagesCount} images.",
        'cloud_link' => trim($cloudLink),
        'timestamp'  => date('c'),
    ];
    $order['messages'][] = $msg;
    saveOrder($order);

    // Free Trial Safeguard: Never bill free trials to ledger
    $isTrial = !empty($order['is_trial']) || (($order['order_type'] ?? '') === 'free_trial') || str_starts_with(strtoupper($orderId), 'TRIAL-');
    if ($isTrial) {
        $billedAmount = 0.0;
        $order['billed_amount'] = 0.0;
        saveOrder($order);
        // Ensure no leftover debt exists in ledger
        syncOrderBillingToLedger($orderId, 0.0);
    } elseif ($billedAmount > 0) {
        // Automatically sync billing to ledger and recalculate client's account balance
        syncOrderBillingToLedger(
            $orderId, 
            $billedAmount, 
            $deliveredImagesCount, 
            "Order #{$orderId}: {$order['property_name']}"
        );
    }

    // Dispatch official Luxury Golden Delivery Email (Free Trial or Paid Invoice)
    if (function_exists('sendOrderDeliveryInvoiceEmail')) {
        sendOrderDeliveryInvoiceEmail($order, $billedAmount, $cloudLink, $deliveredImagesCount);
    }

    return true;
}

/**
 * Master Trigger for Client Amendment / Revision Requests
 * 1. Sets order status to 'amendment_requested'
 * 2. Appends amendment message to order messages thread
 * 3. Triggers real-time Admin notification bell chime & desktop notification
 * 4. Triggers instant Discord webhook alert
 * 5. Synchronizes to AmendmentService data store
 */
function triggerAmendmentRequested(string $orderId, string $notes, array $extra = []): array {
    $order = getOrder($orderId);
    if (!$order) {
        return ['success' => false, 'error' => 'Order not found'];
    }

    $cleanNotes = trim($notes);
    $propName   = $order['property_name'] ?? 'Real Estate Property';

    // Multi-tier client resolution
    $client = null;
    $targetUid = !empty($order['user_id']) ? $order['user_id'] : ($order['client_id'] ?? '');
    if (!empty($targetUid) && function_exists('getUserById')) {
        $client = getUserById($targetUid);
    }
    $clientName  = $client['name'] ?? ($order['client_name'] ?? 'Client');
    $clientEmail = $client['email'] ?? ($order['client_email'] ?? '');

    // 1. Update Order Status & Append Thread Message
    $amendmentHeader = "📌 [AMENDMENT FOR JOB #" . strtoupper($orderId) . " — " . $propName . "]\n" . $cleanNotes;
    appendMessage($orderId, 'client', 'amendment', $amendmentHeader);
    updateOrderStatus($orderId, 'amendment_requested');

    // Reload order after update
    $order = getOrder($orderId);

    // 2. Synchronize to AmendmentService
    $amendRecord = null;
    if (file_exists(__DIR__ . '/services/AmendmentService.php')) {
        require_once __DIR__ . '/services/AmendmentService.php';
        if (class_exists('AmendmentService')) {
            $amendRecord = AmendmentService::createAmendment([
                'order_id'    => $orderId,
                'client_id'   => $targetUid ?: 'CLIENT',
                'reason'      => $cleanNotes,
                'annotations' => $extra['annotations'] ?? ($order['annotations'] ?? []),
                'version'     => $order['version'] ?? 'v1'
            ]);
        }
    }

    // 3. Trigger Real-Time Admin Notification (Audio chime + Desktop popup + Bell dropdown)
    if (function_exists('addAdminNotification')) {
        $shortNote = mb_strlen($cleanNotes) > 120 ? mb_substr($cleanNotes, 0, 117) . '...' : $cleanNotes;
        addAdminNotification(
            'amendment',
            "✏️ Amendment Requested: #" . strtoupper($orderId) . " ({$propName})",
            "{$clientName} requested revisions: \"{$shortNote}\"",
            "/admin/order-view.php?id=" . urlencode($orderId),
            [
                'order_id'      => $orderId,
                'client_name'   => $clientName,
                'client_email'  => $clientEmail,
                'property_name' => $propName,
                'notes'         => $cleanNotes,
                'timestamp'     => date('c')
            ]
        );
    }

    // 4. Trigger Real-Time Discord Bot Webhook Alert
    if (file_exists(__DIR__ . '/discord-bot.php')) {
        require_once __DIR__ . '/discord-bot.php';
        if (function_exists('notifyDiscordAmendmentRequested')) {
            notifyDiscordAmendmentRequested($order, $cleanNotes, [
                'name'    => $clientName,
                'email'   => $clientEmail,
                'company' => $order['client_company'] ?? ($client['company'] ?? '')
            ]);
        }
    }

    return [
        'success'      => true,
        'order'        => $order,
        'amend_record' => $amendRecord
    ];
}

/**
 * Deliver / Resolve an Amendment with Client Notification Email & Tracking
 * 1. Sets order status to 'delivered'
 * 2. Updates final cloud link & delivered count
 * 3. Appends amendment resolution to message audit thread
 * 4. Resolves pending smart amendment record
 * 5. Sends official "Amendment Completed" notification email to client
 * 6. Dispatches Discord delivery ping & in-app confirmation
 */
function deliverAmendmentResolution(
    string $orderId, 
    string $cloudLink, 
    string $resolutionNotes = '', 
    int $deliveredImagesCount = 0, 
    bool $sendEmail = true
): bool {
    $order = getOrder($orderId);
    if (!$order) return false;

    // Resolve client details if missing on legacy order
    if (empty($order['client_email']) && !empty($order['user_id']) && function_exists('getUserById')) {
        $u = getUserById($order['user_id']);
        if ($u) {
            $order['client_name']    = $u['name'] ?? ($order['client_name'] ?? 'Client');
            $order['client_email']   = $u['email'] ?? ($u['username'] ?? '');
            $order['client_phone']   = $u['phone'] ?? ($order['client_phone'] ?? '');
            $order['client_company'] = $u['company'] ?? ($order['client_company'] ?? '');
        }
    }

    $finalLink = !empty(trim($cloudLink)) ? trim($cloudLink) : ($order['final_cloud_link'] ?? ($order['delivery_url'] ?? ($order['cloud_link'] ?? '')));
    $delCount = $deliveredImagesCount > 0 ? $deliveredImagesCount : (int)($order['delivered_images_count'] ?? ($order['final_image_count'] ?? ($order['raw_images_count'] ?? 1)));

    $order['status']                 = 'delivered';
    $order['final_cloud_link']       = $finalLink;
    $order['delivered_images_count'] = $delCount;
    $order['updated_at']             = date('c');

    $resNote = !empty(trim($resolutionNotes)) ? trim($resolutionNotes) : "All requested revisions have been completed and verified to studio quality standard.";
    
    // Append resolution message to thread
    $msg = [
        'id'         => generateId(),
        'sender'     => 'admin',
        'type'       => 'amendment_resolved',
        'content'    => "✅ [AMENDMENT COMPLETED FOR JOB #" . strtoupper($orderId) . "]\n" . $resNote,
        'cloud_link' => $finalLink,
        'timestamp'  => date('c'),
    ];
    $order['messages'][] = $msg;
    saveOrder($order);

    // Sync to SaaS Orders pipeline
    $saasFile = DATA_PATH . 'saas_orders.json';
    if (file_exists($saasFile)) {
        $saasOrders = json_decode(@file_get_contents($saasFile), true) ?: [];
        $sChanged = false;
        foreach ($saasOrders as &$so) {
            if (($so['id'] ?? '') === $orderId) {
                $so['delivery_url']      = $finalLink;
                $so['status']            = 'delivered';
                $so['final_image_count'] = $delCount;
                $so['delivered_at']      = date('c');
                $so['updated_at']        = date('c');
                $sChanged = true;
                break;
            }
        }
        unset($so);
        if ($sChanged) {
            @file_put_contents($saasFile, json_encode($saasOrders, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
        }
    }

    // Resolve in AmendmentService
    if (file_exists(__DIR__ . '/services/AmendmentService.php')) {
        require_once __DIR__ . '/services/AmendmentService.php';
        if (class_exists('AmendmentService')) {
            AmendmentService::resolveAmendment($orderId, $resNote);
        }
    }

    // Dispatch official "Amendment Completed" notification email to Client
    if ($sendEmail && file_exists(__DIR__ . '/mail.php')) {
        require_once __DIR__ . '/mail.php';
        if (function_exists('sendAmendmentCompletedEmail')) {
            sendAmendmentCompletedEmail($order, $resNote, $finalLink, $delCount);
        }
    }

    // Discord Alert
    if (file_exists(__DIR__ . '/discord-bot.php')) {
        require_once __DIR__ . '/discord-bot.php';
        if (function_exists('notifyDiscordAmendmentResolved')) {
            notifyDiscordAmendmentResolved($order, $resNote, $finalLink);
        }
    }

    // Add In-App notification
    if (function_exists('addAdminNotification')) {
        addAdminNotification(
            'order',
            "✅ Amendment Delivered: #" . strtoupper($orderId),
            "Revisions completed and delivered to {$order['client_name']}.",
            "/admin/order-view.php?id=" . urlencode($orderId)
        );
    }

    return true;
}

function addOrderAnnotation(string $orderId, float $x, float $y, string $note, string $author = 'client'): bool {
    $order = getOrder($orderId);
    if (!$order) return false;
    $annotation = [
        'id'        => generateId(),
        'x'         => round($x, 2),
        'y'         => round($y, 2),
        'note'      => trim($note),
        'author'    => $author,
        'timestamp' => date('c'),
    ];
    $order['annotations'][] = $annotation;
    $order['updated_at']    = date('c');
    return saveOrder($order);
}

function clearOrderAnnotations(string $orderId): bool {
    $order = getOrder($orderId);
    if (!$order) return false;
    $order['annotations'] = [];
    $order['updated_at']  = date('c');
    return saveOrder($order);
}

function updateOrderStatus(string $orderId, string $status): bool {
    $order = getOrder($orderId);
    if (!$order) return false;
    $prevStatus = strtolower($order['status'] ?? '');
    $newStatus  = strtolower(trim($status));
    $order['status']     = $status;
    $order['updated_at'] = date('c');
    $saved = saveOrder($order);

    // If transitioned to delivered or completed, automatically dispatch delivery email
    if ($saved && in_array($newStatus, ['delivered', 'completed', 'sent_client']) && !in_array($prevStatus, ['delivered', 'completed', 'sent_client'])) {
        if (function_exists('sendOrderDeliveryInvoiceEmail')) {
            $isTrial = !empty($order['is_trial']) || (($order['order_type'] ?? '') === 'free_trial') || str_starts_with(strtoupper($orderId), 'TRIAL-');
            $billedAmount = $isTrial ? 0.0 : (float)($order['billed_amount'] ?? ($order['price_amount'] ?? 0.0));
            $cloudLink    = $order['final_cloud_link'] ?? ($order['delivery_url'] ?? ($order['cloud_link'] ?? ''));
            $delCount     = (int)($order['delivered_images_count'] ?? ($order['final_image_count'] ?? ($order['raw_images_count'] ?? 1)));
            sendOrderDeliveryInvoiceEmail($order, $billedAmount, $cloudLink, $delCount);
        }
    }

    return $saved;
}

function deleteOrder(string $orderId): bool {
    $orderId = trim($orderId);
    if (empty($orderId)) return false;

    // Purge any associated ledger billing entry and restore client balance
    if (function_exists('syncOrderBillingToLedger')) {
        syncOrderBillingToLedger($orderId, 0.0);
    }

    $rawId   = preg_replace('/^TRIAL-/i', '', $orderId);
    $trialId = 'TRIAL-' . strtoupper($rawId);
    
    $deleted = false;
    
    // 1. Delete physical JSON files from data/orders/
    $paths = [
        getOrderPath($orderId),
        getOrderPath($rawId),
        getOrderPath($trialId)
    ];
    foreach ($paths as $p) {
        if (file_exists($p)) {
            if (@unlink($p)) $deleted = true;
        }
    }
    
    // 2. Remove from saas_orders.json
    $saasFile = DATA_PATH . 'saas_orders.json';
    if (file_exists($saasFile)) {
        $saasOrders = readJson($saasFile);
        if (is_array($saasOrders)) {
            $filtered = array_values(array_filter($saasOrders, function($o) use ($orderId, $rawId, $trialId) {
                $oid = $o['id'] ?? '';
                if (strcasecmp($oid, $orderId) === 0) return false;
                if (strcasecmp($oid, $rawId) === 0) return false;
                if (strcasecmp($oid, $trialId) === 0) return false;
                return true;
            }));
            writeJson($saasFile, $filtered);
            $deleted = true;
        }
    }
    
    // 3. Remove from data/leads.json (CRM & Free Trials)
    $leadsFile = defined('LEADS_FILE') ? LEADS_FILE : (rtrim(DATA_PATH, '/') . '/leads.json');
    if (file_exists($leadsFile)) {
        $leads = readJson($leadsFile);
        if (is_array($leads)) {
            $filteredLeads = array_values(array_filter($leads, function($l) use ($orderId, $rawId, $trialId) {
                $lid = $l['id'] ?? '';
                if (strcasecmp($lid, $orderId) === 0) return false;
                if (strcasecmp($lid, $rawId) === 0) return false;
                if (strcasecmp($lid, $trialId) === 0) return false;
                if (strcasecmp('TRIAL-' . $lid, $trialId) === 0) return false;
                return true;
            }));
            writeJson($leadsFile, $filteredLeads);
            $deleted = true;
        }
    }
    
    return $deleted;
}

function purgeAllOrders(): int {
    if (!is_dir(ORDERS_PATH)) return 0;
    $files = glob(ORDERS_PATH . '*.json');
    $count = 0;
    foreach ($files as $f) {
        if (is_file($f)) {
            if (@unlink($f)) $count++;
        }
    }
    
    // Clear SaaS orders list
    $saasFile = DATA_PATH . 'saas_orders.json';
    if (file_exists($saasFile)) {
        writeJson($saasFile, []);
    }
    return $count;
}

function updateOrderAdmin(string $orderId, array $data): bool {
    $order = getOrder($orderId);
    if (!$order) return false;

    $prevStatus = strtolower($order['status'] ?? '');

    if (isset($data['property_name'])) $order['property_name'] = trim($data['property_name']);
    if (isset($data['service_type']))  $order['service_type']  = trim($data['service_type']);
    if (isset($data['status']))        $order['status']        = trim($data['status']);
    if (isset($data['raw_images_count']))       $order['raw_images_count']       = max(0, (int)$data['raw_images_count']);
    if (isset($data['delivered_images_count'])) $order['delivered_images_count'] = max(0, (int)$data['delivered_images_count']);
    if (isset($data['billed_amount']))          $order['billed_amount']          = max(0.0, (float)$data['billed_amount']);
    if (isset($data['cloud_link']))             $order['cloud_link']             = trim($data['cloud_link']);
    if (isset($data['final_cloud_link']))       $order['final_cloud_link']       = trim($data['final_cloud_link']);
    if (isset($data['instructions']))           $order['instructions']           = trim($data['instructions']);
    if (isset($data['turnaround']))             $order['turnaround']             = trim($data['turnaround']);

    $order['updated_at'] = date('c');
    $saved = saveOrder($order);

    $isTrial = !empty($order['is_trial']) || (($order['order_type'] ?? '') === 'free_trial') || str_starts_with(strtoupper($orderId), 'TRIAL-');
    if ($isTrial) {
        $order['billed_amount'] = 0.0;
        syncOrderBillingToLedger($orderId, 0.0);
    } elseif (isset($data['billed_amount'])) {
        $delCount = (int)($order['delivered_images_count'] ?: $order['raw_images_count'] ?: 0);
        syncOrderBillingToLedger($orderId, (float)$data['billed_amount'], $delCount, "Order #{$orderId}: " . ($order['property_name'] ?? 'Property'));
    }

    $newStatus = strtolower($order['status'] ?? '');
    if ($saved && in_array($newStatus, ['delivered', 'completed']) && !in_array($prevStatus, ['delivered', 'completed'])) {
        if (function_exists('sendOrderDeliveryInvoiceEmail')) {
            $billedAmount = (float)($order['billed_amount'] ?? 0.0);
            $cloudLink    = $order['final_cloud_link'] ?? ($order['delivery_url'] ?? ($order['cloud_link'] ?? ''));
            $delCount     = (int)($order['delivered_images_count'] ?: $order['raw_images_count'] ?: 1);
            sendOrderDeliveryInvoiceEmail($order, $billedAmount, $cloudLink, $delCount);
        }
    }

    return $saved;
}

// ══════════════════════════════════════════════════════════
//  LEDGER & BILLING SYSTEM
// ══════════════════════════════════════════════════════════

function getLedger(): array {
    return readJson(LEDGER_FILE);
}

function saveLedger(array $entries): bool {
    return writeJson(LEDGER_FILE, $entries);
}

function deleteLedgerEntry(string $entryId): bool {
    $ledger = getLedger();
    $userId = '';
    foreach ($ledger as $e) {
        if (($e['id'] ?? '') === $entryId) {
            $userId = $e['user_id'] ?? '';
            break;
        }
    }
    $filtered = array_values(array_filter($ledger, fn($e) => ($e['id'] ?? '') !== $entryId));
    if (count($filtered) === count($ledger)) return false;
    $res = saveLedger($filtered);
    if (!empty($userId)) {
        syncUserBalance($userId);
    }
    return $res;
}

function purgeLedger(): bool {
    $res = saveLedger([]);
    $users = getUsers();
    foreach ($users as &$u) {
        $u['balance'] = 0.0;
    }
    saveUsers($users);
    return $res;
}

function getLedgerByUser(string $userId): array {
    $all = getLedger();
    $userEntries = array_values(array_filter($all, fn($e) => ($e['user_id'] ?? '') === $userId));
    usort($userEntries, fn($a, $b) => strcmp($b['created_at'], $a['created_at']));
    return $userEntries;
}

function addLedgerEntry(
    string $userId, 
    ?string $orderId, 
    string $type, 
    float $amount, 
    string $paymentMethod = '', 
    string $notes = '',
    string $createdBy = 'admin'
): array {
    $ledger = getLedger();
    $entry = [
        'id'             => generateId(),
        'user_id'        => $userId,
        'order_id'       => $orderId,
        'type'           => $type, // 'billed' (charge) or 'payment' (paid)
        'amount'         => round(abs($amount), 2),
        'payment_method' => trim($paymentMethod) ?: 'System Ledger',
        'notes'          => trim($notes),
        'created_by'     => $createdBy,
        'created_at'     => date('c'),
    ];
    array_unshift($ledger, $entry);
    saveLedger($ledger);
    syncUserBalance($userId);
    return $entry;
}

function getUserLedger(string $userId): array {
    return getLedgerByUser($userId);
}

/**
 * Recalculates and synchronizes net account balance for a client user.
 * Positive balance = Client owes unpaid charges (Due: -$)
 * Negative balance = Client has advance credit (+Credit)
 */
function syncUserBalance(string $userId): float {
    if (empty($userId)) return 0.0;

    $all = getLedger();
    $totalBilled = 0.0;
    $totalPaid   = 0.0;

    foreach ($all as $entry) {
        if (($entry['user_id'] ?? '') === $userId) {
            $amt = (float)($entry['amount'] ?? 0.0);
            if (($entry['type'] ?? '') === 'billed') {
                $totalBilled += $amt;
            } elseif (($entry['type'] ?? '') === 'payment') {
                $totalPaid += $amt;
            }
        }
    }

    $netBalance = round($totalBilled - $totalPaid, 2);

    // Save to users.json
    $users = getUsers();
    $dirty = false;
    foreach ($users as &$u) {
        if (($u['id'] ?? '') === $userId) {
            $u['balance'] = $netBalance;
            $dirty = true;
            break;
        }
    }
    if ($dirty) {
        saveUsers($users);
    }

    return $netBalance;
}

function getUserBalance(string $userId): array {
    $entries = getLedgerByUser($userId);
    $totalBilled = 0.0;
    $totalPaid   = 0.0;

    foreach ($entries as $e) {
        if (($e['type'] ?? '') === 'billed') {
            $totalBilled += (float)($e['amount'] ?? 0.0);
        } elseif (($e['type'] ?? '') === 'payment') {
            $totalPaid += (float)($e['amount'] ?? 0.0);
        }
    }

    $netBalance = round($totalBilled - $totalPaid, 2);
    $outstanding = max(0.0, $netBalance);

    return [
        'total_billed'        => round($totalBilled, 2),
        'total_paid'          => round($totalPaid, 2),
        'outstanding_balance' => $outstanding,
        'net_balance'         => $netBalance,
    ];
}

function getGlobalFinancialStats(): array {
    $entries = getLedger();
    $totalBilled = 0.0;
    $totalPaid   = 0.0;

    foreach ($entries as $e) {
        if (($e['type'] ?? '') === 'billed') {
            $totalBilled += (float)($e['amount'] ?? 0.0);
        } elseif (($e['type'] ?? '') === 'payment') {
            $totalPaid += (float)($e['amount'] ?? 0.0);
        }
    }

    $outstanding = max(0.0, $totalBilled - $totalPaid);
    return [
        'total_billed'        => round($totalBilled, 2),
        'total_collected'     => round($totalPaid, 2),
        'total_outstanding'   => round($outstanding, 2),
    ];
}

/**
 * Enterprise Ledger Synchronization Engine:
 * Connects order lifecycle (Supervisor Delivery / Editor Count / Admin Updates)
 * directly into financial ledger records and client due balance.
 */
function syncOrderBillingToLedger(
    string $orderId, 
    float $billedAmount, 
    int $deliveredImagesCount = 0, 
    string $notes = ''
): bool {
    $orderId = trim($orderId);
    if (empty($orderId)) return false;

    // 1. Resolve Order details from physical JSON or SaaS pipeline
    $order = getOrder($orderId);
    $userId = $order['user_id'] ?? '';
    $propertyName = $order['property_name'] ?? 'Property Photos';

    $saasFile = defined('SAAS_ORDERS_FILE') ? SAAS_ORDERS_FILE : (DATA_PATH . 'saas_orders.json');
    if (file_exists($saasFile)) {
        $saasOrders = readJson($saasFile) ?: [];
        foreach ($saasOrders as $so) {
            if (($so['id'] ?? '') === $orderId) {
                if (empty($userId)) {
                    $userId = $so['user_id'] ?? $so['client_id'] ?? '';
                }
                $propertyName = $so['property_name'] ?? $propertyName;
                if ($deliveredImagesCount <= 0) {
                    $deliveredImagesCount = (int)($so['final_image_count'] ?? $so['photo_count'] ?? 0);
                }
                break;
            }
        }
    }

    // Lookup user by email if userId is missing or placeholder
    if (empty($userId) || str_starts_with($userId, 'lead-')) {
        $email = $order['client_email'] ?? '';
        if ($email) {
            $userObj = getUserByEmail($email);
            if ($userObj) {
                $userId = $userObj['id'];
            }
        }
    }

    if (empty($userId)) {
        $userId = 'CL-1001';
    }

    // Free Trial Safeguard: Free trials are 100% complimentary ($0.00). Never bill them to ledger!
    $isTrial = !empty($order['is_trial']) || (($order['order_type'] ?? '') === 'free_trial') || str_starts_with(strtoupper($orderId), 'TRIAL-');
    if ($isTrial) {
        $billedAmount = 0.0;
    }

    $billedAmount = round(max(0.0, $billedAmount), 2);
    $ledger = getLedger();
    $foundIndex = -1;

    foreach ($ledger as $idx => $entry) {
        if (($entry['order_id'] ?? '') === $orderId && ($entry['type'] ?? '') === 'billed') {
            $foundIndex = $idx;
            break;
        }
    }

    $descNotes = !empty($notes) ? $notes : "Order #{$orderId}: {$propertyName}";
    if ($deliveredImagesCount > 0 && !str_contains($descNotes, 'Delivered Images')) {
        $descNotes .= " ({$deliveredImagesCount} Delivered Images)";
    }

    if ($foundIndex >= 0) {
        if ($billedAmount > 0) {
            // Update existing billed transaction
            $ledger[$foundIndex]['user_id']        = $userId;
            $ledger[$foundIndex]['amount']         = $billedAmount;
            $ledger[$foundIndex]['notes']          = $descNotes;
            $ledger[$foundIndex]['payment_method'] = $ledger[$foundIndex]['payment_method'] ?? 'Order Billing';
            $ledger[$foundIndex]['updated_at']     = date('c');
        } else {
            // Remove if amount was zeroed out (e.g. Free Trial or cancelled)
            array_splice($ledger, $foundIndex, 1);
        }
    } else {
        if ($billedAmount > 0) {
            $newEntry = [
                'id'             => generateId(),
                'user_id'        => $userId,
                'order_id'       => $orderId,
                'type'           => 'billed',
                'amount'         => $billedAmount,
                'payment_method' => 'Order Billing',
                'notes'          => $descNotes,
                'created_by'     => 'admin',
                'created_at'     => date('c'),
            ];
            array_unshift($ledger, $newEntry);
        }
    }

    saveLedger($ledger);

    // Update physical order JSON if present
    if ($order) {
        $order['billed_amount'] = $billedAmount;
        if ($isTrial) {
            $order['is_trial'] = true;
            $order['order_type'] = 'free_trial';
        }
        if ($deliveredImagesCount > 0) {
            $order['delivered_images_count'] = $deliveredImagesCount;
        }
        $order['updated_at'] = date('c');
        saveOrder($order);
    }

    // Update SaaS Orders JSON if present
    if (file_exists($saasFile)) {
        $saasOrders = readJson($saasFile) ?: [];
        $sDirty = false;
        foreach ($saasOrders as &$so) {
            if (($so['id'] ?? '') === $orderId) {
                $so['price_amount']  = $billedAmount;
                $so['billed_amount'] = $billedAmount;
                if ($isTrial) {
                    $so['is_trial'] = true;
                    $so['order_type'] = 'free_trial';
                }
                if ($deliveredImagesCount > 0) {
                    $so['final_image_count'] = $deliveredImagesCount;
                }
                $so['updated_at'] = date('c');
                $sDirty = true;
                break;
            }
        }
        if ($sDirty) {
            writeJson($saasFile, array_values($saasOrders));
        }
    }

    // Synchronize client balance in users.json
    syncUserBalance($userId);

    return true;
}

/**
 * Self-Healing Reconciliation Engine:
 * Audits all orders and automatically restores any missing ledger records.
 */
function reconcileAllOrdersLedger(): int {
    $orders = getAllOrders();
    $synced = 0;
    $ledger = getLedger();
    $billedOrderIds = [];
    foreach ($ledger as $l) {
        if (($l['type'] ?? '') === 'billed' && !empty($l['order_id'])) {
            $billedOrderIds[$l['order_id']] = (float)($l['amount'] ?? 0.0);
        }
    }

    $ordersToSync = [];
    foreach ($orders as $o) {
        $oid = $o['id'] ?? '';
        if (!$oid) continue;
        $isTrial = !empty($o['is_trial']) || (($o['order_type'] ?? '') === 'free_trial') || str_starts_with(strtoupper($oid), 'TRIAL-');
        if ($isTrial) continue; // Free trial orders must NEVER be reconciled to financial ledger!

        $amt = (float)($o['billed_amount'] ?? 0.0);
        $st  = $o['status'] ?? '';
        $cnt = (int)($o['delivered_images_count'] ?: $o['raw_images_count'] ?: 0);

        if ($amt > 0 && in_array($st, ['delivered', 'sent_client', 'completed'])) {
            if (!isset($billedOrderIds[$oid]) || abs($billedOrderIds[$oid] - $amt) > 0.009) {
                $ordersToSync[$oid] = ['oid' => $oid, 'amt' => $amt, 'cnt' => $cnt];
            }
        }
    }

    $saasFile = defined('SAAS_ORDERS_FILE') ? SAAS_ORDERS_FILE : (DATA_PATH . 'saas_orders.json');
    if (file_exists($saasFile)) {
        $saasOrders = readJson($saasFile) ?: [];
        foreach ($saasOrders as $so) {
            $oid = $so['id'] ?? '';
            if (!$oid || isset($ordersToSync[$oid])) continue;
            $isTrial = !empty($so['is_trial']) || (($so['order_type'] ?? '') === 'free_trial') || str_starts_with(strtoupper($oid), 'TRIAL-');
            if ($isTrial) continue;

            $amt = (float)($so['price_amount'] ?? $so['billed_amount'] ?? 0.0);
            $st  = $so['status'] ?? '';
            $cnt = (int)($so['final_image_count'] ?? $so['photo_count'] ?? 0);
            if ($amt > 0 && in_array($st, ['sent_client', 'completed', 'delivered'])) {
                if (!isset($billedOrderIds[$oid]) || abs($billedOrderIds[$oid] - $amt) > 0.009) {
                    $ordersToSync[$oid] = ['oid' => $oid, 'amt' => $amt, 'cnt' => $cnt];
                }
            }
        }
    }

    if (empty($ordersToSync)) {
        return 0; // Instant 0ms return, no file locks!
    }

    foreach ($ordersToSync as $item) {
        syncOrderBillingToLedger($item['oid'], $item['amt'], $item['cnt']);
        $synced++;
    }

    return $synced;
}

/**
 * Enterprise Payment Recording:
 * Marks an order as paid in both physical JSON order and SaaS pipeline,
 * logs the payment transaction to the financial ledger, and syncs client balance.
 */
function markOrderPaid(string $orderId, ?float $amount = null, string $paymentMethod = 'PayPal', string $note = ''): bool {
    $orderId = trim($orderId);
    if (empty($orderId)) return false;

    $order = getOrder($orderId);
    $saasFile = defined('SAAS_ORDERS_FILE') ? SAAS_ORDERS_FILE : (DATA_PATH . 'saas_orders.json');
    $saasOrders = file_exists($saasFile) ? (readJson($saasFile) ?: []) : [];
    
    $targetSoIndex = -1;
    $targetSo = null;
    foreach ($saasOrders as $idx => $so) {
        if (($so['id'] ?? '') === $orderId) {
            $targetSo = $so;
            $targetSoIndex = $idx;
            break;
        }
    }

    $userId = $order['user_id'] ?? ($targetSo['user_id'] ?? ($targetSo['client_id'] ?? ''));
    if (empty($userId) || str_starts_with($userId, 'lead-')) {
        $email = $order['client_email'] ?? ($targetSo['client_email'] ?? '');
        if ($email && function_exists('getUserByEmail')) {
            $u = getUserByEmail($email);
            if ($u) $userId = $u['id'];
        }
    }
    if (empty($userId)) $userId = 'CL-1001';

    $payAmt = $amount !== null ? (float)$amount : (float)($order['billed_amount'] ?? ($targetSo['price_amount'] ?? 0.0));
    $payAmt = round(max(0.0, $payAmt), 2);

    $payNote = !empty($note) ? $note : "Payment of \$" . number_format($payAmt, 2) . " received for Order #{$orderId} via {$paymentMethod}";
    
    // Add payment entry to ledger
    addLedgerEntry($userId, $orderId, 'payment', $payAmt, $paymentMethod, $payNote);

    // Update physical order
    if ($order) {
        $order['payment_status'] = 'paid';
        $order['paid_at']        = date('c');
        $order['paid_amount']    = $payAmt;
        if (!isset($order['messages'])) $order['messages'] = [];
        $order['messages'][] = [
            'id'        => generateId(),
            'sender'    => 'admin',
            'type'      => 'payment_confirmed',
            'content'   => "Payment of \$" . number_format($payAmt, 2) . " USD received and verified via {$paymentMethod}. Thank you! Clean deliverables without watermark are now cleared for dispatch.",
            'timestamp' => date('c'),
        ];
        saveOrder($order);
    }

    // Update SaaS Orders
    if ($targetSoIndex >= 0) {
        $saasOrders[$targetSoIndex]['payment_status'] = 'paid';
        $saasOrders[$targetSoIndex]['paid_at']        = date('c');
        $saasOrders[$targetSoIndex]['paid_amount']    = $payAmt;
        writeJson($saasFile, array_values($saasOrders));
    }

    syncUserBalance($userId);
    return true;
}

// ══════════════════════════════════════════════════════════
//  STATUS HELPERS
// ══════════════════════════════════════════════════════════

function statusLabel(string $status): string {
    return match($status) {
        'pending'                                  => 'Pending',
        'in_progress'                              => 'In Production',
        'watermarked_delivered', 'sent_watermarked'=> '💧 Watermarked Proof Sent',
        'delivered', 'sent_client', 'completed'    => '✨ Final Delivered',
        'amendment_requested', 'revision_required' => 'Revision Requested',
        default                                    => ucfirst(str_replace('_', ' ', $status)),
    };
}

function statusClass(string $status): string {
    return match($status) {
        'pending'                                  => 'badge-pending',
        'in_progress'                              => 'badge-inprogress',
        'watermarked_delivered', 'sent_watermarked'=> 'badge-amendment',
        'delivered', 'sent_client', 'completed'    => 'badge-delivered',
        'amendment_requested', 'revision_required' => 'badge-amendment',
        default                                    => 'badge-pending',
    };
}

function statusBadgeClass(string $status): string {
    return match($status) {
        'delivered', 'sent_client', 'completed'    => 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold',
        'watermarked_delivered', 'sent_watermarked'=> 'bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold',
        'in_progress'                              => 'bg-blue-500/20 text-blue-400 border border-blue-500/30 font-bold',
        'pending'                                  => 'bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold',
        'amendment_requested', 'revision_required' => 'bg-red-500/20 text-red-400 border border-red-500/30 font-bold',
        default                                    => 'bg-gray-500/20 text-gray-400 border border-gray-500/30 font-bold',
    };
}

/**
 * Enterprise Financial & Category Resolution:
 * Classifies any order into:
 *  - Category: Free Trial ($0.00) vs Live Order (Commercial)
 *  - Payment Status: Cleared / Paid vs Balance Due vs Complimentary Free Trial vs In Production
 */
function getOrderFinancialStatus(array $order, ?array $ledgerEntries = null): array {
    $oid = $order['id'] ?? $order['order_id'] ?? '';
    $userId = $order['user_id'] ?? $order['client_id'] ?? '';
    $isTrial = !empty($order['is_trial']) 
        || (($order['order_type'] ?? '') === 'free_trial') 
        || (($order['service_type'] ?? '') === 'free_trial') 
        || stripos($oid, 'TRIAL-') === 0;

    $billedAmt = (float)($order['billed_amount'] ?? $order['price_amount'] ?? 0.0);
    $status = strtolower($order['status'] ?? 'pending');
    $isDelivered = in_array($status, ['delivered', 'sent_client', 'completed']);
    $isWatermarked = in_array($status, ['watermarked_delivered', 'sent_watermarked']);

    if ($isTrial) {
        return [
            'is_trial'        => true,
            'order_type'      => 'free_trial',
            'category_key'    => 'free_trial',
            'category_label'  => 'Free Trial',
            'category_badge'  => '<span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm"><span>🎁</span> <span>FREE TRIAL</span></span>',
            'amount'          => 0.0,
            'cleared'         => true,
            'payment_status'  => 'cleared',
            'payment_label'   => 'Complimentary ($0.00)',
            'payment_badge'   => '<span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/15 text-emerald-400 border border-emerald-500/30"><span>🎁</span> <span>$0.00 FREE</span></span>',
        ];
    }

    // Live order
    static $userBalanceMap = null;
    if ($userBalanceMap === null) {
        $ledger = $ledgerEntries ?? getLedger();
        $userBalanceMap = [];
        foreach ($ledger as $e) {
            $uid = $e['user_id'] ?? '';
            if (!$uid) continue;
            if (!isset($userBalanceMap[$uid])) {
                $userBalanceMap[$uid] = ['billed' => 0.0, 'paid' => 0.0];
            }
            $amt = (float)($e['amount'] ?? 0.0);
            if (($e['type'] ?? '') === 'billed') {
                $userBalanceMap[$uid]['billed'] += $amt;
            } elseif (($e['type'] ?? '') === 'payment') {
                $userBalanceMap[$uid]['paid'] += $amt;
            }
        }
    }

    $cBal = $userBalanceMap[$userId] ?? ['billed' => 0.0, 'paid' => 0.0];
    $due = round(max(0.0, $cBal['billed'] - $cBal['paid']), 2);
    $hasDue = $due > 0.009;
    $isExplicitlyPaid = (($order['payment_status'] ?? '') === 'paid');

    if ($isWatermarked) {
        if ($hasDue && !$isExplicitlyPaid) {
            return [
                'is_trial'        => false,
                'order_type'      => 'live_order',
                'category_key'    => 'live_order',
                'category_label'  => 'Live Order',
                'category_badge'  => '<span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-blue-500/20 text-blue-300 border border-blue-500/40 shadow-sm"><span>⚡</span> <span>LIVE ORDER</span></span>',
                'amount'          => $billedAmt,
                'cleared'         => false,
                'payment_status'  => 'pending',
                'payment_label'   => 'Watermark Sent (Due $' . number_format($due > 0 ? $due : $billedAmt, 2) . ')',
                'payment_badge'   => '<span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm"><span>💧</span> <span>WATERMARK PROOF (DUE $' . number_format($due > 0 ? $due : $billedAmt, 2) . ')</span></span>',
            ];
        } else {
            return [
                'is_trial'        => false,
                'order_type'      => 'live_order',
                'category_key'    => 'live_order',
                'category_label'  => 'Live Order',
                'category_badge'  => '<span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-blue-500/20 text-blue-300 border border-blue-500/40 shadow-sm"><span>⚡</span> <span>LIVE ORDER</span></span>',
                'amount'          => $billedAmt,
                'cleared'         => true,
                'payment_status'  => 'cleared',
                'payment_label'   => 'Paid (Ready for Final Release)',
                'payment_badge'   => '<span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-sm"><span>✅</span> <span>PAID (READY FINAL)</span></span>',
            ];
        }
    }

    $cBal = $userBalanceMap[$userId] ?? ['billed' => 0.0, 'paid' => 0.0];
    $due = round(max(0.0, $cBal['billed'] - $cBal['paid']), 2);
    $hasDue = $due > 0.009;

    if ($isDelivered) {
        if ($hasDue) {
            return [
                'is_trial'        => false,
                'order_type'      => 'live_order',
                'category_key'    => 'live_order',
                'category_label'  => 'Live Order',
                'category_badge'  => '<span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-blue-500/20 text-blue-300 border border-blue-500/40 shadow-sm"><span>⚡</span> <span>LIVE ORDER</span></span>',
                'amount'          => $billedAmt,
                'cleared'         => false,
                'payment_status'  => 'pending',
                'payment_label'   => 'Due ($' . number_format($due, 2) . ')',
                'payment_badge'   => '<span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm"><span>⏳</span> <span>DUE $' . number_format($due, 2) . '</span></span>',
            ];
        } else {
            return [
                'is_trial'        => false,
                'order_type'      => 'live_order',
                'category_key'    => 'live_order',
                'category_label'  => 'Live Order',
                'category_badge'  => '<span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-blue-500/20 text-blue-300 border border-blue-500/40 shadow-sm"><span>⚡</span> <span>LIVE ORDER</span></span>',
                'amount'          => $billedAmt,
                'cleared'         => true,
                'payment_status'  => 'cleared',
                'payment_label'   => 'Cleared / Paid',
                'payment_badge'   => '<span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-green-500/20 text-green-400 border border-green-500/40 shadow-sm"><span>✅</span> <span>CLEARED</span></span>',
            ];
        }
    } else {
        return [
            'is_trial'        => false,
            'order_type'      => 'live_order',
            'category_key'    => 'live_order',
            'category_label'  => 'Live Order',
            'category_badge'  => '<span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-blue-500/20 text-blue-300 border border-blue-500/40 shadow-sm"><span>⚡</span> <span>LIVE ORDER</span></span>',
            'amount'          => $billedAmt,
            'cleared'         => false,
            'payment_status'  => 'in_production',
            'payment_label'   => 'In Production',
            'payment_badge'   => '<span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/15 text-blue-300 border border-blue-500/30"><span>🔄</span> <span>IN PRODUCTION</span></span>',
        ];
    }
}

// ══════════════════════════════════════════════════════════
//  LEADS / FREE TRIAL REQUESTS
// ══════════════════════════════════════════════════════════

function getLeads(): array {
    return readJson(LEADS_FILE);
}

function saveLead($nameOrData, string $email = '', string $phone = '', string $service = '', string $cloudLink = '', string $message = ''): array {
    $leads = getLeads();

    // ── Idempotency / Double-Submit Protection ────────────────────────
    $now = time();
    $checkEmail = is_array($nameOrData) ? strtolower(trim($nameOrData['email'] ?? '')) : strtolower(trim($email));
    $checkCloud = is_array($nameOrData) ? trim($nameOrData['cloud_link'] ?? '') : trim($cloudLink);
    if (!empty($checkEmail)) {
        foreach ($leads as $existingLead) {
            $createdAt = strtotime($existingLead['created_at'] ?? '1970-01-01');
            if (($now - $createdAt) < 60) {
                if (strtolower(trim($existingLead['email'] ?? '')) === $checkEmail &&
                    trim($existingLead['cloud_link'] ?? '') === $checkCloud) {
                    error_log("Prevented duplicate lead submission for {$checkEmail}. Returning existing lead {$existingLead['id']}.");
                    return $existingLead;
                }
            }
        }
    }

    if (is_array($nameOrData)) {
        $data = $nameOrData;
        $lead = [
            'id'         => generateClientId(),
            'name'       => trim($data['name'] ?? 'Prospective Client'),
            'email'      => strtolower(trim($data['email'] ?? '')),
            'phone'      => trim($data['phone'] ?? ($data['whatsapp'] ?? '')),
            'service'    => trim($data['service'] ?? ($data['source'] ?? 'General Inquiry')),
            'cloud_link' => trim($data['cloud_link'] ?? ''),
            'message'    => trim($data['message'] ?? ($data['notes'] ?? '')),
            'status'     => $data['status'] ?? 'new',
            'created_at' => $data['created_at'] ?? date('c'),
        ];
    } else {
        $lead = [
            'id'         => generateClientId(),
            'name'       => trim($nameOrData),
            'email'      => strtolower(trim($email)),
            'phone'      => trim($phone),
            'service'    => trim($service),
            'cloud_link' => trim($cloudLink),
            'message'    => trim($message),
            'status'     => 'new',
            'created_at' => date('c'),
        ];
    }

    array_unshift($leads, $lead);
    saveLeads($leads);

    // Send email notification to info@estatehdr.com
    if (!empty($lead['email'])) {
        $to = CONTACT_EMAIL;
        $subject = "New Free Trial / CRM Lead from {$lead['name']} - Estate HDR";
        $body = "You have received a new Lead Submission:\n\n" .
                "Name: {$lead['name']}\n" .
                "Email: {$lead['email']}\n" .
                "WhatsApp/Phone: {$lead['phone']}\n" .
                "Service Requested: {$lead['service']}\n" .
                "Cloud Storage Link: {$lead['cloud_link']}\n" .
                "Instructions/Message:\n{$lead['message']}\n\n" .
                "Submitted At: " . date('Y-m-d H:i:s T') . "\n";
        $headers = "From: no-reply@estatehdr.com\r\n" .
                   "Reply-To: {$lead['email']}\r\n" .
                   "X-Mailer: PHP/" . phpversion();

        @mail($to, $subject, $body, $headers);
    }

    return $lead;
}

// ══════════════════════════════════════════════════════════
//  ADMIN PROFILE & SETTINGS
// ══════════════════════════════════════════════════════════

function getAdminSettings(): array {
    $path = DATA_PATH . 'admin.json';
    $defaults = [
        'email'         => ADMIN_EMAIL,
        'password_hash' => ADMIN_PASSWORD_HASH,
        'contact_email' => CONTACT_EMAIL,
        'whatsapp'      => WHATSAPP_NUMBER,
        'tawkto_id'     => '',
        'updated_at'    => date('c'),
    ];
    if (!file_exists($path)) return $defaults;
    return array_merge($defaults, readJson($path));
}

function updateAdminPassword(string $newPassword): bool {
    $settings = getAdminSettings();
    $settings['password_hash'] = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => 12]);
    $settings['updated_at']    = date('c');
    return writeJson(DATA_PATH . 'admin.json', $settings);
}

function updateAdminSettings(string $email, string $contactEmail, string $whatsapp, string $tawktoId = ''): bool {
    $settings = getAdminSettings();
    $settings['email']         = strtolower(trim($email));
    $settings['contact_email'] = strtolower(trim($contactEmail));
    $settings['whatsapp']      = trim($whatsapp);
    $settings['tawkto_id']     = trim($tawktoId);
    $settings['updated_at']    = date('c');
    return writeJson(DATA_PATH . 'admin.json', $settings);
}

function verifyAdminPassword(string $inputPassword): bool {
    $settings = getAdminSettings();
    return password_verify($inputPassword, $settings['password_hash']) || 
           password_verify($inputPassword, ADMIN_PASSWORD_HASH);
}

// ══════════════════════════════════════════════════════════
//  JOB STATISTICS & PORTAL HELPERS
// ══════════════════════════════════════════════════════════

function getJobStatistics(string $userId = ''): array {
    $orders = $userId ? getOrdersByUser($userId) : getAllOrders();
    $stats = [
        'Photo Enhancement HDR'   => ['jobs' => 0, 'amount' => 0.0, 'photos' => 0],
        'Virtual Staging'          => ['jobs' => 0, 'amount' => 0.0, 'photos' => 0],
        '2D / 3D Floor Plans'      => ['jobs' => 0, 'amount' => 0.0, 'photos' => 0],
        'Item Removal'             => ['jobs' => 0, 'amount' => 0.0, 'photos' => 0],
        'Day to Dusk'              => ['jobs' => 0, 'amount' => 0.0, 'photos' => 0],
        'Virtual Twilight'         => ['jobs' => 0, 'amount' => 0.0, 'photos' => 0],
        'Virtual Renovation'       => ['jobs' => 0, 'amount' => 0.0, 'photos' => 0],
    ];

    $totalJobs = 0;
    $totalAmount = 0.0;
    $totalPhotos = 0;

    foreach ($orders as $o) {
        $service = $o['service_type'] ?? 'Photo Enhancement HDR';
        if (!isset($stats[$service])) {
            $stats[$service] = ['jobs' => 0, 'amount' => 0.0, 'photos' => 0];
        }
        $amount = (float)($o['billed_amount'] ?? 0.0);
        $photos = (int)($o['delivered_images_count'] ?: $o['raw_images_count'] ?: 0);

        $stats[$service]['jobs']++;
        $stats[$service]['amount'] += $amount;
        $stats[$service]['photos'] += $photos;

        $totalJobs++;
        $totalAmount += $amount;
        $totalPhotos += $photos;
    }

    return [
        'breakdown'    => $stats,
        'total_jobs'   => $totalJobs,
        'total_amount' => $totalAmount,
        'total_photos' => $totalPhotos,
    ];
}

function getPendingOrders(string $userId = ''): array {
    $orders = $userId ? getOrdersByUser($userId) : getAllOrders();
    return array_values(array_filter($orders, function($o) {
        return in_array($o['status'], ['pending', 'in_progress', 'amendment_requested', 'quality_checking']);
    }));
}

function getCompletedOrders(string $userId = ''): array {
    $orders = $userId ? getOrdersByUser($userId) : getAllOrders();
    return array_values(array_filter($orders, function($o) {
        return in_array($o['status'], ['delivered', 'completed']);
    }));
}

function getAllAmendmentOrders(): array {
    $orders = getAllOrders();
    return array_values(array_filter($orders, function($o) {
        return $o['status'] === 'amendment_requested' || !empty($o['annotations']);
    }));
}

// ══════════════════════════════════════════════════════════
//  SEO & PAGES MANAGEMENT ENGINE
// ══════════════════════════════════════════════════════════

function getPagesSeo(): array {
    $file = DATA_PATH . '/pages_seo.json';
    if (!file_exists($file)) return [];
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : [];
}

function savePagesSeo(array $pages): void {
    atomicWriteJson(DATA_PATH . '/pages_seo.json', $pages);
}

function getPageSeo(string $slug): ?array {
    $pages = getPagesSeo();
    foreach ($pages as $p) {
        if ($p['slug'] === $slug || $p['id'] === $slug) {
            return $p;
        }
    }
    return null;
}

function updatePageSeo(string $slug, array $data): bool {
    $pages = getPagesSeo();
    $found = false;
    foreach ($pages as &$p) {
        if ($p['slug'] === $slug || $p['id'] === $slug) {
            $p = array_merge($p, $data);
            $p['updated_at'] = date('c');
            $found = true;
            break;
        }
    }
    if (!$found) {
        $data['id'] = $slug;
        $data['slug'] = $slug;
        $data['updated_at'] = date('c');
        $pages[] = $data;
    }
    savePagesSeo($pages);
    return true;
}

// ══════════════════════════════════════════════════════════
//  CATEGORIES & TAXONOMIES ENGINE
// ══════════════════════════════════════════════════════════

function getCategories(?string $type = null): array {
    $file = DATA_PATH . '/categories.json';
    if (!file_exists($file)) return [];
    $data = json_decode(file_get_contents($file), true);
    if (!is_array($data)) return [];
    
    // Ensure all items have a type
    foreach ($data as &$c) {
        if (empty($c['type'])) {
            $c['type'] = 'post';
        }
    }
    unset($c);

    if ($type !== null) {
        return array_values(array_filter($data, fn($c) => ($c['type'] ?? 'post') === $type));
    }
    return $data;
}

function getPageCategories(): array {
    return getCategories('page');
}

function getPostCategories(): array {
    return getCategories('post');
}

function saveCategories(array $categories): void {
    atomicWriteJson(DATA_PATH . '/categories.json', $categories);
}

function addCategory(string $name, string $slug = '', string $parentId = '', string $desc = '', string $type = 'post'): array {
    $cats = getCategories();
    $slugClean = trim($slug) ?: strtolower(preg_replace('/[^a-z0-9]+/', '-', trim($name)));
    $id = 'cat-' . ($type === 'page' ? 'page-' : '') . preg_replace('/[^a-z0-9]/', '', strtolower($slugClean));
    
    $newCat = [
        'id'           => $id ?: generateId(),
        'name'         => trim($name),
        'slug'         => $slugClean,
        'parent_id'    => $parentId,
        'description'  => trim($desc),
        'type'         => in_array($type, ['page', 'post']) ? $type : 'post',
        'noindex_tags' => false
    ];
    $cats[] = $newCat;
    saveCategories($cats);
    return $newCat;
}

function updateCategory(string $id, array $data): bool {
    $cats = getCategories();
    $found = false;
    foreach ($cats as &$c) {
        if ($c['id'] === $id) {
            if (isset($data['name']))        $c['name']        = trim($data['name']);
            if (isset($data['slug']))        $c['slug']        = trim($data['slug']);
            if (isset($data['parent_id']))   $c['parent_id']   = trim($data['parent_id']);
            if (isset($data['description'])) $c['description'] = trim($data['description']);
            if (isset($data['type']))        $c['type']        = trim($data['type']);
            $found = true;
            break;
        }
    }
    unset($c);
    if ($found) {
        saveCategories($cats);
    }
    return $found;
}

function deleteCategory(string $id): bool {
    $cats = getCategories();
    $filtered = array_values(array_filter($cats, fn($c) => $c['id'] !== $id));
    if (count($filtered) === count($cats)) return false;
    saveCategories($filtered);
    return true;
}

// ══════════════════════════════════════════════════════════
//  SEO GENERAL SETTINGS & SEARCH CONSOLE ENGINE
// ══════════════════════════════════════════════════════════

function getSeoSettings(): array {
    $file = DATA_PATH . '/seo_settings.json';
    $robotsFile = defined('ROOT_PATH') ? (rtrim(ROOT_PATH, '/') . '/robots.txt') : (dirname(__DIR__) . '/robots.txt');

    $defaults = [
        'google_site_verification' => '',
        'bing_site_verification'   => '',
        'pinterest_verification'   => '',
        'yandex_verification'      => '',
        'site_name_suffix'         => ' | Estate HDR',
        'default_meta_title'       => 'Estate HDR — High-Converting Real Estate Photo Editing & Virtual Staging',
        'default_meta_description' => 'Professional HDR photo editing, virtual staging, and twilight conversions for real estate photographers and agents worldwide.',
        'default_og_image'         => '/assets/images/portfolio/hdr/1-after.jpg',
        'robots_txt'               => "User-agent: *\nAllow: /\nDisallow: /admin/\nDisallow: /api/\nDisallow: /data/\nDisallow: /cron/\n\nSitemap: https://estatehdr.com/sitemap.xml\nSitemap: https://estatehdr.com/sitemap-pages.xml"
    ];

    if (file_exists($file)) {
        $data = json_decode(file_get_contents($file), true);
        if (is_array($data)) {
            $defaults = array_merge($defaults, $data);
        }
    }

    return $defaults;
}

function saveSeoSettings(array $settings): bool {
    $saved = atomicWriteJson(DATA_PATH . '/seo_settings.json', $settings);

    // Physically write and update robots.txt on server root
    if (isset($settings['robots_txt'])) {
        $robotsFile = defined('ROOT_PATH') ? (rtrim(ROOT_PATH, '/') . '/robots.txt') : (dirname(__DIR__) . '/robots.txt');
        @file_put_contents($robotsFile, $settings['robots_txt']);
    }

    return $saved;
}

// ══════════════════════════════════════════════════════════
//  CUSTOM SITEMAP MANAGER & GENERATOR
// ══════════════════════════════════════════════════════════

function getCustomSitemap(): array {
    $file = DATA_PATH . '/custom_sitemap.json';
    if (!file_exists($file)) return [];
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : [];
}

function saveCustomSitemap(array $items): bool {
    return atomicWriteJson(DATA_PATH . '/custom_sitemap.json', $items);
}

function addCustomSitemapUrl($urlOrData, string $lastmod = '', string $changefreq = 'weekly', string $priority = '0.80', string $title = ''): array {
    $items = getCustomSitemap();

    if (is_array($urlOrData)) {
        $url = $urlOrData['url'] ?? '';
        $lastmod = $urlOrData['lastmod'] ?? '';
        $changefreq = $urlOrData['changefreq'] ?? 'weekly';
        $priority = $urlOrData['priority'] ?? '0.80';
        $title = $urlOrData['title'] ?? '';
    } else {
        $url = (string)$urlOrData;
    }

    $item = [
        'id'         => 'csm-' . time() . '-' . rand(100, 999),
        'url'        => trim($url),
        'lastmod'    => !empty($lastmod) ? trim($lastmod) : date('Y-m-d'),
        'changefreq' => in_array($changefreq, ['always','hourly','daily','weekly','monthly','yearly','never']) ? $changefreq : 'weekly',
        'priority'   => trim($priority) ?: '0.80',
        'title'      => trim($title)
    ];
    $items[] = $item;
    saveCustomSitemap($items);
    return $item;
}

// ══════════════════════════════════════════════════════════
//  GOOGLE SEARCH CONSOLE DISAVOW ENGINE & SPAM SHIELD
// ══════════════════════════════════════════════════════════

function getDisavowFilePath(): string {
    return defined('ROOT_PATH') ? (rtrim(ROOT_PATH, '/') . '/disavow.txt') : (dirname(__DIR__) . '/disavow.txt');
}

function getDisavowContent(): string {
    $file = getDisavowFilePath();
    if (file_exists($file)) {
        return (string)file_get_contents($file);
    }
    return "# Estate HDR Official Google Disavow File\n\ndomain:chordmp3.net\ndomain:fittyfoody.com\ndomain:bazerdaily.com\ndomain:onlyhealthydeals.com\ndomain:hostprinter.com\ndomain:digitalseotool.com\ndomain:cindylaup.com\n";
}

function saveDisavowContent(string $content): bool {
    $file = getDisavowFilePath();
    return @file_put_contents($file, $content) !== false;
}

function getDisavowSummary(): array {
    $content = getDisavowContent();
    $lines = explode("\n", $content);
    $domains = [];
    $urls = [];

    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line) || str_starts_with($line, '#')) continue;
        if (str_starts_with($line, 'domain:')) {
            $domains[] = trim(substr($line, 7));
        } else {
            $urls[] = $line;
        }
    }

    return [
        'total_rules'   => count($domains) + count($urls),
        'domain_count'  => count($domains),
        'url_count'     => count($urls),
        'domains'       => $domains,
        'urls'          => $urls,
        'last_modified' => file_exists(getDisavowFilePath()) ? date('Y-m-d H:i:s', filemtime(getDisavowFilePath())) : 'Never'
    ];
}

function renderSeoHeadTags(array $pageMeta = []): string {
    $seo = getSeoSettings();
    $html = "\n<!-- Dynamic Search Console & Verification Meta Tags -->\n";

    if (!empty($seo['google_site_verification'])) {
        $gTag = trim($seo['google_site_verification']);
        if (str_contains($gTag, '<meta')) {
            $html .= $gTag . "\n";
        } else {
            $html .= '<meta name="google-site-verification" content="' . htmlspecialchars($gTag) . '">' . "\n";
        }
    }

    if (!empty($seo['bing_site_verification'])) {
        $bTag = trim($seo['bing_site_verification']);
        if (str_contains($bTag, '<meta')) {
            $html .= $bTag . "\n";
        } else {
            $html .= '<meta name="msvalidate.01" content="' . htmlspecialchars($bTag) . '">' . "\n";
        }
    }

    if (!empty($seo['pinterest_verification'])) {
        $pTag = trim($seo['pinterest_verification']);
        if (str_contains($pTag, '<meta')) {
            $html .= $pTag . "\n";
        } else {
            $html .= '<meta name="p:domain_verify" content="' . htmlspecialchars($pTag) . '">' . "\n";
        }
    }

    if (!empty($seo['yandex_verification'])) {
        $yTag = trim($seo['yandex_verification']);
        if (str_contains($yTag, '<meta')) {
            $html .= $yTag . "\n";
        } else {
            $html .= '<meta name="yandex-verification" content="' . htmlspecialchars($yTag) . '">' . "\n";
        }
    }

    $bUrl = defined('BASE_URL') ? rtrim(BASE_URL, '/') : 'https://estatehdr.com';
    $reqUri = $_SERVER['REQUEST_URI'] ?? '/';
    $canonicalUrl = $bUrl . $reqUri;

    // Multi-Region Global Real Estate Hreflang Tags
    $html .= '<link rel="alternate" hreflang="en-US" href="' . htmlspecialchars($canonicalUrl) . '">' . "\n";
    $html .= '<link rel="alternate" hreflang="en-GB" href="' . htmlspecialchars($canonicalUrl) . '">' . "\n";
    $html .= '<link rel="alternate" hreflang="en-AU" href="' . htmlspecialchars($canonicalUrl) . '">' . "\n";
    $html .= '<link rel="alternate" hreflang="en-CA" href="' . htmlspecialchars($canonicalUrl) . '">' . "\n";
    $html .= '<link rel="alternate" hreflang="x-default" href="' . htmlspecialchars($canonicalUrl) . '">' . "\n";

    // AI & LLM Search Engine Discovery Protocol
    $html .= '<link rel="alternate" type="text/plain" title="LLMs.txt" href="' . $bUrl . '/llms.txt">' . "\n";

    // RSS & Atom Feeds
    $html .= '<link rel="alternate" type="application/rss+xml" title="Estate HDR RSS Feed" href="' . $bUrl . '/rss.xml">' . "\n";
    $html .= '<link rel="alternate" type="application/atom+xml" title="Estate HDR Atom Feed" href="' . $bUrl . '/rss.xml">' . "\n";

    return $html;
}

function deleteCustomSitemapUrl(string $id): bool {
    $items = getCustomSitemap();
    $filtered = array_values(array_filter($items, fn($i) => ($i['id'] ?? '') !== $id));
    if (count($filtered) === count($items)) return false;
    saveCustomSitemap($filtered);
    return true;
}

function buildSitemapXml(string $type = 'all'): string {
    $baseUrl = rtrim(BASE_URL, '/');
    $pages = getPagesSeo();
    $posts = getPublishedBlogs();
    $pageCategories = getPageCategories();
    $postCategories = getPostCategories();
    $services = getServices();
    $custom = getCustomSitemap();

    if ($type === 'index') {
        $xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
        $xml .= "<sitemapindex xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";
        $xml .= "  <sitemap>\n    <loc>{$baseUrl}/sitemap-pages.xml</loc>\n    <lastmod>" . date('Y-m-d') . "</lastmod>\n  </sitemap>\n";
        $xml .= "  <sitemap>\n    <loc>{$baseUrl}/sitemap-posts.xml</loc>\n    <lastmod>" . date('Y-m-d') . "</lastmod>\n  </sitemap>\n";
        if (count($custom) > 0) {
            $xml .= "  <sitemap>\n    <loc>{$baseUrl}/sitemap-custom.xml</loc>\n    <lastmod>" . date('Y-m-d') . "</lastmod>\n  </sitemap>\n";
        }
        $xml .= "</sitemapindex>\n";
        return $xml;
    }

    $xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    $xml .= "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\"\n";
    $xml .= "        xmlns:image=\"http://www.google.com/schemas/sitemap-image/1.1\">\n\n";

    if ($type === 'all' || $type === 'pages') {
        $xml .= "  <!-- Core Static Pages -->\n";
        $xml .= "  <url>\n    <loc>{$baseUrl}/</loc>\n    <lastmod>" . date('Y-m-d') . "</lastmod>\n    <changefreq>daily</changefreq>\n    <priority>1.0</priority>\n  </url>\n";
        $xml .= "  <url>\n    <loc>{$baseUrl}/real-estate-photo-editing</loc>\n    <lastmod>" . date('Y-m-d') . "</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.98</priority>\n  </url>\n";
        $xml .= "  <url>\n    <loc>{$baseUrl}/pricing</loc>\n    <lastmod>" . date('Y-m-d') . "</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.95</priority>\n  </url>\n";
        $xml .= "  <url>\n    <loc>{$baseUrl}/portfolio</loc>\n    <lastmod>" . date('Y-m-d') . "</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.90</priority>\n  </url>\n";
        $xml .= "  <url>\n    <loc>{$baseUrl}/blog</loc>\n    <lastmod>" . date('Y-m-d') . "</lastmod>\n    <changefreq>daily</changefreq>\n    <priority>0.90</priority>\n  </url>\n";
        $xml .= "  <url>\n    <loc>{$baseUrl}/team</loc>\n    <lastmod>" . date('Y-m-d') . "</lastmod>\n    <changefreq>monthly</changefreq>\n    <priority>0.85</priority>\n  </url>\n";
        $xml .= "  <url>\n    <loc>{$baseUrl}/about</loc>\n    <lastmod>" . date('Y-m-d') . "</lastmod>\n    <changefreq>monthly</changefreq>\n    <priority>0.80</priority>\n  </url>\n";
        $xml .= "  <url>\n    <loc>{$baseUrl}/contact</loc>\n    <lastmod>" . date('Y-m-d') . "</lastmod>\n    <changefreq>monthly</changefreq>\n    <priority>0.85</priority>\n  </url>\n";
        $xml .= "  <url>\n    <loc>{$baseUrl}/alternatives</loc>\n    <lastmod>" . date('Y-m-d') . "</lastmod>\n    <changefreq>monthly</changefreq>\n    <priority>0.75</priority>\n  </url>\n";
        $xml .= "  <url>\n    <loc>{$baseUrl}/sitemap</loc>\n    <lastmod>" . date('Y-m-d') . "</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.50</priority>\n  </url>\n";
        $xml .= "  <url>\n    <loc>{$baseUrl}/editorial-guidelines</loc>\n    <lastmod>" . date('Y-m-d') . "</lastmod>\n    <changefreq>monthly</changefreq>\n    <priority>0.40</priority>\n  </url>\n";
        $xml .= "  <url>\n    <loc>{$baseUrl}/terms</loc>\n    <lastmod>" . date('Y-m-d') . "</lastmod>\n    <changefreq>yearly</changefreq>\n    <priority>0.30</priority>\n  </url>\n";
        $xml .= "  <url>\n    <loc>{$baseUrl}/privacy</loc>\n    <lastmod>" . date('Y-m-d') . "</lastmod>\n    <changefreq>yearly</changefreq>\n    <priority>0.30</priority>\n  </url>\n";

        // Dynamic Pages
        foreach ($pages as $p) {
            if (!empty($p['exclude_sitemap'])) continue;
            if (str_contains(strtolower($p['robots'] ?? ''), 'noindex')) continue;
            if (($p['status'] ?? 'published') === 'draft') continue;
            // Prevent duplicate entries for pages already present in core static sitemap
            if (in_array($p['slug'] ?? '', ['home', 'contact', 'about-us', 'services', 'pricing'])) continue;
            if (!empty($p['canonical_url']) && in_array(rtrim($p['canonical_url'], '/'), [
                $baseUrl, 
                $baseUrl . '/contact', 
                $baseUrl . '/team', 
                $baseUrl . '/about',
                $baseUrl . '/pricing',
                $baseUrl . '/contact.php', 
                $baseUrl . '/team.php'
            ])) continue;

            $loc = !empty($p['canonical_url']) ? $p['canonical_url'] : ($baseUrl . '/page/' . urlencode($p['slug']));
            $lastmod = !empty($p['updated_at']) ? date('Y-m-d', strtotime($p['updated_at'])) : date('Y-m-d');
            $xml .= "  <url>\n    <loc>" . htmlspecialchars($loc) . "</loc>\n    <lastmod>{$lastmod}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.80</priority>\n";
            if (!empty($p['featured_image'])) {
                $img = str_starts_with($p['featured_image'], 'http') ? $p['featured_image'] : ($baseUrl . $p['featured_image']);
                $xml .= "    <image:image>\n      <image:loc>" . htmlspecialchars($img) . "</image:loc>\n      <image:title>" . htmlspecialchars($p['title'] ?? '') . "</image:title>\n    </image:image>\n";
            }
            $xml .= "  </url>\n";
        }

        // Services
        foreach ($services as $srv) {
            $srvLoc = $baseUrl . '/services/' . urlencode($srv['slug']);
            $xml .= "  <url>\n    <loc>" . htmlspecialchars($srvLoc) . "</loc>\n    <lastmod>" . date('Y-m-d') . "</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.90</priority>\n  </url>\n";
        }
    }

    if ($type === 'all' || $type === 'posts') {
        $xml .= "  <!-- Blog Articles & Guides -->\n";
        foreach ($posts as $post) {
            if (!empty($post['exclude_sitemap'])) continue;
            if (str_contains($post['robots'] ?? '', 'noindex')) continue;
            if (($post['status'] ?? 'published') === 'draft') continue;
            $loc = $baseUrl . '/blog/' . urlencode($post['slug']);
            $lastmod = !empty($post['updated_at']) ? date('Y-m-d', strtotime($post['updated_at'])) : (!empty($post['date']) ? date('Y-m-d', strtotime($post['date'])) : date('Y-m-d'));
            $xml .= "  <url>\n    <loc>" . htmlspecialchars($loc) . "</loc>\n    <lastmod>{$lastmod}</lastmod>\n    <changefreq>monthly</changefreq>\n    <priority>0.80</priority>\n";
            if (!empty($post['featured_image'])) {
                $img = str_starts_with($post['featured_image'], 'http') ? $post['featured_image'] : ($baseUrl . $post['featured_image']);
                $xml .= "    <image:image>\n      <image:loc>" . htmlspecialchars($img) . "</image:loc>\n      <image:title>" . htmlspecialchars($post['title']) . "</image:title>\n    </image:image>\n";
            }
            $xml .= "  </url>\n";
        }

        // Post Categories
        foreach ($postCategories as $cat) {
            $loc = $baseUrl . '/blog/category/' . urlencode($cat['slug'] ?? $cat['name']);
            $xml .= "  <url>\n    <loc>" . htmlspecialchars($loc) . "</loc>\n    <lastmod>" . date('Y-m-d') . "</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.60</priority>\n  </url>\n";
        }
    }

    if ($type === 'all' || $type === 'custom') {
        if (count($custom) > 0) {
            $xml .= "  <!-- Custom Sitemaps -->\n";
            foreach ($custom as $c) {
                $xml .= "  <url>\n    <loc>" . htmlspecialchars($c['url']) . "</loc>\n    <lastmod>" . htmlspecialchars($c['lastmod'] ?? date('Y-m-d')) . "</lastmod>\n    <changefreq>" . htmlspecialchars($c['changefreq'] ?? 'weekly') . "</changefreq>\n    <priority>" . htmlspecialchars($c['priority'] ?? '0.80') . "</priority>\n  </url>\n";
            }
        }
    }

    $xml .= "</urlset>\n";
    return $xml;
}

function generatePhysicalSitemaps(): array {
    $results = [];
    $allXml = buildSitemapXml('all');
    $pagesXml = buildSitemapXml('pages');
    $postsXml = buildSitemapXml('posts');
    $custom = getCustomSitemap();
    $customXml = buildSitemapXml('custom');

    $root = rtrim(ROOT_PATH, '/');
    file_put_contents($root . '/sitemap.xml', $allXml);
    file_put_contents($root . '/sitemap-pages.xml', $pagesXml);
    file_put_contents($root . '/sitemap-posts.xml', $postsXml);
    
    if (count($custom) > 0) {
        file_put_contents($root . '/sitemap-custom.xml', $customXml);
    } elseif (file_exists($root . '/sitemap-custom.xml')) {
        @unlink($root . '/sitemap-custom.xml');
    }

    // Also sync robots.txt if needed
    $seoSettings = getSeoSettings();
    if (!empty($seoSettings['robots_txt'])) {
        @file_put_contents($root . '/robots.txt', trim($seoSettings['robots_txt']) . "\n");
    }

    return [
        'sitemap.xml'        => strlen($allXml),
        'sitemap-pages.xml'  => strlen($pagesXml),
        'sitemap-posts.xml'  => strlen($postsXml),
        'sitemap-custom.xml' => count($custom) > 0 ? strlen($customXml) : 0
    ];
}

// ══════════════════════════════════════════════════════════
//  DEDICATED SERVICES ENGINE
// ══════════════════════════════════════════════════════════

function getServices(): array {
    $file = DATA_PATH . '/services.json';
    if (!file_exists($file)) return [];
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : [];
}

function getServiceBySlug(string $slug): ?array {
    $slug = strtolower(trim($slug));
    foreach (getServices() as $srv) {
        if (strtolower($srv['slug']) === $slug) {
            return $srv;
        }
    }
    return null;
}

// ══════════════════════════════════════════════════════════
//  ADVANCED BLOG POSTS CMS
// ══════════════════════════════════════════════════════════

function getBlogs(): array {
    $file = DATA_PATH . '/blogs.json';
    if (!file_exists($file)) return [];
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : [];
}

function saveBlogs(array $blogs): void {
    atomicWriteJson(DATA_PATH . '/blogs.json', $blogs);
}

function getAllBlogsAdmin(): array {
    return getBlogs();
}

function getPublishedBlogs(): array {
    $blogs = getBlogs();
    $now = time();
    return array_values(array_filter($blogs, function($b) use ($now) {
        $status = $b['status'] ?? 'published';
        if ($status === 'draft') return false;
        if ($status === 'scheduled') {
            $schedTime = !empty($b['scheduled_at']) ? strtotime($b['scheduled_at']) : strtotime($b['created_at']);
            if ($schedTime > $now) return false;
        }
        return true;
    }));
}

/**
 * Returns the public author display name for a blog post.
 * - Senior SEO Lead / Automated API articles strictly render 'Estate HDR Team'
 * - Regular SEO Manager (hired individual) renders their custom author name / account name
 */
function getPostAuthorDisplayName(array $post): string {
    $creator = $post['created_by'] ?? $post['author_id'] ?? '';
    $author = trim($post['author'] ?? '');

    // Senior SEO Operations Lead / Automated flow is strictly branded as Estate HDR Team
    if ($creator === 'adm-senior-seo' || strtolower($author) === 'senior seo operations lead' || strtolower($author) === 'senior seo') {
        return 'Estate HDR Team';
    }

    // Regular SEO Manager (the person hired by the user)
    if ($creator === 'adm-7') {
        if (!empty($author) && $author !== 'Estate HDR Team' && $author !== 'Marcus Sterling') {
            return $author;
        }
        if (function_exists('getAdminUserById')) {
            $admin = getAdminUserById('adm-7');
            if ($admin && !empty($admin['name']) && $admin['name'] !== 'SEO & Content Manager') {
                return $admin['name'];
            }
        }
        return 'SEO & Content Manager';
    }

    // Custom author name entered by editor/admin
    if (!empty($author) && $author !== 'Marcus Sterling') {
        return $author;
    }

    return 'Estate HDR Team';
}

/**
 * Benchmark HTML Article Formatter & Beautifier
 * Ensures every post (new or old) matches the rich, professional formatting:
 * - Numbered section headings
 * - 2-column Comparison Card Grid (Traditional vs Estate HDR)
 * - Clean HTML lists & styled paragraphs
 * - High-converting 24-hour turnaround CTA banner
 */
function formatArticleHtmlBenchmark(string $content, string $title = '', string $category = ''): string {
    if (empty(trim($content))) return '';
    $textOnly = trim(strip_tags($content));
    if (empty($textOnly)) return '';

    // 0. Self-healing: Repair any corrupted pricing strings from prior unescaped regexes
    $pricingFixes = [
        ',000 – ,500+'            => '$3,000 – $7,500+',
        ',000 - ,500+'            => '$3,000 – $7,500+',
        'Only – per'               => 'Only $8 – $10 per',
        'Only - per'               => 'Only $8 – $10 per',
        'Cost Burden: 35 – 65/hr'  => 'Cost Burden: $35 – $65/hr',
        'From only 0.68 – 1.20'    => 'From only $0.68 – $1.20',
        'Only 3 – 4 per'           => 'Only $3 – $4 per',
        'Only 12 – 18 per'         => 'Only $12 – $18 per',
        'Only 2 – 4 per'           => 'Only $2 – $4 per',
    ];
    foreach ($pricingFixes as $bad => $good) {
        if (str_contains($content, $bad)) {
            $content = str_replace($bad, $good, $content);
        }
    }

    // 1. Fix malformed LLM tags like <strong Word:</strong>
    $content = preg_replace('/<strong\s+([^>]+):<\/strong>/i', '<strong>$1:</strong>', $content);
    $content = preg_replace('/<strong\s+([^>]+)>/i', '<strong>$1</strong>', $content);

    // 2. Convert markdown bold/italics
    $content = preg_replace('/\*\*([^*]+)\*\*/', '<strong>$1</strong>', $content);
    $content = preg_replace('/\*([^*\n]+)\*/', '<em>$1</em>', $content);

    // 3. Convert markdown headings
    $content = preg_replace('/^###\s+(.+)$/m', '<h3 class="text-xl font-bold text-white mt-8 mb-3">$1</h3>', $content);
    $content = preg_replace('/^##\s+(.+)$/m', '<h2 class="text-2xl font-black text-gold mt-10 mb-4">$1</h2>', $content);
    $content = preg_replace('/^#\s+(.+)$/m', '<h2 class="text-2xl font-black text-gold mt-10 mb-4">$1</h2>', $content);

    // 4. Strip stray asterisks inside list items (e.g. <li>* Text</li>)
    $content = preg_replace('/<li>\s*[\*\-•]\s*/', '<li>', $content);

    // 5. Convert raw markdown list lines (* or -) into HTML lists
    $lines = explode("\n", $content);
    $output = [];
    $inList = false;

    foreach ($lines as $line) {
        $trimmed = trim($line);
        if (preg_match('/^[\*\-•]\s+(.+)$/', $trimmed, $m)) {
            if (!$inList) {
                $output[] = '<ul class="space-y-3 my-4 text-gray-300 list-disc pl-6">';
                $inList = true;
            }
            $item = $m[1];
            $output[] = '  <li>' . $item . '</li>';
        } else {
            if ($inList) {
                $output[] = '</ul>';
                $inList = false;
            }
            // If line is plain non-empty text without HTML tags, wrap in <p>
            if (!empty($trimmed) && !preg_match('/^<(\/?[a-z0-9]+)[\s>]/i', $trimmed)) {
                $output[] = '<p class="leading-normal mb-3 mt-0 text-gray-300">' . $trimmed . '</p>';
            } else {
                $output[] = $line;
            }
        }
    }
    if ($inList) {
        $output[] = '</ul>';
    }
    $content = implode("\n", $output);
    $content = preg_replace('/<li>\s*[\*\-•]\s*/i', '<li>', $content);

    // 5.5. Ensure H2 headings are cleanly numbered (1. Heading, 2. Heading...)
    $h2Idx = 1;
    $content = preg_replace_callback('/<h2([^>]*)>(.*?)<\/h2>/is', function($m) use (&$h2Idx) {
        $attrs = $m[1];
        $inner = trim(strip_tags($m[2]));
        // Remove existing numbering prefix if any (e.g. "1. ", "2 - ")
        $clean = preg_replace('/^\d+[\.\:\-]\s*/', '', $inner);
        $numbered = $h2Idx . '. ' . $clean;
        $h2Idx++;
        return "<h2{$attrs}>{$numbered}</h2>";
    }, $content);

    // 6. User content preserved directly without auto-injected demo cards or comparison grids
    return $content;
}

function saveBlog(array $postData): array {
    $blogs = getBlogs();
    $id = !empty($postData['id']) ? $postData['id'] : ('blog-' . time());
    $slug = !empty($postData['slug']) ? trim($postData['slug']) : strtolower(preg_replace('/[^a-z0-9]+/', '-', trim($postData['title'])));
    
    $rawContent = $postData['content'] ?? '';
    // Strip redundant empty paragraphs while preserving user authoring exactly
    $formattedContent = preg_replace('/<p>\s*(<br\s*\/?>|&nbsp;|\s)*<\/p>/i', '', $rawContent);

    $post = [
        'id'              => $id,
        'slug'            => $slug,
        'title'           => trim($postData['title']),
        'excerpt'         => trim($postData['excerpt'] ?? ''),
        'content'         => $formattedContent,
        'category'        => trim($postData['category'] ?? 'HDR Photo Editing'),
        'category_id'     => $postData['category_id'] ?? '',
        'tags'            => is_array($postData['tags'] ?? null) ? $postData['tags'] : array_map('trim', explode(',', $postData['tags'] ?? '')),
        'featured_image'  => trim($postData['featured_image'] ?? ''),
        'author'          => trim($postData['author'] ?? 'Estate HDR Editorial Team'),
        'author_id'       => trim($postData['author_id'] ?? ''),
        'created_by'      => trim($postData['created_by'] ?? ''),
        'read_time'       => trim($postData['read_time'] ?? '5 min read'),
        'status'          => $postData['status'] ?? 'published', // 'published', 'draft', 'scheduled'
        'scheduled_at'    => $postData['scheduled_at'] ?? '',
        'meta_title'      => trim($postData['meta_title'] ?? $postData['title']),
        'meta_description'=> trim($postData['meta_description'] ?? $postData['excerpt'] ?? ''),
        'canonical_url'   => trim($postData['canonical_url'] ?? ''),
        'robots'          => $postData['robots'] ?? 'index, follow',
        'exclude_sitemap' => !empty($postData['exclude_sitemap']),
        'schema_json'     => $postData['schema_json'] ?? '',
        'views_count'     => (int)($postData['views_count'] ?? 0),
        'created_at'      => $postData['created_at'] ?? date('c'),
        'updated_at'      => date('c')
    ];

    $found = false;
    foreach ($blogs as &$b) {
        if ($b['id'] === $id || $b['slug'] === $slug) {
            $b = array_merge($b, $post);
            $found = true;
            break;
        }
    }
    if (!$found) {
        array_unshift($blogs, $post);
    }

    saveBlogs($blogs);
    return $post;
}

function deleteBlog(string $id): bool {
    $blogs = getBlogs();
    $filtered = array_values(array_filter($blogs, fn($b) => $b['id'] !== $id && $b['slug'] !== $id));
    saveBlogs($filtered);
    return true;
}

// ══════════════════════════════════════════════════════════
//  SEO SCORING (TRAFFIC LIGHT: GREEN / YELLOW / RED)
// ══════════════════════════════════════════════════════════

function calculateSeoScore(array $item): array {
    $title = trim($item['meta_title'] ?? $item['title'] ?? '');
    $desc  = trim($item['meta_description'] ?? $item['excerpt'] ?? '');
    $kw    = trim($item['focus_keyword'] ?? '');
    $tLen  = mb_strlen($title);
    $dLen  = mb_strlen($desc);

    $issues = [];
    $score = 100;

    if (empty($title)) {
        $issues[] = 'Meta title is missing';
        $score -= 40;
    } elseif ($tLen < 30) {
        $issues[] = 'Meta title is too short (' . $tLen . ' chars, min 30)';
        $score -= 15;
    } elseif ($tLen > 60) {
        $issues[] = 'Meta title is too long (' . $tLen . ' chars, max 60)';
        $score -= 15;
    }

    if (empty($desc)) {
        $issues[] = 'Meta description is missing';
        $score -= 40;
    } elseif ($dLen < 70) {
        $issues[] = 'Meta description is too short (' . $dLen . ' chars, min 70)';
        $score -= 15;
    } elseif ($dLen > 160) {
        $issues[] = 'Meta description is too long (' . $dLen . ' chars, max 160)';
        $score -= 15;
    }

    if (!empty($kw)) {
        if (!str_contains(strtolower($title), strtolower($kw))) {
            $issues[] = 'Focus keyword "' . $kw . '" not found in Meta Title';
            $score -= 10;
        }
    }

    if ($score >= 80) {
        $status = 'green';
        $label = 'Good SEO';
        $dotClass = 'bg-emerald-500 shadow-emerald-500/50';
    } elseif ($score >= 50) {
        $status = 'yellow';
        $label = 'Needs Improvement';
        $dotClass = 'bg-amber-500 shadow-amber-500/50';
    } else {
        $status = 'red';
        $label = 'Poor / Missing SEO';
        $dotClass = 'bg-red-500 shadow-red-500/50';
    }

    return [
        'status'   => $status,
        'label'    => $label,
        'dotClass' => $dotClass,
        'score'    => max(0, $score),
        'issues'   => $issues
    ];
}

function getPagesSeoHierarchical(): array {
    $pages = getPagesSeo();
    usort($pages, function($a, $b) {
        $orderA = (int)($a['order'] ?? 0);
        $orderB = (int)($b['order'] ?? 0);
        if ($orderA !== $orderB) return $orderA - $orderB;
        return strcmp($a['page_name'] ?? '', $b['page_name'] ?? '');
    });
    return $pages;
}

function savePage(array $pageData): array {
    $pages = getPagesSeo();
    $id = !empty($pageData['id']) ? $pageData['id'] : ('page-' . time());
    $slug = !empty($pageData['slug']) ? trim($pageData['slug']) : strtolower(preg_replace('/[^a-z0-9]+/', '-', trim($pageData['title'] ?? 'page')));
    
    $parent = !empty($pageData['parent_id']) ? $pageData['parent_id'] : '';
    $urlPath = !empty($pageData['url_path']) ? $pageData['url_path'] : ('/page.php?slug=' . urlencode($slug));

    $page = [
        'id'               => $id,
        'slug'             => $slug,
        'title'            => trim($pageData['title'] ?? $pageData['page_name'] ?? 'Untitled Page'),
        'page_name'        => trim($pageData['page_name'] ?? $pageData['title'] ?? 'Untitled Page'),
        'url_path'         => $urlPath,
        'parent_id'        => $parent,
        'template'         => $pageData['template'] ?? 'default', // 'default', 'full_width', 'landing_page'
        'order'            => (int)($pageData['order'] ?? 0),
        'category'         => trim($pageData['category'] ?? 'Services & Solutions'),
        'author'           => trim($pageData['author'] ?? 'SEO Manager'),
        'status'           => $pageData['status'] ?? 'published',
        'content'          => $pageData['content'] ?? '',
        'featured_image'   => trim($pageData['featured_image'] ?? '/assets/images/portfolio/hdr/1-after.jpg'),
        'focus_keyword'    => trim($pageData['focus_keyword'] ?? ''),
        'meta_title'       => trim($pageData['meta_title'] ?? $pageData['title'] ?? ''),
        'meta_description' => trim($pageData['meta_description'] ?? ''),
        'og_image'         => trim($pageData['og_image'] ?? $pageData['featured_image'] ?? ''),
        'canonical_url'    => trim($pageData['canonical_url'] ?? ''),
        'robots'           => $pageData['robots'] ?? 'index, follow',
        'allow_comments'   => !empty($pageData['allow_comments']),
        'exclude_sitemap'  => !empty($pageData['exclude_sitemap']),
        'schema_json'      => trim($pageData['schema_json'] ?? ''),
        'created_at'       => $pageData['created_at'] ?? date('c'),
        'updated_at'       => date('c')
    ];

    $found = false;
    foreach ($pages as &$p) {
        if ($p['id'] === $id || $p['slug'] === $slug) {
            $p = array_merge($p, $page);
            $found = true;
            break;
        }
    }
    if (!$found) {
        $pages[] = $page;
    }

    savePagesSeo($pages);
    return $page;
}

function deletePage(string $id): bool {
    $pages = getPagesSeo();
    $filtered = array_values(array_filter($pages, fn($p) => $p['id'] !== $id && $p['slug'] !== $id));
    savePagesSeo($filtered);
    return true;
}

// ══════════════════════════════════════════════════════════
//  MULTI-ADMIN USERS & ROLES CRUD (HOMETRACK-STYLE)
// ══════════════════════════════════════════════════════════

function getAdminUsers(): array {
    $path = rtrim(DATA_PATH, '/') . '/admin_users.json';
    if (!file_exists($path)) {
        return [
            [
                'id'            => 'adm-1',
                'name'          => 'Master Administrator',
                'email'         => 'admin@estatehdr.com',
                'phone'         => '+44 770 606 8176',
                'password_hash' => '$2y$10$demoHashForLocalDevelopmentOnlyReplaceWithRealBcrypt000',
                'roles'         => ['owner', 'super_admin'],
                'is_active'     => true,
                'created_at'    => date('c')
            ]
        ];
    }
    return json_decode(file_get_contents($path), true) ?? [];
}

function saveAdminUsers(array $users): bool {
    $path = rtrim(DATA_PATH, '/') . '/admin_users.json';
    return atomicWriteJson($path, $users);
}

function getAdminUserById(string $id): ?array {
    foreach (getAdminUsers() as $u) {
        if ($u['id'] === $id) return $u;
    }
    return null;
}

function saveAdminUser(array $userData): array {
    $users = getAdminUsers();
    $id = !empty($userData['id']) ? $userData['id'] : ('adm-' . time());
    
    $user = [
        'id'         => $id,
        'name'       => trim($userData['name']),
        'email'      => strtolower(trim($userData['email'])),
        'phone'      => trim($userData['phone'] ?? ''),
        'roles'      => is_array($userData['roles'] ?? null) ? $userData['roles'] : [($userData['role'] ?? 'manager')],
        'is_active'  => isset($userData['is_active']) ? (bool)$userData['is_active'] : true,
        'created_at' => $userData['created_at'] ?? date('c')
    ];

    if (!empty($userData['password'])) {
        $user['password_hash'] = password_hash($userData['password'], PASSWORD_BCRYPT, ['cost' => 12]);
    } elseif (!empty($userData['password_hash'])) {
        $user['password_hash'] = $userData['password_hash'];
    }

    $found = false;
    foreach ($users as &$u) {
        if ($u['id'] === $id || strtolower($u['email']) === strtolower($user['email'])) {
            if (empty($user['password_hash']) && !empty($u['password_hash'])) {
                $user['password_hash'] = $u['password_hash'];
            }
            $u = array_merge($u, $user);
            $found = true;
            break;
        }
    }
    if (!$found) {
        if (empty($user['password_hash'])) {
            $user['password_hash'] = password_hash('DemoAdmin@2026!', PASSWORD_BCRYPT, ['cost' => 12]);
        }
        $users[] = $user;
    }

    saveAdminUsers($users);
    return $user;
}

function deleteAdminUser(string $id): bool {
    $users = getAdminUsers();
    $targetUser = null;
    foreach ($users as $u) {
        if ($u['id'] === $id) {
            $targetUser = $u;
            break;
        }
    }

    // 1. Remove from data/admin_users.json (Protect master CEO admin)
    $filtered = array_values(array_filter($users, fn($u) => $u['id'] !== $id && $u['email'] !== 'admin@estatehdr.com'));
    $saved = saveAdminUsers($filtered);

    // 2. Automatically Remove from HR Directory (data/saas_employees.json)
    $empFile = DATA_PATH . 'saas_employees.json';
    if (file_exists($empFile)) {
        $emps = readJson($empFile);
        if (is_array($emps)) {
            $targetEmail = strtolower($targetUser['email'] ?? '');
            $filteredEmps = array_values(array_filter($emps, function($e) use ($id, $targetEmail) {
                if (($e['user_id'] ?? '') === $id || ($e['id'] ?? '') === $id) return false;
                if ($targetEmail !== '' && strtolower($e['email'] ?? '') === $targetEmail) return false;
                return true;
            }));
            writeJson($empFile, $filteredEmps);
        }
    }

    // 3. Remove from legacy data/admin.json if present
    $adminFile = DATA_PATH . 'admin.json';
    if (file_exists($adminFile)) {
        $legacy = readJson($adminFile);
        if (is_array($legacy)) {
            $targetEmail = strtolower($targetUser['email'] ?? '');
            $filteredLegacy = array_values(array_filter($legacy, function($a) use ($id, $targetEmail) {
                if (($a['id'] ?? '') === $id) return false;
                if ($targetEmail !== '' && strtolower($a['email'] ?? '') === $targetEmail) return false;
                return true;
            }));
            writeJson($adminFile, $filteredLegacy);
        }
    }

    return $saved;
}

// ══════════════════════════════════════════════════════════
//  LEADS & FREE TRIAL FULFILLMENT
// ══════════════════════════════════════════════════════════

function saveLeads(array $leads): bool {
    $path = rtrim(DATA_PATH, '/') . '/leads.json';
    return atomicWriteJson($path, $leads);
}

function updateLeadDelivery(string $leadId, string $finalCloudLink): bool {
    $leads = getLeads();
    $targetId = trim($leadId);
    foreach ($leads as &$l) {
        if (strcasecmp($l['id'], $targetId) === 0 || strcasecmp($l['id'], str_ireplace('TRIAL-', '', $targetId)) === 0) {
            $l['final_cloud_link'] = trim($finalCloudLink);
            $l['status'] = 'delivered';
            $l['delivered_at'] = date('c');
            return saveLeads($leads);
        }
    }
    return false;
}

function updateClientBalance(string $clientId, float $newBalance): bool {
    $users = getUsers();
    foreach ($users as &$u) {
        if ($u['id'] === $clientId) {
            $u['balance'] = $newBalance;
            return saveUsers($users);
        }
    }
    return false;
}

// ══════════════════════════════════════════════════════════
//  EXECUTIVE KPI & TELEMETRY INTELLIGENCE ENGINE
// ══════════════════════════════════════════════════════════

/**
 * 3-State Real-Time Presence Calculation (Active <=60s, Idle 61-180s, Chatting)
 */
function calculateLivePresenceStats(array $visitors, array $chats = [], ?int $now = null): array {
    $now = $now ?? time();
    $activeCount   = 0;
    $idleCount     = 0;
    $chattingCount = 0;
    $offlineCount  = 0;

    // Index active chatting visitor IDs (active within 10 mins or status active)
    $activeChattingVids = [];
    foreach ($chats as $vid => $chat) {
        $lastChatTs = $chat['last_active_ts'] ?? strtotime($chat['last_active'] ?? '2000-01-01');
        if (($now - $lastChatTs <= 600) || (($chat['status'] ?? '') === 'active')) {
            $activeChattingVids[$vid] = true;
        }
    }

    foreach ($visitors as $vid => $v) {
        $lastTs = $v['last_seen_ts'] ?? strtotime($v['last_seen'] ?? '2000-01-01');
        $delta = max(0, $now - $lastTs);

        if (isset($activeChattingVids[$vid]) && $delta <= 300) {
            $chattingCount++;
        } elseif ($delta <= 60) {
            $activeCount++;
        } elseif ($delta <= 180) {
            $idleCount++;
        } else {
            $offlineCount++;
        }
    }

    return [
        'online_now'     => $activeCount + $chattingCount,
        'active_count'   => $activeCount,
        'idle_count'     => $idleCount,
        'chatting_count' => $chattingCount,
        'offline_count'  => $offlineCount,
        'total_tracked'  => count($visitors)
    ];
}

/**
 * Formats duration in seconds into human-readable strings
 */
function formatDurationHelper(int $seconds): string {
    if ($seconds <= 0) return '0s';
    if ($seconds < 60) return $seconds . 's';
    $m = floor($seconds / 60);
    $s = $seconds % 60;
    if ($m < 60) return "{$m}m {$s}s";
    $h = floor($m / 60);
    $remM = $m % 60;
    return "{$h}h {$remM}m";
}

/**
 * Filters visitor sessions by date range and calculates session metrics and breakdowns
 */
function filterVisitorSessions(array $visitors, string $range = 'all', string $customStart = '', string $customEnd = '', ?int $now = null): array {
    $now = $now ?? time();
    $todayStr        = date('Y-m-d', $now);
    $yesterdayStr    = date('Y-m-d', strtotime('-1 day', $now));
    $sevenDaysAgo    = date('Y-m-d', strtotime('-7 days', $now));
    $thirtyDaysAgo   = date('Y-m-d', strtotime('-30 days', $now));
    $thisMonthPrefix = date('Y-m', $now);

    $filtered = [];
    $uniqueIps = [];
    $totalHits = 0;
    $totalSeconds = 0;
    $countries = [];
    $cities = [];
    $pages = [];
    $devices = ['Desktop' => 0, 'Mobile' => 0, 'Tablet' => 0];
    $browsers = [];
    $referrers = [];

    foreach ($visitors as $vid => $v) {
        $vDate = $v['date'] ?? date('Y-m-d', strtotime($v['first_seen'] ?? 'now'));
        
        $include = false;
        if ($range === 'today' && $vDate === $todayStr) $include = true;
        elseif ($range === 'yesterday' && $vDate === $yesterdayStr) $include = true;
        elseif ($range === '7days' && $vDate >= $sevenDaysAgo) $include = true;
        elseif ($range === '30days' && $vDate >= $thirtyDaysAgo) $include = true;
        elseif ($range === 'month' && str_starts_with($vDate, $thisMonthPrefix)) $include = true;
        elseif ($range === 'custom' && $customStart && $vDate >= $customStart && ($customEnd ? $vDate <= $customEnd : true)) $include = true;
        elseif ($range === 'all') $include = true;

        if ($include) {
            $filtered[$vid] = $v;
            $ip = trim($v['ip'] ?? '');
            if (!empty($ip)) {
                $uniqueIps[$ip] = true;
            }
            $totalHits += max(1, intval($v['hits'] ?? 1));
            $totalSeconds += max(0, intval($v['time_spent'] ?? 0));

            $c = $v['country'] ?? 'Unknown';
            $countries[$c] = ($countries[$c] ?? 0) + 1;

            $cit = $v['city'] ?? 'Unknown';
            $cities[$cit] = ($cities[$cit] ?? 0) + 1;

            $p = $v['current_page'] ?? '/';
            $pages[$p] = ($pages[$p] ?? 0) + 1;

            $d = $v['device'] ?? 'Desktop';
            if (isset($devices[$d])) {
                $devices[$d]++;
            } else {
                $devices[$d] = 1;
            }

            $b = $v['browser'] ?? 'Chrome';
            $browsers[$b] = ($browsers[$b] ?? 0) + 1;

            $r = $v['referrer'] ?? 'Direct Visit';
            $referrers[$r] = ($referrers[$r] ?? 0) + 1;
        }
    }

    // Sort breakdowns descending
    uasort($filtered, fn($a, $b) => ($b['last_seen_ts'] ?? 0) <=> ($a['last_seen_ts'] ?? 0));
    arsort($countries);
    arsort($cities);
    arsort($pages);
    arsort($browsers);
    arsort($referrers);

    $sessionCount = count($filtered);
    $avgSeconds = $sessionCount > 0 ? (int)round($totalSeconds / $sessionCount) : 0;

    return [
        'filtered_visitors' => $filtered,
        'total_sessions'    => $sessionCount,
        'unique_ips_count'  => count($uniqueIps),
        'total_hits'        => $totalHits,
        'total_seconds'     => $totalSeconds,
        'avg_seconds'       => $avgSeconds,
        'avg_duration_str'  => formatDurationHelper($avgSeconds),
        'countries'         => $countries,
        'cities'            => $cities,
        'pages'             => $pages,
        'devices'           => $devices,
        'browsers'          => $browsers,
        'referrers'         => $referrers
    ];
}

/**
 * Calculates live chat and omnichannel communication KPIs including First Response Time
 */
function calculateChatKpis(array $chats, string $range = 'all', ?int $now = null): array {
    $now = $now ?? time();
    $totalChats     = count($chats);
    $activeChats    = 0;
    $unreadAlerts   = 0;
    $responseTimes  = [];
    $channelCounts  = ['webchat' => 0, 'whatsapp' => 0, 'email' => 0, 'sms' => 0];

    foreach ($chats as $vid => $chat) {
        $channel = strtolower($chat['channel'] ?? 'webchat');
        if (isset($channelCounts[$channel])) {
            $channelCounts[$channel]++;
        } else {
            $channelCounts[$channel] = 1;
        }

        if (!empty($chat['has_unread_for_agent'])) {
            $unreadAlerts++;
        }

        $lastActiveTs = $chat['last_active_ts'] ?? strtotime($chat['last_active'] ?? '2000-01-01');
        if (($now - $lastActiveTs <= 3600) || (($chat['status'] ?? '') === 'active')) {
            $activeChats++;
        }

        // Measure First Response Time from message stream
        $messages = $chat['messages'] ?? [];
        $firstUserTs = null;
        $firstAgentTs = null;

        foreach ($messages as $m) {
            $sender = $m['sender'] ?? '';
            $ts = $m['ts'] ?? strtotime($m['timestamp'] ?? 'now');

            if ($sender === 'user' && $firstUserTs === null) {
                $firstUserTs = $ts;
            } elseif ($sender === 'agent' && $firstUserTs !== null && $firstAgentTs === null) {
                if ($ts >= $firstUserTs) {
                    $firstAgentTs = $ts;
                    break;
                }
            }
        }

        if ($firstUserTs !== null && $firstAgentTs !== null) {
            $diff = $firstAgentTs - $firstUserTs;
            if ($diff >= 0 && $diff <= 86400) {
                $responseTimes[] = $diff;
            }
        }
    }

    $validCount = count($responseTimes);
    $avgFrtSeconds = $validCount > 0 ? (int)round(array_sum($responseTimes) / $validCount) : 42; // Default 42s studio baseline
    $frtFormatted = formatDurationHelper($avgFrtSeconds);

    return [
        'total_conversations' => $totalChats,
        'active_chats_now'    => $activeChats,
        'unread_alerts_count' => $unreadAlerts,
        'avg_frt_seconds'     => $avgFrtSeconds,
        'avg_frt_formatted'   => $frtFormatted,
        'frt_sample_size'     => $validCount,
        'channel_breakdown'   => $channelCounts
    ];
}

/**
 * Calculates Customer Satisfaction (CSAT) score & SLA rating
 */
function calculateCsatKpi(array $chats = [], array $tickets = []): array {
    $ratings = [];

    // Extract chat ratings
    foreach ($chats as $c) {
        if (!empty($c['rating']) && is_numeric($c['rating'])) {
            $r = floatval($c['rating']);
            if ($r >= 1.0 && $r <= 5.0) $ratings[] = $r;
        }
    }

    // Extract ticket ratings
    foreach ($tickets as $t) {
        if (!empty($t['satisfaction_score']) && is_numeric($t['satisfaction_score'])) {
            $r = floatval($t['satisfaction_score']);
            if ($r >= 1.0 && $r <= 5.0) $ratings[] = $r;
        }
    }

    $count = count($ratings);
    if ($count === 0) {
        return [
            'csat_percentage' => 98.4,
            'csat_average'    => 4.9,
            'csat_formatted'  => '98.4%',
            'rating_stars'    => '4.9 / 5.0',
            'sample_count'    => 0,
            'is_benchmark'    => true
        ];
    }

    $positive = count(array_filter($ratings, fn($r) => $r >= 4.0));
    $csatPct = round(($positive / $count) * 100, 1);
    $csatAvg = round(array_sum($ratings) / $count, 1);

    return [
        'csat_percentage' => $csatPct,
        'csat_average'    => $csatAvg,
        'csat_formatted'  => "{$csatPct}%",
        'rating_stars'    => "{$csatAvg} / 5.0",
        'sample_count'    => $count,
        'is_benchmark'    => false
    ];
}

/**
 * Calculates Support Tickets KPIs & SLA status
 */
function calculateTicketKpis(array $tickets = [], ?int $now = null): array {
    $now = $now ?? time();
    $totalTickets      = count($tickets);
    $openTickets       = 0;
    $urgentCount       = 0;
    $highCount         = 0;
    $breachedCount     = 0;
    $approachingBreach = 0;
    $statusCounts = [
        'open'             => 0,
        'assigned'         => 0,
        'in_progress'      => 0,
        'pending_customer' => 0,
        'resolved'         => 0,
        'closed'           => 0
    ];

    foreach ($tickets as $t) {
        $status = strtolower($t['status'] ?? 'open');
        if (isset($statusCounts[$status])) {
            $statusCounts[$status]++;
        } else {
            $statusCounts[$status] = 1;
        }

        $isOpen = !in_array($status, ['resolved', 'closed'], true);
        if ($isOpen) {
            $openTickets++;
            $priority = strtolower($t['priority'] ?? 'normal');
            if ($priority === 'urgent') $urgentCount++;
            if ($priority === 'high') $highCount++;

            // SLA Breach detection
            $firstDue = !empty($t['first_response_due_at']) ? strtotime($t['first_response_due_at']) : 0;
            $resDue   = !empty($t['resolution_due_at']) ? strtotime($t['resolution_due_at']) : 0;
            $firstDone = !empty($t['first_responded_at']);
            $resDone   = !empty($t['resolved_at']);

            $isBreached = false;
            if (!$firstDone && $firstDue > 0 && $now > $firstDue) {
                $isBreached = true;
            }
            if (!$resDone && $resDue > 0 && $now > $resDue) {
                $isBreached = true;
            }

            if ($isBreached) {
                $breachedCount++;
            } elseif ($resDue > 0 && ($resDue - $now) < 1800) { // Under 30m remaining
                $approachingBreach++;
            }
        }
    }

    return [
        'total_tickets'            => $totalTickets,
        'open_tickets_count'       => $openTickets,
        'urgent_count'             => $urgentCount,
        'high_count'               => $highCount,
        'breached_count'           => $breachedCount,
        'approaching_breach_count' => $approachingBreach,
        'status_breakdown'         => $statusCounts
    ];
}

/**
 * Calculates Lead & CRM Pipeline KPIs
 */
function calculateLeadKpis(array $leads = [], array $contacts = []): array {
    $totalLeads = count($leads) + count($contacts);
    $activeLeads = 0;
    $pipeline = [
        'new'       => 0,
        'contacted' => 0,
        'qualified' => 0,
        'won'       => 0,
        'lost'      => 0
    ];

    $trialSamplesPending   = 0;
    $trialSamplesDelivered = 0;

    foreach ($leads as $l) {
        $status = strtolower($l['status'] ?? 'new');
        if ($status === 'delivered') {
            $pipeline['won']++;
            $trialSamplesDelivered++;
        } elseif ($status === 'pending' || $status === 'new') {
            $pipeline['new']++;
            $activeLeads++;
            $trialSamplesPending++;
        } elseif ($status === 'contacted') {
            $pipeline['contacted']++;
            $activeLeads++;
        } elseif ($status === 'qualified') {
            $pipeline['qualified']++;
            $activeLeads++;
        } elseif ($status === 'lost') {
            $pipeline['lost']++;
        } else {
            $pipeline['new']++;
            $activeLeads++;
        }
    }

    foreach ($contacts as $c) {
        $stage = strtolower($c['stage'] ?? 'new');
        if (isset($pipeline[$stage])) {
            $pipeline[$stage]++;
        } else {
            $pipeline['new']++;
        }

        if (in_array($stage, ['new', 'contacted', 'qualified'], true)) {
            $activeLeads++;
        }
    }

    $conversionRate = $totalLeads > 0 ? round(($pipeline['won'] / $totalLeads) * 100, 1) : 0.0;

    return [
        'total_leads'              => $totalLeads,
        'active_leads_count'       => $activeLeads,
        'pipeline_breakdown'       => $pipeline,
        'trial_samples_pending'    => $trialSamplesPending,
        'trial_samples_delivered'  => $trialSamplesDelivered,
        'conversion_rate_pct'      => $conversionRate
    ];
}


/**
 * Volume Tier Pricing Engine
 * • 1-19 Photos: Base $0.80 / photo
 * • 20+ Photos: 5% Discount ($0.76 / photo)
 * • 50+ Photos: 10% Discount ($0.72 / photo)
 * • 100+ Photos: 15% Discount ($0.68 / photo)
 */
function calculateServicePrice(string $serviceType, int $deliveredCount): float {
    $count = max(1, $deliveredCount);
    $st = strtolower(trim($serviceType));
    
    // HDR Photo Editing & Flambient
    if (str_contains($st, 'hdr') || str_contains($st, 'photo') || str_contains($st, 'flambient') || str_contains($st, 'enhancement')) {
        if ($count >= 100) {
            $unitPrice = 0.45; // Slashed from $0.65 (VIP Agency Tier)
        } elseif ($count >= 50) {
            $unitPrice = 0.50; // Slashed from $0.70 (37% Off)
        } elseif ($count >= 25) {
            $unitPrice = 0.55; // Slashed from $0.75 (31% Off)
        } else {
            $unitPrice = 0.60; // Promotional Rate slashed from $0.80 (25% Off)
        }
        return round($count * $unitPrice, 2);
    }
    
    // Virtual Staging ($8.00/photo)
    if (str_contains($st, 'staging')) {
        return round($count * 8.00, 2);
    }
    
    // Day to Dusk ($4.00/photo)
    if (str_contains($st, 'dusk')) {
        return round($count * 4.00, 2);
    }
    
    // Virtual Twilight ($6.00/photo)
    if (str_contains($st, 'twilight')) {
        return round($count * 6.00, 2);
    }
    
    // Item Removal ($2.00/photo)
    if (str_contains($st, 'removal') || str_contains($st, 'declutter')) {
        return round($count * 2.00, 2);
    }
    
    // Floor Plans ($15.00/plan)
    if (str_contains($st, 'floor') || str_contains($st, '3d')) {
        return round($count * 15.00, 2);
    }
    
    return round($count * 0.80, 2);
}

/**
 * Scans server media directories (Blog images, uploads, portfolio) for the Media Gallery Picker
 */
function getServerMediaImages(): array {
    $results = [];
    $allowedExts = ['jpg', 'jpeg', 'png', 'webp', 'gif'];

    // 1. Blog Images (/assets/images/blog)
    $blogDir = ROOT_PATH . '/assets/images/blog';
    if (is_dir($blogDir)) {
        $files = scandir($blogDir);
        foreach ($files as $f) {
            if ($f === '.' || $f === '..') continue;
            $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
            if (in_array($ext, $allowedExts)) {
                $full = $blogDir . '/' . $f;
                $results[] = [
                    'url'      => '/assets/images/blog/' . $f,
                    'filename' => $f,
                    'title'    => ucwords(str_replace(['-', '_'], ' ', pathinfo($f, PATHINFO_FILENAME))),
                    'folder'   => 'blog',
                    'category' => 'Blog Images',
                    'size'     => file_exists($full) ? filesize($full) : 0,
                    'mtime'    => file_exists($full) ? filemtime($full) : 0,
                ];
            }
        }
    }

    // 2. Uploaded Images (/assets/uploads/images)
    $uploadBase = ROOT_PATH . '/assets/uploads/images';
    if (is_dir($uploadBase)) {
        $rdi = new RecursiveDirectoryIterator($uploadBase, RecursiveDirectoryIterator::SKIP_DOTS);
        $rii = new RecursiveIteratorIterator($rdi);
        foreach ($rii as $file) {
            $ext = strtolower($file->getExtension());
            if (in_array($ext, $allowedExts)) {
                $path = str_replace('\\', '/', $file->getPathname());
                $rel = str_replace(str_replace('\\', '/', ROOT_PATH), '', $path);
                $results[] = [
                    'url'      => $rel,
                    'filename' => $file->getFilename(),
                    'title'    => ucwords(str_replace(['-', '_'], ' ', pathinfo($file->getFilename(), PATHINFO_FILENAME))),
                    'folder'   => 'uploads',
                    'category' => 'User Uploads',
                    'size'     => $file->getSize(),
                    'mtime'    => $file->getMTime(),
                ];
            }
        }
    }

    // 3. Studio Portfolio Images (/assets/images/portfolio)
    $portBase = ROOT_PATH . '/assets/images/portfolio';
    if (is_dir($portBase)) {
        $cats = ['virtual-staging' => 'Virtual Staging', 'hdr' => 'HDR Photography', 'day-to-dusk' => 'Day to Dusk', 'twilight' => 'Twilight', 'item-removal' => 'Item Removal', 'renovation' => 'Renovation'];
        foreach ($cats as $sub => $catLabel) {
            $subDir = $portBase . '/' . $sub;
            if (is_dir($subDir)) {
                foreach (glob($subDir . '/*-after.jpg') as $img) {
                    $fn = basename($img);
                    $results[] = [
                        'url'      => '/assets/images/portfolio/' . $sub . '/' . $fn,
                        'filename' => $fn,
                        'title'    => $catLabel . ' (' . $fn . ')',
                        'folder'   => 'portfolio',
                        'category' => $catLabel,
                        'size'     => filesize($img),
                        'mtime'    => filemtime($img),
                    ];
                }
            }
        }
    }

    // Sort by mtime descending (newest first)
    usort($results, fn($a, $b) => ($b['mtime'] ?? 0) <=> ($a['mtime'] ?? 0));
    return $results;
}

// ══════════════════════════════════════════════════════════
//  ADMIN REAL-TIME NOTIFICATIONS ENGINE
// ══════════════════════════════════════════════════════════

if (!defined('ADMIN_NOTIFICATIONS_FILE')) {
    define('ADMIN_NOTIFICATIONS_FILE', DATA_PATH . 'admin_notifications.json');
}

function getAdminNotifications(int $limit = 30): array {
    $all = readJson(ADMIN_NOTIFICATIONS_FILE);
    if (!is_array($all)) $all = [];
    usort($all, fn($a, $b) => ($b['created_at_ts'] ?? 0) <=> ($a['created_at_ts'] ?? 0));
    return array_slice($all, 0, $limit);
}

function getUnreadAdminNotificationsCount(): int {
    $all = readJson(ADMIN_NOTIFICATIONS_FILE);
    if (!is_array($all)) return 0;
    $count = 0;
    foreach ($all as $n) {
        if (empty($n['read'])) $count++;
    }
    return $count;
}

function addAdminNotification(string $type, string $title, string $message, string $link = '', array $meta = []): array {
    $all = readJson(ADMIN_NOTIFICATIONS_FILE);
    if (!is_array($all)) $all = [];

    $notif = [
        'id'            => 'notif_' . time() . '_' . bin2hex(random_bytes(3)),
        'type'          => $type, // 'order', 'client', 'visitor', 'chat'
        'title'         => $title,
        'message'       => $message,
        'link'          => $link,
        'meta'          => $meta,
        'read'          => false,
        'created_at'    => date('c'),
        'created_at_ts' => time(),
        'time_formatted'=> date('M j, g:i A')
    ];

    array_unshift($all, $notif);
    if (count($all) > 150) {
        $all = array_slice($all, 0, 150);
    }

    atomicWriteJson(ADMIN_NOTIFICATIONS_FILE, $all);
    return $notif;
}

function markAdminNotificationsRead(): bool {
    $all = readJson(ADMIN_NOTIFICATIONS_FILE);
    if (!is_array($all)) return false;
    foreach ($all as &$n) {
        $n['read'] = true;
    }
    unset($n);
    return atomicWriteJson(ADMIN_NOTIFICATIONS_FILE, $all);
}

function clearAdminNotifications(): bool {
    return atomicWriteJson(ADMIN_NOTIFICATIONS_FILE, []);
}

