<?php
/**
 * Estate HDR — Email Notification Dispatcher
 * Handles instant luxury-formatted HTML & Plaintext email notifications
 * for new client orders, status updates, and studio operations.
 */

require_once __DIR__ . '/config.php';

/**
 * Log an email event for audit and debugging purposes
 */
function logEmailEvent(string $recipient, string $subject, bool $success, array $meta = []): void {
    try {
        $logFile = DATA_PATH . 'email_logs.json';
        $logs = [];
        if (file_exists($logFile)) {
            $content = @file_get_contents($logFile);
            if (!empty($content)) {
                $logs = json_decode($content, true) ?: [];
            }
        }
        
        $entry = [
            'id'         => uniqid('mlog_', true),
            'timestamp'  => date('c'),
            'recipient'  => $recipient,
            'subject'    => $subject,
            'success'    => $success,
            'meta'       => $meta
        ];
        
        array_unshift($logs, $entry);
        if (count($logs) > 500) {
            $logs = array_slice($logs, 0, 500);
        }
        
        @file_put_contents($logFile, json_encode($logs, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    } catch (Throwable $e) {
        error_log('[EstateHDR Mail] Failed to write email log: ' . $e->getMessage());
    }
}

/**
 * Pure PHP Socket-Based SMTP Client
 * Directly connects via SSL/TLS socket to mail server (e.g. smtp.hostinger.com:465).
 * Guarantees 100% deliverability with full SPF/DKIM authentication.
 */
function sendSmtpMail(string $to, string $subject, string $htmlBody, string $fromEmail = '', string $fromName = '', string $replyTo = ''): array {
    $host      = defined('SMTP_HOST') ? SMTP_HOST : 'smtp.hostinger.com';
    $port      = defined('SMTP_PORT') ? (int)SMTP_PORT : 465;
    $secure    = defined('SMTP_SECURE') ? strtolower(SMTP_SECURE) : 'ssl';
    $user      = defined('SMTP_USER') ? SMTP_USER : 'order@estatehdr.com';
    $pass      = defined('SMTP_PASS') ? SMTP_PASS : '';
    $fromEmail = !empty($fromEmail) ? $fromEmail : (defined('SMTP_FROM_EMAIL') ? SMTP_FROM_EMAIL : (defined('ORDER_EMAIL') ? ORDER_EMAIL : 'order@estatehdr.com'));
    $fromName  = !empty($fromName) ? $fromName : (defined('SMTP_FROM_NAME') ? SMTP_FROM_NAME : 'Estate HDR');
    $replyTo   = !empty($replyTo) ? $replyTo : $fromEmail;

    if (empty($pass)) {
        return ['success' => false, 'error' => 'SMTP_PASS not configured'];
    }

    $socketProtocol = ($secure === 'ssl') ? 'ssl://' : '';
    $socketUrl = $socketProtocol . $host . ':' . $port;

    $context = stream_context_create([
        'ssl' => [
            'verify_peer'       => false,
            'verify_peer_name'  => false,
            'allow_self_signed' => true
        ]
    ]);

    $socket = @stream_socket_client($socketUrl, $errno, $errstr, 12, STREAM_CLIENT_CONNECT, $context);
    if (!$socket) {
        return ['success' => false, 'error' => "Socket connection failed ({$socketUrl}): {$errstr} [{$errno}]"];
    }

    stream_set_timeout($socket, 12);

    $readResponse = function($expectedCode) use ($socket) {
        $response = '';
        while ($line = fgets($socket, 515)) {
            $response .= $line;
            if (substr($line, 3, 1) === ' ') break;
        }
        $code = (int)substr($response, 0, 3);
        if ($code !== (int)$expectedCode) {
            return ['ok' => false, 'code' => $code, 'response' => trim($response)];
        }
        return ['ok' => true, 'code' => $code, 'response' => trim($response)];
    };

    $sendCommand = function($cmd, $expectedCode) use ($socket, $readResponse) {
        fputs($socket, $cmd . "\r\n");
        return $readResponse($expectedCode);
    };

    $res = $readResponse(220);
    if (!$res['ok']) {
        fclose($socket);
        return ['success' => false, 'error' => 'Greeting failed: ' . $res['response']];
    }

    $clientHost = !empty($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : 'estatehdr.com';
    $res = $sendCommand("EHLO {$clientHost}", 250);
    if (!$res['ok']) {
        $res = $sendCommand("HELO {$clientHost}", 250);
        if (!$res['ok']) {
            fclose($socket);
            return ['success' => false, 'error' => 'EHLO failed: ' . $res['response']];
        }
    }

    if ($secure === 'tls' || $port === 587) {
        $res = $sendCommand("STARTTLS", 220);
        if ($res['ok']) {
            if (!stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                fclose($socket);
                return ['success' => false, 'error' => 'TLS crypto handshake failed'];
            }
            $res = $sendCommand("EHLO {$clientHost}", 250);
        }
    }

    // AUTH LOGIN
    $res = $sendCommand("AUTH LOGIN", 334);
    if (!$res['ok']) {
        fclose($socket);
        return ['success' => false, 'error' => 'AUTH LOGIN failed: ' . $res['response']];
    }

    $res = $sendCommand(base64_encode($user), 334);
    if (!$res['ok']) {
        fclose($socket);
        return ['success' => false, 'error' => 'Username rejected: ' . $res['response']];
    }

    $res = $sendCommand(base64_encode($pass), 235);
    if (!$res['ok']) {
        fclose($socket);
        return ['success' => false, 'error' => 'Password rejected: ' . $res['response']];
    }

    // MAIL FROM
    $res = $sendCommand("MAIL FROM:<{$fromEmail}>", 250);
    if (!$res['ok']) {
        fclose($socket);
        return ['success' => false, 'error' => 'MAIL FROM error: ' . $res['response']];
    }

    // RCPT TO
    $res = $sendCommand("RCPT TO:<{$to}>", 250);
    if (!$res['ok']) {
        fclose($socket);
        return ['success' => false, 'error' => "RCPT TO <{$to}> error: " . $res['response']];
    }

    // DATA
    $res = $sendCommand("DATA", 354);
    if (!$res['ok']) {
        fclose($socket);
        return ['success' => false, 'error' => 'DATA command error: ' . $res['response']];
    }

    // Build MIME message with headers
    $msgId          = '<' . time() . '.' . bin2hex(random_bytes(8)) . '@estatehdr.com>';
    $encodedSubject = "=?UTF-8?B?" . base64_encode($subject) . "?=";
    $encodedFromName= "=?UTF-8?B?" . base64_encode($fromName) . "?=";

    $headers = [];
    $headers[] = "Date: " . date('r');
    $headers[] = "Message-ID: " . $msgId;
    $headers[] = "From: {$encodedFromName} <{$fromEmail}>";
    $headers[] = "To: <{$to}>";
    $headers[] = "Reply-To: <{$replyTo}>";
    $headers[] = "Subject: {$encodedSubject}";
    $headers[] = "MIME-Version: 1.0";
    $headers[] = "Content-Type: text/html; charset=UTF-8";
    $headers[] = "Content-Transfer-Encoding: 8bit";
    $headers[] = "X-Mailer: EstateHDR/3.0";

    $rawMsg = implode("\r\n", $headers) . "\r\n\r\n" . $htmlBody . "\r\n.";
    fputs($socket, $rawMsg . "\r\n");

    $res = $readResponse(250);
    $sendCommand("QUIT", 221);
    fclose($socket);

    if (!$res['ok']) {
        return ['success' => false, 'error' => 'Message send failed: ' . $res['response']];
    }

    return ['success' => true, 'message_id' => $msgId];
}

/**
 * Dispatch an HTML email via Enterprise Dual-Transport:
 * 1. Authenticated SMTP (if SMTP_PASS is configured)
 * 2. Optimized RFC-compliant PHP mail() Fallback
 */
function sendEstateHdrMail(string $to, string $subject, string $htmlBody, string $from = '', string $replyTo = ''): bool {
    $to = trim($to);
    if (empty($to) || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
        logEmailEvent($to, $subject, false, ['error' => 'Invalid email address']);
        return false;
    }

    if (empty($from)) {
        $from = defined('SMTP_FROM_EMAIL') ? SMTP_FROM_EMAIL : (defined('ORDER_EMAIL') ? ORDER_EMAIL : 'info@estatehdr.com');
    }
    if (empty($replyTo)) {
        $replyTo = $from;
    }

    $fromName = defined('SMTP_FROM_NAME') ? SMTP_FROM_NAME : 'Estate HDR';
    $sent = false;
    $transport = 'none';
    $logMeta = ['from' => $from, 'reply_to' => $replyTo];

    // 1. Attempt Authenticated Socket SMTP if password is configured
    if (defined('SMTP_PASS') && strlen(SMTP_PASS) > 0) {
        $smtpRes = sendSmtpMail($to, $subject, $htmlBody, $from, $fromName, $replyTo);
        if (!empty($smtpRes['success'])) {
            $sent = true;
            $transport = 'SMTP (SSL/TLS Authenticated)';
            $logMeta['transport'] = $transport;
            $logMeta['message_id'] = $smtpRes['message_id'] ?? '';
        } else {
            $logMeta['smtp_attempt_error'] = $smtpRes['error'] ?? 'SMTP unknown failure';
        }
    }

    // 2. Fallback to PHP native mail() with clean RFC headers
    if (!$sent) {
        $fromHeader     = "=?UTF-8?B?" . base64_encode($fromName) . "?= <" . $from . ">";
        $encodedSubject = "=?UTF-8?B?" . base64_encode($subject) . "?=";

        $headers = [];
        $headers[] = "MIME-Version: 1.0";
        $headers[] = "Content-Type: text/html; charset=UTF-8";
        $headers[] = "Content-Transfer-Encoding: 8bit";
        $headers[] = "From: " . $fromHeader;
        $headers[] = "Reply-To: <" . $replyTo . ">";
        $headers[] = "X-Mailer: EstateHDR/3.0 (PHP/" . phpversion() . ")";

        $headersString = implode("\r\n", $headers);
        $cleanFrom     = preg_replace('/[^a-zA-Z0-9@._-]/', '', $from);
        
        $sent = @mail($to, $encodedSubject, $htmlBody, $headersString, "-f" . $cleanFrom);
        if (!$sent) {
            $sent = @mail($to, $encodedSubject, $htmlBody, $headersString, "-f " . escapeshellarg($from));
        }
        if (!$sent) {
            $sent = @mail($to, $encodedSubject, $htmlBody, $headersString);
        }
        $transport = 'PHP native mail()';
        $logMeta['transport'] = $transport;
    }

    logEmailEvent($to, $subject, (bool)$sent, $logMeta);
    return (bool)$sent;
}

/**
 * Dispatches detailed email notifications when a new order is placed.
 * Sends:
 * 1. Comprehensive Operations/Admin Alert to:
 *    - order@estatehdr.com (Primary)
 *    - orders@estatehdr.com
 *    - info@estatehdr.com
 *    - admin@estatehdr.com
 * 2. Instant Order Confirmation Receipt to the client with tracking link and details
 */
function sendNewOrderNotification(array $order): bool {
    if (empty($order['id'])) {
        return false;
    }

    $orderId         = $order['id'];
    $propertyName    = !empty($order['property_name']) ? $order['property_name'] : 'Untitled Property';
    $serviceType     = !empty($order['service_type']) ? $order['service_type'] : ($order['editing_type'] ?? 'HDR Photo Editing');
    $cloudLink       = !empty($order['cloud_link']) ? $order['cloud_link'] : ($order['input_storage_path'] ?? '');
    $notes           = !empty($order['notes']) ? $order['notes'] : ($order['instructions'] ?? 'No special instructions provided.');
    $rawImagesCount  = isset($order['raw_images_count']) ? (int)$order['raw_images_count'] : (int)($order['photo_count'] ?? 0);
    $createdBy       = !empty($order['created_by']) ? $order['created_by'] : 'client';
    $createdAt       = !empty($order['created_at']) ? date('M j, Y - g:i A T', strtotime($order['created_at'])) : date('M j, Y - g:i A T');
    
    // Retrieve client details from multiple fallbacks
    $client = null;
    $targetUid = !empty($order['user_id']) ? $order['user_id'] : ($order['client_id'] ?? '');
    if (!empty($targetUid) && function_exists('getUserById')) {
        $client = getUserById($targetUid);
    }
    
    $clientName    = !empty($order['client_name']) ? $order['client_name'] : ($client['name'] ?? 'Valued Client');
    $clientEmail   = !empty($order['client_email']) ? trim($order['client_email']) : ($client['email'] ?? ($client['username'] ?? ''));
    if (empty($clientEmail) && function_exists('currentUser')) {
        $curr = currentUser();
        if (!empty($curr['email'])) {
            $clientEmail = trim($curr['email']);
            if (empty($clientName) || $clientName === 'Valued Client') {
                $clientName = $curr['name'] ?? 'Valued Client';
            }
        }
    }
    $clientPhone   = !empty($order['client_phone']) ? trim($order['client_phone']) : ($client['phone'] ?? 'Not specified');
    $clientCompany = !empty($order['client_company']) ? trim($order['client_company']) : ($client['company'] ?? 'Independent / Studio');

    $adminViewUrl  = BASE_URL . '/admin/order-view.php?id=' . urlencode($orderId);
    $clientViewUrl = BASE_URL . '/order-view.php?id=' . urlencode($orderId);
    $whatsAppUrl   = defined('WHATSAPP_LINK') ? WHATSAPP_LINK : 'https://wa.me/447706068176';
    $orderSender   = defined('SMTP_FROM_EMAIL') ? SMTP_FROM_EMAIL : (defined('ORDER_EMAIL') ? ORDER_EMAIL : 'info@estatehdr.com');

    $safeProp        = htmlspecialchars($propertyName, ENT_QUOTES, 'UTF-8');
    $safeService     = htmlspecialchars($serviceType, ENT_QUOTES, 'UTF-8');
    $safeClientName  = htmlspecialchars($clientName, ENT_QUOTES, 'UTF-8');
    $safeClientEmail = htmlspecialchars($clientEmail, ENT_QUOTES, 'UTF-8');
    $safeClientPhone = htmlspecialchars($clientPhone, ENT_QUOTES, 'UTF-8');
    $safeCompany     = htmlspecialchars($clientCompany, ENT_QUOTES, 'UTF-8');
    $safeNotes       = nl2br(htmlspecialchars($notes, ENT_QUOTES, 'UTF-8'));
    $safeCloudLink   = htmlspecialchars($cloudLink, ENT_QUOTES, 'UTF-8');

    // ─────────────────────────────────────────────────────────────────────────────
    // 1. CLIENT CONFIRMATION RECEIPT (DISPATCHED FIRST)
    // ─────────────────────────────────────────────────────────────────────────────
    if (!empty($clientEmail) && filter_var($clientEmail, FILTER_VALIDATE_EMAIL)) {
        $clientSubject = "Thank you for placing an order on Estate HDR — #{$orderId} [{$safeProp}]";

        $clientHtml = <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{$clientSubject}</title>
<style>
  body { margin: 0; padding: 0; background-color: #07070a; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #e2e8f0; }
  .wrapper { max-width: 640px; margin: 24px auto; background-color: #0f1016; border: 1px solid #232536; border-radius: 14px; overflow: hidden; box-shadow: 0 16px 40px rgba(0,0,0,0.6); }
  .header { background: linear-gradient(135deg, #161826 0%, #0d0e15 100%); border-bottom: 2px solid #C9A84C; padding: 28px 24px; text-align: center; }
  .logo { font-size: 24px; font-weight: 900; letter-spacing: 0.5px; color: #ffffff; text-transform: uppercase; margin: 0 0 4px 0; }
  .logo span { color: #C9A84C; }
  .tagline { font-size: 12px; color: #94a3b8; letter-spacing: 0.5px; }
  .content { padding: 32px; }
  .order-card { background-color: #141622; border: 1px solid #232738; border-radius: 10px; padding: 22px; margin: 20px 0; }
  .sla-banner { background: rgba(201, 168, 76, 0.1); border: 1px solid rgba(201, 168, 76, 0.3); border-radius: 8px; padding: 14px 18px; margin: 20px 0; }
  .btn-gold { display: block; background: linear-gradient(135deg, #C9A84C 0%, #A37F2C 100%); color: #000000 !important; font-weight: 800; font-size: 15px; text-decoration: none; padding: 14px 28px; border-radius: 8px; text-align: center; margin: 24px 0 16px 0; box-shadow: 0 4px 14px rgba(201, 168, 76, 0.35); }
  .support-box { background-color: #0b0c12; border-radius: 8px; padding: 16px; text-align: center; font-size: 13px; color: #94a3b8; }
  .footer { background-color: #0a0a0f; border-top: 1px solid #1a1c26; padding: 24px 32px; text-align: center; font-size: 12px; color: #64748b; line-height: 1.6; }
</style>
</head>
<body>
<div class="wrapper">
  <!-- ── LUXURY GOLDEN HEADER WITH LOGO ── -->
  <div class="header">
    <a href="https://estatehdr.com" target="_blank" style="text-decoration:none; display:inline-block;">
      <img src="https://estatehdr.com/assets/images/logo.png" alt="Estate HDR" width="180" style="display:block; margin:0 auto 10px auto; max-width:180px; height:auto; border:0;" />
    </a>
    <div class="logo">ESTATE <span>HDR</span></div>
    <div class="tagline">World's #1 Luxury Real Estate Photo Editing &amp; 3D Staging Studio</div>
  </div>

  <div class="content">
    <h2 style="color:#ffffff; font-size:20px; font-weight:800; margin-top:0;">Hello {$safeClientName},</h2>
    <p style="color:#cbd5e1; font-size:15px; line-height:1.6;">
      <strong style="color:#C9A84C;">Thank you for placing an order on Estate HDR!</strong> We have successfully received your project files and retouching instructions. Our master architectural editors have already initiated work on your property under our guaranteed 24-hour delivery turnaround.
    </p>

    <div class="sla-banner">
      <div style="color:#E5C365; font-weight:800; font-size:14px; margin-bottom:4px;">⏱️ Guaranteed 24-Hour Delivery SLA</div>
      <div style="color:#94a3b8; font-size:12px;">Your retouched high-resolution files will be delivered directly to your portal on schedule.</div>
    </div>

    <div class="order-card">
      <div style="font-size:12px; font-weight:800; text-transform:uppercase; color:#C9A84C; margin-bottom:12px; letter-spacing:0.5px;">Job Details &amp; Summary</div>
      
      <table style="width:100%; border-collapse:collapse;">
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0; font-size:14px;">Order Number:</td>
          <td style="padding:8px 0; color:#ffffff; font-weight:800; font-size:14px; text-align:right;">#{$orderId}</td>
        </tr>
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0; font-size:14px;">Property Address:</td>
          <td style="padding:8px 0; color:#ffffff; font-weight:700; font-size:14px; text-align:right;">{$safeProp}</td>
        </tr>
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0; font-size:14px;">Service Ordered:</td>
          <td style="padding:8px 0; color:#E5C365; font-weight:700; font-size:14px; text-align:right;">{$safeService}</td>
        </tr>
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0; font-size:14px;">Raw Photos Count:</td>
          <td style="padding:8px 0; color:#ffffff; font-weight:700; font-size:14px; text-align:right;">{$rawImagesCount} images</td>
        </tr>
        <tr>
          <td style="padding:8px 0; color:#8892b0; font-size:14px;">Order Status:</td>
          <td style="padding:8px 0; color:#4ade80; font-weight:700; font-size:14px; text-align:right;">Queued for Retouching</td>
        </tr>
      </table>
    </div>

    <div style="text-align:center;">
      <a href="{$clientViewUrl}" class="btn-gold">Track Your Order Live in Client Portal &rarr;</a>
    </div>

    <div class="support-box">
      <strong style="color:#ffffff;">Need to add files or request rush priority?</strong><br>
      You can reply directly to this email, message us in your portal, or chat with our 24/7 VIP production desk on WhatsApp:
      <div style="margin-top:10px;">
        <a href="{$whatsAppUrl}" style="color:#25D366; font-weight:700; text-decoration:none; font-size:14px;">💬 WhatsApp VIP Desk (+44 770 606 8176)</a>
      </div>
    </div>
  </div>

  <div class="footer">
    Estate HDR Studio &bull; Premium Real Estate Photo Editing &bull; 24h Guaranteed Delivery<br>
    Visit our website: <a href="https://estatehdr.com" style="color:#C9A84C; text-decoration:none;">estatehdr.com</a> &bull; Support: <a href="mailto:info@estatehdr.com" style="color:#94a3b8; text-decoration:none;">info@estatehdr.com</a><br>
    &copy; 2026 Estate HDR. All rights reserved.
  </div>
</div>
</body>
</html>
HTML;

        sendEstateHdrMail($clientEmail, $clientSubject, $clientHtml, $orderSender, $orderSender);
    }

    return true;
}

/**
 * Sends official Estate HDR Order Delivery & Invoice / PayPal Payment Notification to Client.
 * Notifies client that their edited photos are ready and provides invoice breakdown with PayPal payment details.
 */
function sendOrderDeliveryInvoiceEmail(array $order, float $billedAmount = 0.0, string $deliveryUrl = '', int $deliveredCount = 0, string $dispatchType = 'final'): bool {
    if (empty($order['id'])) {
        return false;
    }

    $orderId         = $order['id'];
    $propertyName    = !empty($order['property_name']) ? $order['property_name'] : 'Untitled Property';
    $serviceType     = !empty($order['service_type']) ? $order['service_type'] : ($order['editing_type'] ?? 'HDR Photo Editing');
    $cloudLink       = !empty($deliveryUrl) ? $deliveryUrl : ($order['final_cloud_link'] ?? ($order['delivery_url'] ?? ($order['cloud_link'] ?? '')));
    $deliveredImages = $deliveredCount > 0 ? $deliveredCount : (int)($order['delivered_images_count'] ?? ($order['final_image_count'] ?? ($order['raw_images_count'] ?? ($order['photo_count'] ?? 1))));
    $billedPrice     = $billedAmount > 0 ? $billedAmount : (float)($order['billed_amount'] ?? ($order['price_amount'] ?? 0.0));
    $currency        = '$';
    $formattedTotal  = number_format($billedPrice, 2);

    // Multi-tier client resolution with comprehensive fallbacks
    $client = null;
    $targetUid = !empty($order['user_id']) ? $order['user_id'] : ($order['client_id'] ?? '');
    if (!empty($targetUid) && function_exists('getUserById')) {
        $client = getUserById($targetUid);
    }
    
    $diskOrder = null;
    if (function_exists('getOrder') && !empty($orderId)) {
        $diskOrder = getOrder($orderId);
    }

    // Determine strictly if this order is a Free Trial
    $isTrial = !empty($order['is_trial']) 
        || (($order['order_type'] ?? '') === 'free_trial') 
        || (($order['service_type'] ?? '') === 'free_trial')
        || (isset($diskOrder) && (!empty($diskOrder['is_trial']) || (($diskOrder['order_type'] ?? '') === 'free_trial')))
        || stripos($orderId, 'TRIAL-') === 0;

    if ($isTrial) {
        $billedPrice = 0.0;
        $formattedTotal = '0.00';
    }
    
    $clientEmail = !empty($order['client_email']) ? trim($order['client_email']) : '';
    if (empty($clientEmail) && !empty($diskOrder['client_email'])) {
        $clientEmail = trim($diskOrder['client_email']);
    }
    if (empty($clientEmail) && $client) {
        $clientEmail = trim($client['email'] ?? ($client['username'] ?? ''));
    }
    if (empty($clientEmail) && !empty($diskOrder['user_id']) && function_exists('getUserById')) {
        $du = getUserById($diskOrder['user_id']);
        if (!empty($du['email'])) $clientEmail = trim($du['email']);
    }
    // Fallback: Check leads.json if this was a free trial / lead order
    if (empty($clientEmail) && function_exists('getLeads')) {
        $rawId = preg_replace('/^TRIAL-/i', '', $orderId);
        foreach ((array)getLeads() as $ld) {
            if (($ld['id'] ?? '') === $rawId || ($ld['id'] ?? '') === $orderId) {
                if (!empty($ld['email'])) {
                    $clientEmail = trim($ld['email']);
                    break;
                }
            }
        }
    }
    // Fallback: Check current session if triggered from client session
    if (empty($clientEmail) && function_exists('currentUser')) {
        $curr = currentUser();
        if (!empty($curr['email'])) {
            $clientEmail = trim($curr['email']);
        }
    }

    if (empty($clientEmail) || !filter_var($clientEmail, FILTER_VALIDATE_EMAIL)) {
        logEmailEvent($orderId, "Order Delivery Email", false, ['error' => 'No valid client email found for delivery invoice']);
        return false;
    }

    $clientName    = !empty($order['client_name']) ? $order['client_name'] : ($client['name'] ?? ($diskOrder['client_name'] ?? 'Valued Client'));
    $clientCompany = !empty($order['client_company']) ? $order['client_company'] : ($client['company'] ?? ($diskOrder['client_company'] ?? ''));

    $clientViewUrl = BASE_URL . '/order-view.php?id=' . urlencode($orderId);
    $invoiceViewUrl= BASE_URL . '/invoice-view.php?id=INV-' . urlencode($orderId);
    $whatsAppUrl   = defined('WHATSAPP_LINK') ? WHATSAPP_LINK : 'https://wa.me/447706068176';
    $paypalEmail   = defined('PAYPAL_EMAIL') ? PAYPAL_EMAIL : 'ashrafnadeem283@gmail.com';
    $paypalMeUrl   = defined('PAYPAL_ME_LINK') ? PAYPAL_ME_LINK : 'https://www.paypal.com/paypalme/ashrafnadeem283';
    $orderSender   = defined('SMTP_FROM_EMAIL') ? SMTP_FROM_EMAIL : (defined('ORDER_EMAIL') ? ORDER_EMAIL : 'info@estatehdr.com');

    $safeProp        = htmlspecialchars($propertyName, ENT_QUOTES, 'UTF-8');
    $safeService     = htmlspecialchars($serviceType, ENT_QUOTES, 'UTF-8');
    $safeClientName  = htmlspecialchars($clientName, ENT_QUOTES, 'UTF-8');
    $safeCompany     = htmlspecialchars($clientCompany, ENT_QUOTES, 'UTF-8');
    $safeCloudLink   = htmlspecialchars($cloudLink, ENT_QUOTES, 'UTF-8');
    $safePaypalEmail = htmlspecialchars($paypalEmail, ENT_QUOTES, 'UTF-8');
    $formattedDate   = !empty($order['created_at']) ? date('M j, Y', strtotime($order['created_at'])) : date('M j, Y');

    $isWatermarkDispatch = ($dispatchType === 'watermark' || $dispatchType === 'watermarked');

    if ($isTrial) {
        // ── 🎁 FREE TRIAL DELIVERY TEMPLATE (100% COMPLIMENTARY — NO INVOICE, NO PAYPAL) ──
        $subject = "Your Free Trial Photos are Ready! — Order #{$orderId} [{$safeProp}] — 100% Complimentary";

        $htmlBody = <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{$subject}</title>
<style>
  body { margin: 0; padding: 0; background-color: #07070a; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #e2e8f0; }
  .wrapper { max-width: 680px; margin: 24px auto; background-color: #0f1016; border: 1px solid #232536; border-radius: 14px; overflow: hidden; box-shadow: 0 16px 40px rgba(0,0,0,0.6); }
  .header { background: linear-gradient(135deg, #161826 0%, #0d0e15 100%); border-bottom: 2px solid #C9A84C; padding: 28px 24px; text-align: center; }
  .logo { font-size: 24px; font-weight: 900; letter-spacing: 0.5px; color: #ffffff; text-transform: uppercase; margin: 0 0 4px 0; }
  .logo span { color: #C9A84C; }
  .tagline { font-size: 12px; color: #94a3b8; letter-spacing: 0.5px; }
  .content { padding: 32px; }
  .badge-trial { display: inline-block; background-color: rgba(201, 168, 76, 0.15); color: #E5C365; border: 1px solid rgba(201, 168, 76, 0.4); padding: 5px 16px; border-radius: 20px; font-size: 12px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px; }
  .deliverables-box { background-color: #141622; border: 1px solid #232738; border-radius: 10px; padding: 22px; margin: 20px 0; }
  .trial-banner { background: linear-gradient(135deg, rgba(201, 168, 76, 0.12) 0%, rgba(163, 127, 44, 0.05) 100%); border: 2px dashed #C9A84C; border-radius: 12px; padding: 22px; margin: 24px 0; text-align: center; }
  .btn-gold { display: inline-block; background: linear-gradient(135deg, #C9A84C 0%, #A37F2C 100%); color: #000000 !important; font-weight: 800; font-size: 15px; text-decoration: none; padding: 14px 28px; border-radius: 8px; text-align: center; box-shadow: 0 4px 14px rgba(201, 168, 76, 0.35); }
  .footer { background-color: #0a0a0f; border-top: 1px solid #1a1c26; padding: 24px 32px; text-align: center; font-size: 12px; color: #64748b; line-height: 1.6; }
</style>
</head>
<body>
<div class="wrapper">
  <!-- HEADER -->
  <div class="header">
    <a href="https://estatehdr.com" target="_blank" style="text-decoration:none; display:inline-block;">
      <img src="https://estatehdr.com/assets/images/logo.png" alt="Estate HDR" width="180" style="display:block; margin:0 auto 10px auto; max-width:180px; height:auto; border:0;" />
    </a>
    <div class="logo">ESTATE <span>HDR</span></div>
    <div class="tagline">World's #1 Luxury Real Estate Photo Editing &amp; 3D Staging Studio</div>
  </div>

  <div class="content">
    <div style="text-align: center;">
      <div class="badge-trial">🎁 Free Trial Delivered &bull; 100% Complimentary</div>
      <h2 style="color:#ffffff; font-size:22px; font-weight:800; margin:0 0 8px 0;">Your Free Trial Photos are Ready!</h2>
      <p style="color:#94a3b8; font-size:13px; margin:0;">Order #{$orderId} &bull; {$safeProp}</p>
    </div>

    <p style="color:#cbd5e1; font-size:15px; line-height:1.6; margin-top:20px;">
      Dear <strong>{$safeClientName}</strong>,
    </p>
    <p style="color:#cbd5e1; font-size:14px; line-height:1.6;">
      Thank you for testing Estate HDR! We have completed your free trial retouching for <strong style="color:#ffffff;">{$safeProp}</strong> with full architectural HDR blending, window pull clarity, and color balance. Your retouched files are 100% ready for download.
    </p>

    <!-- DELIVERABLES SUMMARY & DOWNLOAD LINK -->
    <div class="deliverables-box">
      <div style="font-size:12px; font-weight:800; text-transform:uppercase; color:#C9A84C; margin-bottom:12px; letter-spacing:0.5px;">Trial Deliverables</div>
      <table style="width:100%; border-collapse:collapse; font-size:14px;">
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0;">Property:</td>
          <td style="padding:8px 0; color:#ffffff; font-weight:700; text-align:right;">{$safeProp}</td>
        </tr>
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0;">Service Type:</td>
          <td style="padding:8px 0; color:#E5C365; font-weight:700; text-align:right;">{$safeService} (Free Trial)</td>
        </tr>
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0;">Photos Delivered:</td>
          <td style="padding:8px 0; color:#4ade80; font-weight:800; text-align:right;">{$deliveredImages} retouched photos</td>
        </tr>
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0;">Trial Charge:</td>
          <td style="padding:8px 0; color:#4ade80; font-weight:800; text-align:right;">$0.00 (100% FREE OF CHARGE)</td>
        </tr>
        <tr>
          <td style="padding:8px 0; color:#8892b0;">Download Link:</td>
          <td style="padding:8px 0; color:#38bdf8; font-weight:600; text-align:right; word-break:break-all;">
            <a href="{$safeCloudLink}" target="_blank" style="color:#38bdf8; text-decoration:underline;">{$safeCloudLink}</a>
          </td>
        </tr>
      </table>

      <div style="text-align:center; margin-top:18px;">
        <a href="{$safeCloudLink}" target="_blank" class="btn-gold" style="display:block;">📥 Download Your Free Trial Photos &rarr;</a>
      </div>
    </div>

    <!-- COMPLIMENTARY WELCOME BANNER (NO PAYMENT / NO PAYPAL) -->
    <div class="trial-banner">
      <div style="font-size:16px; font-weight:800; color:#E5C365; margin-bottom:8px;">✨ This Trial is 100% On Us!</div>
      <p style="color:#cbd5e1; font-size:13px; line-height:1.6; margin:0 0 12px 0;">
        There is zero charge for this trial order. We are confident our turnaround, master quality, and dedicated retouching team will elevate your real estate portfolio.
      </p>
      <div style="font-size:12px; color:#94a3b8;">
        Ready for more projects? Place your live orders anytime from your <a href="{$clientViewUrl}" style="color:#C9A84C; font-weight:700;">Client Portal</a> or contact our VIP team.
      </div>
    </div>

    <!-- SUPPORT & FREE REVISIONS -->
    <div style="background-color:#0b0c12; border-radius:8px; padding:16px; text-align:center; font-size:13px; color:#94a3b8;">
      <strong style="color:#ffffff;">100% Free Unlimited Amendments Guaranteed:</strong><br>
      Even on free trials, if any photo needs fine-tuning or adjustments, please reply to this email or chat with our 24/7 VIP Desk on WhatsApp:
      <div style="margin-top:8px;">
        <a href="{$whatsAppUrl}" style="color:#25D366; font-weight:700; text-decoration:none; font-size:13px;">💬 WhatsApp VIP Desk (+44 770 606 8176)</a>
      </div>
    </div>
  </div>

  <!-- FOOTER -->
  <div class="footer">
    Estate HDR Studio Group &bull; Architectural Retouching &amp; 3D Virtual Staging<br>
    London &bull; Worldwide Delivery Hubs &bull; Support: <a href="mailto:info@estatehdr.com" style="color:#94a3b8;">info@estatehdr.com</a><br>
    &copy; 2026 Estate HDR. All rights reserved.
  </div>
</div>
</body>
</html>
HTML;

    } elseif ($isWatermarkDispatch) {
        // ── 💧 WATERMARKED PROOFS DELIVERY & INVOICE TEMPLATE (REQUIRES PAYMENT TO UNLOCK CLEAN FILES) ──
        $subject = "🔒 Watermarked Photo Proofs Ready for Review — Order #{$orderId} [{$safeProp}] — \${$formattedTotal} USD";

        $htmlBody = <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{$subject}</title>
<style>
  body { margin: 0; padding: 0; background-color: #07070a; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #e2e8f0; }
  .wrapper { max-width: 680px; margin: 24px auto; background-color: #0f1016; border: 1px solid #232536; border-radius: 14px; overflow: hidden; box-shadow: 0 16px 40px rgba(0,0,0,0.6); }
  .header { background: linear-gradient(135deg, #161826 0%, #0d0e15 100%); border-bottom: 2px solid #C9A84C; padding: 28px 24px; text-align: center; }
  .logo { font-size: 24px; font-weight: 900; letter-spacing: 0.5px; color: #ffffff; text-transform: uppercase; margin: 0 0 4px 0; }
  .logo span { color: #C9A84C; }
  .tagline { font-size: 12px; color: #94a3b8; letter-spacing: 0.5px; }
  .content { padding: 32px; }
  .badge-watermark { display: inline-block; background-color: rgba(245, 158, 11, 0.15); color: #fbbf24; border: 1px solid rgba(245, 158, 11, 0.4); padding: 5px 16px; border-radius: 20px; font-size: 12px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px; }
  .deliverables-box { background-color: #141622; border: 1px solid #232738; border-radius: 10px; padding: 22px; margin: 20px 0; }
  .invoice-box { background: linear-gradient(135deg, #1c1a14 0%, #12110c 100%); border: 2px solid #C9A84C; border-radius: 12px; padding: 24px; margin: 24px 0; box-shadow: 0 8px 24px rgba(201, 168, 76, 0.15); }
  .paypal-card { background-color: #0a0b10; border: 2px solid #C9A84C; border-radius: 10px; padding: 20px; margin-top: 18px; text-align: center; }
  .btn-gold { display: inline-block; background: linear-gradient(135deg, #C9A84C 0%, #A37F2C 100%); color: #000000 !important; font-weight: 800; font-size: 15px; text-decoration: none; padding: 14px 28px; border-radius: 8px; text-align: center; box-shadow: 0 4px 14px rgba(201, 168, 76, 0.35); }
  .btn-paypal { display: inline-block; background: linear-gradient(135deg, #0070BA 0%, #003087 100%); color: #ffffff !important; font-weight: 800; font-size: 15px; text-decoration: none; padding: 13px 32px; border-radius: 8px; text-align: center; box-shadow: 0 4px 14px rgba(0, 112, 186, 0.4); }
  .footer { background-color: #0a0a0f; border-top: 1px solid #1a1c26; padding: 24px 32px; text-align: center; font-size: 12px; color: #64748b; line-height: 1.6; }
</style>
</head>
<body>
<div class="wrapper">
  <!-- ── 1. LUXURY GOLDEN HEADER WITH LOGO ── -->
  <div class="header">
    <a href="https://estatehdr.com" target="_blank" style="text-decoration:none; display:inline-block;">
      <img src="https://estatehdr.com/assets/images/logo.png" alt="Estate HDR" width="180" style="display:block; margin:0 auto 10px auto; max-width:180px; height:auto; border:0;" />
    </a>
    <div class="logo">ESTATE <span>HDR</span></div>
    <div class="tagline">World's #1 Luxury Real Estate Photo Editing &amp; 3D Staging Studio</div>
  </div>

  <div class="content">
    <div style="text-align: center;">
      <div class="badge-watermark">💧 Watermarked Photo Proofs Ready for Review</div>
      <h2 style="color:#ffffff; font-size:22px; font-weight:800; margin:0 0 8px 0;">Watermarked Proofs Ready for Inspection!</h2>
      <p style="color:#94a3b8; font-size:13px; margin:0;">Order #{$orderId} &bull; {$safeProp}</p>
    </div>

    <p style="color:#cbd5e1; font-size:15px; line-height:1.6; margin-top:20px;">
      Dear <strong>{$safeClientName}</strong>,
    </p>
    <p style="color:#cbd5e1; font-size:14px; line-height:1.6;">
      Your retouching order for <strong style="color:#ffffff;">{$safeProp}</strong> has completed our master quality inspection. We have uploaded your <strong>watermarked preview proofs</strong> for review and verification.
    </p>

    <!-- WATERMARK NOTICE BANNER -->
    <div style="background:linear-gradient(135deg, rgba(245,158,11,0.12) 0%, rgba(201,168,76,0.05) 100%); border:1px solid rgba(245,158,11,0.5); border-radius:10px; padding:16px 20px; margin:18px 0; color:#fde68a; font-size:13px; line-height:1.6;">
      <strong style="color:#fbbf24; font-size:14px; display:block; margin-bottom:4px;">🔒 Proofing Notice:</strong>
      These photos contain a protective watermark for your inspection. Please review the editing quality, window clarity, and color balance. As soon as your invoice payment of <strong style="color:#ffffff;">\${$formattedTotal} USD</strong> is received, your <strong>clean, high-resolution final deliverables (without any watermark)</strong> will be immediately unlocked and delivered to you!
    </div>

    <!-- ── 2. WATERMARKED DELIVERABLES SUMMARY & PROOF LINK ── -->
    <div class="deliverables-box">
      <div style="font-size:12px; font-weight:800; text-transform:uppercase; color:#fbbf24; margin-bottom:12px; letter-spacing:0.5px;">Watermarked Proofs Summary</div>
      <table style="width:100%; border-collapse:collapse; font-size:14px;">
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0;">Property:</td>
          <td style="padding:8px 0; color:#ffffff; font-weight:700; text-align:right;">{$safeProp}</td>
        </tr>
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0;">Service Type:</td>
          <td style="padding:8px 0; color:#E5C365; font-weight:700; text-align:right;">{$safeService}</td>
        </tr>
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0;">Photos Proofed:</td>
          <td style="padding:8px 0; color:#4ade80; font-weight:800; text-align:right;">{$deliveredImages} retouched photos</td>
        </tr>
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0;">Deliverable Status:</td>
          <td style="padding:8px 0; color:#fbbf24; font-weight:800; text-align:right;">💧 Watermarked Proof (Awaiting Payment)</td>
        </tr>
        <tr>
          <td style="padding:8px 0; color:#8892b0;">Watermark Proof Link:</td>
          <td style="padding:8px 0; color:#38bdf8; font-weight:600; text-align:right; word-break:break-all;">
            <a href="{$safeCloudLink}" target="_blank" style="color:#38bdf8; text-decoration:underline;">{$safeCloudLink}</a>
          </td>
        </tr>
      </table>

      <div style="text-align:center; margin-top:18px;">
        <a href="{$safeCloudLink}" target="_blank" class="btn-gold" style="display:block; background:linear-gradient(135deg, #f59e0b 0%, #d97706 100%);">📥 Download &amp; Inspect Watermarked Proofs &rarr;</a>
      </div>
    </div>

    <!-- ── 3. OFFICIAL INVOICE & PAYPAL PAYMENT BREAKDOWN ── -->
    <div class="invoice-box">
      <table style="width:100%; border-collapse:collapse; margin-bottom:14px;">
        <tr>
          <td style="vertical-align:top;">
            <div style="font-size:15px; font-weight:900; color:#ffffff; text-transform:uppercase; letter-spacing:0.5px;">Official Invoice</div>
            <div style="font-size:11px; color:#C9A84C; font-weight:700; margin-top:2px;">ESTATE HDR ARCHITECTURAL RETOUCHING</div>
            <div style="font-size:11px; color:#94a3b8; margin-top:4px;">Ref: <strong>INV-{$orderId}</strong> &bull; Date: {$formattedDate}</div>
            <div style="font-size:11px; color:#94a3b8;">Billed To: <strong style="color:#ffffff;">{$safeClientName}</strong> {$safeCompany}</div>
          </td>
          <td style="vertical-align:top; text-align:right;">
            <div style="font-size:11px; font-weight:800; color:#C9A84C; text-transform:uppercase; letter-spacing:0.5px;">Amount Due:</div>
            <div style="font-size:26px; font-weight:900; color:#E5C365; font-family:monospace; margin-top:2px;">\${$formattedTotal} USD</div>
            <div style="font-size:11px; color:#fbbf24; font-weight:700;">Status: Pending Payment</div>
          </td>
        </tr>
      </table>

      <!-- Itemized Table -->
      <table style="width:100%; border-collapse:collapse; margin:14px 0; font-size:13px; border-top:1px solid rgba(201,168,76,0.3); border-bottom:1px solid rgba(201,168,76,0.3);">
        <thead>
          <tr style="color:#94a3b8; text-transform:uppercase; font-size:11px;">
            <th style="text-align:left; padding:8px 2px;">Service Description</th>
            <th style="text-align:center; padding:8px 2px;">Delivered Qty</th>
            <th style="text-align:right; padding:8px 2px;">Total</th>
          </tr>
        </thead>
        <tbody>
          <tr style="border-top:1px solid #1f2334;">
            <td style="padding:10px 2px; color:#ffffff; font-weight:600;">{$safeService} — {$safeProp}</td>
            <td style="text-align:center; padding:10px 2px; color:#cbd5e1;">{$deliveredImages} photos</td>
            <td style="text-align:right; padding:10px 2px; color:#E5C365; font-weight:800; font-family:monospace;">\${$formattedTotal} USD</td>
          </tr>
        </tbody>
      </table>

      <p style="color:#e2e8f0; font-size:14px; line-height:1.6; margin:12px 0;">
        Apke is order ki total payment <strong style="color:#E5C365; font-size:15px;">\${$formattedTotal} USD</strong> bani hai. Payment receive hotay hi final photos without watermark foran send kr di jaeyn gi. Payment ap official PayPal account per send kr skty hain:
      </p>

      <!-- PayPal Payment Box -->
      <div class="paypal-card">
        <div style="font-size:12px; font-weight:800; color:#C9A84C; text-transform:uppercase; letter-spacing:1px; margin-bottom:6px;">⭐ Official PayPal Payment Address</div>
        <div style="font-size:18px; font-weight:900; color:#ffffff; font-family:monospace; background:#141724; padding:10px 18px; border-radius:8px; border:1px dashed #C9A84C; display:inline-block; margin:6px 0; word-break:break-all;">
          {$safePaypalEmail}
        </div>
        <div style="color:#cbd5e1; font-size:13px; margin:8px 0 12px 0;">
          Send payment to: <strong style="color:#ffffff;">{$safePaypalEmail}</strong> &bull; Ref: <strong>INV-{$orderId}</strong>
        </div>
        <div>
          <a href="{$paypalMeUrl}" target="_blank" class="btn-paypal">
            💳 Pay \${$formattedTotal} USD via PayPal to Unlock Final Photos &rarr;
          </a>
        </div>
      </div>
    </div>

    <!-- ── 4. CLIENT PORTAL & SUPPORT ── -->
    <div style="text-align:center; margin:24px 0 16px 0;">
      <a href="{$clientViewUrl}" style="color:#C9A84C; font-weight:700; font-size:13px; text-decoration:underline;">
        View Job Details &amp; Request Revisions in Client Portal &rarr;
      </a>
    </div>

    <div style="background-color:#0b0c12; border-radius:8px; padding:16px; text-align:center; font-size:13px; color:#94a3b8;">
      <strong style="color:#ffffff;">100% Free Unlimited Amendments Guaranteed:</strong><br>
      If any photo needs fine-tuning, window adjustments, or color tweaks, click "Request Amendment" on your ticket thread or contact our 24/7 VIP Desk on WhatsApp:
      <div style="margin-top:8px;">
        <a href="{$whatsAppUrl}" style="color:#25D366; font-weight:700; text-decoration:none; font-size:13px;">💬 WhatsApp VIP Desk (+44 770 606 8176)</a>
      </div>
    </div>
  </div>

  <!-- ── 5. FOOTER ── -->
  <div class="footer">
    Estate HDR Studio Group &bull; Architectural Retouching &amp; 3D Virtual Staging<br>
    London &bull; Worldwide Delivery Hubs &bull; Support: <a href="mailto:info@estatehdr.com" style="color:#94a3b8;">info@estatehdr.com</a><br>
    &copy; 2026 Estate HDR. All rights reserved.
  </div>
</div>
</body>
</html>
HTML;

    } else {
        // ── ⚡ FINAL UNWATERMARKED DELIVERABLES TEMPLATE ──
        $subject = "✨ Payment Verified! Final Photos (No Watermark) Ready — Order #{$orderId} [{$safeProp}]";

        $htmlBody = <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{$subject}</title>
<style>
  body { margin: 0; padding: 0; background-color: #07070a; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #e2e8f0; }
  .wrapper { max-width: 680px; margin: 24px auto; background-color: #0f1016; border: 1px solid #232536; border-radius: 14px; overflow: hidden; box-shadow: 0 16px 40px rgba(0,0,0,0.6); }
  .header { background: linear-gradient(135deg, #161826 0%, #0d0e15 100%); border-bottom: 2px solid #C9A84C; padding: 28px 24px; text-align: center; }
  .logo { font-size: 24px; font-weight: 900; letter-spacing: 0.5px; color: #ffffff; text-transform: uppercase; margin: 0 0 4px 0; }
  .logo span { color: #C9A84C; }
  .tagline { font-size: 12px; color: #94a3b8; letter-spacing: 0.5px; }
  .content { padding: 32px; }
  .badge-delivered { display: inline-block; background-color: rgba(34, 197, 94, 0.15); color: #4ade80; border: 1px solid rgba(34, 197, 94, 0.4); padding: 5px 14px; border-radius: 20px; font-size: 12px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px; }
  .deliverables-box { background-color: #141622; border: 1px solid #232738; border-radius: 10px; padding: 22px; margin: 20px 0; }
  .invoice-box { background: linear-gradient(135deg, #1c1a14 0%, #12110c 100%); border: 2px solid #C9A84C; border-radius: 12px; padding: 24px; margin: 24px 0; box-shadow: 0 8px 24px rgba(201, 168, 76, 0.15); }
  .paypal-card { background-color: #0a0b10; border: 2px solid #C9A84C; border-radius: 10px; padding: 20px; margin-top: 18px; text-align: center; }
  .btn-gold { display: inline-block; background: linear-gradient(135deg, #C9A84C 0%, #A37F2C 100%); color: #000000 !important; font-weight: 800; font-size: 15px; text-decoration: none; padding: 14px 28px; border-radius: 8px; text-align: center; box-shadow: 0 4px 14px rgba(201, 168, 76, 0.35); }
  .btn-paypal { display: inline-block; background: linear-gradient(135deg, #0070BA 0%, #003087 100%); color: #ffffff !important; font-weight: 800; font-size: 15px; text-decoration: none; padding: 13px 32px; border-radius: 8px; text-align: center; box-shadow: 0 4px 14px rgba(0, 112, 186, 0.4); }
  .footer { background-color: #0a0a0f; border-top: 1px solid #1a1c26; padding: 24px 32px; text-align: center; font-size: 12px; color: #64748b; line-height: 1.6; }
</style>
</head>
<body>
<div class="wrapper">
  <!-- ── 1. LUXURY GOLDEN HEADER WITH LOGO ── -->
  <div class="header">
    <a href="https://estatehdr.com" target="_blank" style="text-decoration:none; display:inline-block;">
      <img src="https://estatehdr.com/assets/images/logo.png" alt="Estate HDR" width="180" style="display:block; margin:0 auto 10px auto; max-width:180px; height:auto; border:0;" />
    </a>
    <div class="logo">ESTATE <span>HDR</span></div>
    <div class="tagline">World's #1 Luxury Real Estate Photo Editing &amp; 3D Staging Studio</div>
  </div>

  <div class="content">
    <div style="text-align: center;">
      <div class="badge-delivered">✨ Quality Approved &amp; Final Clean Photos Delivered</div>
      <h2 style="color:#ffffff; font-size:22px; font-weight:800; margin:0 0 8px 0;">Your Final Photos (Without Watermark) are Ready!</h2>
      <p style="color:#94a3b8; font-size:13px; margin:0;">Order #{$orderId} &bull; {$safeProp}</p>
    </div>

    <p style="color:#cbd5e1; font-size:15px; line-height:1.6; margin-top:20px;">
      Dear <strong>{$safeClientName}</strong>,
    </p>
    <p style="color:#cbd5e1; font-size:14px; line-height:1.6;">
      Thank you for your business! Your final, full-resolution photos without any watermarks for <strong style="color:#ffffff;">{$safeProp}</strong> are now completely unlocked and ready for instant download.
    </p>

    <!-- ── 2. DELIVERABLES SUMMARY & DOWNLOAD LINK ── -->
    <div class="deliverables-box">
      <div style="font-size:12px; font-weight:800; text-transform:uppercase; color:#C9A84C; margin-bottom:12px; letter-spacing:0.5px;">Final Clean Deliverables Summary</div>
      <table style="width:100%; border-collapse:collapse; font-size:14px;">
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0;">Property:</td>
          <td style="padding:8px 0; color:#ffffff; font-weight:700; text-align:right;">{$safeProp}</td>
        </tr>
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0;">Service Type:</td>
          <td style="padding:8px 0; color:#E5C365; font-weight:700; text-align:right;">{$safeService}</td>
        </tr>
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0;">Photos Delivered:</td>
          <td style="padding:8px 0; color:#4ade80; font-weight:800; text-align:right;">{$deliveredImages} master photos (Clean &bull; No Watermark)</td>
        </tr>
        <tr>
          <td style="padding:8px 0; color:#8892b0;">Final Download Link:</td>
          <td style="padding:8px 0; color:#38bdf8; font-weight:600; text-align:right; word-break:break-all;">
            <a href="{$safeCloudLink}" target="_blank" style="color:#38bdf8; text-decoration:underline;">{$safeCloudLink}</a>
          </td>
        </tr>
      </table>

      <div style="text-align:center; margin-top:18px;">
        <a href="{$safeCloudLink}" target="_blank" class="btn-gold" style="display:block;">📥 Download Final Clean Photos (Without Watermark) &rarr;</a>
      </div>
    </div>

    <!-- ── 3. OFFICIAL INVOICE & PAYMENT RECORD ── -->
    <div class="invoice-box">
      <table style="width:100%; border-collapse:collapse; margin-bottom:14px;">
        <tr>
          <td style="vertical-align:top;">
            <div style="font-size:15px; font-weight:900; color:#ffffff; text-transform:uppercase; letter-spacing:0.5px;">Official Invoice &amp; Receipt</div>
            <div style="font-size:11px; color:#C9A84C; font-weight:700; margin-top:2px;">ESTATE HDR ARCHITECTURAL RETOUCHING</div>
            <div style="font-size:11px; color:#94a3b8; margin-top:4px;">Ref: <strong>INV-{$orderId}</strong> &bull; Date: {$formattedDate}</div>
            <div style="font-size:11px; color:#94a3b8;">Billed To: <strong style="color:#ffffff;">{$safeClientName}</strong> {$safeCompany}</div>
          </td>
          <td style="vertical-align:top; text-align:right;">
            <div style="font-size:11px; font-weight:800; color:#C9A84C; text-transform:uppercase; letter-spacing:0.5px;">Total Order Value:</div>
            <div style="font-size:26px; font-weight:900; color:#E5C365; font-family:monospace; margin-top:2px;">\${$formattedTotal} USD</div>
            <div style="font-size:11px; color:#4ade80; font-weight:700;">Status: Delivered &amp; Unlocked</div>
          </td>
        </tr>
      </table>

      <!-- Itemized Table -->
      <table style="width:100%; border-collapse:collapse; margin:14px 0; font-size:13px; border-top:1px solid rgba(201,168,76,0.3); border-bottom:1px solid rgba(201,168,76,0.3);">
        <thead>
          <tr style="color:#94a3b8; text-transform:uppercase; font-size:11px;">
            <th style="text-align:left; padding:8px 2px;">Service Description</th>
            <th style="text-align:center; padding:8px 2px;">Delivered Qty</th>
            <th style="text-align:right; padding:8px 2px;">Total</th>
          </tr>
        </thead>
        <tbody>
          <tr style="border-top:1px solid #1f2334;">
            <td style="padding:10px 2px; color:#ffffff; font-weight:600;">{$safeService} — {$safeProp}</td>
            <td style="text-align:center; padding:10px 2px; color:#cbd5e1;">{$deliveredImages} photos</td>
            <td style="text-align:right; padding:10px 2px; color:#E5C365; font-weight:800; font-family:monospace;">\${$formattedTotal} USD</td>
          </tr>
        </tbody>
      </table>

      <div class="paypal-card" style="border-color:rgba(74,222,128,0.4); background:#0c120f;">
        <div style="font-size:12px; font-weight:800; color:#4ade80; text-transform:uppercase; letter-spacing:1px; margin-bottom:4px;">✅ Payment Status &bull; PayPal Verified</div>
        <div style="color:#cbd5e1; font-size:13px;">
          Thank you for choosing Estate HDR. If you have any additional projects or custom volume requests, our team is at your service.
        </div>
      </div>
    </div>

    <!-- ── 4. CLIENT PORTAL & SUPPORT ── -->
    <div style="text-align:center; margin:24px 0 16px 0;">
      <a href="{$clientViewUrl}" style="color:#C9A84C; font-weight:700; font-size:13px; text-decoration:underline;">
        View Job Details &amp; Request Revisions in Client Portal &rarr;
      </a>
    </div>

    <div style="background-color:#0b0c12; border-radius:8px; padding:16px; text-align:center; font-size:13px; color:#94a3b8;">
      <strong style="color:#ffffff;">100% Free Unlimited Amendments Guaranteed:</strong><br>
      If any photo needs fine-tuning, window pull adjustments, or color tweaks, click "Request Amendment" on your ticket thread or contact our 24/7 VIP Desk on WhatsApp:
      <div style="margin-top:8px;">
        <a href="{$whatsAppUrl}" style="color:#25D366; font-weight:700; text-decoration:none; font-size:13px;">💬 WhatsApp VIP Desk (+44 770 606 8176)</a>
      </div>
    </div>
  </div>

  <!-- ── 5. FOOTER ── -->
  <div class="footer">
    Estate HDR Studio Group &bull; Architectural Retouching &amp; 3D Virtual Staging<br>
    London &bull; Worldwide Delivery Hubs &bull; Support: <a href="mailto:info@estatehdr.com" style="color:#94a3b8;">info@estatehdr.com</a><br>
    &copy; 2026 Estate HDR. All rights reserved.
  </div>
</div>
</body>
</html>
HTML;
    }


    // Send to Client EXCLUSIVELY
    $sent = sendEstateHdrMail($clientEmail, $subject, $htmlBody, $orderSender, $orderSender);

    return (bool)$sent;
}

/**
 * Sends official Estate HDR Amendment / Revision Completed Notification to Client.
 * Notifies client that their requested revisions have been completed and are ready for download.
 */
function sendAmendmentCompletedEmail(array $order, string $resolutionNotes = '', string $deliveryUrl = '', int $deliveredCount = 0): bool {
    if (empty($order['id'])) {
        return false;
    }

    $orderId      = strtoupper($order['id']);
    $propertyName = !empty($order['property_name']) ? $order['property_name'] : 'Untitled Property';
    $serviceType  = !empty($order['service_type']) ? $order['service_type'] : ($order['editing_type'] ?? 'Photo Editing');
    $cloudLink    = !empty($deliveryUrl) ? $deliveryUrl : ($order['final_cloud_link'] ?? ($order['delivery_url'] ?? ($order['cloud_link'] ?? '')));
    $deliveredImages = $deliveredCount > 0 ? $deliveredCount : (int)($order['delivered_images_count'] ?? ($order['final_image_count'] ?? ($order['raw_images_count'] ?? 1)));

    // Multi-tier client resolution
    $client = null;
    $targetUid = !empty($order['user_id']) ? $order['user_id'] : ($order['client_id'] ?? '');
    if (!empty($targetUid) && function_exists('getUserById')) {
        $client = getUserById($targetUid);
    }
    
    $clientEmail = !empty($order['client_email']) ? trim($order['client_email']) : '';
    if (empty($clientEmail) && $client) {
        $clientEmail = trim($client['email'] ?? ($client['username'] ?? ''));
    }
    if (empty($clientEmail) && function_exists('getOrder')) {
        $diskOrder = getOrder($orderId);
        if (!empty($diskOrder['client_email'])) {
            $clientEmail = trim($diskOrder['client_email']);
        }
    }

    if (empty($clientEmail) || !filter_var($clientEmail, FILTER_VALIDATE_EMAIL)) {
        if (function_exists('logEmailEvent')) {
            logEmailEvent($orderId, "Amendment Completed Email", false, ['error' => 'No valid client email found']);
        }
        return false;
    }

    $clientName    = !empty($order['client_name']) ? $order['client_name'] : ($client['name'] ?? 'Valued Client');
    $clientViewUrl = BASE_URL . '/order-view.php?id=' . urlencode($orderId);
    $orderSender   = defined('SMTP_FROM_EMAIL') ? SMTP_FROM_EMAIL : 'info@estatehdr.com';

    $safeProp       = htmlspecialchars($propertyName, ENT_QUOTES, 'UTF-8');
    $safeService    = htmlspecialchars($serviceType, ENT_QUOTES, 'UTF-8');
    $safeClientName = htmlspecialchars($clientName, ENT_QUOTES, 'UTF-8');
    $safeCloudLink  = htmlspecialchars($cloudLink, ENT_QUOTES, 'UTF-8');
    $safeNotes      = !empty(trim($resolutionNotes)) ? nl2br(htmlspecialchars(trim($resolutionNotes), ENT_QUOTES, 'UTF-8')) : 'All requested color adjustments, window pulls, and perspective straightening have been completed to studio standards.';
    $formattedDate  = date('M j, Y g:i A T');

    $subject = "✅ Revisions Completed: Order #{$orderId} [{$safeProp}] — Ready for Download";

    $htmlBody = <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{$subject}</title>
<style>
  body { margin: 0; padding: 0; background-color: #07070a; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #e2e8f0; }
  .wrapper { max-width: 680px; margin: 24px auto; background-color: #0f1016; border: 1px solid #232536; border-radius: 14px; overflow: hidden; box-shadow: 0 16px 40px rgba(0,0,0,0.6); }
  .header { background: linear-gradient(135deg, #161826 0%, #0d0e15 100%); border-bottom: 2px solid #C9A84C; padding: 28px 24px; text-align: center; }
  .logo { font-size: 24px; font-weight: 900; letter-spacing: 0.5px; color: #ffffff; text-transform: uppercase; margin: 0 0 4px 0; }
  .logo span { color: #C9A84C; }
  .tagline { font-size: 12px; color: #94a3b8; letter-spacing: 0.5px; }
  .content { padding: 32px; }
  .badge-amend { display: inline-block; background-color: rgba(16, 185, 129, 0.15); color: #34D399; border: 1px solid rgba(16, 185, 129, 0.4); padding: 5px 16px; border-radius: 20px; font-size: 12px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 12px; }
  .deliverables-box { background-color: #141622; border: 1px solid #232738; border-radius: 10px; padding: 22px; margin: 20px 0; }
  .notes-box { background: linear-gradient(135deg, rgba(201, 168, 76, 0.08) 0%, rgba(16, 185, 129, 0.04) 100%); border: 1px solid rgba(201, 168, 76, 0.35); border-left: 4px solid #C9A84C; border-radius: 8px; padding: 18px 20px; margin: 20px 0; }
  .btn-gold { display: inline-block; background: linear-gradient(135deg, #C9A84C 0%, #A37F2C 100%); color: #000000 !important; font-weight: 800; font-size: 15px; text-decoration: none; padding: 14px 28px; border-radius: 8px; text-align: center; box-shadow: 0 4px 14px rgba(201, 168, 76, 0.35); }
  .btn-ghost { display: inline-block; background-color: #1a1c26; color: #cbd5e1 !important; border: 1px solid #2e3248; font-weight: 700; font-size: 14px; text-decoration: none; padding: 12px 24px; border-radius: 8px; margin-left: 10px; }
  .footer { background-color: #0a0a0f; border-top: 1px solid #1a1c26; padding: 24px 32px; text-align: center; font-size: 12px; color: #64748b; line-height: 1.6; }
</style>
</head>
<body>
<div class="wrapper">
  <!-- HEADER -->
  <div class="header">
    <a href="https://estatehdr.com" target="_blank" style="text-decoration:none; display:inline-block;">
      <img src="https://estatehdr.com/assets/images/logo.png" alt="Estate HDR" width="180" style="display:block; margin:0 auto 10px auto; max-width:180px; height:auto; border:0;" />
    </a>
    <div class="logo">ESTATE <span>HDR</span></div>
    <div class="tagline">World's #1 Luxury Real Estate Photo Editing &amp; 3D Staging Studio</div>
  </div>

  <div class="content">
    <div style="text-align: center;">
      <div class="badge-amend">✅ Amendments Completed &bull; Free Unlimited Revisions</div>
      <h2 style="color:#ffffff; font-size:22px; font-weight:800; margin:0 0 8px 0;">Your Revised Photos are Ready!</h2>
      <p style="color:#94a3b8; font-size:13px; margin:0;">Job #{$orderId} &bull; {$safeProp}</p>
    </div>

    <p style="color:#cbd5e1; font-size:15px; line-height:1.6; margin-top:24px;">
      Dear <strong>{$safeClientName}</strong>,
    </p>
    <p style="color:#cbd5e1; font-size:14px; line-height:1.6;">
      Good news! Our master architectural retouching team has completed the revisions requested for <strong style="color:#ffffff;">{$safeProp}</strong> (Job #{$orderId}). All updates have been verified under strict MLS and architectural quality guidelines.
    </p>

    <!-- RESOLUTION NOTES BOX -->
    <div class="notes-box">
      <div style="font-size:11px; font-weight:800; text-transform:uppercase; color:#C9A84C; margin-bottom:8px; letter-spacing:0.5px;">Summary of Revisions Completed:</div>
      <div style="color:#f1f5f9; font-size:13px; line-height:1.6;">
        {$safeNotes}
      </div>
    </div>

    <!-- DELIVERABLES DETAILS -->
    <div class="deliverables-box">
      <div style="font-size:11px; font-weight:800; text-transform:uppercase; color:#C9A84C; margin-bottom:12px; letter-spacing:0.5px;">Job Specifications</div>
      <table style="width:100%; border-collapse:collapse; font-size:13px;">
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0;">Property:</td>
          <td style="padding:8px 0; color:#ffffff; font-weight:600; text-align:right;">{$safeProp}</td>
        </tr>
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0;">Job / Ticket ID:</td>
          <td style="padding:8px 0; color:#C9A84C; font-family:monospace; font-weight:700; text-align:right;">#{$orderId}</td>
        </tr>
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0;">Service Type:</td>
          <td style="padding:8px 0; color:#ffffff; text-align:right;">{$safeService}</td>
        </tr>
        <tr style="border-bottom:1px solid #1f2334;">
          <td style="padding:8px 0; color:#8892b0;">Delivered Images:</td>
          <td style="padding:8px 0; color:#ffffff; font-weight:600; text-align:right;">{$deliveredImages} Revised High-Res JPGs</td>
        </tr>
        <tr>
          <td style="padding:8px 0; color:#8892b0;">Revisions Charge:</td>
          <td style="padding:8px 0; color:#34D399; font-weight:700; text-align:right;">$0.00 (100% Free Included)</td>
        </tr>
      </table>
    </div>

    <!-- ACTION BUTTONS -->
    <div style="text-align: center; margin: 32px 0 24px 0;">
      <a href="{$safeCloudLink}" target="_blank" class="btn-gold" style="color:#000000 !important;">
        📥 Download Revised Photos &rarr;
      </a>
      <a href="{$clientViewUrl}" target="_blank" class="btn-ghost">
        View Order in Portal
      </a>
    </div>

    <p style="color:#94a3b8; font-size:12px; line-height:1.6; text-align:center; margin-top:20px;">
      If the download button above doesn't open, copy and paste this link into your browser:<br/>
      <a href="{$safeCloudLink}" target="_blank" style="color:#C9A84C; word-break:break-all; font-size:11px;">{$safeCloudLink}</a>
    </p>

    <!-- SATISFACTION GUARANTEE -->
    <div style="background-color:#11131c; border:1px solid #1e2130; border-radius:8px; padding:16px; margin-top:24px; text-align:center;">
      <p style="color:#cbd5e1; font-size:12px; margin:0; line-height:1.5;">
        🛡️ <strong>100% Satisfaction Guarantee:</strong> All revisions are free of charge. If you need any further adjustments or sky preference tweaks, simply reply to this email or leave a note on your order ticket.
      </p>
    </div>
  </div>

  <!-- FOOTER -->
  <div class="footer">
    <p style="margin:0 0 6px 0; font-weight:700; color:#94a3b8;">Estate HDR Studio Group Ltd</p>
    <p style="margin:0 0 6px 0;">71-75 Shelton Street, Covent Garden, London WC2H 9JQ, United Kingdom</p>
    <p style="margin:0 0 10px 0;">
      Email: <a href="mailto:info@estatehdr.com" style="color:#C9A84C; text-decoration:none;">info@estatehdr.com</a> &bull; 
      WhatsApp 24/7: <a href="https://wa.me/447706068176" style="color:#C9A84C; text-decoration:none;">+44 770 606 8176</a>
    </p>
    <p style="margin:0; font-size:11px; color:#475569;">
      &copy; 2026 Estate HDR. All rights reserved. World's #1 Luxury Real Estate Photo Retouching Studio.
    </p>
  </div>
</div>
</body>
</html>
HTML;

    $sent = sendEstateHdrMail($clientEmail, $subject, $htmlBody, $orderSender, $orderSender);
    if (function_exists('logEmailEvent')) {
        logEmailEvent($orderId, "Amendment Completed Email", (bool)$sent, ['recipient' => $clientEmail, 'subject' => $subject]);
    }

    return (bool)$sent;
}

/**
 * Sends official Estate HDR Client Invoice Email matching the official PDF template
 * Exactly mirrors Esoft invoice letterhead, corporate seal stamp, and signatures.
 */
function sendClientInvoiceEmail(array $inv): bool {
    $invId = !empty($inv['invoice_number']) ? $inv['invoice_number'] : ($inv['id'] ?? 'INV-0001');
    $clientEmail = trim($inv['client_email'] ?? '');
    if (empty($clientEmail) || !filter_var($clientEmail, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    $clientName    = !empty($inv['client_name']) ? $inv['client_name'] : 'Valued Client';
    $clientCompany = !empty($inv['client_address']) ? $inv['client_address'] : 'Independent Agency';
    $date          = !empty($inv['date']) ? $inv['date'] : date('F j, Y');
    $dueDate       = !empty($inv['due_date']) ? $inv['due_date'] : 'Upon Receipt';
    $currency      = !empty($inv['currency']) ? $inv['currency'] : '$';
    $totalDue      = number_format((float)($inv['total'] ?? 0), 2);
    $subtotal      = number_format((float)($inv['subtotal'] ?? 0), 2);
    $tax           = number_format((float)($inv['tax'] ?? 0), 2);
    $payoneerLink  = trim($inv['payoneer_link'] ?? '');
    $remarks       = !empty($inv['remarks']) ? $inv['remarks'] : 'Please process your payment via Payoneer. Send payment to our official account.';
    $refNumber     = $inv['ref_number'] ?? ('REF: EH-INV-' . date('Ym') . '-C9D2E9');
    $clientId      = 'CL-' . substr(md5($clientEmail), 0, 4);
    $viewUrl       = BASE_URL . '/invoice-view.php?id=' . urlencode($invId);
    $orderSender   = defined('ORDER_EMAIL') ? ORDER_EMAIL : 'order@estatehdr.com';

    $subject = "Official Invoice #{$invId} — Estate HDR [{$currency}{$totalDue} USD Due]";

    // Build line items rows
    $items = $inv['items'] ?? [];
    if (empty($items)) {
        $items = [['description' => 'HDR Photo Editing (Professional Blending)', 'qty' => 1, 'rate' => (float)($inv['total'] ?? 0), 'total' => (float)($inv['total'] ?? 0)]];
    }

    $itemRowsHtml = '';
    foreach ($items as $it) {
        $desc = htmlspecialchars($it['description'] ?? 'HDR Photo Editing');
        $qty = htmlspecialchars($it['qty'] ?? 1);
        $rate = $currency . number_format((float)($it['rate'] ?? 0), 2);
        $lineTot = $currency . number_format((float)($it['total'] ?? 0), 2);

        $itemRowsHtml .= <<<ROW
        <tr style="border-bottom: 1px solid #f1f5f9;">
          <td style="padding: 12px 14px; font-weight: 700; color: #0f172a; font-size: 13px;">{$desc}</td>
          <td style="padding: 12px 14px; text-align: center; font-family: monospace; color: #334155; font-size: 13px;">{$qty}</td>
          <td style="padding: 12px 14px; text-align: right; font-family: monospace; color: #334155; font-size: 13px;">{$rate}</td>
          <td style="padding: 12px 14px; text-align: right; font-family: monospace; font-weight: 800; color: #0f172a; font-size: 13px;">{$lineTot}</td>
        </tr>
ROW;
    }

    // Payoneer button HTML
    $payButtonHtml = '';
    if (!empty($payoneerLink)) {
        $safePayUrl = htmlspecialchars($payoneerLink);
        $payButtonHtml = <<<BTN
        <div style="margin-top: 14px;">
          <a href="{$safePayUrl}" target="_blank" style="display: inline-block; background-color: #059669; color: #ffffff !important; font-weight: 800; font-size: 13px; text-decoration: none; padding: 12px 24px; border-radius: 8px; box-shadow: 0 4px 12px rgba(5,150,105,0.35);">
            💳 Click Here to Pay Online via Payoneer &rarr;
          </a>
        </div>
BTN;
    }

    $safeRemarks = nl2br(htmlspecialchars($remarks));
    $safeClientName = htmlspecialchars($clientName);
    $safeCompany = htmlspecialchars($clientCompany);
    $safeClientEmail = htmlspecialchars($clientEmail);

    $htmlBody = <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{$subject}</title>
</head>
<body style="margin: 0; padding: 24px 10px; background-color: #0b0c13; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">

<div style="max-width: 720px; margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 16px 40px rgba(0,0,0,0.6); padding: 36px;">

  <!-- ── 1. CORPORATE LETTERHEAD HEADER ── -->
  <table style="width: 100%; border-collapse: collapse; border-bottom: 2px solid #C9A84C; padding-bottom: 20px; margin-bottom: 24px;">
    <tr>
      <td style="vertical-align: top; text-align: left;">
        <div style="display: inline-block; vertical-align: middle;">
          <span style="font-size: 24px; font-weight: 900; color: #0f172a; letter-spacing: -0.5px;">ESTATE <span style="color: #C9A84C;">HDR</span></span>
          <span style="display: inline-block; margin-left: 10px; font-size: 10px; font-weight: 900; text-transform: uppercase; letter-spacing: 0.5px; padding: 3px 8px; border-radius: 4px; background-color: #fef3c7; color: #78350f; border: 1px solid #fcd34d;">Commercial Billing Division</span>
        </div>
        <div style="font-size: 11px; font-weight: 700; color: #334155; margin-top: 5px; font-family: monospace;">Premium Real Estate Photo Retouching &amp; Virtual Media SaaS</div>
        <div style="font-size: 10px; color: #64748b; font-family: monospace;">UK Reg: EH-789021 &bull; London &bull; Worldwide Delivery Hubs</div>
      </td>
      <td style="vertical-align: top; text-align: right; font-family: monospace; font-size: 11px; color: #475569; line-height: 1.6;">
        <div style="font-weight: 800; color: #0f172a;">{$refNumber}</div>
        <div>Date: <strong style="color: #0f172a;">{$date}</strong></div>
        <div>Contact: <span style="color: #0f172a;">billing@estatehdr.com</span></div>
        <div>Portal: <span style="color: #0f172a;">www.estatehdr.com</span></div>
      </td>
    </tr>
  </table>

  <!-- ── 2. INVOICE TITLE ── -->
  <div style="text-align: center; margin-bottom: 22px;">
    <div style="font-size: 20px; font-weight: 900; color: #0f172a; text-transform: uppercase; letter-spacing: 0.5px;">OFFICIAL COMMERCIAL INVOICE</div>
    <div style="font-size: 12px; font-family: monospace; color: #64748b; margin-top: 4px;">
      Invoice #: <strong style="color: #0f172a;">{$invId}</strong> &bull; Due Date: <strong style="color: #0f172a;">{$dueDate}</strong> &bull; Currency: <strong>USD ($)</strong>
    </div>
  </div>

  <!-- ── 3. CLIENT INFO GRID ── -->
  <table style="width: 100%; border-collapse: collapse; background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 24px; font-size: 12px; font-family: monospace;">
    <tr>
      <td style="padding: 10px 14px; border-right: 1px solid #e2e8f0; width: 25%;">
        <span style="color: #64748b; display: block; font-size: 10px; text-transform: uppercase;">Client ID</span>
        <strong style="color: #0f172a;">{$clientId}</strong>
      </td>
      <td style="padding: 10px 14px; border-right: 1px solid #e2e8f0; width: 25%;">
        <span style="color: #64748b; display: block; font-size: 10px; text-transform: uppercase;">Client Name</span>
        <strong style="color: #0f172a;">{$safeClientName}</strong>
      </td>
      <td style="padding: 10px 14px; border-right: 1px solid #e2e8f0; width: 25%;">
        <span style="color: #64748b; display: block; font-size: 10px; text-transform: uppercase;">Company / Agency</span>
        <strong style="color: #0f172a;">{$safeCompany}</strong>
      </td>
      <td style="padding: 10px 14px; width: 25%;">
        <span style="color: #64748b; display: block; font-size: 10px; text-transform: uppercase;">Client Contact</span>
        <strong style="color: #0f172a;">{$safeClientEmail}</strong>
      </td>
    </tr>
  </table>

  <!-- ── 4. LINE ITEMS TABLE ── -->
  <table style="width: 100%; border-collapse: collapse; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 24px;">
    <thead>
      <tr style="background-color: #f1f5f9; font-size: 11px; text-transform: uppercase; font-weight: 800; color: #475569; border-bottom: 2px solid #cbd5e1;">
        <th style="padding: 10px 14px; text-align: left;">Services &amp; Deliverables Description</th>
        <th style="padding: 10px 14px; text-align: center; width: 60px;">Qty</th>
        <th style="padding: 10px 14px; text-align: right; width: 80px;">Rate ($)</th>
        <th style="padding: 10px 14px; text-align: right; width: 100px;">Line Total ($)</th>
      </tr>
    </thead>
    <tbody>
      {$itemRowsHtml}
    </tbody>
    <tfoot>
      <tr style="background-color: #f8fafc; font-size: 12px; font-family: monospace; font-weight: 700; border-top: 1px solid #cbd5e1;">
        <td colspan="3" style="padding: 8px 14px; text-align: right; color: #475569;">SUBTOTAL:</td>
        <td style="padding: 8px 14px; text-align: right; color: #0f172a;">{$currency}{$subtotal}</td>
      </tr>
      <tr style="background-color: #f8fafc; font-size: 12px; font-family: monospace; font-weight: 700;">
        <td colspan="3" style="padding: 8px 14px; text-align: right; color: #475569;">TAX / VAT:</td>
        <td style="padding: 8px 14px; text-align: right; color: #0f172a;">{$currency}{$tax}</td>
      </tr>
    </tfoot>
  </table>

  <!-- ── 5. TOTAL NET AMOUNT DUE CARD ── -->
  <table style="width: 100%; border-collapse: collapse; background-color: #fefce8; border: 2px solid #C9A84C; border-radius: 10px; margin-bottom: 24px;">
    <tr>
      <td style="padding: 18px 20px; vertical-align: middle;">
        <div style="font-size: 11px; font-weight: 800; color: #78350f; text-transform: uppercase; letter-spacing: 0.5px;">TOTAL NET INVOICE AMOUNT DUE:</div>
        <div style="font-size: 12px; color: #475569; font-family: monospace; margin-top: 2px;">Please settle upon receipt via verified official payment channels.</div>
        {$payButtonHtml}
      </td>
      <td style="padding: 18px 20px; text-align: right; vertical-align: middle; width: 220px;">
        <div style="font-size: 24px; font-weight: 900; color: #0f172a; font-family: monospace;">{$currency}{$totalDue} USD</div>
        <div style="margin-top: 6px;">
          <span style="font-size: 9px; font-weight: 800; text-transform: uppercase; background-color: #d1fae5; color: #065f46; border: 1px solid #6ee7b7; padding: 2px 8px; border-radius: 4px; display: inline-block;">
            &check; PAYMENT PENDING / APPROVED
          </span>
        </div>
      </td>
    </tr>
  </table>

  <!-- ── 6. PAYMENT INSTRUCTIONS BOX ── -->
  <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px 18px; margin-bottom: 24px; font-size: 12px; font-family: monospace;">
    <div style="font-weight: 800; color: #C9A84C; text-transform: uppercase; font-size: 11px; margin-bottom: 4px;">Payment Instructions &amp; Routing</div>
    <div style="color: #334155; line-height: 1.6;">
      {$safeRemarks}
    </div>
  </div>

  <!-- ── 7. ONLINE VIEW / PRINT BUTTON ── -->
  <div style="text-align: center; margin: 24px 0;">
    <a href="{$viewUrl}" target="_blank" style="display: inline-block; background-color: #0f172a; color: #ffffff !important; font-weight: 700; font-size: 13px; text-decoration: none; padding: 12px 28px; border-radius: 8px; box-shadow: 0 4px 12px rgba(15,23,42,0.25);">
      🖨️ View &amp; Print Official A4 Invoice Online &rarr;
    </a>
  </div>

  <!-- ── 8. SIGNATURES & OFFICIAL STAMP (Exact match to PDF) ── -->
  <table style="width: 100%; border-collapse: collapse; border-top: 2px solid #e2e8f0; padding-top: 24px; margin-top: 28px; font-family: monospace; font-size: 11px; text-align: center;">
    <tr>
      <!-- Left: Usman Nadeem -->
      <td style="width: 33%; vertical-align: top; padding: 16px 8px;">
        <div style="height: 38px; border-bottom: 1px solid #94a3b8; margin: 0 auto 8px auto; width: 140px; line-height: 38px;">
          <span style="font-family: Georgia, serif; font-style: italic; font-size: 15px; font-weight: bold; color: #1e293b;">Usman Nadeem</span>
        </div>
        <div style="font-weight: 800; color: #0f172a;">Head of Client Billing</div>
        <div style="font-size: 10px; color: #64748b;">Estate HDR Finance Division</div>
      </td>

      <!-- Center: Official Circular Stamp -->
      <td style="width: 34%; vertical-align: middle; padding: 16px 8px; text-align: center;">
        <div style="display: inline-block; width: 75px; height: 75px; border-radius: 50%; border: 2px dashed #C9A84C; background-color: #fefce8; text-align: center; vertical-align: middle;">
          <div style="margin-top: 14px; font-size: 8px; font-weight: 900; color: #C9A84C; text-transform: uppercase; letter-spacing: -0.5px;">ESTATE HDR</div>
          <div style="font-size: 7px; font-weight: 700; color: #475569;">OFFICIAL SEAL</div>
          <div style="font-size: 6px; color: #94a3b8;">VERIFIED</div>
        </div>
        <div style="font-size: 9px; color: #94a3b8; margin-top: 4px;">Official Corporate Stamp</div>
      </td>

      <!-- Right: Client Signature Line -->
      <td style="width: 33%; vertical-align: top; padding: 16px 8px;">
        <div style="height: 38px; border-bottom: 1px solid #94a3b8; margin: 0 auto 8px auto; width: 140px;"></div>
        <div style="font-weight: 800; color: #0f172a;">{$safeClientName}</div>
        <div style="font-size: 10px; color: #64748b;">Client Signature &amp; Date</div>
      </td>
    </tr>
  </table>

  <div style="margin-top: 16px; font-size: 10px; font-family: monospace; color: #94a3b8; text-align: right;">
    1/1
  </div>

</div>

</body>
</html>
HTML;

    // Send to Client
    $sent = sendEstateHdrMail($clientEmail, $subject, $htmlBody, $orderSender, $orderSender);

    // Also send a copy to order@estatehdr.com for studio records
    if ($sent) {
        sendEstateHdrMail($orderSender, "[COPY] " . $subject, $htmlBody, $orderSender, $orderSender);
    }

    return $sent;
}
/**
 * Sends official Estate HDR Candidate Offer Letter & NDA Invitation Email
 * Provides a secure direct link for the candidate to review, digitally sign, and submit online.
 */
function sendHROfferNdaEmail(array $contract): bool {
    $candidateEmail = trim($contract['candidate_email'] ?? '');
    if (empty($candidateEmail) || !filter_var($candidateEmail, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    $candidateName = htmlspecialchars($contract['candidate_name'] ?? 'Candidate');
    $role          = htmlspecialchars($contract['role'] ?? 'Photo Editor');
    $dept          = htmlspecialchars($contract['department'] ?? 'Production');
    $shift         = htmlspecialchars($contract['shift'] ?? 'Standard Shift');
    $joiningDate   = htmlspecialchars($contract['joining_date'] ?? date('F j, Y', strtotime('+7 days')));
    $currency      = htmlspecialchars($contract['currency'] ?? 'USD ($)');
    $salary        = number_format((float)($contract['total_salary'] ?? 0), 2);
    $compType      = htmlspecialchars($contract['compensation_type'] ?? 'Monthly Salary');
    $token         = trim($contract['token'] ?? '');
    $docType       = $contract['doc_type'] ?? 'offer_and_nda';
    $docTitle      = match($docType) {
        'offer_letter' => 'Employment Offer Letter',
        'nda'          => 'Confidentiality & Non-Disclosure Agreement (NDA)',
        default        => 'Employment Offer Letter & Non-Disclosure Agreement (NDA)'
    };

    $signUrl = BASE_URL . '/hr-sign.php?token=' . urlencode($token);
    $orderSender = defined('ORDER_EMAIL') ? ORDER_EMAIL : 'order@estatehdr.com';
    $hrSender = 'hr@estatehdr.com';

    $subject = "Official {$docTitle}: {$role} — Estate HDR [Review & Sign]";

    $htmlBody = <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{$subject}</title>
</head>
<body style="margin: 0; padding: 24px 12px; background-color: #0b0c13; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;">

<div style="max-width: 680px; margin: 0 auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 16px 40px rgba(0,0,0,0.6); padding: 36px;">

  <!-- Header Section -->
  <table style="width: 100%; border-collapse: collapse; border-bottom: 2px solid #C9A84C; padding-bottom: 18px; margin-bottom: 24px;">
    <tr>
      <td style="vertical-align: top; text-align: left;">
        <div style="font-size: 24px; font-weight: 900; color: #0f172a; letter-spacing: -0.5px;">ESTATE <span style="color: #C9A84C;">HDR</span></div>
        <div style="display: inline-block; margin-top: 4px; font-size: 10px; font-weight: 900; text-transform: uppercase; letter-spacing: 0.5px; padding: 3px 8px; border-radius: 4px; background-color: #fef3c7; color: #78350f; border: 1px solid #fcd34d;">Human Resources &amp; Legal Operations</div>
      </td>
      <td style="vertical-align: top; text-align: right; font-family: monospace; font-size: 11px; color: #64748b; line-height: 1.6;">
        <div>Ref: <strong style="color: #0f172a;">{$contract['id']}</strong></div>
        <div>Date: <strong style="color: #0f172a;">{$joiningDate}</strong></div>
        <div>Contact: <span style="color: #0f172a;">hr@estatehdr.com</span></div>
      </td>
    </tr>
  </table>

  <!-- Salutation -->
  <div style="font-size: 16px; font-weight: 800; color: #0f172a; margin-bottom: 12px;">
    Dear {$candidateName},
  </div>

  <p style="font-size: 13px; color: #334155; line-height: 1.6; margin-bottom: 20px;">
    We are pleased to extend this formal <strong>{$docTitle}</strong> for the position of <strong>{$role}</strong> with Estate HDR.
    Please review the terms of engagement and execute your digital signature via our secure candidate portal.
  </p>

  <!-- Position Summary Card -->
  <table style="width: 100%; border-collapse: collapse; background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 24px; font-size: 12px; font-family: monospace;">
    <tr style="border-bottom: 1px solid #e2e8f0;">
      <td style="padding: 10px 14px; width: 40%; color: #64748b;">Designation / Role:</td>
      <td style="padding: 10px 14px; font-weight: 800; color: #0f172a;">{$role}</td>
    </tr>
    <tr style="border-bottom: 1px solid #e2e8f0;">
      <td style="padding: 10px 14px; color: #64748b;">Department:</td>
      <td style="padding: 10px 14px; font-weight: 700; color: #0f172a;">{$dept}</td>
    </tr>
    <tr style="border-bottom: 1px solid #e2e8f0;">
      <td style="padding: 10px 14px; color: #64748b;">Assigned Shift / Timings:</td>
      <td style="padding: 10px 14px; font-weight: 700; color: #0f172a;">{$shift}</td>
    </tr>
    <tr style="border-bottom: 1px solid #e2e8f0;">
      <td style="padding: 10px 14px; color: #64748b;">Expected Joining Date:</td>
      <td style="padding: 10px 14px; font-weight: 700; color: #0f172a;">{$joiningDate}</td>
    </tr>
    <tr>
      <td style="padding: 10px 14px; color: #78350f; font-weight: 800; background-color: #fefce8;">Agreed Compensation:</td>
      <td style="padding: 10px 14px; font-weight: 900; color: #0f172a; font-size: 14px; background-color: #fefce8;">{$currency} {$salary} <span style="font-size: 11px; font-weight: normal; color: #64748b;">({$compType})</span></td>
    </tr>
  </table>

  <!-- Action Button -->
  <div style="text-align: center; margin: 30px 0;">
    <a href="{$signUrl}" target="_blank" style="display: inline-block; background-color: #C9A84C; color: #000000 !important; font-weight: 800; font-size: 14px; text-decoration: none; padding: 14px 32px; border-radius: 8px; box-shadow: 0 4px 14px rgba(201, 168, 76, 0.4);">
      ✍️ Click Here to Review &amp; Sign Document Online &rarr;
    </a>
    <div style="font-size: 11px; color: #94a3b8; margin-top: 8px; font-family: monospace;">
      Secure Touch / Mouse Digital Signature Enabled
    </div>
  </div>

  <p style="font-size: 12px; color: #64748b; line-height: 1.6;">
    If you have any questions or require modifications prior to signing, please contact HR at <a href="mailto:hr@estatehdr.com" style="color: #C9A84C; text-decoration: none; font-weight: bold;">hr@estatehdr.com</a>.
  </p>

  <div style="margin-top: 24px; padding-top: 14px; border-top: 1px solid #f1f5f9; font-size: 11px; color: #94a3b8; display: flex; justify-content: space-between;">
    <span>Estate HDR &bull; Official Human Resources Division</span>
    <span>UK Reg: EH-789021</span>
  </div>

</div>

</body>
</html>
HTML;

    $sent = sendEstateHdrMail($candidateEmail, $subject, $htmlBody, $orderSender, $hrSender);
    if ($sent) {
        // Also dispatch copy to studio operations
        sendEstateHdrMail($orderSender, "[HR COPY] " . $subject, $htmlBody, $orderSender, $hrSender);
    }
    return $sent;
}

/**
 * Sends notification when candidate completes digital signing of their Offer / NDA
 */
function sendHRSignedNotificationEmail(array $contract): bool {
    $candidateName  = htmlspecialchars($contract['candidate_name'] ?? 'Candidate');
    $candidateEmail = htmlspecialchars($contract['candidate_email'] ?? '');
    $role           = htmlspecialchars($contract['role'] ?? 'Photo Editor');
    $signedAt       = htmlspecialchars($contract['signed_at'] ?? date('Y-m-d H:i:s'));
    $signerIp       = htmlspecialchars($contract['signer_ip'] ?? 'Unknown');
    $contractId     = htmlspecialchars($contract['id'] ?? '');

    $adminUrl = BASE_URL . '/admin/hr-documents.php?tab=contracts&view_id=' . urlencode($contractId);
    $orderSender = defined('ORDER_EMAIL') ? ORDER_EMAIL : 'order@estatehdr.com';

    $subject = "✅ Signed Document Received: {$candidateName} ({$role}) — Estate HDR";

    $htmlBody = <<<HTML
<!DOCTYPE html>
<html lang="en">
<body style="margin: 0; padding: 24px; background-color: #0b0c13; font-family: -apple-system, BlinkMacSystemFont, sans-serif;">
<div style="max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 12px; padding: 32px;">
  <div style="border-bottom: 2px solid #10b981; padding-bottom: 12px; margin-bottom: 20px;">
    <h2 style="margin: 0; color: #065f46; font-size: 18px;">✓ Document Digitally Signed &amp; Verified</h2>
    <div style="font-size: 12px; color: #64748b; margin-top: 4px;">Candidate has executed legally binding digital signature.</div>
  </div>

  <table style="width: 100%; font-size: 12px; font-family: monospace; border-collapse: collapse; margin-bottom: 20px;">
    <tr><td style="padding: 6px 0; color: #64748b;">Candidate:</td><td style="padding: 6px 0; font-weight: bold; color: #0f172a;">{$candidateName} ({$candidateEmail})</td></tr>
    <tr><td style="padding: 6px 0; color: #64748b;">Role:</td><td style="padding: 6px 0; font-weight: bold; color: #0f172a;">{$role}</td></tr>
    <tr><td style="padding: 6px 0; color: #64748b;">Contract ID:</td><td style="padding: 6px 0; font-weight: bold; color: #0f172a;">{$contractId}</td></tr>
    <tr><td style="padding: 6px 0; color: #64748b;">Signed Timestamp:</td><td style="padding: 6px 0; font-weight: bold; color: #0f172a;">{$signedAt}</td></tr>
    <tr><td style="padding: 6px 0; color: #64748b;">Signer IP:</td><td style="padding: 6px 0; font-weight: bold; color: #0f172a;">{$signerIp}</td></tr>
  </table>

  <div style="text-align: center; margin-top: 24px;">
    <a href="{$adminUrl}" style="background-color: #0f172a; color: #ffffff !important; font-weight: bold; font-size: 13px; text-decoration: none; padding: 12px 24px; border-radius: 6px; display: inline-block;">
      👁️ View Signed Document in HR Portal &rarr;
    </a>
  </div>
</div>
</body>
</html>
HTML;

    $hrRecipients = ['hr@estatehdr.com', $orderSender];
    foreach ($hrRecipients as $to) {
        sendEstateHdrMail($to, $subject, $htmlBody, $orderSender, $candidateEmail ?: $orderSender);
    }
    return true;
}
