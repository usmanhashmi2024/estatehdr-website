-- ==============================================================================
-- ESTATE HDR — Enterprise MySQL Database Schema
-- Architecture: High-Throughput Relational Storage with B-Tree Indexes
-- Target: MySQL 5.7+ / MySQL 8.0+ / MariaDB 10.3+ (Hostinger Compatible)
-- ==============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- 1. VISITORS TABLE
CREATE TABLE IF NOT EXISTS isitors (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  isitor_id VARCHAR(64) NOT NULL UNIQUE,
  ip_address VARCHAR(45) NOT NULL DEFAULT '',
  country VARCHAR(100) NOT NULL DEFAULT 'United Kingdom',
  country_code VARCHAR(8) NOT NULL DEFAULT 'GB',
  city VARCHAR(100) NOT NULL DEFAULT '',
  lag VARCHAR(16) NOT NULL DEFAULT '🇬🇧',
  user_agent TEXT,
  device VARCHAR(32) NOT NULL DEFAULT 'Desktop',
  rowser VARCHAR(64) NOT NULL DEFAULT 'Chrome',
  os VARCHAR(64) NOT NULL DEFAULT 'Windows',
  
eferrer VARCHAR(512) NOT NULL DEFAULT '',
  irst_seen DATETIME NOT NULL,
  last_seen DATETIME NOT NULL,
  	otal_visits INT UNSIGNED NOT NULL DEFAULT 1,
  	otal_pageviews INT UNSIGNED NOT NULL DEFAULT 1,
  	otal_time_spent INT UNSIGNED NOT NULL DEFAULT 0,
  lead_score INT NOT NULL DEFAULT 0,
  lead_band ENUM('Cold', 'Warm', 'Hot', 'Sales Priority') NOT NULL DEFAULT 'Cold',
  ssigned_agent_id INT UNSIGNED NULL,
  language VARCHAR(16) NOT NULL DEFAULT 'en',
  currency VARCHAR(8) NOT NULL DEFAULT 'USD',
  
otes TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_visitors_last_seen (last_seen),
  INDEX idx_visitors_country_code (country_code),
  INDEX idx_visitors_lead_band (lead_band),
  INDEX idx_visitors_lead_score (lead_score),
  INDEX idx_visitors_assigned_agent (ssigned_agent_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. VISITOR SESSIONS TABLE
CREATE TABLE IF NOT EXISTS isitor_sessions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  session_token VARCHAR(64) NOT NULL UNIQUE,
  isitor_id VARCHAR(64) NOT NULL,
  ip_address VARCHAR(45) NOT NULL DEFAULT '',
  start_time DATETIME NOT NULL,
  end_time DATETIME NULL,
  duration_seconds INT UNSIGNED NOT NULL DEFAULT 0,
  page_views_count INT UNSIGNED NOT NULL DEFAULT 1,
  entry_page VARCHAR(255) NOT NULL DEFAULT '/',
  exit_page VARCHAR(255) NOT NULL DEFAULT '/',
  
eferrer VARCHAR(512) NOT NULL DEFAULT '',
  utm_source VARCHAR(64) NOT NULL DEFAULT '',
  utm_medium VARCHAR(64) NOT NULL DEFAULT '',
  utm_campaign VARCHAR(128) NOT NULL DEFAULT '',
  device VARCHAR(32) NOT NULL DEFAULT 'Desktop',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_sessions_visitor_id (isitor_id),
  INDEX idx_sessions_start_time (start_time),
  INDEX idx_sessions_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. PAGE VIEWS TABLE
CREATE TABLE IF NOT EXISTS page_views (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  isitor_id VARCHAR(64) NOT NULL,
  session_id VARCHAR(64) NOT NULL DEFAULT '',
  page_url VARCHAR(512) NOT NULL,
  page_title VARCHAR(255) NOT NULL DEFAULT '',
  	ime_spent_seconds INT UNSIGNED NOT NULL DEFAULT 0,
  scroll_depth_percent TINYINT UNSIGNED NOT NULL DEFAULT 0,
  
eferrer VARCHAR(512) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_pageviews_visitor_id (isitor_id),
  INDEX idx_pageviews_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. VISITOR EVENTS TABLE (Telemetry & Telemetry Scoring)
CREATE TABLE IF NOT EXISTS isitor_events (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  isitor_id VARCHAR(64) NOT NULL,
  session_id VARCHAR(64) NOT NULL DEFAULT '',
  event_type VARCHAR(64) NOT NULL,
  event_name VARCHAR(128) NOT NULL,
  event_data_json JSON NULL,
  score_delta INT NOT NULL DEFAULT 0,
  page_url VARCHAR(512) NOT NULL DEFAULT '/',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_events_visitor_id (isitor_id),
  INDEX idx_events_event_type (event_type),
  INDEX idx_events_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. CONVERSATIONS TABLE
CREATE TABLE IF NOT EXISTS conversations (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  session_id VARCHAR(64) NOT NULL UNIQUE,
  isitor_id VARCHAR(64) NOT NULL,
  status ENUM('active', 'idle', 'waiting_agent', 'closed', 'resolved') NOT NULL DEFAULT 'active',
  channel VARCHAR(32) NOT NULL DEFAULT 'live_chat',
  priority ENUM('low', 'normal', 'high', 'urgent') NOT NULL DEFAULT 'normal',
  ssigned_agent_id INT UNSIGNED NULL,
  country_code VARCHAR(8) NOT NULL DEFAULT 'GB',
  language VARCHAR(16) NOT NULL DEFAULT 'en',
  lead_score INT NOT NULL DEFAULT 0,
  lead_temperature ENUM('Cold', 'Warm', 'Hot', 'Sales Priority') NOT NULL DEFAULT 'Warm',
  	otal_messages INT UNSIGNED NOT NULL DEFAULT 0,
  unread_for_agent TINYINT(1) NOT NULL DEFAULT 0,
  unread_for_client TINYINT(1) NOT NULL DEFAULT 0,
  last_message_text TEXT,
  last_message_sender ENUM('user', 'agent', 'bot', 'system') NOT NULL DEFAULT 'bot',
  last_active_at DATETIME NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_conv_visitor_id (isitor_id),
  INDEX idx_conv_status (status),
  INDEX idx_conv_assigned_agent (ssigned_agent_id),
  INDEX idx_conv_last_active (last_active_at),
  INDEX idx_conv_unread_agent (unread_for_agent)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. MESSAGES TABLE
CREATE TABLE IF NOT EXISTS messages (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  conversation_id VARCHAR(64) NOT NULL,
  isitor_id VARCHAR(64) NOT NULL,
  sender_type ENUM('user', 'agent', 'bot', 'system') NOT NULL DEFAULT 'user',
  gent_name VARCHAR(100) NOT NULL DEFAULT '',
  	ext TEXT NOT NULL,
  
aw_html TEXT NULL,
  is_private_note TINYINT(1) NOT NULL DEFAULT 0,
  intent_detected VARCHAR(64) NOT NULL DEFAULT '',
  i_confidence DECIMAL(4,2) NULL,
  quote_id INT UNSIGNED NULL,
  lead_delta INT NOT NULL DEFAULT 0,
  ttachments_json JSON NULL,
  	imestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_msg_conversation_id (conversation_id),
  INDEX idx_msg_visitor_id (isitor_id),
  INDEX idx_msg_timestamp (	imestamp),
  INDEX idx_msg_sender (sender_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. AGENTS TABLE
CREATE TABLE IF NOT EXISTS gents (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  
ame VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  
ole VARCHAR(64) NOT NULL DEFAULT 'Support Agent',
  vatar_url VARCHAR(255) NOT NULL DEFAULT '',
  ssigned_countries_json JSON NULL,
  languages_json JSON NULL,
  	imezone VARCHAR(64) NOT NULL DEFAULT 'UTC',
  is_online TINYINT(1) NOT NULL DEFAULT 0,
  ctive_chats_count INT UNSIGNED NOT NULL DEFAULT 0,
  max_chats INT UNSIGNED NOT NULL DEFAULT 10,
  skill_tags_json JSON NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_agents_email (email),
  INDEX idx_agents_is_online (is_online),
  INDEX idx_agents_role (
ole)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. AGENT PRESENCE TABLE
CREATE TABLE IF NOT EXISTS gent_presence (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  gent_id INT UNSIGNED NOT NULL UNIQUE,
  status ENUM('online', 'busy', 'away', 'offline') NOT NULL DEFAULT 'offline',
  last_heartbeat DATETIME NOT NULL,
  current_workload INT UNSIGNED NOT NULL DEFAULT 0,
  device VARCHAR(64) NOT NULL DEFAULT 'Desktop',
  ip_address VARCHAR(45) NOT NULL DEFAULT '',
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_presence_agent_id (gent_id),
  INDEX idx_presence_status (status),
  INDEX idx_presence_last_heartbeat (last_heartbeat)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. LEADS TABLE
CREATE TABLE IF NOT EXISTS leads (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  lead_number VARCHAR(32) NOT NULL UNIQUE,
  isitor_id VARCHAR(64) NOT NULL DEFAULT '',
  
ame VARCHAR(150) NOT NULL DEFAULT '',
  email VARCHAR(150) NOT NULL DEFAULT '',
  phone VARCHAR(64) NOT NULL DEFAULT '',
  whatsapp VARCHAR(64) NOT NULL DEFAULT '',
  company VARCHAR(150) NOT NULL DEFAULT '',
  country VARCHAR(100) NOT NULL DEFAULT '',
  service_interest VARCHAR(128) NOT NULL DEFAULT 'HDR Photo Editing',
  cloud_storage_link VARCHAR(512) NOT NULL DEFAULT '',
  lead_score INT NOT NULL DEFAULT 0,
  lead_stage ENUM('New', 'Contacted', 'Sample_Sent', 'Quoted', 'Won', 'Lost') NOT NULL DEFAULT 'New',
  quote_id INT UNSIGNED NULL,
  	otal_potential_value DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  source VARCHAR(64) NOT NULL DEFAULT 'live_chat',
  ssigned_agent_id INT UNSIGNED NULL,
  
otes TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_leads_email (email),
  INDEX idx_leads_visitor_id (isitor_id),
  INDEX idx_leads_lead_stage (lead_stage),
  INDEX idx_leads_lead_score (lead_score),
  INDEX idx_leads_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. QUOTES TABLE (Deterministic Server-Side Quotes)
CREATE TABLE IF NOT EXISTS quotes (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  quote_code VARCHAR(32) NOT NULL UNIQUE,
  isitor_id VARCHAR(64) NOT NULL DEFAULT '',
  lead_id INT UNSIGNED NULL,
  service_type VARCHAR(128) NOT NULL,
  quantity INT UNSIGNED NOT NULL DEFAULT 1,
  unit_price DECIMAL(8,2) NOT NULL DEFAULT 0.80,
  subtotal DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  discount_percent INT NOT NULL DEFAULT 0,
  discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  
ush_sla VARCHAR(32) NOT NULL DEFAULT '24_hours',
  
ush_fee DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  	otal_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  currency VARCHAR(8) NOT NULL DEFAULT 'USD',
  line_items_json JSON NULL,
  calculation_hash VARCHAR(64) NOT NULL DEFAULT '',
  status ENUM('draft', 'presented', 'accepted', 'expired', 'converted') NOT NULL DEFAULT 'presented',
  alid_until DATETIME NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_quotes_code (quote_code),
  INDEX idx_quotes_visitor_id (isitor_id),
  INDEX idx_quotes_status (status),
  INDEX idx_quotes_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. FILES TABLE
CREATE TABLE IF NOT EXISTS iles (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ile_code VARCHAR(32) NOT NULL UNIQUE,
  isitor_id VARCHAR(64) NOT NULL DEFAULT '',
  lead_id INT UNSIGNED NULL,
  order_id INT UNSIGNED NULL,
  ile_name VARCHAR(255) NOT NULL,
  ile_url VARCHAR(512) NOT NULL,
  storage_provider ENUM('local', 'google_drive', 'dropbox', 'wetransfer', 's3') NOT NULL DEFAULT 'local',
  ile_size_mb DECIMAL(8,2) NOT NULL DEFAULT 0.00,
  ile_type VARCHAR(64) NOT NULL DEFAULT 'image/jpeg',
  scan_status ENUM('pending', 'clean', 'flagged', 'infected') NOT NULL DEFAULT 'clean',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_files_visitor_id (isitor_id),
  INDEX idx_files_lead_id (lead_id),
  INDEX idx_files_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. AI INTERACTIONS TABLE
CREATE TABLE IF NOT EXISTS i_interactions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  isitor_id VARCHAR(64) NOT NULL DEFAULT '',
  conversation_id VARCHAR(64) NOT NULL DEFAULT '',
  prompt_query TEXT NOT NULL,
  model_used VARCHAR(64) NOT NULL DEFAULT 'rule_neural_brain_v1',
  provider VARCHAR(64) NOT NULL DEFAULT 'in_house_rag',
  	okens_used INT UNSIGNED NOT NULL DEFAULT 0,
  
esponse_text TEXT NOT NULL,
  latency_ms INT UNSIGNED NOT NULL DEFAULT 0,
  intent_classified VARCHAR(64) NOT NULL DEFAULT '',
  
ag_sources_json JSON NULL,
  allback_triggered TINYINT(1) NOT NULL DEFAULT 0,
  confidence_score DECIMAL(4,2) NOT NULL DEFAULT 1.00,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ai_visitor_id (isitor_id),
  INDEX idx_ai_intent (intent_classified),
  INDEX idx_ai_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13. KNOWLEDGE DOCUMENTS & CHUNKS (RAG Base)
CREATE TABLE IF NOT EXISTS knowledge_documents (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  	itle VARCHAR(255) NOT NULL,
  category VARCHAR(64) NOT NULL DEFAULT 'FAQ',
  slug VARCHAR(128) NOT NULL UNIQUE,
  	ags_json JSON NULL,
  content MEDIUMTEXT NOT NULL,
  is_published TINYINT(1) NOT NULL DEFAULT 1,
  ersion VARCHAR(16) NOT NULL DEFAULT '1.0',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_know_category (category),
  INDEX idx_know_is_published (is_published)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS knowledge_chunks (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  document_id INT UNSIGNED NOT NULL,
  chunk_index INT UNSIGNED NOT NULL DEFAULT 0,
  chunk_title VARCHAR(255) NOT NULL DEFAULT '',
  chunk_content TEXT NOT NULL,
  keywords_json JSON NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_chunks_doc_id (document_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 14. CAMPAIGNS TABLE
CREATE TABLE IF NOT EXISTS campaigns (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  
ame VARCHAR(128) NOT NULL,
  utm_source VARCHAR(64) NOT NULL DEFAULT '',
  utm_medium VARCHAR(64) NOT NULL DEFAULT '',
  utm_campaign VARCHAR(128) NOT NULL DEFAULT '',
  	arget_country VARCHAR(64) NOT NULL DEFAULT 'All',
  cta_variant VARCHAR(64) NOT NULL DEFAULT 'default',
  	otal_visitors INT UNSIGNED NOT NULL DEFAULT 0,
  	otal_leads INT UNSIGNED NOT NULL DEFAULT 0,
  	otal_quotes INT UNSIGNED NOT NULL DEFAULT 0,
  	otal_orders INT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_camp_utm_source (utm_source),
  INDEX idx_camp_utm_campaign (utm_campaign)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 15. AUDIT LOGS TABLE
CREATE TABLE IF NOT EXISTS udit_logs (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ctor_type ENUM('admin', 'agent', 'client', 'visitor', 'system') NOT NULL DEFAULT 'system',
  ctor_id VARCHAR(64) NOT NULL DEFAULT '',
  ctor_name VARCHAR(100) NOT NULL DEFAULT '',
  ction VARCHAR(64) NOT NULL,
  	arget_type VARCHAR(64) NOT NULL DEFAULT '',
  	arget_id VARCHAR(64) NOT NULL DEFAULT '',
  ip_address VARCHAR(45) NOT NULL DEFAULT '',
  user_agent TEXT,
  details_json JSON NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audit_action (ction),
  INDEX idx_audit_actor (ctor_type, ctor_id),
  INDEX idx_audit_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 16. NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS 
otifications (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  	ype VARCHAR(64) NOT NULL,
  channel ENUM('discord', 'email', 'whatsapp', 'in_app') NOT NULL DEFAULT 'discord',
  
ecipient VARCHAR(255) NOT NULL DEFAULT '',
  payload_json JSON NULL,
  status ENUM('pending', 'sent', 'failed') NOT NULL DEFAULT 'pending',
  sent_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_notif_status (status),
  INDEX idx_notif_type (	ype),
  INDEX idx_notif_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 17. ORDERS TABLE
CREATE TABLE IF NOT EXISTS orders (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_number VARCHAR(32) NOT NULL UNIQUE,
  user_id VARCHAR(64) NOT NULL DEFAULT '',
  isitor_id VARCHAR(64) NOT NULL DEFAULT '',
  lead_id INT UNSIGNED NULL,
  quote_id INT UNSIGNED NULL,
  service_name VARCHAR(128) NOT NULL DEFAULT 'HDR Photo Editing',
  quantity INT UNSIGNED NOT NULL DEFAULT 1,
  	otal_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  currency VARCHAR(8) NOT NULL DEFAULT 'USD',
  status ENUM('pending', 'in_progress', 'qa_review', 'completed', 'delivered', 'cancelled') NOT NULL DEFAULT 'pending',
  drive_link VARCHAR(512) NOT NULL DEFAULT '',
  delivery_link VARCHAR(512) NOT NULL DEFAULT '',
  	urnaround_hours INT UNSIGNED NOT NULL DEFAULT 24,
  is_rush TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_orders_order_number (order_number),
  INDEX idx_orders_status (status),
  INDEX idx_orders_visitor_id (isitor_id),
  INDEX idx_orders_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
