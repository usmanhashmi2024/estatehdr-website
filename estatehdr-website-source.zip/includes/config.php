<?php
/**
 * Estate HDR — Configuration & Enterprise Session Engine
 */

// ─── App Settings ────────────────────────────────────────────────────────────
define('APP_NAME',    'Estate HDR');
define('BASE_URL',    'https://estatehdr.com');
define('APP_VERSION', '1.0.0');

// ─── Admin Credentials ───────────────────────────────────────────────────────
define('ADMIN_EMAIL',         'admin@estatehdr.com');
define('ADMIN_PASSWORD_HASH',   '$2y$10$demoHashForLocalDevelopmentOnlyReplaceWithRealBcrypt000');
define('ADMIN_SESSION_KEY',   'ehdr_admin_logged_in');

// ─── Contact & Social Channels ─────────────────────────────────────────────
define('ORDER_EMAIL',         'order@estatehdr.com');
define('ORDERS_EMAIL',        'orders@estatehdr.com');
define('CONTACT_EMAIL',       'info@estatehdr.com');
define('WHATSAPP_NUMBER',     '+44 770 606 8176');
define('WHATSAPP_LINK',       'https://wa.me/447706068176?text=Hi%20Estate%20HDR%2C%20I%20would%20like%20to%20request%20a%20free%20trial%20edit.');
define('FACEBOOK_LINK',       'https://www.facebook.com/estatehdr1');
define('INSTAGRAM_LINK',      'https://www.instagram.com/estate_hdr');
define('LINKEDIN_LINK',       'https://www.linkedin.com/company/estate-hdr');
define('TWITTER_LINK',        'https://x.com/estatehdr');
define('YOUTUBE_LINK',        'https://www.youtube.com/@estatehdr');
define('PINTEREST_LINK',      'https://www.pinterest.com/estatehdr');
define('TIKTOK_LINK',         'https://www.tiktok.com/@estatehdr');
define('DEFAULT_AGENT_NAME',  'Alice | Retouching Director');
define('PAYPAL_EMAIL',        'billing@estatehdr.com');
define('PAYPAL_ME_LINK',      'https://www.paypal.com/paypalme/youraccount');

// ─── Enterprise SMTP Email Delivery Engine (Hostinger / Titan / Custom) ──────
define('SMTP_HOST',           'smtp.hostinger.com'); // Hostinger: smtp.hostinger.com | Titan: smtp.titan.email
define('SMTP_PORT',           465);                  // 465 (SSL) or 587 (TLS/STARTTLS)
define('SMTP_SECURE',         'ssl');                // 'ssl' or 'tls'
define('SMTP_USER',           'info@estatehdr.com'); // Official authenticated mailbox username
define('SMTP_PASS',           'your_smtp_password_here');        // Hostinger authenticated email password
define('SMTP_FROM_EMAIL',     'info@estatehdr.com');
define('SMTP_FROM_NAME',      'Estate HDR');

// ─── Paths ────────────────────────────────────────────────────────────────────
define('ROOT_PATH',        dirname(__DIR__));
define('DATA_PATH',        ROOT_PATH . '/data/');
define('ORDERS_PATH',      DATA_PATH  . 'orders/');
define('PREFERENCES_PATH', DATA_PATH  . 'preferences/');
define('LEADS_FILE',       DATA_PATH  . 'leads.json');
define('LEDGER_FILE',      DATA_PATH  . 'ledger.json');
define('USERS_FILE',       DATA_PATH  . 'users.json');

// ─── Security ─────────────────────────────────────────────────────────────────
define('CSRF_TOKEN_LENGTH', 32);

// ─── Session Management (Persistent Root Path across all subdirectories) ─────
if (session_status() === PHP_SESSION_NONE) {
    $isHttps = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    @ini_set('session.gc_maxlifetime', 86400 * 30); // 30 days
    session_set_cookie_params([
        'lifetime' => 86400 * 30,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_name('EHDR_SESSION');
    @session_start();
}

// ─── Performance & Output Buffering ──────────────────────────────────────────
if (!ob_get_level()) {
    @ob_start();
}

// ─── Timezone ─────────────────────────────────────────────────────────────────
date_default_timezone_set('UTC');

// ─── Error Reporting ─────────────────────────────────────────────────────────
error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
@ini_set('display_errors', '0');
@ini_set('log_errors', '1');

// ─── Enterprise Security Bootstrap & HTTP Security Headers ─────────────────────
require_once __DIR__ . '/security/bootstrap.php';
$isApiRoute = !empty($_SERVER['REQUEST_URI']) && str_starts_with(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '', '/api/');
ehdr_security_headers($isApiRoute);

