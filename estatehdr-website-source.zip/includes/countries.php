<?php
/**
 * Estate HDR — Canonical ISO-3166-1 Country and Dial Code Dataset
 * Provides canonical country name, alpha-2 code, alpha-3 code, and international dial code.
 */

if (!function_exists('getCountries')) {
    function getCountries(): array {
        static $countries = [
            ['name' => 'United States', 'code' => 'US', 'alpha3' => 'USA', 'dial_code' => '+1', 'emoji' => '🇺🇸'],
            ['name' => 'United Kingdom', 'code' => 'GB', 'alpha3' => 'GBR', 'dial_code' => '+44', 'emoji' => '🇬🇧'],
            ['name' => 'Canada', 'code' => 'CA', 'alpha3' => 'CAN', 'dial_code' => '+1', 'emoji' => '🇨🇦'],
            ['name' => 'Australia', 'code' => 'AU', 'alpha3' => 'AUS', 'dial_code' => '+61', 'emoji' => '🇦🇺'],
            ['name' => 'Germany', 'code' => 'DE', 'alpha3' => 'DEU', 'dial_code' => '+49', 'emoji' => '🇩🇪'],
            ['name' => 'France', 'code' => 'FR', 'alpha3' => 'FRA', 'dial_code' => '+33', 'emoji' => '🇫🇷'],
            ['name' => 'United Arab Emirates', 'code' => 'AE', 'alpha3' => 'ARE', 'dial_code' => '+971', 'emoji' => '🇦🇪'],
            ['name' => 'Saudi Arabia', 'code' => 'SA', 'alpha3' => 'SAU', 'dial_code' => '+966', 'emoji' => '🇸🇦'],
            ['name' => 'Pakistan', 'code' => 'PK', 'alpha3' => 'PAK', 'dial_code' => '+92', 'emoji' => '🇵🇰'],
            ['name' => 'India', 'code' => 'IN', 'alpha3' => 'IND', 'dial_code' => '+91', 'emoji' => '🇮🇳'],
            ['name' => 'Afghanistan', 'code' => 'AF', 'alpha3' => 'AFG', 'dial_code' => '+93', 'emoji' => '🇦🇫'],
            ['name' => 'Albania', 'code' => 'AL', 'alpha3' => 'ALB', 'dial_code' => '+355', 'emoji' => '🇦🇱'],
            ['name' => 'Algeria', 'code' => 'DZ', 'alpha3' => 'DZA', 'dial_code' => '+213', 'emoji' => '🇩🇿'],
            ['name' => 'Andorra', 'code' => 'AD', 'alpha3' => 'AND', 'dial_code' => '+376', 'emoji' => '🇦🇩'],
            ['name' => 'Angola', 'code' => 'AO', 'alpha3' => 'AGO', 'dial_code' => '+244', 'emoji' => '🇦🇴'],
            ['name' => 'Argentina', 'code' => 'AR', 'alpha3' => 'ARG', 'dial_code' => '+54', 'emoji' => '🇦🇷'],
            ['name' => 'Armenia', 'code' => 'AM', 'alpha3' => 'ARM', 'dial_code' => '+374', 'emoji' => '🇦🇲'],
            ['name' => 'Austria', 'code' => 'AT', 'alpha3' => 'AUT', 'dial_code' => '+43', 'emoji' => '🇦🇹'],
            ['name' => 'Azerbaijan', 'code' => 'AZ', 'alpha3' => 'AZE', 'dial_code' => '+994', 'emoji' => '🇦🇿'],
            ['name' => 'Bahamas', 'code' => 'BS', 'alpha3' => 'BHS', 'dial_code' => '+1-242', 'emoji' => '🇧🇸'],
            ['name' => 'Bahrain', 'code' => 'BH', 'alpha3' => 'BHR', 'dial_code' => '+973', 'emoji' => '🇧🇭'],
            ['name' => 'Bangladesh', 'code' => 'BD', 'alpha3' => 'BGD', 'dial_code' => '+880', 'emoji' => '🇧🇩'],
            ['name' => 'Barbados', 'code' => 'BB', 'alpha3' => 'BRB', 'dial_code' => '+1-246', 'emoji' => '🇧🇧'],
            ['name' => 'Belarus', 'code' => 'BY', 'alpha3' => 'BLR', 'dial_code' => '+375', 'emoji' => '🇧🇾'],
            ['name' => 'Belgium', 'code' => 'BE', 'alpha3' => 'BEL', 'dial_code' => '+32', 'emoji' => '🇧🇪'],
            ['name' => 'Belize', 'code' => 'BZ', 'alpha3' => 'BLZ', 'dial_code' => '+501', 'emoji' => '🇧🇿'],
            ['name' => 'Benin', 'code' => 'BJ', 'alpha3' => 'BEN', 'dial_code' => '+229', 'emoji' => '🇧🇯'],
            ['name' => 'Bhutan', 'code' => 'BT', 'alpha3' => 'BTN', 'dial_code' => '+975', 'emoji' => '🇧🇹'],
            ['name' => 'Bolivia', 'code' => 'BO', 'alpha3' => 'BOL', 'dial_code' => '+591', 'emoji' => '🇧🇴'],
            ['name' => 'Bosnia and Herzegovina', 'code' => 'BA', 'alpha3' => 'BIH', 'dial_code' => '+387', 'emoji' => '🇧🇦'],
            ['name' => 'Botswana', 'code' => 'BW', 'alpha3' => 'BWA', 'dial_code' => '+267', 'emoji' => '🇧🇼'],
            ['name' => 'Brazil', 'code' => 'BR', 'alpha3' => 'BRA', 'dial_code' => '+55', 'emoji' => '🇧🇷'],
            ['name' => 'Brunei', 'code' => 'BN', 'alpha3' => 'BRN', 'dial_code' => '+673', 'emoji' => '🇧🇳'],
            ['name' => 'Bulgaria', 'code' => 'BG', 'alpha3' => 'BGR', 'dial_code' => '+359', 'emoji' => '🇧🇬'],
            ['name' => 'Cambodia', 'code' => 'KH', 'alpha3' => 'KHM', 'dial_code' => '+855', 'emoji' => '🇰🇭'],
            ['name' => 'Cameroon', 'code' => 'CM', 'alpha3' => 'CMR', 'dial_code' => '+237', 'emoji' => '🇨🇲'],
            ['name' => 'Chile', 'code' => 'CL', 'alpha3' => 'CHL', 'dial_code' => '+56', 'emoji' => '🇨🇱'],
            ['name' => 'China', 'code' => 'CN', 'alpha3' => 'CHN', 'dial_code' => '+86', 'emoji' => '🇨🇳'],
            ['name' => 'Colombia', 'code' => 'CO', 'alpha3' => 'COL', 'dial_code' => '+57', 'emoji' => '🇨🇴'],
            ['name' => 'Costa Rica', 'code' => 'CR', 'alpha3' => 'CRI', 'dial_code' => '+506', 'emoji' => '🇨🇷'],
            ['name' => 'Croatia', 'code' => 'HR', 'alpha3' => 'HRV', 'dial_code' => '+385', 'emoji' => '🇭🇷'],
            ['name' => 'Cyprus', 'code' => 'CY', 'alpha3' => 'CYP', 'dial_code' => '+357', 'emoji' => '🇨🇾'],
            ['name' => 'Czech Republic', 'code' => 'CZ', 'alpha3' => 'CZE', 'dial_code' => '+420', 'emoji' => '🇨🇿'],
            ['name' => 'Denmark', 'code' => 'DK', 'alpha3' => 'DNK', 'dial_code' => '+45', 'emoji' => '🇩🇰'],
            ['name' => 'Ecuador', 'code' => 'EC', 'alpha3' => 'ECU', 'dial_code' => '+593', 'emoji' => '🇪🇨'],
            ['name' => 'Egypt', 'code' => 'EG', 'alpha3' => 'EGY', 'dial_code' => '+20', 'emoji' => '🇪🇬'],
            ['name' => 'Estonia', 'code' => 'EE', 'alpha3' => 'EST', 'dial_code' => '+372', 'emoji' => '🇪🇪'],
            ['name' => 'Ethiopia', 'code' => 'ET', 'alpha3' => 'ETH', 'dial_code' => '+251', 'emoji' => '🇪🇹'],
            ['name' => 'Finland', 'code' => 'FI', 'alpha3' => 'FIN', 'dial_code' => '+358', 'emoji' => '🇫🇮'],
            ['name' => 'Georgia', 'code' => 'GE', 'alpha3' => 'GEO', 'dial_code' => '+995', 'emoji' => '🇬🇪'],
            ['name' => 'Ghana', 'code' => 'GH', 'alpha3' => 'GHA', 'dial_code' => '+233', 'emoji' => '🇬🇭'],
            ['name' => 'Greece', 'code' => 'GR', 'alpha3' => 'GRC', 'dial_code' => '+30', 'emoji' => '🇬🇷'],
            ['name' => 'Hong Kong', 'code' => 'HK', 'alpha3' => 'HKG', 'dial_code' => '+852', 'emoji' => '🇭🇰'],
            ['name' => 'Hungary', 'code' => 'HU', 'alpha3' => 'HUN', 'dial_code' => '+36', 'emoji' => '🇭🇺'],
            ['name' => 'Iceland', 'code' => 'IS', 'alpha3' => 'ISL', 'dial_code' => '+354', 'emoji' => '🇮🇸'],
            ['name' => 'Indonesia', 'code' => 'ID', 'alpha3' => 'IDN', 'dial_code' => '+62', 'emoji' => '🇮🇩'],
            ['name' => 'Ireland', 'code' => 'IE', 'alpha3' => 'IRL', 'dial_code' => '+353', 'emoji' => '🇮🇪'],
            ['name' => 'Israel', 'code' => 'IL', 'alpha3' => 'ISR', 'dial_code' => '+972', 'emoji' => '🇮🇱'],
            ['name' => 'Italy', 'code' => 'IT', 'alpha3' => 'ITA', 'dial_code' => '+39', 'emoji' => '🇮🇹'],
            ['name' => 'Japan', 'code' => 'JP', 'alpha3' => 'JPN', 'dial_code' => '+81', 'emoji' => '🇯🇵'],
            ['name' => 'Jordan', 'code' => 'JO', 'alpha3' => 'JOR', 'dial_code' => '+962', 'emoji' => '🇯🇴'],
            ['name' => 'Kazakhstan', 'code' => 'KZ', 'alpha3' => 'KAZ', 'dial_code' => '+7', 'emoji' => '🇰🇿'],
            ['name' => 'Kenya', 'code' => 'KE', 'alpha3' => 'KEN', 'dial_code' => '+254', 'emoji' => '🇰🇪'],
            ['name' => 'Kuwait', 'code' => 'KW', 'alpha3' => 'KWT', 'dial_code' => '+965', 'emoji' => '🇰🇼'],
            ['name' => 'Latvia', 'code' => 'LV', 'alpha3' => 'LVA', 'dial_code' => '+371', 'emoji' => '🇱🇻'],
            ['name' => 'Lebanon', 'code' => 'LB', 'alpha3' => 'LBN', 'dial_code' => '+961', 'emoji' => '🇱🇧'],
            ['name' => 'Lithuania', 'code' => 'LT', 'alpha3' => 'LTU', 'dial_code' => '+370', 'emoji' => '🇱🇹'],
            ['name' => 'Luxembourg', 'code' => 'LU', 'alpha3' => 'LUX', 'dial_code' => '+352', 'emoji' => '🇱🇺'],
            ['name' => 'Malaysia', 'code' => 'MY', 'alpha3' => 'MYS', 'dial_code' => '+60', 'emoji' => '🇲🇾'],
            ['name' => 'Maldives', 'code' => 'MV', 'alpha3' => 'MDV', 'dial_code' => '+960', 'emoji' => '🇲🇻'],
            ['name' => 'Malta', 'code' => 'MT', 'alpha3' => 'MLT', 'dial_code' => '+356', 'emoji' => '🇲🇹'],
            ['name' => 'Mexico', 'code' => 'MX', 'alpha3' => 'MEX', 'dial_code' => '+52', 'emoji' => '🇲🇽'],
            ['name' => 'Monaco', 'code' => 'MC', 'alpha3' => 'MCO', 'dial_code' => '+377', 'emoji' => '🇲🇨'],
            ['name' => 'Morocco', 'code' => 'MA', 'alpha3' => 'MAR', 'dial_code' => '+212', 'emoji' => '🇲🇦'],
            ['name' => 'Nepal', 'code' => 'NP', 'alpha3' => 'NPL', 'dial_code' => '+977', 'emoji' => '🇳🇵'],
            ['name' => 'Netherlands', 'code' => 'NL', 'alpha3' => 'NLD', 'dial_code' => '+31', 'emoji' => '🇳🇱'],
            ['name' => 'New Zealand', 'code' => 'NZ', 'alpha3' => 'NZL', 'dial_code' => '+64', 'emoji' => '🇳🇿'],
            ['name' => 'Nigeria', 'code' => 'NG', 'alpha3' => 'NGA', 'dial_code' => '+234', 'emoji' => '🇳🇬'],
            ['name' => 'Norway', 'code' => 'NO', 'alpha3' => 'NOR', 'dial_code' => '+47', 'emoji' => '🇳🇴'],
            ['name' => 'Oman', 'code' => 'OM', 'alpha3' => 'OMN', 'dial_code' => '+968', 'emoji' => '🇴🇲'],
            ['name' => 'Panama', 'code' => 'PA', 'alpha3' => 'PAN', 'dial_code' => '+507', 'emoji' => '🇵🇦'],
            ['name' => 'Philippines', 'code' => 'PH', 'alpha3' => 'PHL', 'dial_code' => '+63', 'emoji' => '🇵🇭'],
            ['name' => 'Poland', 'code' => 'PL', 'alpha3' => 'POL', 'dial_code' => '+48', 'emoji' => '🇵🇱'],
            ['name' => 'Portugal', 'code' => 'PT', 'alpha3' => 'PRT', 'dial_code' => '+351', 'emoji' => '🇵🇹'],
            ['name' => 'Qatar', 'code' => 'QA', 'alpha3' => 'QAT', 'dial_code' => '+974', 'emoji' => '🇶🇦'],
            ['name' => 'Romania', 'code' => 'RO', 'alpha3' => 'ROU', 'dial_code' => '+40', 'emoji' => '🇷🇴'],
            ['name' => 'Singapore', 'code' => 'SG', 'alpha3' => 'SGP', 'dial_code' => '+65', 'emoji' => '🇸🇬'],
            ['name' => 'South Africa', 'code' => 'ZA', 'alpha3' => 'ZAF', 'dial_code' => '+27', 'emoji' => '🇿🇦'],
            ['name' => 'South Korea', 'code' => 'KR', 'alpha3' => 'KOR', 'dial_code' => '+82', 'emoji' => '🇰🇷'],
            ['name' => 'Spain', 'code' => 'ES', 'alpha3' => 'ESP', 'dial_code' => '+34', 'emoji' => '🇪🇸'],
            ['name' => 'Sri Lanka', 'code' => 'LK', 'alpha3' => 'LKA', 'dial_code' => '+94', 'emoji' => '🇱🇰'],
            ['name' => 'Sweden', 'code' => 'SE', 'alpha3' => 'SWE', 'dial_code' => '+46', 'emoji' => '🇸🇪'],
            ['name' => 'Switzerland', 'code' => 'CH', 'alpha3' => 'CHE', 'dial_code' => '+41', 'emoji' => '🇨🇭'],
            ['name' => 'Taiwan', 'code' => 'TW', 'alpha3' => 'TWN', 'dial_code' => '+886', 'emoji' => '🇹🇼'],
            ['name' => 'Thailand', 'code' => 'TH', 'alpha3' => 'THA', 'dial_code' => '+66', 'emoji' => '🇹🇭'],
            ['name' => 'Turkey', 'code' => 'TR', 'alpha3' => 'TUR', 'dial_code' => '+90', 'emoji' => '🇹🇷'],
            ['name' => 'Ukraine', 'code' => 'UA', 'alpha3' => 'UKR', 'dial_code' => '+380', 'emoji' => '🇺🇦'],
            ['name' => 'Vietnam', 'code' => 'VN', 'alpha3' => 'VNM', 'dial_code' => '+84', 'emoji' => '🇻🇳']
        ];
        return $countries;
    }
}

if (!function_exists('getCountryByCode')) {
    function getCountryByCode(string $code): ?array {
        $clean = strtoupper(trim($code));
        foreach (getCountries() as $c) {
            if ($c['code'] === $clean || $c['alpha3'] === $clean) {
                return $c;
            }
        }
        return null;
    }
}

if (!function_exists('getCountryByName')) {
    function getCountryByName(string $name): ?array {
        $clean = strtolower(trim($name));
        foreach (getCountries() as $c) {
            if (strtolower($c['name']) === $clean) {
                return $c;
            }
        }
        return null;
    }
}
