<?php
/**
 * Estate HDR — Lightweight Background Job Queue Engine
 * PRD Section 13: Async dispatch for notifications, lead score rollups, and file processing.
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';

class QueueEngine {
    public static function dispatch(string $jobType, array $payload): bool {
        $pdo = Database::getConnection();
        $now = date('Y-m-d H:i:s');

        if ($pdo) {
            try {
                $stmt = $pdo->prepare("INSERT INTO database_queue (job_type, payload_json, status, created_at) VALUES (?, ?, 'pending', ?)");
                return $stmt->execute([$jobType, json_encode($payload), $now]);
            } catch (Throwable $e) {}
        }

        // JSON file queue fallback
        $dataPath = defined('DATA_PATH') ? DATA_PATH : (dirname(__DIR__) . '/data/');
        $queueFile = $dataPath . 'async_queue.json';
        $queue = file_exists($queueFile) ? (json_decode(file_get_contents($queueFile), true) ?: []) : [];
        $queue[] = [
            'id'         => 'JOB-' . bin2hex(random_bytes(4)),
            'job_type'   => $jobType,
            'payload'    => $payload,
            'status'     => 'pending',
            'created_at' => $now
        ];
        if (function_exists('atomicWriteJson')) atomicWriteJson($queueFile, $queue);
        return true;
    }
}
