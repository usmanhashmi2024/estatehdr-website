<?php
namespace EstateHDR\Repositories;

require_once __DIR__ . '/RepositoryInterface.php';
require_once __DIR__ . '/../config.php';

/**
 * Enterprise User Repository
 * Abstracts storage of Client and Staff user records with tenancy boundaries
 */
class UserRepository implements RepositoryInterface {
    protected string $usersFile;
    protected string $adminUsersFile;

    public function __construct() {
        $this->usersFile = DATA_PATH . '/users.json';
        $this->adminUsersFile = DATA_PATH . '/admin_users.json';
    }

    public function findById(string $id, string $tenantId = 'ehdr_main'): ?array {
        // Search clients
        if (file_exists($this->usersFile)) {
            $users = json_decode(file_get_contents($this->usersFile), true) ?: [];
            foreach ($users as $u) {
                if (($u['id'] ?? '') === $id) {
                    $u['tenant_id'] = $u['tenant_id'] ?? $tenantId;
                    return $u;
                }
            }
        }
        // Search admin / staff
        if (file_exists($this->adminUsersFile)) {
            $admins = json_decode(file_get_contents($this->adminUsersFile), true) ?: [];
            foreach ($admins as $a) {
                if (($a['id'] ?? '') === $id) {
                    $a['tenant_id'] = $a['tenant_id'] ?? $tenantId;
                    return $a;
                }
            }
        }
        return null;
    }

    public function findByEmail(string $email, string $tenantId = 'ehdr_main'): ?array {
        $cleanEmail = strtolower(trim($email));
        // Search clients
        if (file_exists($this->usersFile)) {
            $users = json_decode(file_get_contents($this->usersFile), true) ?: [];
            foreach ($users as $u) {
                if (strtolower($u['email'] ?? '') === $cleanEmail) {
                    $u['tenant_id'] = $u['tenant_id'] ?? $tenantId;
                    return $u;
                }
            }
        }
        // Search admin / staff
        if (file_exists($this->adminUsersFile)) {
            $admins = json_decode(file_get_contents($this->adminUsersFile), true) ?: [];
            foreach ($admins as $a) {
                if (strtolower($a['email'] ?? '') === $cleanEmail) {
                    $a['tenant_id'] = $a['tenant_id'] ?? $tenantId;
                    return $a;
                }
            }
        }
        return null;
    }

    public function findAll(array $criteria = [], int $limit = 50, int $offset = 0, string $tenantId = 'ehdr_main'): array {
        $results = [];
        if (file_exists($this->usersFile)) {
            $users = json_decode(file_get_contents($this->usersFile), true) ?: [];
            foreach ($users as $u) {
                $u['tenant_id'] = $u['tenant_id'] ?? $tenantId;
                $results[] = $u;
            }
        }
        return array_slice($results, $offset, $limit);
    }

    public function save(array $entity, string $tenantId = 'ehdr_main'): bool {
        $id = $entity['id'] ?? '';
        if (empty($id)) return false;

        $entity['tenant_id'] = $entity['tenant_id'] ?? $tenantId;
        $entity['updated_at'] = date('c');

        $isAdmin = str_starts_with($id, 'adm-') || in_array($entity['role'] ?? '', ['admin', 'manager', 'supervisor', 'team_lead', 'editor', 'photo_editor', 'hr', 'seo', 'owner', 'super_admin'], true);
        $targetFile = $isAdmin ? $this->adminUsersFile : $this->usersFile;

        $records = [];
        if (file_exists($targetFile)) {
            $records = json_decode(file_get_contents($targetFile), true) ?: [];
        }

        $found = false;
        foreach ($records as &$r) {
            if (($r['id'] ?? '') === $id || strtolower($r['email'] ?? '') === strtolower($entity['email'] ?? '')) {
                $r = array_merge($r, $entity);
                $found = true;
                break;
            }
        }
        if (!$found) {
            $records[] = $entity;
        }

        $tmpFile = $targetFile . '.' . bin2hex(random_bytes(4)) . '.tmp';
        if (file_put_contents($tmpFile, json_encode($records, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX) !== false) {
            return @rename($tmpFile, $targetFile);
        }
        return false;
    }

    public function delete(string $id, string $tenantId = 'ehdr_main'): bool {
        // Enforce soft-delete for audit trail
        $user = $this->findById($id, $tenantId);
        if (!$user) return false;
        $user['status'] = 'disabled';
        return $this->save($user, $tenantId);
    }
}
