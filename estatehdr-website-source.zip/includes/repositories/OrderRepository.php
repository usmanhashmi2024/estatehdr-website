<?php
namespace EstateHDR\Repositories;

require_once __DIR__ . '/RepositoryInterface.php';
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../saas-db.php';
require_once __DIR__ . '/../audit.php';

/**
 * Enterprise Order Repository
 * Implements storage abstraction and enforces Free Trial Immunity and State Transitions
 */
class OrderRepository implements RepositoryInterface {
    protected string $ordersDir;

    public function __construct() {
        $this->ordersDir = DATA_PATH . '/orders';
    }

    public function findById(string $id, string $tenantId = 'ehdr_main'): ?array {
        $filePath = $this->ordersDir . '/' . preg_replace('/[^a-zA-Z0-9_-]/', '', $id) . '.json';
        if (file_exists($filePath)) {
            $order = json_decode(file_get_contents($filePath), true) ?: null;
            if ($order) {
                $order['tenant_id'] = $order['tenant_id'] ?? $tenantId;
                return $order;
            }
        }

        // Check legacy saas_orders.json
        $legacy = \getSaaSOrders();
        foreach ($legacy as $o) {
            if (($o['id'] ?? '') === $id) {
                $o['tenant_id'] = $o['tenant_id'] ?? $tenantId;
                return $o;
            }
        }

        return null;
    }

    public function findAll(array $criteria = [], int $limit = 50, int $offset = 0, string $tenantId = 'ehdr_main'): array {
        $orders = \getAllOrders();
        if (!empty($criteria['client_id'])) {
            $orders = array_filter($orders, fn($o) => ($o['client_id'] ?? '') === $criteria['client_id']);
        }
        if (!empty($criteria['status'])) {
            $orders = array_filter($orders, fn($o) => ($o['status'] ?? '') === $criteria['status']);
        }
        if (isset($criteria['is_trial'])) {
            $orders = array_filter($orders, fn($o) => !empty($o['is_trial']) === $criteria['is_trial']);
        }
        return array_slice(array_values($orders), $offset, $limit);
    }

    public function save(array $entity, string $tenantId = 'ehdr_main'): bool {
        $id = $entity['id'] ?? '';
        if (empty($id)) return false;

        $entity['tenant_id'] = $entity['tenant_id'] ?? $tenantId;
        $entity['updated_at'] = date('c');

        // Enforce Free Trial Immunity Invariant (Section 15 & Rule 1)
        if (!empty($entity['is_trial'])) {
            $entity['total_price'] = 0.00;
            $entity['paid_amount'] = 0.00;
            $entity['price'] = 0.00;
            $entity['currency'] = 'USD';
        }

        if (!is_dir($this->ordersDir)) {
            @mkdir($this->ordersDir, 0755, true);
        }

        $filePath = $this->ordersDir . '/' . preg_replace('/[^a-zA-Z0-9_-]/', '', $id) . '.json';
        $tmpFile = $filePath . '.' . bin2hex(random_bytes(4)) . '.tmp';

        if (file_put_contents($tmpFile, json_encode($entity, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX) !== false) {
            $renamed = @rename($tmpFile, $filePath);
            if ($renamed) {
                \logAuditEvent('order.saved', $id, ['status' => $entity['status'] ?? '', 'is_trial' => !empty($entity['is_trial'])]);
            }
            return $renamed;
        }
        return false;
    }

    public function delete(string $id, string $tenantId = 'ehdr_main'): bool {
        $order = $this->findById($id, $tenantId);
        if (!$order) return false;
        $order['status'] = 'cancelled';
        return $this->save($order, $tenantId);
    }
}
