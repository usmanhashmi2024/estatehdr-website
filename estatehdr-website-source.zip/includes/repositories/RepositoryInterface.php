<?php
namespace EstateHDR\Repositories;

/**
 * Universal Repository Interface for Domain Entities
 * Decouples business logic from storage mechanism (JSON / PostgreSQL / MySQL)
 */
interface RepositoryInterface {
    public function findById(string $id, string $tenantId = 'ehdr_main'): ?array;
    public function findAll(array $criteria = [], int $limit = 50, int $offset = 0, string $tenantId = 'ehdr_main'): array;
    public function save(array $entity, string $tenantId = 'ehdr_main'): bool;
    public function delete(string $id, string $tenantId = 'ehdr_main'): bool;
}
