<?php
/**
 * Estate HDR — Structured Security Event Logger
 * Records tamper-evident security telemetry, attack attempts, bot triggers, and WAF blocks.
 */

declare(strict_types=1);

namespace EstateHDR\Security;

class SecurityLogger
{
    private static string $logFile = '';

    public static function init(): void
    {
        if (empty(self::$logFile)) {
            $basePath = defined('DATA_PATH') ? DATA_PATH : (dirname(__DIR__, 2) . '/data/');
            $dir = $basePath . 'security/';
            if (!is_dir($dir)) {
                @mkdir($dir, 0755, true);
            }
            self::$logFile = $dir . 'security_events.jsonl';
        }
    }

    /**
     * Resolves real client IP with support for Cloudflare and trusted reverse proxies.
     */
    public static function getClientIp(): string
    {
        $headers = [
            'HTTP_CF_CONNECTING_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'HTTP_CLIENT_IP',
            'REMOTE_ADDR'
        ];
        foreach ($headers as $h) {
            if (!empty($_SERVER[$h])) {
                $parts = explode(',', $_SERVER[$h]);
                $ip = trim($parts[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    }

    /**
     * Log a security incident to structured JSON Lines file.
     *
     * @param string $eventType e.g., 'bot_blocked', 'honeypot_triggered', 'spam_rejected', 'rate_limit_exceeded', 'xss_detected', 'csrf_failed'
     * @param string $severity 'INFO' | 'WARNING' | 'ALERT' | 'CRITICAL'
     * @param string $message Descriptive summary of the threat
     * @param array $context Additional threat telemetry (automatically sanitizes sensitive keys)
     */
    public static function log(string $eventType, string $severity, string $message, array $context = []): void
    {
        self::init();

        // Redact any potentially sensitive keys
        $redactedContext = self::redactSensitiveData($context);

        $event = [
            'timestamp'  => date('c'),
            'timestamp_epoch' => time(),
            'event_type' => $eventType,
            'severity'   => strtoupper($severity),
            'client_ip'  => self::getClientIp(),
            'user_agent' => substr($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown', 0, 300),
            'method'     => $_SERVER['REQUEST_METHOD'] ?? 'GET',
            'uri'        => substr($_SERVER['REQUEST_URI'] ?? '/', 0, 500),
            'message'    => $message,
            'context'    => $redactedContext
        ];

        $line = json_encode($event, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . PHP_EOL;
        @file_put_contents(self::$logFile, $line, FILE_APPEND | LOCK_EX);
    }

    /**
     * Redacts passwords, auth tokens, credit cards, and sensitive keys.
     */
    private static function redactSensitiveData(array $data): array
    {
        $sensitiveKeys = ['password', 'pass', 'token', 'csrf_token', 'turnstile_token', 'secret', 'auth', 'card', 'cvv'];
        $clean = [];

        foreach ($data as $k => $v) {
            if (in_array(strtolower((string)$k), $sensitiveKeys, true)) {
                $clean[$k] = '[REDACTED]';
            } elseif (is_array($v)) {
                $clean[$k] = self::redactSensitiveData($v);
            } elseif (is_string($v)) {
                $clean[$k] = substr($v, 0, 500); // Prevent gigantic payloads in log
            } else {
                $clean[$k] = $v;
            }
        }
        return $clean;
    }
}
