<?php
/**
 * Estate HDR — Subresource Integrity (SRI) Registry
 * Pre-computed SHA-384 hashes for all external CDN scripts and stylesheets.
 * Fixes Mozilla HTTP Observatory SRI -5 issue.
 *
 * Usage in PHP templates:
 *   <script src="..." <?= \EstateHDR\Security\SriRegistry::attr('https://...js') ?> crossorigin="anonymous"></script>
 *   <link   href="..." <?= \EstateHDR\Security\SriRegistry::attr('https://...css') ?> crossorigin="anonymous">
 */

declare(strict_types=1);

namespace EstateHDR\Security;

class SriRegistry
{
    /**
     * SHA-384 integrity hashes for known CDN assets.
     * Regenerate with: scripts/generate_sri_hashes.py
     */
    private static array $hashes = [
        'https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.1/cropper.min.css' => 'sha384-AMJcAgMUmNt1Zo4ranquGLeT5m7yOrVbtNsNk0oZohvxqKk6RRzXHqlEaS9gFXR7',
        'https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.6.1/cropper.min.js' => 'sha384-jzwsV9ieM/KUDMeo+d8dc+jm0GEl7ywPNwg10alB5BodVuC/Kx9RpEnyrl2Om9zH',
        'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js' => 'sha384-g4NTh/Iv5PPU4xPyhEWqPcwtNXOvdaDI8LLnyYfyNZOjKJeYQyjzQ9X5275eBjpt',
        'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js' => 'sha384-Z3REaz79l2IaAZqJsSABtTbhjgOUYyV3p90XNnAPCSHg3EMTz1fouunq9WZRtj3d',
    ];

    /**
     * Returns the integrity="..." attribute string for a CDN URL.
     * Returns empty string if URL is not in registry (safe fallback).
     */
    public static function attr(string $url): string
    {
        $hash = self::$hashes[$url] ?? null;
        if (!$hash) {
            return '';
        }
        return 'integrity="' . htmlspecialchars($hash, ENT_QUOTES) . '"';
    }

    /**
     * Returns the raw SRI hash for a URL, or null if not registered.
     */
    public static function hash(string $url): ?string
    {
        return self::$hashes[$url] ?? null;
    }

    /**
     * Returns all registered URLs.
     */
    public static function all(): array
    {
        return self::$hashes;
    }
}
