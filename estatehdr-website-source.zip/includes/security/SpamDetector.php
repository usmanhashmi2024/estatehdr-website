<?php
/**
 * Estate HDR — Multi-Tier Spam & Heuristic Threat Detector
 * Analyzes honeypots, submission velocity, keyword risk, URL farming, and disposable domains.
 */

declare(strict_types=1);

namespace EstateHDR\Security;

require_once __DIR__ . '/SecurityConfig.php';
require_once __DIR__ . '/SecurityLogger.php';

class SpamDetector
{
    /**
     * Generates a cryptographically signed time-token to measure form completion velocity.
     */
    public static function generateTimeToken(): string
    {
        $now = time();
        $hmac = hash_hmac('sha256', (string)$now, SecurityConfig::FORM_TOKEN_SECRET);
        return base64_encode("{$now}:{$hmac}");
    }

    /**
     * Validates submission timing token.
     * Returns: ['valid' => bool, 'elapsed' => int, 'reason' => string]
     */
    public static function validateTimeToken(?string $token): array
    {
        if (empty($token)) {
            return ['valid' => false, 'elapsed' => 0, 'reason' => 'Missing time token'];
        }

        $decoded = base64_decode($token, true);
        if (!$decoded || !str_contains($decoded, ':')) {
            return ['valid' => false, 'elapsed' => 0, 'reason' => 'Corrupted time token'];
        }

        [$timestampStr, $clientHmac] = explode(':', $decoded, 2);
        $timestamp = (int)$timestampStr;
        $expectedHmac = hash_hmac('sha256', (string)$timestamp, SecurityConfig::FORM_TOKEN_SECRET);

        if (!hash_equals($expectedHmac, $clientHmac)) {
            return ['valid' => false, 'elapsed' => 0, 'reason' => 'Forged time token'];
        }

        $now = time();
        $elapsed = $now - $timestamp;

        // Check if submitted too fast (automated bot filling fields instantly in < 3 seconds)
        if ($elapsed < SecurityConfig::MIN_SUBMISSION_TIME_SECS) {
            return ['valid' => false, 'elapsed' => $elapsed, 'reason' => 'Instant bot velocity (< 3s)'];
        }

        // Check if token has expired (> 24 hours old)
        if ($elapsed > SecurityConfig::MAX_SUBMISSION_TIME_SECS) {
            return ['valid' => false, 'elapsed' => $elapsed, 'reason' => 'Stale form session (> 24h)'];
        }

        return ['valid' => true, 'elapsed' => $elapsed, 'reason' => 'Valid velocity'];
    }

    /**
     * Inspects honeypot trap fields. Bots typically fill all text inputs found in the DOM.
     */
    public static function checkHoneypots(array $postData): bool
    {
        $honeypotKeys = ['website_url_hp', 'ehdr_company_fax_hp', '_gotcha', 'ehdr_security_hp'];
        foreach ($honeypotKeys as $key) {
            if (!empty($postData[$key])) {
                SecurityLogger::log('honeypot_triggered', 'ALERT', "Honeypot field '{$key}' was populated.", [
                    'field'     => $key,
                    'value'     => substr((string)$postData[$key], 0, 100),
                    'client_ip' => SecurityLogger::getClientIp()
                ]);
                return true; // Trap sprung!
            }
        }
        return false;
    }

    /**
     * Checks whether an email belongs to a known disposable / temporary burner provider.
     */
    public static function isDisposableEmail(string $email): bool
    {
        $domain = strtolower(substr(strrchr($email, "@") ?: '', 1));
        if (empty($domain)) return false;

        return in_array($domain, SecurityConfig::DISPOSABLE_EMAIL_DOMAINS, true);
    }

    /**
     * Heuristic analysis of text payload (message, notes, cloud link, name).
     */
    public static function analyzeSubmission(array $data): array
    {
        $score = 0;
        $reasons = [];

        // 1. Honeypot check (instant score +100)
        if (self::checkHoneypots($data)) {
            $score += 100;
            $reasons[] = 'Honeypot trap triggered';
        }

        // 2. Timing check
        $timeToken = $data['ehdr_time_token'] ?? null;
        $timingResult = self::validateTimeToken($timeToken);
        if (!$timingResult['valid']) {
            $score += 40;
            $reasons[] = 'Velocity check failed: ' . $timingResult['reason'];
        }

        // 3. Disposable email check
        $email = trim($data['email'] ?? '');
        if (!empty($email) && self::isDisposableEmail($email)) {
            $score += 50;
            $reasons[] = 'Disposable burner email domain detected';
        }

        // 4. Content & SEO Spam Inspection
        $combinedText = implode(' ', [
            $data['name'] ?? '',
            $data['email'] ?? '',
            $data['message'] ?? '',
            $data['notes'] ?? '',
            $data['cloud_link'] ?? ''
        ]);

        // Check for spam keyword patterns
        foreach (SecurityConfig::SPAM_KEYWORD_PATTERNS as $pattern) {
            if (preg_match($pattern, $combinedText, $matches)) {
                $score += 35;
                $reasons[] = 'Spam keyword match: ' . ($matches[0] ?? 'pattern');
            }
        }

        // Count URLs in message / notes
        $messageText = ($data['message'] ?? '') . ' ' . ($data['notes'] ?? '');
        $urlCount = preg_match_all('/https?:\/\/[^\s]+|www\.[^\s]+/i', $messageText);
        if ($urlCount > SecurityConfig::MAX_URLS_ALLOWED_IN_MESSAGE) {
            $score += 30;
            $reasons[] = "Excessive URLs in text payload ({$urlCount} links)";
        }

        // Check for Russian / Cyrillic / Chinese mass spam bot patterns in Western real estate forms
        if (preg_match('/[\x{0400}-\x{04FF}]{5,}/u', $combinedText)) {
            // Cyrillic character sequence
            $score += 25;
            $reasons[] = 'Foreign script pattern (Cyrillic bot payload)';
        }

        // 5. Final Determination
        $isSpam = $score >= SecurityConfig::SPAM_SCORE_THRESHOLD;

        if ($isSpam) {
            SecurityLogger::log('spam_rejected', 'ALERT', 'Submission rejected by spam scoring engine.', [
                'score'     => $score,
                'reasons'   => $reasons,
                'client_ip' => SecurityLogger::getClientIp(),
                'email'     => $email
            ]);
        }

        return [
            'is_spam'      => $isSpam,
            'score'        => $score,
            'reasons'      => $reasons,
            'threat_level' => $score >= 80 ? 'CRITICAL' : ($score >= 50 ? 'HIGH' : ($score >= 20 ? 'MEDIUM' : 'LOW'))
        ];
    }

    /**
     * Renders hidden honeypot HTML fields + signed time token.
     */
    public static function renderHoneypotFields(): string
    {
        $timeToken = self::generateTimeToken();
        return <<<HTML
<!-- Anti-Bot Defense Fields -->
<div style="position:absolute;left:-9999px;top:-9999px;opacity:0;pointer-events:none;width:0;height:0;overflow:hidden;" aria-hidden="true" tabindex="-1">
    <label for="website_url_hp">Leave this field blank</label>
    <input type="text" id="website_url_hp" name="website_url_hp" autocomplete="off" tabindex="-1" value="">
    <label for="ehdr_company_fax_hp">Fax Number</label>
    <input type="text" id="ehdr_company_fax_hp" name="ehdr_company_fax_hp" autocomplete="off" tabindex="-1" value="">
    <input type="hidden" name="_gotcha" value="">
</div>
<input type="hidden" name="ehdr_time_token" value="{$timeToken}">
HTML;
    }
}
