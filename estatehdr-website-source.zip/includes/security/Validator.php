<?php
/**
 * Estate HDR — Strict Server-Side Input Validator & Sanitizer
 * Enforces field length constraints, regex schemas, UTF-8 encoding, and prevents XSS/injection attacks.
 */

declare(strict_types=1);

namespace EstateHDR\Security;

class Validator
{
    /**
     * Sanitizes string by stripping dangerous tags, normalizing UTF-8, and removing non-printable characters.
     */
    public static function sanitizeString(string $input, int $maxLength = 1000): string
    {
        // Strip null bytes and control chars
        $clean = str_replace(chr(0), '', $input);
        $clean = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $clean);

        // Strip HTML tags
        $clean = strip_tags($clean);

        // Trim and normalize whitespace
        $clean = trim($clean);

        // Enforce max length
        if (mb_strlen($clean) > $maxLength) {
            $clean = mb_substr($clean, 0, $maxLength);
        }

        return $clean;
    }

    /**
     * Validates and cleans email address.
     */
    public static function sanitizeEmail(string $email): string
    {
        $email = trim(strtolower($email));
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return $email;
        }
        return '';
    }

    /**
     * Sanitizes phone/WhatsApp number.
     */
    public static function sanitizePhone(string $phone): string
    {
        // Keep digits, +, -, (, ), and spaces
        $phone = preg_replace('/[^\d\+\-\(\)\s\.]/', '', $phone);
        return trim(substr($phone, 0, 30));
    }

    /**
     * Validates cloud storage link.
     * Must be a valid HTTPS URL pointing to recognized cloud services or valid HTTP/HTTPS endpoints.
     */
    public static function validateCloudLink(string $url): bool
    {
        $url = trim($url);
        if (empty($url)) return false;

        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return false;
        }

        $scheme = strtolower((string)parse_url($url, PHP_URL_SCHEME));
        if ($scheme !== 'https' && $scheme !== 'http') {
            return false; // Blocks javascript:, file:, phar:, data:
        }

        $host = strtolower((string)parse_url($url, PHP_URL_HOST));
        if (empty($host)) return false;

        // Block localhost and common SSRF bypasses
        if (in_array($host, ['localhost', '127.0.0.1', '::1', '0.0.0.0', '169.254.169.254', 'metadata.google.internal'], true)) {
            return false;
        }

        // Check if IP is in private / reserved IP range
        $ip = filter_var($host, FILTER_VALIDATE_IP) ? $host : @gethostbyname($host);
        if (filter_var($ip, FILTER_VALIDATE_IP)) {
            $isPublic = filter_var(
                $ip,
                FILTER_VALIDATE_IP,
                FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
            );
            if ($isPublic === false) {
                return false; // Block internal network scanning / SSRF
            }
        }

        return true;
    }

    /**
     * Complete validation pipeline for Free Trial and Contact Lead submissions.
     */
    public static function validateLeadSubmission(array $input, bool $requireCloudLink = true): array
    {
        $errors = [];
        $sanitized = [];

        // 1. Name validation
        $rawName = $input['name'] ?? '';
        $name = self::sanitizeString($rawName, 100);
        if (empty($name) || mb_strlen($name) < 2) {
            $errors['name'] = 'Please enter your full name (at least 2 characters).';
        }
        $sanitized['name'] = $name;

        // 2. Email validation
        $rawEmail = $input['email'] ?? '';
        $email = self::sanitizeEmail($rawEmail);
        if (empty($email)) {
            $errors['email'] = 'Please enter a valid work email address.';
        }
        $sanitized['email'] = $email;

        // 3. Phone validation
        $rawPhone = $input['phone'] ?? ($input['whatsapp'] ?? '');
        $sanitized['phone'] = self::sanitizePhone($rawPhone);

        // 4. Service validation
        $allowedServices = [
            'HDR Photo Editing', 'Virtual Staging', 'Item Removal', 'Virtual Twilight',
            'Day to Dusk', 'Floor Plans & 3D Tours', 'Virtual Renovation', 'General Inquiry',
            'Custom Enterprise Inquiry', 'Commercial HDR Retouching'
        ];
        $rawService = self::sanitizeString($input['service'] ?? 'HDR Photo Editing', 100);
        $sanitized['service'] = in_array($rawService, $allowedServices, true) ? $rawService : 'HDR Photo Editing';

        // 5. Cloud Storage Link validation
        $rawLink = trim($input['cloud_link'] ?? '');
        if ($requireCloudLink && empty($rawLink)) {
            $errors['cloud_link'] = 'Please provide a valid cloud storage link (Google Drive, Dropbox, or WeTransfer).';
        } elseif (!empty($rawLink) && !self::validateCloudLink($rawLink)) {
            $errors['cloud_link'] = 'Please provide a valid HTTPS storage link.';
        }
        $sanitized['cloud_link'] = htmlspecialchars($rawLink, ENT_QUOTES, 'UTF-8');

        // 6. Notes / Message validation
        $rawNotes = $input['notes'] ?? ($input['message'] ?? '');
        $sanitized['message'] = self::sanitizeString($rawNotes, 3000);
        $sanitized['notes']   = $sanitized['message'];

        return [
            'valid'     => empty($errors),
            'sanitized' => $sanitized,
            'errors'    => $errors
        ];
    }
}
