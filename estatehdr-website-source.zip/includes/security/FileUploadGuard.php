<?php
/**
 * Estate HDR — Secure File Upload Pipeline & Magic-Byte MIME Enforcement
 * Validates binary signatures, sanitizes SVGs against XSS, prevents directory traversal, and enforces quotas.
 */

declare(strict_types=1);

namespace EstateHDR\Security;

require_once __DIR__ . '/SecurityLogger.php';

class FileUploadGuard
{
    public const MAX_IMAGE_SIZE_BYTES = 26214400; // 25 MB
    public const MAX_ZIP_SIZE_BYTES   = 104857600; // 100 MB

    // Allowed MIME types mapped to allowed extensions
    public const MIME_MAP = [
        'image/jpeg'      => ['jpg', 'jpeg'],
        'image/png'       => ['png'],
        'image/webp'      => ['webp'],
        'image/gif'       => ['gif'],
        'image/svg+xml'   => ['svg'],
        'application/zip' => ['zip'],
        'application/x-zip-compressed' => ['zip']
    ];

    /**
     * Inspects magic bytes and MIME type from temporary uploaded file.
     */
    public static function inspectMime(string $filePath): ?string
    {
        if (!file_exists($filePath) || !is_readable($filePath)) {
            return null;
        }

        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $filePath);
            finfo_close($finfo);
            return $mime ?: null;
        }

        if (function_exists('mime_content_type')) {
            return mime_content_type($filePath) ?: null;
        }

        return null;
    }

    /**
     * Validates an uploaded file from $_FILES.
     *
     * @param array $file Single $_FILES entry
     * @param array $allowedExts Allowed extension list, e.g. ['jpg', 'png', 'webp', 'svg']
     * @param int $maxSizeBytes Maximum size in bytes
     * @return array ['valid' => bool, 'ext' => string, 'mime' => string, 'error' => ?string]
     */
    public static function validateUploadedFile(array $file, array $allowedExts = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'svg'], int $maxSizeBytes = self::MAX_IMAGE_SIZE_BYTES): array
    {
        if (!isset($file['error']) || is_array($file['error'])) {
            return ['valid' => false, 'ext' => '', 'mime' => '', 'error' => 'Invalid upload parameters.'];
        }

        if ($file['error'] !== UPLOAD_ERR_OK) {
            $errorMessages = [
                UPLOAD_ERR_INI_SIZE   => 'The uploaded file exceeds the server max upload size.',
                UPLOAD_ERR_FORM_SIZE  => 'The uploaded file exceeds the form MAX_FILE_SIZE.',
                UPLOAD_ERR_PARTIAL    => 'The file was only partially uploaded.',
                UPLOAD_ERR_NO_FILE    => 'No file was uploaded.',
                UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder on server.',
                UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
                UPLOAD_ERR_EXTENSION  => 'A PHP extension stopped the file upload.'
            ];
            return ['valid' => false, 'ext' => '', 'mime' => '', 'error' => $errorMessages[$file['error']] ?? 'File upload error.'];
        }

        if ($file['size'] > $maxSizeBytes) {
            $maxMb = round($maxSizeBytes / (1024 * 1024), 1);
            return ['valid' => false, 'ext' => '', 'mime' => '', 'error' => "File size exceeds maximum limit of {$maxMb}MB."];
        }

        $tmpPath = $file['tmp_name'];
        if (!is_uploaded_file($tmpPath)) {
            SecurityLogger::log('file_upload_exploit', 'CRITICAL', 'Potential file upload bypass attempt: file is not an uploaded tmp file.', [
                'tmp_name'  => $tmpPath,
                'client_ip' => SecurityLogger::getClientIp()
            ]);
            return ['valid' => false, 'ext' => '', 'mime' => '', 'error' => 'Security error: invalid upload source.'];
        }

        // 1. Verify extension
        $origName = $file['name'];
        $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
        if ($ext === 'jpeg') $ext = 'jpg';

        if (!in_array($ext, $allowedExts, true)) {
            return ['valid' => false, 'ext' => $ext, 'mime' => '', 'error' => "File extension '.{$ext}' is not permitted."];
        }

        // 2. Inspect Magic Bytes / Real MIME
        $realMime = self::inspectMime($tmpPath);
        if ($realMime === null) {
            return ['valid' => false, 'ext' => $ext, 'mime' => '', 'error' => 'Could not determine file MIME type.'];
        }

        // Check if MIME matches extension
        $validMimesForExt = [];
        foreach (self::MIME_MAP as $m => $exts) {
            if (in_array($ext, $exts, true)) {
                $validMimesForExt[] = $m;
            }
        }

        // Handle SVG special text/xml or image/svg+xml
        if ($ext === 'svg' && (str_contains($realMime, 'svg') || str_contains($realMime, 'xml') || str_contains($realMime, 'text/plain'))) {
            // Valid SVG candidate, will be sanitized
        } elseif (!empty($validMimesForExt) && !in_array($realMime, $validMimesForExt, true)) {
            SecurityLogger::log('file_mime_mismatch', 'ALERT', "MIME mismatch: extension .{$ext} but real MIME is {$realMime}", [
                'filename'  => $origName,
                'real_mime' => $realMime,
                'client_ip' => SecurityLogger::getClientIp()
            ]);
            return ['valid' => false, 'ext' => $ext, 'mime' => $realMime, 'error' => 'File content does not match its file extension.'];
        }

        // 3. Image dimensions check for raster images
        if (in_array($ext, ['jpg', 'png', 'webp', 'gif'], true)) {
            $imgInfo = @getimagesize($tmpPath);
            if ($imgInfo === false) {
                return ['valid' => false, 'ext' => $ext, 'mime' => $realMime, 'error' => 'Invalid image structure or corrupt file.'];
            }
        }

        return [
            'valid' => true,
            'ext'   => $ext,
            'mime'  => $realMime,
            'error' => null
        ];
    }

    /**
     * Sanitizes SVG content by removing malicious scripts, javascript: URLs, and XXE injection vectors.
     */
    public static function sanitizeSvg(string $svgContent): string
    {
        // Remove XML external entity doctype / declarations
        $clean = preg_replace('/<!DOCTYPE[^>]*>/i', '', $svgContent);
        $clean = preg_replace('/<!ENTITY[^>]*>/i', '', $clean);

        // Remove <script> tags (including any with nonce attributes)
        $clean = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $clean);

        // Remove dangerous event handlers (onload, onclick, onerror, etc.)
        $clean = preg_replace('/\son[a-z]+\s*=\s*(["\']).*?\1/i', '', $clean);
        $clean = preg_replace('/\son[a-z]+\s*=\s*[^\s>]+/i', '', $clean);

        // Remove javascript: and data: pseudo protocols in href/xlink:href
        $clean = preg_replace('/href\s*=\s*(["\'])\s*(javascript|data):.*?\1/i', 'href="#"', $clean);
        $clean = preg_replace('/xlink:href\s*=\s*(["\'])\s*(javascript|data):.*?\1/i', 'xlink:href="#"', $clean);

        // Remove foreignObject
        $clean = preg_replace('/<foreignObject\b[^>]*>(.*?)<\/foreignObject>/is', '', $clean);

        return $clean;
    }

    /**
     * Generates a safe, randomized filename for storage to avoid collision or path traversal.
     */
    public static function generateSafeFilename(string $originalName, string $prefix = 'ehdr'): string
    {
        $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        if ($ext === 'jpeg') $ext = 'jpg';

        $baseSlug = strtolower(preg_replace('/[^a-z0-9]+/', '-', pathinfo($originalName, PATHINFO_FILENAME)));
        $baseSlug = trim($baseSlug, '-');
        if (empty($baseSlug)) $baseSlug = 'media';
        if (strlen($baseSlug) > 40) $baseSlug = substr($baseSlug, 0, 40);

        $randomHex = bin2hex(random_bytes(6));
        return "{$prefix}_{$baseSlug}_{$randomHex}.{$ext}";
    }
}
