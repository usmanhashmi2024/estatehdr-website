<?php
/**
 * Estate HDR — Atomic Sliding-Window Rate Limiter
 * Protects endpoints, lead forms, and API routes against brute-force, credential stuffing, and bot flooding.
 */

declare(strict_types=1);

namespace EstateHDR\Security;

require_once __DIR__ . '/SecurityConfig.php';
require_once __DIR__ . '/SecurityLogger.php';

class RateLimiter
{
    private static string $storageFile = '';

    private static function initStorage(): void
    {
        if (empty(self::$storageFile)) {
            $basePath = defined('DATA_PATH') ? DATA_PATH : (dirname(__DIR__, 2) . '/data/');
            $dir = $basePath . 'security/';
            if (!is_dir($dir)) {
                @mkdir($dir, 0755, true);
            }
            self::$storageFile = $dir . 'rate_limits.json';
        }
    }

    /**
     * Checks rate limit status for a given action and IP without blocking.
     */
    public static function check(string $action, ?string $ip = null): array
    {
        self::initStorage();
        $ip = $ip ?: SecurityLogger::getClientIp();

        // Check whitelist
        if (in_array($ip, SecurityConfig::IP_WHITELIST, true)) {
            return [
                'allowed'   => true,
                'remaining' => 999,
                'reset'     => time() + 60,
                'limit'     => 999
            ];
        }

        $rule = SecurityConfig::RATE_LIMITS[$action] ?? SecurityConfig::RATE_LIMITS['api_default'];
        $maxRequests   = $rule['limit'];
        $windowSeconds = $rule['window'];
        $now = time();
        $windowStart = $now - $windowSeconds;

        $key = md5("{$action}:{$ip}");
        $data = self::readStore();

        $timestamps = $data[$key] ?? [];
        // Filter timestamps within current sliding window
        $activeTimestamps = array_values(array_filter($timestamps, fn($ts) => $ts > $windowStart));

        $count = count($activeTimestamps);
        $allowed = $count < $maxRequests;
        $remaining = max(0, $maxRequests - $count - 1);
        $oldest = !empty($activeTimestamps) ? min($activeTimestamps) : $now;
        $resetTime = $oldest + $windowSeconds;

        if ($allowed) {
            $activeTimestamps[] = $now;
            $data[$key] = $activeTimestamps;
            self::writeStore($data);
        } else {
            SecurityLogger::log('rate_limit_exceeded', 'WARNING', "Rate limit exceeded for action: {$action}", [
                'action'     => $action,
                'client_ip'  => $ip,
                'count'      => $count,
                'max_limit'  => $maxRequests,
                'window_sec' => $windowSeconds
            ]);
        }

        return [
            'allowed'   => $allowed,
            'remaining' => $remaining,
            'reset'     => $resetTime,
            'limit'     => $maxRequests
        ];
    }

    /**
     * Enforces rate limiting immediately. If exceeded, returns HTTP 429 and terminates request.
     */
    public static function enforce(string $action, ?string $ip = null, bool $isJson = false): void
    {
        $status = self::check($action, $ip);
        if (!$status['allowed']) {
            $retryAfter = max(1, $status['reset'] - time());
            http_response_code(429);
            header("Retry-After: {$retryAfter}");
            header("X-RateLimit-Limit: {$status['limit']}");
            header("X-RateLimit-Remaining: 0");
            header("X-RateLimit-Reset: {$status['reset']}");

            if ($isJson || (!empty($_SERVER['HTTP_ACCEPT']) && str_contains($_SERVER['HTTP_ACCEPT'], 'application/json'))) {
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode([
                    'success'     => false,
                    'error'       => 'Too many requests. Please slow down and try again later.',
                    'retry_after' => $retryAfter
                ]);
            } else {
                echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>429 Too Many Requests</title>'
                   . '<style nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">body{background:#0A0A0F;color:#F3F4F6;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0}'
                   . '.card{background:#111118;border:1px solid #1E1E2E;padding:32px;border-radius:16px;max-width:440px;text-align:center;box-shadow:0 8px 32px rgba(0,0,0,0.5)}'
                   . 'h1{color:#C9A84C;margin-top:0;font-size:24px}p{color:#9CA3AF;font-size:14px;line-height:1.5}</style></head>'
                   . '<body><div class="card"><h1>Rate Limit Exceeded</h1><p>You have submitted too many requests in a short period. For security and anti-bot protection, your access is temporarily throttled.</p>'
                   . "<p>Please retry in <strong>{$retryAfter} seconds</strong>.</p></div></body></html>";
            }
            exit;
        }
    }

    private static function readStore(): array
    {
        if (!file_exists(self::$storageFile)) {
            return [];
        }
        $fp = @fopen(self::$storageFile, 'r');
        if (!$fp) return [];

        @flock($fp, LOCK_SH);
        $content = @stream_get_contents($fp);
        @flock($fp, LOCK_UN);
        @fclose($fp);

        $data = json_decode($content ?: '[]', true);
        return is_array($data) ? $data : [];
    }

    private static function writeStore(array $data): void
    {
        // Periodic clean up of stale keys (> 2 hours old)
        $cutoff = time() - 7200;
        foreach ($data as $k => $timestamps) {
            $data[$k] = array_values(array_filter($timestamps, fn($ts) => $ts > $cutoff));
            if (empty($data[$k])) {
                unset($data[$k]);
            }
        }

        $json = json_encode($data, JSON_UNESCAPED_SLASHES);
        $tempFile = self::$storageFile . '.' . bin2hex(random_bytes(4)) . '.tmp';
        
        if (@file_put_contents($tempFile, $json, LOCK_EX) !== false) {
            @rename($tempFile, self::$storageFile);
        }
    }
}
