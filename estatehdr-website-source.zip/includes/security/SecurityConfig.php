<?php
/**
 * Estate HDR — Enterprise Security & Anti-Bot Hardening Configuration
 * Centralized security settings, API keys, rate limit rules, and threat mitigation policies.
 */

declare(strict_types=1);

namespace EstateHDR\Security;

class SecurityConfig
{
    // ─── Cloudflare Turnstile Configuration ─────────────────────────────────────
    // Set via environment variables or define in config.php. Dummy test keys provided as safe fallbacks.
    public const TURNSTILE_SITE_KEY   = '0x4AAAAAAAxxxxxxxxxxxxxx'; // Cloudflare Turnstile Site Key (env: TURNSTILE_SITE_KEY)
    public const TURNSTILE_SECRET_KEY = '0x4AAAAAAAxxxxxxxxxxxxxxxxxxxxxxxxxxxx'; // Cloudflare Turnstile Secret Key (env: TURNSTILE_SECRET_KEY)
    public const TURNSTILE_VERIFY_URL = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';

    // ─── Google reCAPTCHA v3 Fallback Configuration ──────────────────────────────
    public const RECAPTCHA_SITE_KEY   = ''; // Optional fallback (env: RECAPTCHA_SITE_KEY)
    public const RECAPTCHA_SECRET_KEY = ''; // Optional fallback (env: RECAPTCHA_SECRET_KEY)
    public const RECAPTCHA_VERIFY_URL = 'https://www.google.com/recaptcha/api/siteverify';
    public const RECAPTCHA_MIN_SCORE  = 0.5;

    // ─── Security Timers & Form Token Secret ─────────────────────────────────────
    public const FORM_TOKEN_SECRET    = 'your_32_character_cryptographically_secure_secret_key';
    public const MIN_SUBMISSION_TIME_SECS = 3;    // Minimum seconds between form load and submit (anti-instant-bot)
    public const MAX_SUBMISSION_TIME_SECS = 86400;// Max 24 hours token validity

    // ─── Rate Limiting Policies (Sliding Window: [max_requests, window_seconds]) ─
    public const RATE_LIMITS = [
        'trial_request' => ['limit' => 5,  'window' => 900],   // 5 submissions per 15 minutes per IP
        'contact_form'  => ['limit' => 5,  'window' => 900],   // 5 submissions per 15 minutes per IP
        'login_attempt' => ['limit' => 5,  'window' => 900],   // 5 attempts per 15 minutes per IP
        'register'      => ['limit' => 3,  'window' => 3600],  // 3 registrations per hour per IP
        'chat_message'  => ['limit' => 120, 'window' => 60],   // 120 chat actions per minute per IP
        'visitor_ping'  => ['limit' => 60, 'window' => 60],    // 60 telemetry heartbeats per minute per IP
        'file_upload'   => ['limit' => 20, 'window' => 300],   // 20 file uploads per 5 minutes
        'api_default'   => ['limit' => 60, 'window' => 60],    // 60 API requests per minute
    ];

    // ─── Spam & SEO Abuse Scoring Thresholds ────────────────────────────────────
    public const SPAM_SCORE_THRESHOLD = 50; // Total risk score >= 50 triggers automatic rejection
    public const MAX_URLS_ALLOWED_IN_MESSAGE = 2; // Real estate clients rarely post > 2 external URLs in message

    // ─── High-Risk SEO Spam & Attack Keywords (Regex pattern matching) ──────────
    public const SPAM_KEYWORD_PATTERNS = [
        // Casino & Gambling
        '/\b(casino|slot88|sbobet|poker\s?online|judi\s?online|slot\s?gacor|pragmatic\s?play|betting|roulette|baccarat)\b/i',
        // Crypto, Forex & Financial Scams
        '/\b(crypto\s?doubler|bitcoin\s?investment|forex\s?signals|whatsapp\s?invest|binary\s?options|earn\s?\$[0-9]+(\s?per\s?day)?)\b/i',
        // Pharma & Adult
        '/\b(viagra|cialis|levitra|phentermine|adult\s?dating|porn|escort|cam\s?girl|sex\s?video|onlyfans\s?leak)\b/i',
        // SEO Link Farm & Backlink Pitch Bots
        '/\b(guest\s?post\s?outreach|da\s?90\s?backlink|increase\s?domain\s?rating|seo\s?ranking\s?service|high\s?da\s?pbn|pbn\s?links|rank\s?on\s?google\s?page\s?1|white\s?hat\s?seo\s?package)\b/i',
        // BBCode / HTML Injection in raw text
        '/(\[url=|<a\s+href=|<script|document\.cookie|javascript:|onerror=)/i'
    ];

    // ─── Disposable / Burner Email Provider Blocklist (Extensible) ─────────────
    public const DISPOSABLE_EMAIL_DOMAINS = [
        'mailinator.com', '10minutemail.com', 'tempmail.com', 'temp-mail.org', 'guerrillamail.com',
        'trashmail.com', 'yopmail.com', 'sharklasers.com', 'dispostable.com', 'getairmail.com',
        'throwawaymail.com', 'mohmal.com', 'fakeinbox.com', 'burnermail.io', 'mytemp.email',
        'inboxkitten.com', 'nada.ltd', 'crazymailing.com', 'dropmail.me', 'tempinbox.com',
        'fakemailgenerator.com', 'emailondeck.com', 'throwawayemail.com', 'trashmail.net',
        'generator.email', 'disposablemail.com', 'trashmail.me', 'tempm.com', 'tmpmail.net',
        'minuteinbox.com', 'tempail.com', 'luxusmail.com', 'guerrillamailblock.com', 'grr.la'
    ];

    // ─── IP Whitelist (Search Engines, Cloudflare, Office IPs) ──────────────────
    public const IP_WHITELIST = [
        '127.0.0.1',
        '::1'
    ];

    // ─── Helper method to read environment variable with fallback ──────────────
    public static function getEnv(string $key, string $default = ''): string
    {
        $val = getenv($key);
        if ($val !== false && $val !== '') {
            return (string)$val;
        }
        if (isset($_ENV[$key]) && $_ENV[$key] !== '') {
            return (string)$_ENV[$key];
        }
        if (isset($_SERVER[$key]) && $_SERVER[$key] !== '') {
            return (string)$_SERVER[$key];
        }
        return $default;
    }

    public static function getTurnstileSiteKey(): string
    {
        return self::getEnv('TURNSTILE_SITE_KEY', self::TURNSTILE_SITE_KEY);
    }

    public static function getTurnstileSecretKey(): string
    {
        return self::getEnv('TURNSTILE_SECRET_KEY', self::TURNSTILE_SECRET_KEY);
    }

    public static function isTurnstileConfigured(): bool
    {
        $secret = self::getTurnstileSecretKey();
        return !empty($secret) && !str_contains($secret, 'xxxxxx');
    }
}
