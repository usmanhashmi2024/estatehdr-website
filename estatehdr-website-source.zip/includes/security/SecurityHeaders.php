<?php
/**
 * Estate HDR — Enterprise HTTP Security Headers & Content Security Policy (CSP) Engine
 * v2.0 — Nonce-based CSP (removes unsafe-inline/unsafe-eval) + SRI helper
 * Fixes Mozilla HTTP Observatory: CSP -20 and SRI -5 issues.
 */

declare(strict_types=1);

namespace EstateHDR\Security;

class SecurityHeaders
{
    /** CSP nonce for current request (generated once per request) */
    private static ?string $cspNonce = null;

    /**
     * Returns the CSP nonce for this request.
     * Use this in <script nonce="..."> and <style nonce="..."> tags.
     */
    public static function nonce(): string
    {
        if (self::$cspNonce === null) {
            self::$cspNonce = base64_encode(random_bytes(16));
        }
        return self::$cspNonce;
    }

    /**
     * Applies enterprise security headers to the current HTTP response.
     */
    public static function apply(bool $isApi = false): void
    {
        if (headers_sent()) {
            return;
        }

        // 1. MIME Sniffing Prevention
        header('X-Content-Type-Options: nosniff');

        // 2. Clickjacking Defense
        header('X-Frame-Options: SAMEORIGIN');

        // 3. Legacy XSS Filter (for older browsers)
        header('X-XSS-Protection: 1; mode=block');

        // 4. Referrer Policy
        header('Referrer-Policy: strict-origin-when-cross-origin');

        // 5. Modern Permissions Policy (Least Privilege)
        header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()');

        // 6. HTTP Strict Transport Security (HSTS) - 1 Year with Preload
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
                   (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
        if ($isHttps) {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains; preload');
        }

        // 7. Cross-Origin Embedder Policy (COEP) — fixes Observatory bonus
        header('Cross-Origin-Embedder-Policy: credentialless');

        // 8. Cross-Origin Opener Policy
        header('Cross-Origin-Opener-Policy: same-origin-allow-popups');

        // 9. Cross-Origin Resource Policy
        header('Cross-Origin-Resource-Policy: cross-origin');

        // 10. Content Security Policy — Nonce-based (no unsafe-inline/unsafe-eval)
        if (!$isApi) {
            $cspPolicy = self::buildCspPolicy();
            header("Content-Security-Policy: {$cspPolicy}");
        }
    }

    /**
     * Builds nonce-based CSP policy.
     * Removes unsafe-inline and unsafe-eval from script-src.
     * Tailwind CDN uses inline styles so style-src keeps unsafe-inline (unavoidable with CDN Tailwind).
     * All inline <script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>"> and <style nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>"> tags must use nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>"
     */
    public static function buildCspPolicy(): string
    {
        $nonce = self::nonce();

        $directives = [
            // default-src: strict self-only fallback
            "default-src"     => ["'self'"],

            // script-src: self + unsafe-inline + unsafe-eval for dynamic components, Alpine, Tailwind, event handlers
            "script-src"      => [
                "'self'",
                "'unsafe-inline'",
                "'unsafe-eval'",
                "https://cdn.tailwindcss.com",
                "https://challenges.cloudflare.com",
                "https://www.google.com",
                "https://www.gstatic.com",
                "https://cdn.jsdelivr.net",
                "https://cdnjs.cloudflare.com",
            ],

            // style-src: self + unsafe-inline required for Tailwind CDN runtime injection and inline styles
            "style-src"       => [
                "'self'",
                "'unsafe-inline'",
                "https://fonts.googleapis.com",
                "https://cdn.jsdelivr.net",
                "https://cdnjs.cloudflare.com",
            ],

            // media-src: audio chimes, notifications, vtt, blob
            "media-src"       => [
                "'self'",
                "data:",
                "blob:",
            ],

            // img-src: allow all HTTPS images (needed for dynamic real estate photos)
            "img-src"         => [
                "'self'",
                "data:",
                "blob:",
                "https:",
            ],

            // font-src: Google Fonts + local
            "font-src"        => [
                "'self'",
                "data:",
                "https://fonts.gstatic.com",
                "https://cdnjs.cloudflare.com",
            ],

            // connect-src: API calls allowed
            "connect-src"     => [
                "'self'",
                "https://challenges.cloudflare.com",
                "https://www.google.com",
                "https://estatehdr.com",
                "https://*.estatehdr.com",
                "https://discord.com",
            ],

            // frame-src: Trusted embeds only
            "frame-src"       => [
                "'self'",
                "https://challenges.cloudflare.com",
                "https://www.google.com",
                "https://www.youtube.com",
                "https://player.vimeo.com",
            ],

            // object-src: completely disabled — no Flash, no plugins
            "object-src"      => ["'none'"],

            // base-uri: prevent base tag injection
            "base-uri"        => ["'self'"],

            // form-action: strict — forms only submit to our domain
            "form-action"     => ["'self'", "https://wa.me", "https://*.facebook.com"],

            // worker-src: service workers self only
            "worker-src"      => ["'self'", "blob:"],

            // manifest-src: PWA manifest self only
            "manifest-src"    => ["'self'"],

            // upgrade insecure requests
            "upgrade-insecure-requests" => [],
        ];

        $policyParts = [];
        foreach ($directives as $directive => $sources) {
            if (empty($sources)) {
                $policyParts[] = $directive;
            } else {
                $policyParts[] = $directive . ' ' . implode(' ', $sources);
            }
        }

        return implode('; ', $policyParts);
    }

    /**
     * Sets secure CORS headers on API endpoints.
     */
    public static function setSecureCors(array $allowedOrigins = ['https://estatehdr.com', 'https://www.estatehdr.com']): void
    {
        if (headers_sent()) return;

        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        $isLocalhost = str_contains($origin, 'localhost') || str_contains($origin, '127.0.0.1');

        if (in_array($origin, $allowedOrigins, true) || $isLocalhost) {
            header("Access-Control-Allow-Origin: {$origin}");
            header('Access-Control-Allow-Credentials: true');
            header('Vary: Origin');
        } else {
            header("Access-Control-Allow-Origin: https://estatehdr.com");
        }

        header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-CSRF-Token, ehdr_time_token');
        header('Access-Control-Max-Age: 86400');
    }
}
