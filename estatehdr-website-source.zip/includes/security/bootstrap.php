<?php
/**
 * Estate HDR — Security Engine Bootstrap & Procedural Helper Bridge
 * Loads all security subsystems and provides high-performance helper functions for views and controllers.
 */

declare(strict_types=1);

require_once __DIR__ . '/SecurityConfig.php';
require_once __DIR__ . '/SecurityLogger.php';
require_once __DIR__ . '/RateLimiter.php';
require_once __DIR__ . '/AntiBotProvider.php';
require_once __DIR__ . '/SpamDetector.php';
require_once __DIR__ . '/Validator.php';
require_once __DIR__ . '/FileUploadGuard.php';
require_once __DIR__ . '/SecurityHeaders.php';
require_once __DIR__ . '/SriRegistry.php';

use EstateHDR\Security\SecurityHeaders;
use EstateHDR\Security\SriRegistry;
use EstateHDR\Security\RateLimiter;
use EstateHDR\Security\AntiBotProvider;
use EstateHDR\Security\SpamDetector;
use EstateHDR\Security\Validator;
use EstateHDR\Security\FileUploadGuard;
use EstateHDR\Security\SecurityLogger;

/**
 * Procedural helper: Apply Enterprise Security & CSP Headers
 */
function ehdr_security_headers(bool $isApi = false): void
{
    SecurityHeaders::apply($isApi);
}

/**
 * Procedural helper: Enforce Rate Limiting
 */
function ehdr_rate_limit(string $action, bool $isJson = false): void
{
    RateLimiter::enforce($action, null, $isJson);
}

/**
 * Procedural helper: Render Invisible Honeypot & Anti-Bot Hidden Fields
 */
function ehdr_render_honeypot(): string
{
    return SpamDetector::renderHoneypotFields();
}

/**
 * Procedural helper: Render Cloudflare Turnstile Challenge Widget
 */
function ehdr_render_turnstile(string $action = 'lead_form', string $theme = 'dark'): string
{
    return AntiBotProvider::renderWidget($action, $theme);
}

/**
 * Procedural helper: Verify Anti-Bot & Honeypot & Spam Risk
 *
 * @param array $postData Form POST parameters
 * @param string $action Action name for rate limiting and Turnstile
 * @param bool $requireCloudLink Whether cloud_link is mandatory
 * @return array ['success' => bool, 'error' => ?string, 'sanitized' => array, 'score' => int]
 */
function ehdr_process_and_guard_lead(array $postData, string $action = 'trial_request', bool $requireCloudLink = true): array
{
    // 1. Rate Limiting Check
    $rateStatus = RateLimiter::check($action);
    if (!$rateStatus['allowed']) {
        return [
            'success'   => false,
            'error'     => 'Too many requests submitted. Please wait a few minutes and try again.',
            'sanitized' => [],
            'score'     => 100
        ];
    }

    // 2. Anti-Bot Turnstile / reCAPTCHA Verification
    $botResult = AntiBotProvider::verify($postData, $action);
    if (!$botResult['success']) {
        return [
            'success'   => false,
            'error'     => $botResult['error'] ?? 'Anti-bot verification failed. Please try again.',
            'sanitized' => [],
            'score'     => 100
        ];
    }

    // 3. Multi-Tier Spam & Honeypot Analysis
    $spamResult = SpamDetector::analyzeSubmission($postData);
    if ($spamResult['is_spam']) {
        return [
            'success'   => false,
            'error'     => 'Your submission could not be verified by our security filters. Please check your message or contact us via WhatsApp.',
            'sanitized' => [],
            'score'     => $spamResult['score']
        ];
    }

    // 4. Strict Schema Validation & Sanitization
    $valResult = Validator::validateLeadSubmission($postData, $requireCloudLink);
    if (!$valResult['valid']) {
        $firstError = reset($valResult['errors']);
        return [
            'success'   => false,
            'error'     => $firstError ?: 'Validation error. Please verify your input.',
            'sanitized' => $valResult['sanitized'],
            'score'     => 0
        ];
    }

    return [
        'success'   => true,
        'error'     => null,
        'sanitized' => $valResult['sanitized'],
        'score'     => $spamResult['score']
    ];
}
