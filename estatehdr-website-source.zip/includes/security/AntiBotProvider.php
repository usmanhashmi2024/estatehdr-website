<?php
/**
 * Estate HDR — Unified Anti-Bot Provider (Cloudflare Turnstile & Google reCAPTCHA v3)
 * Provides seamless server-side challenge verification, widget generation, and bot mitigation.
 */

declare(strict_types=1);

namespace EstateHDR\Security;

require_once __DIR__ . '/SecurityConfig.php';
require_once __DIR__ . '/SecurityLogger.php';

class AntiBotProvider
{
    /**
     * Verifies Turnstile or reCAPTCHA token from incoming POST payload.
     *
     * @param array $postData Form POST parameters
     * @param string|null $expectedAction e.g. 'trial_request', 'contact_form', 'login'
     * @return array ['success' => bool, 'score' => float, 'error' => ?string, 'provider' => string]
     */
    public static function verify(array $postData, ?string $expectedAction = null): array
    {
        $ip = SecurityLogger::getClientIp();

        // 1. Check Cloudflare Turnstile token
        $turnstileToken = $postData['cf-turnstile-response'] ?? ($postData['turnstile_token'] ?? '');
        if (!empty($turnstileToken)) {
            return self::verifyTurnstile($turnstileToken, $ip, $expectedAction);
        }

        // 2. Check Google reCAPTCHA v3 token (fallback)
        $recaptchaToken = $postData['g-recaptcha-response'] ?? ($postData['recaptcha_token'] ?? '');
        if (!empty($recaptchaToken)) {
            return self::verifyRecaptcha($recaptchaToken, $ip, $expectedAction);
        }

        // 3. If Turnstile is active in configuration but no token is provided
        if (SecurityConfig::isTurnstileConfigured()) {
            SecurityLogger::log('bot_missing_token', 'WARNING', 'Form submitted without required anti-bot challenge token.', [
                'action'    => $expectedAction,
                'client_ip' => $ip
            ]);
            return [
                'success'  => false,
                'score'    => 0.0,
                'error'    => 'Security verification required. Please complete the anti-bot challenge.',
                'provider' => 'turnstile'
            ];
        }

        // Safe pass in local/dev mode when keys are not yet configured in production env
        return [
            'success'  => true,
            'score'    => 1.0,
            'error'    => null,
            'provider' => 'bypass_dev'
        ];
    }

    /**
     * Verifies token with Cloudflare Turnstile API.
     */
    private static function verifyTurnstile(string $token, string $remoteIp, ?string $expectedAction = null): array
    {
        $secret = SecurityConfig::getTurnstileSecretKey();
        if (empty($secret) || str_contains($secret, 'xxxxxx')) {
            // Unconfigured or dummy key in testing environment
            return ['success' => true, 'score' => 1.0, 'error' => null, 'provider' => 'turnstile_test_pass'];
        }

        $postFields = http_build_query([
            'secret'   => $secret,
            'response' => $token,
            'remoteip' => $remoteIp
        ]);

        $response = self::executeHttpRequest(SecurityConfig::TURNSTILE_VERIFY_URL, $postFields);
        if ($response === null) {
            SecurityLogger::log('turnstile_timeout', 'WARNING', 'Turnstile verification endpoint timed out or failed to connect.');
            // Fail-open or fail-closed policy: allow if timeout to avoid blocking genuine paying clients
            return ['success' => true, 'score' => 0.8, 'error' => null, 'provider' => 'turnstile_failopen'];
        }

        $result = json_decode($response, true);
        if (!is_array($result) || empty($result['success'])) {
            $errorCodes = implode(', ', $result['error-codes'] ?? ['invalid_response']);
            SecurityLogger::log('turnstile_failed', 'ALERT', "Turnstile verification failed: {$errorCodes}", [
                'client_ip' => $remoteIp,
                'action'    => $expectedAction,
                'errors'    => $result['error-codes'] ?? []
            ]);
            return [
                'success'  => false,
                'score'    => 0.0,
                'error'    => 'Anti-bot verification failed. Please refresh and try again.',
                'provider' => 'turnstile'
            ];
        }

        // Verify action if supplied
        if ($expectedAction !== null && !empty($result['action']) && $result['action'] !== $expectedAction) {
            SecurityLogger::log('turnstile_action_mismatch', 'WARNING', "Turnstile action mismatch: expected {$expectedAction}, got {$result['action']}");
        }

        return [
            'success'  => true,
            'score'    => 1.0,
            'error'    => null,
            'provider' => 'turnstile'
        ];
    }

    /**
     * Verifies token with Google reCAPTCHA v3 API.
     */
    private static function verifyRecaptcha(string $token, string $remoteIp, ?string $expectedAction = null): array
    {
        $secret = SecurityConfig::getEnv('RECAPTCHA_SECRET_KEY', SecurityConfig::RECAPTCHA_SECRET_KEY);
        if (empty($secret)) {
            return ['success' => true, 'score' => 1.0, 'error' => null, 'provider' => 'recaptcha_unconfigured'];
        }

        $postFields = http_build_query([
            'secret'   => $secret,
            'response' => $token,
            'remoteip' => $remoteIp
        ]);

        $response = self::executeHttpRequest(SecurityConfig::RECAPTCHA_VERIFY_URL, $postFields);
        if ($response === null) {
            return ['success' => true, 'score' => 0.8, 'error' => null, 'provider' => 'recaptcha_failopen'];
        }

        $result = json_decode($response, true);
        $score = (float)($result['score'] ?? 0.0);
        $success = !empty($result['success']) && ($score >= SecurityConfig::RECAPTCHA_MIN_SCORE);

        if (!$success) {
            SecurityLogger::log('recaptcha_failed', 'ALERT', "reCAPTCHA score too low ({$score})", [
                'client_ip' => $remoteIp,
                'score'     => $score,
                'action'    => $expectedAction
            ]);
            return [
                'success'  => false,
                'score'    => $score,
                'error'    => 'Automated activity detected. Please try again.',
                'provider' => 'recaptcha_v3'
            ];
        }

        return [
            'success'  => true,
            'score'    => $score,
            'error'    => null,
            'provider' => 'recaptcha_v3'
        ];
    }

    /**
     * Robust HTTP client with 3-second timeout.
     */
    private static function executeHttpRequest(string $url, string $postData): ?string
    {
        if (function_exists('curl_init')) {
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL            => $url,
                CURLOPT_POST           => true,
                CURLOPT_POSTFIELDS     => $postData,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => 3,
                CURLOPT_CONNECTTIMEOUT => 2,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded']
            ]);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            return ($httpCode === 200 && is_string($response)) ? $response : null;
        }

        $context = stream_context_create([
            'http' => [
                'method'  => 'POST',
                'header'  => "Content-Type: application/x-www-form-urlencoded\r\nContent-Length: " . strlen($postData) . "\r\n",
                'content' => $postData,
                'timeout' => 3
            ]
        ]);
        $response = @file_get_contents($url, false, $context);
        return is_string($response) ? $response : null;
    }

    /**
     * Renders Cloudflare Turnstile widget HTML.
     */
    public static function renderWidget(string $action = 'lead_form', string $theme = 'dark'): string
    {
        $siteKey = SecurityConfig::getTurnstileSiteKey();
        if (empty($siteKey) || str_contains($siteKey, 'xxxxxx')) {
            // Render hidden token holder for dev/preview
            return '<!-- Anti-Bot Turnstile Widget (Configured) --><input type="hidden" name="cf-turnstile-response" value="ehdr_dev_token">';
        }

        $escapedKey = htmlspecialchars($siteKey, ENT_QUOTES, 'UTF-8');
        $escapedAction = htmlspecialchars($action, ENT_QUOTES, 'UTF-8');

        return <<<HTML
<div class="ehdr-turnstile-wrapper my-3 flex justify-center">
    <div class="cf-turnstile" data-sitekey="{$escapedKey}" data-action="{$escapedAction}" data-theme="{$theme}" data-size="flexible"></div>
</div>
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>
HTML;
    }
}
