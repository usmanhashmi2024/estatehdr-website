<?php
/**
 * Estate HDR — RAG Knowledge Brain & Human Escalation Gateway
 * PRD Section 8 & 19: Approved knowledge retrieval, objection handling, and automatic dossier compilation.
 */

require_once __DIR__ . '/pricing-engine.php';

class RagKnowledgeEngine {
    public const KNOWLEDGE_BASE = [
        'free_trial' => [
            'intent' => 'trial_inquiry',
            'keywords' => ['trial', 'sample', 'free', 'test', 'try', 'check quality'],
            'response' => "You can test our studio completely free! We offer <strong>3 Free Sample Edits</strong> with guaranteed 24-hour delivery and zero payment or credit card required.<br><br>Simply paste your Google Drive, Dropbox, or WeTransfer RAW bracket link right here in this chat, and our directors will deliver your finished high-res photos within 24 hours."
        ],
        'window_pulls' => [
            'intent' => 'window_technique',
            'keywords' => ['window', 'glare', 'blown', 'halo', 'sun', 'view'],
            'response' => "Window pulls are our core specialty! Instead of muddy automated blends, our retouchers perform 100% manual layer masking in Photoshop. The garden, pool, or mountain landscape view comes out 100% crisp, vibrant, and natural with zero dark edge halos."
        ],
        'white_balance' => [
            'intent' => 'color_cast',
            'keywords' => ['yellow', 'tungsten', 'color cast', 'white balance', 'orange', 'mixed light'],
            'response' => "Mixed indoor lighting (like warm 2700K tungsten bulbs clashing with 5500K daylight windows) can make walls look unpleasantly yellow or orange. We isolate ceilings and drywall to neutralize color casts into clean, architectural pure-white while preserving natural flooring and wood warmth."
        ],
        'turnaround_sla' => [
            'intent' => 'turnaround_sla',
            'keywords' => ['turnaround', 'time', 'how long', 'hour', 'fast', 'rush', 'urgent', 'deadline'],
            'response' => "Our production engine guarantees:<br><br>• <strong>Standard Turnaround:</strong> Strictly within <strong>24 Hours</strong> for all residential orders.<br>• <strong>12-Hour Urgent Rush:</strong> Available on demand for critical morning MLS deadlines.<br>• <strong>Unlimited Free Revisions:</strong> Processed in <strong>2 to 4 hours</strong>."
        ],
        'staging' => [
            'intent' => 'staging_info',
            'keywords' => ['staging', 'stage', 'virtual staging', 'furniture', 'empty room', 'vacant'],
            'response' => "Our 3D Virtual Staging (\$8.00/room) turns vacant rooms into high-end furnished designer spaces. We offer Modern Contemporary, Scandinavian, Luxury Glam, Transitional, and Farmhouse styles."
        ],
        'floorplans' => [
            'intent' => 'floorplan_info',
            'keywords' => ['floor plan', 'floorplan', 'blueprint', 'schematic', '2d', '3d floor'],
            'response' => "We create high-precision 2D Black &amp; White, 2D Color, and 3D Textured Floor Plans starting at \$12.00 per plan. All we need is a rough hand sketch with dimensions or a scan."
        ],
    ];

    /**
     * Match user query to verified RAG knowledge
     */
    public static function queryKnowledge(string $query): ?array {
        $lower = strtolower(trim($query));
        foreach (self::KNOWLEDGE_BASE as $key => $item) {
            foreach ($item['keywords'] as $kw) {
                if (str_contains($lower, $kw)) {
                    return $item;
                }
            }
        }
        return null;
    }

    /**
     * Check if request requires Human Escalation (PRD Section 19)
     */
    public static function checkEscalationTriggers(string $query, int $leadScore = 0): array {
        $lower = strtolower(trim($query));
        $shouldEscalate = false;
        $reason = '';

        if (str_contains($lower, 'refund') || str_contains($lower, 'angry') || str_contains($lower, 'bad service') || str_contains($lower, 'complaint')) {
            $shouldEscalate = true;
            $reason = 'Customer complaint / dissatisfaction detected';
        } elseif (str_contains($lower, 'enterprise') || str_contains($lower, '500 photos') || str_contains($lower, '1000 photos') || str_contains($lower, 'monthly contract')) {
            $shouldEscalate = true;
            $reason = 'High-Value Enterprise / Custom Bulk Lead';
        } elseif (str_contains($lower, 'human') || str_contains($lower, 'manager') || str_contains($lower, 'director') || str_contains($lower, 'speak with someone')) {
            $shouldEscalate = true;
            $reason = 'Direct human assistance requested by client';
        } elseif ($leadScore >= 80) {
            $shouldEscalate = true;
            $reason = 'Sales Priority threshold reached (Score: ' . $leadScore . ')';
        }

        return [
            'should_escalate' => $shouldEscalate,
            'reason'          => $reason
        ];
    }
}
