<?php
/**
 * Estate HDR — Autonomous RAG AI Live Chat & Pre-Chat Lead Gate Engine
 * 100% In-House • Zero External Scripts • 0ms Lag • Cross-Browser Safe
 * Pre-Chat Gate: Captures Verified Name & Email Before Chat Starts
 * Discord Dispatcher: Real-Time Live Lead Alerts & Transcript Dossiers
 */
$adminSettings = function_exists('getAdminSettings') ? getAdminSettings() : [];
$rawPhone = !empty($adminSettings['whatsapp']) ? $adminSettings['whatsapp'] : (defined('WHATSAPP_NUMBER') ? WHATSAPP_NUMBER : '+44 770 606 8176');
$cleanPhone = preg_replace('/[^0-9]/', '', $rawPhone);
if (empty($cleanPhone)) $cleanPhone = '447706068176';
?>

<!-- ── WHATSAPP FLOATING BUTTON (BOTTOM-LEFT) ─────────────────────── -->
<a href="https://wa.me/<?= $cleanPhone ?>?text=Hi%20Estate%20HDR%20Team%2C%20I%20have%20an%20inquiry%20about%20photo%20editing%20services." 
   target="_blank" rel="noopener noreferrer" 
   class="fixed bottom-6 left-6 z-50 flex items-center gap-2.5 px-4 py-3 bg-[#047857] hover:bg-[#065f46] text-white rounded-full shadow-[0_10px_30px_rgba(4,120,87,0.4)] transition-all hover:scale-105 group border border-emerald-500/40 font-sans"
   title="Chat with Estate HDR on WhatsApp">
  <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.182-.573c.978.58 1.911.928 3.145.929 3.178 0 5.767-2.587 5.768-5.766.001-3.187-2.575-5.771-5.764-5.771zm3.392 8.244c-.144.405-.837.774-1.17.824-.299.045-.677.063-1.092-.069-.252-.08-.575-.187-.988-.365-1.739-.751-2.874-2.502-2.961-2.617-.087-.116-.708-.94-.708-1.793s.448-1.273.607-1.446c.159-.173.346-.217.462-.217l.332.006c.106.005.249-.04.39.298.144.347.491 1.2.534 1.287.043.087.072.188.014.304-.058.116-.087.188-.173.289l-.26.304c-.087.086-.177.18-.076.354.101.174.449.741.964 1.201.662.591 1.221.774 1.394.86s.275.072.376-.043c.101-.116.433-.506.549-.68.116-.173.231-.145.39-.087s1.011.477 1.184.564.289.13.332.202c.043.072.043.419-.101.824z"/></svg>
  <span class="text-sm font-bold text-white hidden sm:inline-block tracking-wide">WhatsApp Support</span>
</a>

<style nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
/* ─── TAWK.TO-STYLE SCOPED CHAT BOX CSS (FIXED 380px WIDTH, 100% BULLETPROOF) ─── */
#ehdrChatWindow {
  position: fixed !important;
  bottom: 84px !important;
  right: 24px !important;
  left: auto !important;
  top: auto !important;
  width: 380px !important;
  max-width: calc(100vw - 32px) !important;
  height: 520px !important;
  max-height: calc(100vh - 120px) !important;
  border-radius: 18px !important;
  z-index: 999999 !important;
  background-color: #0D0D18 !important;
  border: 1px solid rgba(201, 168, 76, 0.45) !important;
  box-shadow: 0 16px 48px rgba(0, 0, 0, 0.85), 0 0 0 1px rgba(201, 168, 76, 0.18) !important;
  display: flex !important;
  flex-direction: column !important;
  overflow: hidden !important;
  box-sizing: border-box !important;
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
  transform: translateY(16px) scale(0.96) !important;
  opacity: 0 !important;
  pointer-events: none !important;
  transition: transform 0.25s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.25s cubic-bezier(0.16, 1, 0.3, 1) !important;
}

#ehdrChatWindow.ehdr-open {
  transform: translateY(0) scale(1) !important;
  opacity: 1 !important;
  pointer-events: auto !important;
}

#ehdrChatWindow.hidden {
  display: none !important;
}

@media (max-width: 480px) {
  #ehdrChatWindow {
    bottom: 76px !important;
    right: 12px !important;
    left: 12px !important;
    width: auto !important;
    max-width: none !important;
    height: calc(100vh - 96px) !important;
    max-height: none !important;
    border-radius: 14px !important;
  }
}

.ehdr-chip-btn {
  background: rgba(255, 255, 255, 0.05) !important;
  border: 1px solid rgba(255, 255, 255, 0.1) !important;
  color: #E5E7EB !important;
  padding: 5px 8px !important;
  border-radius: 8px !important;
  font-size: 10px !important;
  font-weight: 500 !important;
  text-align: left !important;
  cursor: pointer !important;
  transition: all 0.15s ease !important;
  display: flex !important;
  align-items: center !important;
  gap: 4px !important;
  white-space: nowrap !important;
  overflow: hidden !important;
  text-overflow: ellipsis !important;
}
.ehdr-chip-btn:hover {
  background: #C9A84C !important;
  color: #0A0A0F !important;
  border-color: #C9A84C !important;
}

.ehdr-form-input {
  width: 100% !important;
  background: #141424 !important;
  border: 1px solid rgba(201, 168, 76, 0.3) !important;
  border-radius: 9px !important;
  padding: 7px 11px !important;
  font-size: 12px !important;
  color: #FFFFFF !important;
  outline: none !important;
  box-sizing: border-box !important;
  transition: border-color 0.2s !important;
}
.ehdr-form-input:focus {
  border-color: #C9A84C !important;
  box-shadow: 0 0 0 2px rgba(201, 168, 76, 0.2) !important;
}

/* Scoped Message Bubbles */
.ehdr-msg-row {
  display: flex !important;
  align-items: flex-start !important;
  gap: 8px !important;
  width: 100% !important;
  box-sizing: border-box !important;
}
.ehdr-msg-row.user {
  justify-content: flex-end !important;
}
.ehdr-bubble-user {
  background: #C9A84C !important;
  color: #0A0A0F !important;
  font-weight: 600 !important;
  font-size: 12px !important;
  line-height: 1.5 !important;
  padding: 9px 13px !important;
  border-radius: 14px 14px 2px 14px !important;
  max-width: 82% !important;
  word-break: break-word !important;
  overflow-wrap: break-word !important;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3) !important;
  user-select: text !important;
}
.ehdr-bubble-agent {
  background: #141422 !important;
  border: 1px solid #242438 !important;
  color: #E5E7EB !important;
  font-size: 12px !important;
  line-height: 1.55 !important;
  padding: 9px 13px !important;
  border-radius: 14px 14px 14px 2px !important;
  max-width: 86% !important;
  word-break: break-word !important;
  overflow-wrap: break-word !important;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3) !important;
  user-select: text !important;
}
.ehdr-agent-avatar {
  width: 28px !important;
  height: 28px !important;
  border-radius: 8px !important;
  background: rgba(201, 168, 76, 0.15) !important;
  border: 1px solid rgba(201, 168, 76, 0.3) !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  font-size: 13px !important;
  flex-shrink: 0 !important;
}
.ehdr-typing-bubble {
  background: #141422 !important;
  border: 1px solid #242438 !important;
  padding: 8px 12px !important;
  border-radius: 14px 14px 14px 2px !important;
  display: flex !important;
  align-items: center !important;
  gap: 6px !important;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3) !important;
}
.ehdr-typing-dot {
  width: 6px !important;
  height: 6px !important;
  border-radius: 9999px !important;
  background: #C9A84C !important;
  animation: ehdrBounce 1.4s infinite ease-in-out both !important;
}
@keyframes ehdrBounce {
  0%, 80%, 100% { transform: scale(0); opacity: 0.4; }
  40% { transform: scale(1.0); opacity: 1; }
}
</style>

<!-- ── NATIVE 2-WAY RAG LIVE CHAT MODAL (TAWK.TO STYLE) ───────────── -->
<div id="ehdrChatWindow" class="hidden" 
     style="position: fixed; bottom: 84px; right: 24px; left: auto; top: auto; width: 380px; max-width: calc(100vw - 32px); height: 520px; max-height: calc(100vh - 120px); border-radius: 18px; z-index: 999999; background: #0D0D18; border: 1px solid rgba(201, 168, 76, 0.45); box-shadow: 0 16px 48px rgba(0,0,0,0.85); box-sizing: border-box; display: flex; flex-direction: column; overflow: hidden;">
  
  <!-- Chat Header (Fixed 54px) -->
  <div style="height: 54px; min-height: 54px; background: linear-gradient(90deg, #141424, #1B1B30); border-bottom: 1px solid rgba(201,168,76,0.25); display: flex; align-items: center; justify-content: space-between; padding: 0 14px; flex-shrink: 0; box-sizing: border-box;">
    <div style="display: flex; align-items: center; gap: 10px;">
      <div style="position: relative; width: 34px; height: 34px; border-radius: 10px; background: linear-gradient(135deg, #C9A84C, #F59E0B); display: flex; align-items: center; justify-content: center; font-size: 16px; flex-shrink: 0; box-shadow: 0 2px 8px rgba(0,0,0,0.3);">
        👩‍💼
        <span style="position: absolute; bottom: -2px; right: -2px; width: 9px; height: 9px; border-radius: 9999px; background: #10B981; border: 2px solid #0D0D18;"></span>
      </div>
      <div>
        <div style="font-weight: 700; color: #FFFFFF; font-size: 12px; display: flex; align-items: center; gap: 6px;">
          <span id="ehdrHeaderAgentName">Alice | Senior Director</span>
          <span style="background: rgba(16,185,129,0.2); color: #34D399; font-size: 8px; font-weight: 900; padding: 2px 5px; border-radius: 4px; text-transform: uppercase;">LIVE 24/7</span>
        </div>
        <div id="ehdrHeaderStatusLine" style="color: #9CA3AF; font-size: 10px; display: flex; align-items: center; gap: 4px; margin-top: 1px;">
          <span style="width: 5px; height: 5px; border-radius: 9999px; background: #10B981;"></span>
          <span id="ehdrActiveUserBadge">Online • Retouching Bay</span>
        </div>
      </div>
    </div>

    <div style="display: flex; align-items: center; gap: 6px;">
      <button type="button" onclick="dispatchTranscriptNow()" id="ehdrTranscriptBtn" class="hidden" style="background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1); color: #D1D5DB; font-size: 9px; font-weight: bold; padding: 3px 7px; border-radius: 6px; cursor: pointer;" title="Send Dossier">📋 Dossier</button>
      <button type="button" onclick="toggleEhdrChat()" style="width: 28px; height: 28px; border-radius: 9999px; background: rgba(255,255,255,0.08); border: none; color: #D1D5DB; font-size: 13px; font-weight: bold; cursor: pointer; display: flex; align-items: center; justify-content: center;" title="Minimize Chat" aria-label="Minimize Chat">✕</button>
    </div>
  </div>

  <!-- ── GATEWAY 1: PRE-CHAT LEAD CAPTURE GATE (SHOWN FIRST) ─────── -->
  <div id="ehdrPreChatGate" style="flex: 1; padding: 16px; display: flex; flex-direction: column; justify-content: space-between; overflow-y: auto; background: #0D0D18; box-sizing: border-box;">
    <div>
      <!-- Welcome Badge -->
      <div style="text-align: center; margin-bottom: 12px;">
        <div style="display: inline-flex; align-items: center; gap: 6px; padding: 3px 10px; border-radius: 9999px; background: rgba(201,168,76,0.15); color: #C9A84C; border: 1px solid rgba(201,168,76,0.3); font-size: 10px; font-weight: 800; text-transform: uppercase; margin-bottom: 6px;">
          <span>✨ Live Studio Consultation</span>
        </div>
        <h3 style="font-size: 14px; font-weight: 800; color: #FFFFFF; margin: 4px 0;">Start Your Live Consultation</h3>
        <p style="font-size: 11px; color: #9CA3AF; margin: 4px 0 0 0; line-height: 1.45;">
          Please introduce yourself below. Alice will answer your questions instantly and unlock your <strong style="color: #C9A84C;">3 Free Sample Edits</strong>!
        </p>
      </div>

      <!-- Pre-Chat Form -->
      <form id="ehdrPreChatForm" onsubmit="handlePreChatSubmit(event)" style="display: flex; flex-direction: column; gap: 10px;">
        <div>
          <label for="ehdrPreName" style="display: block; font-size: 10px; font-weight: 700; color: #D1D5DB; margin-bottom: 3px;">
            Full Name <span style="color: #C9A84C;">*</span>
          </label>
          <input type="text" id="ehdrPreName" required placeholder="e.g. David Miller" class="ehdr-form-input">
        </div>

        <div>
          <label for="ehdrPreEmail" style="display: block; font-size: 10px; font-weight: 700; color: #D1D5DB; margin-bottom: 3px;">
            Work / Studio Email <span style="color: #C9A84C;">*</span>
          </label>
          <input type="email" id="ehdrPreEmail" required placeholder="e.g. david@prestigemedia.com" class="ehdr-form-input">
        </div>

        <div>
          <label for="ehdrPrePhone" style="display: block; font-size: 10px; font-weight: 700; color: #D1D5DB; margin-bottom: 3px;">
            WhatsApp / Phone <span style="color: #6B7280; font-weight: 400;">(Optional for quote)</span>
          </label>
          <input type="tel" id="ehdrPrePhone" placeholder="e.g. +1 555 234 5678" class="ehdr-form-input">
        </div>

        <div>
          <label for="ehdrPreInterest" style="display: block; font-size: 10px; font-weight: 700; color: #D1D5DB; margin-bottom: 3px;">
            What can we help you with today?
          </label>
          <select id="ehdrPreInterest" class="ehdr-form-input" style="cursor: pointer;">
            <option value="HDR Photo Editing ($0.60 Promo)" selected>📸 HDR Photo Editing ($0.60 Promo Rate)</option>
            <option value="Claim 3 Free Sample Edits (Risk-Free)">🎁 Claim 3 Free Sample Edits (Risk-Free)</option>
            <option value="1 Free Day-to-Dusk Twilight Hero">🌅 1 Free Day-to-Dusk Hero Photo Perk</option>
            <option value="3D Virtual Staging ($8.00/room)">🛋️ 3D Virtual Staging ($8.00 / room)</option>
            <option value="2D/3D Floor Plans ($10-$25)">📐 2D &amp; 3D Floor Plans</option>
            <option value="High-Volume Studio &amp; Agency Partnership">🏢 Agency / High-Volume Partnership</option>
            <option value="General Question / Technical Support">💬 General Question / Technical Support</option>
          </select>
        </div>

        <div style="padding-top: 4px;">
          <button type="submit" id="ehdrPreSubmitBtn" 
                  style="width: 100%; height: 38px; border-radius: 9px; background: linear-gradient(135deg, #C9A84C 0%, #F59E0B 50%, #C9A84C 100%); color: #0A0A0F; font-weight: 800; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 15px rgba(201,168,76,0.35);">
            <span>Start Live Chat with Alice</span>
            <span>&rarr;</span>
          </button>
        </div>
      </form>
    </div>

    <div style="padding-top: 8px; border-top: 1px solid rgba(255,255,255,0.06); text-align: center;">
      <div style="display: flex; align-items: center; justify-content: center; gap: 4px; font-size: 9px; color: #6B7280;">
        <svg style="width: 12px; height: 12px; color: #10B981;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
        <span>100% Privacy Protected &middot; Zero Spam Guarantee</span>
      </div>
    </div>
  </div>

  <!-- ── GATEWAY 2: LIVE RAG CONVERSATION STREAM (AFTER UNLOCK) ───── -->
  <div id="ehdrChatStream" class="hidden" 
       style="flex: 1; min-height: 0; padding: 12px; overflow-y: auto; display: flex; flex-direction: column; gap: 10px; box-sizing: border-box; scrollbar-width: thin; scrollbar-color: rgba(201,168,76,0.3) #0D0D18;">
    <!-- Quick Prompt Chips -->
    <div id="ehdrQuickChipsContainer" style="padding-bottom: 8px; margin-bottom: 4px; border-bottom: 1px solid rgba(255,255,255,0.07); flex-shrink: 0;">
      <div style="font-size: 9px; color: #9CA3AF; font-weight: 700; text-transform: uppercase; margin-bottom: 6px; letter-spacing: 0.5px;">⚡ Quick Instant Answers:</div>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 5px;">
        <button type="button" onclick="sendQuickPrompt('promo_pricing')" class="ehdr-chip-btn">🔥 $0.60 Promo Pricing</button>
        <button type="button" onclick="sendQuickPrompt('free_dusk')" class="ehdr-chip-btn">🎁 1 Free Day-to-Dusk</button>
        <button type="button" onclick="sendQuickPrompt('free_trial')" class="ehdr-chip-btn">📸 3 Free Samples</button>
        <button type="button" onclick="sendQuickPrompt('turnaround')" class="ehdr-chip-btn">⏱️ 12–24h Turnaround</button>
        <button type="button" onclick="sendQuickPrompt('raw_support')" class="ehdr-chip-btn">📷 Camera RAW Support</button>
        <button type="button" onclick="sendQuickPrompt('revisions')" class="ehdr-chip-btn">🛡️ 100% Free Revisions</button>
      </div>
    </div>

    <!-- Messages Container -->
    <div id="ehdrMessagesList" style="display: flex; flex-direction: column; gap: 10px;"></div>
  </div>

  <!-- Input Footer (Fixed Docked Bottom) -->
  <div id="ehdrChatFooter" class="hidden" 
       style="background: #0E0E1A; border-top: 1px solid rgba(255,255,255,0.08); padding: 8px 12px; flex-shrink: 0; box-sizing: border-box;">
    <form id="ehdrChatForm" onsubmit="handleUserChatSubmit(event)" style="display: flex; gap: 6px; align-items: center; margin: 0;">
      <input type="text" id="ehdrChatInput" aria-label="Ask a question or share bracket link" oninput="emitTypingKeystroke(this.value)" placeholder="Ask Alice anything or paste cloud link..."
             style="flex: 1; height: 36px; background: #151526; border: 1px solid rgba(201,168,76,0.35); border-radius: 9px; padding: 0 11px; font-size: 12px; color: #FFFFFF; outline: none; box-sizing: border-box;" autocomplete="off">
      <button type="submit" id="ehdrChatSendBtn" aria-label="Send message"
              style="width: 36px; height: 36px; border-radius: 9px; background: #C9A84C; border: none; color: #0A0A0F; font-size: 13px; font-weight: bold; display: flex; align-items: center; justify-content: center; cursor: pointer; flex-shrink: 0; box-shadow: 0 2px 8px rgba(201,168,76,0.4);" title="Send">
        ➤
      </button>
    </form>
    <div style="display: flex; align-items: center; justify-content: space-between; padding-top: 6px; font-size: 9px; color: #9CA3AF;">
      <div style="display: flex; align-items: center; gap: 4px;">
        <span style="width: 5px; height: 5px; border-radius: 9999px; background: #C9A84C;"></span>
        <span id="ehdrIdentityPill">AI RAG Cognitive Brain Active</span>
      </div>
      <div style="display: flex; align-items: center; gap: 8px;">
        <button type="button" onclick="resetEhdrPreChat()" style="color: #9CA3AF; text-decoration: underline; background: none; border: none; cursor: pointer; font-size: 9px; padding: 0;">Switch User</button>
        <a href="https://wa.me/<?= $cleanPhone ?>" target="_blank" rel="noopener noreferrer" style="color: #34D399; text-decoration: none; font-weight: 600;">WhatsApp ↗</a>
      </div>
    </div>
  </div>

</div>

<!-- Floating Launcher Button (Fixed Bottom-Right Dock) -->
<button id="ehdrChatToggleBtn" onclick="toggleEhdrChat()" aria-label="Open Estate HDR 24/7 Live Assistant"
        style="position: fixed; bottom: 24px; right: 24px; z-index: 999998; height: 46px; border-radius: 9999px; padding: 0 18px; background: linear-gradient(135deg, #C9A84C 0%, #F59E0B 50%, #C9A84C 100%); color: #0A0A0F; display: flex; align-items: center; gap: 8px; font-weight: 800; font-size: 13px; border: 1px solid rgba(255,255,255,0.4); box-shadow: 0 8px 30px rgba(201,168,76,0.45); cursor: pointer; transition: transform 0.2s, box-shadow 0.2s;"
        title="Open Estate HDR Live Assistant">
  <span style="font-size: 18px;">💬</span>
  <span style="font-weight: 800; letter-spacing: 0.2px;">24/7 Live Assistant</span>
  <span style="width: 8px; height: 8px; border-radius: 9999px; background: #047857;"></span>
</button>

<!-- ── REAL-TIME CHAT & RAG CLIENT SCRIPT ─────────────────────────── -->
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
function getEhdrVid() {
  try {
    let vid = localStorage.getItem('ehdr_vid');
    if (!vid) {
      vid = 'V-' + Math.random().toString(36).substring(2, 10).toUpperCase();
      localStorage.setItem('ehdr_vid', vid);
    }
    return vid;
  } catch (e) {
    if (!window._ehdrMemVid) {
      window._ehdrMemVid = 'V-' + Math.random().toString(36).substring(2, 10).toUpperCase();
    }
    return window._ehdrMemVid;
  }
}

function getStoredVisitor() {
  try {
    return {
      name: localStorage.getItem('ehdr_visitor_name') || '',
      email: localStorage.getItem('ehdr_visitor_email') || '',
      phone: localStorage.getItem('ehdr_visitor_phone') || '',
      registered: localStorage.getItem('ehdr_lead_registered') === '1'
    };
  } catch (e) {
    return { name: '', email: '', phone: '', registered: false };
  }
}

let typingTimeout = null;

function emitTypingKeystroke(val) {
  clearTimeout(typingTimeout);
  typingTimeout = setTimeout(() => {
    fetch('/api/chat-live.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'typing_update',
        visitor_id: getEhdrVid(),
        text: val
      })
    }).catch(() => {});
  }, 300);
}

function updateChatUiState() {
  const visitor = getStoredVisitor();
  const gate = document.getElementById('ehdrPreChatGate');
  const stream = document.getElementById('ehdrChatStream');
  const footer = document.getElementById('ehdrChatFooter');
  const transcriptBtn = document.getElementById('ehdrTranscriptBtn');
  const identityPill = document.getElementById('ehdrIdentityPill');
  const userBadge = document.getElementById('ehdrActiveUserBadge');

  if (visitor.registered && visitor.email) {
    if (gate) gate.classList.add('hidden');
    if (stream) stream.classList.remove('hidden');
    if (footer) footer.classList.remove('hidden');
    if (transcriptBtn) transcriptBtn.classList.remove('hidden');

    const firstName = visitor.name.split(' ')[0] || 'Client';
    if (identityPill) identityPill.innerText = 'Connected as ' + firstName;
    if (userBadge) userBadge.innerText = 'Consulting with ' + firstName;
  } else {
    if (gate) gate.classList.remove('hidden');
    if (stream) stream.classList.add('hidden');
    if (footer) footer.classList.add('hidden');
    if (transcriptBtn) transcriptBtn.classList.add('hidden');
    if (userBadge) userBadge.innerText = 'Online • Architectural Retouching Bay';
  }
}

function appendBubble(sender, text, agentName = 'Alice | Senior Retouching Director') {
  const list = document.getElementById('ehdrMessagesList');
  const stream = document.getElementById('ehdrChatStream');
  if (!list || !stream) return;

  const isUser = (sender === 'user');
  const msgDiv = document.createElement('div');
  msgDiv.className = isUser ? 'ehdr-msg-row user' : 'ehdr-msg-row';

  if (isUser) {
    msgDiv.innerHTML = `
      <div class="ehdr-bubble-user">
        ${text}
      </div>
    `;
  } else {
    msgDiv.innerHTML = `
      <div class="ehdr-agent-avatar">
        👩‍💼
      </div>
      <div class="ehdr-bubble-agent">
        <div style="font-size: 10px; font-weight: bold; color: #C9A84C; margin-bottom: 3px;">● ${agentName}</div>
        <div style="font-size: 12px; line-height: 1.5; color: #E5E7EB;">${text}</div>
      </div>
    `;
  }

  list.appendChild(msgDiv);
  stream.scrollTop = stream.scrollHeight;
}

function handlePreChatSubmit(e) {
  e.preventDefault();
  const nameInp = document.getElementById('ehdrPreName');
  const emailInp = document.getElementById('ehdrPreEmail');
  const phoneInp = document.getElementById('ehdrPrePhone');
  const interestInp = document.getElementById('ehdrPreInterest');
  const btn = document.getElementById('ehdrPreSubmitBtn');

  const name = (nameInp ? nameInp.value : '').trim();
  const email = (emailInp ? emailInp.value : '').trim();
  const phone = (phoneInp ? phoneInp.value : '').trim();
  const interest = interestInp ? interestInp.value : 'HDR Photo Editing';

  if (!name || !email) {
    alert('Please enter your Name and Email to start the chat.');
    return;
  }

  if (btn) {
    btn.disabled = true;
    btn.innerHTML = 'Connecting with Alice... <span class="animate-spin inline-block">⏳</span>';
  }

  fetch('/api/chat-live.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'prechat_register',
      visitor_id: getEhdrVid(),
      name: name,
      email: email,
      phone: phone,
      interest: interest,
      page_url: window.location.pathname + window.location.search
    })
  })
  .then(res => res.json())
  .then(data => {
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = 'Start Live Chat with Alice &rarr;';
    }

    if (data.success) {
      try {
        localStorage.setItem('ehdr_lead_registered', '1');
        localStorage.setItem('ehdr_visitor_name', name);
        localStorage.setItem('ehdr_visitor_email', email);
        localStorage.setItem('ehdr_visitor_phone', phone);
      } catch (err) {}

      updateChatUiState();

      // Render welcome messages
      const list = document.getElementById('ehdrMessagesList');
      if (list) list.innerHTML = '';

      if (data.messages && data.messages.length > 0) {
        data.messages.forEach(m => {
          appendBubble(m.sender, m.text, m.agent_name || 'Alice | Senior Retouching Director');
        });
      } else if (data.welcome_message) {
        appendBubble('agent', data.welcome_message);
      }

      const inp = document.getElementById('ehdrChatInput');
      if (inp) inp.focus();
    } else {
      alert(data.error || 'Failed to initialize session. Please try again.');
    }
  })
  .catch(err => {
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = 'Start Live Chat with Alice &rarr;';
    }
    alert('Network error. Please try again.');
  });
}

function resetEhdrPreChat() {
  if (confirm('Switch user profile and start a new consultation?')) {
    try {
      localStorage.removeItem('ehdr_lead_registered');
      localStorage.removeItem('ehdr_visitor_name');
      localStorage.removeItem('ehdr_visitor_email');
      localStorage.removeItem('ehdr_visitor_phone');
    } catch (e) {}
    updateChatUiState();
  }
}

function toggleEhdrChat() {
  const win = document.getElementById('ehdrChatWindow');
  if (!win) return;

  const isClosed = win.classList.contains('hidden') || !win.classList.contains('ehdr-open');
  if (isClosed) {
    win.classList.remove('hidden');
    void win.offsetWidth;
    win.classList.add('ehdr-open');

    updateChatUiState();

    const visitor = getStoredVisitor();
    if (visitor.registered) {
      loadVisitorHistory();
      const inp = document.getElementById('ehdrChatInput');
      if (inp) inp.focus();
    } else {
      const pName = document.getElementById('ehdrPreName');
      if (pName) pName.focus();
    }
  } else {
    win.classList.remove('ehdr-open');
    setTimeout(() => {
      win.classList.add('hidden');
    }, 260);
  }
}

function loadVisitorHistory() {
  fetch('/api/chat-live.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'get_session',
      visitor_id: getEhdrVid()
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success && data.messages && data.messages.length > 0) {
      const list = document.getElementById('ehdrMessagesList');
      if (list) {
        list.innerHTML = '';
        data.messages.forEach(m => {
          appendBubble(m.sender, m.text, m.agent_name || 'Alice | Senior Retouching Director');
        });
      }
    }
  })
  .catch(() => {});
}

function sendQuickPrompt(key) {
  const prompts = {
    promo_pricing: "Can you break down your $0.60 promotional HDR pricing and volume tiers?",
    free_dusk: "How does the 1 Free Day-to-Dusk Hero Photo perk work for every property?",
    free_trial: "How do I claim my 3 Free Sample Edits on my RAW brackets?",
    turnaround: "What are your turnaround times for standard and rush orders?",
    raw_support: "What camera RAW bracket formats and exposure steps do you support?",
    revisions: "What is your policy on amendments and revisions if I need adjustments?"
  };

  const text = prompts[key];
  if (!text) return;
  dispatchUserMessage(text);
}

function handleUserChatSubmit(e) {
  e.preventDefault();
  const inp = document.getElementById('ehdrChatInput');
  const text = (inp ? inp.value : '').trim();
  if (!text) return;

  inp.value = '';
  emitTypingKeystroke('');
  dispatchUserMessage(text);
}

function dispatchUserMessage(text) {
  const visitorId = getEhdrVid();
  const visitor = getStoredVisitor();
  const stream = document.getElementById('ehdrChatStream');
  const list = document.getElementById('ehdrMessagesList');

  // 1. Immediately render User message bubble
  appendBubble('user', text);

  // 2. Render Alice typing indicator
  const typingDiv = document.createElement('div');
  typingDiv.id = 'ehdrTypingIndicator';
  typingDiv.className = 'ehdr-msg-row';
  typingDiv.innerHTML = `
    <div class="ehdr-agent-avatar">
      👩‍💼
    </div>
    <div class="ehdr-typing-bubble">
      <span class="ehdr-typing-dot" style="animation-delay: -0.32s;"></span>
      <span class="ehdr-typing-dot" style="animation-delay: -0.16s;"></span>
      <span class="ehdr-typing-dot"></span>
      <span style="margin-left: 6px; font-size: 11px; font-weight: 500; color: #C9A84C;">Alice is checking knowledge base...</span>
    </div>
  `;
  if (list) list.appendChild(typingDiv);
  if (stream) stream.scrollTop = stream.scrollHeight;

  // 3. Post to API
  fetch('/api/chat-live.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'visitor_send',
      visitor_id: visitorId,
      visitor_name: visitor.name,
      visitor_email: visitor.email,
      visitor_phone: visitor.phone,
      message: text,
      page_url: window.location.pathname + window.location.search
    })
  })
  .then(res => {
    if (!res.ok) {
      throw new Error('HTTP ' + res.status);
    }
    return res.json();
  })
  .then(data => {
    setTimeout(() => {
      const indicator = document.getElementById('ehdrTypingIndicator');
      if (indicator) indicator.remove();

      if (data.success && data.latest_reply) {
        appendBubble('agent', data.latest_reply, data.agent_name || 'Alice | Senior Retouching Director');
      } else if (data.error) {
        appendBubble('agent', data.error, data.agent_name || 'Alice | Senior Retouching Director');
      }
    }, data.typing_delay_ms || 600);
  })
  .catch(err => {
    console.warn('EHDR Chat connection status:', err);
    setTimeout(() => {
      const indicator = document.getElementById('ehdrTypingIndicator');
      if (indicator) indicator.remove();
      appendBubble('agent', "I'm right here with you! You can email your questions or RAW bracket links directly to <a href=\"mailto:order@estatehdr.com\" class=\"text-gold font-bold underline\">order@estatehdr.com</a>, or message our production bay instantly on WhatsApp: <a href=\"https://wa.me/<?= $cleanPhone ?>\" target=\"_blank\" class=\"text-emerald-400 font-bold underline\">+44 770 606 8176</a>.", 'Alice | Senior Retouching Director');
    }, 600);
  });
}

function dispatchTranscriptNow() {
  const visitorId = getEhdrVid();
  const btn = document.getElementById('ehdrTranscriptBtn');
  if (btn) btn.innerHTML = 'Sending...';

  fetch('/api/chat-live.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'end_chat',
      visitor_id: visitorId
    })
  })
  .then(res => res.json())
  .then(data => {
    if (btn) {
      btn.innerHTML = '✅ Sent!';
      setTimeout(() => { btn.innerHTML = '📋 Dossier'; }, 3000);
    }
    alert('Complete conversation dossier and email details dispatched to our lead studio team on Discord!');
  })
  .catch(() => {
    if (btn) btn.innerHTML = '📋 Dossier';
  });
}

// Background Visitor Telemetry Ping
(function() {
  let startTime = Date.now();
  function ping() {
    if (document.hidden) return;
    const timeSpent = Math.floor((Date.now() - startTime) / 1000);
    const visitor = getStoredVisitor();
    const payload = JSON.stringify({
      visitor_id: getEhdrVid(),
      visitor_name: visitor.name,
      visitor_email: visitor.email,
      page_url: window.location.pathname + window.location.search,
      page_title: document.title,
      referrer: document.referrer || 'Direct Visit',
      time_spent: timeSpent
    });

    if (navigator.sendBeacon) {
      navigator.sendBeacon('/api/visitor-ping.php', payload);
    } else {
      fetch('/api/visitor-ping.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: payload,
        keepalive: true
      }).catch(() => {});
    }
  }

  setTimeout(ping, 1000);
  setInterval(ping, 60000);
})();
</script>

<?php if (empty($GLOBALS['_ehdr_animation_scripts_loaded'])): $GLOBALS['_ehdr_animation_scripts_loaded'] = true; ?>
<!-- Estate HDR Master 120Hz Animation & Smooth Momentum Scroll Engine -->
<script src="/assets/js/vendor/gsap.min.js" defer></script>
<script src="/assets/js/vendor/ScrollTrigger.min.js" defer></script>
<script src="/assets/js/vendor/lenis.min.js" defer></script>
<script src="/assets/js/animations.js?v=<?= file_exists(ROOT_PATH . '/assets/js/animations.js') ? filemtime(ROOT_PATH . '/assets/js/animations.js') : time() ?>" defer></script>
<?php endif; ?>
