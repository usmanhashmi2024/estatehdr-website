<?php
/**
 * Estate HDR — Enterprise Database & Persistence Layer
 * Provides PDO connection pooling, prepared statements, migration checks, and seamless hybrid fallback.
 */

require_once __DIR__ . '/config.php';

class Database {
    private static ?PDO $pdo = null;
    private static bool $isDbAvailable = false;
    private static bool $attemptedConnection = false;

    public static function getConnection(): ?PDO {
        if (self::$attemptedConnection) {
            return self::$pdo;
        }

        self::$attemptedConnection = true;

        // If MySQL is not configured, run in high-speed flat-file JSON mode without timeout lag
        if (!defined('DB_NAME') && !getenv('DB_NAME')) {
            self::$isDbAvailable = false;
            self::$pdo = null;
            return null;
        }

        $host = defined('DB_HOST') ? DB_HOST : (getenv('DB_HOST') ?: '127.0.0.1');
        $db   = defined('DB_NAME') ? DB_NAME : (getenv('DB_NAME') ?: 'estatehdr_db');
        $user = defined('DB_USER') ? DB_USER : (getenv('DB_USER') ?: 'estatehdr_user');
        $pass = defined('DB_PASS') ? DB_PASS : (getenv('DB_PASS') ?: '');
        $port = defined('DB_PORT') ? DB_PORT : (getenv('DB_PORT') ?: 3306);

        try {
            $dsn = "mysql:host={$host};port={$port};dbname={$db};charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::ATTR_TIMEOUT            => 2,
            ];

            self::$pdo = new PDO($dsn, $user, $pass, $options);
            self::$isDbAvailable = true;
            self::ensureSchemaMigrated();
        } catch (Throwable $e) {
            self::$isDbAvailable = false;
            self::$pdo = null;
        }

        return self::$pdo;
    }

    public static function isConnected(): bool {
        self::getConnection();
        return self::$isDbAvailable;
    }

    private static function ensureSchemaMigrated(): void {
        if (!self::$pdo) return;
        try {
            $test = self::$pdo->query("SHOW TABLES LIKE 'visitors'")->fetch();
            if (!$test) {
                $sqlPath = __DIR__ . '/schema.sql';
                if (file_exists($sqlPath)) {
                    $sql = file_get_contents($sqlPath);
                    self::$pdo->exec($sql);
                }
            }
        } catch (Throwable $e) {
            error_log('Database schema check note: ' . $e->getMessage());
        }
    }
}

// ─── AUDIT LOGGING HELPER ─────────────────────────────────────────────
function logEnterpriseAudit($actorType, $actorId, $actorEmail, $action, $targetType = null, $targetId = null, $details = []) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    $now = date('Y-m-d H:i:s');

    $pdo = Database::getConnection();
    if ($pdo) {
        try {
            $stmt = $pdo->prepare("INSERT INTO audit_logs (actor_type, actor_id, actor_email, action, target_type, target_id, ip_address, details_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$actorType, $actorId, $actorEmail, $action, $targetType, $targetId, $ip, json_encode($details), $now]);
            return;
        } catch (Throwable $e) {}
    }

    // JSON fallback
    $dataPath = defined('DATA_PATH') ? DATA_PATH : (dirname(__DIR__) . '/data/');
    $auditFile = $dataPath . 'audit_logs.json';
    $logs = file_exists($auditFile) ? (json_decode(file_get_contents($auditFile), true) ?: []) : [];
    $logs[] = [
        'id'          => 'AUD-' . bin2hex(random_bytes(4)),
        'actor_type'  => $actorType,
        'actor_id'    => $actorId,
        'actor_email' => $actorEmail,
        'action'      => $action,
        'target_type' => $targetType,
        'target_id'   => $targetId,
        'ip_address'  => $ip,
        'details'     => $details,
        'created_at'  => $now
    ];
    if (count($logs) > 500) array_shift($logs);
    if (function_exists('atomicWriteJson')) atomicWriteJson($auditFile, $logs);
}
