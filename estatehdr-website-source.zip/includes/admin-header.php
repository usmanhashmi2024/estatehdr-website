<?php
/**
 * Estate HDR — Master Admin Header Component (SaaS Locked Single-Line Layout)
 * Dynamically adapts tabs based on role: Photo Editor, Team Lead, Supervisor, Manager, HR, SEO Manager, Owner
 */
$adminCurrentPage = basename($_SERVER['PHP_SELF'], '.php');
$currentAdmin     = currentAdminUser();
$adminRoles       = getAdminRoles();

$isOwner          = in_array('owner', $adminRoles) || in_array('super_admin', $adminRoles);
$isManagerOnly    = (in_array('manager', $adminRoles) || in_array('production_manager', $adminRoles)) && !$isOwner;
$isSupervisorOnly = in_array('supervisor', $adminRoles) && !$isManagerOnly && !$isOwner;
$isTeamLeadOnly   = in_array('team_lead', $adminRoles) && !$isSupervisorOnly && !$isManagerOnly && !$isOwner;
$isPhotoEditor    = (in_array('photo_editor', $adminRoles) || in_array('editor', $adminRoles)) && !$isManagerOnly && !$isOwner && !$isSupervisorOnly && !$isTeamLeadOnly;
$isHR             = in_array('hr', $adminRoles) && !$isManagerOnly && !$isOwner;
$isSeoOnly        = in_array('seo_manager', $adminRoles) && !$isOwner && !$isManagerOnly;

// Role label determination
$displayRole = 'Staff';
if ($isOwner) $displayRole = 'CEO / Owner';
elseif (in_array('manager', $adminRoles)) $displayRole = 'Production Manager';
elseif ($isSupervisorOnly) $displayRole = 'Quality & Operations Supervisor';
elseif ($isTeamLeadOnly) $displayRole = 'Production Team Lead';
elseif ($isPhotoEditor) $displayRole = 'Photo Editor';
elseif ($isHR) $displayRole = 'HR Officer';
elseif ($isSeoOnly) $displayRole = 'SEO Manager';

require_once __DIR__ . '/services/ClientChatService.php';
$adminUnreadClientChats = class_exists('ClientChatService') ? ClientChatService::getTotalAdminUnreadCount() : 0;
$adminPendingAmendmentsCount = function_exists('getAllAmendmentOrders') ? count(getAllAmendmentOrders()) : 0;

// Clean dynamic user name & initials
$rawAdminName = $currentAdmin['name'] ?? ($currentAdmin['full_name'] ?? ($currentAdmin['username'] ?? 'Staff'));
$adminDisplayName = trim(preg_replace('/\s*\(.*?\)/', '', $rawAdminName));
if (empty($adminDisplayName)) $adminDisplayName = 'Staff';

$nameWords = preg_split('/\s+/', $adminDisplayName);
if (count($nameWords) >= 2) {
    $adminInitials = strtoupper(substr($nameWords[0], 0, 1) . substr($nameWords[1], 0, 1));
} else {
    $adminInitials = strtoupper(substr($adminDisplayName, 0, 2));
}
?>
<style>
  /* ── Master Admin Animated Dropdown Engine ──────────────── */
  .admin-dropdown-menu {
    opacity: 0;
    visibility: hidden;
    transform: translateY(-8px) scale(0.96);
    transition: opacity 0.22s cubic-bezier(0.16, 1, 0.3, 1),
                transform 0.22s cubic-bezier(0.16, 1, 0.3, 1),
                visibility 0.22s;
    pointer-events: none;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.95), 0 0 0 1px rgba(201, 168, 76, 0.28);
  }
  .admin-dropdown-group:hover .admin-dropdown-menu,
  .admin-dropdown-group:focus-within .admin-dropdown-menu,
  .admin-dropdown-group.is-open .admin-dropdown-menu {
    opacity: 1;
    visibility: visible;
    transform: translateY(0) scale(1);
    pointer-events: auto;
  }
  .admin-dropdown-group:hover .admin-dropdown-arrow,
  .admin-dropdown-group:focus-within .admin-dropdown-arrow,
  .admin-dropdown-group.is-open .admin-dropdown-arrow {
    transform: rotate(180deg);
    color: #C9A84C;
  }
  .admin-nav-item {
    transition: all 0.16s ease;
  }
  .admin-nav-item:hover {
    background: #181926;
    color: #FFFFFF;
    transform: translateX(4px);
  }
  .admin-nav-item.is-active {
    background: rgba(201, 168, 76, 0.15);
    border-left: 3px solid #C9A84C;
    color: #C9A84C;
    font-weight: 800;
  }
</style>
<!-- ── TOP CONTACT & STATUS BAR ──────────────────────────────── -->
<div class="no-print relative z-[999] border-b border-[#1E1E2E]/90 bg-[#07070B] text-sm text-gray-300 py-2 px-6 sm:px-10">
  <div class="max-w-[1850px] mx-auto flex items-center justify-between gap-4">
    <div class="flex items-center gap-6">
      <span class="flex items-center gap-2">
        <span class="text-gold text-base">✉️</span> <span class="font-mono text-gray-200 font-bold">info@estatehdr.com</span>
      </span>
      <span class="flex items-center gap-2">
        <span class="text-gold text-base">📞</span> <span class="font-mono text-gray-200 font-bold">+44 770 606 8176</span>
      </span>
      <a href="<?= FACEBOOK_LINK ?>" target="_blank" rel="noopener noreferrer" class="hidden sm:flex items-center gap-1.5 text-xs text-gray-300 hover:text-blue-400 transition-colors font-medium" title="Estate HDR on Facebook">
        <svg class="w-3.5 h-3.5 fill-current text-blue-400 shrink-0" width="14" height="14" style="width:14px;height:14px;max-width:14px;max-height:14px;" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
        <span>facebook.com/estatehdr1 ↗</span>
      </a>
    </div>

    <div class="flex items-center gap-5">
      <!-- Admin Role Badge -->
      <div class="px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-mono font-black text-xs shadow-sm uppercase">
        Role: <span class="text-emerald-300 font-black"><?= $displayRole ?></span>
      </div>

      <!-- Real-Time Notification Bell Dropdown -->
      <div class="relative z-[1000]" id="adminNotifBellWrapper">
        <button type="button" onclick="toggleNotifDropdown()" id="btnNotifBell" class="relative p-2 rounded-xl bg-dark-card border border-dark-border hover:border-gold text-gray-200 hover:text-gold transition-all flex items-center gap-1.5 text-xs font-bold" title="Activity Notifications & Alerts">
          <span class="text-base leading-none">🔔</span>
          <span id="unreadNotifBadge" class="hidden px-1.5 py-0.5 rounded-full bg-red-500 text-white font-mono text-[10px] font-black animate-pulse leading-none">0</span>
        </button>

        <!-- Dropdown Card -->
        <div id="notifDropdownPanel" class="hidden absolute right-0 top-full mt-2 w-80 sm:w-96 rounded-2xl bg-[#111118] border border-gold/40 shadow-2xl overflow-hidden text-xs" style="z-index: 99999 !important; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.9), 0 0 0 1px rgba(201, 168, 76, 0.35);">
          <div class="p-3.5 bg-[#161622] border-b border-dark-border flex items-center justify-between">
            <div class="font-black text-white flex items-center gap-1.5">
              <span>⚡</span> <span>Live Activity &amp; Alerts</span>
            </div>
            <div class="flex items-center gap-2">
              <button type="button" onclick="requestDesktopNotificationPerm()" class="text-[10px] text-blue-400 hover:underline" title="Enable Windows/Desktop popup notifications">Enable Push</button>
              <span class="text-gray-600">•</span>
              <button type="button" onclick="markAllNotificationsRead()" class="text-[10px] text-gold hover:underline">Mark Read</button>
            </div>
          </div>
          <div id="notifListFeed" class="max-h-80 overflow-y-auto divide-y divide-dark-border p-1 space-y-1">
            <div class="p-4 text-center text-gray-500 text-xs">Connecting to live alert stream...</div>
          </div>
          <div class="p-2.5 bg-[#0D0D14] border-t border-dark-border flex items-center justify-between text-[11px]">
            <button type="button" onclick="testNotificationAlert()" class="text-gray-400 hover:text-white font-medium">🔔 Test Chime</button>
            <button type="button" onclick="clearAllNotifications()" class="text-red-400/80 hover:text-red-400 font-medium">Clear All</button>
          </div>
        </div>
      </div>

      

      <!-- User Badge & Sign Out -->
      <div class="flex items-center gap-2.5">
        <a href="/admin/profile.php" class="w-8 h-8 rounded-full bg-gold text-dark flex items-center justify-center font-black text-xs shadow-sm hover:ring-2 hover:ring-gold transition-all" title="My Profile (<?= htmlspecialchars($adminDisplayName) ?>)">
          <?= htmlspecialchars($adminInitials) ?>
        </a>
        <a href="/admin/profile.php" class="font-bold text-white hover:text-gold text-sm truncate max-w-[200px]" title="<?= htmlspecialchars($adminDisplayName) ?>">
          <?= htmlspecialchars($adminDisplayName) ?>
        </a>
      </div>

      <a href="/admin/logout.php" class="text-gray-400 hover:text-red-400 text-xs transition-colors font-bold uppercase tracking-wider">Sign Out</a>
    </div>
  </div>
</div>

<!-- ── MAIN NAVBAR (EXECUTIVE ANIMATED DROPDOWNS) ──────────────────── -->
<header class="bg-[#0B0C12] border-b border-[#1E1E2E] py-3 px-6 sm:px-10 sticky top-0 z-50 backdrop-blur-md">
  <div class="max-w-[1850px] mx-auto flex items-center justify-between gap-4">
    
    <!-- Left: Logo + Dropdown Navigation -->
    <div class="flex items-center gap-6 lg:gap-8 flex-1 min-w-0">
      <!-- Brand Logo -->
      <a href="/admin/" class="flex items-center py-1 flex-shrink-0 group">
        <img src="/assets/images/logo.png" alt="Estate HDR" class="h-14 sm:h-16 w-auto object-contain max-h-[64px] transition-transform group-hover:scale-105" onerror="this.outerHTML='<span class=\'font-bold text-white text-2xl tracking-tight\'>Estate<span class=\'text-gold\'>HDR</span></span>'">
      </a>

      <!-- Desktop Navigation with Animated Dropdowns (ZERO scrolling / ZERO arrow clicking) -->
      <nav class="hidden md:flex items-center flex-wrap gap-1.5 lg:gap-2 text-xs font-black uppercase tracking-wider">
        
        <?php if ($isPhotoEditor): ?>
          <!-- ─── PHOTO EDITOR TABS (Direct links, no scroll needed) ─── -->
          <a href="/admin/editor-dashboard.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= in_array($adminCurrentPage, ['editor-dashboard', 'editor-order']) ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            🎨 My Assigned Jobs
          </a>
          <a href="/admin/roles-sop.php?tab=editor" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $adminCurrentPage === 'roles-sop' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            📖 My SOP
          </a>
          <a href="/admin/profile.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $adminCurrentPage === 'profile' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            👤 My Profile
          </a>

        <?php elseif ($isTeamLeadOnly): ?>
          <!-- ─── TEAM LEAD TABS ─── -->
          <a href="/admin/teamlead-dashboard.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $adminCurrentPage === 'teamlead-dashboard' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            🛡️ Team Lead QA Hub
          </a>
          <a href="/admin/amendments.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all inline-flex items-center gap-1.5 <?= $adminCurrentPage === 'amendments' ? 'bg-gold text-dark font-black shadow-glow' : 'text-amber-400 hover:text-amber-300 hover:bg-[#161622]' ?>">
            <span>✏️ Amendments</span>
            <?php if ($adminPendingAmendmentsCount > 0): ?>
              <span class="px-1.5 py-0.5 rounded-full bg-amber-500 text-black font-mono text-[10px] font-black animate-pulse leading-none"><?= $adminPendingAmendmentsCount ?></span>
            <?php endif; ?>
          </a>
          <a href="/admin/roles-sop.php?tab=teamlead" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $adminCurrentPage === 'roles-sop' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            📖 Team Lead SOP
          </a>
          <a href="/admin/profile.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $adminCurrentPage === 'profile' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            👤 My Profile
          </a>

        <?php elseif ($isSupervisorOnly): ?>
          <!-- ─── SUPERVISOR TABS ─── -->
          <?php $supView = trim($_GET['view'] ?? ''); ?>
          <a href="/admin/supervisor-dashboard.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= ($adminCurrentPage === 'supervisor-dashboard' && empty($supView)) ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            📋 Daily Properties
          </a>
          <a href="/admin/amendments.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all inline-flex items-center gap-1.5 <?= $adminCurrentPage === 'amendments' ? 'bg-gold text-dark font-black shadow-glow' : 'text-amber-400 hover:text-amber-300 hover:bg-[#161622]' ?>">
            <span>✏️ Amendments</span>
            <?php if ($adminPendingAmendmentsCount > 0): ?>
              <span class="px-1.5 py-0.5 rounded-full bg-amber-500 text-black font-mono text-[10px] font-black animate-pulse leading-none"><?= $adminPendingAmendmentsCount ?></span>
            <?php endif; ?>
          </a>
          <a href="/admin/supervisor-dashboard.php?view=teamleads" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= ($adminCurrentPage === 'supervisor-dashboard' && $supView === 'teamleads') ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            🛡️ Team Leads
          </a>
          <a href="/admin/supervisor-dashboard.php?view=editors" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= ($adminCurrentPage === 'supervisor-dashboard' && $supView === 'editors') ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            🎨 Editors
          </a>
          <a href="/admin/roles-sop.php?tab=supervisor" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $adminCurrentPage === 'roles-sop' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            📖 SOP
          </a>
          <a href="/admin/profile.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $adminCurrentPage === 'profile' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            👤 Profile
          </a>

        <?php elseif ($isHR && !$isOwner && !$isManagerOnly): ?>
          <!-- ─── HR TABS ─── -->
          <?php $hrView = trim($_GET['view'] ?? ''); ?>
          <a href="/admin/hr-dashboard.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= ($adminCurrentPage === 'hr-dashboard' && $hrView !== 'attendance') ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            👥 Staff Profiles
          </a>
          <a href="/admin/hr-dashboard.php?view=attendance" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= ($adminCurrentPage === 'hr-dashboard' && $hrView === 'attendance') ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            📅 Daily Attendance
          </a>
          <a href="/admin/hr-documents.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= in_array($adminCurrentPage, ['hr-documents', 'hr-document']) ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            📄 HR Documents &amp; Salary Hub
          </a>
          <a href="/admin/roles-sop.php?tab=hr" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $adminCurrentPage === 'roles-sop' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            📖 HR SOP
          </a>
          <a href="/admin/profile.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $adminCurrentPage === 'profile' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            👤 Profile
          </a>

        <?php elseif ($isSeoOnly): ?>
          <!-- ─── SEO MANAGER TABS ─── -->
          <a href="/admin/pages.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= in_array($adminCurrentPage, ['pages', 'page-edit']) ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            🌐 Pages
          </a>
          <a href="/admin/posts.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= in_array($adminCurrentPage, ['posts', 'post-edit']) ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            📝 Blog Posts
          </a>
          <a href="/admin/categories.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $adminCurrentPage === 'categories' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            🏷️ Categories
          </a>
          <a href="/admin/seo-sitemap.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $adminCurrentPage === 'seo-sitemap' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            ⚙️ SEO Settings
          </a>
          <a href="/admin/roles-sop.php?tab=seo" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $adminCurrentPage === 'roles-sop' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            📖 SEO SOP
          </a>
          <a href="/admin/profile.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $adminCurrentPage === 'profile' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            👤 Profile
          </a>

        <?php elseif ($isManagerOnly): ?>
          <!-- ─── PRODUCTION MANAGER DROPDOWNS ─── -->
          <?php 
            $isProdActive = in_array($adminCurrentPage, ['orders', 'index', 'amendments', 'supervisor-dashboard', 'teamlead-dashboard', 'manager-dashboard']);
            $isCrmActive = in_array($adminCurrentPage, ['clients', 'client-new', 'client-edit', 'email-crm', 'client-chats', 'live-visitors', 'ai-brain']);
          ?>
          <!-- Production Dropdown -->
          <div class="relative admin-dropdown-group" id="mgrProdDropdown">
            <button type="button" onclick="toggleAdminDropdown('mgrProdDropdown')" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all inline-flex items-center gap-1.5 <?= $isProdActive ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
              <span>📋 Production</span>
              <?php if ($adminPendingAmendmentsCount > 0): ?>
                <span class="px-1.5 py-0.5 rounded-full bg-amber-500 text-black font-mono text-[10px] font-black animate-pulse leading-none"><?= $adminPendingAmendmentsCount ?></span>
              <?php endif; ?>
              <span class="admin-dropdown-arrow text-[10px] transition-transform duration-200">▾</span>
            </button>
            <div class="admin-dropdown-menu absolute left-0 top-full mt-1.5 w-64 rounded-2xl bg-[#0E0F17]/95 backdrop-blur-xl border border-gold/30 p-2 space-y-1 z-50">
              <a href="/admin/orders.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= in_array($adminCurrentPage, ['orders', 'index']) ? 'is-active' : '' ?>">
                <span>📋 Orders &amp; Delivery</span>
              </a>
              <a href="/admin/amendments.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-amber-300 hover:text-white font-bold <?= $adminCurrentPage === 'amendments' ? 'is-active' : '' ?>">
                <span>✏️ Amendments Queue</span>
                <?php if ($adminPendingAmendmentsCount > 0): ?>
                  <span class="px-1.5 py-0.5 rounded-full bg-amber-500 text-black font-mono text-[10px] font-black"><?= $adminPendingAmendmentsCount ?></span>
                <?php endif; ?>
              </a>
              <a href="/admin/supervisor-dashboard.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= $adminCurrentPage === 'supervisor-dashboard' ? 'is-active' : '' ?>">
                <span>🔍 Supervisor Monitor</span>
              </a>
              <a href="/admin/teamlead-dashboard.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= $adminCurrentPage === 'teamlead-dashboard' ? 'is-active' : '' ?>">
                <span>🛡️ Team Lead QA Hub</span>
              </a>
              <a href="/admin/manager-dashboard.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= $adminCurrentPage === 'manager-dashboard' ? 'is-active' : '' ?>">
                <span>📈 Turnaround Analytics</span>
              </a>
            </div>
          </div>

          <!-- CRM & Communications Dropdown -->
          <div class="relative admin-dropdown-group" id="mgrCrmDropdown">
            <button type="button" onclick="toggleAdminDropdown('mgrCrmDropdown')" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all inline-flex items-center gap-1.5 <?= $isCrmActive ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
              <span>💼 CRM &amp; Clients</span>
              <?php if ($adminUnreadClientChats > 0): ?>
                <span class="px-1.5 py-0.5 rounded-full bg-red-500 text-white font-mono text-[10px] font-black animate-pulse leading-none"><?= $adminUnreadClientChats ?></span>
              <?php endif; ?>
              <span class="admin-dropdown-arrow text-[10px] transition-transform duration-200">▾</span>
            </button>
            <div class="admin-dropdown-menu absolute left-0 top-full mt-1.5 w-64 rounded-2xl bg-[#0E0F17]/95 backdrop-blur-xl border border-gold/30 p-2 space-y-1 z-50">
              <a href="/admin/clients.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= in_array($adminCurrentPage, ['clients', 'client-new', 'client-edit']) ? 'is-active' : '' ?>">
                <span>💼 Clients Directory</span>
              </a>
              <a href="/admin/email-crm.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gold hover:text-white font-bold <?= $adminCurrentPage === 'email-crm' ? 'is-active' : '' ?>">
                <span>📧 Email CRM &amp; Verifier</span>
                <span class="text-[9px] px-1.5 py-0.2 rounded-full bg-gold/20 text-gold font-mono uppercase font-black">AI</span>
              </a>
              <a href="/admin/client-chats.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-blue-400 hover:text-white font-bold <?= $adminCurrentPage === 'client-chats' ? 'is-active' : '' ?>">
                <span>💬 Client Live Chats</span>
                <?php if ($adminUnreadClientChats > 0): ?>
                  <span class="px-1.5 py-0.5 rounded-full bg-red-500 text-white font-mono text-[10px] font-black"><?= $adminUnreadClientChats ?></span>
                <?php endif; ?>
              </a>
              <a href="/admin/live-visitors.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-emerald-400 hover:text-white font-bold <?= $adminCurrentPage === 'live-visitors' ? 'is-active' : '' ?>">
                <span>🟢 Live Website Visitors</span>
              </a>
            </div>
          </div>

          <a href="/admin/users.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $adminCurrentPage === 'users' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            👔 Staff
          </a>
          <a href="/admin/roles-sop.php?tab=manager" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $adminCurrentPage === 'roles-sop' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            📖 SOP
          </a>
          <a href="/admin/profile.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $adminCurrentPage === 'profile' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
            👤 Profile
          </a>

        <?php else: ?>
          <!-- ─── CEO / OWNER EXECUTIVE ANIMATED DROPDOWNS (All 20+ features organized into 4 menus) ─── -->
          <?php 
            $isProdActive = in_array($adminCurrentPage, ['orders', 'index', 'amendments', 'supervisor-dashboard', 'teamlead-dashboard', 'editor-dashboard', 'editor-order', 'manager-dashboard']);
            $isCrmActive = in_array($adminCurrentPage, ['clients', 'client-new', 'client-edit', 'email-crm', 'crm', 'client-chats', 'live-visitors', 'ai-brain']);
            $isOpsActive = in_array($adminCurrentPage, ['users', 'hr-dashboard', 'hr-documents', 'hr-document', 'ledger']);
            $isCmsActive = in_array($adminCurrentPage, ['pages', 'page-edit', 'posts', 'post-edit', 'categories', 'seo-sitemap', 'integrations', 'mail-test', 'roles-sop']);
          ?>

          <!-- Direct Link: Mission Control -->
          <a href="/admin/command-center.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $adminCurrentPage === 'command-center' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gold hover:text-white hover:bg-[#161622] border border-gold/40' ?>">
            ⚡ Mission Control
          </a>

          <!-- Dropdown 1: Production ▾ -->
          <div class="relative admin-dropdown-group" id="ownerProdDropdown">
            <button type="button" onclick="toggleAdminDropdown('ownerProdDropdown')" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all inline-flex items-center gap-1.5 <?= $isProdActive ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
              <span>📋 Production</span>
              <?php if ($adminPendingAmendmentsCount > 0): ?>
                <span class="px-1.5 py-0.5 rounded-full bg-amber-500 text-black font-mono text-[10px] font-black animate-pulse leading-none"><?= $adminPendingAmendmentsCount ?></span>
              <?php endif; ?>
              <span class="admin-dropdown-arrow text-[10px] transition-transform duration-200">▾</span>
            </button>
            <div class="admin-dropdown-menu absolute left-0 top-full mt-1.5 w-64 rounded-2xl bg-[#0E0F17]/95 backdrop-blur-xl border border-gold/30 p-2 space-y-1 z-50">
              <a href="/admin/orders.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= in_array($adminCurrentPage, ['orders', 'index']) ? 'is-active' : '' ?>">
                <span>📋 Orders &amp; Delivery</span>
              </a>
              <a href="/admin/amendments.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-amber-300 hover:text-white font-bold <?= $adminCurrentPage === 'amendments' ? 'is-active' : '' ?>">
                <span>✏️ Amendments Queue</span>
                <?php if ($adminPendingAmendmentsCount > 0): ?>
                  <span class="px-1.5 py-0.5 rounded-full bg-amber-500 text-black font-mono text-[10px] font-black"><?= $adminPendingAmendmentsCount ?></span>
                <?php endif; ?>
              </a>
              <a href="/admin/supervisor-dashboard.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= $adminCurrentPage === 'supervisor-dashboard' ? 'is-active' : '' ?>">
                <span>🔍 Supervisor Monitor</span>
              </a>
              <a href="/admin/teamlead-dashboard.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= $adminCurrentPage === 'teamlead-dashboard' ? 'is-active' : '' ?>">
                <span>🛡️ Team Lead QA Hub</span>
              </a>
              <a href="/admin/editor-dashboard.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= in_array($adminCurrentPage, ['editor-dashboard', 'editor-order']) ? 'is-active' : '' ?>">
                <span>🎨 Photo Editor Workspace</span>
              </a>
              <a href="/admin/manager-dashboard.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= $adminCurrentPage === 'manager-dashboard' ? 'is-active' : '' ?>">
                <span>📈 Turnaround Analytics</span>
              </a>
            </div>
          </div>

          <!-- Dropdown 2: CRM & Clients ▾ -->
          <div class="relative admin-dropdown-group" id="ownerCrmDropdown">
            <button type="button" onclick="toggleAdminDropdown('ownerCrmDropdown')" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all inline-flex items-center gap-1.5 <?= $isCrmActive ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
              <span>💼 CRM &amp; Clients</span>
              <?php if ($adminUnreadClientChats > 0): ?>
                <span class="px-1.5 py-0.5 rounded-full bg-red-500 text-white font-mono text-[10px] font-black animate-pulse leading-none"><?= $adminUnreadClientChats ?></span>
              <?php endif; ?>
              <span class="admin-dropdown-arrow text-[10px] transition-transform duration-200">▾</span>
            </button>
            <div class="admin-dropdown-menu absolute left-0 top-full mt-1.5 w-72 rounded-2xl bg-[#0E0F17]/95 backdrop-blur-xl border border-gold/30 p-2 space-y-1 z-50">
              <a href="/admin/email-crm.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gold hover:text-white font-bold <?= $adminCurrentPage === 'email-crm' ? 'is-active' : '' ?>">
                <span>📧 Email CRM &amp; Verifier</span>
                <span class="text-[9px] px-1.5 py-0.2 rounded-full bg-gold/20 text-gold font-mono uppercase font-black">AI Powered</span>
              </a>
              <a href="/admin/crm.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= $adminCurrentPage === 'crm' ? 'is-active' : '' ?>">
                <span>🎯 Sales CRM Pipeline</span>
              </a>
              <a href="/admin/clients.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= in_array($adminCurrentPage, ['clients', 'client-new', 'client-edit']) ? 'is-active' : '' ?>">
                <span>💼 Clients Directory</span>
              </a>
              <a href="/admin/client-chats.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-blue-400 hover:text-white font-bold <?= $adminCurrentPage === 'client-chats' ? 'is-active' : '' ?>">
                <span>💬 Client Live Chats</span>
                <?php if ($adminUnreadClientChats > 0): ?>
                  <span class="px-1.5 py-0.5 rounded-full bg-red-500 text-white font-mono text-[10px] font-black"><?= $adminUnreadClientChats ?></span>
                <?php endif; ?>
              </a>
              <a href="/admin/live-visitors.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-emerald-400 hover:text-white font-bold <?= $adminCurrentPage === 'live-visitors' ? 'is-active' : '' ?>">
                <span>🟢 Live Visitors &amp; Web Chat</span>
              </a>
              <a href="/admin/ai-brain.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-purple-400 hover:text-white font-bold <?= $adminCurrentPage === 'ai-brain' ? 'is-active' : '' ?>">
                <span>🧠 AI Brain &amp; Live Chat</span>
                <span class="text-[9px] px-1.5 py-0.2 rounded-full bg-purple-500/20 text-purple-300 font-mono uppercase font-black">RAG AI</span>
              </a>
            </div>
          </div>

          <!-- Dropdown 3: Operations & HR ▾ -->
          <div class="relative admin-dropdown-group" id="ownerOpsDropdown">
            <button type="button" onclick="toggleAdminDropdown('ownerOpsDropdown')" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all inline-flex items-center gap-1.5 <?= $isOpsActive ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
              <span>👔 Operations &amp; HR</span>
              <span class="admin-dropdown-arrow text-[10px] transition-transform duration-200">▾</span>
            </button>
            <div class="admin-dropdown-menu absolute left-0 top-full mt-1.5 w-64 rounded-2xl bg-[#0E0F17]/95 backdrop-blur-xl border border-gold/30 p-2 space-y-1 z-50">
              <a href="/admin/users.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= $adminCurrentPage === 'users' ? 'is-active' : '' ?>">
                <span>👔 Staff &amp; Role Access</span>
              </a>
              <a href="/admin/hr-dashboard.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= ($adminCurrentPage === 'hr-dashboard' && empty($_GET['view'])) ? 'is-active' : '' ?>">
                <span>👥 HR Staff Profiles</span>
              </a>
              <a href="/admin/hr-dashboard.php?view=attendance" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= ($adminCurrentPage === 'hr-dashboard' && ($_GET['view'] ?? '') === 'attendance') ? 'is-active' : '' ?>">
                <span>📅 Daily Attendance</span>
              </a>
              <a href="/admin/hr-documents.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= in_array($adminCurrentPage, ['hr-documents', 'hr-document']) ? 'is-active' : '' ?>">
                <span>📄 HR Documents &amp; Salary</span>
              </a>
              <a href="/admin/ledger.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= $adminCurrentPage === 'ledger' ? 'is-active' : '' ?>">
                <span>💳 Financial Ledger</span>
              </a>
            </div>
          </div>

          <!-- Dropdown 4: CMS & Platform ▾ -->
          <div class="relative admin-dropdown-group" id="ownerCmsDropdown">
            <button type="button" onclick="toggleAdminDropdown('ownerCmsDropdown')" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all inline-flex items-center gap-1.5 <?= $isCmsActive ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
              <span>⚙️ CMS &amp; Platform</span>
              <span class="admin-dropdown-arrow text-[10px] transition-transform duration-200">▾</span>
            </button>
            <div class="admin-dropdown-menu absolute right-0 sm:left-0 top-full mt-1.5 w-64 rounded-2xl bg-[#0E0F17]/95 backdrop-blur-xl border border-gold/30 p-2 space-y-1 z-50">
              <a href="/admin/pages.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= in_array($adminCurrentPage, ['pages', 'page-edit']) ? 'is-active' : '' ?>">
                <span>🌐 Static Pages</span>
              </a>
              <a href="/admin/posts.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= in_array($adminCurrentPage, ['posts', 'post-edit']) ? 'is-active' : '' ?>">
                <span>📝 Blog Articles CMS</span>
              </a>
              <a href="/admin/categories.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= $adminCurrentPage === 'categories' ? 'is-active' : '' ?>">
                <span>🏷️ Categories &amp; Tags</span>
              </a>
              <a href="/admin/seo-sitemap.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= $adminCurrentPage === 'seo-sitemap' ? 'is-active' : '' ?>">
                <span>⚙️ SEO &amp; Sitemaps</span>
              </a>
              <a href="/admin/integrations.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= $adminCurrentPage === 'integrations' ? 'is-active' : '' ?>">
                <span>🔌 API Integrations</span>
              </a>
              <a href="/admin/mail-test.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gold hover:text-white font-bold <?= $adminCurrentPage === 'mail-test' ? 'is-active' : '' ?>">
                <span>✉️ SMTP Diagnostics</span>
              </a>
              <a href="/admin/roles-sop.php" class="admin-nav-item flex items-center justify-between px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white font-bold <?= $adminCurrentPage === 'roles-sop' ? 'is-active' : '' ?>">
                <span>📖 Roles &amp; SOP Library</span>
              </a>
            </div>
          </div>
        <?php endif; ?>

      </nav>
    </div>

    <!-- Right: Live Site Link + Mobile Menu Toggle -->
    <div class="flex items-center gap-3 shrink-0">
      <a href="/" target="_blank" class="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#161622] hover:bg-gold hover:text-dark text-gold font-black border border-gold/40 transition-all text-xs shadow-sm">
        <span>🌐</span> <span>Site ↗</span>
      </a>

      <!-- Mobile Hamburger Button -->
      <button type="button" onclick="toggleAdminMobileMenu()" class="md:hidden p-2.5 rounded-xl bg-[#161622] border border-gold/40 text-gold hover:bg-gold hover:text-dark transition-all flex items-center justify-center text-sm font-black" title="Toggle Navigation Menu">
        <span>☰</span>
      </button>
    </div>

  </div>

  <!-- ── MOBILE SLIDE-DOWN DRAWER ──────────────────────────────────── -->
  <div id="adminMobileDrawer" class="hidden md:hidden border-t border-[#1E1E2E] mt-3 pt-3 bg-[#0B0C12] space-y-2 text-xs font-bold">
    <div class="grid grid-cols-2 gap-2 p-2">
      <a href="/admin/" class="p-2.5 rounded-xl bg-dark-card border border-dark-border text-center text-white hover:border-gold">⚡ Command</a>
      <a href="/admin/orders.php" class="p-2.5 rounded-xl bg-dark-card border border-dark-border text-center text-white hover:border-gold">📋 Orders</a>
      <a href="/admin/amendments.php" class="p-2.5 rounded-xl bg-dark-card border border-dark-border text-center text-amber-300 hover:border-gold">✏️ Amendments (<?= $adminPendingAmendmentsCount ?>)</a>
      <a href="/admin/email-crm.php" class="p-2.5 rounded-xl bg-gold/10 border border-gold/40 text-center text-gold font-black">📧 Email CRM</a>
      <a href="/admin/clients.php" class="p-2.5 rounded-xl bg-dark-card border border-dark-border text-center text-white hover:border-gold">💼 Clients</a>
      <a href="/admin/client-chats.php" class="p-2.5 rounded-xl bg-dark-card border border-dark-border text-center text-blue-400 hover:border-gold">💬 Chats (<?= $adminUnreadClientChats ?>)</a>
      <a href="/admin/users.php" class="p-2.5 rounded-xl bg-dark-card border border-dark-border text-center text-white hover:border-gold">👔 Staff</a>
      <a href="/admin/manager-dashboard.php" class="p-2.5 rounded-xl bg-dark-card border border-dark-border text-center text-white hover:border-gold">📈 Analytics</a>
      <a href="/admin/hr-dashboard.php" class="p-2.5 rounded-xl bg-dark-card border border-dark-border text-center text-white hover:border-gold">👥 HR Hub</a>
      <a href="/admin/seo-sitemap.php" class="p-2.5 rounded-xl bg-dark-card border border-dark-border text-center text-white hover:border-gold">⚙️ SEO &amp; CMS</a>
    </div>
  </div>
</header>
<script src="/assets/js/table-sorter.js" defer></script>
<script src="/assets/js/custom-dialogs.js"></script>

<!-- ── REAL-TIME ADMIN NOTIFICATION & AUDIO CHIME ENGINE ───────────── -->
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
let lastKnownNotifCount = 0;
let hasPlayedInitialChime = false;
let audioContextInstance = null;

function getAudioContext() {
  if (!audioContextInstance) {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (AudioCtx) audioContextInstance = new AudioCtx();
  }
  if (audioContextInstance && audioContextInstance.state === 'suspended') {
    audioContextInstance.resume();
  }
  return audioContextInstance;
}

// Synthesized Dual-Tone Web Audio Chime (A5 880Hz & E6 1318.51Hz)
function playNotificationChime() {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const t = ctx.currentTime;
    
    // Note 1: A5 (880 Hz)
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(880, t);
    gain1.gain.setValueAtTime(0.001, t);
    gain1.gain.exponentialRampToValueAtTime(0.25, t + 0.04);
    gain1.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(t);
    osc1.stop(t + 0.35);

    // Note 2: E6 (1318.51 Hz) - High harmony ping
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(1318.51, t + 0.12);
    gain2.gain.setValueAtTime(0.001, t + 0.12);
    gain2.gain.exponentialRampToValueAtTime(0.22, t + 0.16);
    gain2.gain.exponentialRampToValueAtTime(0.001, t + 0.55);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(t + 0.12);
    osc2.stop(t + 0.55);
  } catch (err) {
    console.warn('Audio chime playback deferred:', err);
  }
}

// Request Browser Desktop Push Notification Permission
function requestDesktopNotificationPerm() {
  if (!('Notification' in window)) {
    alert('This browser does not support desktop notifications.');
    return;
  }
  Notification.requestPermission().then(permission => {
    if (permission === 'granted') {
      new Notification('Estate HDR Command Center', {
        body: '🟢 Desktop push alerts are now active for new orders and clients!',
        icon: '/assets/images/favicon.png'
      });
      if (window.EstateDialog) EstateDialog.toast('Desktop notifications enabled!', 'success');
    }
  });
}

function showDesktopNotification(title, body, url = '/admin/orders.php') {
  if ('Notification' in window && Notification.permission === 'granted') {
    const notif = new Notification(title, {
      body: body,
      icon: '/assets/images/favicon.png',
      badge: '/assets/images/favicon.png'
    });
    notif.onclick = function() {
      window.focus();
      if (url) window.location.href = url;
    };
  }
}

function toggleNotifDropdown() {
  const panel = document.getElementById('notifDropdownPanel');
  panel.classList.toggle('hidden');
}

// Close dropdown on outside click
document.addEventListener('click', function(e) {
  const wrapper = document.getElementById('adminNotifBellWrapper');
  const panel = document.getElementById('notifDropdownPanel');
  if (wrapper && panel && !wrapper.contains(e.target)) {
    panel.classList.add('hidden');
  }
});

function renderNotificationFeed(list) {
  const feed = document.getElementById('notifListFeed');
  if (!feed) return;

  if (!list || list.length === 0) {
    feed.innerHTML = '<div class="p-6 text-center text-gray-500 text-xs">No notifications yet. All clear!</div>';
    return;
  }

  feed.innerHTML = list.map(n => {
    const isUnread = !n.read;
    const typeIcons = { order: '🛍️', client: '👤', visitor: '🌍', chat: '💬', amendment: '✏️' };
    const icon = typeIcons[n.type] || '⚡';
    const bgClass = isUnread ? 'bg-[#1C1C2C] hover:bg-[#222236]' : 'hover:bg-[#151520] opacity-80';
    const link = n.link || '#';

    return `
      <a href="${link}" class="block p-3 rounded-xl ${bgClass} transition-all border border-transparent hover:border-gold/40 hover:bg-[#1E1E30]">
        <div class="flex items-start gap-2.5">
          <span class="text-base flex-shrink-0 mt-0.5">${icon}</span>
          <div class="flex-1 min-w-0">
            <div class="flex items-start justify-between gap-1.5">
              <span class="font-bold text-white text-xs leading-snug break-words">${n.title}</span>
              <span class="text-[10px] text-gray-400 font-mono flex-shrink-0 ml-1">${n.time_formatted || ''}</span>
            </div>
            <p class="text-[11px] text-gray-300 mt-1 leading-relaxed break-words">${n.message}</p>
          </div>
          ${isUnread ? '<span class="w-2.5 h-2.5 rounded-full bg-gold animate-pulse flex-shrink-0 mt-1 shadow-sm"></span>' : ''}
        </div>
      </a>
    `;
  }).join('');
}

function pollAdminNotifications() {
  fetch('/api/admin-notifications.php?action=poll')
    .then(res => res.json())
    .then(data => {
      if (!data.success) return;

      const unreadCount = data.unread_count || 0;
      const badge = document.getElementById('unreadNotifBadge');
      if (badge) {
        if (unreadCount > 0) {
          badge.textContent = unreadCount > 99 ? '99+' : unreadCount;
          badge.classList.remove('hidden');
        } else {
          badge.classList.add('hidden');
        }
      }

      renderNotificationFeed(data.notifications);

      // Play Audio Chime on fresh notifications
      if (data.play_chime && unreadCount > lastKnownNotifCount && hasPlayedInitialChime) {
        playNotificationChime();
        if (data.notifications && data.notifications[0]) {
          const top = data.notifications[0];
          showDesktopNotification(top.title, top.message, top.link);
          if (window.EstateDialog) {
            EstateDialog.toast(`${top.title}: ${top.message}`, 'info');
          }
        }
      }

      lastKnownNotifCount = unreadCount;
      hasPlayedInitialChime = true;
    })
    .catch(() => {});
}

function markAllNotificationsRead() {
  fetch('/api/admin-notifications.php?action=mark_read')
    .then(res => res.json())
    .then(() => {
      const badge = document.getElementById('unreadNotifBadge');
      if (badge) badge.classList.add('hidden');
      lastKnownNotifCount = 0;
      pollAdminNotifications();
    })
    .catch(() => {});
}

function clearAllNotifications() {
  const doClear = () => {
    fetch('/api/admin-notifications.php?action=clear_all')
      .then(res => res.json())
      .then(() => {
        pollAdminNotifications();
      })
      .catch(() => {});
  };

  if (window.EstateDialog) {
    EstateDialog.confirm('Clear all notification history?', 'Clear Notifications', { danger: true, confirmText: '✓ Clear All' }).then(ok => {
      if (ok) doClear();
    });
  } else {
    doClear();
  }
}

function testNotificationAlert() {
  getAudioContext();
  fetch('/api/admin-notifications.php?action=test_alert')
    .then(res => res.json())
    .then(data => {
      playNotificationChime();
      showDesktopNotification('🛍️ Test Order Placed', 'Sample order test notification received successfully!');
      pollAdminNotifications();
      if (window.EstateDialog) EstateDialog.toast('Test chime & notification dispatched!', 'success');
    })
    .catch(() => {});
}

// Start polling on load and every 12 seconds
document.addEventListener('DOMContentLoaded', function() {
  pollAdminNotifications();
  setInterval(pollAdminNotifications, 12000);
});

// ── Master Admin Dropdown & Mobile Menu Controllers ─────────────
function toggleAdminDropdown(groupId) {
  const targetGroup = document.getElementById(groupId);
  if (!targetGroup) return;
  const isAlreadyOpen = targetGroup.classList.contains('is-open');
  // Close all other open dropdowns
  document.querySelectorAll('.admin-dropdown-group.is-open').forEach(g => {
    if (g !== targetGroup) g.classList.remove('is-open');
  });
  targetGroup.classList.toggle('is-open', !isAlreadyOpen);
}

function toggleAdminMobileMenu() {
  const drawer = document.getElementById('adminMobileDrawer');
  if (drawer) {
    drawer.classList.toggle('hidden');
  }
}

// Global outside click & Escape key listener for dropdowns & mobile drawer
document.addEventListener('click', function(e) {
  if (!e.target.closest('.admin-dropdown-group')) {
    document.querySelectorAll('.admin-dropdown-group.is-open').forEach(g => g.classList.remove('is-open'));
  }
});

document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    document.querySelectorAll('.admin-dropdown-group.is-open').forEach(g => g.classList.remove('is-open'));
    const notifPanel = document.getElementById('notifDropdownPanel');
    if (notifPanel) notifPanel.classList.add('hidden');
    const mobileDrawer = document.getElementById('adminMobileDrawer');
    if (mobileDrawer) mobileDrawer.classList.add('hidden');
  }
});
</script>

