-- ==============================================================================
-- Estate HDR — Enterprise Live Visitor Radar, AI Concierge & Global Agent Platform
-- MySQL Relational Database Schema (Version 1.0 — August 2026)
-- Fully compatible with Hostinger MySQL 8.0+ / MariaDB 10.6+
-- ==============================================================================

SET FOREIGN_KEY_CHECKS = 0;

-- 1. VISITORS TABLE (Identifies unique visitors across devices & sessions)
CREATE TABLE IF NOT EXISTS isitors (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  isitor_uuid VARCHAR(64) NOT NULL UNIQUE,
  ip VARCHAR(45) NOT NULL DEFAULT '127.0.0.1',
  country VARCHAR(100) NOT NULL DEFAULT 'United Kingdom',
  city VARCHAR(100) NOT NULL DEFAULT 'London',
  country_code VARCHAR(10) NOT NULL DEFAULT 'GB',
  lag VARCHAR(10) NOT NULL DEFAULT '🇬🇧',
  device VARCHAR(50) NOT NULL DEFAULT 'Desktop',
  rowser VARCHAR(50) NOT NULL DEFAULT 'Chrome',
  os VARCHAR(50) NOT NULL DEFAULT 'Windows',
  
eferrer VARCHAR(500) DEFAULT 'Direct Visit',
  landing_page VARCHAR(500) DEFAULT '/',
  utm_source VARCHAR(100) DEFAULT NULL,
  utm_medium VARCHAR(100) DEFAULT NULL,
  utm_campaign VARCHAR(100) DEFAULT NULL,
  lead_score INT NOT NULL DEFAULT 0,
  lead_band ENUM('Cold', 'Warm', 'Hot', 'Sales Priority') NOT NULL DEFAULT 'Cold',
  ssigned_agent_id BIGINT UNSIGNED DEFAULT NULL,
  is_online TINYINT(1) NOT NULL DEFAULT 1,
  irst_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_visitor_uuid (isitor_uuid),
  INDEX idx_country_code (country_code),
  INDEX idx_lead_band (lead_band),
  INDEX idx_last_seen (last_seen_at),
  INDEX idx_assigned_agent (ssigned_agent_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. VISITOR SESSIONS TABLE
CREATE TABLE IF NOT EXISTS isitor_sessions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  session_token VARCHAR(64) NOT NULL UNIQUE,
  isitor_id BIGINT UNSIGNED NOT NULL,
  ip VARCHAR(45) NOT NULL DEFAULT '127.0.0.1',
  started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_active_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  duration_seconds INT NOT NULL DEFAULT 0,
  page_views_count INT NOT NULL DEFAULT 1,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  INDEX idx_session_visitor (isitor_id),
  INDEX idx_session_token (session_token),
  INDEX idx_session_active (is_active, last_active_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. PAGE VIEWS TABLE
CREATE TABLE IF NOT EXISTS page_views (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  isitor_id BIGINT UNSIGNED NOT NULL,
  session_id BIGINT UNSIGNED DEFAULT NULL,
  page_url VARCHAR(500) NOT NULL,
  page_title VARCHAR(255) DEFAULT '',
  
eferrer VARCHAR(500) DEFAULT '',
  	ime_spent_seconds INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_pageview_visitor (isitor_id),
  INDEX idx_pageview_url (page_url(191)),
  INDEX idx_pageview_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. VISITOR EVENTS & TELEMETRY TABLE
CREATE TABLE IF NOT EXISTS isitor_events (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  isitor_id BIGINT UNSIGNED NOT NULL,
  session_id BIGINT UNSIGNED DEFAULT NULL,
  event_type VARCHAR(50) NOT NULL,
  event_name VARCHAR(100) NOT NULL,
  event_data JSON DEFAULT NULL,
  points_awarded INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_event_visitor (isitor_id),
  INDEX idx_event_type (event_type),
  INDEX idx_event_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. AGENTS TABLE (Global Country-Based Retouching Directors & Managers)
CREATE TABLE IF NOT EXISTS gents (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(191) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  ull_name VARCHAR(100) NOT NULL,
  
ole ENUM('super_admin', 'ceo_executive', 'country_manager', 'sales_manager', 'country_sales_agent', 'retouching_director', 'technical_specialist', 'support_agent', 'qa', 'viewer') NOT NULL DEFAULT 'retouching_director',
  vatar VARCHAR(255) DEFAULT '/assets/images/team/alice.jpg',
  ssigned_countries JSON DEFAULT NULL,
  spoken_languages JSON DEFAULT NULL,
  	imezone VARCHAR(50) NOT NULL DEFAULT 'UTC',
  max_concurrent_chats INT NOT NULL DEFAULT 5,
  is_online TINYINT(1) NOT NULL DEFAULT 1,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  last_seen_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_agent_role (
ole),
  INDEX idx_agent_online (is_online, is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. AGENT PRESENCE & WORKLOAD TABLE
CREATE TABLE IF NOT EXISTS gent_presence (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  gent_id BIGINT UNSIGNED NOT NULL UNIQUE,
  status ENUM('online', 'busy', 'away', 'offline') NOT NULL DEFAULT 'online',
  ctive_chats_count INT NOT NULL DEFAULT 0,
  last_heartbeat_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_presence_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. CONVERSATIONS TABLE
CREATE TABLE IF NOT EXISTS conversations (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  conversation_uuid VARCHAR(64) NOT NULL UNIQUE,
  isitor_id BIGINT UNSIGNED NOT NULL,
  lead_id BIGINT UNSIGNED DEFAULT NULL,
  channel VARCHAR(50) NOT NULL DEFAULT 'web_chat',
  status ENUM('active', 'waiting_agent', 'ai_handling', 'escalated', 'closed') NOT NULL DEFAULT 'ai_handling',
  priority ENUM('low', 'medium', 'high', 'urgent') NOT NULL DEFAULT 'medium',
  country_code VARCHAR(10) NOT NULL DEFAULT 'GB',
  ssigned_agent_id BIGINT UNSIGNED DEFAULT NULL,
  
outing_tier VARCHAR(50) NOT NULL DEFAULT 'global_fallback',
  lead_score INT NOT NULL DEFAULT 0,
  unread_for_agent TINYINT(1) NOT NULL DEFAULT 0,
  unread_for_visitor TINYINT(1) NOT NULL DEFAULT 0,
  isitor_typing VARCHAR(500) DEFAULT '',
  	yping_updated_at INT NOT NULL DEFAULT 0,
  started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_message_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  closed_at DATETIME DEFAULT NULL,
  INDEX idx_conv_uuid (conversation_uuid),
  INDEX idx_conv_visitor (isitor_id),
  INDEX idx_conv_status (status),
  INDEX idx_conv_agent (ssigned_agent_id),
  INDEX idx_conv_country (country_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. MESSAGES TABLE
CREATE TABLE IF NOT EXISTS messages (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  conversation_id BIGINT UNSIGNED NOT NULL,
  message_uuid VARCHAR(64) NOT NULL UNIQUE,
  sender_type ENUM('user', 'agent', 'bot', 'system') NOT NULL,
  sender_id BIGINT UNSIGNED DEFAULT NULL,
  sender_name VARCHAR(100) NOT NULL DEFAULT 'Alice | Retouching Director',
  message_text TEXT NOT NULL,
  payload_json JSON DEFAULT NULL,
  is_private_note TINYINT(1) NOT NULL DEFAULT 0,
  is_ai_generated TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_msg_conv (conversation_id),
  INDEX idx_msg_sender (sender_type),
  INDEX idx_msg_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. LEADS & CRM PIPELINE TABLE
CREATE TABLE IF NOT EXISTS leads (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  isitor_id BIGINT UNSIGNED DEFAULT NULL,
  
ame VARCHAR(150) NOT NULL,
  email VARCHAR(191) NOT NULL,
  phone VARCHAR(50) DEFAULT '',
  whatsapp VARCHAR(50) DEFAULT '',
  company VARCHAR(150) DEFAULT '',
  country VARCHAR(100) DEFAULT 'United Kingdom',
  country_code VARCHAR(10) DEFAULT 'GB',
  lead_score INT NOT NULL DEFAULT 20,
  lead_band ENUM('Cold', 'Warm', 'Hot', 'Sales Priority') NOT NULL DEFAULT 'Warm',
  status ENUM('new', 'contacted', 'trial_requested', 'trial_delivered', 'quote_sent', 'won', 'lost') NOT NULL DEFAULT 'new',
  source VARCHAR(100) NOT NULL DEFAULT 'live_chat',
  
otes TEXT DEFAULT NULL,
  cloud_link VARCHAR(500) DEFAULT '',
  estimated_value DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  ssigned_agent_id BIGINT UNSIGNED DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_lead_email (email),
  INDEX idx_lead_band (lead_band),
  INDEX idx_lead_status (status),
  INDEX idx_lead_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. QUOTES TABLE (Deterministic Server-Side Calculation Engine)
CREATE TABLE IF NOT EXISTS quotes (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  quote_uuid VARCHAR(64) NOT NULL UNIQUE,
  lead_id BIGINT UNSIGNED DEFAULT NULL,
  conversation_id BIGINT UNSIGNED DEFAULT NULL,
  service_type VARCHAR(100) NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  unit_price DECIMAL(10,2) NOT NULL DEFAULT 0.80,
  subtotal DECIMAL(10,2) NOT NULL DEFAULT 0.80,
  discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  
ush_surcharge DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  	otal_amount DECIMAL(10,2) NOT NULL DEFAULT 0.80,
  currency VARCHAR(10) NOT NULL DEFAULT 'USD',
  alidity_date DATE NOT NULL,
  calculation_breakdown_json JSON NOT NULL,
  status ENUM('draft', 'presented', 'accepted', 'rejected', 'expired') NOT NULL DEFAULT 'presented',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_quote_uuid (quote_uuid),
  INDEX idx_quote_lead (lead_id),
  INDEX idx_quote_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. FILES & FREE SAMPLE JOBS TABLE
CREATE TABLE IF NOT EXISTS iles (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  job_uuid VARCHAR(64) NOT NULL UNIQUE,
  isitor_id BIGINT UNSIGNED DEFAULT NULL,
  lead_id BIGINT UNSIGNED DEFAULT NULL,
  ile_type ENUM('raw_bracket', 'finished_hdr', 'staging_input', 'floorplan_sketch', 'video_footage') NOT NULL,
  ile_source ENUM('google_drive', 'dropbox', 'wetransfer', 'onedrive', 'direct_upload') NOT NULL,
  cloud_url VARCHAR(500) NOT NULL,
  ile_name VARCHAR(255) DEFAULT '',
  ile_size_bytes BIGINT UNSIGNED DEFAULT 0,
  irus_status ENUM('pending', 'clean', 'flagged') NOT NULL DEFAULT 'clean',
  status ENUM('received', 'assigned', 'in_retouching', 'qa_review', 'delivered', 'archived') NOT NULL DEFAULT 'received',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_file_job (job_uuid),
  INDEX idx_file_lead (lead_id),
  INDEX idx_file_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. AI INTERACTIONS & AUDIT TABLE
CREATE TABLE IF NOT EXISTS i_interactions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  conversation_id BIGINT UNSIGNED DEFAULT NULL,
  isitor_id BIGINT UNSIGNED DEFAULT NULL,
  prompt_tokens INT NOT NULL DEFAULT 0,
  completion_tokens INT NOT NULL DEFAULT 0,
  model_used VARCHAR(100) NOT NULL DEFAULT 'internal-rag-v1',
  confidence_score DECIMAL(4,3) NOT NULL DEFAULT 0.950,
  intent_detected VARCHAR(100) NOT NULL DEFAULT 'general_inquiry',
  knowledge_chunks_used_json JSON DEFAULT NULL,
  escalated_to_human TINYINT(1) NOT NULL DEFAULT 0,
  
esponse_latency_ms INT NOT NULL DEFAULT 120,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ai_conv (conversation_id),
  INDEX idx_ai_intent (intent_detected),
  INDEX idx_ai_escalated (escalated_to_human)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13. RAG KNOWLEDGE DOCUMENTS TABLE
CREATE TABLE IF NOT EXISTS knowledge_documents (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  	itle VARCHAR(255) NOT NULL,
  category VARCHAR(100) NOT NULL,
  content MEDIUMTEXT NOT NULL,
  language VARCHAR(10) NOT NULL DEFAULT 'en',
  country_code VARCHAR(10) DEFAULT 'GLOBAL',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_doc_cat (category),
  INDEX idx_doc_lang (language)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 14. RAG KNOWLEDGE CHUNKS TABLE
CREATE TABLE IF NOT EXISTS knowledge_chunks (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  document_id BIGINT UNSIGNED NOT NULL,
  chunk_text TEXT NOT NULL,
  keywords VARCHAR(500) NOT NULL,
  intent_tag VARCHAR(100) NOT NULL,
  priority_weight INT NOT NULL DEFAULT 10,
  INDEX idx_chunk_intent (intent_tag),
  INDEX idx_chunk_doc (document_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 15. CANNED RESPONSES & SHORTCUTS TABLE
CREATE TABLE IF NOT EXISTS canned_responses (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category VARCHAR(100) NOT NULL DEFAULT 'General',
  shortcut VARCHAR(50) NOT NULL,
  	itle VARCHAR(150) NOT NULL,
  	ext TEXT NOT NULL,
  language VARCHAR(10) NOT NULL DEFAULT 'en',
  country_code VARCHAR(10) DEFAULT 'GLOBAL',
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_canned_shortcut (shortcut),
  INDEX idx_canned_cat (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 16. CAMPAIGNS & UTM ATTRIBUTION TABLE
CREATE TABLE IF NOT EXISTS campaigns (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  
ame VARCHAR(150) NOT NULL,
  utm_source VARCHAR(100) NOT NULL,
  utm_medium VARCHAR(100) NOT NULL,
  utm_campaign VARCHAR(100) NOT NULL,
  	arget_country VARCHAR(50) DEFAULT 'ALL',
  cta_text VARCHAR(255) DEFAULT 'Claim 3 Free Sample Edits',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_campaign_utm (utm_source, utm_campaign)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 17. AUDIT LOGS TABLE
CREATE TABLE IF NOT EXISTS udit_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ctor_type ENUM('admin', 'agent', 'system', 'visitor') NOT NULL,
  ctor_id BIGINT UNSIGNED DEFAULT NULL,
  ctor_email VARCHAR(191) DEFAULT NULL,
  ction VARCHAR(100) NOT NULL,
  	arget_type VARCHAR(50) DEFAULT NULL,
  	arget_id VARCHAR(100) DEFAULT NULL,
  ip_address VARCHAR(45) NOT NULL DEFAULT '127.0.0.1',
  details_json JSON DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audit_action (ction),
  INDEX idx_audit_actor (ctor_type, ctor_id),
  INDEX idx_audit_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 18. NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS 
otifications (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  
ecipient_type ENUM('all_agents', 'agent', 'admin', 'client') NOT NULL,
  
ecipient_id BIGINT UNSIGNED DEFAULT NULL,
  	itle VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  link VARCHAR(500) DEFAULT '',
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_notif_recipient (
ecipient_type, 
ecipient_id),
  INDEX idx_notif_read (is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 19. ORDERS TABLE
CREATE TABLE IF NOT EXISTS orders (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_number VARCHAR(64) NOT NULL UNIQUE,
  user_id BIGINT UNSIGNED DEFAULT NULL,
  lead_id BIGINT UNSIGNED DEFAULT NULL,
  quote_id BIGINT UNSIGNED DEFAULT NULL,
  service_name VARCHAR(100) NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  	otal_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  currency VARCHAR(10) NOT NULL DEFAULT 'USD',
  status ENUM('pending', 'in_progress', 'qa_review', 'delivered', 'revision_requested', 'completed', 'cancelled') NOT NULL DEFAULT 'pending',
  payment_status ENUM('unpaid', 'paid', 'refunded') NOT NULL DEFAULT 'unpaid',
  delivery_deadline DATETIME DEFAULT NULL,
  iles_link VARCHAR(500) DEFAULT '',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_order_num (order_number),
  INDEX idx_order_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 20. ASYNC BACKGROUND JOB QUEUE TABLE
CREATE TABLE IF NOT EXISTS database_queue (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  job_type VARCHAR(100) NOT NULL,
  payload_json JSON NOT NULL,
  ttempts INT NOT NULL DEFAULT 0,
  max_attempts INT NOT NULL DEFAULT 3,
  status ENUM('pending', 'processing', 'completed', 'failed') NOT NULL DEFAULT 'pending',
  error_message TEXT DEFAULT NULL,
  vailable_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_queue_status (status, vailable_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 21. A/B EXPERIMENTS TABLE
CREATE TABLE IF NOT EXISTS b_experiments (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  experiment_key VARCHAR(100) NOT NULL UNIQUE,
  ariant_a_name VARCHAR(100) NOT NULL DEFAULT 'Control',
  ariant_b_name VARCHAR(100) NOT NULL DEFAULT 'Variant B',
  impressions_a INT NOT NULL DEFAULT 0,
  impressions_b INT NOT NULL DEFAULT 0,
  conversions_a INT NOT NULL DEFAULT 0,
  conversions_b INT NOT NULL DEFAULT 0,
  status ENUM('active', 'paused', 'concluded') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
