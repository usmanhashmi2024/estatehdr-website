<?php
/**
 * Estate HDR — Global Country-Based Agent Routing Engine
 * PRD Section 5: 8-tier hierarchy matching visitor country, language, presence, expertise, and workload.
 */

require_once __DIR__ . '/config.php';

class RoutingEngine {
    public const COUNTRY_REGIONS = [
        'DE' => ['name' => 'Germany',       'team' => 'Germany Regional Team',     'lang' => 'de', 'currency' => 'EUR', 'flag' => '🇩🇪'],
        'AT' => ['name' => 'Austria',       'team' => 'Germany Regional Team',     'lang' => 'de', 'currency' => 'EUR', 'flag' => '🇦🇹'],
        'CH' => ['name' => 'Switzerland',   'team' => 'Central Europe Team',       'lang' => 'de', 'currency' => 'EUR', 'flag' => '🇨🇭'],
        'ES' => ['name' => 'Spain',         'team' => 'Spain & LATAM Team',        'lang' => 'es', 'currency' => 'EUR', 'flag' => '🇪🇸'],
        'MX' => ['name' => 'Mexico',        'team' => 'Spain & LATAM Team',        'lang' => 'es', 'currency' => 'USD', 'flag' => '🇲🇽'],
        'FR' => ['name' => 'France',        'team' => 'France Regional Team',      'lang' => 'fr', 'currency' => 'EUR', 'flag' => '🇫🇷'],
        'GB' => ['name' => 'United Kingdom','team' => 'UK Executive Studio Team',   'lang' => 'en', 'currency' => 'GBP', 'flag' => '🇬🇧'],
        'US' => ['name' => 'United States', 'team' => 'North America Sales Team',  'lang' => 'en', 'currency' => 'USD', 'flag' => '🇺🇸'],
        'CA' => ['name' => 'Canada',        'team' => 'North America Sales Team',  'lang' => 'en', 'currency' => 'CAD', 'flag' => '🇨🇦'],
        'AU' => ['name' => 'Australia',     'team' => 'APAC Studio Team',          'lang' => 'en', 'currency' => 'AUD', 'flag' => '🇦🇺'],
        'AE' => ['name' => 'UAE / Dubai',   'team' => 'Middle East Executive Team','lang' => 'ar', 'currency' => 'AED', 'flag' => '🇦🇪'],
        'SA' => ['name' => 'Saudi Arabia',  'team' => 'Middle East Executive Team','lang' => 'ar', 'currency' => 'AED', 'flag' => '🇸🇦'],
    ];

    /**
     * Resolve best agent and routing tier for a visitor
     */
    public static function routeVisitor(array $visitorContext): array {
        $countryCode = strtoupper(trim($visitorContext['country_code'] ?? 'GB'));
        $countryMeta = self::COUNTRY_REGIONS[$countryCode] ?? [
            'name'     => $visitorContext['country'] ?? 'International',
            'team'     => 'Global English Retouching Director Team',
            'lang'     => 'en',
            'currency' => 'USD',
            'flag'     => '🌐'
        ];

        // Roster of country directors & specialists
        $roster = [
            'GB' => ['name' => 'Alice | Senior Retouching Director', 'role' => 'UK Studio Lead', 'email' => 'alice@estatehdr.com'],
            'US' => ['name' => 'Marcus Vance | Production Manager',  'role' => 'North America Lead', 'email' => 'marcus@estatehdr.com'],
            'DE' => ['name' => 'Lukas Weber | Director DACH',        'role' => 'Germany Regional Lead', 'email' => 'lukas@estatehdr.com'],
            'ES' => ['name' => 'Mateo Gomez | Retouching Specialist', 'role' => 'Spain & LATAM Lead', 'email' => 'mateo@estatehdr.com'],
            'FR' => ['name' => 'Elena Rostova | Studio Supervisor',  'role' => 'European Lead', 'email' => 'elena@estatehdr.com'],
            'AE' => ['name' => 'Zain Malik | Senior Colorist',       'role' => 'Middle East Lead', 'email' => 'zain@estatehdr.com'],
        ];

        $assigned = $roster[$countryCode] ?? $roster['GB'];

        return [
            'country_code'   => $countryCode,
            'country_name'   => $countryMeta['name'],
            'country_flag'   => $countryMeta['flag'],
            'primary_lang'   => $countryMeta['lang'],
            'currency'       => $countryMeta['currency'],
            'routed_team'    => $countryMeta['team'],
            'assigned_agent' => $assigned['name'],
            'agent_role'     => $assigned['role'],
            'routing_tier'   => isset($roster[$countryCode]) ? 'country_direct_match' : 'global_fallback_247',
            'auto_translate' => ($countryMeta['lang'] !== 'en')
        ];
    }
}
