<?php
/**
 * Estate HDR — Lead Intelligence & Conversion Scoring Engine
 * PRD Section 10: Deterministic event point awards & dynamic lead band transitions.
 */

class LeadScoringEngine {
    public const EVENT_WEIGHTS = [
        'pricing_viewed'      => 10,
        'portfolio_viewed'    => 10,
        'active_3min'         => 5,
        'free_sample_request' => 30,
        'file_upload_link'    => 50,
        'rush_sla_question'   => 20,
        'bulk_order_inquiry'  => 30,
        'whatsapp_cta_click'  => 25,
        'email_provided'      => 20,
    ];

    public static function calculateScore(int $currentScore, string $eventType): array {
        $points = self::EVENT_WEIGHTS[$eventType] ?? 5;
        $newScore = $currentScore + $points;

        $band = 'Cold';
        if ($newScore >= 80) {
            $band = 'Sales Priority';
        } elseif ($newScore >= 50) {
            $band = 'Hot';
        } elseif ($newScore >= 25) {
            $band = 'Warm';
        }

        return [
            'points_added' => $points,
            'new_score'    => $newScore,
            'lead_band'    => $band,
            'is_priority'  => ($band === 'Sales Priority' || $band === 'Hot')
        ];
    }
}
