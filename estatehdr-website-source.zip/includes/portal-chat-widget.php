<?php
/**
 * Estate HDR — Floating Client-to-Management Live Chat Widget
 * Renders on all client portal pages so clients can chat with Management from anywhere,
 * tag orders dynamically, and upload screenshot attachments.
 */
if (!isLoggedIn()) return;
$widgetUser = currentUser();
$widgetClientId = $widgetUser['id'] ?? '';
if (empty($widgetClientId)) return;
?>
<!-- ── FLOATING CLIENT LIVE CHAT WIDGET ────────────────────────── -->
<div id="portalFloatingChatWrapper" class="fixed bottom-6 right-6 z-50 font-sans">
    
    <!-- Floating Trigger Button -->
    <button 
        type="button" 
        id="portalChatToggleBtn" 
        onclick="togglePortalFloatingChat()" 
        class="group flex items-center gap-2.5 px-4 py-3 rounded-full bg-[#111118] border border-gold/50 text-white shadow-2xl hover:border-gold hover:scale-105 transition-all"
        title="Direct Chat with Studio Management"
    >
        <div class="relative flex items-center justify-center">
            <span class="text-xl">💬</span>
            <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 absolute -top-0.5 -right-0.5 animate-pulse"></span>
        </div>
        <span class="text-xs font-bold text-gray-200 group-hover:text-gold transition">
            Chat with Management
        </span>
    </button>

    <!-- Slide-Up Floating Chat Window -->
    <div 
        id="portalFloatingChatBox" 
        class="hidden absolute bottom-16 right-0 w-[380px] sm:w-[420px] h-[560px] bg-[#111118] border border-gold/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col z-50 text-xs"
        style="box-shadow: 0 25px 50px -12px rgba(0,0,0,0.9), 0 0 25px rgba(201, 168, 76, 0.25);"
    >
        <!-- Header -->
        <div class="p-3.5 bg-[#161624] border-b border-dark-border flex items-center justify-between">
            <div class="flex items-center gap-2.5">
                <div class="relative">
                    <div class="w-8 h-8 rounded-xl bg-gold/20 text-gold border border-gold/50 flex items-center justify-center font-black text-xs">
                        EH
                    </div>
                    <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 absolute -bottom-0.5 -right-0.5"></span>
                </div>
                <div>
                    <div class="font-bold text-white text-xs flex items-center gap-1.5">
                        <span>Management Standby</span>
                        <span class="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 font-mono">Live</span>
                    </div>
                    <p class="text-[10px] text-gray-400">Sarah (Director) &bull; Avg: &lt;5m</p>
                </div>
            </div>

            <div class="flex items-center gap-2.5">
                <a href="/support.php" class="text-gray-400 hover:text-gold text-xs font-bold" title="Open Full Screen Tracking Hub">
                    <i class="fas fa-expand-alt"></i>
                </a>
                <button type="button" onclick="togglePortalFloatingChat()" class="text-gray-400 hover:text-white text-lg font-bold px-1.5 leading-none">
                    &times;
                </button>
            </div>
        </div>

        <!-- Optional Order Tag Selector Bar -->
        <div class="px-3 py-1.5 bg-[#10101A] border-b border-dark-border flex items-center gap-1.5 text-[11px]">
            <span class="text-gold"><i class="fas fa-tag"></i></span>
            <select id="floatOrderSelect" class="flex-1 bg-[#0B0C12] border border-gray-700 rounded-lg px-2 py-1 text-[11px] text-white focus:border-gold focus:outline-none">
                <option value="">💬 General Message (No Order Tag)</option>
            </select>
        </div>

        <!-- Messages Area -->
        <div id="floatChatMsgContainer" class="flex-1 p-3.5 overflow-y-auto space-y-3 bg-[#0B0C12]/70">
            <div class="text-center py-6 text-gray-500 text-[11px]">
                <div class="animate-spin text-base mb-1 inline-block">⌛</div>
                <p>Connecting to Management Desk...</p>
            </div>
        </div>

        <!-- Attachment Preview Bar -->
        <div id="floatAttPreviewBar" class="hidden px-3 py-1.5 bg-[#171726] border-t border-gray-800 flex items-center justify-between text-[11px] text-gray-300">
            <div class="flex items-center gap-1.5 truncate">
                <span>📎</span>
                <span id="floatAttName" class="font-bold truncate max-w-[220px]"></span>
            </div>
            <button type="button" onclick="removeFloatAttachment()" class="text-gray-400 hover:text-red-400 text-xs px-1">&times;</button>
        </div>

        <!-- Input Bar -->
        <div class="p-3 bg-[#141420] border-t border-dark-border">
            <form onsubmit="handleSendFloatingMessage(event)" class="flex items-center gap-2">
                <input type="file" id="floatFileInput" onchange="onFloatFileSelected(this)" accept="image/jpeg,image/png,image/webp,application/pdf,application/zip" class="hidden">
                <button type="button" onclick="document.getElementById('floatFileInput').click()" class="p-2 rounded-xl bg-[#0B0C12] hover:bg-gold/10 border border-gray-700 hover:border-gold text-gray-300 hover:text-gold transition shrink-0" title="Attach screenshot or file">
                    <i class="fas fa-paperclip text-xs"></i>
                </button>
                <input 
                    type="text" 
                    id="floatChatInputText" 
                    placeholder="Type message to Management... (Enter)" 
                    class="flex-1 bg-[#0B0C12] border border-gray-700 rounded-xl px-3 py-2 text-xs text-white focus:border-gold focus:outline-none"
                >
                <button type="submit" id="floatSendBtn" class="btn-gold px-3.5 py-2 rounded-xl text-xs font-bold shadow-glow flex items-center justify-center shrink-0">
                    <i class="fas fa-paper-plane"></i>
                </button>
            </form>
        </div>
    </div>
</div>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
let floatChatOpen = false;
let floatLastMsgCount = 0;
let floatSelectedFile = null;
let floatOrdersLoaded = false;

function togglePortalFloatingChat() {
    const box = document.getElementById('portalFloatingChatBox');
    if (!box) return;
    floatChatOpen = !floatChatOpen;
    if (floatChatOpen) {
        box.classList.remove('hidden');
        pollFloatingMessages();
        loadFloatingOrders();
        setTimeout(() => {
            const input = document.getElementById('floatChatInputText');
            if (input) input.focus();
        }, 100);
    } else {
        box.classList.add('hidden');
    }
}

async function loadFloatingOrders() {
    if (floatOrdersLoaded) return;
    try {
        const res = await fetch('/api/client-chat.php?action=client_orders');
        const data = await res.json();
        if (data.success && data.summary && data.summary.orders) {
            const sel = document.getElementById('floatOrderSelect');
            if (sel) {
                sel.innerHTML = '<option value="">💬 General Message (No Order Tag)</option>';
                data.summary.orders.forEach(o => {
                    const opt = document.createElement('option');
                    opt.value = o.id;
                    opt.textContent = `#${o.id} — ${o.address.substring(0, 22)} (${o.status_label})`;
                    sel.appendChild(opt);
                });
            }
            floatOrdersLoaded = true;
        }
    } catch (e) {}
}

function onFloatFileSelected(input) {
    if (input.files && input.files[0]) {
        floatSelectedFile = input.files[0];
        const bar = document.getElementById('floatAttPreviewBar');
        const nameEl = document.getElementById('floatAttName');
        if (bar && nameEl) {
            nameEl.textContent = floatSelectedFile.name;
            bar.classList.remove('hidden');
        }
    }
}

function removeFloatAttachment() {
    floatSelectedFile = null;
    const input = document.getElementById('floatFileInput');
    if (input) input.value = '';
    const bar = document.getElementById('floatAttPreviewBar');
    if (bar) bar.classList.add('hidden');
}

async function pollFloatingMessages() {
    try {
        const res = await fetch('/api/client-chat.php?action=poll&mark_read=1');
        const data = await res.json();
        if (data.success && data.messages) {
            if (data.messages.length !== floatLastMsgCount) {
                renderFloatingMessages(data.messages);
            }
        }
    } catch (err) {
        console.error('Floating chat poll error:', err);
    }
}

async function handleSendFloatingMessage(e) {
    if (e) e.preventDefault();
    const input = document.getElementById('floatChatInputText');
    const orderSelect = document.getElementById('floatOrderSelect');
    const btn = document.getElementById('floatSendBtn');
    const text = input.value.trim();

    if (!text && !floatSelectedFile) return;

    btn.disabled = true;
    btn.classList.add('opacity-50');

    try {
        const formData = new FormData();
        formData.append('action', 'send');
        formData.append('text', text);
        if (orderSelect && orderSelect.value) {
            formData.append('order_id', orderSelect.value);
        }
        if (floatSelectedFile) {
            formData.append('attachment', floatSelectedFile);
        }

        const res = await fetch('/api/client-chat.php', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        if (data.success && data.messages) {
            renderFloatingMessages(data.messages);
            input.value = '';
            removeFloatAttachment();
        } else if (data.error) {
            alert(data.error);
        }
    } catch (err) {
        console.error('Floating chat send error:', err);
    } finally {
        btn.disabled = false;
        btn.classList.remove('opacity-50');
    }
}

function renderFloatingMessages(messages) {
    floatLastMsgCount = messages.length;
    const container = document.getElementById('floatChatMsgContainer');
    if (!container) return;

    let html = '';
    messages.forEach(msg => {
        const isClient = msg.sender === 'client';
        const senderName = msg.sender_name || (isClient ? 'You' : 'Management');
        const timeStr = msg.timestamp ? msg.timestamp.substring(11, 16) : '';
        const orderBadge = msg.order_id 
            ? `<span class="px-1.5 py-0.2 rounded bg-gold/15 text-gold border border-gold/30 font-mono text-[9px]">🏷️ #${escapeHtml(msg.order_id)}</span>` 
            : '';

        const bubbleCls = isClient
            ? 'bg-gradient-to-br from-[#1C180E] to-[#12110B] border border-gold/40 text-gray-100 rounded-br-sm'
            : 'bg-[#161624] border border-gray-700/80 text-gray-200 rounded-bl-sm';

        let attHtml = '';
        if (msg.attachment) {
            const att = msg.attachment;
            if (att.is_image) {
                attHtml = `
                    <div class="mt-1.5 pt-1.5 border-t border-gray-700/50">
                        <a href="${escapeHtml(att.file_url)}" target="_blank" class="block">
                            <img src="${escapeHtml(att.file_url)}" alt="Attachment" class="max-h-32 rounded-lg object-cover border border-gray-700 hover:border-gold transition">
                        </a>
                        <div class="text-[9px] text-gray-400 mt-0.5 truncate">${escapeHtml(att.file_name)}</div>
                    </div>
                `;
            } else {
                attHtml = `
                    <div class="mt-1.5 pt-1.5 border-t border-gray-700/50">
                        <a href="${escapeHtml(att.file_url)}" download class="flex items-center gap-1.5 p-1 rounded bg-black/30 border border-gray-700 text-gray-200 hover:text-gold transition text-[10px]">
                            <span>📄</span>
                            <span class="truncate flex-1">${escapeHtml(att.file_name)}</span>
                            <i class="fas fa-download text-[9px]"></i>
                        </a>
                    </div>
                `;
            }
        }

        html += `
            <div class="flex flex-col ${isClient ? 'items-end' : 'items-start'} space-y-1">
                <div class="flex items-center gap-1.5 text-[9px] text-gray-400">
                    <strong class="${isClient ? 'text-gold' : 'text-blue-300'}">${escapeHtml(senderName)}</strong>
                    <span>${timeStr}</span>
                    ${orderBadge}
                </div>
                <div class="max-w-[85%] p-2.5 rounded-xl text-xs leading-relaxed ${bubbleCls}">
                    ${msg.text ? `<div>${escapeHtml(msg.text).replace(/\n/g, '<br>')}</div>` : ''}
                    ${attHtml}
                </div>
            </div>
        `;
    });

    container.innerHTML = html;
    container.scrollTop = container.scrollHeight;
}

// Background poll if widget open
setInterval(() => {
    if (floatChatOpen) {
        pollFloatingMessages();
    }
}, 4000);
</script>
