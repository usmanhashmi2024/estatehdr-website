<?php
/**
 * Estate HDR — Unified Enterprise Audit Logging System
 * Section 19 Compliance: Immutable append-only audit trail for sensitive mutations
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';

if (!function_exists('logAuditEvent')) {
    function logAuditEvent(string $action, string $target = '', array $details = [], ?string $userId = null, string $tenantId = 'ehdr_main'): bool {
        $actorId = $userId;
        $actorEmail = 'system';
        $actorRole = 'system';

        if (!$actorId) {
            if (isAdminLoggedIn()) {
                $adm = currentAdminUser();
                $actorId = $adm['id'] ?? 'admin';
                $actorEmail = $adm['email'] ?? 'admin@estatehdr.com';
                $actorRole = $adm['role'] ?? 'admin';
            } elseif (isLoggedIn()) {
                $usr = currentUser();
                $actorId = $usr['id'] ?? 'client';
                $actorEmail = $usr['email'] ?? 'client@estatehdr.com';
                $actorRole = 'client';
            } else {
                $actorId = 'anonymous';
            }
        }

        // Sanitize sensitive fields from details
        $sensitiveKeys = ['password', 'password_hash', 'current_password', 'new_password', 'confirm_password', 'token', 'csrf_token', 'secret'];
        $cleanDetails = [];
        foreach ($details as $k => $v) {
            if (in_array(strtolower($k), $sensitiveKeys, true)) {
                $cleanDetails[$k] = '[REDACTED]';
            } else {
                $cleanDetails[$k] = $v;
            }
        }

        $entry = [
            'event_id'    => 'evt_' . bin2hex(random_bytes(8)),
            'timestamp'   => date('c'),
            'tenant_id'   => $tenantId,
            'actor_id'    => $actorId,
            'actor_email' => $actorEmail,
            'actor_role'  => $actorRole,
            'action'      => $action,
            'target'      => $target,
            'ip'          => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
            'user_agent'  => substr($_SERVER['HTTP_USER_AGENT'] ?? 'CLI/Internal', 0, 255),
            'details'     => $cleanDetails
        ];

        $logFile = DATA_PATH . '/audit_logs.json';
        $logs = [];
        if (file_exists($logFile)) {
            $content = file_get_contents($logFile);
            $logs = json_decode($content, true) ?: [];
        }

        // Prepend new event (newest first), capped to 5000 entries
        array_unshift($logs, $entry);
        if (count($logs) > 5000) {
            $logs = array_slice($logs, 0, 5000);
        }

        $tmpFile = $logFile . '.' . bin2hex(random_bytes(4)) . '.tmp';
        if (file_put_contents($tmpFile, json_encode($logs, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX) !== false) {
            return @rename($tmpFile, $logFile);
        }
        return false;
    }
}

if (!function_exists('getAuditLogs')) {
    function getAuditLogs(int $limit = 100, array $filters = []): array {
        $logFile = DATA_PATH . '/audit_logs.json';
        if (!file_exists($logFile)) return [];
        $logs = json_decode(file_get_contents($logFile), true) ?: [];

        if (!empty($filters)) {
            $logs = array_filter($logs, function($l) use ($filters) {
                if (isset($filters['action']) && $l['action'] !== $filters['action']) return false;
                if (isset($filters['actor_id']) && $l['actor_id'] !== $filters['actor_id']) return false;
                if (isset($filters['tenant_id']) && $l['tenant_id'] !== $filters['tenant_id']) return false;
                return true;
            });
        }

        return array_slice($logs, 0, $limit);
    }
}
