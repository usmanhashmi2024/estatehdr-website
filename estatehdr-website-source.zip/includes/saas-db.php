<?php
/**
 * Estate HDR — SaaS Production Management & RBAC Data Engine
 * High-volume order pipeline, Privacy Shielding, Revisions, HR & Audit logs
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

define('SAAS_ORDERS_FILE', rtrim(DATA_PATH, '/\\') . '/saas_orders.json');
define('SAAS_EMPLOYEES_FILE', rtrim(DATA_PATH, '/\\') . '/saas_employees.json');
define('SAAS_ATTENDANCE_FILE', rtrim(DATA_PATH, '/\\') . '/saas_attendance.json');
define('SAAS_AUDIT_FILE', rtrim(DATA_PATH, '/\\') . '/saas_audit_logs.json');

// ── 1. Orders Engine ──────────────────────────────────────────────────────────

/**
 * Auto-bridges client portal orders (from data/orders/*.json) into saas_orders.json
 * Ensures newly placed client or proxy orders immediately appear in Supervisor's queue!
 */
function syncLegacyOrdersToSaaS(): array {
    if (!defined('ORDERS_PATH') || !is_dir(ORDERS_PATH)) return [];
    
    $saasFile = SAAS_ORDERS_FILE;
    $saasOrders = [];
    if (file_exists($saasFile)) {
        $raw = json_decode(file_get_contents($saasFile), true);
        if (is_array($raw)) $saasOrders = $raw;
    }
    
    // Map of existing SaaS orders by ID
    $saasMap = [];
    foreach ($saasOrders as $idx => $so) {
        $saasMap[$so['id']] = $idx;
    }
    
    $legacyFiles = glob(ORDERS_PATH . '*.json');
    $dirty = false;
    
    // Load client users to map names/emails
    $users = function_exists('getUsers') ? getUsers() : [];
    $userMap = [];
    foreach ($users as $u) {
        $userMap[$u['id']] = $u;
    }
    
    foreach ($legacyFiles as $lf) {
        $data = json_decode(file_get_contents($lf), true);
        if (empty($data) || empty($data['id'])) continue;
        
        $orderId = $data['id'];
        $client = $userMap[$data['user_id'] ?? ''] ?? null;
        $isOrderTrial = !empty($data['is_trial']) || (($data['order_type'] ?? '') === 'free_trial') || (($data['service_type'] ?? '') === 'free_trial');
        
        if (!isset($saasMap[$orderId])) {
            // New order placed from Client Portal or Admin Proxy! Add to SaaS Orders
            $newSaas = [
                'id'                  => $orderId,
                'client_id'           => $data['user_id'] ?? 'unknown',
                'client_name'         => $client['name'] ?? 'Client',
                'client_email'        => $client['email'] ?? ($client['username'] ?? 'client@estatehdr.com'),
                'client_phone'        => $client['phone'] ?? '+44 770 606 8176',
                'client_company'      => $client['company'] ?? 'Real Estate Media',
                'property_name'       => $data['property_name'] ?? 'Untitled Property',
                'property_ref'        => 'PROP-' . strtoupper(substr(preg_replace('/[^a-zA-Z0-9]/', '', $data['property_name'] ?? 'PR'), 0, 6)),
                'editing_type'        => $data['service_type'] ?? 'HDR Photo Editing',
                'photo_count'         => (int)($data['raw_images_count'] ?? 10),
                'input_storage_path'  => $data['cloud_link'] ?? '',
                'output_storage_path' => '',
                'delivery_url'        => '',
                'status'              => ($data['status'] === 'delivered' || $data['status'] === 'completed') ? 'sent_client' : 'new',
                'priority'            => $isOrderTrial ? 'high' : 'normal',
                'is_trial'            => $isOrderTrial,
                'order_type'          => $isOrderTrial ? 'free_trial' : 'live_order',
                'deadline'            => date('c', strtotime($data['created_at'] ?? 'now') + 86400),
                'assigned_tl_id'      => '',
                'assigned_tl_name'    => '',
                'assigned_editor_id'  => '',
                'assigned_editor_name'=> '',
                'instructions'        => $data['notes'] ?? '',
                'price_amount'        => $isOrderTrial ? 0.00 : (float)($data['billed_amount'] ?? (($data['raw_images_count'] ?? 10) * 1.0)),
                'currency'            => 'USD',
                'created_at'          => $data['created_at'] ?? date('c'),
                'updated_at'          => $data['updated_at'] ?? date('c'),
                'revisions'           => [],
                'deliveries'          => [],
                'communications'      => []
            ];
            $saasOrders[] = $newSaas;
            $saasMap[$orderId] = count($saasOrders) - 1;
            $dirty = true;
        } else {
            // Check if existing SaaS order trial status needs synchronization with disk order
            $idx = $saasMap[$orderId];
            if ($isOrderTrial && (empty($saasOrders[$idx]['is_trial']) || (float)($saasOrders[$idx]['price_amount'] ?? 0) > 0)) {
                $saasOrders[$idx]['is_trial'] = true;
                $saasOrders[$idx]['order_type'] = 'free_trial';
                $saasOrders[$idx]['price_amount'] = 0.00;
                $dirty = true;
            } elseif (!$isOrderTrial && !empty($saasOrders[$idx]['is_trial']) && (($data['order_type'] ?? '') === 'live_order')) {
                $saasOrders[$idx]['is_trial'] = false;
                $saasOrders[$idx]['order_type'] = 'live_order';
                $dirty = true;
            }
        }
    }
    
        // Also Auto-Bridge Free Trial Leads (from data/leads.json) into SaaS Orders!
    $leadsFile = defined('LEADS_FILE') ? LEADS_FILE : (rtrim(DATA_PATH, '/\\') . '/leads.json');
    if (file_exists($leadsFile)) {
        $leads = json_decode(file_get_contents($leadsFile), true);
        if (is_array($leads)) {
            foreach ($leads as $lead) {
                if (empty($lead) || empty($lead['id'])) continue;
                $trialOrderId = 'TRIAL-' . strtoupper($lead['id']);
                
                if (!isset($saasMap[$trialOrderId])) {
                    $newTrialSaas = [
                        'id'                  => $trialOrderId,
                        'lead_id'             => $lead['id'],
                        'client_id'           => 'lead-' . $lead['id'],
                        'client_name'         => $lead['name'] ?? 'Trial Client',
                        'client_email'        => strtolower($lead['email'] ?? ''),
                        'client_phone'        => $lead['phone'] ?? $lead['whatsapp'] ?? '+44 770 606 8176',
                        'client_company'      => 'Free Trial (No Signup)',
                        'property_name'       => '[Free Trial] ' . ($lead['name'] ?? 'Sample') . ' - ' . ($lead['service'] ?? 'HDR Photo Editing'),
                        'property_ref'        => 'TRIAL-' . strtoupper(substr(preg_replace('/[^a-zA-Z0-9]/', '', $lead['name'] ?? 'TR'), 0, 6)),
                        'editing_type'        => $lead['service'] ?? 'HDR Photo Editing',
                        'photo_count'         => 3,
                        'input_storage_path'  => $lead['cloud_link'] ?? '',
                        'output_storage_path' => '',
                        'delivery_url'        => $lead['final_cloud_link'] ?? '',
                        'status'              => (($lead['status'] ?? '') === 'delivered') ? 'sent_client' : 'new',
                        'priority'            => 'high',
                        'is_trial'            => true,
                        'is_proxy'            => true,
                        'order_type'          => 'Free Trial Lead (No Signup)',
                        'deadline'            => date('c', strtotime($lead['created_at'] ?? 'now') + 86400),
                        'assigned_tl_id'      => '',
                        'assigned_tl_name'    => '',
                        'assigned_editor_id'  => '',
                        'assigned_editor_name'=> '',
                        'instructions'        => 'Landing Page Free Trial Request. Instructions/Notes: ' . ($lead['message'] ?? 'Please process 3 free sample photos with premium HDR blending and clear window pulls.'),
                        'price_amount'        => 0.00,
                        'currency'            => 'USD',
                        'created_at'          => $lead['created_at'] ?? date('c'),
                        'updated_at'          => $lead['updated_at'] ?? date('c'),
                        'revisions'           => [],
                        'deliveries'          => [],
                        'communications'      => []
                    ];
                    $saasOrders[] = $newTrialSaas;
                    $saasMap[$trialOrderId] = count($saasOrders) - 1;
                    $dirty = true;
                }
            }
        }
    }

    if ($dirty) {
        atomicWriteJson($saasFile, array_values($saasOrders));
    }
    return $saasOrders;
}

function getSaaSOrders(): array {
    return syncLegacyOrdersToSaaS();
}

function saveSaaSOrders(array $orders): bool {
    return atomicWriteJson(SAAS_ORDERS_FILE, array_values($orders));
}

function getSaaSOrderById(string $orderId): ?array {
    $orders = getSaaSOrders();
    foreach ($orders as $o) {
        if ($o['id'] === $orderId) return $o;
    }
    return null;
}

/**
 * Privacy Shielding Engine
 * Strips confidential client contact, billing, and rates for Editors and Team Leads
 */
function maskOrderForRole(array $order, array $userRoles): array {
    $isPrivileged = in_array('owner', $userRoles) || in_array('super_admin', $userRoles) || in_array('manager', $userRoles) || in_array('supervisor', $userRoles);
    
    if (!$isPrivileged) {
        // Strip client confidential data
        unset($order['client_email']);
        unset($order['client_phone']);
        unset($order['client_company']);
        unset($order['price_amount']);
        unset($order['currency']);
        unset($order['billing_status']);
    }
    return $order;
}

function updateSaaSOrderStatus(string $orderId, string $newStatus, string $userId, string $userName, string $notes = ''): bool {
    $orders = getSaaSOrders();
    foreach ($orders as &$o) {
        if ($o['id'] === $orderId) {
            $oldStatus = $o['status'] ?? 'new';
            $o['status'] = $newStatus;
            $o['updated_at'] = date('c');
            
            if ($newStatus === 'in_process' && empty($o['started_at'])) {
                $o['started_at'] = date('c');
            }
            if ($newStatus === 'submitted_qa') {
                $o['submitted_at'] = date('c');
            }
            if ($newStatus === 'approved') {
                $o['approved_at'] = date('c');
            }
            if ($newStatus === 'sent_client') {
                $o['delivered_at'] = date('c');
            }
            if ($newStatus === 'completed') {
                $o['completed_at'] = date('c');
            }

            // If transitioned to sent_client or completed, dispatch luxury delivery & invoice email
            if (in_array($newStatus, ['sent_client', 'completed']) && !in_array($oldStatus, ['sent_client', 'completed'])) {
                if (function_exists('sendOrderDeliveryInvoiceEmail')) {
                    $billed = (float)($o['price_amount'] ?? 0.0);
                    $dl = $o['delivery_url'] ?? '';
                    $fc = (int)($o['final_image_count'] ?? ($o['photo_count'] ?? 1));
                    sendOrderDeliveryInvoiceEmail($o, $billed, $dl, $fc);
                }
            }
            
            logSaaSEvent($userId, "Order status changed: $oldStatus -> $newStatus", $orderId, ['notes' => $notes]);
            return saveSaaSOrders($orders);
        }
    }
    return false;
}

function addOrderRevision(string $orderId, string $requestedBy, string $instructions, string $category = 'General'): bool {
    $orders = getSaaSOrders();
    foreach ($orders as &$o) {
        if ($o['id'] === $orderId) {
            if (!isset($o['revisions'])) $o['revisions'] = [];
            $revNum = count($o['revisions']) + 1;
            $o['revisions'][] = [
                'revision_number' => $revNum,
                'requested_by'    => $requestedBy,
                'requested_at'    => date('c'),
                'instructions'    => trim($instructions),
                'category'        => $category,
                'status'          => 'pending'
            ];
            $o['status'] = 'revision_required';
            $o['updated_at'] = date('c');
            logSaaSEvent($requestedBy, "Revision #$revNum requested (Category: $category)", $orderId, ['instructions' => $instructions]);
            return saveSaaSOrders($orders);
        }
    }
    return false;
}

function logOrderDelivery(string $orderId, string $method, string $deliveryUrl, string $sentBy, string $recipient): bool {
    $orders = getSaaSOrders();
    foreach ($orders as &$o) {
        if ($o['id'] === $orderId) {
            if (!isset($o['deliveries'])) $o['deliveries'] = [];
            $o['deliveries'][] = [
                'delivery_number' => count($o['deliveries']) + 1,
                'sent_by'         => $sentBy,
                'sent_at'         => date('c'),
                'method'          => $method, // 'Email' or 'WhatsApp'
                'recipient'       => $recipient,
                'delivery_url'    => $deliveryUrl,
                'status'          => 'Sent'
            ];
            $o['status'] = 'sent_client';
            $o['delivery_url'] = $deliveryUrl;
            $o['updated_at'] = date('c');
            logSaaSEvent($sentBy, "Delivery sent via $method to $recipient", $orderId, ['delivery_url' => $deliveryUrl]);
            $saved = saveSaaSOrders($orders);
            if ($saved && function_exists('sendOrderDeliveryInvoiceEmail')) {
                $billed = (float)($o['price_amount'] ?? 0.0);
                $fc = (int)($o['final_image_count'] ?? ($o['photo_count'] ?? 1));
                sendOrderDeliveryInvoiceEmail($o, $billed, $deliveryUrl, $fc);
            }
            return $saved;
        }
    }
    return false;
}

// ── 2. HR & Employee Engine ───────────────────────────────────────────────────
function getSaaSEmployees(): array {
    if (!file_exists(SAAS_EMPLOYEES_FILE)) return [];
    $data = json_decode(file_get_contents(SAAS_EMPLOYEES_FILE), true);
    return is_array($data) ? $data : [];
}

function saveSaaSEmployees(array $employees): bool {
    return atomicWriteJson(SAAS_EMPLOYEES_FILE, array_values($employees));
}

function getSaaSAttendance(string $date): array {
    if (!file_exists(SAAS_ATTENDANCE_FILE)) return [];
    $data = json_decode(file_get_contents(SAAS_ATTENDANCE_FILE), true);
    if (!is_array($data)) return [];
    return array_values(array_filter($data, fn($a) => ($a['date'] ?? '') === $date));
}

function saveSaaSAttendanceRecord(array $record): bool {
    $all = file_exists(SAAS_ATTENDANCE_FILE) ? json_decode(file_get_contents(SAAS_ATTENDANCE_FILE), true) : [];
    if (!is_array($all)) $all = [];
    
    $found = false;
    foreach ($all as &$a) {
        if ($a['id'] === $record['id']) {
            $a = $record;
            $found = true;
            break;
        }
    }
    if (!$found) {
        $all[] = $record;
    }
    return atomicWriteJson(SAAS_ATTENDANCE_FILE, array_values($all));
}

// ── 3. Append-Only Audit Logging ─────────────────────────────────────────────
function logSaaSEvent(string $userId, string $action, string $targetId, array $details = []): bool {
    $logs = file_exists(SAAS_AUDIT_FILE) ? json_decode(file_get_contents(SAAS_AUDIT_FILE), true) : [];
    if (!is_array($logs)) $logs = [];
    
    $logs[] = [
        'id'        => 'LOG-' . uniqid(),
        'timestamp' => date('c'),
        'user_id'   => $userId,
        'action'    => $action,
        'target_id' => $targetId,
        'ip'        => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
        'details'   => $details
    ];
    // Keep last 5000 events
    if (count($logs) > 5000) $logs = array_slice($logs, -5000);
    return atomicWriteJson(SAAS_AUDIT_FILE, $logs);
}
// ── 4. Job Locking Engine ─────────────────────────────────────────────────────

/**
 * Lock a job to a specific editor so no other editor can open it concurrently.
 * Returns ['success' => bool, 'message' => string]
 */
function lockJobForEditor(string $orderId, string $editorId, string $editorName): array {
    $orders = getSaaSOrders();
    foreach ($orders as &$o) {
        if ($o['id'] !== $orderId) continue;

        // If already locked by someone else, reject
        $lockedBy = $o['locked_by_id'] ?? '';
        if ($lockedBy && $lockedBy !== $editorId) {
            $lockedAt = $o['locked_at'] ?? '';
            // Allow override after 4 hours (stale lock)
            if ($lockedAt && (time() - strtotime($lockedAt)) < 4 * 3600) {
                return ['success' => false, 'locked_by_name' => $o['locked_by_name'] ?? 'Another Editor'];
            }
        }

        $o['locked_by_id']   = $editorId;
        $o['locked_by_name'] = $editorName;
        $o['locked_at']      = date('c');
        // Transition to in_process as soon as locked
        if (in_array($o['status'] ?? '', ['assigned_editor', 'new', 'received', 'assigned_tl'])) {
            $o['status']     = 'in_process';
            $o['started_at'] = date('c');
        }
        $o['updated_at'] = date('c');
        saveSaaSOrders($orders);
        logSaaSEvent($editorId, "Job locked & started by $editorName", $orderId);
        return ['success' => true];
    }
    return ['success' => false, 'locked_by_name' => 'Unknown'];
}

function unlockJob(string $orderId): bool {
    $orders = getSaaSOrders();
    foreach ($orders as &$o) {
        if ($o['id'] === $orderId) {
            $o['locked_by_id']   = '';
            $o['locked_by_name'] = '';
            $o['locked_at']      = '';
            $o['updated_at']     = date('c');
            return saveSaaSOrders($orders);
        }
    }
    return false;
}

/**
 * Submit job for QA (works for both first submission and after-revision resubmission).
 * isRevisionResubmit=true tags it as REVISION DONE so Team Lead sees it differently.
 */
function submitJobForQA(string $orderId, string $editorId, string $editorName, string $outputPath, bool $isRevisionResubmit = false, int $finalImageCount = 0): bool {
    $orders = getSaaSOrders();
    foreach ($orders as &$o) {
        if ($o['id'] !== $orderId) continue;

        $o['output_storage_path']    = $outputPath;
        if ($finalImageCount > 0) {
            $o['final_image_count'] = $finalImageCount;
            // Append to monthly performance log
            $month = date('Y-m');
            if (!isset($o['performance_log'])) $o['performance_log'] = [];
            $o['performance_log'][$month] = ($o['performance_log'][$month] ?? 0) + $finalImageCount;
        }
        $o['status']                 = $isRevisionResubmit ? 'resubmitted' : 'submitted_qa';
        $o['submitted_at']           = date('c');
        $o['updated_at']             = date('c');
        $o['is_revision_resubmit']   = $isRevisionResubmit;
        // Mark the last revision as completed
        if ($isRevisionResubmit && !empty($o['revisions'])) {
            $last = count($o['revisions']) - 1;
            $o['revisions'][$last]['status']       = 'revision_done';
            $o['revisions'][$last]['completed_at'] = date('c');
        }
        // Release lock after submission
        $o['locked_by_id']   = '';
        $o['locked_by_name'] = '';
        $o['locked_at']      = '';

        $tag = $isRevisionResubmit ? 'REVISION DONE - Resubmitted for QA' : 'Submitted for QA';
        logSaaSEvent($editorId, "$tag by $editorName", $orderId, ['output_path' => $outputPath]);
        return saveSaaSOrders($orders);
    }
    return false;
}


/**
 * Records real-time online activity timestamp for logged in staff user
 */
function recordStaffActivity(string $userId): void {
    if (empty($userId)) return;
    $empFile = SAAS_EMPLOYEES_FILE;
    if (!file_exists($empFile)) return;
    
    $employees = json_decode(file_get_contents($empFile), true);
    if (!is_array($employees)) return;
    
    $changed = false;
    foreach ($employees as &$e) {
        if (($e['user_id'] ?? '') === $userId || ($e['id'] ?? '') === $userId) {
            $e['last_active_at'] = date('c');
            $changed = true;
            break;
        }
    }
    if ($changed) {
        atomicWriteJson($empFile, $employees);
    }
}

/**
 * Evaluates real-time online presence status (Online within 15 mins vs Offline)
 */
function getStaffOnlinePresence(array $employee): array {
    $lastActive = $employee['last_active_at'] ?? '';
    if (empty($lastActive)) {
        return [
            'is_online'    => false,
            'label'        => 'Offline',
            'badge_class'  => 'bg-gray-500/20 text-gray-400 border-gray-500/30',
            'dot_class'    => 'bg-gray-500',
            'time_ago'     => 'Offline'
        ];
    }
    
    $diffSec = time() - strtotime($lastActive);
    if ($diffSec <= 900) { // Active in last 15 mins
        return [
            'is_online'    => true,
            'label'        => 'Online Now',
            'badge_class'  => 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40',
            'dot_class'    => 'bg-emerald-400 animate-pulse',
            'time_ago'     => 'Active now'
        ];
    } elseif ($diffSec < 3600) {
        $mins = max(1, round($diffSec / 60));
        return [
            'is_online'    => false,
            'label'        => 'Away',
            'badge_class'  => 'bg-amber-500/20 text-amber-300 border-amber-500/30',
            'dot_class'    => 'bg-amber-400',
            'time_ago'     => $mins . 'm ago'
        ];
    } else {
        $hrs = max(1, round($diffSec / 3600));
        return [
            'is_online'    => false,
            'label'        => 'Offline',
            'badge_class'  => 'bg-gray-500/20 text-gray-400 border-gray-500/30',
            'dot_class'    => 'bg-gray-500',
            'time_ago'     => $hrs . 'h ago'
        ];
    }
}
// ── 5. HR Candidate Contracts & Signed NDAs Engine ───────────────────────────
define('SAAS_HR_CONTRACTS_FILE', rtrim(DATA_PATH, '/\\') . '/hr_contracts.json');
define('SAAS_HR_SIGNED_DOCS_DIR', rtrim(DATA_PATH, '/\\') . '/hr_signed_docs/');

/**
 * Returns role-specific NDA clauses and scope of work for contracts
 */
function getRoleSpecificNDAClauses(string $role): array {
    return match($role) {
        'Photo Editor', 'Senior Photo Editor', 'Freelance Editor' => [
            'title' => 'Photo Editor Media & Raw Bracket Confidentiality',
            'duties' => 'Responsible for professional HDR multi-bracket exposure fusion, flash-ambient compositing, sky replacements, grass enhancement, window pull clarity, and delivering pixel-perfect architectural images under strict 24-hour turnaround SLA.',
            'clauses' => [
                'Raw Media Exclusivity: All unprocessed RAW brackets, HDR exposure sets, and flash frames uploaded by clients remain strictly confidential and must never be copied, shared, or retained on personal drives.',
                'Client Contact Protection: Photo Editors must never contact, solicit, or engage with real estate agents or photographers directly under any circumstances.',
                'Preset & Action Proprietary Protection: Custom Estate HDR Photoshop actions, Sky Replacement libraries, and color grading LUTs are proprietary studio property.',
                'Portfolio Restrictions: No client unedited or raw property images may be publicly displayed in personal portfolios without explicit written management consent.'
            ]
        ],
        'Team Lead' => [
            'title' => 'Team Lead Quality Assurance & Workflow Secrecy',
            'duties' => 'Responsible for real-time quality assurance inspection, color accuracy verification, managing editor assignment queues, monitoring shift productivity, and client revision resolution.',
            'clauses' => [
                'Quality Control Thresholds: Team Leads hold proprietary access to Estate HDR quality benchmark rubrics and batch inspection parameters.',
                'Editor Allocation Metrics: Internal workload distribution, editor performance ratings, and speed capacity metrics are strictly confidential.',
                'Revision Notes & Client Feedback: Feedback logs and revision dispute records must not be shared outside authorized management channels.',
                'Delivery Access Tokens: Team Leads with output cloud access must maintain strict credential protection and two-factor authentication.'
            ]
        ],
        'Supervisor' => [
            'title' => 'Supervisor Production Pipeline & Client Data Protection',
            'duties' => 'Responsible for overseeing entire production shift operations, managing client delivery timelines, quality audit protocols, shift scheduling, and escalation resolution.',
            'clauses' => [
                'Client Cloud Storage Access: Supervisors holding Dropbox, Google Drive, and API delivery tokens must ensure zero unauthorized data leakage.',
                'Turnaround Time & Capacity Analytics: Production volume statistics, shift output counts, and corporate SLA metrics are trade secrets.',
                'Client Identity Shield: Client billing details, corporate contracts, and wholesale volume pricing are strictly restricted.'
            ]
        ],
        'Production Manager' => [
            'title' => 'Operations Manager Corporate Non-Compete & Trade Secrets',
            'duties' => 'Responsible for global studio operations, capacity planning, team lead coordination, client relations, and continuous workflow optimization.',
            'clauses' => [
                'Corporate Client Database: The Manager holds access to the full institutional client roster. Direct solicitation or competing services are strictly prohibited for 24 months post-employment.',
                'Operational Financials & Margins: Studio operational costs, profit margins, editor compensation structures, and supplier agreements are confidential.',
                'Workflow Automation & Proprietary Systems: Estate HDR SaaS architecture and automation workflows are proprietary intellectual property.'
            ]
        ],
        'SEO Manager' => [
            'title' => 'SEO & Digital Strategy Confidentiality',
            'duties' => 'Responsible for search ranking strategies, organic traffic growth, CMS content management, technical SEO auditing, backlink campaigns, and keyword optimization.',
            'clauses' => [
                'Search Algorithm Strategy: Keyword research data, domain ranking strategies, backlink networks, and organic growth blueprints are proprietary.',
                'CMS Access Credentials: All administrative credentials for web pages, blog CMS, and sitemaps must remain encrypted.'
            ]
        ],
        'Quality Assurance Specialist', 'QA Specialist' => [
            'title' => 'QA Inspection & Benchmark Secrecy',
            'duties' => 'Responsible for rigorous multi-point inspection of retouched photos prior to client dispatch, ensuring zero halos, accurate vertical alignment, and Fotello architectural standards.',
            'clauses' => [
                'Benchmark Criteria: Inspection scoring sheets, error tolerance thresholds, and internal audit logs are proprietary.',
                'Dispute Confidentiality: Client dispute escalations and internal feedback records must be handled with strict confidentiality.'
            ]
        ],
        'Virtual Staging Artist' => [
            'title' => '3D Staging Assets & Catalog Confidentiality',
            'duties' => 'Responsible for 3D furniture placement, architectural interior staging, scale accuracy, texture realism, and photorealistic rendering.',
            'clauses' => [
                '3D Asset Libraries: Proprietary 3D models, textures, and staging presets are licensed strictly for Estate HDR production.',
                'Property Floorplans: Client architectural floorplans, dimensions, and structural renders must remain confidential.'
            ]
        ],
        default => [
            'title' => 'General Employee Non-Disclosure & Privacy Shield',
            'duties' => 'Responsible for assigned operational duties in accordance with Estate HDR standard operating procedures, quality benchmarks, and professional ethics.',
            'clauses' => [
                'Data Protection: All client properties, photos, pricing, and internal studio operations are strictly confidential.',
                'Non-Circumvention: Employees agree not to bypass the company to provide direct services to Estate HDR clients.',
                'Intellectual Property: All work created during employment belongs exclusively to Estate HDR.'
            ]
        ]
    };
}

function getHRContracts(): array {
    if (!file_exists(SAAS_HR_CONTRACTS_FILE)) return [];
    $data = json_decode(file_get_contents(SAAS_HR_CONTRACTS_FILE), true);
    return is_array($data) ? $data : [];
}

function saveHRContracts(array $contracts): bool {
    return atomicWriteJson(SAAS_HR_CONTRACTS_FILE, array_values($contracts));
}

function getHRContractByToken(string $token): ?array {
    $token = trim($token);
    if (empty($token)) return null;
    $contracts = getHRContracts();
    foreach ($contracts as $c) {
        if (($c['token'] ?? '') === $token) {
            return $c;
        }
    }
    return null;
}

function getHRContractById(string $id): ?array {
    $id = trim($id);
    if (empty($id)) return null;
    $contracts = getHRContracts();
    foreach ($contracts as $c) {
        if (($c['id'] ?? '') === $id) {
            return $c;
        }
    }
    return null;
}

/**
 * Saves a signed contract into its own dedicated standalone file in data/hr_signed_docs/
 * and updates the central index.
 */
function saveHRSignedDocument(array $contract): bool {
    if (!is_dir(SAAS_HR_SIGNED_DOCS_DIR)) {
        @mkdir(SAAS_HR_SIGNED_DOCS_DIR, 0755, true);
    }
    
    // Dedicated standalone signed document file per user/contract
    $cleanName = strtolower(preg_replace('/[^a-zA-Z0-9_-]/', '_', $contract['candidate_name'] ?? 'candidate'));
    $fileName = $cleanName . '_' . $contract['id'] . '.json';
    $filePath = SAAS_HR_SIGNED_DOCS_DIR . $fileName;
    
    $contract['signed_file'] = 'hr_signed_docs/' . $fileName;
    atomicWriteJson($filePath, $contract);
    
    // Update central index
    $all = getHRContracts();
    $found = false;
    foreach ($all as &$c) {
        if (($c['id'] ?? '') === $contract['id']) {
            $c = $contract;
            $found = true;
            break;
        }
    }
    if (!$found) {
        array_unshift($all, $contract);
    }
    return saveHRContracts($all);
}
