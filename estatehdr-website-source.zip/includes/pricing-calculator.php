<?php
/**
 * Estate HDR — Ultra-Luxury Interactive Pricing Calculator Component
 * Enterprise real-time estimator with multi-currency conversion, multi-service bundles,
 * volume discount visualizer, turnaround speed selector, and 1-click order bridging.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/pricing-engine.php';

$currencies = PricingEngine::CURRENCIES;
$baseRates = PricingEngine::BASE_RATES;
?>

<!-- ── LUXURY PRICING CALCULATOR WRAPPER ── -->
<div id="pricing-calculator-widget" class="relative max-w-7xl mx-auto">
  <!-- Ambient Gold Glow Backdrops -->
  <div class="absolute -top-12 left-1/4 w-96 h-96 bg-gold/10 rounded-full blur-3xl pointer-events-none -z-10"></div>
  <div class="absolute -bottom-12 right-1/4 w-96 h-96 bg-gold/5 rounded-full blur-3xl pointer-events-none -z-10"></div>

  <!-- ── SPECIAL PROMOTIONAL OFFER LIVE BANNER ── -->
  <div class="mb-6 p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-amber-950/50 via-[#161724] to-dark-card border-2 border-gold/50 shadow-2xl relative overflow-hidden">
    <div class="absolute -right-12 -top-12 w-48 h-48 bg-gold/15 rounded-full blur-3xl pointer-events-none"></div>
    <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 relative z-10">
      <div class="space-y-2">
        <div class="flex items-center gap-2">
          <span class="px-3 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-gold text-dark shadow-sm">
            🔥 Limited Time Agency Offer Active
          </span>
          <span class="text-xs font-bold text-amber-400">Exclusive Promotional Tier</span>
        </div>
        <h2 class="text-xl sm:text-2xl lg:text-3xl font-black text-white">
          HDR Photo Retouching: Was <span class="line-through text-gray-500 font-bold">$0.80</span> &rarr; <span class="text-emerald-400 font-black text-2xl sm:text-3xl lg:text-4xl">$0.60</span> <span class="text-sm font-normal text-gray-400">/ photo</span>
        </h2>
        <div class="text-xs sm:text-sm text-gray-200 leading-relaxed space-y-1">
          <div>
            📊 <strong>Tiered Volume Discounts:</strong> 1–24 @ <strong>$0.60</strong> &bull; 25–49 @ <strong>$0.55</strong> &bull; 50–99 @ <strong>$0.50</strong> &bull; 100+ @ <strong>$0.45 / photo</strong>.
          </div>
          <div class="text-gold font-bold flex items-center gap-1.5 flex-wrap">
            <span>🎁 COMPLIMENTARY BONUS:</span>
            <span>Every single property order includes <strong>1 FREE Day-to-Dusk (Virtual Twilight) Hero Photo</strong>!</span>
            <span class="text-[11px] text-gray-400 font-normal">(Normally $4–$15 at other studios, $0 with Estate HDR).</span>
          </div>
        </div>
      </div>
      <div class="shrink-0 flex items-center gap-2">
        <div class="px-4 py-2.5 rounded-2xl bg-emerald-500/15 border border-emerald-500/40 text-center">
          <div class="text-[10px] uppercase font-bold text-gray-400">Instant Savings</div>
          <div class="text-base font-black text-emerald-400 font-mono">SAVE UP TO 44%</div>
        </div>
      </div>
    </div>
  </div>

  <!-- Top Controls Bar: Currency Switcher & Turnaround SLA -->
  <div class="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 sm:p-6 rounded-2xl bg-[#111118]/90 border border-gold/30 shadow-2xl backdrop-blur-xl mb-8">
    <div class="flex items-center gap-3">
      <div class="w-10 h-10 rounded-xl bg-gold/10 border border-gold/40 flex items-center justify-center text-gold flex-shrink-0">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
      </div>
      <div>
        <div class="text-xs font-black text-gold tracking-normal font-bold">Interactive Estimator Studio</div>
        <div class="text-sm font-bold text-white">Select Services &amp; Instant Live Quote</div>
      </div>
    </div>

    <!-- Currency Selector Pills -->
    <div class="flex items-center gap-1.5 p-1 bg-dark/80 rounded-xl border border-dark-border">
      <span class="text-xs font-semibold text-gray-400 px-2 hidden md:inline">Currency:</span>
      <?php foreach ($currencies as $currKey => $c): ?>
      <button type="button" 
              onclick="window.ehdrCalc.setCurrency('<?= $currKey ?>')" 
              data-calc-curr="<?= $currKey ?>"
              class="calc-curr-btn px-2.5 py-1.5 rounded-lg text-xs font-black transition-all <?= $currKey === 'USD' ? 'bg-gold text-dark shadow-sm' : 'text-gray-400 hover:text-white' ?>">
        <?= $currKey ?> (<?= trim($c['symbol']) ?>)
      </button>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Main Calculator 2-Column Grid -->
  <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
    
    <!-- ═════════════════════════════════════════════════════════════ -->
    <!-- LEFT COLUMN: INTERACTIVE CONFIGURATION (7 COLS)               -->
    <!-- ═════════════════════════════════════════════════════════════ -->
    <div class="lg:col-span-7 space-y-6">

      <!-- 1. Primary Service Selector Grid -->
      <div class="p-6 rounded-2xl bg-dark-card border border-dark-border/80 shadow-xl space-y-4">
        <div class="flex items-center justify-between">
          <label class="text-sm font-bold text-white flex items-center gap-2">
            <span class="w-5 h-5 rounded-full bg-gold/20 text-gold flex items-center justify-center text-xs font-bold">1</span>
            <span>Choose Primary Service</span>
          </label>
          <span class="text-xs text-gold font-bold">Includes 24h SLA + Free Revisions</span>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <!-- Service Option 1: HDR (Promotional Tier Active) -->
          <button type="button" 
                  onclick="window.ehdrCalc.setService('hdr')" 
                  data-calc-service="hdr"
                  class="calc-service-btn active p-4 rounded-xl text-left border transition-all relative flex flex-col justify-between bg-gold/10 border-gold shadow-[0_0_15px_rgba(201,168,76,0.15)]">
            <div class="flex items-center justify-between mb-2">
              <span class="text-2xl">📸</span>
              <span class="px-2 py-0.5 rounded-lg bg-emerald-500 text-dark text-xs font-black uppercase tracking-wider">SAVE 25%</span>
            </div>
            <div>
              <div class="text-sm font-bold text-white">HDR Blending</div>
              <div class="text-xs text-gray-400 mt-0.5">Flambient + Window Pulls</div>
              <div class="text-xs font-black text-gold mt-2 flex items-baseline gap-1.5">
                <span class="text-[11px] text-gray-500 line-through font-bold" data-reg-rate-hdr>$0.80</span>
                <span class="text-emerald-400 font-black text-sm" data-rate-hdr>$0.60</span>
                <span class="text-xs font-normal text-gray-400">/ photo</span>
              </div>
              <div class="text-[10px] text-gold font-bold mt-1 flex items-center gap-1">
                <span>🎁</span> <span>+1 FREE Day-to-Dusk Hero</span>
              </div>
            </div>
          </button>

          <!-- Service Option 2: Virtual Staging -->
          <button type="button" 
                  onclick="window.ehdrCalc.setService('staging')" 
                  data-calc-service="staging"
                  class="calc-service-btn p-4 rounded-xl text-left border border-dark-border bg-dark/60 hover:border-gold/50 transition-all relative flex flex-col justify-between">
            <div class="flex items-center justify-between mb-2">
              <span class="text-2xl">🛋️</span>
              <span class="px-1.5 py-0.5 rounded-lg bg-gold/15 text-gold text-xs font-semibold">3D Staging</span>
            </div>
            <div>
              <div class="text-sm font-bold text-white">Virtual Staging</div>
              <div class="text-xs text-gray-400 mt-0.5">Photorealistic Furniture</div>
              <div class="text-xs font-black text-gold mt-2"><span data-rate-staging>$8.00</span> <span class="text-xs font-normal text-gray-400">/ room</span></div>
            </div>
          </button>

          <!-- Service Option 3: Virtual Twilight -->
          <button type="button" 
                  onclick="window.ehdrCalc.setService('twilight')" 
                  data-calc-service="twilight"
                  class="calc-service-btn p-4 rounded-xl text-left border border-dark-border bg-dark/60 hover:border-gold/50 transition-all relative flex flex-col justify-between">
            <div class="flex items-center justify-between mb-2">
              <span class="text-2xl">🌅</span>
              <span class="px-1.5 py-0.5 rounded-lg bg-gold/15 text-gold text-xs font-semibold">Sunset</span>
            </div>
            <div>
              <div class="text-sm font-bold text-white">Day to Dusk</div>
              <div class="text-xs text-gray-400 mt-0.5">Virtual Twilight Glow</div>
              <div class="text-xs font-black text-gold mt-2"><span data-rate-twilight>$4.00</span> <span class="text-xs font-normal text-gray-400">/ photo</span></div>
            </div>
          </button>

          <!-- Service Option 4: Item Removal -->
          <button type="button" 
                  onclick="window.ehdrCalc.setService('item_removal')" 
                  data-calc-service="item_removal"
                  class="calc-service-btn p-4 rounded-xl text-left border border-dark-border bg-dark/60 hover:border-gold/50 transition-all relative flex flex-col justify-between">
            <div class="flex items-center justify-between mb-2">
              <span class="text-2xl">🧹</span>
              <span class="px-1.5 py-0.5 rounded-lg bg-gray-800 text-gray-300 text-xs font-semibold">Clean</span>
            </div>
            <div>
              <div class="text-sm font-bold text-white">Item Removal</div>
              <div class="text-xs text-gray-400 mt-0.5">Declutter &amp; Erase Objects</div>
              <div class="text-xs font-black text-gold mt-2"><span data-rate-item_removal>$2.00</span> <span class="text-xs font-normal text-gray-400">/ photo</span></div>
            </div>
          </button>

          <!-- Service Option 5: Floor Plans -->
          <button type="button" 
                  onclick="window.ehdrCalc.setService('floorplan_2d')" 
                  data-calc-service="floorplan_2d"
                  class="calc-service-btn p-4 rounded-xl text-left border border-dark-border bg-dark/60 hover:border-gold/50 transition-all relative flex flex-col justify-between">
            <div class="flex items-center justify-between mb-2">
              <span class="text-2xl">📐</span>
              <span class="px-1.5 py-0.5 rounded-lg bg-emerald-500/15 text-emerald-400 text-xs font-semibold">Schematic</span>
            </div>
            <div>
              <div class="text-sm font-bold text-white">2D/3D Floor Plan</div>
              <div class="text-xs text-gray-400 mt-0.5">Precise Dimensions &amp; Layout</div>
              <div class="text-xs font-black text-gold mt-2"><span data-rate-floorplan_2d>$12.00</span> <span class="text-xs font-normal text-gray-400">/ plan</span></div>
            </div>
          </button>

          <!-- Service Option 6: 4K Video Tour -->
          <button type="button" 
                  onclick="window.ehdrCalc.setService('video_4k')" 
                  data-calc-service="video_4k"
                  class="calc-service-btn p-4 rounded-xl text-left border border-dark-border bg-dark/60 hover:border-gold/50 transition-all relative flex flex-col justify-between">
            <div class="flex items-center justify-between mb-2">
              <span class="text-2xl">🎬</span>
              <span class="px-1.5 py-0.5 rounded-lg bg-gold/15 text-gold text-xs font-semibold">4K Video</span>
            </div>
            <div>
              <div class="text-sm font-bold text-white">Cinematic Video</div>
              <div class="text-xs text-gray-400 mt-0.5">Reels, Tours &amp; Drone</div>
              <div class="text-xs font-black text-gold mt-2"><span data-rate-video_4k>$30.00</span> <span class="text-xs font-normal text-gray-400">/ video</span></div>
            </div>
          </button>
        </div>
      </div>

      <!-- 2. Interactive Quantity Slider & Stepper -->
      <div class="p-6 rounded-2xl bg-dark-card border border-dark-border/80 shadow-xl space-y-5">
        <div class="flex items-center justify-between">
          <label for="calc-quantity-slider" class="text-sm font-bold text-white flex items-center gap-2">
            <span class="w-5 h-5 rounded-full bg-gold/20 text-gold flex items-center justify-center text-xs font-bold">2</span>
            <span>Quantity / Volume</span>
          </label>
          
          <div class="flex items-center gap-2 bg-[#141422] px-3 py-1.5 rounded-xl border border-dark-border">
            <button type="button" onclick="window.ehdrCalc.stepQty(-1)" aria-label="Decrease quantity" class="w-7 h-7 rounded-lg bg-dark hover:bg-gold hover:text-dark text-gold font-black transition-colors flex items-center justify-center text-sm border border-dark-border">&minus;</button>
            <input type="number" 
                   id="calc-quantity-input" 
                   value="25" 
                   min="1" 
                   max="300"
                   aria-label="Quantity of units"
                   onchange="window.ehdrCalc.setQty(this.value)"
                   class="w-14 text-center bg-transparent font-mono font-black text-base text-white outline-none">
            <button type="button" onclick="window.ehdrCalc.stepQty(1)" aria-label="Increase quantity" class="w-7 h-7 rounded-lg bg-dark hover:bg-gold hover:text-dark text-gold font-black transition-colors flex items-center justify-center text-sm border border-dark-border">&plus;</button>
            <span id="calc-unit-label" class="text-xs font-bold text-gray-400 ml-1">photos</span>
          </div>
        </div>

        <!-- Custom Glowing Range Slider -->
        <div class="space-y-2">
          <div class="relative py-2">
            <input type="range" 
                   id="calc-quantity-slider" 
                   min="1" 
                   max="150" 
                   value="25" 
                   aria-label="Drag volume slider"
                   oninput="window.ehdrCalc.setQty(this.value)"
                   class="calc-slider w-full h-2.5 bg-dark rounded-lg appearance-none cursor-pointer outline-none">
          </div>
          
          <div class="flex justify-between text-xs font-mono text-gray-400 font-medium px-1">
            <span>1 unit</span>
            <span>25 (Standard)</span>
            <span>50 (Luxury)</span>
            <span>100+ (Agency)</span>
            <span>150+</span>
          </div>
        </div>

        <!-- Volume Quick Presets -->
        <div class="pt-2 border-t border-dark-border/60">
          <div class="text-xs text-gray-400 font-semibold mb-2 flex items-center justify-between">
            <span>Quick Volume Presets (Tiered Discounts):</span>
            <span class="text-gold text-[11px] font-bold">More photos = bigger discount</span>
          </div>
          <div class="flex flex-wrap gap-2">
            <button type="button" onclick="window.ehdrCalc.setQty(15)" class="calc-preset-btn px-3 py-1.5 rounded-lg bg-dark/80 hover:bg-gold/20 hover:text-gold border border-dark-border text-xs font-semibold text-gray-300 transition-all">
              15 Photos ($0.60/ea)
            </button>
            <button type="button" onclick="window.ehdrCalc.setQty(25)" class="calc-preset-btn px-3 py-1.5 rounded-lg bg-dark/80 hover:bg-gold/20 hover:text-gold border border-dark-border text-xs font-semibold text-gray-300 transition-all">
              25 Photos ($0.55/ea)
            </button>
            <button type="button" onclick="window.ehdrCalc.setQty(50)" class="calc-preset-btn px-3 py-1.5 rounded-lg bg-gold/15 text-gold border border-gold/40 text-xs font-bold transition-all">
              ⚡ 50 Photos ($0.50/ea)
            </button>
            <button type="button" onclick="window.ehdrCalc.setQty(100)" class="calc-preset-btn px-3 py-1.5 rounded-lg bg-emerald-500/15 text-emerald-400 border border-emerald-500/40 text-xs font-bold transition-all">
              👑 100+ Photos ($0.45/ea VIP)
            </button>
          </div>
        </div>
      </div>

      <!-- 3. Turnaround Speed / Urgent Rush SLA -->
      <div class="p-6 rounded-2xl bg-dark-card border border-dark-border/80 shadow-xl space-y-4">
        <div class="flex items-center justify-between">
          <label class="text-sm font-bold text-white flex items-center gap-2">
            <span class="w-5 h-5 rounded-full bg-gold/20 text-gold flex items-center justify-center text-xs font-bold">3</span>
            <span>Turnaround SLA Speed</span>
          </label>
          <span class="text-xs text-gray-400">Guaranteed on-time delivery</span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <!-- Standard 24h -->
          <button type="button" 
                  onclick="window.ehdrCalc.setTurnaround('24h')" 
                  data-calc-sla="24h"
                  class="calc-sla-btn active p-3.5 rounded-xl border text-left transition-all bg-gold/10 border-gold text-white">
            <div class="flex items-center justify-between">
              <span class="text-sm font-bold text-white">24h Standard</span>
              <span class="px-2 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-400 text-xs font-black">INCLUDED</span>
            </div>
            <div class="text-xs text-gray-400 mt-1">Next-day guaranteed delivery</div>
          </button>

          <!-- 12h Express -->
          <button type="button" 
                  onclick="window.ehdrCalc.setTurnaround('12h')" 
                  data-calc-sla="12h"
                  class="calc-sla-btn p-3.5 rounded-xl border border-dark-border bg-dark/60 text-left hover:border-gold/50 transition-all text-gray-300">
            <div class="flex items-center justify-between">
              <span class="text-sm font-bold text-white">12h Express</span>
              <span class="px-2 py-0.5 rounded-lg bg-gold/15 text-gold text-xs font-black">+25%</span>
            </div>
            <div class="text-xs text-gray-400 mt-1">Same-day priority turnaround</div>
          </button>

          <!-- 6h Super Rush -->
          <button type="button" 
                  onclick="window.ehdrCalc.setTurnaround('6h')" 
                  data-calc-sla="6h"
                  class="calc-sla-btn p-3.5 rounded-xl border border-dark-border bg-dark/60 text-left hover:border-gold/50 transition-all text-gray-300">
            <div class="flex items-center justify-between">
              <span class="text-sm font-bold text-white">6h Super Rush</span>
              <span class="px-2 py-0.5 rounded-lg bg-gold/15 text-gold text-xs font-black">+50%</span>
            </div>
            <div class="text-xs text-gray-400 mt-1">VIP immediate dedicated pod</div>
          </button>
        </div>
      </div>

      <!-- 4. Optional Multi-Service Add-On Bundle -->
      <div class="p-6 rounded-2xl bg-dark-card border border-dark-border/80 shadow-xl space-y-4">
        <div class="flex items-center justify-between">
          <label class="text-sm font-bold text-white flex items-center gap-2">
            <span class="w-5 h-5 rounded-full bg-gold/20 text-gold flex items-center justify-center text-xs font-bold">4</span>
            <span>Optional Add-On Bundle (Combine Services)</span>
          </label>
          <span class="text-xs text-gray-400">Multi-Service Package</span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <!-- Add-on: Twilight Shots -->
          <label class="p-3 rounded-xl bg-dark/60 border border-dark-border hover:border-gold/40 transition-colors flex items-center justify-between cursor-pointer">
            <div class="flex items-center gap-3">
              <input type="checkbox" id="addon-twilight" onchange="window.ehdrCalc.toggleAddon('twilight', this.checked)" class="w-4 h-4 text-gold rounded bg-dark border-dark-border focus:ring-gold">
              <div>
                <div class="text-xs font-bold text-white">Virtual Twilight Shots</div>
                <div class="text-xs text-gray-400">+<span data-rate-twilight>$4.00</span> per photo</div>
              </div>
            </div>
            <div class="flex items-center gap-1">
              <input type="number" id="addon-twilight-qty" min="1" max="20" value="2" onchange="window.ehdrCalc.updateAddonQty('twilight', this.value)" class="w-10 text-center bg-[#111118] border border-dark-border rounded text-xs font-mono text-white p-1">
            </div>
          </label>

          <!-- Add-on: Staged Rooms -->
          <label class="p-3 rounded-xl bg-dark/60 border border-dark-border hover:border-gold/40 transition-colors flex items-center justify-between cursor-pointer">
            <div class="flex items-center gap-3">
              <input type="checkbox" id="addon-staging" onchange="window.ehdrCalc.toggleAddon('staging', this.checked)" class="w-4 h-4 text-gold rounded bg-dark border-dark-border focus:ring-gold">
              <div>
                <div class="text-xs font-bold text-white">3D Virtual Staged Rooms</div>
                <div class="text-xs text-gray-400">+<span data-rate-staging>$8.00</span> per room</div>
              </div>
            </div>
            <div class="flex items-center gap-1">
              <input type="number" id="addon-staging-qty" min="1" max="10" value="2" onchange="window.ehdrCalc.updateAddonQty('staging', this.value)" class="w-10 text-center bg-[#111118] border border-dark-border rounded text-xs font-mono text-white p-1">
            </div>
          </label>

          <!-- Add-on: 2D Floor Plan -->
          <label class="p-3 rounded-xl bg-dark/60 border border-dark-border hover:border-gold/40 transition-colors flex items-center justify-between cursor-pointer">
            <div class="flex items-center gap-3">
              <input type="checkbox" id="addon-floorplan" onchange="window.ehdrCalc.toggleAddon('floorplan', this.checked)" class="w-4 h-4 text-gold rounded bg-dark border-dark-border focus:ring-gold">
              <div>
                <div class="text-xs font-bold text-white">2D Schematic Floor Plan</div>
                <div class="text-xs text-gray-400">+<span data-rate-floorplan_2d>$12.00</span> flat</div>
              </div>
            </div>
            <div class="flex items-center gap-1">
              <input type="number" id="addon-floorplan-qty" min="1" max="5" value="1" onchange="window.ehdrCalc.updateAddonQty('floorplan', this.value)" class="w-10 text-center bg-[#111118] border border-dark-border rounded text-xs font-mono text-white p-1">
            </div>
          </label>

          <!-- Add-on: Object Removal -->
          <label class="p-3 rounded-xl bg-dark/60 border border-dark-border hover:border-gold/40 transition-colors flex items-center justify-between cursor-pointer">
            <div class="flex items-center gap-3">
              <input type="checkbox" id="addon-removal" onchange="window.ehdrCalc.toggleAddon('removal', this.checked)" class="w-4 h-4 text-gold rounded bg-dark border-dark-border focus:ring-gold">
              <div>
                <div class="text-xs font-bold text-white">Complex Item Removal</div>
                <div class="text-xs text-gray-400">+<span data-rate-item_removal>$2.00</span> per photo</div>
              </div>
            </div>
            <div class="flex items-center gap-1">
              <input type="number" id="addon-removal-qty" min="1" max="20" value="3" onchange="window.ehdrCalc.updateAddonQty('removal', this.value)" class="w-10 text-center bg-[#111118] border border-dark-border rounded text-xs font-mono text-white p-1">
            </div>
          </label>
        </div>
      </div>
    </div>

    <!-- ═════════════════════════════════════════════════════════════ -->
    <!-- RIGHT COLUMN: FLOATING ESTIMATED INVOICE BREAKDOWN (5 COLS)  -->
    <!-- ═════════════════════════════════════════════════════════════ -->
    <div class="lg:col-span-5 sticky top-28 space-y-6">
      <div class="p-6 sm:p-8 rounded-2xl bg-gradient-to-b from-[#161722] via-[#0f1017] to-[#0a0a0f] border-2 border-gold/60 shadow-[0_16px_50px_rgba(0,0,0,0.8),0_0_30px_rgba(201,168,76,0.15)] relative overflow-hidden">
        
        <!-- Luxury Top Gold Gradient Accent Line -->
        <div class="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-transparent via-gold to-transparent"></div>

        <!-- Header: Estimate Quote Meta -->
        <div class="flex items-center justify-between pb-4 border-b border-dark-border/80">
          <div>
            <div class="text-xs font-bold text-gold flex items-center gap-1.5">
              <span class="w-2 h-2 rounded-full bg-gold animate-ping"></span>
              <span>Official Live Estimate</span>
            </div>
            <div id="calc-quote-ref" class="text-xs font-mono text-gray-400 mt-0.5">REF: QTE-2026-EH942</div>
          </div>
          <span class="px-2.5 py-1 rounded-full bg-gold/15 text-gold border border-gold/40 text-xs font-bold">
            Guaranteed SLA
          </span>
        </div>

        <!-- Total Price Large Animated Display -->
        <div class="py-6 text-center border-b border-dark-border/80">
          <div class="text-xs text-gray-400 font-bold tracking-normal font-bold mb-1">Estimated Project Total</div>
          <div class="flex items-baseline justify-center gap-1">
            <span id="calc-currency-sym" class="text-3xl sm:text-4xl font-black text-gold font-mono">$</span>
            <span id="calc-total-display" class="text-4xl sm:text-5xl font-black text-white tracking-tight font-mono drop-shadow-md">20.00</span>
            <span id="calc-currency-code" class="text-xs font-black text-gray-400 font-mono uppercase ml-1">USD</span>
          </div>
          <div id="calc-effective-rate" class="text-xs text-emerald-400 font-bold font-mono mt-1">
            Effective Rate: $0.80 / photo
          </div>

          <!-- Volume Discount Alert Badge (Animated) -->
          <div id="calc-discount-badge" class="mt-3 inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-500/40 text-emerald-400 text-xs font-bold animate-bounce hidden">
            <span>🎉</span>
            <span id="calc-discount-text">10% Volume Discount Applied!</span>
          </div>
        </div>

        <!-- Complimentary Day-to-Dusk Bonus Callout -->
        <div id="calc-free-twilight-box" class="my-4 p-3.5 rounded-xl bg-gold/10 border border-gold/40 flex items-center justify-between text-xs">
          <div class="flex items-center gap-2.5">
            <span class="text-xl">🌅</span>
            <div>
              <div class="font-black text-white flex items-center gap-1.5">
                <span>1x FREE Day-to-Dusk Hero Photo</span>
                <span class="px-1.5 py-0.2 rounded bg-gold/20 text-gold text-[10px] font-mono">BONUS</span>
              </div>
              <div class="text-[10px] text-gray-300">Complimentary on every single property order!</div>
            </div>
          </div>
          <span class="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-mono font-black text-xs">$0.00 FREE</span>
        </div>

        <!-- Line Item Breakdown Table -->
        <div class="py-4 space-y-2.5 text-xs font-mono border-b border-dark-border/80">
          <!-- Primary Service Row -->
          <div class="flex justify-between items-center text-gray-300">
            <span id="calc-item-main-title">HDR Photo Editing (25 units)</span>
            <span id="calc-item-main-price" class="font-bold text-white">$20.00</span>
          </div>

          <!-- Add-ons Container -->
          <div id="calc-addons-list" class="space-y-2"></div>

          <!-- Volume Savings Row -->
          <div id="calc-savings-row" class="flex justify-between items-center text-emerald-400 hidden">
            <span>Volume Tier Discount (<span id="calc-savings-pct">10%</span>)</span>
            <span id="calc-savings-amount" class="font-bold">-$2.00</span>
          </div>

          <!-- Turnaround Surcharge Row -->
          <div id="calc-sla-row" class="flex justify-between items-center text-gold hidden">
            <span id="calc-sla-name">12h Express Priority (+25%)</span>
            <span id="calc-sla-amount" class="font-bold">+$5.00</span>
          </div>
        </div>

        <!-- Guarantees & Value Inclusions -->
        <div class="py-4 space-y-2 text-xs text-gray-300">
          <div class="flex items-center gap-2 text-gray-300">
            <svg class="w-4 h-4 text-gold flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/></svg>
            <span><strong>100% Free Unlimited Revisions</strong> until client approved</span>
          </div>
          <div class="flex items-center gap-2 text-gray-300">
            <svg class="w-4 h-4 text-gold flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/></svg>
            <span>Dual High-Res Deliverables: <strong>2048px MLS + 300 DPI Print</strong></span>
          </div>
          <div class="flex items-center gap-2 text-gray-300">
            <svg class="w-4 h-4 text-gold flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/></svg>
            <span>Master 5-Point Quality Inspection by Lead Retouchers</span>
          </div>
        </div>

        <!-- Direct Action Buttons -->
        <div class="pt-2 space-y-3">
          <!-- Primary CTA: Place Order -->
          <a id="calc-cta-order" 
             href="/order-new.php" 
             class="btn-gold w-full py-4 text-sm font-black shadow-glow rounded-xl flex items-center justify-center gap-2 text-center tracking-normal font-bold">
            <span>⚡ Place Order with This Estimate &rarr;</span>
          </a>

          <!-- Secondary CTA: Free Trial -->
          <a href="/#trial" 
             class="btn-ghost w-full py-3 text-xs font-bold rounded-xl flex items-center justify-center gap-2 text-center text-gray-300 hover:text-white border border-dark-border">
            <span>🎁 Test 3 Photos 100% Free First &rarr;</span>
          </a>

          <!-- WhatsApp Direct Link -->
          <a id="calc-cta-whatsapp" 
             href="https://wa.me/447706068176" 
             target="_blank" 
             rel="noopener noreferrer"
             class="w-full py-2.5 text-xs font-bold text-emerald-400 hover:text-emerald-400 flex items-center justify-center gap-1.5 transition-colors">
            <span>💬 Lock this Quote with VIP Desk on WhatsApp</span>
          </a>
        </div>

      </div>
    </div>

  </div>
</div>

<!-- ── CALCULATOR JAVASCRIPT REACTIVE ENGINE ── -->
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
(function() {
  'use strict';

  const FX_RATES = {
    'USD': { symbol: '$',   rate: 1.00 },
    'GBP': { symbol: '£',   rate: 0.78 },
    'EUR': { symbol: '€',   rate: 0.92 },
    'AUD': { symbol: 'A$',  rate: 1.52 },
    'CAD': { symbol: 'C$',  rate: 1.36 },
    'AED': { symbol: 'AED ',rate: 3.67 }
  };

  const REGULAR_RATES_USD = {
    'hdr':          0.80,
    'staging':      8.00,
    'twilight':     4.00,
    'item_removal': 2.00,
    'floorplan_2d': 12.00,
    'floorplan_3d': 20.00,
    'video_4k':     30.00
  };

  const BASE_RATES_USD = {
    'hdr':          0.60, // Promotional rate (was 0.80)
    'staging':      8.00,
    'twilight':     4.00,
    'item_removal': 2.00,
    'floorplan_2d': 12.00,
    'floorplan_3d': 20.00,
    'video_4k':     30.00
  };

  const SERVICE_TITLES = {
    'hdr':          { name: 'HDR Photo Retouching', unit: 'photos' },
    'staging':      { name: '3D Virtual Staging', unit: 'rooms' },
    'twilight':     { name: 'Day to Dusk / Twilight', unit: 'photos' },
    'item_removal': { name: 'Item Removal & Declutter', unit: 'photos' },
    'floorplan_2d': { name: '2D/3D Floor Plans', unit: 'plans' },
    'video_4k':     { name: '4K Cinematic Video Tour', unit: 'videos' }
  };

  const state = {
    service: 'hdr',
    quantity: 25,
    currency: 'USD',
    turnaround: '24h',
    addons: {
      twilight:  { active: false, qty: 2, rate: 4.00, title: 'Virtual Twilight' },
      staging:   { active: false, qty: 2, rate: 8.00, title: '3D Virtual Staged Rooms' },
      floorplan: { active: false, qty: 1, rate: 12.00, title: '2D Floor Plan' },
      removal:   { active: false, qty: 3, rate: 2.00, title: 'Item Removal' }
    }
  };

  // Controller API
  window.ehdrCalc = {
    setService: function(srvKey) {
      state.service = srvKey;
      document.querySelectorAll('.calc-service-btn').forEach(btn => {
        const isSelected = btn.getAttribute('data-calc-service') === srvKey;
        if (isSelected) {
          btn.classList.add('active', 'bg-gold/10', 'border-gold', 'shadow-[0_0_15px_rgba(201,168,76,0.15)]');
          btn.classList.remove('bg-dark/60', 'border-dark-border');
        } else {
          btn.classList.remove('active', 'bg-gold/10', 'border-gold', 'shadow-[0_0_15px_rgba(201,168,76,0.15)]');
          btn.classList.add('bg-dark/60', 'border-dark-border');
        }
      });
      const meta = SERVICE_TITLES[srvKey] || { unit: 'units' };
      const unitLabel = document.getElementById('calc-unit-label');
      if (unitLabel) unitLabel.textContent = meta.unit;
      this.recalculate();
    },

    setQty: function(val) {
      let q = parseInt(val, 10);
      if (isNaN(q) || q < 1) q = 1;
      if (q > 500) q = 500;
      state.quantity = q;
      
      const input = document.getElementById('calc-quantity-input');
      const slider = document.getElementById('calc-quantity-slider');
      if (input && input.value != q) input.value = q;
      if (slider && slider.value != q) slider.value = Math.min(q, 150);
      
      this.updateSliderTrack(q);
      this.recalculate();
    },

    stepQty: function(delta) {
      this.setQty(state.quantity + delta);
    },

    setCurrency: function(curr) {
      if (!FX_RATES[curr]) curr = 'USD';
      state.currency = curr;

      document.querySelectorAll('.calc-curr-btn').forEach(btn => {
        const isSelected = btn.getAttribute('data-calc-curr') === curr;
        if (isSelected) {
          btn.classList.add('bg-gold', 'text-dark', 'shadow-sm');
          btn.classList.remove('text-gray-400');
        } else {
          btn.classList.remove('bg-gold', 'text-dark', 'shadow-sm');
          btn.classList.add('text-gray-400');
        }
      });

      this.updateServiceRatesDisplay();
      this.recalculate();
    },

    setTurnaround: function(sla) {
      state.turnaround = sla;
      document.querySelectorAll('.calc-sla-btn').forEach(btn => {
        const isSelected = btn.getAttribute('data-calc-sla') === sla;
        if (isSelected) {
          btn.classList.add('active', 'bg-gold/10', 'border-gold', 'text-white');
          btn.classList.remove('bg-dark/60', 'border-dark-border', 'text-gray-300');
        } else {
          btn.classList.remove('active', 'bg-gold/10', 'border-gold', 'text-white');
          btn.classList.add('bg-dark/60', 'border-dark-border', 'text-gray-300');
        }
      });
      this.recalculate();
    },

    toggleAddon: function(addonKey, isActive) {
      if (state.addons[addonKey]) {
        state.addons[addonKey].active = !!isActive;
        this.recalculate();
      }
    },

    updateAddonQty: function(addonKey, qty) {
      if (state.addons[addonKey]) {
        state.addons[addonKey].qty = Math.max(1, parseInt(qty, 10) || 1);
        this.recalculate();
      }
    },

    updateSliderTrack: function(q) {
      const slider = document.getElementById('calc-quantity-slider');
      if (!slider) return;
      const pct = Math.min(100, Math.max(0, ((q - 1) / (150 - 1)) * 100));
      slider.style.background = `linear-gradient(to right, #C9A84C 0%, #E5C365 ${pct}%, #141420 ${pct}%, #141420 100%)`;
    },

    updateServiceRatesDisplay: function() {
      const fx = FX_RATES[state.currency] || FX_RATES['USD'];
      Object.keys(BASE_RATES_USD).forEach(k => {
        const local = (BASE_RATES_USD[k] * fx.rate).toFixed(2);
        document.querySelectorAll(`[data-rate-${k}]`).forEach(el => {
          el.textContent = fx.symbol + local;
        });
      });
      // Update regular strikethrough rate for HDR
      const regLocalHdr = (REGULAR_RATES_USD['hdr'] * fx.rate).toFixed(2);
      document.querySelectorAll('[data-reg-rate-hdr]').forEach(el => {
        el.textContent = fx.symbol + regLocalHdr;
      });
    },

    recalculate: function() {
      const fx = FX_RATES[state.currency] || FX_RATES['USD'];
      const sym = fx.symbol;
      const rate = fx.rate;

      // 1. Base Main Service Calculation
      let unitRateUsd = BASE_RATES_USD[state.service] || 0.60;
      let regularUnitRateUsd = REGULAR_RATES_USD[state.service] || 0.80;
      const isHdr = (state.service === 'hdr');
      const freeDayToDusk = isHdr; // 1 Free Day-to-Dusk hero on every single property order!
      let tierLabel = '';

      // Tiered Volume Pricing & Discounts
      let discountPct = 0;
      if (isHdr) {
        // Exact Volume Discount Tiers for HDR:
        // 1 - 24 photos: $0.60 / photo (Promo base rate, was $0.80)
        // 25 - 49 photos: $0.55 / photo
        // 50 - 99 photos: $0.50 / photo
        // 100+ photos: $0.45 / photo
        if (state.quantity >= 100) {
          unitRateUsd = 0.45;
          tierLabel = 'Tier: 100+ Photos ($0.45/photo VIP)';
        } else if (state.quantity >= 50) {
          unitRateUsd = 0.50;
          tierLabel = 'Tier: 50–99 Photos ($0.50/photo)';
        } else if (state.quantity >= 25) {
          unitRateUsd = 0.55;
          tierLabel = 'Tier: 25–49 Photos ($0.55/photo)';
        } else {
          unitRateUsd = 0.60;
          tierLabel = 'Tier: 1–24 Photos ($0.60/photo Promo)';
        }
      } else if (state.service === 'staging' && state.quantity >= 5) {
        discountPct = 10;
      }

      const subtotalMainUsd = unitRateUsd * state.quantity;
      const regularSubtotalUsd = regularUnitRateUsd * state.quantity;
      const discountUsd = (state.service === 'staging') ? ((subtotalMainUsd * discountPct) / 100) : 0;
      const netMainUsd = subtotalMainUsd - discountUsd;

      // Total savings vs standard regular pricing + free twilight ($4.00 value)
      const totalSavingsUsd = (regularSubtotalUsd - netMainUsd) + (freeDayToDusk ? 4.00 : 0);

      // 2. Add-ons Calculation
      let addonsUsd = 0;
      const activeAddonsList = [];
      Object.keys(state.addons).forEach(k => {
        const ad = state.addons[k];
        if (ad.active) {
          const itemTot = ad.rate * ad.qty;
          addonsUsd += itemTot;
          activeAddonsList.push({
            title: `${ad.title} (${ad.qty})`,
            priceLocal: (itemTot * rate).toFixed(2)
          });
        }
      });

      // 3. Turnaround SLA Surcharge
      let slaPct = 0;
      let slaLabel = '24h Standard';
      if (state.turnaround === '12h') {
        slaPct = 0.25;
        slaLabel = '12h Express Priority (+25%)';
      } else if (state.turnaround === '6h') {
        slaPct = 0.50;
        slaLabel = '6h Super Rush (+50%)';
      }

      const baseForSla = netMainUsd + addonsUsd;
      const slaSurchargeUsd = baseForSla * slaPct;
      const finalTotalUsd = baseForSla + slaSurchargeUsd;

      // Local Currency Conversions
      const finalTotalLocal = (finalTotalUsd * rate).toFixed(2);
      const effectiveRateLocal = ((finalTotalLocal / (state.quantity || 1))).toFixed(2);
      const unitRateLocal = (unitRateUsd * rate).toFixed(2);
      const regularUnitRateLocal = (regularUnitRateUsd * rate).toFixed(2);
      const totalSavingsLocal = (totalSavingsUsd * rate).toFixed(2);

      // DOM Updates: Total Display & Currency
      const totalDisplay = document.getElementById('calc-total-display');
      const currSym = document.getElementById('calc-currency-sym');
      const currCode = document.getElementById('calc-currency-code');
      const effectiveRateEl = document.getElementById('calc-effective-rate');
      
      if (totalDisplay) totalDisplay.textContent = finalTotalLocal;
      if (currSym) currSym.textContent = sym;
      if (currCode) currCode.textContent = state.currency;
      
      const srvMeta = SERVICE_TITLES[state.service] || { unit: 'unit' };
      if (effectiveRateEl) {
        if (isHdr) {
          effectiveRateEl.innerHTML = `<span class="line-through text-gray-500 mr-1">${sym}${regularUnitRateLocal}</span> <span class="text-emerald-400 font-black">${sym}${unitRateLocal}</span> / ${srvMeta.unit} <span class="text-gold font-normal">(${tierLabel})</span>`;
        } else {
          effectiveRateEl.textContent = `Effective: ${sym}${effectiveRateLocal} / ${srvMeta.unit}`;
        }
      }

      // Main Service Breakdown Row
      const mainTitle = document.getElementById('calc-item-main-title');
      const mainPrice = document.getElementById('calc-item-main-price');
      if (mainTitle) {
        if (isHdr) {
          mainTitle.textContent = `${srvMeta.name} (${state.quantity} ${srvMeta.unit} @ ${sym}${unitRateLocal})`;
        } else {
          mainTitle.textContent = `${srvMeta.name} (${state.quantity} ${srvMeta.unit})`;
        }
      }
      if (mainPrice) mainPrice.textContent = `${sym}${(subtotalMainUsd * rate).toFixed(2)}`;

      // Free Day-to-Dusk Hero Photo Banner Visibility
      const freeTwilightBox = document.getElementById('calc-free-twilight-box');
      if (freeTwilightBox) {
        if (freeDayToDusk) {
          freeTwilightBox.classList.remove('hidden');
        } else {
          freeTwilightBox.classList.add('hidden');
        }
      }

      // Addons Breakdown
      const addonsBox = document.getElementById('calc-addons-list');
      if (addonsBox) {
        addonsBox.innerHTML = activeAddonsList.map(a => `
          <div class="flex justify-between items-center text-gray-300">
            <span>+ ${a.title}</span>
            <span class="font-bold text-white">${sym}${a.priceLocal}</span>
          </div>
        `).join('');
      }

      // Savings Display & Badge
      const discountBadge = document.getElementById('calc-discount-badge');
      const discountText = document.getElementById('calc-discount-text');
      const savingsRow = document.getElementById('calc-savings-row');
      const savingsPct = document.getElementById('calc-savings-pct');
      const savingsAmount = document.getElementById('calc-savings-amount');

      if (totalSavingsUsd > 0) {
        if (discountBadge) discountBadge.classList.remove('hidden');
        if (discountText) {
          if (isHdr) {
            discountText.innerHTML = `🔥 Promotional Savings: You save <strong>${sym}${totalSavingsLocal} ${state.currency}</strong> vs standard $0.80 rate + Free Twilight!`;
          } else {
            discountText.textContent = `🎉 Volume Discount: You save ${sym}${totalSavingsLocal} ${state.currency}!`;
          }
        }
        if (savingsRow) savingsRow.classList.remove('hidden');
        if (savingsPct) savingsPct.textContent = isHdr ? 'Offer + Perks' : `${discountPct}%`;
        if (savingsAmount) savingsAmount.textContent = `-${sym}${totalSavingsLocal}`;
      } else {
        if (discountBadge) discountBadge.classList.add('hidden');
        if (savingsRow) savingsRow.classList.add('hidden');
      }

      // Turnaround SLA Row
      const slaRow = document.getElementById('calc-sla-row');
      const slaName = document.getElementById('calc-sla-name');
      const slaAmount = document.getElementById('calc-sla-amount');
      if (slaPct > 0) {
        if (slaRow) slaRow.classList.remove('hidden');
        if (slaName) slaName.textContent = slaLabel;
        if (slaAmount) slaAmount.textContent = `+${sym}${(slaSurchargeUsd * rate).toFixed(2)}`;
      } else {
        if (slaRow) slaRow.classList.add('hidden');
      }

      // Dynamic Bridge Links
      const orderCta = document.getElementById('calc-cta-order');
      if (orderCta) {
        const orderUrl = `/order-new.php?service=${encodeURIComponent(srvMeta.name)}&count=${state.quantity}&est=${finalTotalLocal}&curr=${state.currency}`;
        orderCta.href = orderUrl;
      }

      const waCta = document.getElementById('calc-cta-whatsapp');
      if (waCta) {
        const waMsg = `Hi Estate HDR! I generated a quote on your Pricing Calculator:\n• Service: ${srvMeta.name}\n• Quantity: ${state.quantity} ${srvMeta.unit}\n• Turnaround: ${slaLabel}\n• Total Estimate: ${sym}${finalTotalLocal} ${state.currency}\nPlease assist me with placing this order!`;
        waCta.href = `https://wa.me/447706068176?text=${encodeURIComponent(waMsg)}`;
      }
    }
  };

  // Safe DOM mount initialization
  function initCalculator() {
    if (window.ehdrCalc) {
      window.ehdrCalc.setService('hdr');
      window.ehdrCalc.setQty(25);
      window.ehdrCalc.setCurrency('USD');
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCalculator);
  } else {
    initCalculator();
  }
})();
</script>
