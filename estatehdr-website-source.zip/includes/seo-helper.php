<?php
/**
 * Estate HDR — Master SEO & Structured Data (JSON-LD) Engine
 * Generates Rich Snippets, AggregateRatings, Breadcrumbs, FAQs, Services, Articles & AI-ready Metadata
 */

if (!defined('BASE_URL')) {
    require_once __DIR__ . '/config.php';
}

/**
 * Global Organization & LocalBusiness Schema with 4.98-star AggregateRating
 */
function getGlobalOrganizationSchema(): array {
    return [
        "@context" => "https://schema.org",
        "@type" => "ProfessionalService",
        "@id" => BASE_URL . "/#organization",
        "name" => "Estate HDR",
        "legalName" => "Estate HDR Studio Ltd.",
        "url" => BASE_URL,
        "logo" => [
            "@type" => "ImageObject",
            "url" => BASE_URL . "/assets/images/logo.png",
            "width" => 600,
            "height" => 200
        ],
        "image" => BASE_URL . "/assets/images/og-image.jpg",
        "description" => "World's #1 Luxury Real Estate Photo Editing & 3D Virtual Staging Studio. 24-hour delivery, unlimited revisions, and dedicated editing teams.",
        "telephone" => WHATSAPP_NUMBER,
        "email" => CONTACT_EMAIL,
        "priceRange" => "$$",
        "currenciesAccepted" => "USD, GBP, EUR, AUD, CAD",
        "paymentAccepted" => "Credit Card, PayPal, Stripe, Bank Wire",
        "openingHoursSpecification" => [
            [
                "@type" => "OpeningHoursSpecification",
                "dayOfWeek" => ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
                "opens" => "00:00",
                "closes" => "23:59"
            ]
        ],
        "address" => [
            "@type" => "PostalAddress",
            "streetAddress" => "71-75 Shelton Street, Covent Garden",
            "addressLocality" => "London",
            "postalCode" => "WC2H 9JQ",
            "addressCountry" => "GB"
        ],
        "geo" => [
            "@type" => "GeoCoordinates",
            "latitude" => 51.5147,
            "longitude" => -0.1246
        ],
        "areaServed" => [
            ["@type" => "Country", "name" => "United States"],
            ["@type" => "Country", "name" => "United Kingdom"],
            ["@type" => "Country", "name" => "Australia"],
            ["@type" => "Country", "name" => "Canada"],
            ["@type" => "Country", "name" => "European Union"]
        ],
        "aggregateRating" => [
            "@type" => "AggregateRating",
            "ratingValue" => "4.98",
            "reviewCount" => "2840",
            "bestRating" => "5",
            "worstRating" => "1"
        ],
        "sameAs" => [
            FACEBOOK_LINK,
            INSTAGRAM_LINK,
            LINKEDIN_LINK,
            TWITTER_LINK,
            YOUTUBE_LINK,
            PINTEREST_LINK,
            TIKTOK_LINK
        ],
        "founder" => [
            [
                "@type" => "Person",
                "@id" => BASE_URL . "/team.php#usman-hashmi",
                "name" => "Usman Hashmi",
                "jobTitle" => "Co-Founder & Chief Executive Officer (CEO)",
                "description" => "Top Rated Real Estate Photo Editor with 17,000+ hours on Upwork. Specialist in luxury HDR bracket fusion, flambient retouching, 3D virtual staging, and day-to-dusk conversion.",
                "url" => BASE_URL . "/team.php#usman-hashmi",
                "sameAs" => [
                    "https://www.crunchbase.com/person/usman-hashmi",
                    "https://www.producthunt.com/@uzithecreator",
                    "https://www.behance.net/usmanhashmi1",
                    "https://medium.com/@usman.hashmi905",
                    "https://about.me/usman.hashmi",
                    "https://gravatar.com/usmanhashmi905",
                    "https://taplink.cc/uzithecreator",
                    "https://linktr.ee/usman.hashmi905",
                    "https://www.flickr.com/people/205022697@N02/",
                    "https://github.com/usmanhashmi2024",
                    "https://www.upwork.com/freelancers/usmans",
                    "https://www.linkedin.com/in/usman-hashmi-editing-expert/",
                    "https://www.facebook.com/UsmanHashmiPOV",
                    "https://www.instagram.com/uzithecreator0/"
                ]
            ],
            [
                "@type" => "Person",
                "@id" => BASE_URL . "/team.php#salman-hashmi",
                "name" => "Salman Hashmi",
                "jobTitle" => "Co-Founder & Head of Production Operations",
                "description" => "Master architectural retoucher and workflow engineer spearheading daily high-volume production queues and multi-bracket exposure fusion.",
                "url" => BASE_URL . "/team.php#salman-hashmi",
                "sameAs" => [
                    "https://www.linkedin.com/in/hsalmanhashmi/",
                    "https://www.facebook.com/HSalmanhashmi"
                ]
            ]
        ]
    ];
}

/**
 * WebSite & Sitelinks Searchbox Schema
 */
function getWebsiteSearchSchema(): array {
    return [
        "@context" => "https://schema.org",
        "@type" => "WebSite",
        "@id" => BASE_URL . "/#website",
        "url" => BASE_URL,
        "name" => "Estate HDR",
        "publisher" => [
            "@id" => BASE_URL . "/#organization"
        ],
        "potentialAction" => [
            "@type" => "SearchAction",
            "target" => [
                "@type" => "EntryPoint",
                "urlTemplate" => BASE_URL . "/blog?q={search_term_string}"
            ],
            "query-input" => "required name=search_term_string"
        ]
    ];
}

/**
 * Service & Offer Schema
 */
function getServiceRichSchema(string $serviceName, string $slug, string $description, float $priceFrom = 0.80, string $image = ''): array {
    $serviceUrl = BASE_URL . "/services/" . $slug;
    $imgUrl = !empty($image) ? (str_starts_with($image, 'http') ? $image : BASE_URL . $image) : BASE_URL . "/assets/images/portfolio/hdr/1-after.jpg";
    
    return [
        "@context" => "https://schema.org",
        "@type" => "Service",
        "@id" => $serviceUrl . "/#service",
        "name" => $serviceName . " — Estate HDR",
        "serviceType" => $serviceName,
        "description" => $description,
        "url" => $serviceUrl,
        "image" => $imgUrl,
        "provider" => [
            "@id" => BASE_URL . "/#organization"
        ],
        "offers" => [
            "@type" => "Offer",
            "url" => $serviceUrl,
            "price" => number_format($priceFrom, 2, '.', ''),
            "priceCurrency" => "USD",
            "availability" => "https://schema.org/InStock",
            "validFrom" => "2026-01-01",
            "priceValidUntil" => "2027-12-31"
        ],
        "aggregateRating" => [
            "@type" => "AggregateRating",
            "ratingValue" => "4.98",
            "reviewCount" => "1420",
            "bestRating" => "5",
            "worstRating" => "1"
        ]
    ];
}

/**
 * FAQPage Schema generator
 */
function getFaqPageSchema(array $faqs): array {
    $entities = [];
    foreach ($faqs as $faq) {
        $q = $faq['q'] ?? $faq['question'] ?? '';
        $a = $faq['a'] ?? $faq['answer'] ?? '';
        if (!empty($q) && !empty($a)) {
            $entities[] = [
                "@type" => "Question",
                "name" => strip_tags($q),
                "acceptedAnswer" => [
                    "@type" => "Answer",
                    "text" => strip_tags($a)
                ]
            ];
        }
    }
    
    return [
        "@context" => "https://schema.org",
        "@type" => "FAQPage",
        "mainEntity" => $entities
    ];
}

/**
 * BreadcrumbList Schema generator
 */
function getBreadcrumbListSchema(array $crumbs): array {
    $itemList = [];
    $pos = 1;
    foreach ($crumbs as $crumb) {
        $name = $crumb['name'] ?? '';
        $url = $crumb['url'] ?? '';
        if (!empty($name) && !empty($url)) {
            $fullUrl = str_starts_with($url, 'http') ? $url : (BASE_URL . (str_starts_with($url, '/') ? '' : '/') . $url);
            $itemList[] = [
                "@type" => "ListItem",
                "position" => $pos++,
                "name" => $name,
                "item" => $fullUrl
            ];
        }
    }
    
    return [
        "@context" => "https://schema.org",
        "@type" => "BreadcrumbList",
        "itemListElement" => $itemList
    ];
}

/**
 * Article / BlogPosting Schema generator
 */
function getArticleRichSchema(array $post): array {
    $slug = $post['slug'] ?? '';
    $postUrl = BASE_URL . "/blog/" . $slug;
    $title = $post['title'] ?? '';
    $excerpt = $post['excerpt'] ?? $post['meta_description'] ?? '';
    $image = $post['featured_image'] ?? '/assets/images/portfolio/hdr/1-after.jpg';
    $fullImage = str_starts_with($image, 'http') ? $image : BASE_URL . $image;
    $datePublished = !empty($post['created_at']) ? date('c', strtotime($post['created_at'])) : date('c');
    $dateModified = !empty($post['updated_at']) ? date('c', strtotime($post['updated_at'])) : $datePublished;
    $author = $post['author'] ?? 'Estate HDR Editorial Team';
    
    return [
        "@context" => "https://schema.org",
        "@type" => "BlogPosting",
        "@id" => $postUrl . "/#article",
        "mainEntityOfPage" => [
            "@type" => "WebPage",
            "@id" => $postUrl
        ],
        "headline" => $title,
        "description" => $excerpt,
        "image" => [
            "@type" => "ImageObject",
            "url" => $fullImage,
            "width" => 1200,
            "height" => 630
        ],
        "datePublished" => $datePublished,
        "dateModified" => $dateModified,
        "author" => [
            "@type" => "Person",
            "name" => $author,
            "url" => BASE_URL . "/team"
        ],
        "publisher" => [
            "@id" => BASE_URL . "/#organization"
        ]
    ];
}

/**
 * Contextual Keyword Auto-Linker Engine for Programmatic Internal Linking
 * Automatically links target commercial keyword anchors to corresponding service/pillar pages
 * to boost Page Authority and rank for 500+ long-tail search terms.
 */
function autoLinkKeywords(string $html, string $currentUrl = ''): string {
    $keywords = [
        'professional real estate photo editing' => '/real-estate-photo-editing',
        'real estate photo editing services'    => '/real-estate-photo-editing',
        'real estate photo editing'             => '/real-estate-photo-editing',
        'real estate photo retouching'          => '/real-estate-photo-editing',
        '3D virtual staging'                    => '/services/virtual-staging',
        'virtual staging services'              => '/services/virtual-staging',
        'virtual staging'                       => '/services/virtual-staging',
        'virtual twilight'                      => '/services/virtual-twilight',
        'day to dusk conversion'                => '/services/virtual-twilight',
        'day to dusk'                           => '/services/virtual-twilight',
        'HDR photo editing'                     => '/services/hdr-photo-editing',
        'flambient photo editing'               => '/services/hdr-photo-editing',
        'flambient'                             => '/services/hdr-photo-editing',
        'item removal'                          => '/services/item-removal',
        'object removal and decluttering'       => '/services/item-removal',
        '2D and 3D floor plans'                 => '/services/floor-plans',
        '3D floor plans'                        => '/services/floor-plans',
        'floor plans'                           => '/services/floor-plans',
        'interactive pricing calculator'        => '/pricing.php',
        'pricing calculator'                    => '/pricing.php',
        'free trial'                            => '/#trial',
    ];

    uksort($keywords, fn($a, $b) => strlen($b) <=> strlen($a));

    // Tokenize HTML to protect existing links, headings, scripts, styles, and tags
    $tokens = preg_split('/(<a\b[^>]*>.*?<\/a>|<(?:h[1-6]|script|style|button|input|textarea)\b[^>]*>.*?<\/(?:h[1-6]|script|style|button|input|textarea)>|<[^>]+>)/is', $html, -1, PREG_SPLIT_DELIM_CAPTURE);

    $replacedTotal = 0;
    foreach ($keywords as $kw => $targetUrl) {
        if ($currentUrl && (str_contains($currentUrl, $targetUrl) || $currentUrl === $targetUrl)) {
            continue;
        }

        $kwPattern = '/\b(' . preg_quote($kw, '/') . ')\b/i';
        $kwReplaced = 0;

        foreach ($tokens as &$token) {
            if (empty($token) || $token[0] === '<') {
                continue;
            }

            if ($kwReplaced < 2) {
                $token = preg_replace_callback($kwPattern, function($matches) use ($targetUrl, &$kwReplaced, &$replacedTotal) {
                    if ($kwReplaced >= 2) {
                        return $matches[0];
                    }
                    $kwReplaced++;
                    $replacedTotal++;
                    return '<a href="' . htmlspecialchars($targetUrl) . '" class="text-gold hover:underline font-semibold" title="' . htmlspecialchars($matches[1]) . '">' . $matches[1] . '</a>';
                }, $token, 2 - $kwReplaced);
            }
        }
        unset($token);
    }

    return implode('', $tokens);
}

