<?php
/**
 * Estate HDR — Unified Public Navigation Bar with Dynamic Active Gold Highlighting
 * Exact Same Nav Links: Services, How It Works, Pricing, Portfolio, Blog, Contact, FAQ
 */
$publicCurrent = basename($_SERVER['PHP_SELF'] ?? '', '.php');
$reqUri = $_SERVER['REQUEST_URI'] ?? '';
$isHome = ($publicCurrent === 'index' || $publicCurrent === '' || $reqUri === '/' || $reqUri === '/index.php');
?>
<style nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
.nav-link.nav-active {
  color: #C9A84C !important;
  font-weight: 800 !important;
  position: relative;
}
.nav-link.nav-active::after {
  content: '';
  position: absolute;
  bottom: -6px;
  left: 0;
  right: 0;
  height: 2.5px;
  background: #C9A84C;
  border-radius: 9999px;
  box-shadow: 0 0 10px rgba(201,168,76,0.8);
}
.mobile-nav-link.mobile-nav-active {
  background: rgba(201,168,76,0.15) !important;
  color: #C9A84C !important;
  font-weight: 800 !important;
  border-left: 3px solid #C9A84C !important;
}
</style>
<link rel="alternate" type="application/rss+xml" title="Estate HDR RSS Feed" href="/rss.xml">
<script type="application/ld+json" nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "Estate HDR",
  "url": "https://estatehdr.com",
  "logo": "https://estatehdr.com/assets/images/logo.png",
  "sameAs": [
    "https://www.facebook.com/estatehdr1",
    "https://www.instagram.com/estate_hdr",
    "https://www.linkedin.com/company/estate-hdr",
    "https://x.com/estatehdr",
    "https://www.youtube.com/@estatehdr",
    "https://www.pinterest.com/estatehdr",
    "https://www.tiktok.com/@estatehdr"
  ],
  "parentOrganization": {
    "@type": "Organization",
    "name": "Estate HDR Studio Group Ltd"
  },
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "71-75 Shelton Street, Covent Garden",
    "addressLocality": "London",
    "postalCode": "WC2H 9JQ",
    "addressCountry": "GB"
  },
  "founder": [
    {
      "@type": "Person",
      "@id": "https://estatehdr.com/team.php#usman-hashmi",
      "name": "Usman Hashmi",
      "jobTitle": "Co-Founder & Chief Executive Officer (CEO)",
      "description": "Top Rated Real Estate Photo Editor with 17,000+ hours on Upwork. Specialist in luxury HDR bracket fusion, flambient retouching, 3D virtual staging, and day-to-dusk conversion.",
      "url": "https://estatehdr.com/team.php#usman-hashmi",
      "sameAs": [
        "https://www.crunchbase.com/person/usman-hashmi",
        "https://www.producthunt.com/@uzithecreator",
        "https://www.behance.net/usmanhashmi1",
        "https://medium.com/@usman.hashmi905",
        "https://about.me/usman.hashmi",
        "https://gravatar.com/usmanhashmi905",
        "https://taplink.cc/uzithecreator",
        "https://linktr.ee/usman.hashmi905",
        "https://www.flickr.com/people/205022697@N02/",
        "https://github.com/usmanhashmi2024",
        "https://www.upwork.com/freelancers/usmans",
        "https://www.linkedin.com/in/usman-hashmi-editing-expert/",
        "https://www.facebook.com/UsmanHashmiPOV",
        "https://www.instagram.com/uzithecreator0/"
      ]
    },
    {
      "@type": "Person",
      "@id": "https://estatehdr.com/team.php#salman-hashmi",
      "name": "Salman Hashmi",
      "jobTitle": "Co-Founder & Head of Production Operations",
      "description": "Master architectural retoucher and workflow engineer spearheading daily high-volume production queues and multi-bracket exposure fusion.",
      "url": "https://estatehdr.com/team.php#salman-hashmi",
      "sameAs": [
        "https://www.linkedin.com/in/hsalmanhashmi/",
        "https://www.facebook.com/HSalmanhashmi"
      ]
    }
  ]
}
</script>

<!-- NAV -->
<nav id="navbar" role="navigation" aria-label="Main Navigation" class="fixed top-0 left-0 right-0 z-50 transition-all duration-500 bg-dark/85 backdrop-blur-md border-b border-dark-border/60">
  <div class="max-w-[1850px] mx-auto px-6 lg:px-8">
    <div class="flex items-center justify-between h-20 sm:h-24">
      <!-- Brand Logo -->
      <a href="/" class="flex items-center gap-3 py-1 flex-shrink-0" aria-label="Estate HDR Home">
        <img src="/assets/images/logo.png" alt="Estate HDR - Real Estate Photo Editing & 3D Staging" width="240" height="84" class="h-16 sm:h-20 w-auto object-contain max-h-[80px]">
      </a>

      <!-- Full Master Public Navigation Links (Identical across all pages) -->
      <div class="hidden md:flex items-center gap-3 lg:gap-4 xl:gap-6 font-bold text-xs lg:text-sm">
        <a href="/"              data-nav="home"         class="nav-link <?= $isHome ? 'nav-active text-gold' : 'text-gray-300' ?> hover:text-gold transition-colors">Home</a>
        <a href="/about"         data-nav="about"        class="nav-link <?= $publicCurrent === 'about' ? 'nav-active text-gold' : 'text-gray-300' ?> hover:text-gold transition-colors">About</a>
        <a href="/#services"     data-nav="services"     class="nav-link <?= $publicCurrent === 'service' ? 'nav-active text-gold' : 'text-gray-300' ?> hover:text-gold transition-colors">Services</a>
        <a href="/#how-it-works" data-nav="how-it-works" class="nav-link text-gray-300 hover:text-gold transition-colors">How It Works</a>
        <a href="/pricing"       data-nav="pricing"      class="nav-link <?= $publicCurrent === 'pricing' ? 'nav-active text-gold' : 'text-gray-300' ?> hover:text-gold transition-colors">Pricing</a>
        <a href="/portfolio"     data-nav="portfolio"    class="nav-link <?= $publicCurrent === 'portfolio' ? 'nav-active text-gold' : 'text-gray-300' ?> hover:text-gold transition-colors">Portfolio</a>
        <a href="/team"          data-nav="team"         class="nav-link <?= $publicCurrent === 'team' ? 'nav-active text-gold' : 'text-gray-300' ?> hover:text-gold transition-colors">Our Team</a>
        <a href="/blog"          data-nav="blog"         class="nav-link <?= in_array($publicCurrent, ['blog', 'blog-post']) ? 'nav-active text-gold' : 'text-gray-300' ?> hover:text-gold transition-colors">Blog</a>
        <a href="/contact"       data-nav="contact"      class="nav-link <?= $publicCurrent === 'contact' ? 'nav-active text-gold' : 'text-gray-300' ?> hover:text-gold transition-colors">Contact</a>
        <a href="/#faq"          data-nav="faq"          class="nav-link text-gray-300 hover:text-gold transition-colors">FAQ</a>
      </div>

      <!-- Quick Search & Right Action Controls -->
      <div class="hidden md:flex items-center gap-2 lg:gap-3">
        <form action="/blog" method="GET" role="search" class="flex items-center relative" aria-label="Site Search">
          <input type="search" name="q" placeholder="Search..." aria-label="Search guides & services" class="bg-[#111118] border border-dark-border focus:border-gold rounded-xl py-1.5 pl-8 pr-2.5 text-xs text-white placeholder-gray-500 w-28 lg:w-36 xl:w-48 focus:w-48 transition-all outline-none">
          <svg class="w-3.5 h-3.5 text-gray-400 absolute left-2.5 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
        </form>
        <?php if (isLoggedIn()): ?>
          <a href="/dashboard" class="btn-ghost py-2.5 px-5 text-xs font-bold">Dashboard &rarr;</a>
        <?php else: ?>
          <a href="/login"    class="btn-ghost py-2.5 px-5 text-xs font-bold">Sign In</a>
          <a href="/register" class="btn-gold py-2.5 px-6 text-xs font-black shadow-glow">Start Free</a>
        <?php endif; ?>
      </div>

      <!-- Mobile Menu Hamburger Button -->
      <div class="flex items-center gap-2 md:hidden">
        <button id="mobileMenuBtn" onclick="window.ehdrToggleMobileMenu()" class="p-2.5 rounded-xl bg-dark-card/80 border border-dark-border hover:border-gold/50 text-gray-300 hover:text-white transition-all focus:outline-none focus:ring-2 focus:ring-gold/50" aria-label="Toggle Navigation Menu" aria-expanded="false" aria-controls="mobileMenu">
          <svg id="menuOpenIcon" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M4 6h16M4 12h16M4 18h16"/></svg>
          <svg id="menuCloseIcon" class="w-6 h-6 hidden" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M6 18L18 6M6 6l12 12"/></svg>
        </button>
      </div>
    </div>
  </div>

  <!-- Mobile Navigation Drawer -->
  <div id="mobileMenu" class="hidden md:hidden bg-dark-card/98 backdrop-blur-2xl border-t border-dark-border px-6 py-6 shadow-2xl max-h-[85vh] overflow-y-auto" role="dialog" aria-label="Mobile Navigation Menu">
    <div class="flex flex-col gap-3.5 text-sm font-semibold">
      
      <!-- Mobile Quick Search -->
      <form action="/blog" method="GET" role="search" class="relative w-full">
        <input type="search" name="q" placeholder="Search guides & services..." class="bg-[#111118] border border-dark-border focus:border-gold rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-gray-500 w-full outline-none">
        <svg class="w-4 h-4 text-gray-400 absolute left-3 top-2.5 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
      </form>

      <!-- Primary Links -->
      <div class="space-y-1">
        <div class="text-xs font-semibold text-gray-400 tracking-wide mb-2">Main Navigation</div>
        <a href="/"              data-nav="home"         class="mobile-nav-link flex items-center justify-between py-2 px-3 rounded-lg <?= $isHome ? 'mobile-nav-active bg-gold/15 text-gold' : 'text-gray-300 hover:bg-white/5 hover:text-white' ?> transition-colors">
          <span>🏠 Home</span>
          <span class="text-xs text-gray-400">&rarr;</span>
        </a>
        <a href="/about"         data-nav="about"        class="mobile-nav-link flex items-center justify-between py-2 px-3 rounded-lg <?= $publicCurrent === 'about' ? 'mobile-nav-active bg-gold/15 text-gold' : 'text-gray-300 hover:bg-white/5 hover:text-white' ?> transition-colors">
          <span>🏛️ About Us</span>
          <span class="text-xs text-gray-400">&rarr;</span>
        </a>
        <a href="/#services"     data-nav="services"     class="mobile-nav-link flex items-center justify-between py-2 px-3 rounded-lg <?= $publicCurrent === 'service' ? 'mobile-nav-active bg-gold/15 text-gold' : 'text-gray-300 hover:bg-white/5 hover:text-white' ?> transition-colors">
          <span>⚡ All Services</span>
          <span class="text-xs text-gray-400">&rarr;</span>
        </a>
        <a href="/#how-it-works" data-nav="how-it-works" class="mobile-nav-link flex items-center justify-between py-2 px-3 rounded-lg text-gray-300 hover:bg-white/5 hover:text-white transition-colors">
          <span>🔄 How It Works</span>
          <span class="text-xs text-gray-400">&rarr;</span>
        </a>
        <a href="/pricing"       data-nav="pricing"      class="mobile-nav-link flex items-center justify-between py-2 px-3 rounded-lg <?= $publicCurrent === 'pricing' ? 'mobile-nav-active bg-gold/15 text-gold' : 'text-gray-300 hover:bg-white/5 hover:text-white' ?> transition-colors">
          <span>💳 Pricing Calculator</span>
          <span class="text-xs text-gray-400">&rarr;</span>
        </a>
        <a href="/portfolio"     data-nav="portfolio"    class="mobile-nav-link flex items-center justify-between py-2 px-3 rounded-lg <?= $publicCurrent === 'portfolio' ? 'mobile-nav-active bg-gold/15 text-gold' : 'text-gray-300 hover:bg-white/5 hover:text-white' ?> transition-colors">
          <span>🖼️ Interactive Portfolio</span>
          <span class="text-xs text-gray-400">&rarr;</span>
        </a>
        <a href="/team"          data-nav="team"         class="mobile-nav-link flex items-center justify-between py-2 px-3 rounded-lg <?= $publicCurrent === 'team' ? 'mobile-nav-active bg-gold/15 text-gold' : 'text-gray-300 hover:bg-white/5 hover:text-white' ?> transition-colors">
          <span>👥 Creative Team</span>
          <span class="text-xs text-gray-400">&rarr;</span>
        </a>
        <a href="/blog"          data-nav="blog"         class="mobile-nav-link flex items-center justify-between py-2 px-3 rounded-lg <?= in_array($publicCurrent, ['blog', 'blog-post']) ? 'mobile-nav-active bg-gold/15 text-gold' : 'text-gray-300 hover:bg-white/5 hover:text-white' ?> transition-colors">
          <span>📰 Guides &amp; Blog</span>
          <span class="text-xs text-gray-400">&rarr;</span>
        </a>
        <a href="/contact"       data-nav="contact"      class="mobile-nav-link flex items-center justify-between py-2 px-3 rounded-lg <?= $publicCurrent === 'contact' ? 'mobile-nav-active bg-gold/15 text-gold' : 'text-gray-300 hover:bg-white/5 hover:text-white' ?> transition-colors">
          <span>📞 Contact &amp; Support</span>
          <span class="text-xs text-gray-400">&rarr;</span>
        </a>
        <a href="/#faq"          data-nav="faq"          class="mobile-nav-link flex items-center justify-between py-2 px-3 rounded-lg text-gray-300 hover:bg-white/5 hover:text-white transition-colors">
          <span>❓ FAQ</span>
          <span class="text-xs text-gray-400">&rarr;</span>
        </a>
      </div>

      <!-- Specific Services Group -->
      <div class="pt-2 border-t border-dark-border/70 space-y-1">
        <div class="text-xs font-semibold text-gray-400 tracking-wide mb-2">Core Retouching Services</div>
        <div class="grid grid-cols-2 gap-1.5 text-xs">
          <a href="/services/hdr-photo-editing" class="p-2 rounded-lg bg-dark/60 border border-dark-border hover:border-gold/40 text-gray-300 hover:text-gold transition-all">☀️ HDR Editing</a>
          <a href="/services/virtual-staging"   class="p-2 rounded-lg bg-dark/60 border border-dark-border hover:border-gold/40 text-gray-300 hover:text-gold transition-all">🛋️ 3D Staging</a>
          <a href="/services/floor-plans"       class="p-2 rounded-lg bg-dark/60 border border-dark-border hover:border-gold/40 text-gray-300 hover:text-gold transition-all">📐 Floor Plans</a>
          <a href="/services/item-removal"      class="p-2 rounded-lg bg-dark/60 border border-dark-border hover:border-gold/40 text-gray-300 hover:text-gold transition-all">✨ Decluttering</a>
          <a href="/services/virtual-twilight"  class="p-2 rounded-lg bg-dark/60 border border-dark-border hover:border-gold/40 text-gray-300 hover:text-gold transition-all">🌅 Twilight</a>
          <a href="/services/day-to-dusk"       class="p-2 rounded-lg bg-dark/60 border border-dark-border hover:border-gold/40 text-gray-300 hover:text-gold transition-all">🌇 Day to Dusk</a>
        </div>
      </div>

      <!-- Action CTAs -->
      <div class="pt-3 border-t border-dark-border space-y-2.5">
        <a href="/#trial" class="btn-gold block text-center py-3 text-sm font-black shadow-glow">
          Claim Free Trial (No Signup) &rarr;
        </a>
        <a href="https://wa.me/447706068176" target="_blank" rel="noopener noreferrer" class="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl bg-emerald-600/90 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md">
          <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.182-.573c.978.58 1.911.928 3.145.929 3.178 0 5.767-2.587 5.768-5.766.001-3.187-2.575-5.771-5.764-5.771zm3.392 8.244c-.144.405-.837.774-1.17.824-.299.045-.677.063-1.092-.069-.252-.08-.575-.187-.988-.365-1.739-.751-2.874-2.502-2.961-2.617-.087-.116-.708-.94-.708-1.793s.448-1.273.607-1.446c.159-.173.346-.217.462-.217l.332.006c.106.005.249-.04.39.298.144.347.491 1.2.534 1.287.043.087.072.188.014.304-.058.116-.087.188-.173.289l-.26.304c-.087.086-.177.18-.076.354.101.174.449.741.964 1.201.662.591 1.221.774 1.394.86s.275.072.376-.043c.101-.116.433-.506.549-.68.116-.173.231-.145.39-.087s1.011.477 1.184.564.289.13.332.202c.043.072.043.419-.101.824z"/></svg>
          <span>Chat on WhatsApp (+44 770 606 8176)</span>
        </a>

        <?php if (isLoggedIn()): ?>
          <a href="/dashboard.php" class="btn-ghost block text-center py-2.5 text-xs font-bold">Open Client Dashboard &rarr;</a>
        <?php else: ?>
          <div class="grid grid-cols-2 gap-2.5 pt-1">
            <a href="/login.php"    class="btn-ghost text-center py-2.5 text-xs font-bold">Sign In</a>
            <a href="/register.php" class="btn-gold text-center py-2.5 text-xs font-bold">Client Register</a>
          </div>
        <?php endif; ?>
      </div>

    </div>
  </div>
</nav>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
// Dynamic Active Navigation Link Highlighter & ScrollSpy Engine
function updateActiveNavLink(key) {
  if (!key) return;
  
  // Desktop Navbar Links
  document.querySelectorAll('.nav-link').forEach(function(el) {
    if (el.getAttribute('data-nav') === key) {
      el.classList.add('nav-active', 'text-gold');
      el.classList.remove('text-gray-300');
    } else {
      el.classList.remove('nav-active', 'text-gold');
      el.classList.add('text-gray-300');
    }
  });

  // Mobile Drawer Links
  document.querySelectorAll('.mobile-nav-link').forEach(function(el) {
    if (el.getAttribute('data-nav') === key) {
      el.classList.add('mobile-nav-active', 'bg-gold/15', 'text-gold');
      el.classList.remove('text-gray-300');
    } else {
      el.classList.remove('mobile-nav-active', 'bg-gold/15', 'text-gold');
      el.classList.add('text-gray-300');
    }
  });
}

// Auto-detect current page / hash on load & hashchange
function detectAndHighlightActiveNav() {
  const path = window.location.pathname.toLowerCase();
  const hash = window.location.hash.toLowerCase();

  if (hash && ['#services', '#how-it-works', '#pricing', '#faq'].includes(hash)) {
    updateActiveNavLink(hash.replace('#', ''));
    return;
  }

  if (path.includes('portfolio')) {
    updateActiveNavLink('portfolio');
  } else if (path.includes('team')) {
    updateActiveNavLink('team');
  } else if (path.includes('blog')) {
    updateActiveNavLink('blog');
  } else if (path.includes('contact')) {
    updateActiveNavLink('contact');
  } else if (path.includes('services') || path.includes('service')) {
    updateActiveNavLink('services');
  } else if (path === '/' || path.includes('index') || path === '') {
    updateActiveNavLink('home');
  }
}

// Unified Mobile Navigation Controller
window.ehdrToggleMobileMenu = function(forceClose) {
  const menu = document.getElementById('mobileMenu');
  const btn  = document.getElementById('mobileMenuBtn');
  const openIcon  = document.getElementById('menuOpenIcon');
  const closeIcon = document.getElementById('menuCloseIcon');
  if (!menu || !btn) return;

  const isCurrentlyOpen = !menu.classList.contains('hidden');
  const shouldOpen = forceClose ? false : !isCurrentlyOpen;

  if (shouldOpen) {
    menu.classList.remove('hidden');
    btn.setAttribute('aria-expanded', 'true');
    if (openIcon) openIcon.classList.add('hidden');
    if (closeIcon) closeIcon.classList.remove('hidden');
  } else {
    menu.classList.add('hidden');
    btn.setAttribute('aria-expanded', 'false');
    if (openIcon) openIcon.classList.remove('hidden');
    if (closeIcon) closeIcon.classList.add('hidden');
  }
};

// Event Listeners Initialization
document.addEventListener('DOMContentLoaded', function() {
  detectAndHighlightActiveNav();

  // Instant click listener for all links
  document.querySelectorAll('.nav-link, .mobile-nav-link').forEach(function(link) {
    link.addEventListener('click', function() {
      const key = this.getAttribute('data-nav');
      if (key) updateActiveNavLink(key);
      window.ehdrToggleMobileMenu(true);
    });
  });

  // On Homepage, run ScrollSpy to update active nav as user scrolls
  const isHomepage = (window.location.pathname === '/' || window.location.pathname.includes('index') || window.location.pathname === '');
  if (isHomepage) {
    const sections = [
      { id: 'faq', key: 'faq' },
      { id: 'pricing', key: 'pricing' },
      { id: 'how-it-works', key: 'how-it-works' },
      { id: 'services', key: 'services' },
      { id: 'hero', key: 'home' }
    ];

    window.addEventListener('scroll', function() {
      const scrollPos = window.scrollY + 250;
      for (let i = 0; i < sections.length; i++) {
        const sec = document.getElementById(sections[i].id);
        if (sec && scrollPos >= sec.offsetTop) {
          updateActiveNavLink(sections[i].key);
          break;
        }
      }
    }, { passive: true });
  }

  // Close on Escape key
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
      window.ehdrToggleMobileMenu(true);
    }
  });
});

window.addEventListener('hashchange', detectAndHighlightActiveNav);
</script>
<script src="/assets/js/custom-dialogs.js" defer></script></script>
