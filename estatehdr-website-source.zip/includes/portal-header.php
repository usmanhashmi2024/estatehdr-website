<?php
/**
 * Estate HDR — Unified Client Portal Header
 * Single-line horizontal layout: Logo + Nav Tabs on Left/Center | + New Job on Right
 */
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$currentUser = currentUser();
$userBalance = 0.00;
if ($currentUser) {
    $dbUser = getUserById($currentUser['id']) ?? $currentUser;
    $userBalance = (float)($dbUser['balance'] ?? 0.00);
}

// Balance formatting (+ / -)
$balVal = (float)$userBalance;
if ($balVal > 0) {
    $balBadgeCls = 'bg-[#B91C1C]/25 text-red-400 border-red-500/50';
    $balDisplay  = 'Charges: US -$' . number_format($balVal, 2);
    $balNote     = 'Due';
} elseif ($balVal < 0) {
    $balBadgeCls = 'bg-emerald-500/25 text-emerald-400 border-emerald-500/50';
    $balDisplay  = 'Credit: US +$' . number_format(abs($balVal), 2);
    $balNote     = 'Prepaid';
} else {
    $balBadgeCls = 'bg-blue-600/20 text-blue-400 border-blue-500/40';
    $balDisplay  = 'Charges: US $0.00';
    $balNote     = 'Clear';
}
?>
<!-- ── TOP CONTACT & STATUS BAR ──────────────────────────────── -->
<div class="border-b border-[#1E1E2E]/90 bg-[#07070B] text-sm text-gray-400 py-2 px-6 sm:px-10">
  <div class="max-w-[1850px] mx-auto flex items-center justify-between gap-4">
    <div class="flex items-center gap-6">
      <span class="flex items-center gap-2">
        <span class="text-gold text-base">✉️</span> <span class="font-mono text-gray-300 font-semibold">info@estatehdr.com</span>
      </span>
      <span class="flex items-center gap-2">
        <span class="text-gold text-base">📞</span> <span class="font-mono text-gray-300 font-semibold">+44 770 606 8176</span>
      </span>
      <a href="/" class="hover:text-gold transition-colors flex items-center gap-1.5 font-bold text-xs ml-2">
        <span>🏠</span> <span>Home Website</span>
      </a>
    </div>

    <div class="flex items-center gap-5">
      <!-- +/- Charges & Balance Status Pill -->
      <div class="px-3.5 py-1 rounded-xl border font-mono font-black text-xs shadow-sm <?= $balBadgeCls ?>" title="Your Account Billing Status">
        <span><?= $balDisplay ?></span>
        <span class="text-[10px] uppercase tracking-wider ml-1 opacity-80">(<?= $balNote ?>)</span>
      </div>

      

      <!-- User Badge & Sign Out -->
      <?php if ($currentUser): 
        $clientRawName = $currentUser['name'] ?? 'Client';
        $clientWords = preg_split('/\s+/', trim($clientRawName));
        $clientInitials = count($clientWords) >= 2 
            ? strtoupper(substr($clientWords[0], 0, 1) . substr($clientWords[1], 0, 1))
            : strtoupper(substr($clientRawName, 0, 2));
      ?>
      <div class="flex items-center gap-2.5">
        <a href="/profile.php" class="w-8 h-8 rounded-full bg-gold text-dark flex items-center justify-center font-black text-xs shadow-sm hover:ring-2 hover:ring-gold transition-all" title="My Profile (<?= htmlspecialchars($clientRawName) ?>)">
          <?= htmlspecialchars($clientInitials) ?>
        </a>
        <a href="/profile.php" class="font-bold text-white hover:text-gold text-sm truncate max-w-[200px]" title="<?= htmlspecialchars($clientRawName) ?>">
          <?= htmlspecialchars($clientRawName) ?>
        </a>
      </div>
      <?php endif; ?>

      <a href="/logout.php" class="text-gray-400 hover:text-red-400 text-xs transition-colors font-bold uppercase tracking-wider">Sign Out</a>
    </div>
  </div>
</div>

<!-- ── MAIN NAVBAR (SINGLE HORIZONTAL LINE) ──────────────────── -->
<header class="bg-[#0B0C12] border-b border-[#1E1E2E] py-3.5 px-6 sm:px-10 sticky top-0 z-40 backdrop-blur-md">
  <div class="max-w-[1850px] mx-auto flex items-center justify-between gap-6">
    
    <!-- Left: Logo + Navigation Tabs Side-by-Side on the SAME Line -->
    <div class="flex items-center gap-6 lg:gap-8 flex-1 min-w-0">
      <!-- Brand Logo -->
      <a href="/dashboard.php" class="flex items-center py-1 flex-shrink-0 group">
        <img src="/assets/images/logo.png" alt="Estate HDR" class="h-16 sm:h-20 w-auto object-contain max-h-[74px] transition-transform group-hover:scale-105" onerror="this.outerHTML='<span class=\'font-bold text-white text-2xl tracking-tight\'>Estate<span class=\'text-gold\'>HDR</span></span>'">
      </a>

      <!-- Navigation Tabs (Clean Bold Horizontal Row) -->
      <nav class="hidden md:flex items-center gap-1.5 sm:gap-2.5 text-xs sm:text-sm font-black uppercase tracking-wider overflow-x-auto py-1">
        <a href="/" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all bg-[#161622] text-gold hover:bg-gold hover:text-dark font-black border border-gold/40 inline-flex items-center gap-1.5 shadow-sm">
          <span>🏠</span> <span>MAIN SITE</span>
        </a>
        <a href="/dashboard.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $currentPage === 'dashboard' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
          DASHBOARD
        </a>
        <a href="/pending-jobs.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $currentPage === 'pending-jobs' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
          PENDING JOBS
        </a>
        <a href="/completed-jobs.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $currentPage === 'completed-jobs' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
          COMPLETED JOBS
        </a>
        <a href="/billing.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $currentPage === 'billing' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
          TRANSACTION HISTORY
        </a>
        <a href="/preferences.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $currentPage === 'preferences' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
          PREFERENCES
        </a>
        <a href="/support.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= in_array($currentPage, ['support', 'knowledge-base']) ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
          SUPPORT &amp; CHAT
        </a>
        <a href="/profile.php" class="px-3.5 py-2 rounded-xl whitespace-nowrap transition-all <?= $currentPage === 'profile' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white hover:bg-[#161622]' ?>">
          MY PROFILE
        </a>
      </nav>
    </div>

    <!-- Right: + New Job Button Anchored to Far Right -->
    <div class="flex items-center flex-shrink-0">
      <a href="/order-new.php" class="btn-gold py-2.5 px-6 text-xs sm:text-sm font-black shadow-glow inline-flex items-center gap-1.5 rounded-xl">
        <span>+</span> <span>New Job</span>
      </a>
    </div>

  </div>
</header>
<script src="/assets/js/table-sorter.js" defer></script>
<?php require_once __DIR__ . '/portal-chat-widget.php'; ?>
