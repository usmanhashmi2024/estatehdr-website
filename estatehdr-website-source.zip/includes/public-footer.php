<?php
/**
 * Estate HDR — Unified Public Footer Component
 * Standardized across all public pages with full schema links, legal pages, social links, and WhatsApp chat
 */
?>
<!-- FOOTER -->
<footer class="border-t border-dark-border py-16 px-6 bg-dark" role="contentinfo">
  <div class="max-w-7xl mx-auto">
    <div class="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
      <!-- Brand & Info -->
      <div class="col-span-1 md:col-span-2">
        <a href="/" class="flex items-center gap-3 mb-5 py-1" aria-label="Estate HDR Home">
          <img src="/assets/images/logo.png" alt="Estate HDR - Real Estate Photo Editing & 3D Staging" width="240" height="84" class="h-20 sm:h-24 w-auto object-contain max-h-[84px]">
        </a>
        <p class="text-gray-300 text-sm leading-relaxed max-w-sm mb-6">
          Premium real estate photo editing, virtual staging, HDR blending, and floor plan services. Fast 24-hour turnaround for agencies and photographers worldwide.
        </p>

        <!-- Parent Company Entity & Physical Address -->
        <p class="text-xs text-gray-400 leading-relaxed mb-3">
          <strong>Parent Company &amp; Corporate Entity:</strong> Estate HDR is a specialized real estate post-production brand owned and operated by our parent company, <strong class="text-gray-200">Estate HDR Studio Group Ltd</strong> (Company Registration No: 14892015).
        </p>
        <address class="not-italic text-xs text-gray-400 mb-5 flex items-start gap-2" itemscope itemtype="https://schema.org/PostalAddress">
          <span class="text-gold flex-shrink-0 mt-0.5">📍</span>
          <span>
            <strong>Physical Address &amp; Registered Headquarters:</strong> 
            <span itemprop="streetAddress">71-75 Shelton Street, Covent Garden</span>, 
            <span itemprop="addressLocality">London</span>, 
            <span itemprop="postalCode">WC2H 9JQ</span>, 
            <span itemprop="addressCountry">United Kingdom</span>
          </span>
        </address>

        <!-- Direct Contact Pills -->
        <div class="flex flex-col sm:flex-row gap-3 mb-5">
          <a href="mailto:info@estatehdr.com" class="inline-flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-dark-card border border-dark-border hover:border-gold/50 text-sm text-gray-300 hover:text-gold transition-all">
            <svg class="w-4 h-4 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
            <span>info@estatehdr.com</span>
          </a>
          <a href="<?= WHATSAPP_LINK ?>" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40 hover:border-emerald-500 text-sm text-emerald-400 hover:text-emerald-400 transition-all">
            <svg class="w-4 h-4 text-emerald-400" fill="currentColor" viewBox="0 0 24 24"><path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.182-.573c.978.58 1.911.928 3.145.929 3.178 0 5.767-2.587 5.768-5.766.001-3.187-2.575-5.771-5.764-5.771zm3.392 8.244c-.144.405-.837.774-1.17.824-.299.045-.677.063-1.092-.069-.252-.08-.575-.187-.988-.365-1.739-.751-2.874-2.502-2.961-2.617-.087-.116-.708-.94-.708-1.793s.448-1.273.607-1.446c.159-.173.346-.217.462-.217l.332.006c.106.005.249-.04.39.298.144.347.491 1.2.534 1.287.043.087.072.188.014.304-.058.116-.087.188-.173.289l-.26.304c-.087.086-.177.18-.076.354.101.174.449.741.964 1.201.662.591 1.221.774 1.394.86s.275.072.376-.043c.101-.116.433-.506.549-.68.116-.173.231-.145.39-.087s1.011.477 1.184.564.289.13.332.202c.043.072.043.419-.101.824z"/></svg>
            <span>WhatsApp Support</span>
          </a>
        </div>

        <!-- DMCA Signal & Trust Badges -->
        <div class="flex flex-wrap items-center gap-3 mb-6 text-xs text-gray-400">
          <a href="https://www.dmca.com/Protection/Status.aspx?ID=estatehdr.com" title="DMCA.com Protection Status" class="dmca-badge inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-dark-card border border-dark-border hover:border-gold/50 transition-colors" target="_blank" rel="noopener noreferrer">
            <img src="https://images.dmca.com/Badges/dmca-badge-w100-5x1-01.png?ID=estatehdr.com" alt="DMCA.com Protection Status" width="100" height="20" class="inline-block">
            <span class="font-bold text-gray-300">DMCA Protected</span>
          </a>
          <a href="/terms#dmca" class="text-gray-400 hover:text-gold text-xs underline">DMCA Policy</a>
          <span class="text-dark-border">•</span>
          <span class="text-gray-400">ISO 12646 Calibrated Studio</span>
        </div>

        <!-- Quick Search in Footer -->
        <div class="mb-6 max-w-sm">
          <span class="text-xs font-bold text-gray-400 tracking-wide block mb-2 font-medium">Search Estate HDR:</span>
          <form action="/blog" method="GET" role="search" class="relative w-full" aria-label="Footer Site Search">
            <input type="search" name="q" placeholder="Search guides, floor plans, virtual staging..." aria-label="Search guides and services" class="w-full bg-[#111118] border border-dark-border focus:border-gold rounded-xl py-2 pl-9 pr-3 text-xs text-white placeholder-gray-500 outline-none transition-all">
            <svg class="w-4 h-4 text-gray-400 absolute left-3 top-2.5 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
          </form>
        </div>

        <!-- Official Social Channels (Facebook, Instagram, LinkedIn, X/Twitter, YouTube, Pinterest, TikTok, RSS) -->
        <div class="space-y-2">
          <span class="text-xs font-bold text-gray-400 tracking-wide block font-medium">Official Social Channels:</span>
          <div class="flex flex-wrap items-center gap-2">
            <!-- Facebook -->
            <a href="<?= FACEBOOK_LINK ?>" target="_blank" rel="noopener noreferrer" class="w-9 h-9 rounded-xl bg-dark-card border border-dark-border hover:border-blue-500/60 flex items-center justify-center text-gray-300 hover:text-gold hover:scale-110 transition-all shadow-md" title="Facebook" aria-label="Facebook">
              <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
            </a>
            <!-- Instagram -->
            <a href="<?= INSTAGRAM_LINK ?>" target="_blank" rel="noopener noreferrer" class="w-9 h-9 rounded-xl bg-dark-card border border-dark-border hover:border-pink-500/60 flex items-center justify-center text-gray-300 hover:text-gold hover:scale-110 transition-all shadow-md" title="Instagram" aria-label="Instagram">
              <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
            </a>
            <!-- LinkedIn -->
            <a href="<?= LINKEDIN_LINK ?>" target="_blank" rel="noopener noreferrer" class="w-9 h-9 rounded-xl bg-dark-card border border-dark-border hover:border-blue-400/60 flex items-center justify-center text-gray-300 hover:text-gold hover:scale-110 transition-all shadow-md" title="LinkedIn" aria-label="LinkedIn">
              <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
            </a>
            <!-- Twitter/X -->
            <a href="<?= TWITTER_LINK ?>" target="_blank" rel="noopener noreferrer" class="w-9 h-9 rounded-xl bg-dark-card border border-dark-border hover:border-gray-400 flex items-center justify-center text-gray-300 hover:text-white hover:scale-110 transition-all shadow-md" title="Twitter / X" aria-label="Twitter / X">
              <svg class="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
            </a>
            <!-- YouTube -->
            <a href="<?= YOUTUBE_LINK ?>" target="_blank" rel="noopener noreferrer" class="w-9 h-9 rounded-xl bg-dark-card border border-dark-border hover:border-red-500/60 flex items-center justify-center text-gray-300 hover:text-red-400 hover:scale-110 transition-all shadow-md" title="YouTube" aria-label="YouTube">
              <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
            </a>
            <!-- Pinterest -->
            <a href="<?= PINTEREST_LINK ?>" target="_blank" rel="noopener noreferrer" class="w-9 h-9 rounded-xl bg-dark-card border border-dark-border hover:border-gold/60 flex items-center justify-center text-gray-300 hover:text-gold hover:scale-110 transition-all shadow-md" title="Pinterest" aria-label="Pinterest">
              <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.162-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.69 0 1.029-.655 2.568-.994 3.995-.283 1.194.599 2.169 1.777 2.169 2.133 0 3.772-2.249 3.772-5.495 0-2.873-2.064-4.882-5.012-4.882-3.414 0-5.418 2.561-5.418 5.207 0 1.031.397 2.138.893 2.738.098.119.112.224.083.345-.09.378-.293 1.199-.334 1.368-.053.225-.172.271-.401.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.92-7.252 4.158 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.354-.629-2.758-1.379l-.749 2.848c-.269 1.045-1.004 2.352-1.498 3.146 1.123.345 2.306.535 3.55.535 6.607 0 11.985-5.365 11.985-11.987C23.97 5.39 18.592.026 11.985.026L12.017 0z"/></svg>
            </a>
            <!-- TikTok -->
            <a href="<?= TIKTOK_LINK ?>" target="_blank" rel="noopener noreferrer" class="w-9 h-9 rounded-xl bg-dark-card border border-dark-border hover:border-cyan-400 flex items-center justify-center text-gray-300 hover:text-gold hover:scale-110 transition-all shadow-md" title="TikTok" aria-label="TikTok">
              <svg class="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24"><path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.97-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.24 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/></svg>
            </a>
            <!-- RSS Feed -->
            <a href="/rss.xml" target="_blank" rel="noopener noreferrer" class="w-9 h-9 rounded-xl bg-dark-card border border-dark-border hover:border-gold/60 flex items-center justify-center text-gray-300 hover:text-gold hover:scale-110 transition-all shadow-md" title="RSS Feed" aria-label="RSS Feed">
              <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M6.503 20.752c0 1.794-1.456 3.248-3.251 3.248-1.796 0-3.252-1.454-3.252-3.248 0-1.794 1.456-3.248 3.252-3.248 1.795.001 3.251 1.454 3.251 3.248zm-6.503-12.572v4.811c6.05 0 10.96 4.91 10.96 10.96h4.811c0-8.7-7.072-15.771-15.771-15.771zm0-8.18v4.812c10.564 0 19.139 8.574 19.139 19.138h4.811c0-13.216-10.733-23.95-23.95-23.95z"/></svg>
            </a>
          </div>
        </div>
      </div>

      <!-- Services List -->
      <div>
        <h3 class="font-semibold text-white mb-5 text-base">Core Services</h3>
        <ul class="space-y-3 text-sm text-gray-300">
          <li><a href="/real-estate-photo-editing" class="hover:text-gold transition-colors font-semibold text-gold">Photo Editing Services</a></li>
          <li><a href="/services/flambient-photo-editing" class="hover:text-gold transition-colors">Flambient Editing</a></li>
          <li><a href="/services/hdr-photo-editing" class="hover:text-gold transition-colors">HDR Bracket Blending</a></li>
          <li><a href="/services/window-pull" class="hover:text-gold transition-colors">Window Pull Recovery</a></li>
          <li><a href="/services/virtual-staging" class="hover:text-gold transition-colors">3D Virtual Staging</a></li>
          <li><a href="/services/floor-plans" class="hover:text-gold transition-colors">2D &amp; 3D Floor Plans</a></li>
          <li><a href="/services/day-to-dusk" class="hover:text-gold transition-colors">Day to Dusk Conversion</a></li>
          <li><a href="/services/real-estate-video-editing" class="hover:text-gold transition-colors">Video &amp; Drone Reels</a></li>
        </ul>
      </div>

      <!-- Platform & Company Links -->
      <div>
        <h3 class="font-semibold text-white mb-5 text-base">Company &amp; Quick Links</h3>
        <ul class="space-y-3 text-sm text-gray-300">
          <li><a href="/about"           class="text-gold font-bold hover:underline">About Estate HDR</a></li>
          <li><a href="/#trial"         class="text-gold font-medium hover:underline">Claim Free Trial (No Signup)</a></li>
          <li><a href="/alternatives"   class="hover:text-gold transition-colors">Compare Alternatives</a></li>
          <li><a href="/portfolio"      class="hover:text-gold transition-colors">Interactive Portfolio</a></li>
          <li><a href="/team"           class="hover:text-gold transition-colors">Our Creative Team</a></li>
          <li><a href="https://www.upwork.com/freelancers/usmans" target="_blank" rel="noopener noreferrer" class="text-emerald-400 font-semibold hover:underline flex items-center gap-1.5"><span class="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block animate-pulse"></span>Usman Hashmi on Upwork (Top Rated)</a></li>
          <li><a href="/blog"           class="hover:text-gold transition-colors">Photography Guides &amp; Blog</a></li>
          <li><a href="/editorial-guidelines" class="hover:text-gold transition-colors">Editorial Guidelines</a></li>
          <li><a href="/sitemap"        class="hover:text-gold transition-colors">HTML Sitemap</a></li>
          <li><a href="/contact"        class="hover:text-gold transition-colors">Contact Support</a></li>
          <li><a href="<?= WHATSAPP_LINK ?>" target="_blank" rel="noopener noreferrer" class="text-emerald-400 hover:underline">WhatsApp Support</a></li>
        </ul>
      </div>
    </div>

    <!-- Bottom Bar -->
    <div class="border-t border-dark-border pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
      <div class="flex flex-col sm:flex-row items-center gap-3 sm:gap-6 text-sm">
        <p class="text-gray-400 font-medium">&copy; <?= date('Y') ?> Estate HDR. Operated by Estate HDR Studio Group Ltd. All rights reserved.</p>
        <div class="flex flex-wrap items-center gap-3 text-xs font-semibold">
          <a href="/terms" class="text-gray-400 hover:text-gold transition-colors">Terms</a>
          <span class="text-dark-border">&bull;</span>
          <a href="/privacy" class="text-gray-400 hover:text-gold transition-colors">Privacy</a>
          <span class="text-dark-border">&bull;</span>
          <a href="/editorial-guidelines" class="text-gray-400 hover:text-gold transition-colors">Editorial Policy</a>
          <span class="text-dark-border">&bull;</span>
          <a href="/sitemap" class="text-gray-400 hover:text-gold transition-colors">HTML Sitemap</a>
          <span class="text-dark-border">&bull;</span>
          <a href="/sitemap.xml" target="_blank" rel="noopener noreferrer" class="text-gray-400 hover:text-gold transition-colors">XML Sitemap</a>
          <span class="text-dark-border">&bull;</span>
          <a href="/rss.xml" target="_blank" rel="noopener noreferrer" class="text-gold hover:underline">RSS / Atom Feed</a>
        </div>
      </div>
      <div class="flex items-center gap-4 text-xs text-gray-300">
        <a href="<?= FACEBOOK_LINK ?>" target="_blank" rel="noopener noreferrer" class="hover:text-gold transition-colors">Facebook</a>
        <a href="<?= INSTAGRAM_LINK ?>" target="_blank" rel="noopener noreferrer" class="hover:text-gold transition-colors">Instagram</a>
        <a href="<?= LINKEDIN_LINK ?>" target="_blank" rel="noopener noreferrer" class="hover:text-gold transition-colors">LinkedIn</a>
        <a href="<?= TWITTER_LINK ?>" target="_blank" rel="noopener noreferrer" class="hover:text-white transition-colors">X</a>
        <a href="<?= YOUTUBE_LINK ?>" target="_blank" rel="noopener noreferrer" class="hover:text-red-400 transition-colors">YouTube</a>
        <a href="<?= PINTEREST_LINK ?>" target="_blank" rel="noopener noreferrer" class="hover:text-gold transition-colors">Pinterest</a>
        <a href="<?= TIKTOK_LINK ?>" target="_blank" rel="noopener noreferrer" class="hover:text-gold transition-colors">TikTok</a>
      </div>
    </div>
  </div>
</footer>

<?php require_once __DIR__ . '/chat-widgets.php'; ?>

<?php if (empty($GLOBALS['_ehdr_animation_scripts_loaded'])): $GLOBALS['_ehdr_animation_scripts_loaded'] = true; ?>
<!-- Master Animation & Smooth Momentum Scroll Engine -->
<script src="/assets/js/vendor/gsap.min.js" defer></script>
<script src="/assets/js/vendor/ScrollTrigger.min.js" defer></script>
<script src="/assets/js/vendor/lenis.min.js" defer></script>
<script src="/assets/js/animations.js?v=<?= file_exists(ROOT_PATH . '/assets/js/animations.js') ? filemtime(ROOT_PATH . '/assets/js/animations.js') : time() ?>" defer></script>
<?php endif; ?>

