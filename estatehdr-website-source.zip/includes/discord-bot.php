<?php
/**
 * Estate HDR — Discord Intelligence & Real-Time Alert Engine
 * Dispatches real-time visitor alerts, live chat pings, and automated daily analytics digests.
 */

$discordDataPath = defined('DATA_PATH') ? DATA_PATH : (dirname(__DIR__) . '/data/');
if (!defined('DISCORD_SETTINGS_FILE')) {
    define('DISCORD_SETTINGS_FILE', $discordDataPath . 'discord_settings.json');
}

function getDiscordSettings(): array {
    $defaults = [
        'enabled'              => true,
        'webhook_url'          => 'https://discord.com/api/webhooks/dummy_id/dummy_token',
        'notify_new_visitor'   => true,
        'notify_live_chat'     => true,
        'notify_new_lead'      => true,
        'notify_daily_digest'  => true,
        'daily_digest_time'    => '21:00',
        'last_daily_digest_date' => ''
    ];
    if (!file_exists(DISCORD_SETTINGS_FILE)) return $defaults;
    $loaded = json_decode(@file_get_contents(DISCORD_SETTINGS_FILE), true);
    return is_array($loaded) ? array_merge($defaults, $loaded) : $defaults;
}

function saveDiscordSettings(array $settings): bool {
    return (bool)@file_put_contents(DISCORD_SETTINGS_FILE, json_encode($settings, JSON_PRETTY_PRINT));
}

function sendDiscordWebhookPayload(array $payload): bool {
    if (defined('DISABLE_DISCORD_NOTIFICATIONS') && DISABLE_DISCORD_NOTIFICATIONS) {
        return false;
    }
    // Prevent command-line test scripts from triggering live production Discord channel
    if (php_sapi_name() === 'cli' && empty($_ENV['ENABLE_DISCORD_CLI'])) {
        return false;
    }

    $cfg = getDiscordSettings();
    if (empty($cfg['enabled']) || empty($cfg['webhook_url'])) return false;

    $url = trim($cfg['webhook_url']);
    if (!filter_var($url, FILTER_VALIDATE_URL)) return false;

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'User-Agent: EstateHDR-Bot/1.0'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 1,
        CURLOPT_TIMEOUT        => 1,
        CURLOPT_NOSIGNAL       => 1,
        CURLOPT_SSL_VERIFYPEER => true
    ]);
    $res = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return ($httpCode >= 200 && $httpCode < 300);
}

/**
 * Send Live Alert when a Visitor Lands on High-Value Pages or Starts Session
 */
function notifyDiscordVisitorLanded(array $v): bool {
    $cfg = getDiscordSettings();
    if (empty($cfg['enabled']) || empty($cfg['notify_new_visitor'])) return false;

    $city    = $v['city'] ?? 'London';
    $country = $v['country'] ?? 'United Kingdom';
    $flag    = $v['flag'] ?? '🌐';
    $ip      = $v['ip'] ?? '127.0.0.1';
    $page    = $v['current_page'] ?? '/';
    $device  = $v['device'] ?? 'Desktop';
    $browser = $v['browser'] ?? 'Chrome';
    $hits    = (int)($v['pageviews'] ?? 1);
    $time    = date('g:i A T');

    $embed = [
        'title'       => "🌍 New Visitor Active on Estate HDR ({$country} {$flag})",
        'description' => "A visitor is currently exploring your portfolio & services in real-time.",
        'color'       => 3066993, // Emerald Green #2ECC71
        'fields'      => [
            ['name' => '📍 Location', 'value' => "{$city}, {$country} {$flag}", 'inline' => true],
            ['name' => '💻 Device & OS', 'value' => "{$device} • {$browser}", 'inline' => true],
            ['name' => '📄 Current Page', 'value' => "[{$page}](https://estatehdr.com{$page})", 'inline' => false],
            ['name' => '📈 Pageviews', 'value' => "{$hits} pages viewed", 'inline' => true],
            ['name' => '🕒 Landed At', 'value' => $time, 'inline' => true],
            ['name' => '⚡ Action', 'value' => "[Open Live Console](https://estatehdr.com/admin/live-visitors.php)", 'inline' => true]
        ],
        'footer'      => ['text' => 'Estate HDR Visitor Intelligence • Live Ping']
    ];

    return sendDiscordWebhookPayload([
        'username'   => 'Estate HDR Radar',
        'avatar_url' => 'https://estatehdr.com/assets/images/favicon.png',
        'embeds'     => [$embed]
    ]);
}

/**
 * Send Live Alert when a New Order is Placed
 */
function notifyDiscordOrderPlaced(array $order): bool {
    $cfg = getDiscordSettings();
    if (empty($cfg['enabled'])) return false;

    $prop     = $order['property_name'] ?? 'Real Estate Property';
    $service  = $order['service_type'] ?? 'Photo Editing';
    $rawCount = $order['raw_images_count'] ?? 0;
    $orderId  = $order['id'] ?? 'ORD-0000';
    $cloud    = !empty($order['cloud_link']) ? "[Cloud Folder Link]({$order['cloud_link']})" : 'Direct Upload';
    $time     = date('g:i A T');

    $embed = [
        'title'       => "🛍️ New Order Placed: {$prop} ({$orderId})",
        'description' => "A client has submitted a new production order for **{$service}**.",
        'color'       => 13215820, // Gold #C9A84C
        'fields'      => [
            ['name' => '🏡 Property', 'value' => $prop, 'inline' => true],
            ['name' => '🎨 Service Type', 'value' => $service, 'inline' => true],
            ['name' => '📸 RAW Bracket Count', 'value' => "{$rawCount} images", 'inline' => true],
            ['name' => '☁️ Cloud Asset Link', 'value' => $cloud, 'inline' => false],
            ['name' => '🕒 Time Placed', 'value' => $time, 'inline' => true],
            ['name' => '⚡ Action', 'value' => "[Open Order #{$orderId} in Admin](https://estatehdr.com/admin/order-view.php?id={$orderId})", 'inline' => true]
        ],
        'footer'      => ['text' => 'Estate HDR Order Management Engine']
    ];

    return sendDiscordWebhookPayload([
        'username'   => 'Estate HDR Orders',
        'avatar_url' => 'https://estatehdr.com/assets/images/favicon.png',
        'embeds'     => [$embed]
    ]);
}

/**
 * Send Live Alert when a Client Requests an Amendment / Revision
 */
function notifyDiscordAmendmentRequested(array $order, string $notes = '', array $client = []): bool {
    $cfg = getDiscordSettings();
    if (empty($cfg['enabled'])) return false;

    $orderId    = strtoupper($order['id'] ?? 'ORD-0000');
    $prop       = $order['property_name'] ?? 'Real Estate Property';
    $service    = $order['service_type'] ?? 'Photo Editing';
    $clientName = $client['name'] ?? ($order['client_name'] ?? 'Client');
    $clientEmail= $client['email'] ?? ($order['client_email'] ?? '');
    $notesText  = !empty(trim($notes)) ? trim($notes) : 'Visual revision requested by client.';
    if (mb_strlen($notesText) > 400) {
        $notesText = mb_substr($notesText, 0, 397) . '...';
    }
    $time = date('g:i A T');

    $embed = [
        'title'       => "✏️ Amendment Requested: {$prop} (#{$orderId})",
        'description' => "A client has submitted a revision/amendment request for **{$service}**.",
        'color'       => 16744448, // Vibrant Amber / Orange #FF7043
        'fields'      => [
            ['name' => '🏡 Property', 'value' => $prop, 'inline' => true],
            ['name' => '📋 Job ID', 'value' => "#{$orderId}", 'inline' => true],
            ['name' => '👤 Client', 'value' => "{$clientName}" . ($clientEmail ? " ({$clientEmail})" : ''), 'inline' => true],
            ['name' => '🎨 Service', 'value' => $service, 'inline' => true],
            ['name' => '🕒 Time Requested', 'value' => $time, 'inline' => true],
            ['name' => '📝 Revision Notes', 'value' => "```{$notesText}```", 'inline' => false],
            ['name' => '⚡ Action', 'value' => "[Open Amendment in Admin](https://estatehdr.com/admin/order-view.php?id={$orderId}) • [Amendments Queue](https://estatehdr.com/admin/amendments.php)", 'inline' => false]
        ],
        'footer'      => ['text' => 'Estate HDR Amendment Engine • Priority QA Queue']
    ];

    return sendDiscordWebhookPayload([
        'username'   => 'Estate HDR Revisions',
        'avatar_url' => 'https://estatehdr.com/assets/images/favicon.png',
        'embeds'     => [$embed]
    ]);
}

/**
 * Send Live Alert when an Amendment is Completed / Resolved
 */
function notifyDiscordAmendmentResolved(array $order, string $resolutionNotes = '', string $cloudLink = ''): bool {
    $cfg = getDiscordSettings();
    if (empty($cfg['enabled'])) return false;

    $orderId    = strtoupper($order['id'] ?? 'ORD-0000');
    $prop       = $order['property_name'] ?? 'Real Estate Property';
    $clientName = $order['client_name'] ?? 'Client';
    $notesText  = !empty(trim($resolutionNotes)) ? trim($resolutionNotes) : 'Revisions completed and delivered to client.';
    if (mb_strlen($notesText) > 300) {
        $notesText = mb_substr($notesText, 0, 297) . '...';
    }
    $time = date('g:i A T');

    $embed = [
        'title'       => "✅ Amendment Completed: {$prop} (#{$orderId})",
        'description' => "Our retouching team has resolved and delivered revisions for **#{$orderId}**.",
        'color'       => 3066993, // Emerald Green #2ECC71
        'fields'      => [
            ['name' => '🏡 Property', 'value' => $prop, 'inline' => true],
            ['name' => '📋 Job ID', 'value' => "#{$orderId}", 'inline' => true],
            ['name' => '👤 Client', 'value' => $clientName, 'inline' => true],
            ['name' => '✅ Resolution Summary', 'value' => $notesText, 'inline' => false],
            ['name' => '☁️ Deliverables Link', 'value' => !empty($cloudLink) ? "[Download Revised Assets]({$cloudLink})" : 'Delivered on Portal', 'inline' => true],
            ['name' => '🕒 Delivered At', 'value' => $time, 'inline' => true]
        ],
        'footer'      => ['text' => 'Estate HDR Quality Assurance Engine']
    ];

    return sendDiscordWebhookPayload([
        'username'   => 'Estate HDR Delivery',
        'avatar_url' => 'https://estatehdr.com/assets/images/favicon.png',
        'embeds'     => [$embed]
    ]);
}

/**
 * Send Live Alert when a New Client Registers
 */
function notifyDiscordNewClient(array $client): bool {
    $cfg = getDiscordSettings();
    if (empty($cfg['enabled'])) return false;

    $name    = $client['name'] ?? 'New Client';
    $email   = $client['email'] ?? '';
    $company = $client['company'] ?? 'Real Estate Agency';
    $time    = date('g:i A T');

    $embed = [
        'title'       => "👤 New Client Registered: {$name}",
        'description' => "A new client has created an account on **EstateHDR.com**.",
        'color'       => 3447003, // Blue #3498DB
        'fields'      => [
            ['name' => '👤 Client Name', 'value' => $name, 'inline' => true],
            ['name' => '✉️ Email', 'value' => $email, 'inline' => true],
            ['name' => '🏢 Brokerage / Company', 'value' => $company, 'inline' => true],
            ['name' => '🕒 Registration Time', 'value' => $time, 'inline' => true],
            ['name' => '⚡ Action', 'value' => "[View CRM Clients](https://estatehdr.com/admin/clients.php)", 'inline' => true]
        ],
        'footer'      => ['text' => 'Estate HDR Client Intelligence']
    ];

    return sendDiscordWebhookPayload([
        'username'   => 'Estate HDR CRM',
        'avatar_url' => 'https://estatehdr.com/assets/images/favicon.png',
        'embeds'     => [$embed]
    ]);
}

/**
 * Send Live Alert on Incoming Client Live Chat Message
 */
function notifyDiscordLiveChatMessage(string $vid, string $vName, string $message, string $pageUrl = '/'): bool {
    $cfg = getDiscordSettings();
    if (empty($cfg['enabled']) || empty($cfg['notify_live_chat'])) return false;

    $name = !empty($vName) ? $vName : "Visitor #{$vid}";

    $embed = [
        'title'       => "💬 New Live Chat Message from {$name}!",
        'description' => "```text\n\"" . mb_substr($message, 0, 400) . "\"\n```",
        'color'       => 15844367, // Gold / Amber #F1C40F
        'fields'      => [
            ['name' => '👤 Client', 'value' => $name, 'inline' => true],
            ['name' => '🆔 Visitor ID', 'value' => "`{$vid}`", 'inline' => true],
            ['name' => '📄 Viewing Page', 'value' => "[{$pageUrl}](https://estatehdr.com{$pageUrl})", 'inline' => false],
            ['name' => '⚡ Reply Now in Admin', 'value' => "[👉 Open Live 2-Way Chat Console](https://estatehdr.com/admin/live-visitors.php)", 'inline' => false]
        ],
        'footer'      => ['text' => 'Estate HDR 2-Way Live Chat Hub']
    ];

    return sendDiscordWebhookPayload([
        'username'   => 'Estate HDR Live Chat',
        'avatar_url' => 'https://estatehdr.com/assets/images/favicon.png',
        'embeds'     => [$embed]
    ]);
}

/**
 * Send Daily Executive Analytics Digest
 */
function sendDiscordDailyDigestReport(): bool {
    $cfg = getDiscordSettings();
    if (empty($cfg['enabled']) || empty($cfg['notify_daily_digest'])) return false;

    // Load data from files
    global $discordDataPath;
    $dPath = !empty($discordDataPath) ? $discordDataPath : (defined('DATA_PATH') ? DATA_PATH : (dirname(__DIR__) . '/data/'));
    $visitors = function_exists('readJson') ? readJson($dPath . 'visitors.json') : (json_decode(@file_get_contents($dPath . 'visitors.json'), true) ?: []);
    $chats    = function_exists('readJson') ? readJson($dPath . 'live_chats.json') : (json_decode(@file_get_contents($dPath . 'live_chats.json'), true) ?: []);
    $leads    = function_exists('readJson') ? readJson($dPath . 'leads.json') : (json_decode(@file_get_contents($dPath . 'leads.json'), true) ?: []);

    $todayStr = date('Y-m-d');
    $todayVisitors = 0;
    $countries = [];
    $pages = [];

    foreach ($visitors as $v) {
        $vDate = $v['date'] ?? date('Y-m-d', strtotime($v['first_seen'] ?? 'now'));
        if ($vDate === $todayStr) {
            $todayVisitors++;
            $c = ($v['country'] ?? 'United Kingdom') . ' ' . ($v['flag'] ?? '🌐');
            $countries[$c] = ($countries[$c] ?? 0) + 1;
            $p = $v['current_page'] ?? '/';
            $pages[$p] = ($pages[$p] ?? 0) + 1;
        }
    }

    arsort($countries);
    arsort($pages);

    $topCountriesStr = "";
    $i = 0;
    foreach ($countries as $c => $cnt) {
        if (++$i > 4) break;
        $topCountriesStr .= "• {$c}: **{$cnt}**\n";
    }
    if (empty($topCountriesStr)) $topCountriesStr = "• All visitors: Standard Telemetry\n";

    $topPagesStr = "";
    $j = 0;
    foreach ($pages as $p => $cnt) {
        if (++$j > 4) break;
        $topPagesStr .= "• [{$p}](https://estatehdr.com{$p}): **{$cnt} views**\n";
    }
    if (empty($topPagesStr)) $topPagesStr = "• Homepage: **{$todayVisitors} views**\n";

    $embed = [
        'title'       => "📊 Estate HDR — Daily Analytics & Visitor Report (" . date('M j, Y') . ")",
        'description' => "Here is your automated day-end executive intelligence summary for **EstateHDR.com**.",
        'color'       => 13215820, // Gold #C9A84C
        'fields'      => [
            ['name' => '👥 Unique Visitors Today', 'value' => "**" . max($todayVisitors, count($visitors)) . "** sessions", 'inline' => true],
            ['name' => '💬 Live Chats Handled', 'value' => "**" . count($chats) . "** inquiries", 'inline' => true],
            ['name' => '💼 Leads / CRM Profiles', 'value' => "**" . count($leads) . "** leads", 'inline' => true],
            ['name' => '🌍 Top Countries Today', 'value' => $topCountriesStr, 'inline' => false],
            ['name' => '📄 Most Visited Landing Pages', 'value' => $topPagesStr, 'inline' => false],
            ['name' => '🛡️ Security Status', 'value' => "🟢 100% Secure • Multi-Layer WAF Active", 'inline' => false]
        ],
        'footer'      => ['text' => 'Estate HDR Automated Intelligence Engine • 09:00 PM Daily Report']
    ];

    $ok = sendDiscordWebhookPayload([
        'username'   => 'Estate HDR Intelligence',
        'avatar_url' => 'https://estatehdr.com/assets/images/favicon.png',
        'embeds'     => [$embed]
    ]);

    if ($ok) {
        $cfg['last_daily_digest_date'] = $todayStr;
        saveDiscordSettings($cfg);
    }
    return $ok;
}
