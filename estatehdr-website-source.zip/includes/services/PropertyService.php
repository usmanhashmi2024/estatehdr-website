<?php
/**
 * Estate HDR - Project & Property Management Service
 * Enterprise Layer: Project -> Property -> Order Hierarchy & Property Entity
 * 
 * Tracks real estate listings/properties, previous orders, media assets, and specs.
 */

class PropertyService {
    private static string $propFile = __DIR__ . '/../../data/properties.json';
    private static string $projFile = __DIR__ . '/../../data/projects.json';

    public static function getProperties(?string $orgId = null): array {
        if (!file_exists(self::$propFile)) {
            @file_put_contents(self::$propFile, json_encode([], JSON_PRETTY_PRINT));
            return [];
        }
        $data = json_decode(@file_get_contents(self::$propFile), true);
        if (!is_array($data)) return [];
        if ($orgId) {
            return array_filter($data, fn($p) => ($p['organization_id'] ?? '') === $orgId);
        }
        return $data;
    }

    public static function getPropertyById(string $propId): ?array {
        $props = self::getProperties();
        return $props[$propId] ?? null;
    }

    /**
     * Create or auto-link a property record from an incoming order
     */
    public static function findOrCreateProperty(
        string $address,
        string $clientId,
        string $orgId = 'org-estatehdr-default',
        array $extraSpecs = []
    ): array {
        $props = self::getProperties();
        $normalizedAddr = trim(strtolower($address));
        
        // Match existing property by normalized address and client/org
        foreach ($props as $id => $prop) {
            if (trim(strtolower($prop['address'] ?? '')) === $normalizedAddr &&
                ($prop['client_id'] ?? '') === $clientId) {
                return $prop;
            }
        }

        // Create new Property
        $propId = 'PROP-' . strtoupper(substr(md5($address . $clientId . time()), 0, 8));
        $newProp = [
            'id' => $propId,
            'organization_id' => $orgId,
            'client_id' => $clientId,
            'address' => $address,
            'mls_id' => $extraSpecs['mls_id'] ?? '',
            'property_type' => $extraSpecs['property_type'] ?? 'Residential Single Family',
            'bedrooms' => $extraSpecs['bedrooms'] ?? 0,
            'bathrooms' => $extraSpecs['bathrooms'] ?? 0,
            'sqft' => $extraSpecs['sqft'] ?? 0,
            'agent_name' => $extraSpecs['agent_name'] ?? '',
            'brokerage' => $extraSpecs['brokerage'] ?? '',
            'listing_status' => $extraSpecs['listing_status'] ?? 'Active Listing',
            'orders' => [],
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $props[$propId] = $newProp;
        @file_put_contents(self::$propFile, json_encode($props, JSON_PRETTY_PRINT));
        return $newProp;
    }

    /**
     * Link an order to a property's order history
     */
    public static function linkOrderToProperty(string $propId, string $orderId): bool {
        $props = self::getProperties();
        if (!isset($props[$propId])) return false;

        if (!in_array($orderId, $props[$propId]['orders'] ?? [])) {
            $props[$propId]['orders'][] = $orderId;
            $props[$propId]['updated_at'] = date('Y-m-d H:i:s');
            @file_put_contents(self::$propFile, json_encode($props, JSON_PRETTY_PRINT));
        }
        return true;
    }

    /**
     * Projects Management (Grouping multiple orders/properties for an agency)
     */
    public static function getProjects(?string $orgId = null): array {
        if (!file_exists(self::$projFile)) {
            @file_put_contents(self::$projFile, json_encode([], JSON_PRETTY_PRINT));
            return [];
        }
        $data = json_decode(@file_get_contents(self::$projFile), true);
        return is_array($data) ? $data : [];
    }
}
