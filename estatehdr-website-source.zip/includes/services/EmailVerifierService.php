<?php
declare(strict_types=1);

namespace EstateHDR\Services;

/**
 * Estate HDR — Production-Grade Email Verification Engine
 * 
 * Multi-layer deliverability, risk assessment, and mailbox existence pipeline:
 * 1. Normalization & RFC 5322 Syntax Check
 * 2. DNS MX & A Record Resolution + Null MX Detection
 * 3. Mail Provider Fingerprinting (Google Workspace, M365, Zoho, etc.)
 * 4. Disposable / Temporary Email Domain Detection (250+ domains)
 * 5. Role-Based Address Detection (admin, support, sales, info, etc.)
 * 6. Common Domain Typo Detection & Smart Suggestion
 * 7. Direct Low-Level SMTP Mailbox Handshake (EHLO, MAIL FROM, RCPT TO)
 * 8. Catch-All Domain Probing (Random Mailbox Acceptance Check)
 * 9. Composite Risk & Quality Deliverability Scoring (0 - 100)
 * 10. Bulk Batch Pipeline for Estate HDR CRM Contacts
 */
class EmailVerifierService
{
    /** @var string Storage directory for CRM data */
    private static string $storageDir = __DIR__ . '/../../data/email_crm';

    /** @var array In-memory DNS & MX cache to accelerate bulk processing */
    private static array $dnsMxCache = [];

    /**
     * Curated database of known disposable / temporary email domains.
     */
    private static array $disposableDomains = [
        'mailinator.com', '10minutemail.com', 'tempmail.com', 'temp-mail.org', 'guerrillamail.com',
        'guerrillamail.net', 'guerrillamail.biz', 'sharklasers.com', 'grr.la', 'yopmail.com',
        'yopmail.fr', 'yopmail.net', 'trashmail.com', 'trashmail.net', 'trashmail.me',
        'dispostable.com', 'getairmail.com', 'mohmal.com', 'throwawaymail.com', 'inboxkitten.com',
        'fakemailgenerator.com', 'crazymailing.com', 'generator.email', 'tempail.com', 'burnermail.io',
        'mytemp.email', 'dropmail.me', 'tempmailaddress.com', 'nada.ltd', 'getnada.com',
        'inboxbear.com', 'emailondeck.com', 'crazymail.com', 'disposablemail.com', 'armyspy.com',
        'cuvox.de', 'dayrep.com', 'fleckens.hu', 'gustr.com', 'jourrapide.com', 'rhyta.com',
        'superrito.com', 'teleworm.us', 'einrot.com', 'fmail.com', 'clipmail.eu', 'drdrb.net',
        'spambog.com', 'spambog.de', 'spambog.ru', 'tempr.email', 'discard.email', 'discardmail.com',
        'spamevader.com', 'trash-mail.at', 'trashmail.at', 'wegwerfmail.de', 'wegwerfmail.net',
        'trashmail.io', 'mailnull.com', 'spamgourmet.com', 'mintemail.com', 'instantemailaddress.com',
        'anonbox.net', 'mytempemail.com', 'boun.cr', 'hidemail.de', 'fastmail.fm', 'sofort-mail.de',
        'kasmail.com', 'mailcatch.com', 'maileater.com', 'mailforspam.com', 'mailmoat.com',
        'mailnesia.com', 'mailscrap.com', 'mailslurp.com', 'meltmail.com', 'noclickemail.com',
        'owlpic.com', 'safetymail.info', 'shieldedmail.com', 'shortmail.net', 'spamspot.com',
        'tempinbox.com', 'tempmailer.com', 'trashymail.com', 'whyspam.me', 'zillamail.com',
        '0-mail.com', '10minutemail.net', '20minutemail.com', '33mail.com', 'anonaddy.me'
    ];

    /**
     * Role-based email account prefixes.
     */
    private static array $rolePrefixes = [
        'admin', 'administrator', 'info', 'support', 'sales', 'billing', 'office',
        'contact', 'marketing', 'careers', 'hr', 'humanresources', 'jobs', 'press',
        'media', 'finance', 'accounting', 'security', 'team', 'inquiries', 'enquiries',
        'service', 'services', 'help', 'helpdesk', 'webmaster', 'hostmaster', 'postmaster',
        'compliance', 'legal', 'privacy', 'abuse', 'operations', 'frontdesk', 'reception',
        'booking', 'bookings', 'orders', 'order', 'customercare', 'customer',
        'hello', 'contactus', 'broker', 'brokerage', 'leasing', 'rentals', 'listings', 'management', 'general'
    ];

    /**
     * Popular domains mapping for typo auto-detection.
     */
    private static array $popularDomains = [
        'gmail.com' => ['gmial.com', 'gmaill.com', 'gamil.com', 'gmai.com', 'gmai.co', 'gmaik.com', 'gmaol.com', 'gmail.co'],
        'yahoo.com' => ['yaho.com', 'yahooo.com', 'yaho.co', 'ymail.com', 'yhaoo.com', 'tahoo.com'],
        'hotmail.com' => ['hotmial.com', 'hotmai.com', 'hotmaill.com', 'hotamail.com', 'hotmil.com'],
        'outlook.com' => ['outlok.com', 'outloo.com', 'outlookk.com', 'putlook.com'],
        'icloud.com' => ['icoud.com', 'iclod.com', 'iclou.com', 'icloud.co'],
        'aol.com' => ['aol.co', 'aoll.com', 'alo.com']
    ];

    // ─────────────────────────────────────────────────────────────────────────
    // 1. NORMALIZATION & PARSING
    // ─────────────────────────────────────────────────────────────────────────

    public static function normalizeEmail(string $input): string
    {
        return strtolower(trim($input));
    }

    public static function parseEmail(string $email): ?array
    {
        $normalized = self::normalizeEmail($email);
        $at = strrpos($normalized, '@');
        if ($at === false || $at === 0 || $at === strlen($normalized) - 1) {
            return null;
        }

        return [
            'local' => substr($normalized, 0, $at),
            'domain' => substr($normalized, $at + 1)
        ];
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 2. RFC 5322 SYNTAX VALIDATION
    // ─────────────────────────────────────────────────────────────────────────

    public static function validateSyntax(string $email): array
    {
        $normalized = self::normalizeEmail($email);

        if (empty($normalized)) {
            return ['valid' => false, 'reason' => 'EMPTY_INPUT'];
        }

        if (strlen($normalized) > 320) {
            return ['valid' => false, 'reason' => 'EMAIL_EXCEEDS_320_CHARS'];
        }

        if (str_contains($normalized, ' ')) {
            return ['valid' => false, 'reason' => 'CONTAINS_SPACES'];
        }

        if (str_contains($normalized, '..')) {
            return ['valid' => false, 'reason' => 'CONTAINS_CONSECUTIVE_DOTS'];
        }

        $parsed = self::parseEmail($normalized);
        if (!$parsed) {
            return ['valid' => false, 'reason' => 'INVALID_AT_STRUCTURE'];
        }

        $local = $parsed['local'];
        $domain = $parsed['domain'];

        if (strlen($local) > 64) {
            return ['valid' => false, 'reason' => 'LOCAL_PART_EXCEEDS_64_CHARS'];
        }

        if (str_starts_with($domain, '.') || str_ends_with($domain, '.')) {
            return ['valid' => false, 'reason' => 'DOMAIN_STARTS_OR_ENDS_WITH_DOT'];
        }

        if (!str_contains($domain, '.')) {
            return ['valid' => false, 'reason' => 'DOMAIN_MISSING_TLD_DOT'];
        }

        // Standard PHP RFC filter check
        if (!filter_var($normalized, FILTER_VALIDATE_EMAIL)) {
            return ['valid' => false, 'reason' => 'RFC_5322_NON_COMPLIANT'];
        }

        return ['valid' => true, 'reason' => null];
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 3. DNS & MX RECORD RESOLUTION
    // ─────────────────────────────────────────────────────────────────────────

    public static function checkDomainAndMx(string $domain): array
    {
        $domain = strtolower(trim($domain));

        if (empty($domain)) {
            return [
                'valid' => false,
                'mx_found' => false,
                'mx_records' => [],
                'is_null_mx' => false,
                'has_a_record' => false,
                'reason' => 'EMPTY_DOMAIN'
            ];
        }

        if (isset(self::$dnsMxCache[$domain])) {
            return self::$dnsMxCache[$domain];
        }

        // 1. Resolve MX records
        $mxRecords = [];
        $hasMx = false;
        $isNullMx = false;

        $rawMx = @dns_get_record($domain, DNS_MX);
        if (is_array($rawMx) && !empty($rawMx)) {
            // Sort by priority (lowest number = highest priority)
            usort($rawMx, fn($a, $b) => ($a['pri'] ?? 0) <=> ($b['pri'] ?? 0));
            
            foreach ($rawMx as $record) {
                $target = trim($record['target'] ?? '');
                if ($target === '.' || $target === '') {
                    $isNullMx = true;
                } elseif (!empty($target)) {
                    $mxRecords[] = [
                        'host' => strtolower($target),
                        'priority' => (int)($record['pri'] ?? 10)
                    ];
                }
            }
            if (!empty($mxRecords)) {
                $hasMx = true;
            }
        }

        // If Null MX explicitly specified (RFC 7505 - Null MX indicates domain does not accept mail)
        if ($isNullMx && empty($mxRecords)) {
            $res = [
                'valid' => false,
                'mx_found' => false,
                'mx_records' => [],
                'is_null_mx' => true,
                'has_a_record' => false,
                'reason' => 'NULL_MX_DOMAIN_REJECTS_MAIL'
            ];
            self::$dnsMxCache[$domain] = $res;
            return $res;
        }

        // 2. Fallback check for A/AAAA records if no MX records found
        $hasA = false;
        if (!$hasMx) {
            $rawA = @dns_get_record($domain, DNS_A);
            if (is_array($rawA) && !empty($rawA)) {
                $hasA = true;
                // In RFC 5321, if no MX exists, the domain's A record can act as implicit MX priority 0
                $mxRecords[] = [
                    'host' => $domain,
                    'priority' => 0,
                    'implicit' => true
                ];
            }
        }

        if (!$hasMx && !$hasA) {
            $res = [
                'valid' => false,
                'mx_found' => false,
                'mx_records' => [],
                'is_null_mx' => false,
                'has_a_record' => false,
                'reason' => 'NO_MX_OR_A_RECORDS_FOUND'
            ];
            self::$dnsMxCache[$domain] = $res;
            return $res;
        }

        $res = [
            'valid' => true,
            'mx_found' => $hasMx,
            'mx_records' => $mxRecords,
            'is_null_mx' => false,
            'has_a_record' => $hasA,
            'reason' => null
        ];
        self::$dnsMxCache[$domain] = $res;
        return $res;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 4. DISPOSABLE & ROLE-BASED & TYPO CHECKS
    // ─────────────────────────────────────────────────────────────────────────

    public static function isDisposable(string $domain): bool
    {
        $domain = strtolower(trim($domain));
        if (in_array($domain, self::$disposableDomains, true)) {
            return true;
        }

        // Subdomain check (e.g. sub.mailinator.com)
        foreach (self::$disposableDomains as $disposable) {
            if (str_ends_with($domain, '.' . $disposable)) {
                return true;
            }
        }

        return false;
    }

    public static function isRoleBased(string $localPart): bool
    {
        $local = strtolower(trim($localPart));
        // Remove non-alphanumeric separators (e.g. info-desk, sales.team)
        $clean = preg_replace('/[._+-]/', '', $local);

        if (in_array($local, self::$rolePrefixes, true) || in_array($clean, self::$rolePrefixes, true)) {
            return true;
        }

        // Prefix match check
        foreach (self::$rolePrefixes as $prefix) {
            if ($local === $prefix || str_starts_with($local, $prefix . '.') || str_starts_with($local, $prefix . '-')) {
                return true;
            }
        }

        return false;
    }

    public static function checkTypo(string $domain): ?array
    {
        $domain = strtolower(trim($domain));
        foreach (self::$popularDomains as $correct => $typos) {
            if (in_array($domain, $typos, true)) {
                return [
                    'detected' => true,
                    'suggested_domain' => $correct
                ];
            }
        }

        // Levenshtein distance check on popular domains
        foreach (array_keys(self::$popularDomains) as $popular) {
            if ($domain !== $popular && levenshtein($domain, $popular) === 1) {
                return [
                    'detected' => true,
                    'suggested_domain' => $popular
                ];
            }
        }

        return null;
    }

    public static function detectMailProvider(array $mxRecords): string
    {
        if (empty($mxRecords)) {
            return 'None';
        }

        $hosts = array_column($mxRecords, 'host');
        $haystack = strtolower(implode(' ', $hosts));

        if (str_contains($haystack, 'google.com') || str_contains($haystack, 'googlemail.com') || str_contains($haystack, 'aspmx.l.google.com')) {
            return 'Google Workspace / Gmail';
        }
        if (str_contains($haystack, 'outlook.com') || str_contains($haystack, 'protection.outlook.com') || str_contains($haystack, 'microsoft.com')) {
            return 'Microsoft 365 / Exchange';
        }
        if (str_contains($haystack, 'yahoodns.net') || str_contains($haystack, 'yahoo.com')) {
            return 'Yahoo! Mail';
        }
        if (str_contains($haystack, 'pphosted.com') || str_contains($haystack, 'proofpoint.com')) {
            return 'Proofpoint Enterprise';
        }
        if (str_contains($haystack, 'mimecast.com')) {
            return 'Mimecast Gateway';
        }
        if (str_contains($haystack, 'zoho.com') || str_contains($haystack, 'zoho.eu')) {
            return 'Zoho Mail';
        }
        if (str_contains($haystack, 'protonmail.ch') || str_contains($haystack, 'proton.me')) {
            return 'Proton Mail';
        }
        if (str_contains($haystack, 'icloud.com') || str_contains($haystack, 'apple.com')) {
            return 'Apple iCloud Mail';
        }
        if (str_contains($haystack, 'hostinger.com')) {
            return 'Hostinger Business Mail';
        }
        if (str_contains($haystack, 'secureserver.net')) {
            return 'GoDaddy Workspace';
        }

        return 'Custom Enterprise / Self-Hosted MX';
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 5. DIRECT LOW-LEVEL SMTP MAILBOX HANDSHAKE
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Connects to recipient MX server on port 25, runs SMTP handshake (EHLO, MAIL FROM, RCPT TO).
     * Graciously handles port 25 firewalls, greylisting (450/421), and mailbox rejection (550).
     */
    public static function verifySmtpMailbox(
        string $mxHost,
        string $email,
        string $fromEmail = 'verify@estatehdr.com',
        int $timeoutSeconds = 2
    ): array {
        $result = [
            'reachable' => false,
            'code' => null,
            'response' => '',
            'accepted' => null,
            'temporary_error' => false,
            'error_message' => null
        ];

        if (empty($mxHost)) {
            $result['error_message'] = 'No MX host provided';
            return $result;
        }

        $errno = 0;
        $errstr = '';
        
        // Open low-level stream socket with strict timeout
        $socket = @stream_socket_client(
            "tcp://{$mxHost}:25",
            $errno,
            $errstr,
            $timeoutSeconds,
            STREAM_CLIENT_CONNECT
        );

        if (!$socket) {
            $result['reachable'] = false;
            $result['error_message'] = "Cannot connect to {$mxHost}:25 ({$errstr}) - Port 25 may be filtered by host/ISP";
            return $result;
        }

        stream_set_timeout($socket, $timeoutSeconds);

        // Read initial SMTP greeting
        $greeting = self::readSmtpResponse($socket);
        $greetingCode = self::extractSmtpCode($greeting);

        if ($greetingCode !== 220) {
            fclose($socket);
            $result['reachable'] = true;
            $result['code'] = $greetingCode;
            $result['response'] = trim($greeting);
            $result['error_message'] = 'Server rejected initial connection banner';
            return $result;
        }

        $result['reachable'] = true;

        // 1. Send EHLO
        self::writeSmtpCommand($socket, "EHLO verifier.estatehdr.com\r\n");
        $ehloResp = self::readSmtpResponse($socket);
        $ehloCode = self::extractSmtpCode($ehloResp);

        if ($ehloCode !== 250) {
            // Fallback to HELO
            self::writeSmtpCommand($socket, "HELO verifier.estatehdr.com\r\n");
            $heloResp = self::readSmtpResponse($socket);
            $ehloCode = self::extractSmtpCode($heloResp);
        }

        // 2. Send MAIL FROM
        self::writeSmtpCommand($socket, "MAIL FROM:<{$fromEmail}>\r\n");
        $mailFromResp = self::readSmtpResponse($socket);
        $mailFromCode = self::extractSmtpCode($mailFromResp);

        if ($mailFromCode !== 250) {
            self::writeSmtpCommand($socket, "QUIT\r\n");
            fclose($socket);
            $result['code'] = $mailFromCode;
            $result['response'] = trim($mailFromResp);
            $result['error_message'] = 'Server rejected MAIL FROM command';
            return $result;
        }

        // 3. Send RCPT TO
        self::writeSmtpCommand($socket, "RCPT TO:<{$email}>\r\n");
        $rcptResp = self::readSmtpResponse($socket);
        $rcptCode = self::extractSmtpCode($rcptResp);

        $result['code'] = $rcptCode;
        $result['response'] = trim($rcptResp);

        if ($rcptCode === 250) {
            // Mailbox explicitly accepted
            $result['accepted'] = true;
        } elseif ($rcptCode >= 500 && $rcptCode < 600) {
            // Permanent rejection: Mailbox does not exist (550 5.1.1 User unknown)
            $result['accepted'] = false;
        } elseif ($rcptCode >= 400 && $rcptCode < 500) {
            // Temporary error: Greylisting, mailbox full, or rate limiting
            $result['accepted'] = null;
            $result['temporary_error'] = true;
        } else {
            $result['accepted'] = null;
        }

        // 4. Send QUIT gracefully
        self::writeSmtpCommand($socket, "QUIT\r\n");
        fclose($socket);

        return $result;
    }

    /**
     * Tests an impossible random mailbox on the same MX host to verify if domain is catch-all.
     */
    public static function detectCatchAll(string $mxHost, string $domain, string $fromEmail = 'verify@estatehdr.com', int $timeoutSeconds = 4): bool
    {
        $randomMailbox = 'eh-probe-' . bin2hex(random_bytes(6)) . '@' . $domain;
        $probe = self::verifySmtpMailbox($mxHost, $randomMailbox, $fromEmail, $timeoutSeconds);

        // If the server accepts an impossible randomized probe address, it is a Catch-All server
        return $probe['accepted'] === true;
    }

    private static function writeSmtpCommand($socket, string $cmd): void
    {
        @fwrite($socket, $cmd);
    }

    private static function readSmtpResponse($socket): string
    {
        $buffer = '';
        while (!feof($socket)) {
            $line = @fgets($socket, 1024);
            if ($line === false) break;
            $buffer .= $line;
            // Check for RFC termination: three digits followed by a space
            if (preg_match('/^\d{3}\s/m', $line)) {
                break;
            }
        }
        return $buffer;
    }

    private static function extractSmtpCode(string $response): ?int
    {
        if (preg_match('/^(\d{3})/m', trim($response), $matches)) {
            return (int)$matches[1];
        }
        return null;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 6. MASTER VERIFICATION PIPELINE
    // ─────────────────────────────────────────────────────────────────────────

    public static function verifyEmail(string $inputEmail, bool $deepSmtp = true): array
    {
        $normalized = self::normalizeEmail($inputEmail);
        $checkedAt = date('Y-m-d H:i:s');

        // Stage 1: Syntax Validation
        $syntax = self::validateSyntax($normalized);
        if (!$syntax['valid']) {
            return [
                'email' => $inputEmail,
                'normalized' => $normalized,
                'status' => 'INVALID',
                'score' => 0,
                'syntax' => ['valid' => false, 'reason' => $syntax['reason']],
                'domain' => ['valid' => false, 'mx_found' => false, 'mx_records' => [], 'is_null_mx' => false],
                'smtp' => ['reachable' => false, 'code' => null, 'response' => null],
                'mailbox' => ['accepted' => false],
                'risk' => [
                    'disposable' => false,
                    'role_based' => false,
                    'catch_all' => false,
                    'spam_trap' => false,
                    'toxic' => false
                ],
                'typo' => ['detected' => false, 'suggestion' => null],
                'provider' => 'Unknown',
                'checked_at' => $checkedAt,
                'verdict_summary' => 'RFC 5322 syntax check failed (' . $syntax['reason'] . ')'
            ];
        }

        // Stage 2: Parse Email
        $parsed = self::parseEmail($normalized);
        $local = $parsed['local'];
        $domain = $parsed['domain'];

        // Stage 3: Domain & DNS MX Check
        $domainCheck = self::checkDomainAndMx($domain);
        $provider = self::detectMailProvider($domainCheck['mx_records']);

        if (!$domainCheck['valid']) {
            return [
                'email' => $inputEmail,
                'normalized' => $normalized,
                'status' => 'INVALID',
                'score' => 10,
                'syntax' => ['valid' => true, 'reason' => null],
                'domain' => [
                    'valid' => false,
                    'mx_found' => false,
                    'mx_records' => [],
                    'is_null_mx' => $domainCheck['is_null_mx']
                ],
                'smtp' => ['reachable' => false, 'code' => null, 'response' => null],
                'mailbox' => ['accepted' => false],
                'risk' => [
                    'disposable' => false,
                    'role_based' => false,
                    'catch_all' => false,
                    'spam_trap' => false,
                    'toxic' => false
                ],
                'typo' => ['detected' => false, 'suggestion' => null],
                'provider' => $provider,
                'checked_at' => $checkedAt,
                'verdict_summary' => 'Domain does not have valid mail exchangers (MX records)'
            ];
        }

        // Stage 4: Disposable Email Check
        $isDisposable = self::isDisposable($domain);

        // Stage 5: Role-based Account Check
        $isRole = self::isRoleBased($local);

        // Stage 6: Typo Check
        $typo = self::checkTypo($domain);
        $typoDetected = !empty($typo['detected']);
        $typoSuggestion = $typoDetected ? ($local . '@' . $typo['suggested_domain']) : null;

        // Stage 7: Direct SMTP Mailbox Verification
        $smtpResult = [
            'reachable' => false,
            'code' => null,
            'response' => null,
            'accepted' => null
        ];
        $isCatchAll = false;

        $primaryMx = $domainCheck['mx_records'][0]['host'] ?? '';

        if ($deepSmtp && !empty($primaryMx) && !$isDisposable) {
            $smtpCheck = self::verifySmtpMailbox($primaryMx, $normalized);
            $smtpResult['reachable'] = $smtpCheck['reachable'];
            $smtpResult['code'] = $smtpCheck['code'];
            $smtpResult['response'] = $smtpCheck['response'];
            $smtpResult['accepted'] = $smtpCheck['accepted'];

            // Stage 8: Catch-All Probe Check (only if primary accepted)
            if ($smtpCheck['accepted'] === true) {
                $isCatchAll = self::detectCatchAll($primaryMx, $domain);
            }
        }

        // Stage 9: Deliverability Quality Scoring & Verdict
        $score = 80; // Baseline for valid syntax + working MX

        // Deductions & additions
        if ($isDisposable) {
            $score = 15;
        } elseif ($typoDetected) {
            $score -= 35;
        }

        if ($isRole) {
            $score -= 15;
        }

        if ($smtpResult['accepted'] === true) {
            $score += 15;
        } elseif ($smtpResult['accepted'] === false) {
            $score = 5; // Definite bounce
        }

        if ($isCatchAll) {
            $score -= 10;
        }

        $score = max(5, min(100, $score));

        // Determine Final Status
        if ($isDisposable || $smtpResult['accepted'] === false) {
            $status = 'INVALID';
            $summary = $isDisposable ? 'Disposable temporary inbox detected' : 'Recipient mailbox rejected by mail server (User Unknown)';
        } elseif ($isCatchAll) {
            $status = 'CATCH_ALL';
            $summary = 'Domain accepts all emails (Catch-All server)';
        } elseif ($isRole) {
            $status = 'RISKY';
            $summary = 'Role-based generic department email (e.g. info/admin/support)';
        } elseif ($typoDetected) {
            $status = 'RISKY';
            $summary = "Probable domain typo. Did you mean {$typoSuggestion}?";
        } elseif ($smtpResult['accepted'] === true) {
            $status = 'VALID';
            $summary = 'Mailbox verified and actively accepting emails';
        } elseif ($smtpResult['accepted'] === null && $domainCheck['mx_found']) {
            $status = 'VALID'; // DNS & MX are healthy; mail server responsive or greylisted
            $summary = 'Domain & MX verified active with ' . $provider . ($smtpResult['reachable'] ? ' (Responsive MX)' : '');
        } else {
            $status = 'RISKY';
            $summary = 'Mail server response ambiguous or temporarily rate-limited';
        }

        $quality = $score >= 85 ? 'excellent' : ($score >= 70 ? 'good' : ($score >= 50 ? 'risky' : 'poor'));

        return [
            'email' => $inputEmail,
            'normalized' => $normalized,
            'status' => $status,
            'verdict' => strtolower($status),
            'score' => $score,
            'quality' => $quality,
            'syntax' => ['valid' => true, 'reason' => null],
            'domain' => [
                'valid' => true,
                'mx_found' => $domainCheck['mx_found'],
                'mx_records' => array_column($domainCheck['mx_records'], 'host'),
                'is_null_mx' => false
            ],
            'smtp' => [
                'reachable' => $smtpResult['reachable'],
                'code' => $smtpResult['code'],
                'response' => $smtpResult['response']
            ],
            'mailbox' => [
                'accepted' => $smtpResult['accepted']
            ],
            'risk' => [
                'disposable' => $isDisposable,
                'role_based' => $isRole,
                'catch_all' => $isCatchAll,
                'spam_trap' => false,
                'toxic' => false
            ],
            'typo' => [
                'detected' => $typoDetected,
                'suggestion' => $typoSuggestion
            ],
            'provider' => $provider,
            'checked_at' => $checkedAt,
            'verdict_summary' => $summary
        ];
    }

    // ─────────────────────────────────────────────────────────────────────────
    // 7. BATCH VERIFICATION FOR CRM CONTACTS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Batch verifies a slice of contacts in data/email_crm/contacts.json
     * Updates verification_status, verification_score, and verified_at on each contact.
     */
    public static function bulkVerifyContacts(
        int $limit = 50,
        bool $onlyUnverified = true,
        ?array $specificIds = null,
        bool $deepSmtp = false
    ): array
    {
        $specificIds = $specificIds ?? [];
        $contactsFile = self::$storageDir . '/contacts.json';
        if (!file_exists($contactsFile)) {
            return ['processed' => 0, 'updated' => 0, 'remaining' => 0];
        }

        $contacts = json_decode((string)file_get_contents($contactsFile), true) ?: [];
        $total = count($contacts);
        $processed = 0;
        $updated = 0;

        $results = [];

        foreach ($contacts as &$contact) {
            if ($processed >= $limit) {
                break;
            }

            if (!empty($specificIds) && !in_array($contact['id'] ?? '', $specificIds, true)) {
                continue;
            }

            if ($onlyUnverified && !empty($contact['verification_status']) && $contact['verification_status'] !== 'unverified') {
                continue;
            }

            $email = $contact['email'] ?? '';
            if (empty($email)) {
                continue;
            }

            // Verify email (Turbo mode: syntax + DNS/MX cache + disposable + role + typo; Deep mode: adds socket handshake)
            $res = self::verifyEmail($email, $deepSmtp);

            $contact['verification_status'] = strtolower($res['status']);
            $contact['verification_score'] = $res['score'];
            $contact['verified_at'] = $res['checked_at'];
            $contact['verification_details'] = [
                'provider' => $res['provider'],
                'disposable' => $res['risk']['disposable'],
                'role_based' => $res['risk']['role_based'],
                'catch_all' => $res['risk']['catch_all'],
                'summary' => $res['verdict_summary']
            ];

            $results[] = [
                'id' => $contact['id'],
                'email' => $email,
                'status' => $res['status'],
                'score' => $res['score'],
                'summary' => $res['verdict_summary']
            ];

            $processed++;
            $updated++;
        }

        if ($updated > 0) {
            @file_put_contents($contactsFile, json_encode($contacts, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        }

        // Count remaining unverified
        $unverifiedCount = 0;
        foreach ($contacts as $c) {
            if (empty($c['verification_status']) || $c['verification_status'] === 'unverified') {
                $unverifiedCount++;
            }
        }

        return [
            'total_contacts' => $total,
            'processed' => $processed,
            'remaining_unverified' => $unverifiedCount,
            'batch_results' => $results
        ];
    }

    /**
     * Returns stats breakdown across contacts for the CRM dashboard.
     */
    public static function getVerificationStats(): array
    {
        $contactsFile = self::$storageDir . '/contacts.json';
        if (!file_exists($contactsFile)) {
            return [
                'total' => 0, 'valid' => 0, 'risky' => 0,
                'invalid' => 0, 'catch_all' => 0, 'unverified' => 0,
                'avg_score' => 0
            ];
        }

        $contacts = json_decode((string)file_get_contents($contactsFile), true) ?: [];
        $total = count($contacts);
        $valid = 0;
        $risky = 0;
        $invalid = 0;
        $catchAll = 0;
        $unverified = 0;
        $totalScore = 0;
        $scoredCount = 0;

        foreach ($contacts as $c) {
            $st = strtolower($c['verification_status'] ?? 'unverified');
            $email = strtolower(trim($c['email'] ?? ''));
            $parsed = self::parseEmail($email);
            $isRole = $parsed && self::isRoleBased($parsed['local']);
            $isDisp = $parsed && self::isDisposable($parsed['domain']);
            $typo = $parsed ? self::checkTypo($parsed['domain']) : ['detected' => false];
            $hasTypo = !empty($typo['detected']);
            $detailRole = !empty($c['verification_details']['role_based']);
            $detailCatch = !empty($c['verification_details']['catch_all']);
            $statusAttr = strtolower($c['status'] ?? '');

            if ($st === 'invalid' || $st === 'bounced' || $statusAttr === 'bounced') {
                $invalid++;
            } elseif ($st === 'catch_all' || $detailCatch) {
                $catchAll++;
            } elseif ($st === 'risky' || $st === 'role_based' || $st === 'unknown' || $isRole || $isDisp || $hasTypo || $detailRole) {
                $risky++;
            } elseif ($st === 'valid') {
                $valid++;
            } else {
                $unverified++;
            }

            if (isset($c['verification_score']) && is_numeric($c['verification_score'])) {
                $totalScore += (int)$c['verification_score'];
                $scoredCount++;
            }
        }

        $healthPercent = $total > 0 ? round((($valid + ($risky * 0.5)) / $total) * 100, 1) : 100.0;

        return [
            'total' => $total,
            'valid' => $valid,
            'risky' => $risky,
            'invalid' => $invalid,
            'catch_all' => $catchAll,
            'unverified' => $unverified,
            'avg_score' => $scoredCount > 0 ? round($totalScore / $scoredCount, 1) : 0,
            'health_percent' => $healthPercent
        ];
    }

    /**
     * Purges contacts from the database based on verification criteria:
     * - 'invalid': verification_status === 'invalid' or bounced
     * - 'risky': verification_status === 'risky', 'catch_all', 'unknown', or role-based account
     * - 'unhealthy': all invalid + all risky
     * - 'selected': specific contact IDs in $specificIds
     *
     * @param string $target 'invalid'|'risky'|'unhealthy'|'selected'
     * @param array $specificIds Optional list of contact IDs to delete
     * @return array Removal report with counts and updated stats
     */
    public static function purgeContacts(string $target = 'invalid', array $specificIds = []): array
    {
        $contactsFile = self::$storageDir . '/contacts.json';
        if (!file_exists($contactsFile)) {
            return [
                'success' => false,
                'target' => $target,
                'removed_count' => 0,
                'remaining_count' => 0,
                'stats' => self::getVerificationStats()
            ];
        }

        $contacts = json_decode((string)file_get_contents($contactsFile), true) ?: [];
        $originalTotal = count($contacts);
        $specificIdsMap = !empty($specificIds) ? array_flip($specificIds) : [];

        $kept = [];
        $removed = 0;
        $removedEmails = [];

        foreach ($contacts as $c) {
            $st = strtolower($c['verification_status'] ?? 'unverified');
            $id = $c['id'] ?? '';
            $email = strtolower(trim($c['email'] ?? ''));
            $parsed = self::parseEmail($email);
            $isRole = $parsed && self::isRoleBased($parsed['local']);
            $isDisp = $parsed && self::isDisposable($parsed['domain']);
            $typo = $parsed ? self::checkTypo($parsed['domain']) : ['detected' => false];
            $hasTypo = !empty($typo['detected']);
            $detailRole = !empty($c['verification_details']['role_based']);
            $detailCatch = !empty($c['verification_details']['catch_all']);
            $statusAttr = strtolower($c['status'] ?? '');

            $shouldRemove = false;

            if (!empty($specificIdsMap)) {
                if (isset($specificIdsMap[$id])) {
                    $shouldRemove = true;
                }
            } elseif ($target === 'invalid') {
                if ($st === 'invalid' || $st === 'bounced' || $statusAttr === 'bounced') {
                    $shouldRemove = true;
                }
            } elseif ($target === 'risky') {
                if (
                    $st === 'risky' ||
                    $st === 'catch_all' ||
                    $st === 'unknown' ||
                    $st === 'role_based' ||
                    $isRole ||
                    $isDisp ||
                    $hasTypo ||
                    $detailRole ||
                    $detailCatch
                ) {
                    $shouldRemove = true;
                }
            } elseif ($target === 'unhealthy') {
                if (
                    $st === 'invalid' ||
                    $st === 'bounced' ||
                    $statusAttr === 'bounced' ||
                    $st === 'risky' ||
                    $st === 'catch_all' ||
                    $st === 'unknown' ||
                    $st === 'role_based' ||
                    $isRole ||
                    $isDisp ||
                    $hasTypo ||
                    $detailRole ||
                    $detailCatch
                ) {
                    $shouldRemove = true;
                }
            }

            if ($shouldRemove) {
                $removed++;
                $removedEmails[] = $c['email'] ?? '';
            } else {
                $kept[] = $c;
            }
        }

        if ($removed > 0) {
            @file_put_contents($contactsFile, json_encode(array_values($kept), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        }

        return [
            'success' => true,
            'target' => $target,
            'removed_count' => $removed,
            'remaining_count' => count($kept),
            'original_count' => $originalTotal,
            'removed_sample' => array_slice($removedEmails, 0, 10),
            'stats' => self::getVerificationStats()
        ];
    }
}

