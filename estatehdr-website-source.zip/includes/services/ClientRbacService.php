<?php
/**
 * Estate HDR - Client-Side Permission-Based RBAC Service
 * Enterprise Layer: Client RBAC Architecture
 * 
 * Supports Client Owner, Client Admin, Billing Manager, Ordering Manager, Reviewer, Viewer.
 * Uses fine-grained permissions instead of hard-coded checks.
 */

class ClientRbacService {
    // Client-side Roles
    public const ROLE_CLIENT_OWNER     = 'client_owner';
    public const ROLE_CLIENT_ADMIN     = 'client_admin';
    public const ROLE_BILLING_MANAGER  = 'billing_manager';
    public const ROLE_ORDERING_MANAGER = 'ordering_manager';
    public const ROLE_REVIEWER         = 'reviewer';
    public const ROLE_VIEWER           = 'viewer';

    // Permissions
    public const PERM_VIEW_DASHBOARD       = 'dashboard.view';
    public const PERM_VIEW_ORDERS          = 'orders.view';
    public const PERM_CREATE_ORDERS        = 'orders.create';
    public const PERM_EDIT_ORDERS          = 'orders.edit';
    public const PERM_CANCEL_ORDERS        = 'orders.cancel';
    public const PERM_VIEW_ASSETS          = 'assets.view';
    public const PERM_DOWNLOAD_DELIVERIES  = 'assets.download';
    public const PERM_REVIEW_DELIVERIES    = 'review.action'; // approve / request amendments
    public const PERM_VIEW_BILLING         = 'billing.view';
    public const PERM_PAY_INVOICES         = 'billing.pay';
    public const PERM_MANAGE_USERS         = 'users.manage';
    public const PERM_MANAGE_PREFERENCES   = 'preferences.manage';
    public const PERM_MANAGE_PROPERTIES    = 'properties.manage';
    public const PERM_API_ACCESS           = 'api.access';

    /**
     * Map of roles to assigned permissions
     */
    private static array $rolePermissions = [
        self::ROLE_CLIENT_OWNER => [
            self::PERM_VIEW_DASHBOARD,
            self::PERM_VIEW_ORDERS,
            self::PERM_CREATE_ORDERS,
            self::PERM_EDIT_ORDERS,
            self::PERM_CANCEL_ORDERS,
            self::PERM_VIEW_ASSETS,
            self::PERM_DOWNLOAD_DELIVERIES,
            self::PERM_REVIEW_DELIVERIES,
            self::PERM_VIEW_BILLING,
            self::PERM_PAY_INVOICES,
            self::PERM_MANAGE_USERS,
            self::PERM_MANAGE_PREFERENCES,
            self::PERM_MANAGE_PROPERTIES,
            self::PERM_API_ACCESS
        ],
        self::ROLE_CLIENT_ADMIN => [
            self::PERM_VIEW_DASHBOARD,
            self::PERM_VIEW_ORDERS,
            self::PERM_CREATE_ORDERS,
            self::PERM_EDIT_ORDERS,
            self::PERM_VIEW_ASSETS,
            self::PERM_DOWNLOAD_DELIVERIES,
            self::PERM_REVIEW_DELIVERIES,
            self::PERM_MANAGE_USERS,
            self::PERM_MANAGE_PREFERENCES,
            self::PERM_MANAGE_PROPERTIES
        ],
        self::ROLE_BILLING_MANAGER => [
            self::PERM_VIEW_DASHBOARD,
            self::PERM_VIEW_BILLING,
            self::PERM_PAY_INVOICES,
            self::PERM_VIEW_ORDERS
            // Notably excluded: PERM_VIEW_ASSETS, PERM_DOWNLOAD_DELIVERIES
        ],
        self::ROLE_ORDERING_MANAGER => [
            self::PERM_VIEW_DASHBOARD,
            self::PERM_VIEW_ORDERS,
            self::PERM_CREATE_ORDERS,
            self::PERM_EDIT_ORDERS,
            self::PERM_VIEW_ASSETS,
            self::PERM_DOWNLOAD_DELIVERIES,
            self::PERM_MANAGE_PROPERTIES
            // Notably excluded: PERM_VIEW_BILLING, PERM_PAY_INVOICES
        ],
        self::ROLE_REVIEWER => [
            self::PERM_VIEW_DASHBOARD,
            self::PERM_VIEW_ORDERS,
            self::PERM_VIEW_ASSETS,
            self::PERM_DOWNLOAD_DELIVERIES,
            self::PERM_REVIEW_DELIVERIES
            // Excluded: PERM_VIEW_BILLING, PERM_CREATE_ORDERS
        ],
        self::ROLE_VIEWER => [
            self::PERM_VIEW_DASHBOARD,
            self::PERM_VIEW_ORDERS,
            self::PERM_VIEW_ASSETS
        ]
    ];

    /**
     * Resolve effective client role. Legacy users default to ROLE_CLIENT_OWNER.
     */
    public static function getClientRole(?array $user): string {
        if (!$user) return self::ROLE_VIEWER;
        if (!empty($user['client_role'])) {
            return $user['client_role'];
        }
        // Legacy single-user clients behave as Owner
        return self::ROLE_CLIENT_OWNER;
    }

    /**
     * Check if client user has permission
     */
    public static function userCan(string $permission, ?array $user): bool {
        if (!$user) return false;

        // Custom individual overrides
        if (!empty($user['custom_permissions']) && is_array($user['custom_permissions'])) {
            if (in_array($permission, $user['custom_permissions'], true)) {
                return true;
            }
        }

        $role = self::getClientRole($user);
        $allowed = self::$rolePermissions[$role] ?? [];
        return in_array($permission, $allowed, true);
    }

    /**
     * Guard a client action or terminate with friendly error / redirect
     */
    public static function enforce(string $permission, ?array $user, string $redirectUrl = '/client/app.php'): void {
        if (!self::userCan($permission, $user)) {
            if (headers_sent()) {
                echo "<div style='background:#1F2937;color:#F87171;padding:20px;font-family:sans-serif;'>
                        <h3>Access Restricted</h3>
                        <p>Your client account role does not have authorization for this operation ({$permission}).</p>
                        <a href='{$redirectUrl}' style='color:#C9A84C;'>Return to Portal</a>
                      </div>";
                exit;
            }
            $_SESSION['flash_error'] = "Access restricted: you do not have permission for this section.";
            header("Location: {$redirectUrl}");
            exit;
        }
    }
}
