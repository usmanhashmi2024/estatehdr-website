<?php
/**
 * Estate HDR - Dynamic Pricing Engine & Immutable Pricing Snapshots
 * Enterprise Layer: Dynamic Pricing & Enterprise Contracts
 * 
 * Rules: Client + Country + Service + Volume + Subscription + Contract + Priority + Tax
 * Generates versioned price snapshots so historical records remain immutable.
 */

class PricingEngineService {
    public const PRICING_VERSION = 'v2026.1';

    // Base rates per photo
    private static array $baseRates = [
        'hdr_standard' => 1.50,
        'hdr_luxury'   => 2.50,
        'flambient'    => 3.25,
        'twilight'     => 4.50,
        'virtual_staging' => 15.00,
        'floor_plan'   => 12.00,
        'video_edit'   => 35.00
    ];

    /**
     * Compute dynamic per-photo or order price
     */
    public static function calculateOrderPrice(array $params): array {
        $service = $params['service'] ?? 'hdr_standard';
        $quantity = max(1, (int)($params['quantity'] ?? 10));
        $country = strtoupper($params['country'] ?? 'US');
        $priority = $params['priority'] ?? 'normal'; // normal, rush_12h, urgent_6h
        $tier = $params['subscription_tier'] ?? 'standard'; // starter, pro, business, enterprise

        $baseRate = self::$baseRates[$service] ?? 1.50;

        // Volume Discount
        $volumeDiscountPct = 0;
        if ($quantity >= 50) $volumeDiscountPct = 20;
        elseif ($quantity >= 30) $volumeDiscountPct = 15;
        elseif ($quantity >= 20) $volumeDiscountPct = 10;

        // Subscription Tier Discount
        $tierDiscountPct = match ($tier) {
            'enterprise' => 25,
            'business'   => 15,
            'pro'        => 10,
            default      => 0
        };

        // Priority Multiplier
        $priorityMultiplier = match ($priority) {
            'urgent_6h' => 1.50,
            'rush_12h'  => 1.25,
            default     => 1.00
        };

        $netRate = $baseRate * (1 - ($volumeDiscountPct / 100)) * (1 - ($tierDiscountPct / 100)) * $priorityMultiplier;
        $netRate = round($netRate, 2);

        $subtotal = round($netRate * $quantity, 2);

        // Tax calculation (e.g. US sales tax or UK VAT)
        $taxPct = ($country === 'GB') ? 20 : (($country === 'AU') ? 10 : 0);
        $taxAmount = round($subtotal * ($taxPct / 100), 2);
        $totalAmount = round($subtotal + $taxAmount, 2);

        return [
            'pricing_version' => self::PRICING_VERSION,
            'service' => $service,
            'quantity' => $quantity,
            'base_unit_rate' => $baseRate,
            'effective_unit_rate' => $netRate,
            'subtotal' => $subtotal,
            'tax_pct' => $taxPct,
            'tax_amount' => $taxAmount,
            'total' => $totalAmount,
            'currency' => ($country === 'GB') ? 'GBP' : (($country === 'AU') ? 'AUD' : (($country === 'EU') ? 'EUR' : 'USD')),
            'calculated_at' => date('Y-m-d H:i:s')
        ];
    }
}
