<?php
/**
 * Estate HDR - Dropbox-Grade Enterprise Asset Management Service
 * Enterprise Layer: Asset Management, Storage, Versioning & Hashing
 * 
 * Supports version trees (v1, v2, v3, final), SHA-256 hashes, metadata, and client access rules.
 */

class AssetService {
    private static string $assetsFile = __DIR__ . '/../../data/assets.json';

    public static function getAssets(): array {
        if (!file_exists(self::$assetsFile)) {
            @file_put_contents(self::$assetsFile, json_encode([], JSON_PRETTY_PRINT));
            return [];
        }
        $data = json_decode(@file_get_contents(self::$assetsFile), true);
        return is_array($data) ? $data : [];
    }

    /**
     * Get all assets belonging to a specific order
     */
    public static function getOrderAssets(string $orderId): array {
        $assets = self::getAssets();
        return array_values(array_filter($assets, fn($a) => ($a['order_id'] ?? '') === $orderId));
    }

    /**
     * Register or upload a new versioned asset
     */
    public static function registerAsset(array $params): array {
        $assets = self::getAssets();

        $assetId = $params['id'] ?? ('AST-' . strtoupper(substr(md5(uniqid('', true)), 0, 10)));
        $orderId = $params['order_id'] ?? 'UNKNOWN';
        $version = $params['version'] ?? 'v1'; // v1, v2, v3, final
        $originalFilename = $params['original_filename'] ?? basename($params['file_path'] ?? 'image.jpg');
        $storageKey = $params['storage_key'] ?? ($params['file_path'] ?? '');
        $fileSize = $params['file_size'] ?? 0;
        $hash = $params['hash'] ?? '';
        $dimensions = $params['dimensions'] ?? ['width' => 0, 'height' => 0];
        $mime = $params['mime'] ?? 'image/jpeg';
        $uploadedBy = $params['uploaded_by'] ?? 'system';
        $orgId = $params['organization_id'] ?? 'org-estatehdr-default';
        $propId = $params['property_id'] ?? '';
        $type = $params['type'] ?? 'delivery'; // 'raw', 'delivery', 'amendment', 'preview'

        // Auto-calculate hash & dimensions if physical file exists
        if (!empty($params['physical_path']) && file_exists($params['physical_path'])) {
            $fileSize = filesize($params['physical_path']);
            $hash = hash_file('sha256', $params['physical_path']);
            $imgSize = @getimagesize($params['physical_path']);
            if ($imgSize) {
                $dimensions = ['width' => $imgSize[0], 'height' => $imgSize[1]];
                $mime = $imgSize['mime'] ?? $mime;
            }
        }

        $record = [
            'id' => $assetId,
            'organization_id' => $orgId,
            'property_id' => $propId,
            'order_id' => $orderId,
            'version' => $version,
            'original_filename' => $originalFilename,
            'storage_key' => $storageKey,
            'file_size' => $fileSize,
            'hash' => $hash,
            'dimensions' => $dimensions,
            'mime' => $mime,
            'type' => $type,
            'is_final' => ($version === 'final' || !empty($params['is_final'])),
            'uploaded_by' => $uploadedBy,
            'created_at' => date('Y-m-d H:i:s'),
            'versions_history' => $params['versions_history'] ?? [$version]
        ];

        $assets[$assetId] = $record;
        @file_put_contents(self::$assetsFile, json_encode($assets, JSON_PRETTY_PRINT));
        return $record;
    }

    /**
     * Get version timeline for an asset group
     */
    public static function getAssetVersions(string $orderId, string $filename): array {
        $assets = self::getOrderAssets($orderId);
        $matches = array_filter($assets, fn($a) => $a['original_filename'] === $filename);
        usort($matches, fn($a, $b) => strcmp($a['version'], $b['version']));
        return array_values($matches);
    }
}
