<?php
declare(strict_types=1);

namespace EstateHDR\Services;

/**
 * Estate HDR - High-Converting Email Template Library
 * Features:
 * - 8 Luxury, responsive, client-tested email templates
 * - Special limited-time offer: Regular $0.80 -> Promotional $0.60 / photo
 * - Tiered volume discounts: 1-24 @ $0.60, 25-49 @ $0.55, 50-99 @ $0.50, 100+ @ $0.45
 * - Exclusive complimentary bonus: 1 FREE Day-to-Dusk (Virtual Twilight) Hero Photo on EVERY single property order!
 * - 7-Day sequence templates (Day 1 through Day 7) + High-Volume Agency Special
 */
class EmailTemplateLibrary
{
    /**
     * Get all available email templates with metadata and HTML
     *
     * @return array<string, array>
     */
    public static function getAllTemplates(): array
    {
        return [
            'tmpl_day1_offer' => [
                'id' => 'tmpl_day1_offer',
                'name' => 'Day 1: Cold Intro — $0.60 HDR + Free Day-to-Dusk Hero',
                'day' => 'Day 1',
                'category' => '7-Day Sequence',
                'badge' => 'Exclusive Offer',
                'badge_color' => 'gold',
                'subject' => 'Exclusive: $0.60 HDR Photo Editing (Was $0.80) + 1 FREE Day-to-Dusk on Every Listing 🌟',
                'preview_text' => 'Limited time launch offer for real estate media pros: 25% off HDR + free virtual twilight.',
                'description' => 'Direct cold outreach introducing the slashed $0.60 price, tiered volume discounts, and 1 free day-to-dusk per property.',
                'html' => self::buildTemplateDay1()
            ],
            'tmpl_day2_proof' => [
                'id' => 'tmpl_day2_proof',
                'name' => 'Day 2: Visual Proof — Before vs After & Hand Blending',
                'day' => 'Day 2',
                'category' => '7-Day Sequence',
                'badge' => 'Visual Proof',
                'badge_color' => 'blue',
                'subject' => 'Before vs After: See why US/UK photo studios switched to Estate HDR ($0.60/photo + Free Twilight)',
                'preview_text' => 'Crystal-clear window pulls, true wall colors, zero radioactive grass. See our sample gallery.',
                'description' => 'Highlights manual flambient blending quality, window pulls, sky replacement, and pricing comparison.',
                'html' => self::buildTemplateDay2()
            ],
            'tmpl_day3_calculator' => [
                'id' => 'tmpl_day3_calculator',
                'name' => 'Day 3: Cost Calculator — Cut Editing Bills by 40%',
                'day' => 'Day 3',
                'category' => '7-Day Sequence',
                'badge' => 'ROI / Savings',
                'badge_color' => 'emerald',
                'subject' => 'Cut your editing bill by 40% with our $0.60 limited rate (+ Free Day-to-Dusk)',
                'preview_text' => 'A typical 30-photo shoot costs just $16.50 total and includes a $15 free twilight hero!',
                'description' => 'Real-world math showing how much photographers save on every shoot with our volume discounts.',
                'html' => self::buildTemplateDay3()
            ],
            'tmpl_day4_speed' => [
                'id' => 'tmpl_day4_speed',
                'name' => 'Day 4: Workflow Speed — Shoot, Drop Dropbox Link, Done',
                'day' => 'Day 4',
                'category' => '7-Day Sequence',
                'badge' => 'Workflow Speed',
                'badge_color' => 'purple',
                'subject' => 'Shoot all day, send Dropbox link from your car, wake up to MLS-ready HDRs ⚡',
                'preview_text' => 'No complicated software or portals. Just send your Dropbox or Drive link before you head home.',
                'description' => 'Frictionless ordering explanation: Send Dropbox/Drive link, 24h turnaround, zero stress.',
                'html' => self::buildTemplateDay4()
            ],
            'tmpl_day5_twilight' => [
                'id' => 'tmpl_day5_twilight',
                'name' => 'Day 5: Twilight Secret — Sell Listings 3x Faster',
                'day' => 'Day 5',
                'category' => '7-Day Sequence',
                'badge' => 'Twilight Feature',
                'badge_color' => 'amber',
                'subject' => 'How our 1 FREE Day-to-Dusk on every property wins you more agent clients 🌅',
                'preview_text' => 'Listings with twilight covers get 3x more clicks on Zillow. Give your agents a free hero shot!',
                'description' => 'Deep dive into why Day-to-Dusk drives clicks and why our complimentary hero perk beats all competitors.',
                'html' => self::buildTemplateDay5()
            ],
            'tmpl_day6_urgency' => [
                'id' => 'tmpl_day6_urgency',
                'name' => 'Day 6: Final 48 Hours — Lock In $0.60 Grandfathered Rate',
                'day' => 'Day 6',
                'category' => '7-Day Sequence',
                'badge' => 'Urgency',
                'badge_color' => 'rose',
                'subject' => '⚠️ Final 48 Hours: Lock in your $0.60 HDR rate + Free Twilight before promo closes',
                'preview_text' => 'This exclusive agency promotional tier is ending. Lock in your grandfathered rate today.',
                'description' => 'Urgency email to close warm leads before promo expiration, locking in grandfathered rate.',
                'html' => self::buildTemplateDay6()
            ],
            'tmpl_day7_breakup' => [
                'id' => 'tmpl_day7_breakup',
                'name' => 'Day 7: Breakup Letter — Permission to Close Your File?',
                'day' => 'Day 7',
                'category' => '7-Day Sequence',
                'badge' => 'Breakup / VIP',
                'badge_color' => 'indigo',
                'subject' => 'Permission to close your file? (Last chance for $0.60 HDR + Free Day-to-Dusk Hero)',
                'preview_text' => 'I do not want to clutter your inbox. Let me know if you want 3 free test edits or if I should step back.',
                'description' => 'Ultra-polite breakup email inviting them to test 3 free photos with zero commitment.',
                'html' => self::buildTemplateDay7()
            ],
            'tmpl_agency_volume' => [
                'id' => 'tmpl_agency_volume',
                'name' => 'Agency Special: High Volume Tier ($0.45 - $0.60) + Dedicated Editor',
                'day' => 'Special',
                'category' => 'Broadcast / Special',
                'badge' => 'High Volume',
                'badge_color' => 'gold',
                'subject' => 'Bulk Rate Alert: Volume HDR blending starting at $0.45/image + Free Twilight Heroes',
                'preview_text' => 'Designed for teams shooting 10+ homes weekly. Dedicated editor pod, custom presets, 12h SLA.',
                'description' => 'Targeted at high-volume photography agencies, production companies, and multi-shooter teams.',
                'html' => self::buildTemplateAgencyVolume()
            ],
        ];
    }

    /**
     * Get a single template by ID
     */
    public static function getTemplateById(string $id): ?array
    {
        $templates = self::getAllTemplates();
        return $templates[$id] ?? null;
    }

    /**
     * Renders standard wrapper styling with Estate HDR branding
     */
    private static function wrapEmail(string $title, string $preheader, string $bodyContent): string
    {
        return '<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>' . htmlspecialchars($title) . '</title>
<style>
  body { margin: 0; padding: 0; background-color: #0A0A0F; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; -webkit-font-smoothing: antialiased; }
  table { border-collapse: collapse; }
  a { color: #C9A84C; text-decoration: none; }
  @media only screen and (max-width: 620px) {
    .wrapper-table { width: 100% !important; padding: 12px !important; }
    .col-half { display: block !important; width: 100% !important; margin-bottom: 12px !important; }
    .hero-btn { display: block !important; width: 100% !important; text-align: center !important; }
    .pricing-table th, .pricing-table td { padding: 6px 8px !important; font-size: 11px !important; }
  }
</style>
</head>
<body style="margin:0;padding:0;background-color:#0A0A0F;color:#F3F4F6;">
  <!-- Preheader Text (Hidden in body, visible in inbox preview) -->
  <div style="display:none;font-size:1px;color:#0A0A0F;line-height:1px;max-height:0px;max-width:0px;opacity:0;overflow:hidden;">
    ' . htmlspecialchars($preheader) . ' &zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;
  </div>

  <table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color:#0A0A0F;padding:30px 10px;">
    <tr>
      <td align="center">
        <!-- Main Email Container -->
        <table class="wrapper-table" width="620" border="0" cellpadding="0" cellspacing="0" style="width:620px;max-width:620px;background-color:#12121A;border:1px solid #232332;border-radius:18px;overflow:hidden;box-shadow:0 12px 40px rgba(0,0,0,0.6);">
          
          <!-- Header Bar -->
          <tr>
            <td style="padding:28px 36px;background:linear-gradient(180deg, #181824 0%, #12121A 100%);border-bottom:1px solid #232332;">
              <table width="100%" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="left">
                    <span style="font-size:22px;font-weight:900;letter-spacing:1.5px;color:#FFFFFF;text-transform:uppercase;">
                      ESTATE<span style="color:#C9A84C;">HDR</span>
                    </span>
                    <div style="font-size:10px;font-weight:700;letter-spacing:2px;color:#8E8EA0;text-transform:uppercase;margin-top:2px;">
                      PREMIUM REAL ESTATE PHOTO RETOUCHING
                    </div>
                  </td>
                  <td align="right">
                    <span style="display:inline-block;padding:5px 12px;background:rgba(201,168,76,0.12);border:1px solid rgba(201,168,76,0.35);border-radius:20px;font-size:10px;font-weight:800;letter-spacing:1px;color:#C9A84C;text-transform:uppercase;">
                      ★ EXCLUSIVE OFFER
                    </span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Body Content -->
          <tr>
            <td style="padding:32px 36px;color:#D1D5DB;font-size:14px;line-height:1.7;">
              ' . $bodyContent . '
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="padding:24px 36px;background-color:#0D0D14;border-top:1px solid #1E1E2B;text-align:center;color:#6B7280;font-size:11px;line-height:1.6;">
              <div style="font-size:13px;font-weight:800;color:#9CA3AF;margin-bottom:8px;">
                ESTATE HDR STUDIO &bull; 24/7 PRODUCTION DESK
              </div>
              <p style="margin:0 0 10px 0;">
                Trusted by 500+ Real Estate Photographers across the US, UK, Canada & Australia.<br>
                Official Support: <a href="mailto:info@estatehdr.com" style="color:#C9A84C;">info@estatehdr.com</a> &bull; WhatsApp: +92 312 6023223
              </p>
              <p style="margin:0;color:#4B5563;font-size:10px;">
                You received this email because you are a registered real estate media partner or subscriber.<br>
                <a href="{{unsubscribe_link}}" style="color:#6B7280;text-decoration:underline;">Unsubscribe from promotional announcements</a>
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>';
    }

    /**
     * Standard Pricing Matrix Block (Reused in templates)
     */
    private static function renderPricingMatrix(): string
    {
        return '<!-- Pricing & Perks Showcase Card -->
<div style="background:#171724;border:1px solid #2D2D3F;border-radius:14px;padding:22px;margin:24px 0;">
  
  <!-- Highlight Banner -->
  <div style="text-align:center;padding-bottom:16px;border-bottom:1px solid #262638;">
    <div style="font-size:11px;font-weight:800;letter-spacing:2px;color:#C9A84C;text-transform:uppercase;">LIMITED-TIME AGENCY RATE</div>
    <div style="margin-top:6px;">
      <span style="font-size:16px;color:#8E8EA0;text-decoration:line-through;margin-right:8px;font-weight:700;">Regular $0.80</span>
      <span style="font-size:32px;font-weight:900;color:#10B981;letter-spacing:-0.5px;">$0.60</span>
      <span style="font-size:14px;color:#9CA3AF;font-weight:600;">/ photo</span>
    </div>
    <div style="font-size:12px;color:#D1D5DB;margin-top:4px;">
      🔥 Instant <strong>25% Savings</strong> on every single HDR bracket!
    </div>
  </div>

  <!-- Complimentary Bonus Perk -->
  <div style="background:rgba(201,168,76,0.1);border:1px dashed #C9A84C;border-radius:10px;padding:14px 16px;margin:16px 0;text-align:center;">
    <div style="font-size:12px;font-weight:900;letter-spacing:1px;color:#FFFFFF;text-transform:uppercase;">
      🎁 COMPLIMENTARY BONUS PERK
    </div>
    <div style="font-size:15px;font-weight:900;color:#C9A84C;margin:4px 0;">
      1 FREE Day-to-Dusk (Virtual Twilight) Hero Photo
    </div>
    <div style="font-size:12px;color:#E5E7EB;">
      Included on <strong>EVERY single property order</strong> (Competitors charge $10–$15 extra!).
    </div>
  </div>

  <!-- Tiered Volume Discount Table -->
  <div style="margin-top:14px;">
    <div style="font-size:11px;font-weight:800;color:#9CA3AF;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;">
      📊 Volume Discount Scale (The More You Shoot, The More You Save):
    </div>
    <table class="pricing-table" width="100%" border="0" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse;font-size:12px;">
      <thead>
        <tr style="background:#1F1F30;color:#C9A84C;text-align:left;">
          <th style="padding:8px 12px;border:1px solid #2C2C40;border-radius:6px 0 0 0;">Volume / Photos</th>
          <th style="padding:8px 12px;border:1px solid #2C2C40;">Was</th>
          <th style="padding:8px 12px;border:1px solid #2C2C40;">Promo Rate</th>
          <th style="padding:8px 12px;border:1px solid #2C2C40;border-radius:0 6px 0 0;">Bonus Perk</th>
        </tr>
      </thead>
      <tbody>
        <tr style="background:#151522;">
          <td style="padding:8px 12px;border:1px solid #262638;color:#FFFFFF;font-weight:700;">1 &ndash; 24 Photos</td>
          <td style="padding:8px 12px;border:1px solid #262638;color:#71717A;text-decoration:line-through;">$0.80</td>
          <td style="padding:8px 12px;border:1px solid #262638;color:#10B981;font-weight:800;">$0.60 / photo</td>
          <td style="padding:8px 12px;border:1px solid #262638;color:#C9A84C;font-weight:700;">+ 1 Free Twilight</td>
        </tr>
        <tr style="background:#181827;">
          <td style="padding:8px 12px;border:1px solid #262638;color:#FFFFFF;font-weight:700;">25 &ndash; 49 Photos</td>
          <td style="padding:8px 12px;border:1px solid #262638;color:#71717A;text-decoration:line-through;">$0.75</td>
          <td style="padding:8px 12px;border:1px solid #262638;color:#10B981;font-weight:800;">$0.55 / photo</td>
          <td style="padding:8px 12px;border:1px solid #262638;color:#C9A84C;font-weight:700;">+ 1 Free Twilight</td>
        </tr>
        <tr style="background:#151522;">
          <td style="padding:8px 12px;border:1px solid #262638;color:#FFFFFF;font-weight:700;">50 &ndash; 99 Photos</td>
          <td style="padding:8px 12px;border:1px solid #262638;color:#71717A;text-decoration:line-through;">$0.70</td>
          <td style="padding:8px 12px;border:1px solid #262638;color:#10B981;font-weight:800;">$0.50 / photo</td>
          <td style="padding:8px 12px;border:1px solid #262638;color:#C9A84C;font-weight:700;">+ 1 Free Twilight</td>
        </tr>
        <tr style="background:#181827;">
          <td style="padding:8px 12px;border:1px solid #262638;color:#FFFFFF;font-weight:700;">100+ Photos</td>
          <td style="padding:8px 12px;border:1px solid #262638;color:#71717A;text-decoration:line-through;">$0.65</td>
          <td style="padding:8px 12px;border:1px solid #262638;color:#10B981;font-weight:900;">$0.45 / photo</td>
          <td style="padding:8px 12px;border:1px solid #262638;color:#C9A84C;font-weight:700;">+ 1 Free Twilight + Rush SLA</td>
        </tr>
      </tbody>
    </table>
  </div>
</div>';
    }

    /**
     * Day 1: Cold Intro & Announcement
     */
    private static function buildTemplateDay1(): string
    {
        $body = '<p style="font-size:16px;color:#FFFFFF;margin-top:0;">
  Hi <strong>{{first_name}}</strong>,
</p>
<p>
  If you are spending hours editing HDR brackets late at night or paying <strong>$0.80–$1.50+ per image</strong> to your current editing team, I have exciting news for you.
</p>
<p>
  At <strong>Estate HDR</strong>, we are officially rolling out our <strong>Exclusive Agency Promotional Rate</strong> for select real estate photographers:
</p>

<!-- Big Announcement Header -->
<div style="text-align:center;margin:20px 0;">
  <span style="display:inline-block;padding:6px 14px;background:#C9A84C;color:#0A0A0F;font-size:12px;font-weight:900;border-radius:20px;letter-spacing:1px;text-transform:uppercase;">
    ⚡ LIMITED TIME LAUNCH PRICING
  </span>
</div>

' . self::renderPricingMatrix() . '

<!-- Quality Guarantees -->
<div style="background:#151522;border:1px solid #262638;border-radius:12px;padding:16px;margin:20px 0;">
  <div style="font-size:12px;font-weight:800;color:#C9A84C;text-transform:uppercase;margin-bottom:8px;">
    🏆 Every Order Includes Our Studio Standard:
  </div>
  <table width="100%" border="0" cellpadding="4" cellspacing="0" style="font-size:13px;color:#E5E7EB;">
    <tr><td width="20" style="color:#10B981;">✔</td><td><strong>100% Hand-Blended Flambient & HDR:</strong> Crisp window pulls with natural, halo-free lighting.</td></tr>
    <tr><td width="20" style="color:#10B981;">✔</td><td><strong>24-Hour Standard Turnaround:</strong> Need it faster? 12-hour rush SLA available.</td></tr>
    <tr><td width="20" style="color:#10B981;">✔</td><td><strong>Sky Replacement & Lawn Greening:</strong> Vibrant skies and lush lawns at zero extra charge.</td></tr>
    <tr><td width="20" style="color:#10B981;">✔</td><td><strong>Unlimited Free Revisions:</strong> We keep tweaking until you and your client are 100% thrilled.</td></tr>
  </table>
</div>

<p>
  <strong>Want to test us with zero risk?</strong><br>
  Send us <strong>3 bracket sets from your latest shoot</strong>. We will edit them for <strong>FREE ($0.00)</strong> so you can see the craftsmanship first-hand before spending a dime.
</p>

<!-- CTA Button -->
<div style="text-align:center;margin:30px 0 10px 0;">
  <a class="hero-btn" href="https://estatehdr.com/#pricing" style="display:inline-block;padding:16px 36px;background:linear-gradient(135deg, #C9A84C 0%, #DFBE65 100%);color:#0A0A0F;font-size:14px;font-weight:900;letter-spacing:1px;text-transform:uppercase;border-radius:10px;text-decoration:none;box-shadow:0 8px 24px rgba(201,168,76,0.35);">
    Claim Your $0.60 Rate + Free Day-to-Dusk &rarr;
  </a>
</div>

<p style="font-size:12px;color:#8E8EA0;text-align:center;margin-top:14px;">
  No credit card required. Just drop your Dropbox or Drive link and experience the speed.
</p>

<p style="margin-top:24px;">
  Best regards,<br>
  <strong>Nadeem Ashraf & The Estate HDR Production Team</strong><br>
  <span style="font-size:12px;color:#8E8EA0;">WhatsApp / Direct: +92 312 6023223 | info@estatehdr.com</span>
</p>';

        return self::wrapEmail(
            'Exclusive: $0.60 HDR Photo Editing (Was $0.80) + 1 FREE Day-to-Dusk',
            'Limited time launch offer: 25% off HDR + free virtual twilight on every shoot.',
            $body
        );
    }

    /**
     * Day 2: Visual Proof & Hand-Blended Quality
     */
    private static function buildTemplateDay2(): string
    {
        $body = '<p style="font-size:16px;color:#FFFFFF;margin-top:0;">
  Hi <strong>{{first_name}}</strong>,
</p>
<p>
  Yesterday I mentioned our limited-time <strong>$0.60 / photo HDR rate</strong> (slashed from $0.80). But as a professional photographer, I know talk is cheap &mdash; <strong>the proof is in the pixels</strong>.
</p>
<p>
  Most cheap editing overseas relies on automated software that leaves muddy walls, radioactive neon greens, and dark halos around window frames. Here is how Estate HDR does it differently:
</p>

<!-- Comparison Pillars -->
<div style="background:#171724;border:1px solid #2D2D3F;border-radius:14px;padding:20px;margin:22px 0;">
  <div style="font-size:13px;font-weight:900;color:#C9A84C;text-transform:uppercase;margin-bottom:12px;letter-spacing:1px;">
    🔍 The Estate HDR Quality Standard:
  </div>
  
  <table width="100%" border="0" cellpadding="6" cellspacing="0" style="font-size:13px;color:#D1D5DB;">
    <tr>
      <td width="30" valign="top" style="font-size:18px;">🪟</td>
      <td valign="top">
        <strong style="color:#FFFFFF;">Crystal-Clear Window Pulls:</strong> We cleanly expose the lush garden, mountain view, or blue sky outside with zero unnatural ghosting or black border halos.
      </td>
    </tr>
    <tr>
      <td width="30" valign="top" style="font-size:18px;">🎨</td>
      <td valign="top">
        <strong style="color:#FFFFFF;">True White Walls & Ceilings:</strong> We balance interior tungsten bulbs and cool ambient daylight so whites look crisp and wood textures stay warm.
      </td>
    </tr>
    <tr>
      <td width="30" valign="top" style="font-size:18px;">🌅</td>
      <td valign="top">
        <strong style="color:#FFFFFF;">1 Free Day-to-Dusk Hero Photo:</strong> Every property includes 1 free dusk twilight conversion that stops house hunters mid-scroll on Zillow!
      </td>
    </tr>
    <tr>
      <td width="30" valign="top" style="font-size:18px;">⚡</td>
      <td valign="top">
        <strong style="color:#FFFFFF;">Guaranteed 24-Hour SLA:</strong> Sleep easy knowing your files will be waiting in your inbox before your morning shoot.
      </td>
    </tr>
  </table>
</div>

' . self::renderPricingMatrix() . '

<p>
  Whether you shoot 20 photos a week or 200 photos a day, we have dedicated retouchers ready to lock in your custom color profile.
</p>

<!-- CTA Button -->
<div style="text-align:center;margin:30px 0 10px 0;">
  <a class="hero-btn" href="https://estatehdr.com" style="display:inline-block;padding:16px 36px;background:linear-gradient(135deg, #C9A84C 0%, #DFBE65 100%);color:#0A0A0F;font-size:14px;font-weight:900;letter-spacing:1px;text-transform:uppercase;border-radius:10px;text-decoration:none;box-shadow:0 8px 24px rgba(201,168,76,0.35);">
    View Our Full Portfolio & Samples &rarr;
  </a>
</div>

<p style="margin-top:24px;">
  Talk soon,<br>
  <strong>Nadeem Ashraf & The Estate HDR Production Team</strong>
</p>';

        return self::wrapEmail(
            'Before vs After: See why studios switched to Estate HDR ($0.60/photo + Free Twilight)',
            'Crystal-clear window pulls, true wall colors, zero radioactive grass. See our portfolio.',
            $body
        );
    }

    /**
     * Day 3: Cost Calculator & Margin Analysis
     */
    private static function buildTemplateDay3(): string
    {
        $body = '<p style="font-size:16px;color:#FFFFFF;margin-top:0;">
  Hi <strong>{{first_name}}</strong>,
</p>
<p>
  Let’s do some quick math on your real estate photography margins.
</p>
<p>
  If you shoot <strong>15 properties a month</strong> averaging 30 photos per property:
</p>

<!-- Math Breakdown Box -->
<div style="background:#171724;border:1px solid #2D2D3F;border-radius:14px;padding:20px;margin:22px 0;">
  <div style="font-size:12px;font-weight:800;color:#C9A84C;text-transform:uppercase;letter-spacing:1px;margin-bottom:12px;">
    💰 Monthly Editing Bill Comparison (450 Photos / Month):
  </div>
  
  <table width="100%" border="0" cellpadding="8" cellspacing="0" style="font-size:13px;border-collapse:collapse;">
    <tr style="border-bottom:1px solid #262638;">
      <td style="color:#9CA3AF;">At Typical Agency Rate ($1.00 / photo):</td>
      <td align="right" style="color:#EF4444;font-weight:800;font-size:15px;">$450.00 / mo</td>
    </tr>
    <tr style="border-bottom:1px solid #262638;">
      <td style="color:#9CA3AF;">At Our Previous Standard ($0.80 / photo):</td>
      <td align="right" style="color:#F59E0B;font-weight:800;font-size:15px;">$360.00 / mo</td>
    </tr>
    <tr style="background:#1F1F32;">
      <td style="color:#FFFFFF;font-weight:700;">At Estate HDR Promo Tier ($0.50 volume rate):</td>
      <td align="right" style="color:#10B981;font-weight:900;font-size:18px;">$225.00 / mo</td>
    </tr>
    <tr style="border-top:1px solid #262638;">
      <td style="color:#C9A84C;font-weight:700;">+ 15 FREE Day-to-Dusk Twilight Heroes (Value: $225):</td>
      <td align="right" style="color:#C9A84C;font-weight:900;font-size:15px;">$0.00 (FREE!)</td>
    </tr>
  </table>

  <div style="background:rgba(16,185,129,0.1);border:1px solid #10B981;border-radius:8px;padding:12px;margin-top:14px;text-align:center;">
    <span style="font-size:14px;font-weight:900;color:#10B981;">
      💵 You pocket over $225.00 cash savings every month + $225 in free twilights!
    </span>
  </div>
</div>

' . self::renderPricingMatrix() . '

<p>
  Why pay more for slower turnaround and extra twilight fees? With Estate HDR, you get luxury hand-blended quality while dramatically improving your take-home pay.
</p>

<!-- CTA Button -->
<div style="text-align:center;margin:30px 0 10px 0;">
  <a class="hero-btn" href="https://estatehdr.com/#pricing" style="display:inline-block;padding:16px 36px;background:linear-gradient(135deg, #C9A84C 0%, #DFBE65 100%);color:#0A0A0F;font-size:14px;font-weight:900;letter-spacing:1px;text-transform:uppercase;border-radius:10px;text-decoration:none;box-shadow:0 8px 24px rgba(201,168,76,0.35);">
    Start Saving With $0.60 Pricing Today &rarr;
  </a>
</div>

<p style="margin-top:24px;">
  Best regards,<br>
  <strong>The Estate HDR Team</strong>
</p>';

        return self::wrapEmail(
            'Cut your editing bill by 40% with our $0.60 limited rate (+ Free Day-to-Dusk)',
            'A typical 30-photo shoot costs just $16.50 total and includes a $15 free twilight hero!',
            $body
        );
    }

    /**
     * Day 4: Workflow Speed & In-Car Ordering
     */
    private static function buildTemplateDay4(): string
    {
        $body = '<p style="font-size:16px;color:#FFFFFF;margin-top:0;">
  Hi <strong>{{first_name}}</strong>,
</p>
<p>
  How much time do you spend wrestling with complex upload forms or uploading RAW files through slow portals?
</p>
<p>
  At <strong>Estate HDR</strong>, we built our workflow around how real estate photographers actually work in the field:
</p>

<!-- Steps Box -->
<div style="background:#171724;border:1px solid #2D2D3F;border-radius:14px;padding:22px;margin:22px 0;">
  <div style="font-size:12px;font-weight:800;color:#C9A84C;text-transform:uppercase;letter-spacing:1px;margin-bottom:14px;">
    ⚡ The 60-Second In-Car Workflow:
  </div>

  <table width="100%" border="0" cellpadding="8" cellspacing="0" style="font-size:13px;color:#D1D5DB;">
    <tr>
      <td width="36" valign="top" style="font-weight:900;color:#C9A84C;font-size:18px;">1.</td>
      <td valign="top">
        <strong style="color:#FFFFFF;">Upload to Dropbox, Google Drive, or WeTransfer:</strong> Before leaving the driveway of your listing, kick off your upload.
      </td>
    </tr>
    <tr>
      <td width="36" valign="top" style="font-weight:900;color:#C9A84C;font-size:18px;">2.</td>
      <td valign="top">
        <strong style="color:#FFFFFF;">Send us the link:</strong> Drop the link into our portal or email it to us with any custom notes.
      </td>
    </tr>
    <tr>
      <td width="36" valign="top" style="font-weight:900;color:#C9A84C;font-size:18px;">3.</td>
      <td valign="top">
        <strong style="color:#FFFFFF;">Wake up to MLS-Ready Images:</strong> 24 hours later (or 12h rush), high-res, print-ready, MLS-sized HDR photos + your Free Day-to-Dusk hero are waiting.
      </td>
    </tr>
  </table>
</div>

' . self::renderPricingMatrix() . '

<p>
  No credit card needed to test. Try 3 free photos today and see how easy real estate editing should be.
</p>

<!-- CTA Button -->
<div style="text-align:center;margin:30px 0 10px 0;">
  <a class="hero-btn" href="https://estatehdr.com" style="display:inline-block;padding:16px 36px;background:linear-gradient(135deg, #C9A84C 0%, #DFBE65 100%);color:#0A0A0F;font-size:14px;font-weight:900;letter-spacing:1px;text-transform:uppercase;border-radius:10px;text-decoration:none;box-shadow:0 8px 24px rgba(201,168,76,0.35);">
    Send Your Drive Link & Start Test Edit &rarr;
  </a>
</div>

<p style="margin-top:24px;">
  Cheers,<br>
  <strong>Nadeem Ashraf & The Estate HDR Production Team</strong>
</p>';

        return self::wrapEmail(
            'Shoot all day, send Dropbox link from your car, wake up to MLS-ready HDRs ⚡',
            'No complicated software or portals. Just send your Dropbox or Drive link before you head home.',
            $body
        );
    }

    /**
     * Day 5: Twilight Focus & Agent Delight
     */
    private static function buildTemplateDay5(): string
    {
        $body = '<p style="font-size:16px;color:#FFFFFF;margin-top:0;">
  Hi <strong>{{first_name}}</strong>,
</p>
<p>
  Did you know that listings featuring a <strong>twilight exterior as their primary photo generate 3x more click-throughs</strong> on Zillow, Realtor.com, and Redfin?
</p>
<p>
  Agents love twilights. But taking real twilight photos means waiting around until 8:30 PM, freezing outside, and charging the agent $150+ for a separate shoot.
</p>
<p>
  That is why <strong>Estate HDR includes 1 FREE Day-to-Dusk (Virtual Twilight) Hero Photo with EVERY single property order!</strong>
</p>

<!-- Twilight Feature Card -->
<div style="background:linear-gradient(180deg, #1C1528 0%, #12121A 100%);border:1px solid #4C2D75;border-radius:14px;padding:22px;margin:22px 0;">
  <div style="font-size:11px;font-weight:800;letter-spacing:2px;color:#C9A84C;text-transform:uppercase;">
    🌅 THE ESTATE HDR SECRET WEAPON
  </div>
  <div style="font-size:18px;font-weight:900;color:#FFFFFF;margin:8px 0;">
    Day-to-Dusk Conversion with Warm Interior Glow
  </div>
  <p style="font-size:13px;color:#D1D5DB;margin:0 0 12px 0;">
    We transform a plain daytime exterior into a moody, glowing luxury dusk showcase:
  </p>
  <ul style="font-size:13px;color:#E5E7EB;margin:0;padding-left:20px;line-height:1.8;">
    <li>Dramatic sunset/twilight sky replacement (deep blue, purple, and warm gold hues).</li>
    <li>Realistic warm window lighting added to every pane so the home looks welcoming.</li>
    <li>Landscape and pathway lighting illumination for magazine-cover appeal.</li>
  </ul>
  <div style="margin-top:14px;padding-top:12px;border-top:1px solid #36224E;font-size:12px;color:#C9A84C;font-weight:700;">
    ★ Yours 100% FREE on every home (Competitors charge $10 &ndash; $15 per photo!).
  </div>
</div>

' . self::renderPricingMatrix() . '

<p>
  You can either gift this twilight photo to your agents to blow them away and earn repeat business, or resell it to them for $25&ndash;$45 pure profit!
</p>

<!-- CTA Button -->
<div style="text-align:center;margin:30px 0 10px 0;">
  <a class="hero-btn" href="https://estatehdr.com" style="display:inline-block;padding:16px 36px;background:linear-gradient(135deg, #C9A84C 0%, #DFBE65 100%);color:#0A0A0F;font-size:14px;font-weight:900;letter-spacing:1px;text-transform:uppercase;border-radius:10px;text-decoration:none;box-shadow:0 8px 24px rgba(201,168,76,0.35);">
    Get Your Free Day-to-Dusk On Next Order &rarr;
  </a>
</div>

<p style="margin-top:24px;">
  Best regards,<br>
  <strong>Nadeem Ashraf & The Estate HDR Production Team</strong>
</p>';

        return self::wrapEmail(
            'How our 1 FREE Day-to-Dusk on every property wins you more agent clients 🌅',
            'Listings with twilight covers get 3x more clicks on Zillow. Give your agents a free hero shot!',
            $body
        );
    }

    /**
     * Day 6: Urgency & Rate Grandfathering
     */
    private static function buildTemplateDay6(): string
    {
        $body = '<p style="font-size:16px;color:#FFFFFF;margin-top:0;">
  Hi <strong>{{first_name}}</strong>,
</p>
<p>
  Quick heads up: our <strong>$0.60 / photo promotional tier</strong> (slashed from our regular $0.80 standard) is closing soon.
</p>
<p>
  Because each photo is <strong>100% hand-blended by expert architectural retouchers</strong>, we limit how many new photography studios we onboard to protect our strict 24-hour delivery SLA.
</p>

<!-- Urgency Banner -->
<div style="background:#2A1414;border:1px solid #7F1D1D;border-radius:12px;padding:18px;margin:20px 0;text-align:center;">
  <div style="font-size:11px;font-weight:900;letter-spacing:2px;color:#EF4444;text-transform:uppercase;">
    ⚠️ FINAL 48 HOURS NOTICE
  </div>
  <div style="font-size:16px;font-weight:900;color:#FFFFFF;margin:6px 0;">
    Lock in your $0.60/photo Grandfathered Rate Today
  </div>
  <div style="font-size:12px;color:#FCA5A5;">
    Once this enrollment window closes, new accounts revert back to the standard $0.80 rate.
  </div>
</div>

' . self::renderPricingMatrix() . '

<p>
  <strong>How to lock in your rate:</strong><br>
  You do not need to place an order today. Simply reply to this email with <em>"LOCK MY RATE"</em> or submit a test bracket, and we will grandfather your account at the <strong>$0.60 tier + 1 Free Day-to-Dusk perk</strong> for all your shoots throughout the upcoming season!
</p>

<!-- CTA Button -->
<div style="text-align:center;margin:30px 0 10px 0;">
  <a class="hero-btn" href="https://estatehdr.com/#pricing" style="display:inline-block;padding:16px 36px;background:linear-gradient(135deg, #EF4444 0%, #F87171 100%);color:#FFFFFF;font-size:14px;font-weight:900;letter-spacing:1px;text-transform:uppercase;border-radius:10px;text-decoration:none;box-shadow:0 8px 24px rgba(239,68,68,0.35);">
    Lock In Grandfathered $0.60 Pricing Now &rarr;
  </a>
</div>

<p style="margin-top:24px;">
  Best regards,<br>
  <strong>Nadeem Ashraf & The Estate HDR Production Team</strong>
</p>';

        return self::wrapEmail(
            '⚠️ Final 48 Hours: Lock in your $0.60 HDR rate + Free Twilight before promo closes',
            'This exclusive agency promotional tier is ending. Lock in your grandfathered rate today.',
            $body
        );
    }

    /**
     * Day 7: Breakup Letter & Final Free Pass
     */
    private static function buildTemplateDay7(): string
    {
        $body = '<p style="font-size:16px;color:#FFFFFF;margin-top:0;">
  Hi <strong>{{first_name}}</strong>,
</p>
<p>
  I haven’t heard back from you, so I assume you are completely satisfied with your current editing workflow or the timing isn’t right. Completely understand!
</p>
<p>
  I promise I won’t clutter your inbox further. Before I close your file, I wanted to leave you with one permanent invitation:
</p>

<!-- Breakup Pass Box -->
<div style="background:#171724;border:1px solid #2D2D3F;border-radius:14px;padding:22px;margin:22px 0;">
  <div style="font-size:12px;font-weight:800;color:#C9A84C;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;">
    🎟️ YOUR PERMANENT BACKUP PASS
  </div>
  <div style="font-size:15px;font-weight:800;color:#FFFFFF;margin-bottom:10px;">
    Keep Estate HDR as Your Secret Weapon
  </div>
  <p style="font-size:13px;color:#D1D5DB;margin:0 0 10px 0;">
    The next time your primary editor is sick, takes vacation, misses a 24-hour deadline, or delivers muddy windows:
  </p>
  <ul style="font-size:13px;color:#E5E7EB;margin:0;padding-left:20px;line-height:1.7;">
    <li>Send us your brackets via Dropbox or Drive.</li>
    <li>Enjoy the special <strong>$0.60 / photo rate</strong> (Was $0.80) with tiered volume discounts down to $0.45.</li>
    <li>Get <strong>1 FREE Day-to-Dusk Hero Photo</strong> included on every property.</li>
    <li>24-hour turnaround with unlimited free revisions guaranteed.</li>
  </ul>
</div>

' . self::renderPricingMatrix() . '

<p>
  Whenever you are ready for a test run, just visit <a href="https://estatehdr.com" style="color:#C9A84C;font-weight:700;">estatehdr.com</a> or shoot us a WhatsApp message at <strong>+92 312 6023223</strong>.
</p>

<!-- CTA Button -->
<div style="text-align:center;margin:30px 0 10px 0;">
  <a class="hero-btn" href="https://estatehdr.com" style="display:inline-block;padding:16px 36px;background:linear-gradient(135deg, #C9A84C 0%, #DFBE65 100%);color:#0A0A0F;font-size:14px;font-weight:900;letter-spacing:1px;text-transform:uppercase;border-radius:10px;text-decoration:none;box-shadow:0 8px 24px rgba(201,168,76,0.35);">
    Bookmark Estate HDR For Your Next Shoot &rarr;
  </a>
</div>

<p style="margin-top:24px;">
  Wishing you an incredible shooting season ahead,<br>
  <strong>Nadeem Ashraf & The Estate HDR Production Team</strong><br>
  <span style="font-size:12px;color:#8E8EA0;">info@estatehdr.com | estatehdr.com</span>
</p>';

        return self::wrapEmail(
            'Permission to close your file? (Last chance for $0.60 HDR + Free Day-to-Dusk Hero)',
            'I do not want to clutter your inbox. Let me know if you want 3 free test edits or if I should step back.',
            $body
        );
    }

    /**
     * High-Volume Agency & Studio Special
     */
    private static function buildTemplateAgencyVolume(): string
    {
        $body = '<p style="font-size:16px;color:#FFFFFF;margin-top:0;">
  Hi <strong>{{first_name}}</strong>,
</p>
<p>
  Are you managing a real estate photography team or agency shooting <strong>10 to 50+ listings every single week</strong>?
</p>
<p>
  Managing high-volume editing is a nightmare when turnaround delays cost you realtor clients. That is why <strong>Estate HDR</strong> provides dedicated enterprise editing solutions for volume media studios:
</p>

<!-- Agency Perks Box -->
<div style="background:#171724;border:1px solid #2D2D3F;border-radius:14px;padding:22px;margin:22px 0;">
  <div style="font-size:12px;font-weight:800;color:#C9A84C;text-transform:uppercase;letter-spacing:1px;margin-bottom:12px;">
    🏢 High-Volume Media Agency Features:
  </div>
  
  <table width="100%" border="0" cellpadding="6" cellspacing="0" style="font-size:13px;color:#D1D5DB;">
    <tr>
      <td width="26" valign="top" style="color:#10B981;font-weight:900;">✓</td>
      <td valign="top"><strong>Dedicated Retouching Pod:</strong> The exact same hand-blending artists assigned to your agency every day for 100% style consistency.</td>
    </tr>
    <tr>
      <td width="26" valign="top" style="color:#10B981;font-weight:900;">✓</td>
      <td valign="top"><strong>Volume Rates Down to $0.45 / photo:</strong> Slashed from our regular $0.80 standard pricing.</td>
    </tr>
    <tr>
      <td width="26" valign="top" style="color:#10B981;font-weight:900;">✓</td>
      <td valign="top"><strong>1 FREE Day-to-Dusk on EVERY Property:</strong> Add $1,000s in perceived value to your client delivery packages without paying an extra cent.</td>
    </tr>
    <tr>
      <td width="26" valign="top" style="color:#10B981;font-weight:900;">✓</td>
      <td valign="top"><strong>Priority 12-Hour SLA:</strong> Overnight delivery ready for your agents at 9:00 AM sharp.</td>
    </tr>
    <tr>
      <td width="26" valign="top" style="color:#10B981;font-weight:900;">✓</td>
      <td valign="top"><strong>Flexible Billing:</strong> Monthly unified invoicing or pay-as-you-go via PayPal or Stripe.</td>
    </tr>
  </table>
</div>

' . self::renderPricingMatrix() . '

<p>
  Let’s run a <strong>batch test on 5 listings</strong> so you can inspect speed, style matching, and communication.
</p>

<!-- CTA Button -->
<div style="text-align:center;margin:30px 0 10px 0;">
  <a class="hero-btn" href="https://estatehdr.com" style="display:inline-block;padding:16px 36px;background:linear-gradient(135deg, #C9A84C 0%, #DFBE65 100%);color:#0A0A0F;font-size:14px;font-weight:900;letter-spacing:1px;text-transform:uppercase;border-radius:10px;text-decoration:none;box-shadow:0 8px 24px rgba(201,168,76,0.35);">
    Request Volume Agency Partnership &rarr;
  </a>
</div>

<p style="margin-top:24px;">
  Sincerely,<br>
  <strong>Nadeem Ashraf & The Estate HDR Production Team</strong><br>
  <span style="font-size:12px;color:#8E8EA0;">WhatsApp / Direct: +92 312 6023223 | info@estatehdr.com</span>
</p>';

        return self::wrapEmail(
            'Bulk Rate Alert: Volume HDR blending starting at $0.45/image + Free Twilight Heroes',
            'Designed for teams shooting 10+ homes weekly. Dedicated editor pod, custom presets, 12h SLA.',
            $body
        );
    }
}
