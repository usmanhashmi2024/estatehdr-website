<?php
/**
 * Estate HDR - Subscription & Usage Metering Service
 * Enterprise Layer: Subscription System & Usage Metering
 * 
 * Tiers: Starter, Professional, Business, Enterprise
 * Tracks image credits, storage GB, API calls, and overages.
 */

class SubscriptionService {
    private static string $subFile = __DIR__ . '/../../data/client_subscriptions.json';
    private static string $meterFile = __DIR__ . '/../../data/usage_metering.json';

    public static array $tiers = [
        'starter' => [
            'name' => 'Starter Agency',
            'monthly_fee' => 99,
            'image_credits' => 100,
            'max_users' => 3,
            'api_access' => false,
            'storage_gb' => 25,
            'sla_hours' => 24
        ],
        'pro' => [
            'name' => 'Professional Media',
            'monthly_fee' => 299,
            'image_credits' => 350,
            'max_users' => 8,
            'api_access' => true,
            'storage_gb' => 100,
            'sla_hours' => 18
        ],
        'business' => [
            'name' => 'Business Studio',
            'monthly_fee' => 699,
            'image_credits' => 1000,
            'max_users' => 20,
            'api_access' => true,
            'storage_gb' => 500,
            'sla_hours' => 12
        ],
        'enterprise' => [
            'name' => 'Enterprise Billion-Scale',
            'monthly_fee' => 1999,
            'image_credits' => 3500,
            'max_users' => 100,
            'api_access' => true,
            'storage_gb' => 5000,
            'sla_hours' => 6,
            'dedicated_team' => true
        ]
    ];

    /**
     * Get or initialize client subscription
     */
    public static function getSubscription(string $clientId): array {
        if (!file_exists(self::$subFile)) {
            @file_put_contents(self::$subFile, json_encode([], JSON_PRETTY_PRINT));
        }
        $data = json_decode(@file_get_contents(self::$subFile), true) ?: [];

        if (isset($data[$clientId])) {
            return $data[$clientId];
        }

        // Default to Starter
        $sub = [
            'client_id' => $clientId,
            'tier' => 'starter',
            'status' => 'active',
            'renews_at' => date('Y-m-d', strtotime('+30 days')),
            'created_at' => date('Y-m-d H:i:s')
        ];
        $data[$clientId] = $sub;
        @file_put_contents(self::$subFile, json_encode($data, JSON_PRETTY_PRINT));
        return $sub;
    }

    /**
     * Record usage metering for a client (images, storage, api calls)
     */
    public static function recordUsage(string $clientId, string $metricType, int $amount = 1): void {
        if (!file_exists(self::$meterFile)) {
            @file_put_contents(self::$meterFile, json_encode([], JSON_PRETTY_PRINT));
        }
        $data = json_decode(@file_get_contents(self::$meterFile), true) ?: [];

        $period = date('Y-m');
        if (!isset($data[$clientId][$period])) {
            $data[$clientId][$period] = [
                'images_processed' => 0,
                'api_calls' => 0,
                'storage_bytes' => 0,
                'orders_count' => 0
            ];
        }

        if (isset($data[$clientId][$period][$metricType])) {
            $data[$clientId][$period][$metricType] += $amount;
        } else {
            $data[$clientId][$period][$metricType] = $amount;
        }

        @file_put_contents(self::$meterFile, json_encode($data, JSON_PRETTY_PRINT));
    }

    /**
     * Get current month usage
     */
    public static function getUsage(string $clientId): array {
        if (!file_exists(self::$meterFile)) return [];
        $data = json_decode(@file_get_contents(self::$meterFile), true) ?: [];
        $period = date('Y-m');
        return $data[$clientId][$period] ?? [
            'images_processed' => 0,
            'api_calls' => 0,
            'storage_bytes' => 0,
            'orders_count' => 0
        ];
    }
}
