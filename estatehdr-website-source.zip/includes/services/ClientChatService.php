<?php
/**
 * Estate HDR — Client-to-Management Live Chat Service
 * Handles persistent 2-way real-time messaging between portal clients and studio management.
 */

class ClientChatService {
    private static function getFilePath(): string {
        $dataPath = defined('DATA_PATH') ? DATA_PATH : (dirname(__DIR__, 2) . '/data/');
        if (!is_dir($dataPath)) {
            @mkdir($dataPath, 0755, true);
        }
        return $dataPath . 'client_chats.json';
    }

    public static function getAllChats(): array {
        $file = self::getFilePath();
        if (!file_exists($file)) {
            return [];
        }
        $data = @json_decode(@file_get_contents($file), true);
        return is_array($data) ? $data : [];
    }

    public static function saveAllChats(array $chats): bool {
        $file = self::getFilePath();
        $json = json_encode($chats, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return (bool)@file_put_contents($file, $json, LOCK_EX);
    }

    public static function getClientThread(string $clientId, ?array $userContext = null): array {
        $chats = self::getAllChats();
        if (!isset($chats[$clientId])) {
            $now = date('Y-m-d H:i:s');
            $name = $userContext['name'] ?? 'Client';
            $email = $userContext['email'] ?? '';
            $company = $userContext['company'] ?? ($userContext['agency'] ?? 'Photography Studio');

            $chats[$clientId] = [
                'client_id'       => $clientId,
                'client_name'     => $name,
                'client_email'    => $email,
                'company'         => $company,
                'created_at'      => $now,
                'last_active'     => $now,
                'last_active_ts'  => time(),
                'unread_admin'    => 0,
                'unread_client'   => 0,
                'selected_order'  => null,
                'assigned_lead'   => 'Production Management Desk',
                'status'          => 'open',
                'messages'        => [
                    [
                        'id'          => 'msg_welcome_' . substr(md5($clientId), 0, 6),
                        'sender'      => 'management',
                        'sender_name' => 'Sarah (Production Director)',
                        'sender_role' => 'Management',
                        'text'        => "Hello {$name}! Welcome to the Estate HDR Direct Management Desk. 👋\n\nHow can we assist you today? You can select an order to track, request rush delivery, or ask about revisions.",
                        'order_id'    => null,
                        'timestamp'   => $now,
                        'ts'          => time()
                    ]
                ]
            ];
            self::saveAllChats($chats);
        }
        return $chats[$clientId];
    }

    public static function postClientMessage(string $clientId, string $text, ?string $orderId = null, ?array $userContext = null, ?array $attachment = null): array {
        $chats = self::getAllChats();
        $thread = self::getClientThread($clientId, $userContext);
        
        $now = date('Y-m-d H:i:s');
        $nowTs = time();

        $clientName = $userContext['name'] ?? ($thread['client_name'] ?? 'Client');
        $clientEmail = $userContext['email'] ?? ($thread['client_email'] ?? '');

        // Auto-extract Order ID from text if not explicitly passed
        if (empty($orderId) && preg_match('/\b(ORD-[A-Z0-9\-]+|TRIAL-[A-Z0-9\-]+)\b/i', $text, $m)) {
            $orderId = strtoupper($m[1]);
        }

        $thread['client_name'] = $clientName;
        if (!empty($clientEmail)) $thread['client_email'] = $clientEmail;
        $thread['last_active'] = $now;
        $thread['last_active_ts'] = $nowTs;
        $thread['unread_admin'] = (int)($thread['unread_admin'] ?? 0) + 1;
        if ($orderId) {
            $thread['selected_order'] = $orderId;
        }

        // New client message
        $userMsgId = 'msg_c_' . substr(bin2hex(random_bytes(4)), 0, 8);
        $thread['messages'][] = [
            'id'          => $userMsgId,
            'sender'      => 'client',
            'sender_name' => $clientName,
            'sender_role' => 'Client',
            'text'        => $text,
            'order_id'    => $orderId ?: null,
            'attachment'  => $attachment,
            'timestamp'   => $now,
            'ts'          => $nowTs
        ];

        // Intelligent auto-acknowledgment logic
        $lower = strtolower(trim($text));
        $autoReply = null;

        // Check if message is asking about rush/expedite
        if (preg_match('/\b(rush|expedite|urgent|emergency|deadline|fast|hurry|asap|today|tonight)\b/i', $lower)) {
            $orderMention = $orderId ? "for Order #{$orderId}" : "";
            $autoReply = "We have received your urgent priority request {$orderMention}! ⚡ Our shift supervisor has been alerted and is reviewing the retoucher's progress right now. A manager will update you here shortly.";
        } elseif (preg_match('/\b(status|track|update|progress|when|ready|finish|completed)\b/i', $lower)) {
            $orderMention = $orderId ? "regarding Order #{$orderId}" : "regarding your property";
            $autoReply = "Thank you for checking in {$orderMention}. Our production pipeline is operating at optimal speed. We're verifying live status with the Team Lead and will reply directly in this thread.";
        } elseif (preg_match('/\b(revision|fix|change|tweak|amendment|reshoot|grass|sky|window)\b/i', $lower)) {
            $orderMention = $orderId ? "for Order #{$orderId}" : "";
            $autoReply = "Revision request noted {$orderMention}! Our QC lead will inspect your notes and any attached screenshots to make sure changes are applied immediately.";
        }

        // Add auto acknowledgment if relevant and last message wasn't already an auto reply
        if ($autoReply) {
            $thread['messages'][] = [
                'id'          => 'msg_m_' . substr(bin2hex(random_bytes(4)), 0, 8),
                'sender'      => 'management',
                'sender_name' => 'Sarah (Production Director)',
                'sender_role' => 'Management',
                'text'        => $autoReply,
                'order_id'    => $orderId ?: null,
                'attachment'  => null,
                'timestamp'   => date('Y-m-d H:i:s', $nowTs + 1),
                'ts'          => $nowTs + 1
            ];
            $thread['unread_client'] = (int)($thread['unread_client'] ?? 0) + 1;
        }

        $chats[$clientId] = $thread;
        self::saveAllChats($chats);

        return $thread;
    }

    public static function postManagementReply(string $clientId, string $agentName, string $agentRole, string $text, ?string $orderId = null, ?array $attachment = null): array {
        $chats = self::getAllChats();
        if (!isset($chats[$clientId])) {
            $thread = self::getClientThread($clientId);
        } else {
            $thread = $chats[$clientId];
        }

        $now = date('Y-m-d H:i:s');
        $nowTs = time();

        $thread['last_active'] = $now;
        $thread['last_active_ts'] = $nowTs;
        $thread['unread_client'] = (int)($thread['unread_client'] ?? 0) + 1;
        $thread['unread_admin'] = 0; // Cleared since management just replied
        $thread['assigned_lead'] = $agentName . ' (' . $agentRole . ')';

        $thread['messages'][] = [
            'id'          => 'msg_m_' . substr(bin2hex(random_bytes(4)), 0, 8),
            'sender'      => 'management',
            'sender_name' => $agentName,
            'sender_role' => $agentRole,
            'text'        => $text,
            'order_id'    => $orderId ?: null,
            'attachment'  => $attachment,
            'timestamp'   => $now,
            'ts'          => $nowTs
        ];

        $chats[$clientId] = $thread;
        self::saveAllChats($chats);

        return $thread;
    }

    public static function getClientOrderSummary(string $clientId): array {
        $allOrders = function_exists('getAllOrders') ? getAllOrders() : [];
        $clientOrders = array_values(array_filter($allOrders, fn($o) => ($o['user_id'] ?? '') === $clientId));

        usort($clientOrders, fn($a, $b) => strtotime($b['created_at'] ?? 'now') <=> strtotime($a['created_at'] ?? 'now'));

        $summary = [
            'total'      => count($clientOrders),
            'processing' => 0,
            'qa'         => 0,
            'delivered'  => 0,
            'pending'    => 0,
            'orders'     => []
        ];

        foreach ($clientOrders as $o) {
            $st = strtolower($o['status'] ?? 'pending');
            $stage = 'processing';

            if (in_array($st, ['delivered', 'completed', 'approved', 'cleared'])) {
                $summary['delivered']++;
                $stage = 'delivered';
                $label = 'Delivered & Cleared';
                $badge = 'bg-emerald-500/15 border-emerald-500/40 text-emerald-400';
            } elseif (in_array($st, ['qa', 'quality_check', 'review', 'ready_for_review', 'under_review'])) {
                $summary['qa']++;
                $stage = 'qa';
                $label = 'In QA Review';
                $badge = 'bg-purple-500/15 border-purple-500/40 text-purple-400';
            } elseif (in_array($st, ['retouching', 'in_retouch', 'editing', 'in_progress', 'assigned', 'processing'])) {
                $summary['processing']++;
                $stage = 'processing';
                $label = 'In Retouching';
                $badge = 'bg-amber-500/15 border-amber-500/40 text-amber-400';
            } else {
                $summary['pending']++;
                $stage = 'pending';
                $label = 'Order Received';
                $badge = 'bg-blue-500/15 border-blue-500/40 text-blue-400';
            }

            $summary['orders'][] = [
                'id'            => $o['id'] ?? '',
                'address'       => $o['property_address'] ?? ($o['address'] ?? ($o['title'] ?? 'Real Estate Property')),
                'status'        => $st,
                'stage'         => $stage,
                'status_label'  => $label,
                'badge_class'   => $badge,
                'photos_count'  => (int)($o['raw_images_count'] ?? ($o['photos_count'] ?? 0)),
                'service'       => $o['service'] ?? 'HDR Retouching',
                'created_at'    => $o['created_at'] ?? date('Y-m-d H:i:s'),
                'is_trial'      => !empty($o['is_trial'])
            ];
        }

        return $summary;
    }

    public static function markReadForClient(string $clientId): void {
        $chats = self::getAllChats();
        if (isset($chats[$clientId])) {
            $chats[$clientId]['unread_client'] = 0;
            self::saveAllChats($chats);
        }
    }

    public static function markReadForAdmin(string $clientId): void {
        $chats = self::getAllChats();
        if (isset($chats[$clientId])) {
            $chats[$clientId]['unread_admin'] = 0;
            self::saveAllChats($chats);
        }
    }

    public static function getTotalAdminUnreadCount(): int {
        $chats = self::getAllChats();
        $count = 0;
        foreach ($chats as $c) {
            $count += (int)($c['unread_admin'] ?? 0);
        }
        return $count;
    }
}
