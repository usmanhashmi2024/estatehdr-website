<?php
declare(strict_types=1);

/**
 * Estate HDR — Email Automation CRM Service Layer
 * Enterprise-grade, self-hosted Email Marketing & Automation CRM Engine.
 * 
 * Manages contacts, tags, campaigns, visual automation workflows, signup forms,
 * open/click tracking, and analytics dashboards with zero third-party dependencies.
 */

namespace EstateHDR\Services;

require_once __DIR__ . '/EmailTemplateLibrary.php';

use Throwable;

class EmailCrmService
{
    private static string $storageDir = '';

    private static function initStorage(): string
    {
        if (empty(self::$storageDir)) {
            $dir = dirname(__DIR__, 2) . '/data/email_crm';
            if (!is_dir($dir)) {
                @mkdir($dir, 0755, true);
            }
            self::$storageDir = $dir;
            self::seedInitialDataIfEmpty();
        }
        return self::$storageDir;
    }

    private static function getFilePath(string $file): string
    {
        return self::initStorage() . '/' . $file;
    }

    private static function readJson(string $filename, array $default = []): array
    {
        $path = self::getFilePath($filename);
        if (!file_exists($path)) {
            return $default;
        }
        $raw = @file_get_contents($path);
        if ($raw === false || trim($raw) === '') {
            return $default;
        }
        $data = json_decode($raw, true);
        return is_array($data) ? $data : $default;
    }

    private static function writeJson(string $filename, array $data): bool
    {
        $path = self::getFilePath($filename);
        $tmp = $path . '.tmp.' . bin2hex(random_bytes(6));
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if ($json === false) {
            return false;
        }
        if (@file_put_contents($tmp, $json, LOCK_EX) === false) {
            return false;
        }
        return @rename($tmp, $path);
    }

    /**
     * Seeds realistic initial data if clean setup to give a rich dashboard out-of-the-box
     */
    private static function seedInitialDataIfEmpty(): void
    {
        $contactsFile = self::$storageDir . '/contacts.json';
        if (!file_exists($contactsFile)) {
            $initialContacts = [
                [
                    'id' => 'CNT-101',
                    'email' => 'ayesha@email.com',
                    'first_name' => 'Ayesha',
                    'last_name' => 'Khan',
                    'phone' => '+1 (555) 234-8901',
                    'company' => 'Ayesha Realty Luxe',
                    'status' => 'subscribed',
                    'tags' => ['customer', 'vip'],
                    'score' => 85,
                    'source' => 'Website Signup',
                    'created_at' => date('Y-m-d H:i:s', strtotime('-18 days')),
                    'updated_at' => date('Y-m-d H:i:s')
                ],
                [
                    'id' => 'CNT-102',
                    'email' => 'bilal@email.com',
                    'first_name' => 'Bilal',
                    'last_name' => 'Ahmed',
                    'phone' => '+44 7700 900123',
                    'company' => 'Prime London Spaces',
                    'status' => 'pending',
                    'tags' => ['lead'],
                    'score' => 40,
                    'source' => 'Lead Magnet Form',
                    'created_at' => date('Y-m-d H:i:s', strtotime('-12 days')),
                    'updated_at' => date('Y-m-d H:i:s')
                ],
                [
                    'id' => 'CNT-103',
                    'email' => 'sara@email.com',
                    'first_name' => 'Sara',
                    'last_name' => 'Malik',
                    'phone' => '+1 (415) 890-1234',
                    'company' => 'Malik Architectural Media',
                    'status' => 'subscribed',
                    'tags' => ['vip', 'customer'],
                    'score' => 95,
                    'source' => 'Direct Order',
                    'created_at' => date('Y-m-d H:i:s', strtotime('-25 days')),
                    'updated_at' => date('Y-m-d H:i:s')
                ],
                [
                    'id' => 'CNT-104',
                    'email' => 'marcus@premierwest.com',
                    'first_name' => 'Marcus',
                    'last_name' => 'Vance',
                    'phone' => '+1 (310) 555-7821',
                    'company' => 'Premier West Realty Media',
                    'status' => 'subscribed',
                    'tags' => ['customer', 'commercial'],
                    'score' => 70,
                    'source' => 'Enterprise Pipeline',
                    'created_at' => date('Y-m-d H:i:s', strtotime('-40 days')),
                    'updated_at' => date('Y-m-d H:i:s')
                ],
                [
                    'id' => 'CNT-105',
                    'email' => 'oliver.wright@londonprime.co.uk',
                    'first_name' => 'Oliver',
                    'last_name' => 'Wright',
                    'phone' => '+44 20 7946 0912',
                    'company' => 'London Prime Architectural',
                    'status' => 'subscribed',
                    'tags' => ['lead', 'uk'],
                    'score' => 60,
                    'source' => 'Website Inquiry',
                    'created_at' => date('Y-m-d H:i:s', strtotime('-5 days')),
                    'updated_at' => date('Y-m-d H:i:s')
                ]
            ];
            @file_put_contents($contactsFile, json_encode($initialContacts, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        }

        $campaignsFile = self::$storageDir . '/campaigns.json';
        if (!file_exists($campaignsFile)) {
            $initialCampaigns = [
                [
                    'id' => 'CMP-101',
                    'name' => 'September Sale — Luxury HDR Editing Pack',
                    'subject' => '🔥 Exclusive 20% Off: Flambient & High-End HDR Photo Retouching',
                    'preview_text' => 'Elevate your real estate listings with 12h turnaround and natural window pulls.',
                    'target_tag' => 'all',
                    'status' => 'sent',
                    'scheduled_at' => null,
                    'sent_at' => date('Y-m-d H:i:s', strtotime('-4 days')),
                    'stats' => [
                        'total' => 3200,
                        'sent' => 3200,
                        'delivered' => 3142,
                        'opens' => 1472,
                        'clicks' => 448,
                        'bounces' => 58,
                        'unsubscribes' => 12
                    ],
                    'content_html' => '<h2>Elevate Your Property Listings with Precision HDR</h2><p>Dear {{first_name}},</p><p>We are delighted to offer an exclusive 20% rate reduction across all standard and twilight HDR processing this season.</p><p><a href="https://estatehdr.com" style="background:#C9A84C;color:#000;padding:12px 24px;text-decoration:none;border-radius:8px;font-weight:bold;">Claim 20% Off Your Next Shoot</a></p>',
                    'created_at' => date('Y-m-d H:i:s', strtotime('-5 days'))
                ],
                [
                    'id' => 'CMP-102',
                    'name' => 'Weekly Architectural Digest & Masterclass',
                    'subject' => '📸 Top 5 Lighting Mistakes Real Estate Photographers Make',
                    'preview_text' => 'Master window pulls, color balance, and flash-ambient fusion effortlessly.',
                    'target_tag' => 'all',
                    'status' => 'scheduled',
                    'scheduled_at' => date('Y-m-d 09:00:00', strtotime('+1 day')),
                    'sent_at' => null,
                    'stats' => [
                        'total' => 4812,
                        'sent' => 0,
                        'delivered' => 0,
                        'opens' => 0,
                        'clicks' => 0,
                        'bounces' => 0,
                        'unsubscribes' => 0
                    ],
                    'content_html' => '<h2>Lighting Masterclass for Real Estate Photographers</h2><p>Hi {{first_name}},</p><p>Here is our latest weekly breakdown on balancing warm ambient lamps with cool daylight windows.</p>',
                    'created_at' => date('Y-m-d H:i:s', strtotime('-2 days'))
                ],
                [
                    'id' => 'CMP-103',
                    'name' => 'Free Trial Follow-up & Cart Recovery',
                    'subject' => 'Your 3 Free HDR Sample Photos are Waiting!',
                    'preview_text' => 'Send us any bracket set and receive published MLS-ready photos in 12 hours.',
                    'target_tag' => 'lead',
                    'status' => 'draft',
                    'scheduled_at' => null,
                    'sent_at' => null,
                    'stats' => [
                        'total' => 0,
                        'sent' => 0,
                        'delivered' => 0,
                        'opens' => 0,
                        'clicks' => 0,
                        'bounces' => 0,
                        'unsubscribes' => 0
                    ],
                    'content_html' => '<h2>Have you submitted your sample bracket yet?</h2><p>Hey {{first_name}}, our senior retouchers are on standby to process 3 free test images for your studio.</p>',
                    'created_at' => date('Y-m-d H:i:s', strtotime('-1 day'))
                ]
            ];
            @file_put_contents($campaignsFile, json_encode($initialCampaigns, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        }

        $automationsFile = self::$storageDir . '/automations.json';
        if (!file_exists($automationsFile)) {
            $initialAutomations = [
                [
                    'id' => 'AUTO-101',
                    'name' => 'Welcome Series & Studio Onboarding',
                    'status' => 'active',
                    'trigger_type' => 'new_signup',
                    'trigger_config' => ['tag' => ''],
                    'steps' => [
                        [
                            'id' => 'step_1',
                            'type' => 'send_email',
                            'title' => 'Send "Welcome to Estate HDR!"',
                            'config' => [
                                'subject' => 'Welcome to Estate HDR — Here are your next steps',
                                'body' => '<p>Hi {{first_name}},</p><p>Welcome to Estate HDR! We are excited to help you scale your real estate photography business with consistent, luxury hand-blended editing.</p>'
                            ]
                        ],
                        [
                            'id' => 'step_2',
                            'type' => 'wait',
                            'title' => 'Wait 2 Days',
                            'config' => ['duration_hours' => 48]
                        ],
                        [
                            'id' => 'step_3',
                            'type' => 'send_email',
                            'title' => 'Send "Getting Started Guide"',
                            'config' => [
                                'subject' => 'How to prepare and upload your bracket sets for best results',
                                'body' => '<p>Hello {{first_name}},</p><p>Here is our quick 3-step checklist for shooting brackets that give crystal-clear window views every time.</p>'
                            ]
                        ],
                        [
                            'id' => 'step_4',
                            'type' => 'add_tag',
                            'title' => 'Add Tag "onboarded"',
                            'config' => ['tag' => 'onboarded']
                        ]
                    ],
                    'enrollments_count' => 124,
                    'created_at' => date('Y-m-d H:i:s', strtotime('-30 days'))
                ],
                [
                    'id' => 'AUTO-102',
                    'name' => 'Lead Magnet Nurture Sequence',
                    'status' => 'active',
                    'trigger_type' => 'form_submit',
                    'trigger_config' => ['form_id' => 'FORM-101'],
                    'steps' => [
                        [
                            'id' => 'step_1',
                            'type' => 'send_email',
                            'title' => 'Instant Guide Delivery',
                            'config' => [
                                'subject' => 'Your Free Real Estate Photography Pricing Guide (PDF)',
                                'body' => '<p>Thank you for downloading our 2026 Real Estate Photography Pricing Guide. Check out the link below to view it instantly.</p>'
                            ]
                        ],
                        [
                            'id' => 'step_2',
                            'type' => 'wait',
                            'title' => 'Wait 1 Day',
                            'config' => ['duration_hours' => 24]
                        ],
                        [
                            'id' => 'step_3',
                            'type' => 'send_email',
                            'title' => 'Offer Free Trial Edit',
                            'config' => [
                                'subject' => 'Would you like us to edit 3 photos for free as a comparison?',
                                'body' => '<p>Hi {{first_name}}, compare your current editing speed with our 12-hour turnaround time completely free.</p>'
                            ]
                        ]
                    ],
                    'enrollments_count' => 88,
                    'created_at' => date('Y-m-d H:i:s', strtotime('-15 days'))
                ]
            ];
            @file_put_contents($automationsFile, json_encode($initialAutomations, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        }

        $formsFile = self::$storageDir . '/forms.json';
        if (!file_exists($formsFile)) {
            $initialForms = [
                [
                    'id' => 'FORM-101',
                    'name' => 'Website Header Lead Magnet Form',
                    'target_tag' => 'lead',
                    'redirect_url' => '/thank-you',
                    'submits_count' => 142,
                    'created_at' => date('Y-m-d H:i:s', strtotime('-60 days'))
                ],
                [
                    'id' => 'FORM-102',
                    'name' => 'Free Trial Registration Form',
                    'target_tag' => 'trial_requested',
                    'redirect_url' => '/order-new.php',
                    'submits_count' => 89,
                    'created_at' => date('Y-m-d H:i:s', strtotime('-30 days'))
                ]
            ];
            @file_put_contents($formsFile, json_encode($initialForms, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        }

        $settingsFile = self::$storageDir . '/settings.json';
        if (!file_exists($settingsFile)) {
            $initialSettings = [
                'from_name' => defined('SMTP_FROM_NAME') ? SMTP_FROM_NAME : 'Estate HDR',
                'from_email' => defined('SMTP_FROM_EMAIL') ? SMTP_FROM_EMAIL : 'info@estatehdr.com',
                'reply_to' => 'info@estatehdr.com',
                'delivery_mode' => 'smtp', // smtp | mail | simulate
                'track_opens' => true,
                'track_clicks' => true,
                'daily_limit' => 2000,
                'updated_at' => date('Y-m-d H:i:s')
            ];
            @file_put_contents($settingsFile, json_encode($initialSettings, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        }

        $eventsFile = self::$storageDir . '/events.json';
        if (!file_exists($eventsFile)) {
            $initialEvents = [
                [
                    'id' => 'EVT-01',
                    'type' => 'open',
                    'contact_id' => 'CNT-101',
                    'campaign_id' => 'CMP-101',
                    'meta' => ['user_agent' => 'Mozilla/5.0 (iPhone; CPU iPhone OS)', 'ip' => '172.56.21.9'],
                    'created_at' => date('Y-m-d H:i:s', strtotime('-2 hours'))
                ],
                [
                    'id' => 'EVT-02',
                    'type' => 'click',
                    'contact_id' => 'CNT-101',
                    'campaign_id' => 'CMP-101',
                    'meta' => ['url' => 'https://estatehdr.com', 'ip' => '172.56.21.9'],
                    'created_at' => date('Y-m-d H:i:s', strtotime('-1 hour 50 min'))
                ],
                [
                    'id' => 'EVT-03',
                    'type' => 'open',
                    'contact_id' => 'CNT-103',
                    'campaign_id' => 'CMP-101',
                    'meta' => ['user_agent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X)', 'ip' => '68.105.12.44'],
                    'created_at' => date('Y-m-d H:i:s', strtotime('-3 hours'))
                ],
                [
                    'id' => 'EVT-04',
                    'type' => 'form_submit',
                    'contact_id' => 'CNT-105',
                    'campaign_id' => null,
                    'meta' => ['form_id' => 'FORM-101'],
                    'created_at' => date('Y-m-d H:i:s', strtotime('-5 days'))
                ]
            ];
            @file_put_contents($eventsFile, json_encode($initialEvents, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CONTACTS API
    // ─────────────────────────────────────────────────────────────────────────

    public static function getDuplicateEmailCount(): int
    {
        $contacts = self::readJson('contacts.json');
        $counts = [];
        foreach ($contacts as $c) {
            $email = strtolower(trim($c['email'] ?? ''));
            if (!empty($email)) {
                $counts[$email] = ($counts[$email] ?? 0) + 1;
            }
        }
        $dupes = 0;
        foreach ($counts as $cnt) {
            if ($cnt > 1) {
                $dupes += ($cnt - 1);
            }
        }
        return $dupes;
    }

    public static function deduplicateContacts(): array
    {
        $contacts = self::readJson('contacts.json');
        $unique = [];
        $duplicatesRemoved = 0;

        foreach ($contacts as $c) {
            $email = strtolower(trim($c['email'] ?? ''));
            if (empty($email)) {
                continue;
            }
            if (!isset($unique[$email])) {
                $unique[$email] = $c;
            } else {
                // Merge tags and details into the primary record
                $existing = $unique[$email];
                $mergedTags = array_values(array_unique(array_merge($existing['tags'] ?? [], $c['tags'] ?? [])));
                $existing['tags'] = $mergedTags;
                if (empty($existing['phone']) && !empty($c['phone'])) {
                    $existing['phone'] = $c['phone'];
                }
                if (empty($existing['company']) && !empty($c['company'])) {
                    $existing['company'] = $c['company'];
                }
                $existing['score'] = max((int)($existing['score'] ?? 50), (int)($c['score'] ?? 50));
                $unique[$email] = $existing;
                $duplicatesRemoved++;
            }
        }

        $cleaned = array_values($unique);
        self::writeJson('contacts.json', $cleaned);

        return [
            'original_count' => count($contacts),
            'unique_count' => count($cleaned),
            'duplicates_removed' => $duplicatesRemoved
        ];
    }

    public static function getContacts(string $search = '', string $tagFilter = '', string $statusFilter = '', string $sortBy = 'newest', string $verifyFilter = ''): array
    {
        $contacts = self::readJson('contacts.json');
        
        // If filtering for duplicates
        $duplicateEmails = [];
        if ($statusFilter === 'duplicates') {
            $emailFreq = [];
            foreach ($contacts as $c) {
                $em = strtolower(trim($c['email'] ?? ''));
                if (!empty($em)) {
                    $emailFreq[$em] = ($emailFreq[$em] ?? 0) + 1;
                }
            }
            foreach ($emailFreq as $em => $freq) {
                if ($freq > 1) {
                    $duplicateEmails[$em] = true;
                }
            }
        }

        if (!empty($search) || !empty($tagFilter) || !empty($statusFilter) || !empty($verifyFilter)) {
            $search = strtolower(trim($search));
            $tagFilter = strtolower(trim($tagFilter));
            $statusFilter = strtolower(trim($statusFilter));
            $verifyFilter = strtolower(trim($verifyFilter));

            $contacts = array_filter($contacts, function ($c) use ($search, $tagFilter, $statusFilter, $duplicateEmails, $verifyFilter) {
                if ($statusFilter === 'duplicates') {
                    $em = strtolower(trim($c['email'] ?? ''));
                    if (!isset($duplicateEmails[$em])) {
                        return false;
                    }
                } elseif (str_starts_with($statusFilter, 'v_')) {
                    $targetV = substr($statusFilter, 2);
                    $cVer = strtolower($c['verification_status'] ?? 'unverified');
                    if ($targetV === 'risky') {
                        $parsed = \EstateHDR\Services\EmailVerifierService::parseEmail($c['email'] ?? '');
                        $isRole = $parsed && \EstateHDR\Services\EmailVerifierService::isRoleBased($parsed['local']);
                        $isDisp = $parsed && \EstateHDR\Services\EmailVerifierService::isDisposable($parsed['domain']);
                        $typo = $parsed ? \EstateHDR\Services\EmailVerifierService::checkTypo($parsed['domain']) : ['detected' => false];
                        $hasTypo = !empty($typo['detected']);
                        $detailRole = !empty($c['verification_details']['role_based']);
                        $detailCatch = !empty($c['verification_details']['catch_all']);
                        $isRisky = ($cVer === 'risky' || $cVer === 'catch_all' || $cVer === 'unknown' || $cVer === 'role_based' || $isRole || $isDisp || $hasTypo || $detailRole || $detailCatch);
                        if (!$isRisky) {
                            return false;
                        }
                    } elseif ($targetV === 'invalid') {
                        $statusAttr = strtolower($c['status'] ?? '');
                        if ($cVer !== 'invalid' && $cVer !== 'bounced' && $statusAttr !== 'bounced') {
                            return false;
                        }
                    } elseif ($targetV === 'valid') {
                        if ($cVer !== 'valid') {
                            return false;
                        }
                    } elseif ($cVer !== $targetV) {
                        return false;
                    }
                } elseif (!empty($statusFilter) && strtolower($c['status'] ?? '') !== $statusFilter) {
                    return false;
                }

                if (!empty($verifyFilter)) {
                    $cVer = strtolower($c['verification_status'] ?? 'unverified');
                    if ($verifyFilter === 'risky') {
                        $parsed = \EstateHDR\Services\EmailVerifierService::parseEmail($c['email'] ?? '');
                        $isRole = $parsed && \EstateHDR\Services\EmailVerifierService::isRoleBased($parsed['local']);
                        $isDisp = $parsed && \EstateHDR\Services\EmailVerifierService::isDisposable($parsed['domain']);
                        $typo = $parsed ? \EstateHDR\Services\EmailVerifierService::checkTypo($parsed['domain']) : ['detected' => false];
                        $hasTypo = !empty($typo['detected']);
                        $detailRole = !empty($c['verification_details']['role_based']);
                        $detailCatch = !empty($c['verification_details']['catch_all']);
                        $isRisky = ($cVer === 'risky' || $cVer === 'catch_all' || $cVer === 'unknown' || $cVer === 'role_based' || $isRole || $isDisp || $hasTypo || $detailRole || $detailCatch);
                        if (!$isRisky) {
                            return false;
                        }
                    } elseif ($cVer !== $verifyFilter) {
                        return false;
                    }
                }

                if (!empty($tagFilter)) {
                    $tags = array_map('strtolower', $c['tags'] ?? []);
                    if (!in_array($tagFilter, $tags, true)) {
                        return false;
                    }
                }

                if (!empty($search)) {
                    $haystack = strtolower(
                        ($c['first_name'] ?? '') . ' ' .
                        ($c['last_name'] ?? '') . ' ' .
                        ($c['email'] ?? '') . ' ' .
                        ($c['company'] ?? '') . ' ' .
                        ($c['phone'] ?? '')
                    );
                    if (strpos($haystack, $search) === false) {
                        return false;
                    }
                }
                return true;
            });
        }

        // Apply Sorting
        usort($contacts, function ($a, $b) use ($sortBy) {
            switch ($sortBy) {
                case 'oldest':
                    return strcmp($a['created_at'] ?? '', $b['created_at'] ?? '');
                case 'name_asc':
                    $nameA = trim(($a['first_name'] ?? '') . ' ' . ($a['last_name'] ?? ''));
                    $nameB = trim(($b['first_name'] ?? '') . ' ' . ($b['last_name'] ?? ''));
                    return strcasecmp($nameA, $nameB);
                case 'name_desc':
                    $nameA = trim(($a['first_name'] ?? '') . ' ' . ($a['last_name'] ?? ''));
                    $nameB = trim(($b['first_name'] ?? '') . ' ' . ($b['last_name'] ?? ''));
                    return strcasecmp($nameB, $nameA);
                case 'email_asc':
                    return strcasecmp($a['email'] ?? '', $b['email'] ?? '');
                case 'company_asc':
                    return strcasecmp($a['company'] ?? '', $b['company'] ?? '');
                case 'score_desc':
                    return ((int)($b['score'] ?? 0)) <=> ((int)($a['score'] ?? 0));
                case 'score_asc':
                    return ((int)($a['score'] ?? 0)) <=> ((int)($b['score'] ?? 0));
                case 'newest':
                default:
                    return strcmp($b['created_at'] ?? '', $a['created_at'] ?? '');
            }
        });

        return array_values($contacts);
    }

    public static function getContactById(string $id): ?array
    {
        $contacts = self::readJson('contacts.json');
        foreach ($contacts as $c) {
            if ($c['id'] === $id) {
                return $c;
            }
        }
        return null;
    }

    public static function getContactByEmail(string $email): ?array
    {
        $contacts = self::readJson('contacts.json');
        $email = strtolower(trim($email));
        foreach ($contacts as $c) {
            if (strtolower(trim($c['email'] ?? '')) === $email) {
                return $c;
            }
        }
        return null;
    }

    public static function saveContact(array $data): array
    {
        $contacts = self::readJson('contacts.json');
        $email = strtolower(trim($data['email'] ?? ''));
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new \InvalidArgumentException('Valid email address is required.');
        }

        $id = $data['id'] ?? '';
        $existingIndex = -1;

        foreach ($contacts as $idx => $c) {
            if (!empty($id) && $c['id'] === $id) {
                $existingIndex = $idx;
                break;
            }
            if (empty($id) && strtolower($c['email'] ?? '') === $email) {
                $existingIndex = $idx;
                break;
            }
        }

        $now = date('Y-m-d H:i:s');
        $tags = [];
        if (isset($data['tags'])) {
            if (is_array($data['tags'])) {
                $tags = array_values(array_unique(array_filter(array_map('trim', $data['tags']))));
            } elseif (is_string($data['tags'])) {
                $tags = array_values(array_unique(array_filter(array_map('trim', explode(',', $data['tags'])))));
            }
        }

        if ($existingIndex >= 0) {
            // Update
            $existing = $contacts[$existingIndex];
            $mergedTags = !empty($tags) ? array_values(array_unique(array_merge($existing['tags'] ?? [], $tags))) : ($existing['tags'] ?? []);
            
            $contacts[$existingIndex] = [
                'id' => $existing['id'],
                'email' => $email,
                'first_name' => trim($data['first_name'] ?? ($existing['first_name'] ?? '')),
                'last_name' => trim($data['last_name'] ?? ($existing['last_name'] ?? '')),
                'phone' => trim($data['phone'] ?? ($existing['phone'] ?? '')),
                'company' => trim($data['company'] ?? ($existing['company'] ?? '')),
                'status' => in_array($data['status'] ?? '', ['subscribed', 'pending', 'unsubscribed', 'bounced'], true) ? $data['status'] : ($existing['status'] ?? 'subscribed'),
                'tags' => $mergedTags,
                'score' => isset($data['score']) ? (int)$data['score'] : ($existing['score'] ?? 50),
                'source' => $data['source'] ?? ($existing['source'] ?? 'Direct Entry'),
                'verification_status' => $data['verification_status'] ?? ($existing['verification_status'] ?? 'unverified'),
                'verification_score' => isset($data['verification_score']) ? (int)$data['verification_score'] : ($existing['verification_score'] ?? null),
                'verified_at' => $data['verified_at'] ?? ($existing['verified_at'] ?? null),
                'created_at' => $existing['created_at'],
                'updated_at' => $now
            ];
            self::writeJson('contacts.json', $contacts);
            return $contacts[$existingIndex];
        } else {
            // Create
            $newContact = [
                'id' => 'CNT-' . (count($contacts) + 101) . '-' . substr(bin2hex(random_bytes(3)), 0, 4),
                'email' => $email,
                'first_name' => trim($data['first_name'] ?? ''),
                'last_name' => trim($data['last_name'] ?? ''),
                'phone' => trim($data['phone'] ?? ''),
                'company' => trim($data['company'] ?? ''),
                'status' => in_array($data['status'] ?? '', ['subscribed', 'pending', 'unsubscribed', 'bounced'], true) ? $data['status'] : 'subscribed',
                'tags' => $tags,
                'score' => isset($data['score']) ? (int)$data['score'] : 50,
                'source' => $data['source'] ?? 'Manual Admin',
                'verification_status' => $data['verification_status'] ?? 'unverified',
                'verification_score' => isset($data['verification_score']) ? (int)$data['verification_score'] : null,
                'verified_at' => $data['verified_at'] ?? null,
                'created_at' => $now,
                'updated_at' => $now
            ];
            $contacts[] = $newContact;
            self::writeJson('contacts.json', $contacts);

            // Auto-enroll in new_signup automations
            self::triggerAutomationEvent('new_signup', $newContact);

            return $newContact;
        }
    }

    public static function deleteContact(string $id): bool
    {
        $contacts = self::readJson('contacts.json');
        $filtered = array_filter($contacts, fn($c) => ($c['id'] ?? '') !== $id);
        if (count($filtered) !== count($contacts)) {
            return self::writeJson('contacts.json', array_values($filtered));
        }
        return false;
    }

    /**
     * Delete multiple contacts by IDs in a single operation
     */
    public static function deleteContactsByIds(array $ids): int
    {
        if (empty($ids)) return 0;
        $contacts = self::readJson('contacts.json');
        $idMap = array_flip($ids);
        $filtered = array_filter($contacts, fn($c) => !isset($idMap[$c['id'] ?? '']));
        $removed = count($contacts) - count($filtered);
        if ($removed > 0) {
            self::writeJson('contacts.json', array_values($filtered));
        }
        return $removed;
    }

    /**
     * Purges contacts based on deliverability verification status (invalid, risky, unhealthy)
     */
    public static function purgeVerifiedContacts(string $target = 'invalid', array $specificIds = []): array
    {
        return \EstateHDR\Services\EmailVerifierService::purgeContacts($target, $specificIds);
    }

    public static function importContactsCsv(string $csvContent, array $defaultTags = []): array
    {
        $lines = preg_split('/\r\n|\r|\n/', trim($csvContent));
        if (empty($lines)) {
            return ['imported' => 0, 'skipped' => 0, 'errors' => ['CSV is empty']];
        }

        $header = str_getcsv(array_shift($lines));
        $headerMap = [];
        foreach ($header as $colIdx => $colName) {
            $colKey = strtolower(trim(preg_replace('/[^a-zA-Z0-9_]/', '', $colName)));
            if (in_array($colKey, ['email', 'e_mail', 'mail'])) $headerMap['email'] = $colIdx;
            elseif (in_array($colKey, ['first_name', 'firstname', 'fname', 'first'])) $headerMap['first_name'] = $colIdx;
            elseif (in_array($colKey, ['last_name', 'lastname', 'lname', 'last'])) $headerMap['last_name'] = $colIdx;
            elseif (in_array($colKey, ['name', 'fullname', 'full_name'])) $headerMap['full_name'] = $colIdx;
            elseif (in_array($colKey, ['phone', 'telephone', 'mobile', 'cell'])) $headerMap['phone'] = $colIdx;
            elseif (in_array($colKey, ['company', 'organization', 'agency', 'business'])) $headerMap['company'] = $colIdx;
            elseif (in_array($colKey, ['tags', 'tag'])) $headerMap['tags'] = $colIdx;
        }

        if (!isset($headerMap['email'])) {
            return ['imported' => 0, 'skipped' => 0, 'errors' => ['No Email column detected in CSV header.']];
        }

        $imported = 0;
        $skipped = 0;
        $errors = [];

        foreach ($lines as $lineIndex => $line) {
            if (trim($line) === '') continue;
            $row = str_getcsv($line);
            $email = trim($row[$headerMap['email']] ?? '');
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $skipped++;
                continue;
            }

            $firstName = '';
            $lastName = '';
            if (isset($headerMap['first_name'])) {
                $firstName = trim($row[$headerMap['first_name']] ?? '');
                $lastName = trim($row[$headerMap['last_name'] ?? 999] ?? '');
            } elseif (isset($headerMap['full_name'])) {
                $parts = explode(' ', trim($row[$headerMap['full_name']] ?? ''), 2);
                $firstName = $parts[0] ?? '';
                $lastName = $parts[1] ?? '';
            }

            $phone = isset($headerMap['phone']) ? trim($row[$headerMap['phone']] ?? '') : '';
            $company = isset($headerMap['company']) ? trim($row[$headerMap['company']] ?? '') : '';
            
            $rowTags = $defaultTags;
            if (isset($headerMap['tags'])) {
                $extraTags = explode(',', trim($row[$headerMap['tags']] ?? ''));
                $rowTags = array_merge($rowTags, array_filter(array_map('trim', $extraTags)));
            }

            try {
                self::saveContact([
                    'email' => $email,
                    'first_name' => $firstName,
                    'last_name' => $lastName,
                    'phone' => $phone,
                    'company' => $company,
                    'tags' => $rowTags,
                    'source' => 'CSV Import',
                    'status' => 'subscribed'
                ]);
                $imported++;
            } catch (Throwable $e) {
                $errors[] = "Row " . ($lineIndex + 2) . ": " . $e->getMessage();
                $skipped++;
            }
        }

        return ['imported' => $imported, 'skipped' => $skipped, 'errors' => $errors];
    }

    public static function exportContactsCsv(string $tagFilter = '', string $statusFilter = ''): string
    {
        $contacts = self::getContacts('', $tagFilter, $statusFilter);
        $output = fopen('php://temp', 'r+');
        fputcsv($output, ['ID', 'Email', 'First Name', 'Last Name', 'Phone', 'Company', 'Tags', 'Status', 'Score', 'Source', 'Created At']);

        foreach ($contacts as $c) {
            fputcsv($output, [
                $c['id'] ?? '',
                $c['email'] ?? '',
                $c['first_name'] ?? '',
                $c['last_name'] ?? '',
                $c['phone'] ?? '',
                $c['company'] ?? '',
                implode(', ', $c['tags'] ?? []),
                $c['status'] ?? '',
                $c['score'] ?? '',
                $c['source'] ?? '',
                $c['created_at'] ?? ''
            ]);
        }

        rewind($output);
        $csv = stream_get_contents($output);
        fclose($output);
        return $csv ?: '';
    }

    public static function getAllTags(): array
    {
        $contacts = self::readJson('contacts.json');
        $tags = [];
        foreach ($contacts as $c) {
            foreach ($c['tags'] ?? [] as $t) {
                $t = trim($t);
                if (!empty($t)) {
                    $tags[$t] = ($tags[$t] ?? 0) + 1;
                }
            }
        }
        arsort($tags);
        return $tags;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CAMPAIGNS API
    // ─────────────────────────────────────────────────────────────────────────

    public static function getCampaigns(string $statusFilter = ''): array
    {
        $campaigns = self::readJson('campaigns.json');
        if (!empty($statusFilter)) {
            $campaigns = array_filter($campaigns, fn($c) => ($c['status'] ?? '') === $statusFilter);
        }
        usort($campaigns, function ($a, $b) {
            return strcmp($b['created_at'] ?? '', $a['created_at'] ?? '');
        });
        return array_values($campaigns);
    }

    public static function getCampaignById(string $id): ?array
    {
        $campaigns = self::readJson('campaigns.json');
        foreach ($campaigns as $c) {
            if ($c['id'] === $id) {
                return $c;
            }
        }
        return null;
    }

    public static function saveCampaign(array $data): array
    {
        $campaigns = self::readJson('campaigns.json');
        $id = $data['id'] ?? '';
        $existingIndex = -1;

        if (!empty($id)) {
            foreach ($campaigns as $idx => $c) {
                if ($c['id'] === $id) {
                    $existingIndex = $idx;
                    break;
                }
            }
        }

        $now = date('Y-m-d H:i:s');
        if ($existingIndex >= 0) {
            $existing = $campaigns[$existingIndex];
            $campaigns[$existingIndex] = [
                'id' => $existing['id'],
                'name' => trim($data['name'] ?? ($existing['name'] ?? 'Untitled Campaign')),
                'subject' => trim($data['subject'] ?? ($existing['subject'] ?? '')),
                'preview_text' => trim($data['preview_text'] ?? ($existing['preview_text'] ?? '')),
                'target_tag' => trim($data['target_tag'] ?? ($existing['target_tag'] ?? 'all')),
                'status' => in_array($data['status'] ?? '', ['draft', 'scheduled', 'sending', 'sent', 'chained'], true) ? $data['status'] : ($existing['status'] ?? 'draft'),
                'scheduled_at' => $data['scheduled_at'] ?? ($existing['scheduled_at'] ?? null),
                'sent_at' => $existing['sent_at'] ?? null,
                'chained_parent_id' => trim($data['chained_parent_id'] ?? ($existing['chained_parent_id'] ?? '')),
                'chained_delay_hours' => (int)($data['chained_delay_hours'] ?? ($existing['chained_delay_hours'] ?? 0)),
                'allow_parallel' => isset($data['allow_parallel']) ? !empty($data['allow_parallel']) : ($existing['allow_parallel'] ?? true),
                'stats' => $existing['stats'] ?? [
                    'total' => 0, 'sent' => 0, 'delivered' => 0, 'opens' => 0, 'clicks' => 0, 'bounces' => 0, 'unsubscribes' => 0
                ],
                'content_html' => $data['content_html'] ?? ($existing['content_html'] ?? ''),
                'created_at' => $existing['created_at'],
                'updated_at' => $now
            ];
            self::writeJson('campaigns.json', $campaigns);
            return $campaigns[$existingIndex];
        } else {
            $newCampaign = [
                'id' => 'CMP-' . (count($campaigns) + 101) . '-' . substr(bin2hex(random_bytes(3)), 0, 4),
                'name' => trim($data['name'] ?? 'New Campaign'),
                'subject' => trim($data['subject'] ?? 'Announcement from Estate HDR'),
                'preview_text' => trim($data['preview_text'] ?? ''),
                'target_tag' => trim($data['target_tag'] ?? 'all'),
                'status' => in_array($data['status'] ?? '', ['draft', 'scheduled', 'sending', 'sent', 'chained'], true) ? $data['status'] : 'draft',
                'scheduled_at' => $data['scheduled_at'] ?? null,
                'sent_at' => null,
                'chained_parent_id' => trim($data['chained_parent_id'] ?? ''),
                'chained_delay_hours' => (int)($data['chained_delay_hours'] ?? 0),
                'allow_parallel' => isset($data['allow_parallel']) ? !empty($data['allow_parallel']) : true,
                'stats' => [
                    'total' => 0, 'sent' => 0, 'delivered' => 0, 'opens' => 0, 'clicks' => 0, 'bounces' => 0, 'unsubscribes' => 0
                ],
                'content_html' => $data['content_html'] ?? '<p>Hello {{first_name}},</p><p>We have exciting news to share with your photography studio.</p>',
                'created_at' => $now,
                'updated_at' => $now
            ];
            $campaigns[] = $newCampaign;
            self::writeJson('campaigns.json', $campaigns);
            return $newCampaign;
        }
    }

    public static function deleteCampaign(string $id): bool
    {
        $campaigns = self::readJson('campaigns.json');
        $filtered = array_filter($campaigns, fn($c) => ($c['id'] ?? '') !== $id);
        if (count($filtered) !== count($campaigns)) {
            return self::writeJson('campaigns.json', array_values($filtered));
        }
        return false;
    }

    /**
     * Sends campaign to target audience (or single test email)
     */
    public static function sendCampaignNow(string $campaignId, string $testRecipient = ''): array
    {
        $campaign = self::getCampaignById($campaignId);
        if (!$campaign) {
            return ['success' => false, 'error' => 'Campaign not found'];
        }

        $settings = self::getSettings();
        $isTest = !empty($testRecipient);

        if ($isTest) {
            $recipients = [[
                'id' => 'TEST-001',
                'email' => $testRecipient,
                'first_name' => 'Studio Partner',
                'last_name' => '(Test)',
                'company' => 'Sample Agency'
            ]];
        } else {
            $targetTag = $campaign['target_tag'] ?? 'all';
            $allContacts = self::getContacts('', ($targetTag === 'all' ? '' : $targetTag), 'subscribed');
            $recipients = $allContacts;
        }

        if (empty($recipients)) {
            return ['success' => false, 'error' => 'No subscribed contacts match target audience (' . ($campaign['target_tag'] ?? 'all') . ')'];
        }

        $sentCount = 0;
        $failedCount = 0;
        $baseUrl = defined('BASE_URL') ? BASE_URL : 'https://estatehdr.com';

        require_once dirname(__DIR__) . '/mail.php';

        foreach ($recipients as $recipient) {
            $body = self::renderPersonalizedHtml(
                $campaign['content_html'],
                $recipient,
                $campaign['id'],
                $baseUrl,
                $settings['track_opens'] ?? true,
                $settings['track_clicks'] ?? true
            );

            $subject = str_replace(
                ['{{first_name}}', '{{company}}'],
                [$recipient['first_name'] ?? 'Friend', $recipient['company'] ?? 'Studio'],
                $campaign['subject']
            );

            $fromName = $settings['from_name'] ?? 'Estate HDR';
            $fromEmail = $settings['from_email'] ?? 'info@estatehdr.com';
            $replyTo = $settings['reply_to'] ?? $fromEmail;

            // Dispatch
            if (($settings['delivery_mode'] ?? 'smtp') === 'simulate') {
                $res = ['success' => true];
            } else {
                if (function_exists('sendSmtpMail')) {
                    $res = sendSmtpMail($recipient['email'], $subject, $body, $fromEmail, $fromName, $replyTo);
                } else {
                    $headers = "MIME-Version: 1.0\r\nContent-type: text/html; charset=UTF-8\r\nFrom: {$fromName} <{$fromEmail}>\r\n";
                    $ok = @mail($recipient['email'], $subject, $body, $headers);
                    $res = ['success' => $ok];
                }
            }

            if (!empty($res['success'])) {
                $sentCount++;
            } else {
                $failedCount++;
            }
        }

        if (!$isTest) {
            // Update campaign stats and trigger any chained campaigns
            $campaigns = self::readJson('campaigns.json');
            foreach ($campaigns as &$c) {
                if ($c['id'] === $campaignId) {
                    $c['status'] = 'sent';
                    $c['sent_at'] = date('Y-m-d H:i:s');
                    $c['stats']['total'] = count($recipients);
                    $c['stats']['sent'] = $sentCount;
                    $c['stats']['delivered'] = $sentCount;
                    $c['stats']['bounces'] = $failedCount;
                    break;
                }
            }

            // Check for dependent / chained campaigns
            foreach ($campaigns as &$child) {
                if (($child['chained_parent_id'] ?? '') === $campaignId && in_array($child['status'] ?? '', ['draft', 'scheduled', 'chained'], true)) {
                    $delayHours = (int)($child['chained_delay_hours'] ?? 0);
                    if ($delayHours <= 0) {
                        $child['status'] = 'scheduled';
                        $child['scheduled_at'] = date('Y-m-d H:i:s');
                    } else {
                        $child['status'] = 'scheduled';
                        $child['scheduled_at'] = date('Y-m-d H:i:s', time() + ($delayHours * 3600));
                    }
                }
            }
            self::writeJson('campaigns.json', $campaigns);
        }

        return [
            'success' => true,
            'sent' => $sentCount,
            'failed' => $failedCount,
            'is_test' => $isTest
        ];
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PERSONALIZATION & TRACKING INJECTION
    // ─────────────────────────────────────────────────────────────────────────

    private static function renderPersonalizedHtml(
        string $html,
        array $contact,
        string $campaignId,
        string $baseUrl,
        bool $trackOpens = true,
        bool $trackClicks = true
    ): string {
        $contactId = $contact['id'] ?? 'CNT-000';
        $firstName = htmlspecialchars($contact['first_name'] ?? 'Friend');
        $lastName = htmlspecialchars($contact['last_name'] ?? '');
        $company = htmlspecialchars($contact['company'] ?? 'Your Studio');
        $email = htmlspecialchars($contact['email'] ?? '');

        // Unsubscribe link
        $unsubUrl = rtrim($baseUrl, '/') . "/unsubscribe.php?c=" . urlencode($campaignId) . "&u=" . urlencode($contactId) . "&t=" . md5($email . 'ehdr_salt_2026');

        $replacements = [
            '{{first_name}}' => $firstName,
            '{{last_name}}' => $lastName,
            '{{name}}' => trim($firstName . ' ' . $lastName) ?: 'Valued Client',
            '{{email}}' => $email,
            '{{company}}' => $company,
            '{{unsubscribe_link}}' => $unsubUrl,
            '{{year}}' => date('Y')
        ];

        $rendered = str_replace(array_keys($replacements), array_values($replacements), $html);

        // Click tracking wrapper
        if ($trackClicks) {
            $rendered = preg_replace_callback('/<a\s+(?:[^>]*?\s+)?href=(["\'])(https?:\/\/[^"\']+)\1/i', function ($matches) use ($baseUrl, $campaignId, $contactId, $unsubUrl) {
                $targetUrl = $matches[2];
                // Do not wrap unsubscribe link
                if (strpos($targetUrl, 'unsubscribe.php') !== false) {
                    return $matches[0];
                }
                $wrapped = rtrim($baseUrl, '/') . "/api/crm-track.php?t=click&c=" . urlencode($campaignId) . "&u=" . urlencode($contactId) . "&url=" . urlencode($targetUrl);
                return str_replace($targetUrl, $wrapped, $matches[0]);
            }, $rendered);
        }

        // Open tracking pixel
        if ($trackOpens) {
            $pixelUrl = rtrim($baseUrl, '/') . "/api/crm-track.php?t=open&c=" . urlencode($campaignId) . "&u=" . urlencode($contactId);
            $pixelTag = '<img src="' . htmlspecialchars($pixelUrl) . '" width="1" height="1" style="display:none !important; max-height:0; max-width:0; overflow:hidden;" alt="" />';
            if (strpos($rendered, '</body>') !== false) {
                $rendered = str_replace('</body>', $pixelTag . '</body>', $rendered);
            } else {
                $rendered .= $pixelTag;
            }
        }

        // Unsubscribe footer if not present
        if (strpos($rendered, 'unsubscribe') === false) {
            $rendered .= '<div style="margin-top:40px;padding-top:20px;border-top:1px solid #333;font-size:11px;color:#888;text-align:center;">
                <p>You received this email because you are a registered client or subscriber of Estate HDR.</p>
                <p><a href="' . htmlspecialchars($unsubUrl) . '" style="color:#C9A84C;text-decoration:underline;">Unsubscribe from marketing emails</a> | <a href="' . htmlspecialchars($baseUrl) . '" style="color:#888;">estatehdr.com</a></p>
            </div>';
        }

        return $rendered;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AUTOMATIONS (WORKFLOWS ENGINE)
    // ─────────────────────────────────────────────────────────────────────────

    public static function getAutomations(): array
    {
        $automations = self::readJson('automations.json');
        usort($automations, function ($a, $b) {
            return strcmp($b['created_at'] ?? '', $a['created_at'] ?? '');
        });
        return array_values($automations);
    }

    public static function getAutomationById(string $id): ?array
    {
        $automations = self::readJson('automations.json');
        foreach ($automations as $a) {
            if ($a['id'] === $id) {
                return $a;
            }
        }
        return null;
    }

    public static function saveAutomation(array $data): array
    {
        $automations = self::readJson('automations.json');
        $id = $data['id'] ?? '';
        $existingIndex = -1;

        if (!empty($id)) {
            foreach ($automations as $idx => $a) {
                if ($a['id'] === $id) {
                    $existingIndex = $idx;
                    break;
                }
            }
        }

        $now = date('Y-m-d H:i:s');
        if ($existingIndex >= 0) {
            $existing = $automations[$existingIndex];
            $automations[$existingIndex] = [
                'id' => $existing['id'],
                'name' => trim($data['name'] ?? ($existing['name'] ?? 'Untitled Workflow')),
                'status' => in_array($data['status'] ?? '', ['active', 'paused'], true) ? $data['status'] : ($existing['status'] ?? 'active'),
                'trigger_type' => $data['trigger_type'] ?? ($existing['trigger_type'] ?? 'new_signup'),
                'trigger_config' => $data['trigger_config'] ?? ($existing['trigger_config'] ?? []),
                'steps' => $data['steps'] ?? ($existing['steps'] ?? []),
                'enrollments_count' => $existing['enrollments_count'] ?? 0,
                'created_at' => $existing['created_at'],
                'updated_at' => $now
            ];
            self::writeJson('automations.json', $automations);
            return $automations[$existingIndex];
        } else {
            $newAutomation = [
                'id' => 'AUTO-' . (count($automations) + 101) . '-' . substr(bin2hex(random_bytes(3)), 0, 4),
                'name' => trim($data['name'] ?? 'New Automation Flow'),
                'status' => in_array($data['status'] ?? '', ['active', 'paused'], true) ? $data['status'] : 'active',
                'trigger_type' => $data['trigger_type'] ?? 'new_signup',
                'trigger_config' => $data['trigger_config'] ?? [],
                'steps' => $data['steps'] ?? [
                    [
                        'id' => 'step_1',
                        'type' => 'send_email',
                        'title' => 'Send Welcome Email',
                        'config' => [
                            'subject' => 'Welcome to Estate HDR',
                            'body' => '<p>Hi {{first_name}}, glad to have you aboard!</p>'
                        ]
                    ]
                ],
                'enrollments_count' => 0,
                'created_at' => $now,
                'updated_at' => $now
            ];
            $automations[] = $newAutomation;
            self::writeJson('automations.json', $automations);
            return $newAutomation;
        }
    }

    public static function toggleAutomationStatus(string $id): ?string
    {
        $automations = self::readJson('automations.json');
        $newStatus = null;
        foreach ($automations as &$a) {
            if ($a['id'] === $id) {
                $a['status'] = ($a['status'] === 'active') ? 'paused' : 'active';
                $newStatus = $a['status'];
                break;
            }
        }
        if ($newStatus !== null) {
            self::writeJson('automations.json', $automations);
        }
        return $newStatus;
    }

    public static function deleteAutomation(string $id): bool
    {
        $automations = self::readJson('automations.json');
        $filtered = array_filter($automations, fn($a) => ($a['id'] ?? '') !== $id);
        if (count($filtered) !== count($automations)) {
            return self::writeJson('automations.json', array_values($filtered));
        }
        return false;
    }

    /**
     * Triggers active automations matching the specified event
     */
    public static function triggerAutomationEvent(string $eventType, array $contact, array $meta = []): int
    {
        $automations = self::readJson('automations.json');
        $enrolledCount = 0;

        foreach ($automations as &$auto) {
            if (($auto['status'] ?? '') !== 'active') {
                continue;
            }

            $matches = false;
            if ($auto['trigger_type'] === $eventType) {
                if ($eventType === 'form_submit') {
                    $expectedForm = $auto['trigger_config']['form_id'] ?? '';
                    if (empty($expectedForm) || $expectedForm === ($meta['form_id'] ?? '')) {
                        $matches = true;
                    }
                } elseif ($eventType === 'tag_added') {
                    $expectedTag = $auto['trigger_config']['tag'] ?? '';
                    if (empty($expectedTag) || in_array($expectedTag, $contact['tags'] ?? [], true)) {
                        $matches = true;
                    }
                } else {
                    $matches = true;
                }
            }

            if ($matches) {
                self::enrollContact($auto['id'], $contact['id']);
                $auto['enrollments_count'] = ($auto['enrollments_count'] ?? 0) + 1;
                $enrolledCount++;
            }
        }

        if ($enrolledCount > 0) {
            self::writeJson('automations.json', $automations);
        }

        return $enrolledCount;
    }

    public static function isEngineEnabled(): bool
    {
        $settings = self::getSettings();
        return !empty($settings['engine_enabled']);
    }

    public static function setEngineEnabled(bool $enabled): bool
    {
        self::saveSettings(['engine_enabled' => $enabled]);
        return $enabled;
    }

    private static function enrollContact(string $automationId, string $contactId): void
    {
        if (!self::isEngineEnabled()) {
            return; // Automation engine disabled by admin to keep website fast
        }

        $enrollments = self::readJson('enrollments.json');
        $enrollments[] = [
            'id' => uniqid('enr_', true),
            'automation_id' => $automationId,
            'contact_id' => $contactId,
            'current_step' => 0,
            'status' => 'active',
            'next_run_at' => date('Y-m-d H:i:s'),
            'enrolled_at' => date('Y-m-d H:i:s')
        ];
        self::writeJson('enrollments.json', $enrollments);
    }

    /**
     * Executes pending automation steps (called by Cron or manually)
     */
    public static function processAutomationQueue(): array
    {
        if (!self::isEngineEnabled()) {
            return [
                'status' => 'disabled',
                'message' => 'Automation engine is disabled by admin to maximize website performance.',
                'processed_steps' => 0,
                'completed_enrollments' => 0
            ];
        }

        $enrollments = self::readJson('enrollments.json');
        $automations = self::readJson('automations.json');
        $autoMap = [];
        foreach ($automations as $a) {
            $autoMap[$a['id']] = $a;
        }

        $now = time();
        $processed = 0;
        $completed = 0;
        $baseUrl = defined('BASE_URL') ? BASE_URL : 'https://estatehdr.com';

        foreach ($enrollments as &$enr) {
            if ($enr['status'] !== 'active') {
                continue;
            }

            $nextRunTime = !empty($enr['next_run_at']) ? strtotime($enr['next_run_at']) : 0;
            if ($nextRunTime > $now) {
                continue; // Still waiting for delay
            }

            $auto = $autoMap[$enr['automation_id']] ?? null;
            if (!$auto || ($auto['status'] ?? '') !== 'active') {
                continue;
            }

            $steps = $auto['steps'] ?? [];
            $stepIdx = (int)($enr['current_step'] ?? 0);

            if ($stepIdx >= count($steps)) {
                $enr['status'] = 'completed';
                $completed++;
                continue;
            }

            $step = $steps[$stepIdx];
            $contact = self::getContactById($enr['contact_id']);
            if (!$contact || ($contact['status'] ?? '') === 'unsubscribed') {
                $enr['status'] = 'cancelled';
                continue;
            }

            // Execute current step
            $stepType = $step['type'] ?? 'send_email';
            $config = $step['config'] ?? [];

            if ($stepType === 'send_email') {
                $subject = $config['subject'] ?? 'Notification from Estate HDR';
                $html = $config['body'] ?? '';
                $body = self::renderPersonalizedHtml($html, $contact, 'AUTO-' . $auto['id'], $baseUrl, true, true);
                
                require_once dirname(__DIR__) . '/mail.php';
                if (function_exists('sendSmtpMail')) {
                    sendSmtpMail($contact['email'], $subject, $body);
                }

                self::logEvent($contact['id'], 'automation_email_sent', null, $auto['id'], [
                    'step_id' => $step['id'] ?? $stepIdx,
                    'subject' => $subject
                ]);

                $enr['current_step']++;
                $enr['next_run_at'] = date('Y-m-d H:i:s');
                $processed++;

            } elseif ($stepType === 'wait') {
                $hours = (int)($config['duration_hours'] ?? 24);
                $enr['next_run_at'] = date('Y-m-d H:i:s', strtotime("+{$hours} hours"));
                $enr['current_step']++;
                $processed++;

            } elseif ($stepType === 'add_tag') {
                $newTag = trim($config['tag'] ?? '');
                if (!empty($newTag)) {
                    $tags = $contact['tags'] ?? [];
                    if (!in_array($newTag, $tags, true)) {
                        $tags[] = $newTag;
                        self::saveContact([
                            'id' => $contact['id'],
                            'email' => $contact['email'],
                            'tags' => $tags
                        ]);
                    }
                }
                $enr['current_step']++;
                $enr['next_run_at'] = date('Y-m-d H:i:s');
                $processed++;

            } elseif ($stepType === 'remove_tag') {
                $removeTag = trim($config['tag'] ?? '');
                if (!empty($removeTag)) {
                    $tags = array_values(array_filter($contact['tags'] ?? [], fn($t) => $t !== $removeTag));
                    self::saveContact([
                        'id' => $contact['id'],
                        'email' => $contact['email'],
                        'tags' => $tags
                    ]);
                }
                $enr['current_step']++;
                $enr['next_run_at'] = date('Y-m-d H:i:s');
                $processed++;
            }

            // Check if workflow reached end
            if ($enr['current_step'] >= count($steps)) {
                $enr['status'] = 'completed';
                $completed++;
            }
        }

        self::writeJson('enrollments.json', $enrollments);

        return [
            'processed_steps' => $processed,
            'completed_enrollments' => $completed
        ];
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SIGNUP FORMS API
    // ─────────────────────────────────────────────────────────────────────────

    public static function getForms(): array
    {
        $forms = self::readJson('forms.json');
        usort($forms, function ($a, $b) {
            return strcmp($b['created_at'] ?? '', $a['created_at'] ?? '');
        });
        return array_values($forms);
    }

    public static function saveForm(array $data): array
    {
        $forms = self::readJson('forms.json');
        $id = $data['id'] ?? '';
        $existingIndex = -1;

        if (!empty($id)) {
            foreach ($forms as $idx => $f) {
                if ($f['id'] === $id) {
                    $existingIndex = $idx;
                    break;
                }
            }
        }

        $now = date('Y-m-d H:i:s');
        if ($existingIndex >= 0) {
            $existing = $forms[$existingIndex];
            $forms[$existingIndex] = [
                'id' => $existing['id'],
                'name' => trim($data['name'] ?? ($existing['name'] ?? 'Untitled Form')),
                'target_tag' => trim($data['target_tag'] ?? ($existing['target_tag'] ?? 'lead')),
                'redirect_url' => trim($data['redirect_url'] ?? ($existing['redirect_url'] ?? '/thank-you')),
                'submits_count' => $existing['submits_count'] ?? 0,
                'created_at' => $existing['created_at'],
                'updated_at' => $now
            ];
            self::writeJson('forms.json', $forms);
            return $forms[$existingIndex];
        } else {
            $newForm = [
                'id' => 'FORM-' . (count($forms) + 101) . '-' . substr(bin2hex(random_bytes(3)), 0, 4),
                'name' => trim($data['name'] ?? 'New Signup Form'),
                'target_tag' => trim($data['target_tag'] ?? 'lead'),
                'redirect_url' => trim($data['redirect_url'] ?? '/thank-you'),
                'submits_count' => 0,
                'created_at' => $now,
                'updated_at' => $now
            ];
            $forms[] = $newForm;
            self::writeJson('forms.json', $forms);
            return $newForm;
        }
    }

    public static function deleteForm(string $id): bool
    {
        $forms = self::readJson('forms.json');
        $filtered = array_filter($forms, fn($f) => ($f['id'] ?? '') !== $id);
        if (count($filtered) !== count($forms)) {
            return self::writeJson('forms.json', array_values($filtered));
        }
        return false;
    }

    public static function handleFormSubmission(array $postData): array
    {
        $email = strtolower(trim($postData['email'] ?? ''));
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['success' => false, 'error' => 'Please provide a valid email address.'];
        }

        $formId = trim($postData['form_id'] ?? '');
        $forms = self::readJson('forms.json');
        $matchedForm = null;
        foreach ($forms as &$f) {
            if ($f['id'] === $formId) {
                $f['submits_count'] = ($f['submits_count'] ?? 0) + 1;
                $matchedForm = $f;
                break;
            }
        }
        if ($matchedForm) {
            self::writeJson('forms.json', $forms);
        }

        $tag = $matchedForm['target_tag'] ?? 'lead';
        $contact = self::saveContact([
            'email' => $email,
            'first_name' => trim($postData['first_name'] ?? ($postData['name'] ?? '')),
            'last_name' => trim($postData['last_name'] ?? ''),
            'phone' => trim($postData['phone'] ?? ''),
            'company' => trim($postData['company'] ?? ''),
            'tags' => [$tag],
            'source' => $matchedForm['name'] ?? 'Website Form',
            'status' => 'subscribed'
        ]);

        self::logEvent($contact['id'], 'form_submit', null, null, ['form_id' => $formId]);
        self::triggerAutomationEvent('form_submit', $contact, ['form_id' => $formId]);

        return [
            'success' => true,
            'contact' => $contact,
            'redirect_url' => $matchedForm['redirect_url'] ?? ''
        ];
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ANALYTICS, TRACKING & EVENTS
    // ─────────────────────────────────────────────────────────────────────────

    public static function logEvent(
        string $contactId,
        string $type,
        ?string $campaignId = null,
        ?string $automationId = null,
        array $meta = []
    ): void {
        $events = self::readJson('events.json');
        $event = [
            'id' => 'EVT-' . bin2hex(random_bytes(5)),
            'type' => $type,
            'contact_id' => $contactId,
            'campaign_id' => $campaignId,
            'automation_id' => $automationId,
            'meta' => $meta,
            'created_at' => date('Y-m-d H:i:s')
        ];
        array_unshift($events, $event);
        if (count($events) > 1000) {
            $events = array_slice($events, 0, 1000);
        }
        self::writeJson('events.json', $events);
    }

    public static function recordOpen(string $campaignId, string $contactId): void
    {
        $campaigns = self::readJson('campaigns.json');
        $updated = false;
        foreach ($campaigns as &$c) {
            if ($c['id'] === $campaignId) {
                $c['stats']['opens'] = ($c['stats']['opens'] ?? 0) + 1;
                $updated = true;
                break;
            }
        }
        if ($updated) {
            self::writeJson('campaigns.json', $campaigns);
        }

        self::logEvent($contactId, 'open', $campaignId, null, [
            'ip' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'
        ]);
    }

    public static function recordClick(string $campaignId, string $contactId, string $targetUrl): void
    {
        $campaigns = self::readJson('campaigns.json');
        $updated = false;
        foreach ($campaigns as &$c) {
            if ($c['id'] === $campaignId) {
                $c['stats']['clicks'] = ($c['stats']['clicks'] ?? 0) + 1;
                $updated = true;
                break;
            }
        }
        if ($updated) {
            self::writeJson('campaigns.json', $campaigns);
        }

        self::logEvent($contactId, 'click', $campaignId, null, [
            'url' => $targetUrl,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'
        ]);
    }

    public static function recordUnsubscribe(string $campaignId, string $contactId): bool
    {
        $contacts = self::readJson('contacts.json');
        $found = false;
        foreach ($contacts as &$c) {
            if ($c['id'] === $contactId) {
                $c['status'] = 'unsubscribed';
                $found = true;
                break;
            }
        }
        if ($found) {
            self::writeJson('contacts.json', $contacts);
            self::logEvent($contactId, 'unsubscribe', $campaignId);

            $campaigns = self::readJson('campaigns.json');
            foreach ($campaigns as &$cmp) {
                if ($cmp['id'] === $campaignId) {
                    $cmp['stats']['unsubscribes'] = ($cmp['stats']['unsubscribes'] ?? 0) + 1;
                    break;
                }
            }
            self::writeJson('campaigns.json', $campaigns);
            return true;
        }
        return false;
    }

    public static function getStatsSummary(): array
    {
        $contacts = self::readJson('contacts.json');
        $campaigns = self::readJson('campaigns.json');
        $automations = self::readJson('automations.json');

        $totalContacts = count($contacts);
        $subscribedContacts = count(array_filter($contacts, fn($c) => ($c['status'] ?? '') === 'subscribed'));
        $unsubscribedContacts = count(array_filter($contacts, fn($c) => ($c['status'] ?? '') === 'unsubscribed'));
        $leadContacts = count(array_filter($contacts, fn($c) => in_array('lead', $c['tags'] ?? [])));
        $agentContacts = count(array_filter($contacts, fn($c) => 
            in_array('real_estate_agent', $c['tags'] ?? []) || 
            in_array('agent_listing', $c['tags'] ?? []) || 
            in_array('realtor', $c['tags'] ?? []) || 
            in_array('agent', $c['tags'] ?? [])
        ));

        $totalSent = 0;
        $totalDelivered = 0;
        $totalOpens = 0;
        $totalClicks = 0;
        $totalBounces = 0;
        $totalUnsubs = 0;

        foreach ($campaigns as $c) {
            $s = $c['stats'] ?? [];
            $totalSent += (int)($s['sent'] ?? 0);
            $totalDelivered += (int)($s['delivered'] ?? 0);
            $totalOpens += (int)($s['opens'] ?? 0);
            $totalClicks += (int)($s['clicks'] ?? 0);
            $totalBounces += (int)($s['bounces'] ?? 0);
            $totalUnsubs += (int)($s['unsubscribes'] ?? 0);
        }

        $openRate = $totalDelivered > 0 ? round(($totalOpens / $totalDelivered) * 100, 1) : 0.0;
        $clickRate = $totalDelivered > 0 ? round(($totalClicks / $totalDelivered) * 100, 1) : 0.0;
        $bounceRate = $totalSent > 0 ? round(($totalBounces / $totalSent) * 100, 1) : 0.0;
        $unsubRate = $totalDelivered > 0 ? round(($totalUnsubs / $totalDelivered) * 100, 1) : 0.0;
        $deliveryRate = $totalSent > 0 ? round(($totalDelivered / $totalSent) * 100, 1) : ($totalSent === 0 ? 0.0 : 100.0);

        $activeAutomations = count(array_filter($automations, fn($a) => ($a['status'] ?? '') === 'active'));
        $duplicateEmailsCount = self::getDuplicateEmailCount();

        // Calculate dynamic monthly growth or activity (last 6 months)
        $growthBars = [];
        for ($i = 5; $i >= 0; $i--) {
            $m = date('M', strtotime("-$i months"));
            $ym = date('Y-m', strtotime("-$i months"));
            $countMonth = 0;
            foreach ($contacts as $c) {
                if (isset($c['created_at']) && strpos($c['created_at'], $ym) === 0) {
                    $countMonth++;
                }
            }
            $growthBars[] = [
                'month' => $m,
                'count' => $countMonth,
                'percent' => $totalContacts > 0 ? min(100, max(8, round(($countMonth / $totalContacts) * 100))) : 0
            ];
        }

        $verifiedValid = count(array_filter($contacts, fn($c) => ($c['verification_status'] ?? '') === 'valid'));
        $verifiedRisky = count(array_filter($contacts, fn($c) => ($c['verification_status'] ?? '') === 'risky'));
        $verifiedInvalid = count(array_filter($contacts, fn($c) => ($c['verification_status'] ?? '') === 'invalid'));
        $unverifiedCount = count(array_filter($contacts, fn($c) => empty($c['verification_status']) || $c['verification_status'] === 'unverified'));

        return [
            'total_contacts' => $totalContacts,
            'subscribed_contacts' => $subscribedContacts,
            'unsubscribed_contacts' => $unsubscribedContacts,
            'lead_contacts' => $leadContacts,
            'agent_contacts' => $agentContacts,
            'duplicate_contacts' => $duplicateEmailsCount,
            'verified_valid' => $verifiedValid,
            'verified_risky' => $verifiedRisky,
            'verified_invalid' => $verifiedInvalid,
            'unverified_count' => $unverifiedCount,
            'emails_sent_month' => $totalSent,
            'delivery_rate' => $deliveryRate,
            'avg_open_rate' => $openRate,
            'avg_click_rate' => $clickRate,
            'bounce_rate' => $bounceRate,
            'unsub_rate' => $unsubRate,
            'active_automations' => $activeAutomations,
            'growth_bars' => $growthBars
        ];
    }

    public static function freshStartReset(bool $keepContacts = true): array
    {
        self::initStorage();
        $contacts = self::readJson('contacts.json');
        $contactCount = count($contacts);

        if (!$keepContacts) {
            $contacts = [];
            self::writeJson('contacts.json', []);
            $contactCount = 0;
        }

        // Clean slate campaigns: 1 fresh draft outreach campaign ready to send
        $cleanCampaigns = [
            [
                'id' => 'CMP-' . strtoupper(substr(uniqid(), -6)),
                'name' => 'Realtor Outreach — Luxury 12h HDR Photo Blending',
                'subject' => 'Elevate Your Property Listings with 12h HDR Turnaround | Estate HDR',
                'preview_text' => 'Crisp architectural lines, natural window views, and guaranteed 12-hour turnaround.',
                'target_tag' => 'all',
                'status' => 'draft',
                'scheduled_at' => null,
                'sent_at' => null,
                'stats' => [
                    'total' => $contactCount,
                    'sent' => 0,
                    'delivered' => 0,
                    'opens' => 0,
                    'clicks' => 0,
                    'bounces' => 0,
                    'unsubscribes' => 0
                ],
                'content_html' => '<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;color:#222;line-height:1.6;">'
                    . '<h2 style="color:#C9A84C;">Elevate Your Real Estate Listings</h2>'
                    . '<p>Hi {{first_name}},</p>'
                    . '<p>High-quality visuals sell properties 32% faster. At <strong>Estate HDR</strong>, we provide premium architectural editing, flambient blending, and twilight conversions tailored specifically for elite listing agents.</p>'
                    . '<p style="margin:24px 0;"><a href="https://estatehdr.com" style="background:#C9A84C;color:#000;padding:12px 24px;border-radius:6px;font-weight:bold;text-decoration:none;display:inline-block;">Explore Our Portfolio</a></p>'
                    . '<p>Best regards,<br>The Estate HDR Team</p>'
                    . '</div>',
                'created_at' => date('Y-m-d H:i:s')
            ]
        ];
        self::writeJson('campaigns.json', $cleanCampaigns);

        // Reset events and log system fresh start
        $freshEvents = [
            [
                'id' => 'EVT-' . strtoupper(substr(uniqid(), -6)),
                'type' => 'system_reset',
                'contact_id' => null,
                'campaign_id' => null,
                'meta' => [
                    'action' => 'fresh_start',
                    'contacts_preserved' => $contactCount,
                    'timestamp' => date('Y-m-d H:i:s')
                ],
                'created_at' => date('Y-m-d H:i:s')
            ]
        ];
        self::writeJson('events.json', $freshEvents);

        // Reset enrollments if file exists
        $enrollmentsFile = self::$storageDir . '/enrollments.json';
        if (file_exists($enrollmentsFile)) {
            @file_put_contents($enrollmentsFile, json_encode([], JSON_PRETTY_PRINT));
        }

        return [
            'success' => true,
            'contacts_preserved' => $contactCount,
            'campaigns_reset' => count($cleanCampaigns),
            'message' => "Dashboard and campaigns successfully reset! {$contactCount} contacts preserved."
        ];
    }

    public static function getTopCampaigns(int $limit = 5): array
    {
        $campaigns = self::readJson('campaigns.json');
        usort($campaigns, function ($a, $b) {
            $aRate = !empty($a['stats']['delivered']) ? ($a['stats']['opens'] / $a['stats']['delivered']) : 0;
            $bRate = !empty($b['stats']['delivered']) ? ($b['stats']['opens'] / $b['stats']['delivered']) : 0;
            return $bRate <=> $aRate;
        });
        return array_slice($campaigns, 0, $limit);
    }

    public static function getRecentEvents(int $limit = 15): array
    {
        $events = self::readJson('events.json');
        return array_slice($events, 0, $limit);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SETTINGS API
    // ─────────────────────────────────────────────────────────────────────────

    public static function getSettings(): array
    {
        return self::readJson('settings.json', [
            'from_name' => defined('SMTP_FROM_NAME') ? SMTP_FROM_NAME : 'Estate HDR',
            'from_email' => defined('SMTP_FROM_EMAIL') ? SMTP_FROM_EMAIL : 'info@estatehdr.com',
            'reply_to' => 'info@estatehdr.com',
            'delivery_mode' => 'smtp',
            'track_opens' => true,
            'track_clicks' => true,
            'daily_limit' => 2000,
            'engine_enabled' => false
        ]);
    }

    public static function saveSettings(array $newSettings): array
    {
        $current = self::getSettings();
        $updated = array_merge($current, $newSettings, ['updated_at' => date('Y-m-d H:i:s')]);
        self::writeJson('settings.json', $updated);
        return $updated;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TEMPLATE LIBRARY & DAILY LEAD SUBMISSIONS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Get all available pre-built email templates
     */
    public static function getEmailTemplates(): array
    {
        return EmailTemplateLibrary::getAllTemplates();
    }

    /**
     * Get a single template by ID
     */
    public static function getEmailTemplate(string $id): ?array
    {
        return EmailTemplateLibrary::getTemplateById($id);
    }

    /**
     * Quick submit daily leads and optionally enroll in 7-day outreach sequence
     */
    public static function quickSubmitDailyLeads(string $rawText, string $tag = '', bool $enrollInDrip = false): array
    {
        $lines = preg_split('/[\r\n]+/', trim($rawText));
        if (empty($lines)) {
            return ['total_parsed' => 0, 'imported' => 0, 'updated' => 0, 'drip_enrolled' => 0, 'tag' => ''];
        }

        $defaultTag = !empty($tag) ? trim($tag) : 'daily-batch-' . date('Y-m-d');
        $imported = 0;
        $updated = 0;
        $enrolledCount = 0;

        // Ensure 7-day sequence exists in automations
        if ($enrollInDrip) {
            self::seedOutreachAutomation();
        }

        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) continue;

            $email = '';
            $firstName = '';
            $lastName = '';
            $company = '';

            if (str_contains($line, ',') || str_contains($line, "\t")) {
                $delim = str_contains($line, "\t") ? "\t" : ',';
                $parts = array_map('trim', explode($delim, $line));
                
                $foundEmailIdx = -1;
                foreach ($parts as $idx => $p) {
                    if (filter_var($p, FILTER_VALIDATE_EMAIL)) {
                        $email = strtolower($p);
                        $foundEmailIdx = $idx;
                        break;
                    }
                }

                if ($foundEmailIdx !== -1) {
                    unset($parts[$foundEmailIdx]);
                    $parts = array_values($parts);
                    if (isset($parts[0])) {
                        $names = explode(' ', $parts[0], 2);
                        $firstName = $names[0] ?? '';
                        $lastName = $names[1] ?? '';
                    }
                    if (isset($parts[1]) && empty($lastName)) {
                        $lastName = $parts[1];
                    }
                    if (isset($parts[2])) {
                        $company = $parts[2];
                    } elseif (isset($parts[1]) && !empty($lastName)) {
                        $company = $parts[1];
                    }
                }
            } else {
                if (preg_match('/^(.*?)\s*<([^>]+)>$/', $line, $m)) {
                    $email = strtolower(trim($m[2]));
                    $names = explode(' ', trim($m[1]), 2);
                    $firstName = $names[0] ?? '';
                    $lastName = $names[1] ?? '';
                } elseif (filter_var($line, FILTER_VALIDATE_EMAIL)) {
                    $email = strtolower($line);
                }
            }

            if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                continue;
            }

            $existing = self::getContactByEmail($email);
            $tags = $existing ? ($existing['tags'] ?? []) : [];
            if (!in_array($defaultTag, $tags, true)) {
                $tags[] = $defaultTag;
            }

            $contactData = [
                'id' => $existing['id'] ?? '',
                'email' => $email,
                'first_name' => !empty($firstName) ? $firstName : ($existing['first_name'] ?? 'Friend'),
                'last_name' => !empty($lastName) ? $lastName : ($existing['last_name'] ?? ''),
                'company' => !empty($company) ? $company : ($existing['company'] ?? 'Photo Studio'),
                'status' => 'subscribed',
                'tags' => $tags,
                'source' => 'Daily Lead Submission (' . date('Y-m-d') . ')'
            ];

            $saved = self::saveContact($contactData);
            if ($existing) {
                $updated++;
            } else {
                $imported++;
            }

            if ($enrollInDrip && !empty($saved['id'])) {
                self::enrollContactInOutreachSequence($saved['id']);
                $enrolledCount++;
            }
        }

        return [
            'total_parsed' => count($lines),
            'imported' => $imported,
            'updated' => $updated,
            'drip_enrolled' => $enrolledCount,
            'tag' => $defaultTag
        ];
    }

    /**
     * Enrolls contact in 7-Day Outreach Sequence
     */
    public static function enrollContactInOutreachSequence(string $contactId): bool
    {
        $autoId = 'AUTO-7DAY-OUTREACH';
        $enrollments = self::readJson('enrollments.json');

        // Check if already enrolled
        foreach ($enrollments as $enr) {
            if (($enr['automation_id'] ?? '') === $autoId && ($enr['contact_id'] ?? '') === $contactId && ($enr['status'] ?? '') === 'active') {
                return false; // Already actively enrolled
            }
        }

        self::enrollContact($autoId, $contactId);
        return true;
    }

    /**
     * Seeds or updates the 7-Day Full Week Outreach Sequence in automations.json
     */
    public static function seedOutreachAutomation(): array
    {
        $automations = self::readJson('automations.json');
        $autoId = 'AUTO-7DAY-OUTREACH';
        $existingIdx = -1;

        foreach ($automations as $idx => $a) {
            if (($a['id'] ?? '') === $autoId) {
                $existingIdx = $idx;
                break;
            }
        }

        $templates = EmailTemplateLibrary::getAllTemplates();

        $steps = [
            // Day 1
            [
                'id' => 'step_1_day1',
                'type' => 'send_email',
                'title' => 'Day 1: Cold Intro — $0.60 HDR + Free Day-to-Dusk Hero',
                'config' => [
                    'subject' => $templates['tmpl_day1_offer']['subject'] ?? 'Exclusive: $0.60 HDR Photo Editing (Was $0.80) + 1 FREE Day-to-Dusk',
                    'body' => $templates['tmpl_day1_offer']['html'] ?? ''
                ]
            ],
            [
                'id' => 'step_2_wait24h',
                'type' => 'wait',
                'title' => 'Wait 24 Hours (Day 2 Delivery)',
                'config' => ['duration_hours' => 24]
            ],
            // Day 2
            [
                'id' => 'step_3_day2',
                'type' => 'send_email',
                'title' => 'Day 2: Visual Proof — Hand Blending vs AI Muddy Edits',
                'config' => [
                    'subject' => $templates['tmpl_day2_proof']['subject'] ?? 'Before vs After: See why studios switched to Estate HDR ($0.60/photo + Free Twilight)',
                    'body' => $templates['tmpl_day2_proof']['html'] ?? ''
                ]
            ],
            [
                'id' => 'step_4_wait24h',
                'type' => 'wait',
                'title' => 'Wait 24 Hours (Day 3 Delivery)',
                'config' => ['duration_hours' => 24]
            ],
            // Day 3
            [
                'id' => 'step_5_day3',
                'type' => 'send_email',
                'title' => 'Day 3: Cost Calculator — Cut Editing Bills by 40%',
                'config' => [
                    'subject' => $templates['tmpl_day3_calculator']['subject'] ?? 'Cut your editing bill by 40% with our $0.60 limited rate (+ Free Day-to-Dusk)',
                    'body' => $templates['tmpl_day3_calculator']['html'] ?? ''
                ]
            ],
            [
                'id' => 'step_6_wait24h',
                'type' => 'wait',
                'title' => 'Wait 24 Hours (Day 4 Delivery)',
                'config' => ['duration_hours' => 24]
            ],
            // Day 4
            [
                'id' => 'step_7_day4',
                'type' => 'send_email',
                'title' => 'Day 4: Workflow Speed — Shoot, Drop Dropbox Link, Done',
                'config' => [
                    'subject' => $templates['tmpl_day4_speed']['subject'] ?? 'Shoot all day, send Dropbox link from your car, wake up to MLS-ready HDRs ⚡',
                    'body' => $templates['tmpl_day4_speed']['html'] ?? ''
                ]
            ],
            [
                'id' => 'step_8_wait24h',
                'type' => 'wait',
                'title' => 'Wait 24 Hours (Day 5 Delivery)',
                'config' => ['duration_hours' => 24]
            ],
            // Day 5
            [
                'id' => 'step_9_day5',
                'type' => 'send_email',
                'title' => 'Day 5: Twilight Secret — Sell Listings 3x Faster',
                'config' => [
                    'subject' => $templates['tmpl_day5_twilight']['subject'] ?? 'How our 1 FREE Day-to-Dusk on every property wins you more agent clients 🌅',
                    'body' => $templates['tmpl_day5_twilight']['html'] ?? ''
                ]
            ],
            [
                'id' => 'step_10_wait24h',
                'type' => 'wait',
                'title' => 'Wait 24 Hours (Day 6 Delivery)',
                'config' => ['duration_hours' => 24]
            ],
            // Day 6
            [
                'id' => 'step_11_day6',
                'type' => 'send_email',
                'title' => 'Day 6: Urgency — Final 48 Hours to Lock In $0.60 Rate',
                'config' => [
                    'subject' => $templates['tmpl_day6_urgency']['subject'] ?? '⚠️ Final 48 Hours: Lock in your $0.60 HDR rate + Free Twilight before promo closes',
                    'body' => $templates['tmpl_day6_urgency']['html'] ?? ''
                ]
            ],
            [
                'id' => 'step_12_wait24h',
                'type' => 'wait',
                'title' => 'Wait 24 Hours (Day 7 Delivery)',
                'config' => ['duration_hours' => 24]
            ],
            // Day 7
            [
                'id' => 'step_13_day7',
                'type' => 'send_email',
                'title' => 'Day 7: Breakup Letter — Permission to Close Your File?',
                'config' => [
                    'subject' => $templates['tmpl_day7_breakup']['subject'] ?? 'Permission to close your file? (Last chance for $0.60 HDR + Free Day-to-Dusk Hero)',
                    'body' => $templates['tmpl_day7_breakup']['html'] ?? ''
                ]
            ],
            [
                'id' => 'step_14_tag_complete',
                'type' => 'add_tag',
                'title' => 'Add Tag: completed-7day-outreach',
                'config' => ['tag' => 'completed-7day-outreach']
            ]
        ];

        $sequenceData = [
            'id' => $autoId,
            'name' => '7-Day Full Week Outreach Sequence ($0.60 HDR + Free Day-to-Dusk)',
            'status' => 'active',
            'trigger_type' => 'daily_lead_submission',
            'trigger_config' => ['tag' => 'daily-batch'],
            'steps' => $steps,
            'enrollments_count' => ($existingIdx >= 0) ? ($automations[$existingIdx]['enrollments_count'] ?? 0) : 0,
            'created_at' => ($existingIdx >= 0) ? ($automations[$existingIdx]['created_at'] ?? date('Y-m-d H:i:s')) : date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        if ($existingIdx >= 0) {
            $automations[$existingIdx] = $sequenceData;
        } else {
            $automations[] = $sequenceData;
        }

        self::writeJson('automations.json', $automations);
        return $sequenceData;
    }

}