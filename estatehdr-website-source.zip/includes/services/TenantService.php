<?php
/**
 * Estate HDR - Tenant & Multi-Workspace Service
 * Enterprise Layer: Organization / Multi-Tenant Architecture & Workspaces
 * 
 * Manages Organizations, Workspaces, Regional Settings, SLAs, and Context.
 * Guarantees 100% backward compatibility for legacy non-tenant records.
 */

class TenantService {
    private static string $orgFile = __DIR__ . '/../../data/organizations.json';
    private static string $workspaceFile = __DIR__ . '/../../data/workspaces.json';

    public const DEFAULT_ORG_ID = 'org-estatehdr-default';
    public const DEFAULT_WORKSPACE_ID = 'ws-us-production';

    /**
     * Get or create default organization
     */
    public static function getOrganizations(): array {
        if (!file_exists(self::$orgFile)) {
            $defaults = [
                self::DEFAULT_ORG_ID => [
                    'id' => self::DEFAULT_ORG_ID,
                    'name' => 'Estate HDR Global',
                    'slug' => 'estatehdr-global',
                    'tier' => 'enterprise',
                    'status' => 'active',
                    'created_at' => '2026-01-01 00:00:00',
                    'settings' => [
                        'default_currency' => 'USD',
                        'data_residency' => 'US',
                        'white_label' => false,
                        'branding' => [
                            'logo_url' => '/assets/images/logo.png',
                            'primary_color' => '#C9A84C',
                            'accent_color' => '#E5C05D'
                        ]
                    ]
                ]
            ];
            @file_put_contents(self::$orgFile, json_encode($defaults, JSON_PRETTY_PRINT));
            return $defaults;
        }
        $data = json_decode(@file_get_contents(self::$orgFile), true);
        return is_array($data) ? $data : [];
    }

    /**
     * Get or create default workspaces
     */
    public static function getWorkspaces(): array {
        if (!file_exists(self::$workspaceFile)) {
            $defaults = [
                self::DEFAULT_WORKSPACE_ID => [
                    'id' => self::DEFAULT_WORKSPACE_ID,
                    'organization_id' => self::DEFAULT_ORG_ID,
                    'name' => 'USA Production',
                    'region' => 'US',
                    'timezone' => 'America/New_York',
                    'default_sla_hours' => 24,
                    'status' => 'active',
                    'teams' => ['team-us-hdr', 'team-us-twilight'],
                    'created_at' => '2026-01-01 00:00:00'
                ],
                'ws-uk-production' => [
                    'id' => 'ws-uk-production',
                    'organization_id' => self::DEFAULT_ORG_ID,
                    'name' => 'UK & Europe Production',
                    'region' => 'EU',
                    'timezone' => 'Europe/London',
                    'default_sla_hours' => 24,
                    'status' => 'active',
                    'teams' => ['team-uk-hdr'],
                    'created_at' => '2026-01-01 00:00:00'
                ],
                'ws-au-production' => [
                    'id' => 'ws-au-production',
                    'organization_id' => self::DEFAULT_ORG_ID,
                    'name' => 'Australia Production',
                    'region' => 'APAC',
                    'timezone' => 'Australia/Sydney',
                    'default_sla_hours' => 24,
                    'status' => 'active',
                    'teams' => ['team-au-hdr'],
                    'created_at' => '2026-01-01 00:00:00'
                ],
                'ws-commercial' => [
                    'id' => 'ws-commercial',
                    'organization_id' => self::DEFAULT_ORG_ID,
                    'name' => 'Commercial & Luxury Properties',
                    'region' => 'US',
                    'timezone' => 'America/Los_Angeles',
                    'default_sla_hours' => 12,
                    'status' => 'active',
                    'teams' => ['team-luxury-qa'],
                    'created_at' => '2026-01-01 00:00:00'
                ]
            ];
            @file_put_contents(self::$workspaceFile, json_encode($defaults, JSON_PRETTY_PRINT));
            return $defaults;
        }
        $data = json_decode(@file_get_contents(self::$workspaceFile), true);
        return is_array($data) ? $data : [];
    }

    /**
     * Resolve organization for a user/order record with backwards compatibility
     */
    public static function resolveOrgId(?string $providedOrgId = null, ?array $record = null): string {
        if (!empty($providedOrgId)) {
            return $providedOrgId;
        }
        if (!empty($record['organization_id'])) {
            return $record['organization_id'];
        }
        return self::DEFAULT_ORG_ID;
    }

    /**
     * Resolve workspace for a user/order record with backwards compatibility
     */
    public static function resolveWorkspaceId(?string $providedWsId = null, ?array $record = null): string {
        if (!empty($providedWsId)) {
            return $providedWsId;
        }
        if (!empty($record['workspace_id'])) {
            return $record['workspace_id'];
        }
        return self::DEFAULT_WORKSPACE_ID;
    }

    /**
     * Attach multi-tenant metadata to any record before saving
     */
    public static function applyTenantMetadata(array $data, ?string $userId = null): array {
        if (empty($data['organization_id'])) {
            $data['organization_id'] = self::DEFAULT_ORG_ID;
        }
        if (empty($data['workspace_id'])) {
            $data['workspace_id'] = self::DEFAULT_WORKSPACE_ID;
        }
        if (empty($data['created_by']) && $userId) {
            $data['created_by'] = $userId;
        }
        if ($userId) {
            $data['updated_by'] = $userId;
        }
        $data['updated_at'] = date('Y-m-d H:i:s');
        return $data;
    }

    /**
     * Filter array of records by Tenant context
     */
    public static function filterByTenant(array $records, ?string $orgId = null, ?string $workspaceId = null): array {
        if (!$orgId && !$workspaceId) {
            return $records;
        }
        return array_filter($records, function($item) use ($orgId, $workspaceId) {
            $itemOrg = $item['organization_id'] ?? self::DEFAULT_ORG_ID;
            $itemWs  = $item['workspace_id'] ?? self::DEFAULT_WORKSPACE_ID;
            if ($orgId && $itemOrg !== $orgId) return false;
            if ($workspaceId && $itemWs !== $workspaceId) return false;
            return true;
        });
    }
}
