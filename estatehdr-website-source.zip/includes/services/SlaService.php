<?php
/**
 * Estate HDR - SLA Automation & Client SLA Profiles
 * Enterprise Layer: SLA Automation & Escalation Engine
 * 
 * Computes consumed SLA %, triggers alerts at 50%, 75%, 90%, 100%, 110%.
 * Supports tiered SLA profiles (Standard 24h, Premium 12h, Enterprise 6h, VIP Custom).
 */

class SlaService {
    public const PROFILE_STANDARD   = 'standard_24h';
    public const PROFILE_PREMIUM    = 'premium_12h';
    public const PROFILE_ENTERPRISE = 'enterprise_6h';
    public const PROFILE_VIP        = 'vip_custom';

    public static function getTargetHours(string $profile): int {
        return match ($profile) {
            self::PROFILE_ENTERPRISE => 6,
            self::PROFILE_PREMIUM    => 12,
            self::PROFILE_VIP        => 4,
            default                  => 24
        };
    }

    /**
     * Compute real-time SLA metrics for an order
     */
    public static function evaluateOrderSla(array $order): array {
        $createdAt = strtotime($order['created_at'] ?? 'now');
        $now = time();
        $elapsedSec = max(0, $now - $createdAt);
        $elapsedHours = round($elapsedSec / 3600, 1);

        $profile = $order['sla_profile'] ?? self::PROFILE_STANDARD;
        $targetHours = $order['sla_hours'] ?? self::getTargetHours($profile);
        $targetSec = $targetHours * 3600;

        $consumedPct = round(($elapsedSec / $targetSec) * 100, 1);
        $remainingSec = max(0, $targetSec - $elapsedSec);
        $remainingHours = round($remainingSec / 3600, 1);

        // Escalation Level
        if ($consumedPct >= 110) {
            $escalation = 'EXECUTIVE_ESCALATION';
            $badgeColor = 'red';
            $isOverdue = true;
        } elseif ($consumedPct >= 100) {
            $escalation = 'OVERDUE';
            $badgeColor = 'red';
            $isOverdue = true;
        } elseif ($consumedPct >= 90) {
            $escalation = 'SUPERVISOR_ESCALATION';
            $badgeColor = 'amber';
            $isOverdue = false;
        } elseif ($consumedPct >= 75) {
            $escalation = 'MANAGER_NOTIFICATION';
            $badgeColor = 'amber';
            $isOverdue = false;
        } elseif ($consumedPct >= 50) {
            $escalation = 'SLA_WARNING';
            $badgeColor = 'yellow';
            $isOverdue = false;
        } else {
            $escalation = 'ON_TRACK';
            $badgeColor = 'emerald';
            $isOverdue = false;
        }

        return [
            'profile' => $profile,
            'target_hours' => $targetHours,
            'elapsed_hours' => $elapsedHours,
            'remaining_hours' => $remainingHours,
            'consumed_pct' => $consumedPct,
            'escalation' => $escalation,
            'badge_color' => $badgeColor,
            'is_overdue' => $isOverdue
        ];
    }
}
