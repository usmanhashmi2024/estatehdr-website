<?php
/**
 * Estate HDR - API Security & Idempotency Key Engine
 * Enterprise Layer: API Security, Scopes & Idempotency
 * 
 * Enforces granular API key scopes (orders:read, orders:create, assets:upload)
 * and guarantees request idempotency (duplicate prevention).
 */

class ApiKeyService {
    private static string $keysFile = __DIR__ . '/../../data/api_keys.json';
    private static string $idemFile = __DIR__ . '/../../data/idempotency_keys.json';

    public static function getApiKeys(): array {
        if (!file_exists(self::$keysFile)) {
            // Seed a default test key
            $defaults = [
                'ehdr_live_demo_key_99x' => [
                    'key_id' => 'key_demo_1',
                    'client_id' => 'USR-DEMO-101',
                    'client_name' => 'ABC Luxury Photography',
                    'organization_id' => 'org-estatehdr-default',
                    'scopes' => ['orders:read', 'orders:create', 'assets:upload', 'amendments:create'],
                    'rate_limit_per_min' => 120,
                    'is_active' => true,
                    'created_at' => '2026-01-01 00:00:00'
                ]
            ];
            @file_put_contents(self::$keysFile, json_encode($defaults, JSON_PRETTY_PRINT));
            return $defaults;
        }
        $data = json_decode(@file_get_contents(self::$keysFile), true) ?: [];
        return $data;
    }

    /**
     * Authenticate bearer token and check required scope
     */
    public static function authenticate(string $token, string $requiredScope): array {
        $keys = self::getApiKeys();
        if (!isset($keys[$token]) || empty($keys[$token]['is_active'])) {
            return ['authenticated' => false, 'error' => 'Invalid or inactive API key.'];
        }

        $keyData = $keys[$token];
        if (!in_array($requiredScope, $keyData['scopes'] ?? [], true)) {
            return [
                'authenticated' => false,
                'error' => "Forbidden: API key does not possess required scope '{$requiredScope}'."
            ];
        }

        return ['authenticated' => true, 'key_data' => $keyData];
    }

    /**
     * Check if request with Idempotency-Key has already executed
     */
    public static function getIdempotentResponse(string $idempotencyKey): ?array {
        if (!file_exists(self::$idemFile)) return null;
        $data = json_decode(@file_get_contents(self::$idemFile), true) ?: [];
        return $data[$idempotencyKey] ?? null;
    }

    /**
     * Cache response for Idempotency-Key
     */
    public static function saveIdempotentResponse(string $idempotencyKey, array $responsePayload): void {
        if (!file_exists(self::$idemFile)) {
            @file_put_contents(self::$idemFile, json_encode([], JSON_PRETTY_PRINT));
        }
        $data = json_decode(@file_get_contents(self::$idemFile), true) ?: [];
        $data[$idempotencyKey] = [
            'response' => $responsePayload,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        // Retain latest 500 keys
        if (count($data) > 500) $data = array_slice($data, -500);
        @file_put_contents(self::$idemFile, json_encode($data, JSON_PRETTY_PRINT));
    }
}
