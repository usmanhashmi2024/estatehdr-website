<?php
/**
 * Estate HDR — Enterprise Role-Based Access Control (RBAC) Engine
 * Blueprint & Master Upgrade Specification: 8 canonical roles with strict permission checks.
 */

class RBAC {
    public const ROLES = [
        // 1. CEO / Director / Owner
        'owner' => ['all' => true],
        'super_admin' => ['all' => true],
        'ceo' => ['all' => true],

        // 2. Production / Operations Manager
        'manager' => [
            'orders.read' => true, 'orders.update' => true, 'orders.assign' => true, 'orders.deliver' => true, 'orders.amend' => true,
            'users.read' => true, 'view_leads' => true, 'view_chats' => true, 'send_replies' => true, 'create_quotes' => true,
            'profile.self.update' => true, 'profile.avatar.update' => true
        ],
        'production_manager' => [
            'orders.read' => true, 'orders.update' => true, 'orders.assign' => true, 'orders.deliver' => true, 'orders.amend' => true,
            'users.read' => true, 'view_leads' => true, 'view_chats' => true, 'send_replies' => true, 'create_quotes' => true,
            'profile.self.update' => true, 'profile.avatar.update' => true
        ],

        // 3. Supervisor
        'supervisor' => [
            'orders.read' => true, 'orders.update' => true, 'orders.assign' => true, 'orders.deliver' => true, 'orders.amend' => true,
            'view_leads' => true, 'view_chats' => true, 'send_replies' => true,
            'profile.self.update' => true, 'profile.avatar.update' => true
        ],

        // 4. Team Lead (Privacy Shielded: Client contacts & rates masked)
        'team_lead' => [
            'orders.read' => true, 'orders.assign' => true, 'orders.update' => true,
            'approve_files' => true, 'write_internal_notes' => true,
            'profile.self.update' => true, 'profile.avatar.update' => true
        ],

        // 5. Photo Editor (Privacy Shielded: Client contacts & rates masked)
        'photo_editor' => [
            'orders.read' => true, 'orders.update' => true,
            'manage_files' => true,
            'profile.self.update' => true, 'profile.avatar.update' => true
        ],
        'editor' => [
            'orders.read' => true, 'orders.update' => true,
            'manage_files' => true,
            'profile.self.update' => true, 'profile.avatar.update' => true
        ],

        // 6. HR Department (Staff data only)
        'hr' => [
            'hr.read' => true, 'hr.manage' => true, 'users.read' => true,
            'profile.self.update' => true, 'profile.avatar.update' => true
        ],

        // 7. SEO & Content Manager (CMS only)
        'seo' => [
            'cms.publish' => true, 'seo.manage' => true,
            'profile.self.update' => true, 'profile.avatar.update' => true
        ],
        'seo_manager' => [
            'cms.publish' => true, 'seo.manage' => true,
            'profile.self.update' => true, 'profile.avatar.update' => true
        ],

        // 8. Client (Own data only)
        'client' => [
            'orders.read' => true, 'orders.create' => true, 'orders.amend' => true,
            'billing.read' => true,
            'profile.self.update' => true, 'profile.avatar.update' => true
        ],

        // Legacy compatibility mappings
        'country_manager'      => ['manage_country_agents' => true, 'view_leads' => true, 'view_chats' => true, 'send_replies' => true, 'create_quotes' => true],
        'sales_manager'        => ['view_leads' => true, 'assign_leads' => true, 'create_quotes' => true, 'view_chats' => true, 'send_replies' => true],
        'country_sales_agent'  => ['view_assigned_leads' => true, 'send_replies' => true, 'create_quotes' => true],
        'retouching_director'  => ['view_chats' => true, 'send_replies' => true, 'create_quotes' => true, 'manage_files' => true, 'write_internal_notes' => true],
        'technical_specialist' => ['view_chats' => true, 'send_replies' => true, 'manage_files' => true],
        'support_agent'        => ['view_chats' => true, 'send_replies' => true],
        'qa'                   => ['view_files' => true, 'approve_files' => true],
        'viewer'               => ['view_only' => true]
    ];

    public static function checkPermission(string $role, string $permission): bool {
        $cleanRole = strtolower(trim($role));
        if (!isset(self::ROLES[$cleanRole])) return false;
        $perms = self::ROLES[$cleanRole];
        if (!empty($perms['all'])) return true;
        return !empty($perms[$permission]);
    }
}
