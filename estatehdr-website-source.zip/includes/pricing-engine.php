<?php
/**
 * Estate HDR — Deterministic Server-Side Pricing Engine
 * PRD Section 9: Server-authoritative calculations with line items, volume discounts, currency conversions & Quote IDs.
 * AI never invents pricing; it strictly delegates to this engine.
 * 
 * Special Promotional Tier Active:
 * - Regular HDR rate: $0.80 / photo
 * - Promotional HDR rate: $0.60 / photo (Save 25%)
 * - Tiered Volume Discounts:
 *     1–24 photos:  $0.60 / photo
 *     25–49 photos: $0.55 / photo
 *     50–99 photos: $0.50 / photo
 *     100+ photos:  $0.45 / photo
 * - Complementary Perk: 1 FREE Day-to-Dusk (Virtual Twilight) Hero Photo with EVERY single property order!
 */

class PricingEngine {
    public const REGULAR_RATES = [
        'hdr'          => 0.80, // USD per photo standard
        'staging'      => 8.00, // USD per room
        'twilight'     => 4.00, // USD per photo
        'item_removal' => 2.00, // USD per photo
        'floorplan_2d' => 12.00, // USD per plan
        'floorplan_3d' => 20.00, // USD per plan
        'video_4k'     => 35.00, // USD per property
    ];

    public const BASE_RATES = [
        'hdr'          => 0.60, // Promotional USD per photo (slashed from $0.80)
        'staging'      => 8.00, // USD per room
        'twilight'     => 4.00, // USD per photo
        'item_removal' => 2.00, // USD per photo
        'floorplan_2d' => 12.00, // USD per plan
        'floorplan_3d' => 20.00, // USD per plan
        'video_4k'     => 35.00, // USD per property
    ];

    public const CURRENCIES = [
        'USD' => ['symbol' => '$',   'rate' => 1.00],
        'GBP' => ['symbol' => '£',   'rate' => 0.78],
        'EUR' => ['symbol' => '€',   'rate' => 0.92],
        'AUD' => ['symbol' => 'A$',  'rate' => 1.52],
        'CAD' => ['symbol' => 'C$',  'rate' => 1.36],
        'AED' => ['symbol' => 'AED ', 'rate' => 3.67],
    ];

    /**
     * Calculate authoritative quote
     *
     * @param string $service Service key ('hdr', 'staging', 'twilight', etc.)
     * @param int $quantity Quantity of units
     * @param string $currency Currency code (USD, GBP, EUR, AUD, CAD, AED)
     * @param bool $isRush 12-Hour Rush Turnaround requested (+25%)
     * @param string|null $promoCode Optional promotional code
     * @return array Complete Quote Object with calculation breakdown and Quote UUID
     */
    public static function calculateQuote(string $service, int $quantity = 1, string $currency = 'USD', bool $isRush = false, ?string $promoCode = null): array {
        $service = strtolower(trim($service));
        $quantity = max(1, $quantity);
        $currency = strtoupper(trim($currency));
        if (!isset(self::CURRENCIES[$currency])) {
            $currency = 'USD';
        }

        $rateInfo = self::CURRENCIES[$currency];
        $fxRate = $rateInfo['rate'];
        $sym = $rateInfo['symbol'];

        $regularUnitRateUsd = self::REGULAR_RATES[$service] ?? 0.80;
        $unitPriceUsd = self::BASE_RATES[$service] ?? self::BASE_RATES['hdr'];

        // Tiered Volume Pricing & Discounts
        $discountPct = 0;
        $freeDayToDuskIncluded = false;

        if ($service === 'hdr') {
            $freeDayToDuskIncluded = true;
            // Tiered volume discount schedule:
            // 1-24:  $0.60 (was $0.80) -> 25% off regular $0.80
            // 25-49: $0.55 (was $0.75) -> 31% off regular $0.80
            // 50-99: $0.50 (was $0.70) -> 37.5% off regular $0.80
            // 100+:  $0.45 (was $0.65) -> 43.8% off regular $0.80
            if ($quantity >= 100) {
                $unitPriceUsd = 0.45;
                $discountPct = 25; // 25% off the $0.60 base
            } elseif ($quantity >= 50) {
                $unitPriceUsd = 0.50;
                $discountPct = 16.67; // ~$0.10 off $0.60 base
            } elseif ($quantity >= 25) {
                $unitPriceUsd = 0.55;
                $discountPct = 8.33; // ~$0.05 off $0.60 base
            } else {
                $unitPriceUsd = 0.60;
                $discountPct = 0;
            }
        } elseif ($service === 'staging' && $quantity >= 5) {
            $discountPct = 10;
        }

        $subtotalUsd = $unitPriceUsd * $quantity;
        $regularSubtotalUsd = $regularUnitRateUsd * $quantity;
        $discountAmountUsd = ($subtotalUsd * $discountPct) / 100.0;
        $netAfterDiscountUsd = $subtotalUsd; // Direct net unit price already applies tiered rate for HDR

        // 12-Hour Urgent Rush SLA (+25%)
        $rushSurchargeUsd = 0.0;
        if ($isRush) {
            $rushSurchargeUsd = $netAfterDiscountUsd * 0.25;
        }

        $totalUsd = $netAfterDiscountUsd + $rushSurchargeUsd;
        $totalSavingsUsd = max(0.0, ($regularSubtotalUsd - $netAfterDiscountUsd)) + ($freeDayToDuskIncluded ? 4.00 : 0.0);

        // Convert to target currency
        $unitPriceLocal = round($unitPriceUsd * $fxRate, 2);
        $regularUnitPriceLocal = round($regularUnitRateUsd * $fxRate, 2);
        $subtotalLocal = round($subtotalUsd * $fxRate, 2);
        $regularSubtotalLocal = round($regularSubtotalUsd * $fxRate, 2);
        $discountLocal = round($discountAmountUsd * $fxRate, 2);
        $rushLocal = round($rushSurchargeUsd * $fxRate, 2);
        $totalLocal = round($totalUsd * $fxRate, 2);
        $totalSavingsLocal = round($totalSavingsUsd * $fxRate, 2);

        $quoteId = 'QTE-' . date('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
        $validUntil = date('Y-m-d', strtotime('+14 days'));

        $serviceTitles = [
            'hdr'          => 'Hand-Blended HDR Photo Retouching (Was $0.80 -> Now $0.60)',
            'staging'      => '3D Virtual Staging & Designer Furnishing',
            'twilight'     => 'Day to Dusk / Virtual Sunset Twilight Conversion',
            'item_removal' => 'Item Removal, Decluttering & Object Erase',
            'floorplan_2d' => '2D Black/White & Color Floor Plan Schematic',
            'floorplan_3d' => '3D Textured Architectural Floor Plan',
            'video_4k'     => '4K Real Estate Cinematic Video Editing Showcase',
        ];

        return [
            'quote_id'               => $quoteId,
            'service'                => $service,
            'service_title'          => $serviceTitles[$service] ?? 'Professional Retouching Service',
            'quantity'               => $quantity,
            'unit_name'              => ($service === 'staging' ? 'room(s)' : ($service === 'video_4k' ? 'video(s)' : 'photo(s)')),
            'currency'               => $currency,
            'currency_symbol'        => $sym,
            'unit_price'             => $unitPriceLocal,
            'regular_unit_price'     => $regularUnitPriceLocal,
            'is_promo_active'        => ($service === 'hdr'),
            'promo_tag'              => 'Limited Time Agency Offer: Was $0.80 -> Now $0.60/photo',
            'subtotal'               => $subtotalLocal,
            'regular_subtotal'       => $regularSubtotalLocal,
            'discount_pct'           => $discountPct,
            'discount_amount'        => $discountLocal,
            'is_rush'                => $isRush,
            'rush_surcharge'         => $rushLocal,
            'total_amount'           => $totalLocal,
            'formatted_total'        => $sym . number_format($totalLocal, 2),
            'total_savings'          => $totalSavingsLocal,
            'formatted_savings'      => $sym . number_format($totalSavingsLocal, 2),
            'free_day_to_dusk'       => $freeDayToDuskIncluded,
            'free_day_to_dusk_text'  => $freeDayToDuskIncluded ? '🎁 1 FREE Day-to-Dusk (Virtual Twilight) Hero Photo included on every property ($0.00)' : '',
            'turnaround_sla'         => $isRush ? 'Guaranteed 12-Hour Urgent Rush' : 'Guaranteed 24-Hour Standard Delivery',
            'free_revisions'         => 'Unlimited Free Revisions (2-4h turnaround)',
            'valid_until'            => $validUntil,
            'is_free_trial_eligible' => ($quantity <= 3),
            'calculation_inputs'     => [
                'base_rate_usd'    => $unitPriceUsd,
                'regular_rate_usd' => $regularUnitRateUsd,
                'fx_rate'          => $fxRate,
                'quantity'         => $quantity,
                'is_rush'          => $isRush
            ]
        ];
    }
}
