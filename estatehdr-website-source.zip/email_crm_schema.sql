-- =====================================================================
-- Estate HDR — Email Automation CRM MySQL Schema
-- Generated according to PRD / TRD Part C.3 for Hostinger / MariaDB
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- 1. Contacts Database
CREATE TABLE IF NOT EXISTS `crm_contacts` (
  `id` VARCHAR(50) NOT NULL,
  `email` VARCHAR(191) NOT NULL,
  `first_name` VARCHAR(100) DEFAULT '',
  `last_name` VARCHAR(100) DEFAULT '',
  `phone` VARCHAR(50) DEFAULT '',
  `company` VARCHAR(150) DEFAULT '',
  `status` ENUM('subscribed', 'pending', 'unsubscribed', 'bounced') NOT NULL DEFAULT 'subscribed',
  `score` INT NOT NULL DEFAULT 50,
  `source` VARCHAR(100) DEFAULT 'Website Form',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_crm_contacts_email` (`email`),
  KEY `idx_crm_contacts_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Tags Table
CREATE TABLE IF NOT EXISTS `crm_tags` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Contact Tags Pivot
CREATE TABLE IF NOT EXISTS `crm_contact_tags` (
  `contact_id` VARCHAR(50) NOT NULL,
  `tag_name` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`contact_id`, `tag_name`),
  KEY `idx_tag_name` (`tag_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Campaigns Table
CREATE TABLE IF NOT EXISTS `crm_campaigns` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `subject` VARCHAR(255) NOT NULL,
  `preview_text` VARCHAR(255) DEFAULT '',
  `target_tag` VARCHAR(100) DEFAULT 'all',
  `status` ENUM('draft', 'scheduled', 'sending', 'sent') NOT NULL DEFAULT 'draft',
  `content_html` LONGTEXT,
  `scheduled_at` DATETIME NULL,
  `sent_at` DATETIME NULL,
  `stats_json` JSON NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_crm_campaigns_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Automations (Workflows) Table
CREATE TABLE IF NOT EXISTS `crm_automations` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `status` ENUM('active', 'paused') NOT NULL DEFAULT 'active',
  `trigger_type` VARCHAR(50) NOT NULL DEFAULT 'new_signup',
  `trigger_config_json` JSON NULL,
  `steps_json` JSON NULL,
  `enrollments_count` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Automation Enrollments
CREATE TABLE IF NOT EXISTS `crm_automation_enrollments` (
  `id` VARCHAR(60) NOT NULL,
  `automation_id` VARCHAR(50) NOT NULL,
  `contact_id` VARCHAR(50) NOT NULL,
  `current_step` INT NOT NULL DEFAULT 0,
  `status` ENUM('active', 'completed', 'cancelled') NOT NULL DEFAULT 'active',
  `next_run_at` DATETIME NOT NULL,
  `enrolled_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_enrollment_queue` (`status`, `next_run_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Forms Table
CREATE TABLE IF NOT EXISTS `crm_forms` (
  `id` VARCHAR(50) NOT NULL,
  `name` VARCHAR(191) NOT NULL,
  `target_tag` VARCHAR(100) DEFAULT 'lead',
  `redirect_url` VARCHAR(255) DEFAULT '/thank-you',
  `submits_count` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Analytics Events Log
CREATE TABLE IF NOT EXISTS `crm_events` (
  `id` VARCHAR(60) NOT NULL,
  `type` VARCHAR(50) NOT NULL,
  `contact_id` VARCHAR(50) NOT NULL,
  `campaign_id` VARCHAR(50) NULL,
  `automation_id` VARCHAR(50) NULL,
  `meta_json` JSON NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_crm_events_contact` (`contact_id`),
  KEY `idx_crm_events_campaign` (`campaign_id`),
  KEY `idx_crm_events_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
