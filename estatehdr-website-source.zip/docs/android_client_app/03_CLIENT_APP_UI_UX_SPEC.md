# 🎨 UI/UX Design Specification & Style Guide
# Estate HDR — Client Android Application
> **Document Version:** 2.0.0  
> **Aesthetic Theme:** Soft Lavender Soft-Glass Luxury (`#EDEEF7` / `#5B6BF8` / `#FFFFFF` / `#0A0A0F`)  
> **Target Devices:** Android Handsets (e.g. Galaxy S24 Ultra, Pixel 9 Pro) & Foldables (Z Fold 6)  
> **Lead Designer:** Principal Mobile Design Architect  

---

## 📑 Table of Contents
1. [Design Philosophy & Aesthetic Vision](#1-design-philosophy--aesthetic-vision)
2. [Complete Design Tokens & System](#2-complete-design-tokens--system)
3. [Global Component Library Anatomy](#3-global-component-library-anatomy)
4. [Screen-by-Screen Wireframes & Layout Specs](#4-screen-by-screen-wireframes--layout-specs)
5. [Micro-Interactions, Haptics & 60-120 FPS Physics](#5-micro-interactions-haptics--60-120-fps-physics)
6. [Foldable & Tablet Responsive Adaptation](#6-foldable--tablet-responsive-adaptation)

---

## 1. Design Philosophy & Aesthetic Vision

The Estate HDR Client App diverges from generic, dark developer dashboards by embracing a **Soft Lavender Soft-Glass Luxury** aesthetic inspired by modern architectural and property management interfaces.

```
Key Visual Attributes:
• Background: Airy, soothing Soft Lavender (#EDEEF7) that makes photo proofs visually pop.
• Cards: Crisp pure white (#FFFFFF) with generous 16dp/24dp radii and soft indigo drop-shadows.
• Primary Accent: Confident Electric Indigo (#5B6BF8) for interactive pills, buttons, and badges.
• Luxury Accent: Warm Architectural Gold (#C9A84C) reserved for Before/After splitters and VIP tags.
• Typography: Plus Jakarta Sans & Inter for clinical, ultra-crisp legibility.
```

---

## 2. Complete Design Tokens & System

### 2.1 Color Palette

| Token Name | Hex Code | RGB | Role / Usage |
| :--- | :--- | :--- | :--- |
| **`bg-canvas`** | `#EDEEF7` | `237, 238, 247` | Screen background canvas across all primary screens. |
| **`surface-white`** | `#FFFFFF` | `255, 255, 255` | Primary card background, bottom sheets, input fields. |
| **`primary-indigo`**| `#5B6BF8` | `91, 107, 248` | Primary CTA buttons, active tab indicators, focus rings. |
| **`primary-dark`** | `#4553D8` | `69, 83, 216` | Pressed button state, active pill hover. |
| **`luxury-gold`** | `#C9A84C` | `201, 168, 76` | Before/After split slider bar, VIP Free Trial badge. |
| **`text-headline`** | `#14142B` | `20, 20, 43` | Screen titles, property names, primary headings. |
| **`text-body`** | `#4E4B66` | `78, 75, 102` | Subtitles, descriptions, secondary metadata. |
| **`text-muted`** | `#8E8E93` | `142, 142, 147` | Timestamps, placeholder labels, disabled items. |
| **`accent-green`** | `#A8D060` | `168, 208, 96` | 'FOR SALE' status badge, completed checkmark, live orders. |
| **`accent-rose`** | `#E53E6B` | `229, 62, 107` | Notification badge dot, rush priority chip, errors. |
| **`border-subtle`** | `#E2E8F0` | `226, 232, 240` | 1dp card borders, divider lines, sheet handles. |

### 2.2 Typography Scale (Plus Jakarta Sans / Inter)

```
• Display 1:   28sp | Line-Height: 36sp | Weight: 800 (ExtraBold) -> Hero Metrics, Welcome Back
• Title 1:     22sp | Line-Height: 28sp | Weight: 700 (Bold)      -> Screen Headers, Modal Titles
• Title 2:     18sp | Line-Height: 24sp | Weight: 600 (SemiBold)  -> Card Titles, Property Names
• Body Bold:   15sp | Line-Height: 20sp | Weight: 600 (SemiBold)  -> Button Labels, Status Badges
• Body Normal: 14sp | Line-Height: 20sp | Weight: 400 (Regular)   -> Descriptions, Instructions
• Caption:     12sp | Line-Height: 16sp | Weight: 600 (SemiBold)  -> Timestamps, Tags, EXIF Data
• Micro:       10sp | Line-Height: 12sp | Weight: 700 (Bold)      -> Status Pills, Count Badges
```

### 2.3 Elevation & Shadow Hierarchy
- **Card Shadow:** `0dp 4dp 24dp rgba(91, 107, 248, 0.10)` (Soft indigo dispersion)
- **Floating Pill Nav Shadow:** `0dp 8dp 32dp rgba(20, 20, 43, 0.18)`
- **Modal Bottom Sheet Shadow:** `0dp -8dp 40dp rgba(0, 0, 0, 0.22)`

---

## 3. Global Component Library Anatomy

### 3.1 The Floating Pill Bottom Navigation Bar
Elevated 24dp above the screen bottom, floating over content:

```
┌────────────────────────────────────────────────────────┐
│  [🏠 Home]    [🔍 Orders]    [➕]    [🖼️ Proofs]    [👤 Me]  │
└────────────────────────────────────────────────────────┘
```
- **Container:** Rounded capsule `radius = 999dp`, background `#0A0A0F` (Obsidian), width 92% of screen.
- **Center Action Button (`+`):** Electric Indigo circle `#5B6BF8` with white plus icon; triggers 60-second wizard.
- **Active State:** Icon switches to `#5B6BF8` with a subtle 4dp glow dot underneath.
- **Haptic:** `HapticFeedbackType.TextHandleMove` fired on tab switch.

### 3.2 2x2 Property & Metrics Matrix
```
┌──────────────────────────────┬──────────────────────────────┐
│ 📋 ACTIVE ORDERS             │ ✨ READY PROOFS              │
│ 4 Properties                 │ 2 Ready for Review           │
│ [24h SLA Running...]         │ [Tap to Inspect Proofs ➔]    │
├──────────────────────────────┼──────────────────────────────┤
│ 🏆 DELIVERED TOTAL           │ ⏱️ AVG TURNAROUND            │
│ 156 Master Properties        │ 18.2 Hours                   │
│ [99.4% On-Time SLA]          │ [100% Retouching Guarantee]  │
└──────────────────────────────┴──────────────────────────────┘
```

### 3.3 Dual-Handle Price Range Bottom Sheet
```
┌────────────────────────────────────────────────────────┐
│                      ── Handle ──                      │
│ Price Range                                            │
│                                                        │
│  [|||  |||||  ||||||||||  ||||||||  |||||  |||  |]    │  <- Histogram
│  ═══════════●════════════════════════●════════════     │  <- Dual Slider
│                                                        │
│  ┌──────────────────────┐    ┌──────────────────────┐  │
│  │ Minimum              │    │ Maximum              │  │
│  │ $15.00               │    │ $120.00              │  │
│  └──────────────────────┘    └──────────────────────┘  │
│                                                        │
│  [ Toggle ] Include Rush Turnaround Priority (+25%)    │
│                                                        │
│  ┌──────────────────────────────────────────────────┐  │
│  │          See 14 Available Packages               │  │  <- Pill CTA
│  └──────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────┘
```

---

## 4. Screen-by-Screen Wireframes & Layout Specs

### Screen 1: Home Dashboard (Property Manager Hub)
```
┌────────────────────────────────────────────────────────┐
│ [Avatar] Good Morning, Marcus!                   [🔔3] │
│ Vance Architectural Media • Pro Member                 │
├────────────────────────────────────────────────────────┤
│ ┌────────────────────────────────────────────────────┐ │
│ │ 📋 2x2 METRIC MATRIX                               │ │
│ │ Active: 4        Ready: 2                          │ │
│ │ Delivered: 156   Avg SLA: 18.2h                    │ │
│ └────────────────────────────────────────────────────┘ │
│                                                        │
│ ┌────────────────────────────────────────────────────┐ │
│ │ ⚡ CURRENT PRODUCTION SLA COUNTDOWN                 │ │
│ │ ORD-5006: 742 Evergreen Terrace                    │ │
│ │ 35 Photos • HDR Photo Fusion                       │ │
│ │ [======== 14 Hours Remaining ========]             │ │
│ └────────────────────────────────────────────────────┘ │
│                                                        │
│ RECENT PROPERTIES & PROOFS                             │
│ ┌────────────────────────────────────────────────────┐ │
│ │ [Photo Preview]  Pageant Place Estate              │ │
│ │ 24 Photos • Delivered 2h ago                       │ │
│ │ Status: [✨ READY FOR APPROVAL]       $68.60       │ │
│ └────────────────────────────────────────────────────┘ │
│ ┌────────────────────────────────────────────────────┐ │
│ │ [Photo Preview]  Whispering Pines Villa            │ │
│ │ 42 Photos • In Retouching Pipeline                 │ │
│ │ Status: [⏳ IN PRODUCTION]             $84.00       │ │
│ └────────────────────────────────────────────────────┘ │
└────────────────────────────────────────────────────────┘
```

### Screen 2: 60-Second Order Placement Wizard
```
┌────────────────────────────────────────────────────────┐
│ [ < Back ]             New Retouching Order            │
├────────────────────────────────────────────────────────┤
│ 1. PROPERTY DETAILS                                    │
│ [ Property Address / Listing Name                    ] │
│                                                        │
│ 2. CLOUD RAW BRACKET LINK                              │
│ ┌────────────────────────────────────────────────────┐ │
│ │ 📎 Paste Google Drive, Dropbox, or WeTransfer Link │ │
│ │ [ https://dropbox.com/scl/fo/abc123xyz...        ] │ │
│ │ ✓ Detected: Dropbox Folder (Valid Public Access)   │ │
│ └────────────────────────────────────────────────────┘ │
│                                                        │
│ 3. SELECT SERVICE TIER                                 │
│ ┌─────────────────┐ ┌─────────────────┐ ┌────────────┐ │
│ │ HDR Fusion      │ │ Flambient       │ │ Virtual    │ │
│ │ $0.80 / photo   │ │ $1.25 / photo   │ │ Staging $18│ │
│ │ [ SELECTED ✓ ]  │ │ [ Select ]      │ │ [ Select ] │ │
│ └─────────────────┘ └─────────────────┘ └────────────┘ │
│                                                        │
│ 4. BRACKET SIZE & QUANTITY                             │
│ Exposures:  ( ) 3-Bracket   (•) 5-Bracket   ( ) Flash  │
│ Number of Final Photos: [ - ]  35  [ + ]               │
│                                                        │
│ 5. TURNAROUND SPEED                                    │
│ [•] Standard (24 Hours - Included)                     │
│ [ ] Rush Priority (12 Hours - +$15.00)                 │
│                                                        │
│ ┌────────────────────────────────────────────────────┐ │
│ │ ESTIMATED TOTAL: $26.60 USD                        │ │
│ │ ┌────────────────────────────────────────────────┐ │ │
│ │ │           SUBMIT ORDER & START SLA ➔           │ │ │
│ │ └────────────────────────────────────────────────┘ │ │
│ └────────────────────────────────────────────────────┘ │
└────────────────────────────────────────────────────────┘
```

### Screen 3: Interactive Before/After Proof Studio
```
┌────────────────────────────────────────────────────────┐
│ [ < Back ]  Pageant Place Estate (Photo 2 of 24) [ ⋯ ] │
├────────────────────────────────────────────────────────┤
│                                                        │
│                 BEFORE / AFTER SPLIT                   │
│                                                        │
│         RAW BRACKET       │       RETOUCHED MASTER     │
│                           │                            │
│                           ●                            │
│                           │                            │
│      [Pinch to zoom up to 400% synchronized]           │
│                                                        │
├────────────────────────────────────────────────────────┤
│ [ 🔍 100% Zoom ]  [ ☀️ EXIF Data ]  [ 🔄 Toggle Full ] │
├────────────────────────────────────────────────────────┤
│ ┌──────────────────────────┐┌────────────────────────┐ │
│ │ 💬 Request Revision (Pin)││ ✓ Approve & Save MLS   │ │
│ └──────────────────────────┘└────────────────────────┘ │
└────────────────────────────────────────────────────────┘
```

### Screen 4: Pin-Point Visual Revision Tool
```
┌────────────────────────────────────────────────────────┐
│ [ Cancel ]              Drop Revision Pin     [ Save ] │
├────────────────────────────────────────────────────────┤
│                                                        │
│             [ Full Retouched Master Image ]            │
│                                                        │
│                        📍 [Pulsing Gold Pin]           │
│                           (X: 68%, Y: 42%)             │
│                                                        │
├────────────────────────────────────────────────────────┤
│ QUICK TAGS:                                            │
│ [✓ Pull Windows] [ Remove Glare ] [ Grass Greener ]    │
│                                                        │
│ WRITTEN INSTRUCTION:                                   │
│ [ The garden outside the window has dark shadows.   ]  │
│ [ Please balance exterior foliage exposure.         ]  │
│                                                        │
│ VOICE INSTRUCTION (OPTIONAL):                          │
│ [ 🎙️ Hold to Record Audio Note (0:14 / 1:00) ]        │
│                                                        │
│ [ SUBMIT REVISION (UNLIMITED & $0.00 FREE GUARANTEE) ] │
└────────────────────────────────────────────────────────┘
```

---

## 5. Micro-Interactions, Haptics & 60-120 FPS Physics

1. **Before/After Split Slider:**
   - Velocity tracking with Spring Deceleration curve (`stiffness = 300f`, `dampingRatio = 0.75f`).
   - Haptic feedback fires when slider crosses center (50% mark).
2. **Pin-Point Coordinate Drop:**
   - Spring pop animation (`scale = 0f -> 1.2f -> 1.0f`).
   - Ripple beacon pulse radiating around pin tip.
3. **Order Placement Success:**
   - Button transforms into circular loading spinner -> Burst checkmark with subtle device vibration -> Golden confetti particle explosion.
4. **Shimmer Skeleton Loading:**
   - Subtle lavender-to-white gradient sweep across order cards while fetching from Room/API.

---

## 6. Foldable & Tablet Responsive Adaptation

For **Samsung Galaxy Z Fold 6** and tablets:
- In unfolded tablet mode (> 600dp width):
  - Dashboard converts to a **Dual-Pane Layout**: Left 35% displays active properties list; Right 65% displays the full Before/After Proof Studio.
  - Wizard converts into a seamless two-column form with live price summary updating instantly in the right rail.
