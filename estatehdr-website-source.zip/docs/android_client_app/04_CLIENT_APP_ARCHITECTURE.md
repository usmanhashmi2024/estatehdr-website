# 🏛️ System Architecture & Data Flow Documentation
# Estate HDR — Client Android Application
> **Document Version:** 2.0.0  
> **Architecture Pattern:** Clean Architecture + MVI (Model-View-Intent) + Offline-First SSOT  
> **System Scope:** Client Android App, Cloud Gateway, API Engine & Dual-Store Backend  
> **Lead Architect:** Principal Systems & Mobile Architect  

---

## 📑 Table of Contents
1. [End-to-End Infrastructure Topology](#1-end-to-end-infrastructure-topology)
2. [Android Clean Architecture Deep Dive](#2-android-clean-architecture-deep-dive)
3. [Core Data Flow & Sequence Diagrams](#3-core-data-flow--sequence-diagrams)
   - [3.1 Order Creation & Idempotency Flow](#31-order-creation--idempotency-flow)
   - [3.2 Proof Delivery & Push Notification Flow](#32-proof-delivery--push-notification-flow)
   - [3.3 Visual Pin-Point Amendment Flow](#33-visual-pin-point-amendment-flow)
   - [3.4 Offline-First Synchronization Flow](#34-offline-first-synchronization-flow)
   - [3.5 Multi-Threaded Batch Download Pipeline](#35-multi-threaded-batch-download-pipeline)
4. [State Management & Unidirectional Data Flow (UDF)](#4-state-management--unidirectional-data-flow-udf)
5. [Storage, Caching & Memory Management](#5-storage-caching--memory-management)

---

## 1. End-to-End Infrastructure Topology

The Estate HDR client ecosystem connects the native mobile client to high-performance web and storage tiers:

```
┌────────────────────────────────────────────────────────────────────────┐
│                      NATIVE ANDROID CLIENT (KOTLIN)                    │
│   Jetpack Compose • Room Encrypted DB • WorkManager • Coil Engine      │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ TLS 1.3 / Certificate Pinning
┌───────────────────────────────────▼────────────────────────────────────┐
│                    CLOUDFLARE EDGE WAF & CDN                           │
│   DDoS Mitigation • Turnstile Verification • Geo-Routing • Rate Limits │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ Reverse Proxy
┌───────────────────────────────────▼────────────────────────────────────┐
│                HOSTINGER CLOUD / APACHE & LITESPEED GATEWAY            │
│   HTTP Security Headers • HSTS • Nonce Enforcement • URL Routing       │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ REST API Routing
┌───────────────────────────────────▼────────────────────────────────────┐
│                    ESTATE HDR PHP 8.2 API ENGINE                       │
│   Auth & RBAC (`auth.php`) • Order Processor • Amendment Engine        │
│   Quote Calculator • Anti-Bot Provider • System Health Observability   │
└───────────────────┬────────────────────────────────┬───────────────────┘
                    │                                │
┌───────────────────▼──────────────┐  ┌──────────────▼───────────────────┐
│     ATOMIC STORAGE ENGINE        │  │     THIRD-PARTY SERVICES         │
│  data/orders/*.json              │  │  Firebase Cloud Messaging (FCM)  │
│  data/ledger.json (Double-Entry) │  │  PayPal IPN & REST API           │
│  data/users.json (Staff & Client)│  │  Hostinger SMTP Enterprise Mail  │
│  File-Locking (`LOCK_EX`) Safety │  │  Cloud Object Storage (Proofs)   │
└──────────────────────────────────┘  └──────────────────────────────────┘
```

---

## 2. Android Clean Architecture Deep Dive

Every functional epic in the Android client app strictly respects the three-layer clean architecture boundaries:

```
                  ┌─────────────────────────────────┐
                  │       PRESENTATION LAYER        │
                  │  Composables (UI Screens)       │
                  │  MVI ViewModels                 │
                  │  UiState / UiIntent / UiEffect  │
                  └───────────────┬─────────────────┘
                                  │ Direct Dependency
                                  ▼
                  ┌─────────────────────────────────┐
                  │          DOMAIN LAYER           │
                  │  UseCases (Pure Business Logic) │
                  │  Domain Entities (Pure Models)  │
                  │  Repository Interfaces          │
                  └───────────────▲─────────────────┘
                                  │ Inverted Dependency
                                  │ (Implements Interfaces)
                  ┌───────────────┴─────────────────┐
                  │           DATA LAYER            │
                  │  Repository Implementations     │
                  │  Room Database (Local Cache)    │
                  │  Retrofit Services (Remote API) │
                  │  WorkManager Background Tasks   │
                  └─────────────────────────────────┘
```

### 2.1 Layer Responsibilities

1. **Presentation Layer:**
   - **Composables:** Completely stateless; render solely based on incoming `UiState` and dispatch user interactions via `UiIntent` callbacks.
   - **ViewModels:** Maintain a single immutable `StateFlow<UiState>`, handle screen lifecycles, and emit one-off side effects (e.g. snackbars, navigation) through `Channel<UiEffect>`.

2. **Domain Layer:**
   - **Zero Android Framework Dependencies:** Pure Kotlin module, completely testable via standard JVM unit tests.
   - **UseCases:** Single-responsibility interactors (e.g. `SubmitPinAmendmentUseCase`, `GetLiveOrdersUseCase`).

3. **Data Layer:**
   - **Single Source of Truth (SSOT):** The UI observes database streams (`Flow<List<OrderEntity>>`). Network responses populate Room, which automatically pushes updates to the UI.

---

## 3. Core Data Flow & Sequence Diagrams

### 3.1 Order Creation & Idempotency Flow
```
User (App)            WizardViewModel       OrdersRepository        Estate HDR API
    │                       │                       │                      │
    │── Taps 'Submit Order' ─>                      │                      │
    │                       │── Generate UUID ─────>│                      │
    │                       │   (Idempotency-Key)   │                      │
    │                       │                       │── POST /api/v1/orders ->
    │                       │                       │   [Bearer Token +    │
    │                       │                       │    Idempotency-Key]  │
    │                       │                       │                      │── Validate Cloud Link
    │                       │                       │                      │── Apply Tier Pricing
    │                       │                       │                      │── Atomic Write JSON
    │                       │                       │                      │── Start SLA Timer (24h)
    │                       │                       │<─ 201 Created ───────│
    │                       │                       │   [Order Data]       │
    │                       │                       │                      │
    │                       │                       │── Save to Room DB ──>│
    │                       │<─ Success Result ─────│                      │
    │<─ Haptic + Confetti ──│                       │                      │
```

### 3.2 Proof Delivery & Push Notification Flow
```
Estate HDR Studio         Firebase FCM          Android OS           Client App
    │                          │                    │                    │
    │── QA Approves Proofs ───>│                    │                    │
    │── Trigger Push Alert ───>│                    │                    │
    │                          │── High-Priority ──>│                    │
    │                          │   Data Notification│                    │
    │                          │                    │── Wakeup Worker ──>│
    │                          │                    │                    │── Pre-fetch Proof
    │                          │                    │                    │   Thumbnails to Cache
    │                          │                    │<─ Show System ─────│
    │                          │                    │   Notification     │
    │                          │                    │                    │
    │                          │                    │── User Taps Alert ─>
    │                          │                    │                    │── Deep Link directly
    │                          │                    │                    │   to Before/After Studio
```

### 3.3 Visual Pin-Point Amendment Flow
```
User (Proof Studio)       ViewerViewModel      AmendmentRepository    Estate HDR API
    │                           │                       │                   │
    │── Taps point on photo ───>│                       │                   │
    │   (Normalized X:0.68, Y:0.41)                     │                   │
    │── Enters text + audio ───>│                       │                   │
    │── Taps 'Submit Revision' ─>                       │                   │
    │                           │── Create Temp Local ─>│                   │
    │                           │   Amendment (Pending) │                   │
    │                           │                       │── Multipart POST ─>
    │                           │                       │   /orders/id/amendments
    │                           │                       │                   │── Assert Free Revision
    │                           │                       │                   │   Guarantee ($0.00)
    │                           │                       │                   │── Notify Team Lead
    │                           │                       │                   │── Reset QA SLA (3h)
    │                           │                       │<─ 201 Created ────│
    │                           │                       │                   │
    │                           │                       │── Update Room ───>│
    │<─ Show Revision Track Bar │                       │   (Status: Active)│
```

### 3.4 Offline-First Synchronization Flow
```
Network State          Room Database        SyncWorker          Estate HDR API
    │                        │                   │                     │
    │── Cellular drops ─────>│                   │                     │
    │   (Network: DISCONNECTED)                  │                     │
    │                        │                   │                     │
    │── User places order ──>│ [Store in Room    │                     │
    │                        │  is_synced = 0]   │                     │
    │                        │                   │                     │
    │── 4G Restored ────────>│                   │                     │
    │   (Network: CONNECTED) │                   │                     │
    │                        │                   │── Trigger Sync ────>│
    │                        │<─ Fetch unsynced ─│                     │
    │                        │   orders/amends   │                     │
    │                        │                   │── POST Pending ────>│
    │                        │                   │   Mutations         │
    │                        │                   │<─ 200 OK Response ──│
    │                        │<─ Set is_synced=1 │                     │
```

### 3.5 Multi-Threaded Batch Download Pipeline
```
User (Gallery)         DownloadViewModel     BatchDownloadWorker    MediaStore (Gallery)
    │                         │                       │                     │
    │── Taps 'Save MLS Batch' >                       │                     │
    │                         │── Enqueue WorkManager │                     │
    │                         │   Request with ID     │                     │
    │                         │                       │── Request Signed ──> [API Server]
    │                         │                       │   Archive URL       │
    │                         │                       │<─ ZIP Stream ───────│
    │                         │                       │                     │
    │                         │                       │── Extract WebP      │
    │                         │                       │   Files in memory   │
    │                         │                       │── Checksum Verify   │
    │                         │                       │                     │
    │                         │                       │── Insert Content ──>│
    │                         │                       │   Values into       │
    │                         │                       │   Pictures/EstateHDR│
    │                         │<─ Progress (65%) ─────│                     │
    │<─ Live Progress Bar ────│                       │                     │
    │                         │<─ Completed ──────────│── Finalize URIs ───>│
    │<─ Toast: 'Saved to Roll'│                       │                     │
```

---

## 4. State Management & Unidirectional Data Flow (UDF)

The application enforces strict **MVI (Model-View-Intent)** architecture:

```kotlin
// 1. Immutable UI State
data class OrderListUiState(
    val isLoading: Boolean = false,
    val orders: List<Order> = emptyList(),
    val activeFilter: OrderFilter = OrderFilter.ALL,
    val searchQuery: String = "",
    val errorMessage: String? = null
)

// 2. User Intent Actions
sealed interface OrderListIntent {
    data class ChangeFilter(val filter: OrderFilter) : OrderListIntent
    data class SearchQueryChanged(val query: String) : OrderListIntent
    data class RefreshOrders(val forceRemote: Boolean) : OrderListIntent
    data class CancelOrder(val orderId: String) : OrderListIntent
}

// 3. One-off Side Effects
sealed interface OrderListEffect {
    data class NavigateToDetails(val orderId: String) : OrderListEffect
    data class ShowToast(val message: String) : OrderListEffect
    object TriggerHaptic : OrderListEffect
}
```

---

## 5. Storage, Caching & Memory Management

### 5.1 Image Caching Policy
- **Coil 3 ImageLoader Configuration:**
  - **Memory Cache:** 25% of available heap size (~45 MB), caching downsampled 2048px WebP bitmaps.
  - **Disk Cache:** 250 MB directory in `context.cacheDir/image_cache` with LRU eviction.
  - **Hardware Bitmaps:** `Bitmap.Config.HARDWARE` enabled for zero-copy GPU rendering during 120Hz Before/After panning.
