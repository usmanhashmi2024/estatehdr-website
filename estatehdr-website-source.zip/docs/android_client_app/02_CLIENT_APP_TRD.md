# ⚙️ Technical Requirements Document (TRD)
# Estate HDR — Client Android Application Architecture
> **Document Version:** 2.0.0  
> **Platform Target:** Android 8.0+ (API Level 26–35)  
> **Core Framework:** Android Native (Kotlin) with Jetpack Compose  
> **Backend Integration:** Estate HDR REST API v1 (`https://estatehdr.com/api/v1`)  
> **Author:** Staff Android Architect & Backend Lead  

---

## 📑 Table of Contents
1. [System Architecture & Stack Selection](#1-system-architecture--stack-selection)
2. [Project Modularization & Package Structure](#2-project-modularization--package-structure)
3. [Exhaustive REST API Specifications](#3-exhaustive-rest-api-specifications)
4. [Offline Database Architecture (Room + SQLCipher)](#4-offline-database-architecture-room--sqlcipher)
5. [Hardware-Accelerated Before/After Touch Canvas Engine](#5-hardware-accelerated-beforeafter-touch-canvas-engine)
6. [Background Media Download & MediaStore Pipeline](#6-background-media-download--mediastore-pipeline)
7. [Firebase Push Notifications & Deep Linking](#7-firebase-push-notifications--deep-linking)
8. [Security, Cryptography & Hardware Keystore](#8-security-cryptography--hardware-keystore)
9. [ProGuard / R8 Obfuscation & Build Configurations](#9-proguard--r8-obfuscation--build-configurations)

---

## 1. System Architecture & Stack Selection

The app follows **Modern Android Clean Architecture** combined with the **Model-View-Intent (MVI)** reactive pattern, enforcing unidirectional data flow (UDF) and strict boundary separation.

```
┌────────────────────────────────────────────────────────────────────────┐
│                        PRESENTATION LAYER                              │
│   Jetpack Compose UI • Compose Material 3 • Navigation Compose        │
│   ViewModels (StateFlow / SharedFlow) • UI States & Intent Actions     │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ Emits Intents / Observes UiState
┌───────────────────────────────────▼────────────────────────────────────┐
│                           DOMAIN LAYER                                 │
│   UseCases (e.g. CreateOrderUseCase, SyncProofsUseCase)                │
│   Pure Kotlin Domain Models • Repository Interfaces                    │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ Calls Repository Abstractions
┌───────────────────────────────────▼────────────────────────────────────┐
│                            DATA LAYER                                  │
│   Repositories Implementation (Offline-First Single Source of Truth)   │
│   Local Source (Room DB + SQLCipher) • Remote Source (Retrofit API)    │
│   WorkManager Background Workers • Coil Image Loading Engine           │
└────────────────────────────────────────────────────────────────────────┘
```

### 1.1 Technical Stack Specifications

| Component | Technology | Version | Justification |
| :--- | :--- | :--- | :--- |
| **Language** | Kotlin | 2.0.x | Modern, null-safe, coroutines first-class citizen. |
| **UI Toolkit** | Jetpack Compose | 1.7.x | Declarative, reactive, zero XML overhead, 120Hz smooth rendering. |
| **Design System** | Material 3 (M3) | 1.3.x | Dynamic color, elevation tokens, soft lavender luxury theme. |
| **Async & Streams** | Kotlin Coroutines & Flow | 1.8.x | Lightweight structured concurrency; Cold Flows & StateFlows. |
| **Dependency Injection** | Hilt / Dagger | 2.51.x | Compile-time dependency verification and Android lifecycle scoping. |
| **Networking** | Retrofit 2 + OkHttp 4 | 2.11.x / 4.12.x | Type-safe REST client with HTTP/2, connection pooling, and interceptors. |
| **Local Database** | Android Room + SQLCipher | 2.6.x | SQLite abstraction with compile-time query verification & AES-256 encryption. |
| **Image Pipeline** | Coil | 3.0.x | Kotlin-first, memory-optimized, support for WebP, animated GIFs, and HDR tone mapping. |
| **Background Tasks** | AndroidX WorkManager | 2.9.x | Guaranteed execution for multi-gigabyte ZIP downloads across app restarts. |
| **Biometrics** | AndroidX Biometric | 1.2.x | Unified Fingerprint and 3D Face Unlock backed by Android Keystore. |
| **Push Notifications** | Firebase Cloud Messaging | 24.0.x | Low-latency cloud alerts with custom sound channels and direct deep linking. |

---

## 2. Project Modularization & Package Structure

The project is structured in a scalable multi-module format:

```
estatehdr-android/
├── app/                              # Application class, DI bindings, Navigation Root
├── core/
│   ├── common/                       # Result sealed class, Dispatcher providers, Extensions
│   ├── database/                     # Room DB, Entity definitions, DAOs, Migrations
│   ├── datastore/                    # EncryptedSharedPreferences, UserPreferences
│   ├── designsystem/                 # Theme, Color, Type, Shape, Custom Canvas Components
│   └── network/                      # Retrofit instance, Interceptors, API Services, DTOs
└── feature/
    ├── auth/                         # Login, Register, Biometric lock screens
    ├── dashboard/                    # Home hub, 2x2 matrix, SLA timers, pipeline chart
    ├── order_wizard/                 # 60-Second order placement wizard & price estimator
    ├── proof_viewer/                 # 120Hz Before/After split slider & pin annotation tool
    ├── gallery/                      # Grid view, batch selection, MLS MediaStore export
    ├── chat/                         # Live concierge messaging & WhatsApp bridge
    └── billing/                      # Invoices, ledger, PayPal payment bridge
```

---

## 3. Exhaustive REST API Specifications

### Base URL & Global Headers
- **Base Endpoint:** `https://estatehdr.com/api/v1`
- **Standard Request Headers:**
  ```http
  Content-Type: application/json
  Accept: application/json
  Authorization: Bearer <JWT_ACCESS_TOKEN>
  X-Client-Platform: Android
  X-Client-Version: 2.0.0
  X-Device-ID: 7a8f90b2-4d1e-45a8-92c1-88f623e1b092
  ```

---

### 3.1 Authentication & Profile APIs

#### `POST /auth/login`
Authenticates client and issues access and refresh tokens.
```json
// Request Body
{
  "email": "marcus.vance@vancephotography.com",
  "password": "CorrectHorseBatteryStaple!2026",
  "device_name": "Samsung Galaxy S24 Ultra",
  "fcm_token": "fL92kXpQ..."
}

// Response (200 OK)
{
  "status": "success",
  "data": {
    "access_token": "eyJhbGciOiJIUzI1NiIsIn...",
    "refresh_token": "d98124018247012984...",
    "expires_in": 3600,
    "user": {
      "id": "CLI-8821",
      "name": "Marcus Vance",
      "email": "marcus.vance@vancephotography.com",
      "company": "Vance Architectural Media",
      "phone": "+1 (555) 234-8901",
      "role": "client",
      "is_first_order": false,
      "style_preset": {
        "color_temp": "Neutral Pure White (5000K)",
        "window_pull": "High Contrast Crisp",
        "sky_preference": "Clear Blue Summer",
        "lawn_greening": true
      }
    }
  }
}
```

#### `POST /auth/refresh`
Refreshes an expired access token using the long-lived refresh token.
```json
// Request Body
{
  "refresh_token": "d98124018247012984..."
}

// Response (200 OK)
{
  "status": "success",
  "data": {
    "access_token": "eyJhbGciOiJIUzI1NiIsInNEW...",
    "expires_in": 3600
  }
}
```

---

### 3.2 Order Lifecycle APIs

#### `POST /orders` (Create Order)
Creates a new retouching order. Implements strict idempotency via `Idempotency-Key` header.
```http
POST /api/v1/orders HTTP/1.1
Idempotency-Key: ord_req_998124_uuid
```
```json
// Request Body
{
  "property_address": "742 Evergreen Terrace, Springfield, OR",
  "service_slug": "hdr_photo_editing",
  "bracket_type": "5_bracket",
  "photo_count": 35,
  "cloud_link": "https://www.dropbox.com/scl/fo/abc123xyz/shoot_raws?rlkey=xyz",
  "turnaround_priority": "standard", // "standard" (24h) or "rush" (12h)
  "instructions": "Please ensure the mountain view out the dining room sliding door is crisp.",
  "add_ons": [
    {"type": "day_to_dusk", "count": 2},
    {"type": "virtual_staging", "count": 1, "room": "Empty Master Bedroom"}
  ]
}

// Response (201 Created)
{
  "status": "success",
  "data": {
    "order_id": "ORD-5006",
    "tracking_number": "EHDR-2026-5006",
    "status": "new_intake",
    "is_trial": false,
    "photo_count": 35,
    "sla_deadline": "2026-09-30T14:30:00Z",
    "estimated_hours": 24,
    "pricing": {
      "unit_price": 0.76,
      "base_total": 26.60,
      "add_ons_total": 42.00,
      "rush_fee": 0.00,
      "grand_total": 68.60,
      "currency": "USD"
    }
  }
}
```

#### `GET /orders/{id}` (Order Details & Proofs)
Fetches full order status, photo bracket details, proofs, and active amendments.
```json
// Response (200 OK)
{
  "status": "success",
  "data": {
    "order_id": "ORD-5004",
    "property_address": "Pageant Place Estate, Beverly Hills, CA",
    "status": "ready_for_review", // new_intake | in_production | qa_review | ready_for_review | delivered
    "is_trial": false,
    "photo_count": 24,
    "sla_deadline": "2026-09-29T18:00:00Z",
    "time_remaining_seconds": 14200,
    "photos": [
      {
        "photo_id": "PHT-101",
        "index": 1,
        "title": "Front Exterior Golden Hour",
        "raw_preview_url": "https://estatehdr.com/storage/previews/ORD5004_P01_before.webp",
        "retouched_url": "https://estatehdr.com/storage/deliveries/ORD5004_P01_after.webp",
        "mls_download_url": "https://estatehdr.com/storage/mls/ORD5004_P01_mls.webp",
        "print_download_url": "https://estatehdr.com/storage/print/ORD5004_P01_print.jpg",
        "status": "approved",
        "amendments_count": 0
      },
      {
        "photo_id": "PHT-102",
        "index": 2,
        "title": "Grand Living Room & Panoramic Windows",
        "raw_preview_url": "https://estatehdr.com/storage/previews/ORD5004_P02_before.webp",
        "retouched_url": "https://estatehdr.com/storage/deliveries/ORD5004_P02_after.webp",
        "mls_download_url": "https://estatehdr.com/storage/mls/ORD5004_P02_mls.webp",
        "print_download_url": "https://estatehdr.com/storage/print/ORD5004_P02_print.jpg",
        "status": "under_amendment",
        "amendments_count": 1
      }
    ]
  }
}
```

---

### 3.3 Visual Amendment Submission API

#### `POST /orders/{id}/amendments`
Submits coordinate-tagged pin revision with optional audio note.
```http
POST /api/v1/orders/ORD-5004/amendments HTTP/1.1
Content-Type: multipart/form-data
```
```
--Boundary1234
Content-Disposition: form-data; name="photo_id"

PHT-102
--Boundary1234
Content-Disposition: form-data; name="pin_x"

0.6842
--Boundary1234
Content-Disposition: form-data; name="pin_y"

0.4189
--Boundary1234
Content-Disposition: form-data; name="zoom_level"

2.45
--Boundary1234
Content-Disposition: form-data; name="quick_tags"

["Pull Windows More", "Remove Ceiling Glare"]
--Boundary1234
Content-Disposition: form-data; name="comment"

Please remove the reflection on the glass panel and balance the outdoor sky.
--Boundary1234
Content-Disposition: form-data; name="audio_memo"; filename="memo.aac"
Content-Type: audio/aac

[BINARY AUDIO STREAM]
--Boundary1234--
```
```json
// Response (201 Created)
{
  "status": "success",
  "data": {
    "amendment_id": "AMD-9912",
    "photo_id": "PHT-102",
    "status": "assigned_to_qa",
    "estimated_completion": "2026-09-29T21:00:00Z",
    "message": "Amendment registered under Unlimited Revision Guarantee ($0.00)."
  }
}
```

---

### 3.4 Media Download & Batch Delivery API

#### `GET /orders/{id}/download`
Generates signed pre-authenticated download URLs for complete batches.
```json
// Request: GET /api/v1/orders/ORD-5004/download?format=all
// Response (200 OK)
{
  "status": "success",
  "data": {
    "order_id": "ORD-5004",
    "property_address": "Pageant Place Estate",
    "mls_package": {
      "format": "WebP (2048px, sRGB)",
      "file_count": 24,
      "total_bytes": 38491200,
      "download_url": "https://estatehdr.com/storage/archives/ORD-5004_MLS_WebP.zip?exp=17890124&sig=a9f1...",
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    "print_package": {
      "format": "Full-Resolution JPEG (300 DPI, AdobeRGB)",
      "file_count": 24,
      "total_bytes": 312894100,
      "download_url": "https://estatehdr.com/storage/archives/ORD-5004_PRINT_300DPI.zip?exp=17890124&sig=c18d...",
      "sha256": "4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a"
    }
  }
}
```

---

## 4. Offline Database Architecture (Room + SQLCipher)

The app operates seamlessly in airplane mode or spotty 4G cell areas through an encrypted Room database:

### 4.1 Room Entity Schemas

```kotlin
@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val orderId: String,
    val propertyAddress: String,
    val status: String,
    val isTrial: Boolean,
    val photoCount: Int,
    val serviceSlug: String,
    val grandTotal: Double,
    val currency: String,
    val slaDeadline: Long,
    val createdAt: Long,
    val updatedAt: Long,
    val isSynced: Boolean = true
)

@Entity(
    tableName = "photos",
    foreignKeys = [
        ForeignKey(
            entity = OrderEntity::class,
            parentColumns = ["orderId"],
            childColumns = ["orderId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("orderId")]
)
data class PhotoEntity(
    @PrimaryKey val photoId: String,
    val orderId: String,
    val index: Int,
    val title: String,
    val rawPreviewUrl: String,
    val retouchedUrl: String,
    val mlsUrl: String,
    val printUrl: String,
    val localMlsUri: String? = null,
    val localPrintUri: String? = null,
    val status: String,
    val hasAmendments: Boolean
)

@Entity(tableName = "amendments")
data class AmendmentEntity(
    @PrimaryKey val amendmentId: String,
    val photoId: String,
    val pinX: Float,
    val pinY: Float,
    val zoomLevel: Float,
    val quickTags: String, // Stored as comma-separated or JSON string
    val comment: String,
    val localAudioPath: String?,
    val status: String,
    val submittedAt: Long
)
```

---

## 5. Hardware-Accelerated Before/After Touch Canvas Engine

To deliver a silky-smooth **120 FPS experience** on Samsung 120Hz AMOLED and Google Pixel Smooth Display devices, the Before/After split viewer uses a custom Jetpack Compose Canvas backed by dual hardware bitmaps:

```kotlin
@Composable
fun BeforeAfterSplitViewer(
    beforeBitmap: ImageBitmap,
    afterBitmap: ImageBitmap,
    modifier: Modifier = Modifier
) {
    var splitPosition by remember { mutableFloatStateOf(0.5f) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 4f)
                    offset = if (scale > 1f) offset + pan else Offset.Zero
                }
            }
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    val width = size.width
                    splitPosition = (splitPosition + dragAmount.x / width).coerceIn(0.05f, 0.95f)
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val splitPx = canvasWidth * splitPosition

            withTransform({
                translate(offset.x, offset.y)
                scale(scale, scale, Offset(canvasWidth / 2f, canvasHeight / 2f))
            }) {
                // Layer 1: Draw Full 'Before' RAW Preview
                drawImage(image = beforeBitmap, dstSize = IntSize(canvasWidth.toInt(), canvasHeight.toInt()))

                // Layer 2: Clip & Draw 'After' Retouched Master
                clipRect(left = splitPx, top = 0f, right = canvasWidth, bottom = canvasHeight) {
                    drawImage(image = afterBitmap, dstSize = IntSize(canvasWidth.toInt(), canvasHeight.toInt()))
                }
            }

            // Divider Line (Luxury Gold #C9A84C)
            drawLine(
                color = Color(0xFFC9A84C),
                start = Offset(splitPx, 0f),
                end = Offset(splitPx, canvasHeight),
                strokeWidth = 3.dp.toPx()
            )

            // Draggable Thumb Knob
            drawCircle(
                color = Color.White,
                radius = 16.dp.toPx(),
                center = Offset(splitPx, canvasHeight / 2f)
            )
            drawCircle(
                color = Color(0xFFC9A84C),
                radius = 14.dp.toPx(),
                center = Offset(splitPx, canvasHeight / 2f)
            )
        }
    }
}
```

---

## 6. Background Media Download & MediaStore Pipeline

Batch downloads of 100+ properties must not fail if the photographer locks their phone or drives through a tunnel.

1. **WorkManager Enqueue:** Downloads are scheduled via `OneTimeWorkRequestBuilder<BatchDownloadWorker>()` with network constraints (`NetworkType.CONNECTED`).
2. **Foreground Service Notification:** Displays a persistent Android notification with animated progress bar and cancel action.
3. **Chunked Stream Ingestion:** OkHttp reads input stream in 64 KB buffers, writing to temporary cache.
4. **Scoped Storage Insertion (MediaStore):**
   ```kotlin
   val contentValues = ContentValues().apply {
       put(MediaStore.Images.Media.DISPLAY_NAME, "${propertyTitle}_${index}.webp")
       put(MediaStore.Images.Media.MIME_TYPE, "image/webp")
       put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/EstateHDR/$propertyTitle")
       put(MediaStore.Images.Media.IS_PENDING, 1)
   }
   val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
   resolver.openOutputStream(uri)?.use { output ->
       inputStream.copyTo(output)
   }
   contentValues.clear()
   contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
   resolver.update(uri, contentValues, null, null)
   ```

---

## 7. Firebase Push Notifications & Deep Linking

### Notification Channels Configuration
```kotlin
enum class NotificationChannels(val id: String, val title: String, val importance: Int) {
    ORDERS("ehdr_orders", "Estate HDR Deliveries", NotificationManager.IMPORTANCE_HIGH),
    AMENDMENTS("ehdr_amendments", "Revision Updates", NotificationManager.IMPORTANCE_HIGH),
    CHAT("ehdr_chat", "Concierge Chat", NotificationManager.IMPORTANCE_DEFAULT),
    BILLING("ehdr_billing", "Invoices & Receipts", NotificationManager.IMPORTANCE_LOW)
}
```

### Deep Link Intent Routing
- `estatehdr://orders/{order_id}` -> Opens Order Details Screen
- `estatehdr://orders/{order_id}/proofs/{photo_id}` -> Opens Before/After Split Viewer
- `estatehdr://chat?order_id={order_id}` -> Opens Concierge Chat with context

---

## 8. Security, Cryptography & Hardware Keystore

1. **Hardware Keystore Keyset:**
   - Tokens stored using `EncryptedSharedPreferences.create()` backed by `MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)`.
2. **Network SSL Certificate Pinning:**
   ```kotlin
   val certificatePinner = CertificatePinner.Builder()
       .add("estatehdr.com", "sha256/k20YWj5/AQchIhEdUqwTFnlNaDhY9BSFYSTUMKek18A=")
       .add("estatehdr.com", "sha256/FEzAlgtdHGwgJ24NY/7vNPqbXY406Ut/FlZY3EGWBVU=")
       .build()
   ```
3. **Biometric CryptoObject Authentication:**
   - For invoice payments > $200, prompt user with `BiometricPrompt.CryptoObject` initialized with an AES-256 cipher requiring biometric user presence.

---

## 9. ProGuard / R8 Obfuscation & Build Configurations

```properties
# app/proguard-rules.pro
-keepattributes Signature, InnerClasses, EnclosingMethod
-keepattributes *Annotation*

# Retain Retrofit Data Transfer Objects (DTOs)
-keepclassmembers,allowobfuscation class * {
    @com.google.gson.annotations.SerializedName <fields>;
}
-keep,allowobfuscation class com.estatehdr.client.data.remote.dto.** { *; }

# Room SQLite Schema
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# Coil Image Loaders
-keep class coil.** { *; }
-dontwarn okio.**
```
