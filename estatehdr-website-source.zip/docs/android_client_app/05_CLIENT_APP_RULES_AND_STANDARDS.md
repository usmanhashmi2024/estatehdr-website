# 📜 Business Rules, Engineering Standards & Compliance
# Estate HDR — Client Android Application
> **Document Version:** 2.0.0  
> **Scope:** Core Platform Rules, Kotlin Coding Standards, Security & Play Store Compliance  
> **Enforcement:** Automated CI/CD Linter Checks & Architecture Gatekeepers  
> **Author:** Head of Engineering & Quality Assurance  

---

## 📑 Table of Contents
1. [Core Business Logic Rules (System-Enforced)](#1-core-business-logic-rules-system-enforced)
   - [Rule 1: Free Trial Immunity Rule](#rule-1-free-trial-immunity-rule)
   - [Rule 2: Live Billing & Itemized Tier Pricing Rule](#rule-2-live-billing--itemized-tier-pricing-rule)
   - [Rule 3: Privacy Shielding & Data Isolation Rule](#rule-3-privacy-shielding--data-isolation-rule)
   - [Rule 4: Unlimited Free Revision Guarantee](#rule-4-unlimited-free-revision-guarantee)
   - [Rule 5: Turnaround SLA & Escalation Hierarchy](#rule-5-turnaround-sla--escalation-hierarchy)
2. [Android Engineering & Kotlin Coding Standards](#2-android-engineering--kotlin-coding-standards)
3. [Network Resilience, Caching & Error Handling Standards](#3-network-resilience-caching--error-handling-standards)
4. [Testing & QA Verification Matrix](#4-testing--qa-verification-matrix)
5. [Google Play Store Release & Compliance Checklist](#5-google-play-store-release--compliance-checklist)

---

## 1. Core Business Logic Rules (System-Enforced)

### Rule 1: Free Trial Immunity Rule
> [!IMPORTANT]
> **A Free Trial order must NEVER, under any circumstance, charge a client, post a debt to their ledger, or trigger PayPal payment prompts.**

1. **Strict $0.00 Pricing Enforcement:**
   - Any order marked with `is_trial = true` or where client completed orders == 0 must force the total price to `$0.00`.
   - The price summary component must display: `🎁 COMPLIMENTARY TRIAL ($0.00 USD)`.
2. **Zero Ledger Debt:**
   - Trial orders must never post debit entries to the client's financial ledger.
3. **PayPal Exemption:**
   - When a trial order is delivered, all PayPal payment buttons and payment due callouts must be completely hidden. The screen must show a **"Thank you for trying Estate HDR!"** invitation to upgrade to a Pro account.

---

### Rule 2: Live Billing & Itemized Tier Pricing Rule
1. **Tiered HDR Volume Pricing:**
   - The app's price calculation engine must calculate HDR Photo Fusion using the official volume tiers:
     - 1–19 Photos: **$0.80 / photo**
     - 20–49 Photos: **$0.76 / photo**
     - 50–99 Photos: **$0.72 / photo**
     - 100+ Photos: **$0.65 / photo**
2. **Fixed Service Rates:**
   - Flambient Fusion: **$1.25 / photo**
   - Day to Dusk Conversion: **$12.00 / photo**
   - Virtual Staging: **$18.00 / room**
   - Item Removal & Decluttering: **$5.00 / photo**
   - 2D / 3D Floor Plans: **$25.00 / floor**
3. **Official Corporate Payment Channel:**
   - The designated PayPal receiving address is strictly:
     ```
     ashrafnadeem283@gmail.com
     ```
   - Direct link integration: `https://www.paypal.com/paypalme/ashrafnadeem283`

---

### Rule 3: Privacy Shielding & Data Isolation Rule
1. **Zero Client Cross-Contamination:**
   - A client must only be able to view, query, and download orders associated with their authenticated `user_id`.
   - Local Room database queries must always include `WHERE client_id = :currentClientId`.
2. **Staff Anonymity Shielding:**
   - In proof previews and chat threads, individual retouchers and editors are referred to generically as **"Estate HDR Studio Retoucher"** or **"Alice | Retouching Director"**. Staff internal IDs and editor compensation rates must never leak into client mobile payloads.

---

### Rule 4: Unlimited Free Revision Guarantee
1. **Zero-Cost Amendment Submissions:**
   - Visual pin-point amendments submitted via the app must never charge the client.
2. **Expedited Turnaround:**
   - Revisions are automatically tagged with a high-priority **3-Hour Expedited SLA**.

---

### Rule 5: Turnaround SLA & Escalation Hierarchy
1. **Standard Turnaround:** 24 Hours from order intake.
2. **Rush Turnaround:** 12 Hours (+25% surcharge or +$15 flat fee).
3. **Visual SLA Alerts:**
   - > 6 Hours remaining: Green badge `[On Track]`
   - 2–6 Hours remaining: Amber warning `[Final QA Phase]`
   - < 2 Hours remaining: Rose priority `[Imminent Delivery]`

---

## 2. Android Engineering & Kotlin Coding Standards

### 2.1 Kotlin Idioms & Safety
- **No Force Unwraps (`!!`):**
  - The use of `!!` is strictly banned in production code. Use `?.let {}`, elvis operator `?:`, or safe require/check blocks.
- **Explicit Visibility & Immutability:**
  - All classes, functions, and properties must default to `val` and `private`/`internal`.
- **Pure Domain Layer:**
  - The `:core:domain` module must contain ZERO imports from `android.*`. It must remain pure Kotlin to allow instant JVM testing.

### 2.2 Jetpack Compose Best Practices
- **Stateless Composables:**
  - UI composables must accept state objects and emit lambda callbacks. They must never hold or mutate ViewModel references directly.
  ```kotlin
  // Good: Stateless
  @Composable
  fun OrderCard(
      order: Order,
      onCardClick: (String) -> Unit,
      modifier: Modifier = Modifier
  ) { ... }
  ```
- **Stable Parameters:**
  - Use `@Immutable` or `@Stable` annotations on all UI state models to prevent unnecessary recompositions.

### 2.3 Coroutine & Concurrency Rules
- **No `GlobalScope`:**
  - Use `viewModelScope` for presentation, or custom lifecycle-scoped coroutine scopes injected via Hilt.
- **Explicit Dispatchers:**
  - Always inject a `CoroutineDispatcherProvider` instead of hardcoding `Dispatchers.IO`. This allows seamless unit testing with `StandardTestDispatcher`.

---

## 3. Network Resilience, Caching & Error Handling Standards

1. **Unified Result Wrapper:**
   - All repository calls must return the standardized `Result<T>` sealed class:
   ```kotlin
   sealed interface AppResult<out T> {
       data class Success<T>(val data: T) : AppResult<T>
       data class Error(val exception: Throwable, val userMessage: String) : AppResult<Nothing>
       object Loading : AppResult<Nothing>
   }
   ```
2. **Automatic Silent Token Refresh:**
   - OkHttp `Authenticator` automatically catches HTTP 401 Unauthorized, locks the mutex, requests a fresh token via `/auth/refresh`, and retries the failed request seamlessly.
3. **Exponential Backoff Retry:**
   - Network calls experiencing HTTP 502/503/504 or socket timeouts retry up to 3 times with exponential backoff (1s, 2s, 4s).

---

## 4. Testing & QA Verification Matrix

| Test Level | Target Coverage | Tools Used | Scope |
| :--- | :--- | :--- | :--- |
| **Unit Tests** | > 85% Domain & Data | JUnit 5, MockK, Turbine | UseCases, Mappers, Repositories, ViewModels |
| **DAO Tests** | 100% Query Coverage | AndroidX Room Testing, Robolectric | In-Memory SQLite query assertions |
| **UI Tests** | Critical User Flows | Compose Test Rule, Espresso | Wizard checkout, Proof split viewer touch drag |
| **API Contract** | 100% DTO Validation | MockWebServer | Network error handling, 401 refresh, JSON schemas |

---

## 5. Google Play Store Release & Compliance Checklist

- [x] **Target SDK Level:** Android 14+ (`targetSdk = 34` or `35`).
- [x] **App Bundle Deployment:** Release builds generated as Android App Bundle (`.aab`) with R8 optimization.
- [x] **Minimal Permissions Principle:**
  - `android.permission.INTERNET` (API communication)
  - `android.permission.ACCESS_NETWORK_STATE` (Offline sync detection)
  - `android.permission.POST_NOTIFICATIONS` (Order and proof alerts)
  - `android.permission.RECORD_AUDIO` (Optional voice notes for revisions)
  - `android.permission.USE_BIOMETRIC` (App lock)
  - *No `MANAGE_EXTERNAL_STORAGE` or legacy storage permissions.*
- [x] **Data Safety Form Disclosures:**
  - Personal Info: Name, Email (Account management).
  - Photos: User-selected property media (App functionality).
  - Audio: User-recorded voice memos (Feature-specific revision notes).
  - Security: All data encrypted in transit via TLS 1.3.
- [x] **Google Play App Signing:** Configured with Google-managed private key.
