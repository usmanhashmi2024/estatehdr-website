# 📱 Product Requirements Document (PRD)
# Estate HDR — Client Android Application
> **Document Version:** 2.0.0  
> **Target Release:** Q4 2026 / Q1 2027  
> **Platform:** Android Native (Phone & Foldable Optimized)  
> **Status:** Approved for Architectural Engineering & UI/UX Design  
> **Author:** Estate HDR Product & Architecture Team  
> **Scope:** Complete Client Mobile Ecosystem (Photographers, Realtors, Agencies)  

---

## 📑 Table of Contents
1. [Executive Summary & Vision](#1-executive-summary--vision)
2. [Target Personas & User Journeys](#2-target-personas--user-journeys)
3. [Core Problem-Solution Matrix](#3-core-problem-solution-matrix)
4. [Information Architecture & Navigation](#4-information-architecture--navigation)
5. [Exhaustive Feature Specifications](#5-exhaustive-feature-specifications)
   - [Epic 1: Identity, Auth & Biometrics](#epic-1-identity-auth--biometrics)
   - [Epic 2: Real-Time Property & Order Dashboard](#epic-2-real-time-property--order-dashboard)
   - [Epic 3: 60-Second Order Placement Wizard](#epic-3-60-second-order-placement-wizard)
   - [Epic 4: Touch-Interactive Before/After Proofing Viewer](#epic-4-touch-interactive-beforeafter-proofing-viewer)
   - [Epic 5: Pin-Point Visual Amendment Tool](#epic-5-pin-point-visual-amendment-tool)
   - [Epic 6: 1-Tap MLS Batch Downloader & Media Export](#epic-6-1-tap-mls-batch-downloader--media-export)
   - [Epic 7: 24/7 Concierge Chat & Studio Bridge](#epic-7-247-concierge-chat--studio-bridge)
   - [Epic 8: Invoicing, Ledger & In-App PayPal Billing](#epic-8-invoicing-ledger--in-app-paypal-billing)
   - [Epic 9: Client Style Preferences & Presets](#epic-9-client-style-preferences--presets)
6. [Non-Functional Requirements (NFRs)](#6-non-functional-requirements-nfrs)
7. [Edge Cases & Error States](#7-edge-cases--error-states)
8. [KPIs & Product Success Metrics](#8-kpis--product-success-metrics)

---

## 1. Executive Summary & Vision

### 1.1 Product Vision
The **Estate HDR Client Android App** is a luxury mobile concierge designed for real estate photographers, commercial brokers, and top-tier media production agencies. It empowers creative professionals to offload RAW photo brackets in seconds directly from their vehicles between property shoots, review retouched architectural masterworks through a 120Hz touch Before/After split slider, drop coordinate-accurate revision pins with voice notes, and deliver MLS-compliant media directly to their clients' hands—all without ever opening a laptop.

### 1.2 Strategic Objectives
1. **Accelerate Time-to-Order:** Reduce average order creation time from 4.5 minutes (desktop web) to under 55 seconds on mobile via one-tap cloud link paste and smart package presets.
2. **Eliminate Revision Friction:** Replace vague email chains with coordinate-tagged visual pin drops on high-resolution images, decreasing revision cycles by 64%.
3. **Instant Mobile Delivery:** Provide one-tap download of MLS-optimized WebP (2048px) and 300 DPI print-ready JPEG/TIFF directly into the native Android MediaStore.
4. **Transparent Turnaround Tracking:** Give clients real-time live order tracking with a countdown SLA timer, QA inspection checkpoints, and instant push notifications upon delivery.

---

## 2. Target Personas & User Journeys

### 2.1 Persona Matrix

| Attribute | Persona 1: Solo Pro Photographer | Persona 2: Top-Producing Luxury Realtor | Persona 3: Media Production Agency Director |
| :--- | :--- | :--- | :--- |
| **Name & Role** | *Marcus Vance*, Architectural Photographer | *Sophia Sterling*, Luxury Real Estate Agent | *David Chen*, Media Agency Operations Lead |
| **Monthly Volume** | 15–30 Properties (500–1,500 HDR photos) | 4–8 Multimillion Dollar Listings | 80–150 Properties (5,000+ photos) |
| **Hardware** | Samsung Galaxy S24 Ultra, Sony A7R V | Google Pixel 9 Pro, iPhone 16 Pro Max | OnePlus 12, Samsung Galaxy Z Fold 6 |
| **Primary Frustration** | Sitting in traffic editing brackets; laptop battery draining in his car. | Waiting on retouchers while sellers demand immediate MLS listing. | Tracking 6 photographers' invoices, revision requests, and Dropbox links. |
| **Key Mobile Need** | Rapid cloud link submission, push alert when proofs are ready, quick mobile approval. | Rapid Virtual Staging & Day-to-Dusk previews to show sellers on-site. | Centralized billing history, PDF invoice export, multi-order monitoring. |

### 2.2 Primary User Journey: 60-Second In-Car Offloading
```
[Photo Shoot Concludes]
       │
       ▼
[Marcus uploads RAW brackets to Dropbox/Drive from camera/laptop hotspot]
       │
       ▼
[Opens Estate HDR Android App on phone]
       │
       ▼ (Biometric Instant Unlock: Fingerprint / Face)
[Taps Floating Action "+" Button -> Selects 'HDR Fusion $0.80']
       │
       ▼
[Auto-detects Cloud Link from Clipboard -> Enters Property Name '742 Evergreen Terr']
       │
       ▼
[Selects Bracket Size: 5-Exposures (-2 to +2 EV) -> Photo Count: 35]
       │
       ▼
[Taps 'Submit Order' -> Haptic Confirmation + Confetti Animation]
       │
       ▼ (< 45 Seconds Elapsed)
[Real-Time SLA Clock Starts: 24h Countdown with Production Pipeline Visualization]
```

### 2.3 Secondary User Journey: Touch Review & Visual Revision
```
[Push Notification: '🎉 Order ORD-5004 is Ready for Inspection!']
       │
       ▼
[Taps Notification -> Deep links directly to Full-Screen Proof Viewer]
       │
       ▼
[Drags 120Hz Before/After Slider -> Synchronized 400% Zoom on Living Room Windows]
       │
       ▼
[Notices glare on sliding glass door -> Taps 'Drop Pin' -> Taps on window pane]
       │
       ▼
[Microphone Button Held: 'Please reduce window glare and pull outside garden greens']
       │
       ▼
[Taps 'Submit Amendment' -> Retoucher receives pinpoint coordinates (X:68%, Y:42%)]
       │
       ▼ (< 3 Hours Later)
[Push Notification: '✨ Amendment for ORD-5004 Delivered!']
       │
       ▼
[Approves Photo -> Taps 'Save MLS Batch' -> All 35 photos saved to Android Gallery]
```

---

## 3. Core Problem-Solution Matrix

| Current Desktop Friction | Mobile Native Solution | Technical Execution |
| :--- | :--- | :--- |
| Photographers must wait until returning to their home studio to submit orders. | 60-Second In-Car Order Placement Wizard with clipboard cloud link parsing. | Android ClipboardManager integration + background link validator. |
| Reviewing proofs on phone web browsers is clunky, laggy, and lacks true zoom. | Native 120Hz Hardware-Accelerated Before/After Split Viewer with synchronized gesture zooming up to 400%. | Custom Jetpack Compose Canvas / OpenGL Shader with dual Matrix transformation. |
| Communicating revision notes via email leads to confusion ("the 3rd photo, top right window"). | Coordinate-tagged visual pin-drop annotations directly onto high-res canvas with voice notes. | Normalized (X, Y) canvas coordinates mapped to original resolution + AAC voice memo recording. |
| Downloading zip files on mobile is frustrating with file manager extract steps. | One-tap native MediaStore batch ingestion saving 2048px MLS images straight to camera roll. | Android `MediaStore.Images.Media` API + WorkManager background stream extractor. |
| Clients worry about unexpected charges on free trial orders. | **Free Trial Immunity Rule:** Permanent $0.00 lock, zero ledger debt, prominent visual badging. | System-level assertion forbidding billing calculators on trial orders. |

---

## 4. Information Architecture & Navigation

The app utilizes a modern, ergonomic **Floating Pill Bottom Navigation Bar** elevated above a soft lavender canvas (`#EDEEF7`):

```
┌────────────────────────────────────────────────────────────────────────┐
│                        ESTATE HDR CLIENT APP                           │
├────────────────────────────────────────────────────────────────────────┤
│ Top App Bar: User Avatar | Greeting | Notification Bell (Active Badge) │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│                       MAIN CONTENT AREA (SCREENS)                      │
│                                                                        │
│  [Screen 1] Home Dashboard (2x2 Matrix, SLA Timers, Pipeline Chart)   │
│  [Screen 2] Search & Active Orders (Filter Chips, Map View, Order List)│
│  [Screen 3] Order Placement Wizard (Cloud Links, Brackets, Add-ons)   │
│  [Screen 4] Proof Gallery & Before/After Studio (120Hz Slider, Zoom)   │
│  [Screen 5] Profile, Billing Ledger & Preferences (Invoices, Settings) │
│                                                                        │
├────────────────────────────────────────────────────────────────────────┤
│ Floating Bottom Navigation Bar:                                        │
│  [🏠 Home]    [🔍 Orders]    [➕ Upload]    [🖼️ Gallery]    [👤 Account] │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 5. Exhaustive Feature Specifications

### Epic 1: Identity, Auth & Biometrics
- **REQ-AUTH-101: Unified Authentication:** Support email/password login and client self-registration with automatic role assignment (`client`).
- **REQ-AUTH-102: Biometric App Lock:** Integrate AndroidX `BiometricPrompt` (Fingerprint and Face Unlock). Users can toggle biometrics in Settings. App locks after 5 minutes in background.
- **REQ-AUTH-103: JWT Session Management:** Store access token (1 hour) and refresh token (30 days) securely in Android Keystore backed `EncryptedSharedPreferences`.
- **REQ-AUTH-104: Silent Token Refresh:** OkHttp Authenticator automatically intercepts 401 Unauthorized responses and fetches a new JWT without interrupting user flow.

### Epic 2: Real-Time Property & Order Dashboard
- **REQ-DASH-201: Executive Greeting Bar:** Displays client avatar, full name, company name, and an active notification bell with unread badge count.
- **REQ-DASH-202: 2x2 Metric Matrix:** Four distinct cards displaying:
  1. *Active Intake:* Orders currently in editing/QA pipeline.
  2. *Ready for Review:* Orders delivered awaiting client proof approval.
  3. *Delivered Total:* Cumulative lifetime completed properties.
  4. *Turnaround SLA:* Average turnaround speed over last 30 days (e.g., 18.4 hrs).
- **REQ-DASH-203: Real-Time SLA Countdown Clock:** Active orders display a live countdown timer showing remaining hours until guaranteed delivery (24h or 12h rush).
- **REQ-DASH-204: Production Pipeline Bar Chart:** Visual breakdown of weekly deliverables across HDR, Virtual Staging, Dusk, and Floor Plans.

### Epic 3: 60-Second Order Placement Wizard
- **REQ-ORD-301: One-Tap Cloud Ingestion:** Automatic clipboard detection of links from Google Drive, Dropbox, WeTransfer, OneDrive, Box, or iCloud. Auto-validates URL format.
- **REQ-ORD-302: Service Selection Carousel:** Visual cards for:
  - *HDR Photo Fusion:* $0.80/photo (1–19), $0.76 (20–49), $0.72 (50–99), $0.65 (100+).
  - *Flambient Fusion:* $1.25/photo.
  - *Virtual Staging:* $18.00/room (Living, Master Bedroom, Dining, Patio, Home Office).
  - *Day to Dusk (Virtual Twilight):* $12.00/photo.
  - *Item Removal & Decluttering:* $5.00/photo.
  - *2D / 3D Floor Plans:* $25.00/floor.
- **REQ-ORD-303: Bracket Configuration:** Quick selector chips for bracket exposures: `Single Exposure`, `3-Bracket (-2, 0, +2 EV)`, `5-Bracket (-2, -1, 0, +1, +2 EV)`, `Flambient (Flash + Ambient)`.
- **REQ-ORD-304: Free Trial Mode:** If client has 0 completed orders, automatically activate the **Complimentary Free Trial** (up to 3 free HDR edits). Price displays `$0.00 (FREE TRIAL)` with zero payment required.
- **REQ-ORD-305: Instant Turnaround Selection:** Standard (24 Hours - Included) vs Rush Priority (12 Hours - +25% surcharge).

### Epic 4: Touch-Interactive Before/After Proofing Viewer
- **REQ-VIEW-401: 120Hz Smooth Split Slider:** Vertical gold divider line (`#C9A84C`) with draggable circular thumb. Left side renders RAW/bracket preview; right side renders retouched master.
- **REQ-VIEW-402: Synchronized Dual-Layer Zoom:** Pinch-to-zoom up to 400% with double-tap zoom to 200%. As the user pans and zooms, both before and after layers remain locked in pixel-perfect alignment.
- **REQ-VIEW-403: Single-Tap Quick Compare:** Holding down anywhere on the screen toggles full original view; releasing snaps back to retouched view with subtle haptic tap.
- **REQ-VIEW-404: Color & EXIF Metadata Inspector:** Overlay toggle displaying camera model, focal length, aperture, ISO, exposure bracket range, and retoucher ID.

### Epic 5: Pin-Point Visual Amendment Tool
- **REQ-AMEND-501: Coordinate Pin Drop:** Tapping 'Request Revision' freezes canvas. User taps any exact point on the photo to drop an animated gold location pin.
- **REQ-AMEND-502: Normalized Spatial Tagging:** Pin stores normalized coordinates `(x: 0.000 to 1.000, y: 0.000 to 1.000)` along with current zoom level and crop viewport.
- **REQ-AMEND-503: Voice Memo Recording:** Built-in microphone button allows user to record up to 60 seconds of high-fidelity voice instructions (AAC encoded).
- **REQ-AMEND-504: Quick Revision Presets:** One-tap quick tags: `[Pull Windows More]`, `[Remove Ceiling Glare]`, `[Fix Green Grass Color]`, `[Replace Grey Sky]`, `[Straighten Verticals]`, `[Warm Up Interior]`.
- **REQ-AMEND-505: Unlimited Revisions Guarantee:** Submitting revisions costs $0.00 and routes directly to the assigned Team Lead with an expedited 3-hour SLA.

### Epic 6: 1-Tap MLS Batch Downloader & Media Export
- **REQ-EXP-601: Dual Delivery Formats:**
  - *MLS Optimized:* 2048px longest edge, 72 DPI, optimized WebP / JPEG, sRGB color profile, under 2MB per file (meets Zillow, Realtor.com, BrightMLS rules).
  - *Print Master:* Full camera sensor resolution (up to 60MP), 300 DPI, uncompressed JPEG / 16-bit TIFF, AdobeRGB / ProPhoto RGB.
- **REQ-EXP-602: Native Android MediaStore Ingestion:** Downloads save directly to a dedicated `Pictures/EstateHDR/{Property_Name}/` album in the Android Gallery with proper EXIF tags preserved.
- **REQ-EXP-603: Direct App Share Sheet:** One-tap sharing to Android system share sheet for instant dispatch via WhatsApp, Email, Slack, Google Drive, or Instagram.

### Epic 7: 24/7 Concierge Chat & Studio Bridge
- **REQ-CHAT-701: Real-Time Messaging:** Direct chat connection between client, Retouching Director (Alice), and assigned production Team Leads.
- **REQ-CHAT-702: Image & Voice Attachments:** Send reference photos, screenshots of staging furniture, or audio messages directly inside the chat thread.
- **REQ-CHAT-703: Instant WhatsApp Integration:** Deep-link button to open official studio WhatsApp (`+44 770 606 8176`) with pre-filled order context.

### Epic 8: Invoicing, Ledger & In-App PayPal Billing
- **REQ-BILL-801: Transparent Itemized Invoices:** Detailed breakdown of every property order, photo counts, service add-ons, and payment status (`Paid`, `Pending`, `Complimentary Trial`).
- **REQ-BILL-802: One-Tap PayPal Payment:** Native PayPal checkout bridge and direct link to official receiving address (`ashrafnadeem283@gmail.com` / `paypal.me/ashrafnadeem283`).
- **REQ-BILL-803: PDF Invoice Export:** Download official Estate HDR corporate PDF invoices directly to phone storage for tax and accounting records.

### Epic 9: Client Style Preferences & Presets
- **REQ-PREF-901: Color Temperature Preset:** Global slider: `Warm (3200K)` <-> `Neutral Pure White (5000K)` <-> `Cool Natural (6500K)`.
- **REQ-PREF-902: Window Pull Intensity:** Choice between `Natural Ambient (soft view)` vs `High Contrast Crisp (full architectural clarity)`.
- **REQ-PREF-903: Sky Replacement Preferences:** Favorites selector: `Clear Blue Summer`, `Wispy Sunset Clouds`, `Dramatic Golden Hour`, `Deep Twilight`.
- **REQ-PREF-904: Lawn & Foliage Treatment:** `Natural Lawn Match` vs `Lush Emerald Green Enhancement`.

---

## 6. Non-Functional Requirements (NFRs)

| Category | Metric / Requirement | Validation Method |
| :--- | :--- | :--- |
| **Cold App Launch** | < 1,200 ms to interactive dashboard | Android Vitals / Macrobenchmark |
| **Frame Rate** | 60 FPS continuous list scrolling; 120 FPS on Before/After slider | Android Studio Profiler (Choreographer) |
| **Memory Footprint** | Peak RAM < 180 MB during full 400% dual-bitmap inspection | Android Memory Profiler (LeakCanary) |
| **Offline Resilience** | Full read access to previous orders, proofs, and invoices without internet | Airplane mode testing with Room database |
| **Network Data Efficiency**| Thumbnail previews < 120 KB; progressive WebP loading | OkHttp cache & Coil image pipeline |
| **Security & Privacy** | AES-256 encrypted SharedPreferences; TLS 1.3; Certificate Pinning | OWASP Mobile Security Testing Guide (MSTG) |
| **Battery Impact** | Background sync WorkManager consumes < 1% battery / 24 hours | Android Battery Historian |

---

## 7. Edge Cases & Error States

1. **Unstable 4G/5G in Remote Real Estate:** Background uploads/downloads auto-pause and resume when network reconnects without corrupting files.
2. **Expired Cloud Links (Dropbox 404):** Wizard validates link access before accepting order. If broken, client receives an immediate inline prompt: *"Link appears private or expired. Please enable public access."*
3. **Massive Bracket Uploads (100+ RAWs):** App displays background notification with deterministic progress percentage and remaining time estimate.
4. **Simultaneous Multi-Device Login:** Session refresh token rotation ensures client stays logged in securely while preventing token replay attacks.

---

## 8. KPIs & Product Success Metrics

- **Order Placement Speed:** Median order time < 55 seconds.
- **Revision Efficiency:** > 80% of revisions resolved on first submission via pin-point annotations.
- **Crash-Free Sessions:** > 99.85% across all Android 10+ devices.
- **Client Satisfaction (CSAT):** In-app delivery rating >= 4.9 / 5.0 stars.
- **Monthly Active Mobile Orders:** > 65% of all Estate HDR studio orders placed via Android app.
