# 📱 Estate HDR — Client Android Application Documentation Suite
> **Master Documentation Package Version:** 2.0.0  
> **Target Release:** Q4 2026 / Q1 2027  
> **Platform:** Android Native (Kotlin + Jetpack Compose)  
> **Backend Integration:** Estate HDR Platform (`https://estatehdr.com`)  

---

## 🌟 Master Documentation Index

Welcome to the definitive engineering and design documentation suite for the **Estate HDR Client Android Application**. This documentation is specifically structured for mobile developers, UI/UX designers, backend engineers, and AI coding agents to build a world-class, production-grade Android application.

| Document | File Name | Core Contents |
| :--- | :--- | :--- |
| **01. PRD** | [`01_CLIENT_APP_PRD.md`](./01_CLIENT_APP_PRD.md) | Product Vision, Target Personas, User Journeys, 9 Functional Epics, Non-Functional Requirements, Edge Cases & Success KPIs. |
| **02. TRD** | [`02_CLIENT_APP_TRD.md`](./02_CLIENT_APP_TRD.md) | Clean Architecture, MVI Pattern, Complete REST API Schemas, Room + SQLCipher Database, 120Hz Before/After Canvas Engine, MediaStore Ingestion, FCM Notifications & Keystore Security. |
| **03. UI/UX Spec** | [`03_CLIENT_APP_UI_UX_SPEC.md`](./03_CLIENT_APP_UI_UX_SPEC.md) | Soft Lavender Luxury Design System (`#EDEEF7`), Plus Jakarta Sans Typography, 8pt Grid, Component Library, 12+ Screen Wireframes, Haptics & 120 FPS Physics. |
| **04. Architecture** | [`04_CLIENT_APP_ARCHITECTURE.md`](./04_CLIENT_APP_ARCHITECTURE.md) | End-to-End System Topology, Android Clean Architecture Layers, Sequence Diagrams, Offline-First Sync Engine, State Management & Memory Management. |
| **05. Rules & Standards** | [`05_CLIENT_APP_RULES_AND_STANDARDS.md`](./05_CLIENT_APP_RULES_AND_STANDARDS.md) | Free Trial Immunity Rule, Tiered Pricing Standards, Unlimited Revision Guarantee, Kotlin Coding Standards, Testing Matrix & Google Play Store Compliance. |

---

## 🚀 Quick-Start Guide for Android Developers

### 1. Prerequisites & Environment Setup
- **Android Studio:** Ladybug (2024.2.1+) or newer.
- **JDK:** OpenJDK 17 or 21 (`C:\Users\uzith\AppData\Local\Programs\jdk-17`).
- **Android SDK:** API Level 34+ (Android 14) / Min SDK 26 (Android 8.0).
- **Kotlin:** Version 2.0.x with Compose Compiler plugin.

### 2. Core Architectural Principles
1. **Offline-First:** All read operations stream from the encrypted Room database (`Flow<List<Order>>`). Network updates write to the database first.
2. **Stateless UI:** Composables take immutable state and emit events (`UiIntent`). No business logic inside Composables.
3. **Free Trial Immunity:** Any order flagged as trial MUST strictly calculate to `$0.00` and suppress PayPal payment options.
4. **120Hz Proofing:** The Before/After split viewer uses dual hardware bitmaps with sub-pixel canvas clipping and synchronized dual-finger zoom.

---

## 🗺️ Implementation Roadmap

```
PHASE 1: Core Foundation & Auth (Weeks 1–2)
├── Hilt DI setup, Room DB schema, Network module (Retrofit + OkHttp)
├── JWT Auth flow, BiometricPrompt lock screen, and Keystore storage
└── Design System Tokens (Colors, Typography, Theme, Surface Cards)

PHASE 2: Order Management & Dashboard (Weeks 3–4)
├── Home Dashboard (2x2 Matrix, SLA live countdown clock, Pipeline chart)
├── 60-Second Order Placement Wizard (Cloud link ingestion, service tiers)
└── Orders List & Active Pipeline Screen with filter chips

PHASE 3: Before/After Proof Studio & Revisions (Weeks 5–6)
├── 120Hz Hardware-Accelerated Touch Before/After Split Viewer
├── Synchronized 400% Dual-Layer Pinch-to-Zoom & Pan
└── Coordinate-Tagged Pin-Point Revision Annotation Tool with Voice Notes

PHASE 4: Delivery, Batch Ingestion & MediaStore (Weeks 7–8)
├── WorkManager background batch download worker
├── Scoped Storage MediaStore integration (Pictures/EstateHDR/)
└── 1-Tap MLS Export (2048px WebP) and 300 DPI Print Export

PHASE 5: Billing, Chat, QA & Play Store Launch (Weeks 9–10)
├── Concierge Live Chat & WhatsApp Studio Bridge
├── Invoices list, PDF download, and PayPal 1-tap checkout
└── Unit test coverage > 85%, ProGuard/R8 optimization, Play Store Release
```

---

## 📍 File Locations in Codebase
All master documentation files are permanently stored in:
`c:\Users\uzith\Documents\Estate HDR Site\docs\android_client_app\`
