<?php
/**
 * Estate HDR — Editorial Guidelines & Ethics Policy
 * Demonstrates high EEAT (Experience, Expertise, Authoritativeness, Trustworthiness)
 */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Editorial Guidelines &amp; Quality Standards — Estate HDR</title>
<meta name="description" content="Learn about Estate HDR's editorial guidelines, architectural photography post-production ethics, MLS compliance policies, and AI disclosure standards.">
<link rel="canonical" href="<?= rtrim(BASE_URL, '/') ?>/editorial-guidelines">
<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" onload="this.onload=null;this.rel='stylesheet'">
<noscript>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap">
</noscript>
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
tailwind.config = {
  theme: {
    extend: {
      colors: {
        gold: { DEFAULT: '#C9A84C', light: '#E8C97B', dark: '#9A7A2E' },
        dark: { DEFAULT: '#0A0A0F', card: '#111118', border: '#1E1E2E' },
      }
    }
  }
}
</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/includes/public-header.php'; ?>

<main class="flex-1 pt-36 pb-20 px-6 sm:px-10 max-w-5xl mx-auto w-full">
  <div class="text-center mb-12">
    <div class="section-tag mb-3">Editorial Policy &amp; Standards</div>
    <h1 class="text-3xl sm:text-5xl font-black text-white leading-tight">Editorial Guidelines &amp; Retouching Standards</h1>
    <p class="text-gray-300 text-sm sm:text-base mt-4 max-w-2xl mx-auto leading-relaxed">
      Our commitment to journalistic accuracy, visual integrity, MLS compliance, and transparent post-production disclosures.
    </p>
    <div class="flex items-center justify-center gap-4 text-xs font-mono text-gold mt-4">
      <span>Last Updated: <?= date('F j, Y') ?></span>
      <span>•</span>
      <span>ISO 12646 / MLS Compliant</span>
    </div>
  </div>

  <div class="glass-card rounded-3xl p-8 sm:p-12 border border-dark-border shadow-2xl space-y-10 bg-[#111118] text-gray-300 text-sm sm:text-base leading-relaxed">
    
    <!-- Section 1 -->
    <div>
      <h2 class="text-xl sm:text-2xl font-bold text-white mb-3 flex items-center gap-2.5">
        <span class="text-gold">1.</span> <span>Mission &amp; Editorial Purpose</span>
      </h2>
      <p>
        Estate HDR is dedicated to empowering real estate photographers, licensed REALTORS&reg;, brokers, and architectural marketing agencies with verified, actionable, and mathematically accurate post-production techniques. Every guide, case study, comparison benchmark, and technical workflow published on EstateHDR.com is written, reviewed, or verified by professional architectural retouching supervisors with active field and studio post-production experience.
      </p>
    </div>

    <!-- Section 2 -->
    <div>
      <h2 class="text-xl sm:text-2xl font-bold text-white mb-3 flex items-center gap-2.5">
        <span class="text-gold">2.</span> <span>Factual Accuracy &amp; Technical Verification</span>
      </h2>
      <p class="mb-3">
        Before publication, all content undergoes multi-tier technical verification:
      </p>
      <ul class="list-disc pl-6 space-y-2 text-gray-300 text-sm">
        <li><strong>Camera &amp; Bracket Data:</strong> EV exposures, ISO noise limits, and dynamic range claims are tested against calibrated Sony, Canon, and Nikon full-frame RAW files.</li>
        <li><strong>Software Benchmarks:</strong> Photoshop, Lightroom, Enfuse, and custom neural networks workflows are audited for rendering speed, memory foot-print, and color profile preservation (sRGB / AdobeRGB).</li>
        <li><strong>Pricing &amp; Economic Models:</strong> ROI estimates and market turnaround calculations are cross-referenced with active US, UK, Canadian, and Australian MLS photography standard rate sheets.</li>
      </ul>
    </div>

    <!-- Section 3 -->
    <div>
      <h2 class="text-xl sm:text-2xl font-bold text-white mb-3 flex items-center gap-2.5">
        <span class="text-gold">3.</span> <span>MLS Compliance &amp; Real Estate Ethics</span>
      </h2>
      <p class="mb-3">
        National Association of Realtors (NAR) Code of Ethics (Article 12) strictly prohibits deceptive or misleading property presentations. Estate HDR strictly enforces the following rules across both our client editing services and our published guides:
      </p>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 my-4">
        <div class="p-5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30">
          <div class="text-emerald-400 font-bold text-sm mb-2">✓ Permissible Enhancements</div>
          <ul class="text-xs space-y-1.5 text-gray-300">
            <li>• Exposure balancing &amp; window pull highlight recovery</li>
            <li>• Vertical line perspective correction (90-degree keystone)</li>
            <li>• Temporary clutter removal (trash cans, hoses, cars)</li>
            <li>• Lawn greening within realistic seasonal boundaries</li>
            <li>• Virtual staging with explicit "Virtually Staged" disclosure</li>
            <li>• Day-to-dusk twilight conversion for ambiance illustration</li>
          </ul>
        </div>
        <div class="p-5 rounded-2xl bg-red-500/10 border border-red-500/30">
          <div class="text-red-400 font-bold text-sm mb-2">&times; Strictly Prohibited Modifications</div>
          <ul class="text-xs space-y-1.5 text-gray-300">
            <li>• Removing permanent physical fixtures (powerlines, water towers)</li>
            <li>• Erasing structural cracks, water damage, or foundation issues</li>
            <li>• Misrepresenting room dimensions, ceiling heights, or lot views</li>
            <li>• Fabricating surrounding landscapes or phantom water views</li>
            <li>• Digital alteration of neighboring property boundaries</li>
          </ul>
        </div>
      </div>
    </div>

    <!-- Section 4 -->
    <div>
      <h2 class="text-xl sm:text-2xl font-bold text-white mb-3 flex items-center gap-2.5">
        <span class="text-gold">4.</span> <span>AI Retouching &amp; Virtual Staging Disclosures</span>
      </h2>
      <p>
        Where artificial intelligence or generative 3D modeling is discussed or demonstrated (e.g. 3D virtual furniture placement, sky replacement neural filters, digital decluttering), we adhere to transparent labeling. Real estate agents are always advised to furnish buyers with raw or unaltered vacancy photos alongside staged mockups in accordance with local MLS regulations.
      </p>
    </div>

    <!-- Section 5 -->
    <div>
      <h2 class="text-xl sm:text-2xl font-bold text-white mb-3 flex items-center gap-2.5">
        <span class="text-gold">5.</span> <span>Editorial Independence &amp; Affiliate Transparency</span>
      </h2>
      <p>
        Estate HDR does not accept paid editorial inclusions, pay-to-play review ratings, or non-disclosed promotional sponsorship. When third-party hardware, lenses, gimbal equipment, or software plugins are reviewed, recommendations reflect independent studio benchmark testing.
      </p>
    </div>

    <!-- Section 6 -->
    <div>
      <h2 class="text-xl sm:text-2xl font-bold text-white mb-3 flex items-center gap-2.5">
        <span class="text-gold">6.</span> <span>Corrections &amp; Feedback Policy</span>
      </h2>
      <p>
        We maintain a rigorous zero-tolerance policy for factual or technical inaccuracies. If you detect any technical discrepancy, broken standard, or mathematical error in our publications, please notify our editorial board at <a href="mailto:editorial@estatehdr.com" class="text-gold font-bold hover:underline">editorial@estatehdr.com</a>. Confirmed errors are amended within 24 hours with an updated timestamp and change log.
      </p>
    </div>

  </div>
</main>

<?php require_once __DIR__ . '/includes/public-footer.php'; ?>

</body>
</html>
