# Project: Estate HDR Visitor Intelligence Hub Transformation

## Architecture
Estate HDR Visitor Intelligence Hub transforms `admin/live-visitors.php` into an enterprise-grade, production-ready unified customer communication, real-time telemetry, CRM, omnichannel shared inbox, ticketing, and automation command center.

### Core Architectural Pillars
1. **Data Layer (`includes/db.php`, `data/*.json`)**:
   - Flat-file JSON database engine with strict concurrency protection (`atomicWriteJson`) using temporary swap files and exclusive locking (`LOCK_EX`).
   - Unified data models: `visitors.json`, `live_chats.json`, `leads.json`, `contacts.json`, `tickets.json`, `chat_automations.json`, `widget_settings.json`, `knowledge_base.json`, `analytics_history.json`.
2. **Telemetry & Presence Engine (`api/visitor-ping.php`, `includes/chat-widgets.php`)**:
   - High-precision telemetry receiving initial pings (800ms) and heartbeats (40s).
   - 3-State Presence Engine: Active (≤60s), Idle (61s–180s), Chatting (active chat session).
   - Journey Tracker: Full chronological page navigation stack (`journey: [{url, title, ts, time_spent}]`).
3. **Omnichannel Communication & Real-Time Chat Engine (`api/chat-live.php`, `includes/chat-widgets.php`)**:
   - 2-Way communication with sub-second typing sneak-peek synchronization (300ms throttle).
   - Web Audio API synthesized notification chimes (A5→E6).
   - Unified multi-channel message model supporting Live Web Chat, WhatsApp, Email, and SMS.
   - Internal private agent notes, staff role assignments (`sales`, `photo_editing`, `management`).
   - Canned quick replies with slash shortcuts (`/pricing`, `/turnaround`, `/sample`, `/discounts`).
4. **CRM & Dynamic Lead Scoring Engine (`includes/db.php`, `admin/live-visitors.php`)**:
   - Dynamic 0–100 mathematical lead scoring based on user actions (e.g. Pricing +20, Contact +20, Chat +30, RAW upload +40).
   - Lead temperature tiers: Cold (0–29), Warm (30–59), Hot (60–89), Qualified (90–100).
   - 360° Contact Profile dossier aggregating sessions, transcripts, leads, orders, and ledger.
5. **Automation Rules & Customizer Studio (`data/chat_automations.json`, `data/widget_settings.json`)**:
   - Behavioral trigger engine evaluating dwell times (e.g. >45s on `/services/`), page visits, and intent triggers.
   - Real-time chat widget customizer (colors, headers, greeting text, business hours, offline intake form).
6. **Support Ticketing & Knowledge Base System (`data/tickets.json`, `data/knowledge_base.json`)**:
   - 1-Click conversation-to-ticket conversion with SLA priority matrix (Urgent: 15m/2h, High: 1h/6h, Normal: 4h/24h, Low: 12h/48h).
   - Dual-surface embedded Knowledge Base for public widget search and agent inbox search.
7. **Unified Command Center UI (`admin/live-visitors.php`)**:
   - Interactive, glassmorphic 6-tab navigation:
     1. Overview & KPI Summary
     2. Live Visitor Radar & Interactive Geo-Map
     3. Omnichannel Shared Inbox & Real-Time Live Chat
     4. Integrated CRM & Dynamic Lead Scoring
     5. Behavioral Triggers & Widget Studio
     6. Support Ticketing & Knowledge Base Center

---

## Feature Inventory
| # | Feature | Description | Milestone | Source |
|---|---------|-------------|-----------|--------|
| 1 | Flat-File JSON Concurrency & Atomic Writes | `atomicWriteJson()` with `tmp` swap and `LOCK_EX` across all writes | M1 | Survey |
| 2 | Command Center Tab Navigation & Layout | 6-tab interactive navigation preserving all existing styles and RBAC | M1 | R1 |
| 3 | Executive KPI Summary Dashboard | Real-time active visitors, sessions, response time, CSAT, open tickets, active leads | M1 | R1 |
| 4 | 3-State Live Presence Engine | Active (≤60s), Idle (61–180s), Chatting status badges with live indicators | M2 | R1 |
| 5 | Interactive Visitor Radar & Geo-Map | Country/city breakdown, % bars, SVG map / country visualizer, direct URL links | M2 | R1 |
| 6 | Slide-over Visitor Drawer & Journey Timeline | Page-by-page history, time on page, referrer, device/OS/browser, dynamic lead score | M2 | R1 |
| 7 | 2-Way Real-Time Live Chat Console | Sub-second agent/visitor messaging with sub-3s polling and instant local echo | M3 | R2 |
| 8 | Real-Time Typing Sneak-Peek Sync | Visitor keystroke preview banner in admin console with 6s expiration | M3 | R2 |
| 9 | Canned Quick Replies with Slash Commands | Quick reply chips and slash triggers (`/pricing`, `/turnaround`, `/sample`, `/discounts`) | M3 | R2 |
| 10 | Synthesized Web Audio Notification Chime | Web Audio API dual-tone chime for new messages and visitor alerts | M3 | R2 |
| 11 | Omnichannel Multi-Channel Filter | Unified conversation stream with filters for Website, WhatsApp, Email, and SMS | M3 | R2 |
| 12 | Internal Private Agent Notes | Private staff notes embedded in chat transcripts without visitor visibility | M3 | R2 |
| 13 | Multi-Role Team Assignment | Assign conversations to Sales, Photo Editing, Management with badge tags | M3 | R2 |
| 14 | Dynamic Lead Scoring Engine (0–100) | Deterministic scoring algorithm based on page visits, time, chat, and form actions | M4 | R3 |
| 15 | Lead Temperature Tiers | Visual badges: Cold (0–29), Warm (30–59), Hot (60–89), Qualified (90–100) | M4 | R3 |
| 16 | Visitor-to-Lead Promotion & Pipeline | 1-Click lead creation, lead stage pipeline (New, Contacted, Qualified, Won, Lost) | M4 | R3 |
| 17 | 360° Unified Contact Profile Dossier | Comprehensive view linking visitor ID, sessions, chats, leads, orders, and ledger | M4 | R3 |
| 18 | Behavioral Trigger & Proactive Greeting Engine | Configurable rules (dwell time >45s, pricing visit, exit intent) with action dispatch | M5 | R4 |
| 19 | Customizable Chat Widget Settings Studio | Visual editor for widget colors, greeting, avatars, business hours, offline form | M5 | R4 |
| 20 | Real-Time Widget Preview Frame | Live interactive preview reflecting customized settings in real time | M5 | R4 |
| 21 | 1-Click Conversation-to-Ticket Conversion | Convert chat transcripts or offline messages to support tickets | M5 | R5 |
| 22 | SLA Priority Matrix & Management | Ticket priority levels (Urgent, High, Normal, Low) with SLA response/resolution timers | M5 | R5 |
| 23 | Embedded Searchable Knowledge Base | Categorized articles (Photo Editing, Virtual Staging, Pricing, Turnaround) | M5 | R5 |
| 24 | Dual-Surface KB Search (Widget + Admin) | In-widget visitor self-service and in-inbox agent insert shortcut | M5 | R5 |

---

## Milestones
| # | Name | Scope | Dependencies | Status |
|---|------|-------|-------------|--------|
| M1 | Core Concurrency, Atomic Storage & Command Center Navigation | Features 1, 2, 3: `atomicWriteJson()`, layout, tabs, KPI summary cards, DB helper foundation | none | DONE |
| M2 | Live Visitor Radar, Geo-Mapping & Journey Drawer | Features 4, 5, 6: 3-state presence, country/city radar, interactive map, visitor drawer & timeline | M1 | IN_PROGRESS |
| M3 | Omnichannel Shared Inbox & Real-Time Live Chat | Features 7, 8, 9, 10, 11, 12, 13: 2-way chat, typing sneak-peek, canned replies, chimes, omnichannel filter, private notes, role assignment | M1 | PLANNED |
| M4 | Integrated CRM & Dynamic Lead Scoring Engine | Features 14, 15, 16, 17: Dynamic 0–100 scoring algorithm, temperature tiers, lead promotion, 360° contact dossier | M1, M2 | PLANNED |
| M5 | Behavioral Triggers, Widget Studio, Ticketing & Knowledge Base | Features 18, 19, 20, 21, 22, 23, 24: Rule engine, widget customizer with live preview, 1-click ticketing with SLAs, dual-surface KB | M1, M3 | PLANNED |
| Final | 100% E2E Verification & Adversarial Coverage Hardening | Full validation against E2E test suite (Tiers 1–4) and Adversarial Coverage Hardening (Tier 5) | M1, M2, M3, M4, M5, E2E | PLANNED |

---

## Code Layout
- `admin/live-visitors.php`: Master multi-tab Command Center interface.
- `includes/db.php`: Database abstraction, atomic file locking, data access helpers for visitors, chats, contacts, leads, tickets, rules, widget settings, knowledge base.
- `includes/admin-header.php`: Master admin navigation and RBAC.
- `includes/chat-widgets.php`: Client-side floating widget, telemetry ping generator, typing emitter, in-widget KB and offline form.
- `api/visitor-ping.php`: Telemetry receiver, journey tracking, presence state and dynamic lead score updater.
- `api/chat-live.php`: 2-way chat engine, typing sneak-peek handler, omnichannel messages, private notes, ticket conversion bridge.
- `api/crm-tickets.php`: Dedicated REST API for contacts, lead scoring, tickets, automations, and knowledge base.
- `data/*.json`: Persistent flat-file JSON stores.
- `tests/e2e/`: Automated E2E verification test suite.

---

## Interface Contracts

### 1. Concurrency Contract (`includes/db.php`)
- `atomicWriteJson(string $path, array $data): bool`
  - Writes to `$path . '.' . bin2hex(random_bytes(6)) . '.tmp'`, locks exclusively (`LOCK_EX`), flushes buffer, closes, and atomically renames over target file.

### 2. Telemetry & Journey Contract (`api/visitor-ping.php`, `includes/chat-widgets.php`)
- `POST /api/visitor-ping.php`
  - Request: `{ visitor_id, current_page, page_title, referrer, time_spent, screen_res, client_ts }`
  - Response: `{ success: true, visitor_id: string, active_rules: array, lead_score: int }`
- Client script in `includes/chat-widgets.php` sends page navigation telemetry and captures chronological journey array in `localStorage['ehdr_journey']`.

### 3. Visitor Drawer & Journey Contract (`admin/live-visitors.php`)
- JS function `openVisitorDrawer(visitorId)` renders slide-over drawer (`#visitorDetailDrawer`):
  - Visitor header (flag, IP, city, country, browser, OS, device, current page URL with link)
  - 3-State badge (Active / Idle / Chatting / Offline)
  - Chronological Journey timeline (page by page, dwell time, entry referrer)
  - 1-Click quick actions ("Start Live Chat", "Promote to Lead", "Create Support Ticket")

### 4. Omnichannel Chat & Keystroke Sneak-Peek Contract (`api/chat-live.php`)
- Actions:
  - `typing_update`: `{ visitor_id, text, channel }`
  - `visitor_send`: `{ visitor_id, message, channel, name, email, phone }`
  - `agent_send`: `{ visitor_id, message, persona, channel, is_private_note, assigned_to }`
  - `poll_visitor`: `?action=poll_visitor&vid=...`
  - `poll_admin`: `?action=poll_admin`
  - `convert_ticket`: `{ visitor_id, subject, priority, department }`

### 5. CRM & Lead Scoring Contract (`includes/db.php`, `api/crm-tickets.php`)
- `calculateDynamicLeadScore(array $visitor, array $chat, array $leads): array`
  - Computes score (0–100) and returns `{ score: int, tier: string, breakdown: array }`.

### 6. Ticket & Knowledge Base Contract (`api/crm-tickets.php`)
- Actions: `get_tickets`, `update_ticket_status`, `create_ticket`, `get_kb`, `search_kb`, `save_rule`, `save_widget_settings`.
