<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';

$pageTitle = 'Terms of Service — Estate HDR Real Estate Photo Editing';
$pageDesc  = 'Read the official Terms of Service, 24-hour turnaround SLA, revision policies, commercial copyright, and client guarantees for Estate HDR.';
$canonUrl  = rtrim(BASE_URL, '/') . '/terms';
$ogImage   = BASE_URL . '/assets/images/portfolio/hdr/1-after.jpg';
$robots    = 'index, follow';
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?></title>
<meta name="description" content="<?= htmlspecialchars($pageDesc) ?>">
<meta name="robots" content="<?= $robots ?>">
<link rel="canonical" href="<?= $canonUrl ?>">

<meta property="og:type" content="website">
<meta property="og:url" content="<?= $canonUrl ?>">
<meta property="og:title" content="<?= htmlspecialchars($pageTitle) ?>">
<meta property="og:description" content="<?= htmlspecialchars($pageDesc) ?>">
<meta property="og:image" content="<?= $ogImage ?>">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap">
<link rel="stylesheet" href="/assets/css/bundle.css?v=<?= file_exists(ROOT_PATH . '/assets/css/bundle.css') ? filemtime(ROOT_PATH . '/assets/css/bundle.css') : time() ?>">
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">

<script type="application/ld+json" nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "name": "Terms of Service",
  "url": "https://estatehdr.com/terms.php",
  "description": "<?= htmlspecialchars($pageDesc) ?>",
  "publisher": {
    "@type": "Organization",
    "name": "Estate HDR",
    "url": "https://estatehdr.com",
    "logo": "https://estatehdr.com/assets/images/logo.png"
  }
}
</script>
</head>
<body class="bg-dark text-gray-200 font-sans min-h-screen flex flex-col antialiased selection:bg-gold/30 selection:text-white">

<?php require_once __DIR__ . '/includes/public-header.php'; ?>

<section class="relative pt-32 sm:pt-40 pb-16 px-6 overflow-hidden border-b border-dark-border bg-gradient-to-b from-dark-card to-dark">
  <div class="max-w-4xl mx-auto text-center relative z-10">
    <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-gold/10 border border-gold/30 text-gold text-xs font-bold uppercase tracking-widest mb-4">
      <span>⚖️</span> <span>Legal Agreement &amp; Client SLA</span>
    </div>
    <h1 class="text-3xl sm:text-5xl font-black text-white uppercase tracking-tight mb-4">
      Terms of <span class="text-gold">Service</span>
    </h1>
    <p class="text-sm sm:text-base text-gray-400 max-w-2xl mx-auto leading-relaxed">
      Transparent guidelines covering our 24-hour turnaround guarantees, commercial copyright assignment, free revision policy, and studio standards.
    </p>
    <div class="mt-4 text-xs font-mono text-gray-500">Last Updated: September 4, 2026 &bull; Version 2.4</div>
  </div>
</section>

<main class="max-w-4xl mx-auto px-6 py-16 flex-1 space-y-12 text-sm leading-relaxed text-gray-300">
  <section class="glass-card p-8 rounded-2xl border border-dark-border space-y-4">
    <h2 class="text-xl font-bold text-white flex items-center gap-3">
      <span class="text-gold font-mono">01.</span> Acceptance of Terms
    </h2>
    <p>
      By accessing our website (<a href="https://estatehdr.com" class="text-gold underline">estatehdr.com</a>), ordering photo editing services, submitting media via our client portal, or engaging Estate HDR ("we", "us", "our") for post-processing fulfillment, you ("Client", "Agency", "Photographer") agree to be bound by these Terms of Service.
    </p>
    <p>
      If you are entering into this agreement on behalf of a real estate brokerage, marketing agency, or photography corporation, you represent that you have the authority to bind that entity to these terms.
    </p>
  </section>

  <section class="glass-card p-8 rounded-2xl border border-dark-border space-y-4">
    <h2 class="text-xl font-bold text-white flex items-center gap-3">
      <span class="text-gold font-mono">02.</span> Service Scope &amp; 24-Hour SLA Delivery
    </h2>
    <p>
      Estate HDR provides professional architectural and real estate media post-processing, including:
    </p>
    <ul class="list-disc list-inside space-y-2 text-gray-300 pl-2">
      <li><strong>HDR Photo Editing &amp; Multi-Bracket Blending:</strong> Exposure fusion, window pulls, natural flash-ambient (flambient) balance, and color neutralization.</li>
      <li><strong>3D Virtual Staging:</strong> Photorealistic 3D interior design placement for vacant rooms according to specified architectural styles.</li>
      <li><strong>Day to Dusk &amp; Virtual Twilight:</strong> Golden hour lighting transformations, interior window illumination, and realistic sky replacement.</li>
      <li><strong>Item Removal &amp; Decluttering:</strong> Seamless removal of distracting clutter, vehicles, hoses, and personal property from MLS listing shots.</li>
      <li><strong>2D &amp; 3D Floor Plans:</strong> Precision dimension drafting and textured 3D architectural renders.</li>
    </ul>
    <div class="p-4 rounded-xl bg-gold/10 border border-gold/30 text-xs text-gold-light mt-4">
      <strong>Guaranteed 24-Hour SLA:</strong> Standard orders submitted prior to cut-off times are guaranteed to be delivered within 24 hours. High-volume batches (exceeding 200 images per order) or specialized custom CGI requests will receive an agreed-upon delivery window prior to queue dispatch.
    </div>
  </section>

  <section class="glass-card p-8 rounded-2xl border border-dark-border space-y-4">
    <h2 class="text-xl font-bold text-white flex items-center gap-3">
      <span class="text-gold font-mono">03.</span> Intellectual Property &amp; 100% Client Copyright
    </h2>
    <p>
      We respect the creative ownership of photographers and media creators:
    </p>
    <ul class="list-disc list-inside space-y-2 pl-2">
      <li><strong>Your Unprocessed Images:</strong> You retain all intellectual property rights and copyrights to the raw and source images you submit to our studio.</li>
      <li><strong>Final Retouched Assets:</strong> Upon full payment of the invoice, Estate HDR assigns 100% of commercial usage rights and ownership of the final edited images to you. You may use, market, license, and publish the final images anywhere worldwide without royalty obligations.</li>
      <li><strong>Confidentiality Guarantee:</strong> Your raw files, client listing addresses, and unpublished real estate assets are kept strictly confidential. We never disclose unreleased property shoots to third parties.</li>
    </ul>
  </section>

  <section class="glass-card p-8 rounded-2xl border border-dark-border space-y-4">
    <h2 class="text-xl font-bold text-white flex items-center gap-3">
      <span class="text-gold font-mono">04.</span> Free Unlimited Revisions Policy
    </h2>
    <p>
      We stand firmly behind our master retouchers with a 100% satisfaction guarantee:
    </p>
    <p>
      If any edited image does not meet your required studio style, color balance, or window pull standard, you may request free revisions within <strong>7 days</strong> of job completion. Revision requests must be aligned with the original order brief. Revisions are prioritized with accelerated turnaround times.
    </p>
  </section>

  <section class="glass-card p-8 rounded-2xl border border-dark-border space-y-4">
    <h2 class="text-xl font-bold text-white flex items-center gap-3">
      <span class="text-gold font-mono">05.</span> Pricing, Billing &amp; Payment Terms
    </h2>
    <p>
      Our pricing is transparent and based on a per-image model as detailed on our <a href="/#pricing" class="text-gold underline">Pricing Page</a>:
    </p>
    <ul class="list-disc list-inside space-y-2 pl-2">
      <li>Prices are quoted in US Dollars (USD $) and British Pounds (GBP &pound;).</li>
      <li>Payments are processed securely via Stripe or approved merchant channels.</li>
      <li>We offer pay-per-job billing as well as monthly volume invoicing for verified agency partners.</li>
    </ul>
  </section>

  <section class="glass-card p-8 rounded-2xl border border-dark-border space-y-4">
    <h2 class="text-xl font-bold text-white flex items-center gap-3">
      <span class="text-gold font-mono">06.</span> Contact &amp; Support Inquiries
    </h2>
    <p>
      For billing questions, enterprise agreements, or technical support:
    </p>
    <div class="flex flex-wrap gap-4 pt-2">
      <a href="mailto:info@estatehdr.com" class="text-gold hover:underline">✉️ info@estatehdr.com</a>
      <a href="tel:+447706068176" class="text-gold hover:underline">📞 +44 770 606 8176</a>
      <a href="/contact" class="text-gold hover:underline">🌐 Contact Form</a>
    </div>
  </section>
</main>

<footer class="border-t border-dark-border py-12 px-6 bg-dark">
  <div class="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-400">
    <div>&copy; <?= date('Y') ?> Estate HDR. All rights reserved.</div>
    <div class="flex items-center gap-5">
      <a href="/" class="hover:text-gold transition-colors">Home</a>
      <a href="/terms" class="text-gold font-bold">Terms of Service</a>
      <a href="/privacy" class="hover:text-gold transition-colors">Privacy Policy</a>
      <a href="/contact" class="hover:text-gold transition-colors">Contact</a>
    </div>
  </div>
</footer>
</body>
</html>