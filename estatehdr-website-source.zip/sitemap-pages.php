<?php
/**
 * Estate HDR — Core Pages XML Sitemap
 */
require_once __DIR__ . '/includes/config.php';

header('Content-Type: application/xml; charset=utf-8');
header('Cache-Control: public, max-age=3600');

$now = date('Y-m-d\TH:i:s+00:00');

$corePages = [
    ['loc' => '/', 'priority' => '1.00', 'changefreq' => 'daily'],
    ['loc' => '/real-estate-photo-editing', 'priority' => '0.95', 'changefreq' => 'weekly'],
    ['loc' => '/pricing', 'priority' => '0.95', 'changefreq' => 'weekly'],
    ['loc' => '/portfolio', 'priority' => '0.90', 'changefreq' => 'weekly'],
    ['loc' => '/blog', 'priority' => '0.90', 'changefreq' => 'daily'],
    ['loc' => '/team', 'priority' => '0.85', 'changefreq' => 'monthly'],
    ['loc' => '/about', 'priority' => '0.80', 'changefreq' => 'monthly'],
    ['loc' => '/contact', 'priority' => '0.85', 'changefreq' => 'monthly'],
    ['loc' => '/alternatives', 'priority' => '0.75', 'changefreq' => 'monthly'],
    ['loc' => '/sitemap', 'priority' => '0.50', 'changefreq' => 'weekly'],
    ['loc' => '/editorial-guidelines', 'priority' => '0.40', 'changefreq' => 'monthly'],
    ['loc' => '/terms', 'priority' => '0.30', 'changefreq' => 'yearly'],
    ['loc' => '/privacy', 'priority' => '0.30', 'changefreq' => 'yearly']
];

echo '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
<?php foreach ($corePages as $p): 
    $targetLoc = rtrim(BASE_URL, '/') . ($p['loc'] === '/' ? '/' : $p['loc']);
?>
    <url>
        <loc><?= $targetLoc ?></loc>
        <lastmod><?= $now ?></lastmod>
        <changefreq><?= $p['changefreq'] ?></changefreq>
        <priority><?= $p['priority'] ?></priority>
    </url>
<?php endforeach; ?>
</urlset>
