<?php
/**
 * Estate HDR — Dynamic Services XML Sitemap with Image Extensions
 */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';

header('Content-Type: application/xml; charset=utf-8');
header('Cache-Control: public, max-age=3600');

$services = getServices();
$now = date('Y-m-d\TH:i:s+00:00');

echo '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">

<?php foreach ($services as $srv): 
    $slug = $srv['slug'] ?? '';
    if (empty($slug)) continue;
    $url = rtrim(BASE_URL, '/') . '/services/' . urlencode($slug);
    $title = htmlspecialchars($srv['name'] ?? $srv['title'] ?? 'Real Estate Photo Editing', ENT_QUOTES, 'UTF-8');
    $img = $srv['featured_image'] ?? $srv['image'] ?? '/assets/images/portfolio/hdr/1-after.jpg';
    $imgUrl = str_starts_with($img, 'http') ? $img : (rtrim(BASE_URL, '/') . '/' . ltrim($img, '/'));
?>
    <url>
        <loc><?= $url ?></loc>
        <lastmod><?= $now ?></lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.90</priority>
        <image:image>
            <image:loc><?= $imgUrl ?></image:loc>
            <image:title><?= $title ?> — Estate HDR</image:title>
            <image:caption><?= htmlspecialchars($srv['description'] ?? $title, ENT_QUOTES, 'UTF-8') ?></image:caption>
        </image:image>
    </url>
<?php endforeach; ?>

</urlset>
