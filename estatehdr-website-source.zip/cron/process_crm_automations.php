<?php
declare(strict_types=1);

/**
 * Estate HDR — Background Cron Worker (DEACTIVATED ON HOSTINGER)
 * Email automation has been safely decoupled from the web server to prevent site slowdown.
 * All CRM order management, invoicing, and email automation now run locally via Estate Management Software.
 */

header('Content-Type: application/json');
http_response_code(200);

echo json_encode([
    'status' => 'deactivated',
    'message' => 'Email automation cron is deactivated on the web server to maximize site speed. Run automations via Estate Management Software locally.',
    'timestamp' => date('c')
], JSON_PRETTY_PRINT);
exit;
