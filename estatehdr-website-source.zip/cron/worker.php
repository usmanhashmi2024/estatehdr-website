<?php
/**
 * Estate HDR — Background Queue & Maintenance Worker
 * PRD Section 13 & 20: Processes async jobs, lead score rollups, telemetry aggregation & session maintenance.
 * Triggered via Hostinger Cron Job: php /path/to/cron/worker.php
 */

if (php_sapi_name() !== 'cli' && (!isset($_GET['token']) || $_GET['token'] !== 'EHDR_CRON_SECRET_2026')) {
    http_response_code(403);
    die('Forbidden: CLI or authorized token required.');
}

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/lead-scoring.php';

echo "[Estate HDR Worker] Started at " . date('Y-m-d H:i:s') . "\n";

// 1. Process Database Queue Jobs
$pdo = Database::getConnection();
$processedCount = 0;

if ($pdo) {
    try {
        $stmt = $pdo->prepare("SELECT * FROM database_queue WHERE status = 'pending' AND available_at <= NOW() LIMIT 20");
        $stmt->execute();
        $jobs = $stmt->fetchAll();

        foreach ($jobs as $job) {
            $jobId = $job['id'];
            $type = $job['job_type'];
            $payload = json_decode($job['payload_json'], true) ?: [];

            // Mark processing
            $pdo->prepare("UPDATE database_queue SET status = 'processing', attempts = attempts + 1 WHERE id = ?")->execute([$jobId]);

            // Execute job logic
            // (e.g. telemetry aggregation, email notifications, lead synchronization)

            // Mark completed
            $pdo->prepare("UPDATE database_queue SET status = 'completed' WHERE id = ?")->execute([$jobId]);
            $processedCount++;
        }
    } catch (Throwable $e) {
        echo "Queue processing note: " . $e->getMessage() . "\n";
    }
}

// 2. Session & Telemetry Retention Cleanup (Prune records older than 30 days)
$dataPath = defined('DATA_PATH') ? DATA_PATH : (dirname(__DIR__) . '/data/');
$visitorsFile = $dataPath . 'visitors.json';
if (file_exists($visitorsFile)) {
    $visitors = json_decode(file_get_contents($visitorsFile), true) ?: [];
    $cutoff = time() - (86400 * 30);
    $initialCount = count($visitors);
    $visitors = array_filter($visitors, fn($v) => ($v['last_seen_ts'] ?? 0) >= $cutoff);
    if (count($visitors) !== $initialCount && function_exists('atomicWriteJson')) {
        atomicWriteJson($visitorsFile, $visitors);
        echo "Pruned " . ($initialCount - count($visitors)) . " stale visitor records.\n";
    }
}

echo "[Estate HDR Worker] Finished. Processed {$processedCount} jobs.\n";
