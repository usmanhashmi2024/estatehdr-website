<?php
declare(strict_types=1);

/**
 * Estate HDR — Background Cron Worker (DEACTIVATED ON HOSTINGER)
 * Scheduled campaign worker has been safely decoupled from the web server.
 * Run campaign dispatches locally via Estate Management Software.
 */

header('Content-Type: application/json');
http_response_code(200);

echo json_encode([
    'status' => 'deactivated',
    'message' => 'Campaigns cron is deactivated on the web server to keep the website blazing fast. Run campaigns via Estate Management Software locally.',
    'timestamp' => date('c')
], JSON_PRETTY_PRINT);
exit;
