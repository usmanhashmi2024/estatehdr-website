<?php
/**
 * Estate HDR — Automated Programmatic Article Publisher
 * Can be triggered via:
 * 1. CLI: php cron/auto-article-publisher.php
 * 2. HTTP Webhook: https://estatehdr.com/cron/auto-article-publisher.php?token=EHDR_CRON_SECRET_2026
 * 3. n8n workflow HTTP node
 * 
 * Generates authoritative articles with verified internal links, FAQ Schema markup,
 * auto-publishes under Senior SEO Lead (isolated from regular SEO manager),
 * and physically synchronizes sitemap-posts.xml and sitemap.xml.
 */

if (php_sapi_name() !== 'cli' && (!isset($_GET['token']) || $_GET['token'] !== 'EHDR_CRON_SECRET_2026')) {
    $authHeader = $_SERVER['HTTP_X_API_KEY'] ?? $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if ($authHeader !== 'your_n8n_api_key_here' && !str_contains($authHeader, 'your_n8n_api_key_here')) {
        http_response_code(403);
        die(json_encode(['success' => false, 'error' => 'Forbidden: CLI or authorized token required.']));
    }
}

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json; charset=utf-8');

$topicClusters = [
    [
        'title' => '3D Floor Plan Marketing for Real Estate Listings',
        'category' => '3D Floor Plans & CAD',
        'primaryServiceUrl' => 'https://estatehdr.com/services/floor-plans',
        'primaryAnchor' => 'professional 2D and 3D floor plan redrawing services',
        'secondaryServiceUrl' => 'https://estatehdr.com/#pricing',
        'secondaryAnchor' => 'transparent per-unit floor plan pricing'
    ],
    [
        'title' => 'Drone & Aerial Photography Best Practices for Luxury Real Estate',
        'category' => 'Drone & Aerial Media',
        'primaryServiceUrl' => 'https://estatehdr.com/services/hdr-photo-editing',
        'primaryAnchor' => 'high-dynamic-range aerial photo editing',
        'secondaryServiceUrl' => 'https://estatehdr.com/portfolio.php',
        'secondaryAnchor' => 'interactive real estate portfolio gallery'
    ],
    [
        'title' => 'Virtual Staging vs Traditional Home Staging: Complete 2026 ROI Guide',
        'category' => 'Virtual Staging',
        'primaryServiceUrl' => 'https://estatehdr.com/services/virtual-staging',
        'primaryAnchor' => 'luxury virtual staging and 3D furniture insertion',
        'secondaryServiceUrl' => 'https://estatehdr.com/#pricing',
        'secondaryAnchor' => 'affordable virtual staging rates starting at $12'
    ],
    [
        'title' => 'Real Estate Photography Pricing Guide for High-Volume Agents',
        'category' => 'Pricing & Industry Insights',
        'primaryServiceUrl' => 'https://estatehdr.com/#pricing',
        'primaryAnchor' => 'Estate HDR productized editing pricing',
        'secondaryServiceUrl' => 'https://estatehdr.com/services/hdr-photo-editing',
        'secondaryAnchor' => 'flambient real estate photo editing'
    ],
    [
        'title' => 'Day to Dusk Twilight Conversion vs Live Sunset Shoot Comparison',
        'category' => 'Day to Dusk Twilight',
        'primaryServiceUrl' => 'https://estatehdr.com/services/day-to-dusk',
        'primaryAnchor' => 'day-to-dusk digital twilight conversion',
        'secondaryServiceUrl' => 'https://estatehdr.com/portfolio.php',
        'secondaryAnchor' => 'dusk lighting before and after examples'
    ],
    [
        'title' => 'Item Removal & Decluttering: Preparing Distressed Homes for MLS',
        'category' => 'Item Removal & Declutter',
        'primaryServiceUrl' => 'https://estatehdr.com/services/item-removal',
        'primaryAnchor' => 'seamless object removal and digital decluttering',
        'secondaryServiceUrl' => 'https://estatehdr.com/services/virtual-staging',
        'secondaryAnchor' => 'virtual staging after decluttering'
    ],
    [
        'title' => 'Virtual Renovation and Architectural Visualization for Fixer-Uppers',
        'category' => 'Virtual Renovation',
        'primaryServiceUrl' => 'https://estatehdr.com/services/virtual-renovation',
        'primaryAnchor' => 'photorealistic virtual renovation services',
        'secondaryServiceUrl' => 'https://estatehdr.com/services/floor-plans',
        'secondaryAnchor' => '2D schematic floor plans'
    ],
    [
        'title' => 'How to Bracket 3 to 5 EV Exposures for Flambient Photo Blending',
        'category' => 'HDR Photo Editing',
        'primaryServiceUrl' => 'https://estatehdr.com/services/hdr-photo-editing',
        'primaryAnchor' => 'manual HDR bracket blending and window pull techniques',
        'secondaryServiceUrl' => 'https://estatehdr.com/#faq',
        'secondaryAnchor' => 'file submission specifications in our FAQ'
    ],
    [
        'title' => 'Sky Replacement Techniques for Overcast and Rainy Property Shoots',
        'category' => 'HDR Photo Editing',
        'primaryServiceUrl' => 'https://estatehdr.com/services/hdr-photo-editing',
        'primaryAnchor' => 'photorealistic blue sky replacement service',
        'secondaryServiceUrl' => 'https://estatehdr.com/services/day-to-dusk',
        'secondaryAnchor' => 'golden hour and twilight sky conversions'
    ],
    [
        'title' => 'Why 12-Hour Turnaround Time Matters in Competitive Real Estate Markets',
        'category' => 'Pricing & Industry Insights',
        'primaryServiceUrl' => 'https://estatehdr.com/#pricing',
        'primaryAnchor' => 'guaranteed overnight 12-hour delivery',
        'secondaryServiceUrl' => 'https://estatehdr.com/services/hdr-photo-editing',
        'secondaryAnchor' => 'high volume real estate batch processing'
    ],
    [
        'title' => 'Architectural Twilight Photography: Exterior Lighting & Warm Glow Techniques',
        'category' => 'Day to Dusk Twilight',
        'primaryServiceUrl' => 'https://estatehdr.com/services/day-to-dusk',
        'primaryAnchor' => 'twilight exterior photo retouching',
        'secondaryServiceUrl' => 'https://estatehdr.com/portfolio.php',
        'secondaryAnchor' => 'browse our architectural twilight gallery'
    ],
    [
        'title' => 'Virtual Staging Software vs Dedicated Professional Retouching Studio',
        'category' => 'Virtual Staging',
        'primaryServiceUrl' => 'https://estatehdr.com/services/virtual-staging',
        'primaryAnchor' => 'human-curated 3D virtual staging services',
        'secondaryServiceUrl' => 'https://estatehdr.com/#pricing',
        'secondaryAnchor' => 'unlimited revisions policy'
    ],
    [
        'title' => 'Camera Settings and Flambient Flash Power for Interior Architecture',
        'category' => 'HDR Photo Editing',
        'primaryServiceUrl' => 'https://estatehdr.com/services/hdr-photo-editing',
        'primaryAnchor' => 'professional HDR real estate photo enhancement',
        'secondaryServiceUrl' => 'https://estatehdr.com/#faq',
        'secondaryAnchor' => 'RAW exposure guidelines'
    ],
    [
        'title' => 'Virtual Walkthroughs and Interactive Real Estate Media Tours',
        'category' => '3D Floor Plans & CAD',
        'primaryServiceUrl' => 'https://estatehdr.com/services/floor-plans',
        'primaryAnchor' => 'interactive 3D floor plan renderings',
        'secondaryServiceUrl' => 'https://estatehdr.com/contact.php',
        'secondaryAnchor' => 'speak with our production team'
    ],
    [
        'title' => 'Real Estate Photo Enhancement: Color Correction, Verticals & Lawn Touchups',
        'category' => 'HDR Photo Editing',
        'primaryServiceUrl' => 'https://estatehdr.com/services/hdr-photo-editing',
        'primaryAnchor' => 'vertical correction and grass greening enhancements',
        'secondaryServiceUrl' => 'https://estatehdr.com/#pricing',
        'secondaryAnchor' => 'per-image pricing starting at $0.68'
    ]
];

// Determine next topic: find cluster not yet published or generate unique slug
$existingBlogs = getBlogs();
$existingSlugs = array_map(fn($b) => $b['slug'] ?? '', $existingBlogs);

$selectedCluster = null;
foreach ($topicClusters as $tc) {
    $baseSlug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $tc['title']));
    if (!in_array($baseSlug, $existingSlugs)) {
        $selectedCluster = $tc;
        $finalSlug = $baseSlug;
        break;
    }
}

if (!$selectedCluster) {
    // If all 15 base titles published, create an advanced edition variation
    $selectedCluster = $topicClusters[array_rand($topicClusters)];
    $suffix = date('Y') . '-edition-' . substr(md5(uniqid()), 0, 4);
    $finalSlug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $selectedCluster['title'])) . '-' . $suffix;
}

$title = $selectedCluster['title'];
$category = $selectedCluster['category'];
$primaryUrl = $selectedCluster['primaryServiceUrl'];
$primaryAnchor = $selectedCluster['primaryAnchor'];
$secondaryUrl = $selectedCluster['secondaryServiceUrl'];
$secondaryAnchor = $selectedCluster['secondaryAnchor'];

$content = "<h2>The Strategic Importance of " . htmlspecialchars(explode(':', $title)[0]) . "</h2>"
    . "<p>In contemporary high-stakes real estate marketing, visual assets determine buyer engagement across major property search portals. Over 93% of prospective home buyers begin their property search online via Zillow, Redfin, and Realtor.com. In these fast-moving digital feeds, compelling visual media directly correlates with higher showing volume, reduced days on market, and competitive bidding environments.</p>"
    . "<p>When properties are showcased with immaculate visual post-production, listings achieve up to 340% longer dwell time. Leveraging <a href=\"{$primaryUrl}\">{$primaryAnchor}</a> empowers listing agents, brokerages, and professional real estate photographers to present every home at its absolute aesthetic potential.</p>"
    . "<h2>Commercial Advantages for Top-Producing Agents</h2>"
    . "<p>Listings marketed with polished, high-fidelity visual assets consistently outperform standard camera captures across all key marketing metrics:</p>"
    . "<ul>"
    . "<li><strong>Higher Inquiries:</strong> Listings receive up to 48% more qualified tour bookings within the critical first seven days on market.</li>"
    . "<li><strong>Elevated Valuation Perception:</strong> Crisp window pulls, balanced exposures, and vibrant staging eliminate visual distractions and reinforce asking prices.</li>"
    . "<li><strong>MLS & Syndication Compliance:</strong> Perfectly formatted image files prevent distortion or resolution degradation across syndication networks.</li>"
    . "</ul>"
    . "<blockquote>\"Exceptional imagery is no longer merely an advertising tool—it is the definitive benchmark by which buyers and sellers evaluate professional representation.\"</blockquote>"
    . "<h2>Professional Post-Production Workflow</h2>"
    . "<p>Capturing consistent property media requires disciplined bracketed exposure control and lens leveling. However, attempting to retouch complex lighting imbalances, lawn deficiencies, and overcast skies manually consumes hours of valuable field time.</p>"
    . "<p>By delegating post-production to a dedicated studio with <a href=\"{$secondaryUrl}\">{$secondaryAnchor}</a>, photographers and agencies can streamline their operations, scale their volume, and guarantee flawless 12-hour turnaround for their clientele.</p>"
    . "<h2>Frequently Asked Questions</h2>"
    . "<h3>What turnaround time is guaranteed for listing media?</h3>"
    . "<p>Standard turnaround is guaranteed within 12 to 24 hours, including weekends, ensuring marketing launches proceed on schedule.</p>"
    . "<h3>Are the resulting files MLS-compliant?</h3>"
    . "<p>Yes. All photographic and floor plan edits are calibrated to meet national MLS specifications and strict architectural truth-in-advertising guidelines.</p>"
    . "<h3>How do I submit batch orders?</h3>"
    . "<p>RAW, TIFF, or high-res JPEG files can be uploaded directly into the client portal, where style preferences and sky replacement options are configured with one click.</p>";

$plainText = strip_tags($content);
$excerpt = mb_substr($plainText, 0, 160) . '...';
$wordCount = str_word_count($plainText);
$readTime = max(1, (int)ceil($wordCount / 200)) . ' min read';

$schemaObj = [
    '@context' => 'https://schema.org',
    '@type'    => 'FAQPage',
    'mainEntity' => [
        [
            '@type' => 'Question',
            'name' => "How does {$title} impact real estate marketing?",
            'acceptedAnswer' => [
                '@type' => 'Answer',
                'text' => "Professional media increases dwell time by 340% and generates up to 48% more qualified property inquiries on online portals."
            ]
        ],
        [
            '@type' => 'Question',
            'name' => "What is the turnaround time for Estate HDR editing services?",
            'acceptedAnswer' => [
                '@type' => 'Answer',
                'text' => "Estate HDR guarantees 12 to 24 hour turnaround across HDR photo editing, virtual staging, and floor plan redrawing."
            ]
        ]
    ]
];

$postData = [
    'title'            => $title,
    'slug'             => $finalSlug,
    'excerpt'          => $excerpt,
    'content'          => $content,
    'category'         => $category,
    'tags'             => ['Real Estate Photography', 'HDR Editing', $category, 'SEO Cluster'],
    'featured_image'   => '/assets/images/portfolio/hdr/1-after.jpg',
    'author'           => 'Estate HDR Team',
    'author_id'        => 'adm-senior-seo',
    'created_by'       => 'adm-senior-seo',
    'read_time'        => $readTime,
    'status'           => 'published', // Instant live publishing
    'meta_title'       => $title . ' | Estate HDR',
    'meta_description' => $excerpt,
    'canonical_url'    => 'https://estatehdr.com/blog/' . urlencode($finalSlug),
    'robots'           => 'index, follow',
    'exclude_sitemap'  => false,
    'schema_json'      => json_encode($schemaObj, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)
];

$saved = saveBlog($postData);

// Physically generate and update sitemaps on disk
$sitemaps = generatePhysicalSitemaps();

echo json_encode([
    'success'         => true,
    'message'         => 'Article published live and sitemaps synchronized.',
    'article' => [
        'id'          => $saved['id'] ?? '',
        'title'       => $saved['title'] ?? '',
        'slug'        => $saved['slug'] ?? '',
        'category'    => $saved['category'] ?? '',
        'status'      => $saved['status'] ?? 'published',
        'author'      => $saved['author'] ?? 'Estate HDR Team',
        'created_by'  => $saved['created_by'] ?? '',
        'word_count'  => $wordCount,
        'read_time'   => $readTime,
        'live_url'    => 'https://estatehdr.com/blog/' . urlencode($saved['slug'] ?? '')
    ],
    'sitemaps_updated' => [
        'primary_sitemap_index' => 'https://estatehdr.com/sitemap.xml',
        'pages_sitemap'         => 'https://estatehdr.com/sitemap-pages.xml',
        'posts_sitemap'         => 'https://estatehdr.com/sitemap-posts.xml',
        'robots_txt'            => 'https://estatehdr.com/robots.txt',
        'file_sizes'            => $sitemaps
    ]
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
