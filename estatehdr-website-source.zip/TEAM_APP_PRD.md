# Product Requirements Document (PRD)
# Estate HDR — Team & Retoucher Mobile Application

**App Name:** Estate HDR Team Workstation  
**Document Version:** 1.0.0  
**Status:** Approved for Design & Engineering  
**Target Platforms:** iOS (Apple App Store / TestFlight) & Android (Google Play Store)  
**Author:** Estate HDR Operations & Engineering Group  
**Target Audience:** Photo Retouchers, 3D Stagers, Quality Supervisors, Team Leads & Production Managers  

---

## 1. Executive Summary & Operational Vision

The **Estate HDR Team App** is a mission-critical mobile production command center. It empowers our globally distributed team of photo retouchers, virtual stagers, quality control (QC) supervisors, and shift leads to claim orders, manage turnaround countdowns, upload deliverables, resolve client revision tickets, and maintain strict SLA compliance 24/7/365.

### Key Operational Goals
- **Zero SLA Breaches:** Real-time audio-visual push warnings and live countdown timers for 24h Standard, 12h Express, and 6h Rush orders.
- **1-Tap Job Claiming:** Atomic order distribution allowing verified retouchers on shift to claim orders in real time.
- **Fast Amendment Resolution:** Direct mobile viewing of client visual pin coordinates and audio voice memos for rapid <2-hour revision turnarounds.
- **Supervisory Quality Control (QC):** 1-tap review, 5-star scoring, or rejection with constructive feedback directly from supervisors' phones.
- **Shift Performance & Earnings:** Live transparency into daily completed photo counts, acceptance rates, and weekly pay ledgers.

---

## 2. User Roles & Hierarchy

```
┌─────────────────────────────────────────────────────────────┐
│                 ESTATE HDR TEAM APP ROLES                   │
├─────────────────────────────────────────────────────────────┤
│ 1. Photo Editor / Stager    ➔ Claims & processes orders     │
│ 2. Team Lead                ➔ Monitors team queue & audits  │
│ 3. Quality Supervisor       ➔ Approves/Rejects deliverables │
│ 4. Production Manager       ➔ SLA monitoring & reallocations│
│ 5. Studio Admin / Owner     ➔ Full organizational oversight │
└─────────────────────────────────────────────────────────────┘
```

---

## 3. Information Architecture & Navigation

```
Team Mobile App (Bottom Tab Navigation)
├── 1. Production Dashboard (Shift Command)
│   ├── Shift Status Toggle (Available / On Shift / Break / Off Shift)
│   ├── Active Shift Timer & Daily Photo Count
│   ├── SLA Critical Breach Alert Banner (Orders with <2 hours remaining)
│   ├── KPI Metric Cards (Claimed, Pending QC, Completed Today, Daily Earnings)
│   └── My Active Orders List (Live countdown timers)
├── 2. Job Queue (Unassigned Orders)
│   ├── Filters: Service Type (HDR, Staging, Twilight, Floor Plans)
│   ├── Filters: SLA Urgency (Rush 6h, Express 12h, Standard 24h)
│   ├── Order Preview Card (Photo count, service requirements, client style preset)
│   └── 1-Tap "Claim Order" Button with Concurrency Lock
├── 3. Workstation (Order Execution)
│   ├── Client Brief & Specific Property Notes
│   ├── RAW Brackets Cloud Download Link (Google Drive / Dropbox)
│   ├── Deliverable Uploader (Before/After WebP/JPEG + High-Res Archive Link)
│   ├── Mandatory 5-Point Self-QC Checklist
│   └── "Submit to QC Supervisor" Button
├── 4. Amendments Desk (Revision Tickets)
│   ├── Urgent Revision Queue (Ordered by time remaining)
│   ├── Interactive Client Pin Coordinate Overlay Viewer
│   ├── Voice Memo Player (Listen to client audio instructions)
│   ├── Previous Version vs. New Edit Comparison
│   └── "Submit Re-Delivered Revision" Button
├── 5. QC Review Center (Supervisor / Lead Mode Only)
│   ├── Pending QC Order Submissions
│   ├── Before/After Inspection Tool with 400% Zoom
│   ├── 1-Tap "Approve & Release to Client"
│   └── "Reject & Return to Editor" with Timestamped Correction Notes
└── 6. Profile & Earnings
    ├── Monthly / Weekly Shift Attendance Log
    ├── Completed Photo Ledger & Itemized Pay Calculations
    ├── Quality Rating (% First-Time QC Pass Rate)
    └── Embedded Production SOP Handbook & Tutorial Videos
```

---

## 4. Detailed Feature Specifications

### Epic 1: Shift Check-In & Availability Management
- **Shift Status Toggle:** Switch between `On Shift (Available)`, `In Production`, `On Break`, and `Off Shift`.
- **Auto-Assignment Eligibility:** Only retouchers with status `On Shift` receive high-priority push notifications for new incoming rush jobs.
- **Shift Time Tracker:** Tracks active production hours and calculates daily throughput velocity.

### Epic 2: Real-Time Job Queue & 1-Tap Claiming
- **Job Feed:** Live feed of incoming orders populated via WebSockets.
- **Service Tags:** Highlighting HDR Blending, 3D Staging, Virtual Twilight, Decluttering, or Custom Floor Plans.
- **Urgency Badges:** Red badges for 6h Rush, Yellow for 12h Express, Gold for 24h Standard.
- **Atomic Concurrency Lock:** Ensures an order can only be claimed by exactly one retoucher; prevents duplicate processing.

### Epic 3: Workstation & Deliverable Verification
- **Client Style Dossier:** Displays client's preset (e.g. "Crisp Scandinavian — Cool Interior Lights, Blue Sky #4, Muted Wood Tones").
- **RAW Source Link:** 1-tap copy link or direct cloud storage launcher.
- **Deliverables Uploader:** Upload processed Before and After proof images and provide high-resolution cloud links.
- **Mandatory 5-Point Self-QC Checklist:**
  1. [ ] Vertical lines 100% perpendicular (2-point perspective corrected).
  2. [ ] Window views balanced (no clipped highlights or dark halos).
  3. [ ] Ceiling and wall color casts neutralized.
  4. [ ] Sky replacement realistic with matching lighting angle.
  5. [ ] Camera sensor dust spots and lens artifacts removed.

### Epic 4: Visual Amendment Resolution Desk
- **Visual Coordinate Pin Mapping:** Overlays numbered pins at the exact `x, y` percentages specified by the client.
- **Voice Memo Playback:** Native in-app audio player to listen to client voice recordings.
- **Revision History:** Side-by-side comparison of v1 deliverable and v2 revision before submitting.
- **SLA Countdown for Revisions:** 2-hour standard countdown timer for all revision tickets.

### Epic 5: Supervisor Quality Control (QC) Center
- **Inspection Hub:** Dedicated interface for shift supervisors and team leads to review editor submissions before they reach clients.
- **Approval Flow:** 1-tap approval automatically dispatches `ORDER_READY` push notification to the client.
- **Rejection Flow:** If flaws are detected, supervisor selects rejection reasons and returns job to the editor's queue with priority flag.

### Epic 6: Earnings Ledger & SOP Handbook
- **Earnings Calculator:** Real-time earnings breakdown per photo and per service tier.
- **Weekly Payout Tracker:** Clear accounting of approved photos and scheduled bank/crypto/PayPal payouts.
- **Interactive SOP Handbook:** In-app access to standard operating procedures, architectural retouching guidelines, and video tutorials.

---

## 5. Non-Functional Requirements & Operational KPIs

- **Push Notification Latency:** Under 500ms for incoming rush job alerts.
- **Offline Resilience:** Editors can view active job instructions and client style guides without active cellular connection.
- **Security:** Strict role-based permission enforcement; watermarking on all internal proofing screens.
- **Success Metrics:** >99.2% on-time SLA delivery rate; <2.5% supervisor QC rejection rate; 100% amendment resolution within 2 hours.
