<?php
/**
 * Estate HDR — High-Resolution Portfolio Image Sitemap
 * Indexes all Before/After architectural photos directly for Google Images SERP dominance
 */
require_once __DIR__ . '/includes/config.php';

header('Content-Type: application/xml; charset=utf-8');
header('Cache-Control: public, max-age=3600');

$now = date('Y-m-d\TH:i:s+00:00');

$portfolioImages = [
    ['title' => 'Luxury Villa HDR Bracket Blending', 'img' => '/assets/images/portfolio/hdr/1-after.jpg'],
    ['title' => 'Modern Living Room Flambient Window Pull', 'img' => '/assets/images/portfolio/hdr/2-after.jpg'],
    ['title' => 'Architectural Twilight Masterpiece', 'img' => '/assets/images/portfolio/hdr/3-after.jpg'],
    ['title' => 'Contemporary Kitchen Virtual Staging', 'img' => '/assets/images/portfolio/virtual-staging/1-after.jpg'],
    ['title' => 'Master Bedroom 3D Furniture Placement', 'img' => '/assets/images/portfolio/virtual-staging/2-after.jpg'],
    ['title' => 'Golden Hour Day to Dusk Conversion', 'img' => '/assets/images/portfolio/day-to-dusk/1-after.jpg'],
    ['title' => 'Driveway Car & Bin Digital Removal', 'img' => '/assets/images/portfolio/item-removal/1-after.jpg'],
    ['title' => '2D & 3D Architectural Color Floor Plan', 'img' => '/assets/images/portfolio/floor-plans/1.jpg']
];

echo '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
    <url>
        <loc><?= BASE_URL ?>/portfolio</loc>
        <lastmod><?= $now ?></lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.90</priority>
        <?php foreach ($portfolioImages as $img): ?>
        <image:image>
            <image:loc><?= BASE_URL . $img['img'] ?></image:loc>
            <image:title><?= htmlspecialchars($img['title'], ENT_QUOTES, 'UTF-8') ?> — Estate HDR</image:title>
            <image:caption><?= htmlspecialchars($img['title'], ENT_QUOTES, 'UTF-8') ?> by Estate HDR Studio.</image:caption>
        </image:image>
        <?php endforeach; ?>
    </url>
</urlset>
