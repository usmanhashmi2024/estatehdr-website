<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';

$blogsData = getPublishedBlogs();

$selectedCat = trim($_GET['category'] ?? ($_GET['cat'] ?? ''));
if (!empty($selectedCat) && strtolower($selectedCat) === 'uncategorized') {
    header("HTTP/1.1 404 Not Found");
    require_once __DIR__ . '/404.php';
    exit;
}
$selectedTag = trim($_GET['tag'] ?? '');
$searchQuery = trim($_GET['q'] ?? '');

$filteredBlogs = array_filter($blogsData, function($b) use ($selectedCat, $selectedTag, $searchQuery) {
    if ($selectedCat !== '' && ($b['category'] ?? '') !== $selectedCat) return false;
    if ($selectedTag !== '') {
        $tags = is_array($b['tags'] ?? null) ? $b['tags'] : array_map('trim', explode(',', $b['tags'] ?? ''));
        if (!in_array($selectedTag, $tags)) return false;
    }
    if ($searchQuery !== '') {
        $kw = strtolower($searchQuery);
        $match = str_contains(strtolower($b['title']), $kw) ||
                 str_contains(strtolower($b['excerpt']), $kw) ||
                 str_contains(strtolower($b['category'] ?? ''), $kw);
        if (!$match) return false;
    }
    return true;
});
$filteredBlogs = array_values($filteredBlogs);

$allPostCategories = function_exists('getPostCategories') ? getPostCategories() : [];
$catCounts = [];
foreach ($blogsData as $b) {
    $cName = $b['category'] ?? 'General';
    $catCounts[$cName] = ($catCounts[$cName] ?? 0) + 1;
}

$seo = getPageSeo('blog') ?: [
    'meta_title'       => 'Estate HDR Blog — Real Estate Photography & Editing Insights',
    'meta_description' => 'Expert guides on HDR blending, virtual staging, flambient photography, twilight conversion, and real estate marketing strategies.',
    'canonical_url'    => BASE_URL . '/blog.php',
    'og_image'         => BASE_URL . '/assets/images/portfolio/virtual-staging/1-after.jpg',
    'robots'           => 'index, follow',
    'schema_json'      => ''
];

$pageTitle = htmlspecialchars($seo['meta_title'] ?? 'Estate HDR Blog');
$pageDesc  = htmlspecialchars($seo['meta_description'] ?? '');
if (!empty($selectedCat)) {
    $canonUrl = rtrim(BASE_URL, '/') . '/blog?cat=' . urlencode($selectedCat);
} else {
    $canonUrl = htmlspecialchars(!empty($seo['canonical_url']) && !str_ends_with($seo['canonical_url'], '.php') ? $seo['canonical_url'] : (rtrim(BASE_URL, '/') . '/blog'));
}
$ogImage   = htmlspecialchars(!empty($seo['og_image']) ? $seo['og_image'] : (BASE_URL . '/assets/images/portfolio/virtual-staging/1-after.jpg'));
// Tag pages automatically receive noindex to prevent duplicate content
$robots    = !empty($selectedTag) ? 'noindex, follow' : htmlspecialchars($seo['robots'] ?? 'index, follow');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<meta name="description" content="<?= $pageDesc ?>">
<meta name="robots" content="<?= $robots ?>">
<link rel="canonical" href="<?= $canonUrl ?>">
<!-- Open Graph -->
<meta property="og:type"        content="website">
<meta property="og:url"         content="<?= $canonUrl ?>">
<meta property="og:title"       content="<?= $pageTitle ?>">
<meta property="og:description" content="<?= $pageDesc ?>">
<meta property="og:image"       content="<?= $ogImage ?>">
<?= renderSeoHeadTags() ?>
<?php if (!empty($seo['schema_json'])): ?>
<!-- Dynamic JSON-LD Schema -->
<script type="application/ld+json" nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
<?= $seo['schema_json'] ?>
</script>
<?php endif; ?>
<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap" onload="this.onload=null;this.rel='stylesheet'">
<noscript>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap">
</noscript>
<link rel="stylesheet" href="/assets/css/bundle.css?v=<?= file_exists(ROOT_PATH . '/assets/css/bundle.css') ? filemtime(ROOT_PATH . '/assets/css/bundle.css') : time() ?>">
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/includes/public-header.php'; ?>

<main class="flex-1 pt-32 pb-20 px-6 max-w-7xl mx-auto w-full">
  <div class="text-center max-w-3xl mx-auto mb-14">
    <div class="section-tag mb-3">Industry Knowledge Base</div>
    <h1 class="text-4xl sm:text-5xl font-black text-white tracking-tight">Real Estate Photography &amp; Editing Guides</h1>
    <p class="text-gray-400 text-sm mt-4">In-depth tutorials, HDR bracketing workflows, and ROI analyses written by master real estate photo retouchers.</p>
  </div>

  <!-- Search & Category Filters -->
  <div class="glass-card rounded-2xl p-5 mb-12 border border-dark-border shadow-xl flex flex-wrap items-center justify-between gap-4">
    <!-- Category Tabs -->
    <div class="flex items-center gap-2 overflow-x-auto py-1 text-xs no-scrollbar">
      <a href="/blog" class="px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap inline-flex items-center gap-2 <?= empty($selectedCat) && empty($selectedTag) ? 'bg-gold text-dark font-black shadow-glow' : 'bg-[#161622] text-white border border-[#2A2A3A] hover:border-gold hover:text-gold' ?>">
        <span>All Guides</span>
        <span class="px-2 py-0.5 rounded-full text-[11px] <?= empty($selectedCat) && empty($selectedTag) ? 'bg-dark/20 text-dark font-black' : 'bg-gold/20 text-gold font-bold' ?>"><?= count($blogsData) ?></span>
      </a>
      <?php foreach ($allPostCategories as $c): 
        $cName = $c['name'];
        $count = $catCounts[$cName] ?? 0;
        $isActive = ($selectedCat === $cName);
      ?>
      <a href="/blog?cat=<?= urlencode($cName) ?>" class="px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap inline-flex items-center gap-2 <?= $isActive ? 'bg-gold text-dark font-black shadow-glow' : 'bg-[#161622] text-white border border-[#2A2A3A] hover:border-gold hover:text-gold' ?>">
        <span><?= htmlspecialchars($cName) ?></span>
        <?php if ($count > 0): ?>
          <span class="px-2 py-0.5 rounded-full text-[11px] <?= $isActive ? 'bg-dark/20 text-dark font-black' : 'bg-gold/20 text-gold font-bold' ?>"><?= $count ?></span>
        <?php endif; ?>
      </a>
      <?php endforeach; ?>
    </div>

    <!-- Search Form -->
    <form method="GET" action="/blog" class="flex items-center gap-2">
      <?php if (!empty($selectedCat)): ?>
        <input type="hidden" name="cat" value="<?= htmlspecialchars($selectedCat) ?>">
      <?php endif; ?>
      <input type="text" name="q" value="<?= htmlspecialchars($searchQuery) ?>" class="form-input text-xs py-2 px-3.5 w-64" placeholder="Search guides by keyword...">
      <button type="submit" class="btn-gold py-2 px-4 text-xs font-bold">Search</button>
    </form>
  </div>

  <!-- Articles Grid -->
  <?php if (empty($filteredBlogs)): ?>
  <div class="p-20 text-center text-gray-500 text-sm glass-card rounded-2xl border border-dark-border">
    <div class="text-4xl mb-3">🔍</div>
    <h3 class="text-white font-bold text-base mb-1">No articles found</h3>
    <p class="text-xs text-gray-400">Try searching with different keywords or view all categories.</p>
    <a href="/blog" class="btn-gold py-2 px-5 text-xs font-bold shadow-glow mt-4 inline-block">View All Guides</a>
  </div>
  <?php else: ?>
  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
    <?php foreach ($filteredBlogs as $post): ?>
    <article class="glass-card rounded-2xl overflow-hidden border border-dark-border hover:border-gold/50 transition-all flex flex-col group shadow-xl">
      <a href="/blog/<?= urlencode($post['slug']) ?>" class="block relative aspect-[16/10] overflow-hidden bg-dark">
        <img loading="lazy" decoding="async" src="<?= htmlspecialchars(!empty($post['featured_image']) ? $post['featured_image'] : '/assets/images/blog/ai-commercial-real-estate-listings-optimization.jpg') ?>" onerror="this.src='/assets/images/blog/ai-commercial-real-estate-listings-optimization.jpg'" 
             alt="<?= htmlspecialchars($post['title']) ?>" 
             class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500">
        <span class="absolute top-3 left-3 px-3 py-1 rounded-lg bg-dark/90 backdrop-blur-md text-xs font-bold text-gold border border-gold/30">
          <?= htmlspecialchars($post['category'] ?? 'Guide') ?>
        </span>
      </a>

      <div class="p-6 flex-1 flex flex-col justify-between space-y-4">
        <div>
          <div class="flex items-center gap-3 text-xs text-gray-400 font-mono mb-2">
            <span><?= date('M j, Y', strtotime($post['date'] ?? ($post['created_at'] ?? 'now'))) ?></span>
            <span>•</span>
            <span><?= htmlspecialchars($post['read_time'] ?? '5 min read') ?></span>
          </div>

          <h2 class="text-lg font-bold text-white group-hover:text-gold transition-colors leading-snug line-clamp-2">
            <a href="/blog/<?= urlencode($post['slug']) ?>">
              <?= htmlspecialchars($post['title']) ?>
            </a>
          </h2>

          <?php
            $cardExcerpt = !empty(trim($post['excerpt'] ?? ''))
              ? $post['excerpt']
              : (!empty(trim($post['meta_description'] ?? ''))
                  ? $post['meta_description']
                  : (mb_substr(trim(strip_tags($post['content'] ?? '')), 0, 160) . '...'));
          ?>
          <p class="text-xs text-gray-400 mt-2.5 leading-relaxed line-clamp-3">
            <?= htmlspecialchars($cardExcerpt) ?>
          </p>
        </div>

        <div class="pt-4 border-t border-dark-border flex items-center justify-between">
          <?php
            $authorDisplayName = getPostAuthorDisplayName($post);
            $isSeniorOrTeam = ($authorDisplayName === 'Estate HDR Team' || ($post['created_by'] ?? '') === 'adm-senior-seo');
            $authorInitial = strtoupper(mb_substr($authorDisplayName, 0, 1));
          ?>
          <span class="text-xs font-semibold text-gray-300 flex items-center gap-2">
            <span class="w-5 h-5 rounded-full <?= $isSeniorOrTeam ? 'bg-gold text-dark' : 'bg-emerald-500 text-white' ?> flex items-center justify-center font-bold text-[9px]"><?= htmlspecialchars($authorInitial) ?></span>
            <span><?= htmlspecialchars($authorDisplayName) ?></span>
          </span>

          <a href="/blog/<?= urlencode($post['slug']) ?>" class="text-xs font-bold text-gold group-hover:underline flex items-center gap-1">
            <span>Read Guide</span> &rarr;
          </a>
        </div>
      </div>
    </article>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</main>

<footer class="border-t border-dark-border bg-dark-card py-10 px-6 text-xs text-gray-500 text-center">
  <div class="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
    <div>&copy; <?= date('Y') ?> Estate HDR Retouching. All rights reserved.</div>
    <div class="flex items-center gap-5 text-gray-400">
      <a href="<?= FACEBOOK_LINK ?>" target="_blank" class="hover:text-blue-400" rel="noopener noreferrer">Facebook</a>
      <a href="<?= INSTAGRAM_LINK ?>" target="_blank" class="hover:text-pink-400" rel="noopener noreferrer">Instagram</a>
      <a href="<?= LINKEDIN_LINK ?>" target="_blank" class="hover:text-blue-300" rel="noopener noreferrer">LinkedIn</a>
      <a href="<?= WHATSAPP_LINK ?>" target="_blank" class="hover:text-emerald-400" rel="noopener noreferrer">WhatsApp</a>
      <a href="/terms" class="hover:text-gold">Terms</a>
      <a href="/privacy" class="hover:text-gold">Privacy</a>
      <a href="/sitemap.xml" class="hover:text-gold">Sitemap.xml</a>
      <a href="/contact" class="hover:text-gold">Contact</a>
    </div>
  </div>
</footer>

<?php require_once __DIR__ . '/includes/chat-widgets.php'; ?>
</body>
</html>
