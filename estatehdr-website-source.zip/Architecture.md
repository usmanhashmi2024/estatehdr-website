# 🏛️ Estate HDR — Complete System Architecture

> **Document Version:** 2.0  
> **Target Platform:** Luxury Real Estate Photo Editing & 3D Virtual Staging Studio CRM  
> **Runtime Environment:** PHP 8.2+, Apache / Nginx, Hostinger Cloud  
> **Storage Architecture:** High-Concurrency Atomic JSON Flat-File Engine (`data/`)  

---

## 📑 Table of Contents
1. [Platform Overview & Tech Stack](#1-platform-overview--tech-stack)
2. [Directory & System Structure](#2-directory--system-structure)
3. [Multi-Tier RBAC Architecture (Roles & Boundaries)](#3-multi-tier-rbac-architecture)
4. [Order Processing Pipeline (End-to-End Workflow)](#4-order-processing-pipeline)
5. [Dual-Storage Synchronization Engine](#5-dual-storage-synchronization-engine)
6. [Financial Ledger & Double-Entry Accounting Engine](#6-financial-ledger--double-entry-accounting-engine)
7. [Privacy Shielding Engine](#7-privacy-shielding-engine)
8. [Notification & Email Dispatch Architecture](#8-notification--email-dispatch-architecture)
9. [Client Style Preference Engine](#9-client-style-preference-engine)
10. [Security & Hardening Architecture](#10-security--hardening-architecture)

---

## 1. Platform Overview & Tech Stack

Estate HDR is an enterprise-grade digital retouching CRM engineered specifically for high-volume architectural real estate media agencies. The platform models the operational workflows of tier-1 global studios (e.g., Esoft, BoxBrownie).

```
┌────────────────────────────────────────────────────────────────────────┐
│                          PRESENTATION LAYER                            │
│  Tailwind CSS (Gold/Dark Luxury Theme) • Vanilla JS • Responsive UI   │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼────────────────────────────────────┐
│                          APPLICATION LAYER                             │
│  Authentication & RBAC (`auth.php`) • Order Engine (`db.php`)          │
│  Production Pipeline (`saas-db.php`) • Dispatcher (`mail.php`)         │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
┌───────────────────────────────────▼────────────────────────────────────┐
│                            DATA LAYER                                  │
│  Atomic Lock JSON Store (`LOCK_EX`) • Audit Logs • Financial Ledger    │
└────────────────────────────────────────────────────────────────────────┘
```

- **Backend Runtime:** Native PHP 8.2+ with strict typing and defense-in-depth error handling.
- **Storage Subsystem:** High-speed atomic JSON storage utilizing flock (`LOCK_EX`) and temporary write swaps to prevent race conditions without SQL overhead.
- **Frontend Layer:** Tailwind CSS with an architectural Gold & Midnight Obsidian theme (`#C9A84C` / `#0A0A0F`), secured by Content Security Policy (CSP) cryptographic nonces.
- **Integration Layer:** SMTP Email Engine (PHPMailer with TLS / SPF / DKIM verification), Discord Webhooks, and PayPal.

---

## 2. Directory & System Structure

```
Estate HDR Site/
├── admin/                         # Internal Staff & Operations Hub
│   ├── index.php                  # Admin Master Login & Portal Gateway
│   ├── orders.php                 # Orders Control Panel (Badges, Toggles, Filters)
│   ├── order-view.php             # Individual Job Manager, Audit Trail, & Delivery Form
│   ├── order-new.php              # Proxy Job Creation (on behalf of client)
│   ├── supervisor-dashboard.php   # Supervisor Intake & Delivery Dispatch Hub
│   ├── teamlead-dashboard.php     # Team Lead QA & Editor Assignment Hub
│   ├── editor-dashboard.php       # Photo Editor Workspace (Assigned Jobs Queue)
│   ├── editor-order.php           # Photo Editor Processing & Output Upload Screen
│   ├── ledger.php                 # Master Double-Entry Financial Ledger (CEO/Owner only)
│   ├── clients.php                # Client Directory & Balance Inspection
│   ├── users.php                  # Staff & System Accounts Management
│   ├── hr-dashboard.php           # HR Staff, Shift Attendance, & SOP Portal
│   └── pages.php / posts.php      # CMS & SEO Engine
├── includes/                      # Core Engines & Shared Libraries
│   ├── config.php                 # Global Configuration & Environment Constants
│   ├── auth.php                   # Authentication, Session Hardening & RBAC Engine
│   ├── db.php                     # Client Database & Legacy Orders Controller
│   ├── saas-db.php                # Production Pipeline & Privacy Shielding Engine
│   ├── mail.php                   # Luxury Email Dispatcher & PayPal Templates
│   ├── security.php               # CSP Nonce, CSRF, & Security Headers
│   ├── public-header.php          # Main Website Navigation & Gold Active Indicator
│   └── admin-header.php           # Internal Admin Bar & Real-time Role Switcher
├── data/                          # Secure Storage Vault (Protected via .htaccess)
│   ├── users.json                 # Client Accounts & Style Preferences
│   ├── admin_users.json           # Internal Staff Profiles & Role Assignments
│   ├── saas_orders.json           # High-Volume Master Production Pipeline
│   ├── saas_employees.json        # Team Leads & Photo Editors Roster
│   ├── saas_attendance.json       # Real-Time Staff Online Presence & Shifts
│   ├── ledger.json                # Master Double-Entry Financial Records
│   ├── leads.json                 # Free Trial Intake Records
│   └── orders/                    # Individual Client Order Files (`ORD-XXXX.json`)
├── order-new.php                  # Client Portal: New Job Submission
├── order-view.php                 # Client Portal: Tracking, Downloads, & Amendments
└── dashboard.php                  # Client Portal: Live Account & Pipeline Overview
```

---

## 3. Multi-Tier RBAC Architecture

Estate HDR enforces a strict 7-role privilege hierarchy. Unprivileged roles are shielded from confidential client data and financial records.

```mermaid
flowchart TD
    subgraph Executives ["Executive Tier"]
        Owner["Owner / CEO / Super Admin<br/>(Full Unrestricted Access)"]
        Manager["Production Manager<br/>(Operations & Pipeline, No Finance/HR)"]
    end

    subgraph Operations ["Operations Tier"]
        Supervisor["Supervisor<br/>(Intake, TL Allocation, Final Delivery)"]
        HR["HR Officer<br/>(Staff Roster, Attendance, SOPs)"]
        SEO["SEO Manager<br/>(CMS, Blogs, Sitemap)"]
    end

    subgraph Production ["Production Floor (Privacy-Shielded)"]
        TL["Team Lead<br/>(Editor Delegation, QA Inspection)"]
        Editor["Photo Editor<br/>(Retouching, Output Upload)"]
    end

    subgraph Public ["External Tier"]
        Client["Client<br/>(Order Placement, Downloads, Amendments)"]
    end

    Owner --> Manager --> Supervisor --> TL --> Editor
    Owner --> HR
    Owner --> SEO
    Client -. Orders .-> Supervisor
```

### Detailed Privilege Matrix

| Feature / Action | Owner / CEO | Manager | Supervisor | Team Lead | Photo Editor | Client |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Financial Ledger (`ledger.php`)** | ✅ Full | ❌ Blocked | ❌ Blocked | ❌ Blocked | ❌ Blocked | ❌ Blocked |
| **Delete / Purge Orders** | ✅ Full | ✅ Delete Only | ❌ Blocked | ❌ Blocked | ❌ Blocked | ❌ Blocked |
| **Switch Free Trial / Live Order** | ✅ Yes | ✅ Yes | ✅ Yes | ❌ Blocked | ❌ Blocked | ❌ Blocked |
| **Daily Intake & TL Assignment** | ✅ Yes | ✅ Yes | ✅ Primary | ❌ Blocked | ❌ Blocked | ❌ Blocked |
| **Editor Assignment & QA Review** | ✅ Yes | ✅ Yes | ✅ Yes | ✅ Primary | ❌ Blocked | ❌ Blocked |
| **Raw Retouching & Output Upload** | ✅ Yes | ✅ Yes | ❌ Read | ✅ QA Check | ✅ Primary | ❌ Blocked |
| **Deliver to Client & Dispatch Email** | ✅ Yes | ✅ Yes | ✅ Primary | ❌ Blocked | ❌ Blocked | ❌ Blocked |
| **Client Confidential Data Visibility** | ✅ 100% | ✅ 100% | ✅ 100% | 🛡️ Masked | 🛡️ Masked | 👤 Self Only |
| **Place Orders** | ✅ Proxy | ✅ Proxy | ❌ Blocked | ❌ Blocked | ❌ Blocked | ✅ Primary |

---

## 4. Order Processing Pipeline

```mermaid
sequenceDiagram
    autonumber
    actor Client as 👤 Client / Lead
    participant Portal as 🌐 Client Portal
    participant Sup as 📋 Supervisor Hub
    participant TL as 🛡️ Team Lead Hub
    participant Ed as 🎨 Photo Editor
    participant Mail as 📧 Mail Dispatcher

    Client->>Portal: Place Order (Live Order OR Free Trial)
    Portal->>Sup: Auto-Bridge to SaaS Pipeline & Notify Discord
    Sup->>Sup: Inspect Order Classification (Free Trial vs Live)
    Sup->>TL: Assign Job to Online Team Lead
    TL->>Ed: Delegate Job to Active Photo Editor
    Note over Ed: Privacy Shield Active (Email, Phone & Cost Masked)
    Ed->>Ed: Retouch Photos (HDR Blending, Windows, Sky)
    Ed->>TL: Upload Output Storage Path & Submit for QA
    alt QA Requires Revisions
        TL->>Ed: Request Revision (Detailed Feedback)
        Ed->>TL: Re-submit Corrected Output
    else QA Approved
        TL->>Sup: Mark QA Approved (Ready for Client Delivery)
    end
    Sup->>Sup: Input Client Download Link
    alt Is Free Trial ($0.00)
        Sup->>Mail: Dispatch Complimentary Delivery Email (Zero Charge, No PayPal)
    else Is Live Order (Paid)
        Sup->>Mail: Dispatch Luxury Invoice Email (With PayPal Payment Details)
    end
    Mail->>Client: Deliver Download Link & Notification
    Client->>Portal: Download High-Res Files & (Optional) Request Amendments
```

---

## 5. Dual-Storage Synchronization Engine

The platform operates on a synchronized dual-file architecture to decouple client portal requests from the real-time production floor:

1. **Client Storage (`data/orders/ORD-XXXX.json`):**
   - Individual ticket record for client interactions.
   - Contains message threads, amendments history, and public download links.
2. **Production Pipeline (`data/saas_orders.json`):**
   - High-throughput flat index for Team Leads and Supervisors.
   - Houses production queues, editor assignments, internal storage paths, and turnaround deadlines.
3. **Synchronization Core (`includes/saas-db.php` -> `syncLegacyOrdersToSaaS()`):**
   - Watches for new client submissions and automatically bridges them into `saas_orders.json`.
   - Propagates classification changes (`free_trial` vs `live_order`) across both data stores atomically.

---

## 6. Financial Ledger & Double-Entry Accounting Engine

Estate HDR features a transparent running account balance system (`data/ledger.json`):

$$\text{Client Balance} = \sum \text{Payments Received (Credits)} - \sum \text{Delivered Orders (Debits)}$$

```mermaid
flowchart LR
    A["Order Delivered"] --> B{"Is Free Trial?"}
    B -- "YES (100% Free)" --> C["Ledger Immunity: $0.00 Debit (No Debt Added)"]
    B -- "NO (Live Order)" --> D["Record Billed Debit (INV-XXXX)"]
    D --> E["Balance Decreases (Pending Payment)"]
    F["Client Sends PayPal Payment"] --> G["Admin Records Received Credit"]
    G --> H["Balance Settled ($0.00)"]
```

- **Free Trial Protection:** All free trial orders (`is_trial = true`) are strictly blocked from generating ledger debit entries.
- **Reconciliation Engine (`reconcileAllOrdersLedger()`):** Scans all delivered production records and matches them with invoice references while bypassing free trials.

---

## 7. Privacy Shielding Engine

To prevent client poaching and maintain corporate secrecy, sensitive information is masked for operational roles:

```php
// includes/saas-db.php
function maskOrderForRole(array $order, array $userRoles): array {
    $isPrivileged = in_array('owner', $userRoles) || in_array('manager', $userRoles) || in_array('supervisor', $userRoles);
    if (!$isPrivileged) {
        unset($order['client_email']);
        unset($order['client_phone']);
        unset($order['client_company']);
        unset($order['price_amount']);
        unset($order['currency']);
    }
    return $order;
}
```

- **Photo Editors** see only: Order ID, Property Reference, Photo Count, Retouching Notes, and Internal Storage Paths.
- **Team Leads** see only: Editor Performance, QA Status, and Delivery Quality.
- **Client Contact Details** remain exclusive to Owner, Production Manager, and Supervisor.

---

## 8. Notification & Email Dispatch Architecture

The delivery engine (`includes/mail.php`) dynamically branches delivery templates based on order classification:

```
                    ┌────────────────────────┐
                    │ Supervisor Dispatches  │
                    │    Order Delivery      │
                    └───────────┬────────────┘
                                │
               ┌────────────────┴────────────────┐
               │                                 │
     [Is Free Trial?]                   [Is Live Order?]
               │                                 │
               ▼                                 ▼
┌─────────────────────────────┐   ┌─────────────────────────────┐
│ 🎁 COMPLIMENTARY TRIAL EMAIL│   │ ⚡ PAID ORDER INVOICE EMAIL │
│ • High-Res Download Link    │   │ • High-Res Download Link    │
│ • "100% On Us" Banner       │   │ • Itemized Invoice Breakdown│
│ • Free Revisions Guarantee  │   │ • Official PayPal Address   │
│ • ZERO Payment Demands      │   │ • Clickable PayPal.me Button│
│ • NO PayPal Links / Email   │   │ • Ref: INV-ORD-XXXX         │
└─────────────────────────────┘   └─────────────────────────────┘
```

---

## 9. Client Style Preference Engine

Every client profile stores personalized architectural retouching preferences (`data/users.json`):

- **Color Science Preset:** Natural / True-to-Life, Vivid Pop, Bright & Airy, Luxury Moody.
- **Sky Replacement Profile:** Azure Blue, Dramatic Sunset, Soft Whispering Clouds.
- **Window Treatment Method:** Deep Window Pull (100% exterior view), Natural Soft Pull (50% blend), Flambient Fusion.
- **Auto-Injection:** When a client places an order, their saved style guidelines are automatically merged into the job ticket instructions, ensuring editors adhere to their custom aesthetic from minute one.

---

## 10. Security & Hardening Architecture

- **Content Security Policy (CSP):** Dynamic per-request cryptographic nonces (`\EstateHDR\Security\SecurityHeaders::nonce()`) for all scripts, preventing XSS and disallowing unsanctioned inline event handlers.
- **CSRF Token Guard:** Every state-modifying POST request validates a cryptographic token using `hash_equals()`.
- **Anti-Brute-Force Engine:** Tracks IP login attempts in `data/login_attempts.json`. Locks offending IPs for 15 minutes upon 5 consecutive failures with artificial random timing pauses (200-400ms) to defeat side-channel attacks.
- **Session Hijack Defense:** Verifies client User-Agent fingerprints against session state on every privileged request.
