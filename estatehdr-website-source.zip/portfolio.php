<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';

function getYoutubeEmbedUrl(string $url): string {
    $url = trim($url);
    if (preg_match('/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/', $url, $matches)) {
        return 'https://www.youtube-nocookie.com/embed/' . $matches[1] . '?rel=0&modestbranding=1';
    }
    return $url;
}

function getYoutubeVideoId(string $url): string {
    if (preg_match('/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/', $url, $matches)) {
        return $matches[1];
    }
    return '';
}

// Master Video Tours Array (Add any YouTube link here!)
$videoItems = [
    [
        'title' => 'Full 4K Property Walkthrough',
        'price' => '$50.00',
        'desc'  => 'Room-by-room stabilized flow with branded agent lower-thirds and licensed audio.',
        'url'   => 'https://www.youtube.com/watch?v=Ixj2hcyKeRo'
    ],
    [
        'title' => 'Cinematic Drone / Aerial Tour',
        'price' => '$70.00',
        'desc'  => 'Boundary lines callouts, speed ramps, and neighborhood amenities showcase.',
        'url'   => 'https://www.youtube.com/watch?v=nD_pu79-zKs'
    ],
    [
        'title' => 'Vertical Reels / TikTok Teaser',
        'price' => '$30.00',
        'desc'  => '9:16 high-energy viral cut for Instagram Reels, TikTok, and YouTube Shorts.',
        'url'   => 'https://www.youtube.com/watch?v=Lxl3pC_3RlE'
    ]
];


$activeService = trim($_GET['service'] ?? 'all');

// Master Portfolio Registry with ALL available photo pairs
$portfolioItems = [
    // ── HDR Photography (15 items) ──
    ['cat' => 'hdr', 'service' => 'HDR Photography', 'title' => 'Luxury Penthouse Master Bedroom', 'price' => 'From $0.50', 'before' => '/assets/images/portfolio/hdr/1-before.webp', 'after' => '/assets/images/portfolio/hdr/1-after.webp', 'b_label' => 'Raw Bracket', 'a_label' => 'Flambient HDR Retouched'],
    ['cat' => 'hdr', 'service' => 'HDR Photography', 'title' => 'Open Concept Modern Kitchen & Dining', 'price' => 'From $0.50', 'before' => '/assets/images/portfolio/hdr/2-before.webp', 'after' => '/assets/images/portfolio/hdr/2-after.webp', 'b_label' => 'Overexposed Ambient', 'a_label' => 'Balanced Window Pull'],
    ['cat' => 'hdr', 'service' => 'HDR Photography', 'title' => 'Spacious Family Living Area', 'price' => 'From $0.50', 'before' => '/assets/images/portfolio/hdr/3-before.webp', 'after' => '/assets/images/portfolio/hdr/3-after.webp', 'b_label' => 'Underexposed Shadows', 'a_label' => 'Color Balanced HDR'],
    ['cat' => 'hdr', 'service' => 'HDR Photography', 'title' => 'Architectural Sunroom & Patio', 'price' => 'From $0.50', 'before' => '/assets/images/portfolio/hdr/4-before.webp', 'after' => '/assets/images/portfolio/hdr/4-after.webp', 'b_label' => 'Severe Window Glare', 'a_label' => 'Crystal Window View'],
    ['cat' => 'hdr', 'service' => 'HDR Photography', 'title' => 'Executive Home Office & Library', 'price' => 'From $0.50', 'before' => '/assets/images/portfolio/hdr/5-before.webp', 'after' => '/assets/images/portfolio/hdr/5-after.webp', 'b_label' => 'Harsh Flash Shadows', 'a_label' => 'Natural Ambient Blend'],
    ['cat' => 'hdr', 'service' => 'HDR Photography', 'title' => 'Primary Bathroom Suite & Vanity', 'price' => 'From $0.50', 'before' => '/assets/images/portfolio/hdr/6-before.webp', 'after' => '/assets/images/portfolio/hdr/6-after.webp', 'b_label' => 'Yellow Tungsten Cast', 'a_label' => 'Pure Neutral Whites'],
    ['cat' => 'hdr', 'service' => 'HDR Photography', 'title' => 'Grand Foyer & Winding Staircase', 'price' => 'From $0.50', 'before' => '/assets/images/portfolio/hdr/7-before.webp', 'after' => '/assets/images/portfolio/hdr/7-after.webp', 'b_label' => 'Mixed Color Temp', 'a_label' => 'True-to-Life Colors'],
    ['cat' => 'hdr', 'service' => 'HDR Photography', 'title' => 'Contemporary Loft Great Room', 'price' => 'From $0.50', 'before' => '/assets/images/portfolio/hdr/8-before.webp', 'after' => '/assets/images/portfolio/hdr/8-after.webp', 'b_label' => 'Blown Highlights', 'a_label' => 'Full Dynamic Range'],
    ['cat' => 'hdr', 'service' => 'HDR Photography', 'title' => 'Chef Kitchen Island & Cabinetry', 'price' => 'From $0.50', 'before' => '/assets/images/portfolio/hdr/9-before.webp', 'after' => '/assets/images/portfolio/hdr/9-after.webp', 'b_label' => 'Lens Distortion', 'a_label' => 'Perspective Corrected'],
    ['cat' => 'hdr', 'service' => 'HDR Photography', 'title' => 'Cozy Fireplace Sitting Nook', 'price' => 'From $0.50', 'before' => '/assets/images/portfolio/hdr/10-before.webp', 'after' => '/assets/images/portfolio/hdr/10-after.webp', 'b_label' => 'Dark Corner Shadows', 'a_label' => 'Warm Even Lighting'],
    ['cat' => 'hdr', 'service' => 'HDR Photography', 'title' => 'Bright Bedroom with Yard View', 'price' => 'From $0.50', 'before' => '/assets/images/portfolio/hdr/11-before.webp', 'after' => '/assets/images/portfolio/hdr/11-after.webp', 'b_label' => 'Hazy Exterior View', 'a_label' => 'Crisp Garden Details'],
    ['cat' => 'hdr', 'service' => 'HDR Photography', 'title' => 'Modern Minimalist Dining Table', 'price' => 'From $0.50', 'before' => '/assets/images/portfolio/hdr/12-before.webp', 'after' => '/assets/images/portfolio/hdr/12-after.webp', 'b_label' => 'Flat Low Contrast', 'a_label' => 'Punchy Rich Contrast'],

    // ── Virtual Staging (7 items) ──
    ['cat' => 'staging', 'service' => 'Virtual Staging', 'title' => 'Empty Primary Suite &rarr; Modern Luxury Staging', 'price' => '$10.00', 'before' => '/assets/images/portfolio/virtual-staging/1-before.webp', 'after' => '/assets/images/portfolio/virtual-staging/1-after.webp', 'b_label' => 'Vacant Unfurnished', 'a_label' => '3D Staged Master Bedroom'],
    ['cat' => 'staging', 'service' => 'Virtual Staging', 'title' => 'Vacant Living Room &rarr; Scandinavian Design', 'price' => '$10.00', 'before' => '/assets/images/portfolio/virtual-staging/2-before.webp', 'after' => '/assets/images/portfolio/virtual-staging/2-after.webp', 'b_label' => 'Empty Floor Space', 'a_label' => 'Modern Sofa & Decor'],
    ['cat' => 'staging', 'service' => 'Virtual Staging', 'title' => 'Open Concept Dining Area Virtual Staging', 'price' => '$10.00', 'before' => '/assets/images/portfolio/virtual-staging/3-before.webp', 'after' => '/assets/images/portfolio/virtual-staging/3-after.webp', 'b_label' => 'Unfurnished Hall', 'a_label' => 'Full Dining Set & Rug'],
    ['cat' => 'staging', 'service' => 'Virtual Staging', 'title' => 'Cozy Family Room Furniture Placement', 'price' => '$10.00', 'before' => '/assets/images/portfolio/virtual-staging/4-before.webp', 'after' => '/assets/images/portfolio/virtual-staging/4-after.webp', 'b_label' => 'Bare Walls & Floor', 'a_label' => 'Complete Living Room Set'],
    ['cat' => 'staging', 'service' => 'Virtual Staging', 'title' => 'Modern Luxury Home Office Staging', 'price' => '$10.00', 'before' => '/assets/images/portfolio/virtual-staging/5-before.webp', 'after' => '/assets/images/portfolio/virtual-staging/5-after.webp', 'b_label' => 'Vacant Office', 'a_label' => 'Executive Desk & Art'],
    ['cat' => 'staging', 'service' => 'Virtual Staging', 'title' => 'Guest Bedroom Cozy Staging Setup', 'price' => '$10.00', 'before' => '/assets/images/portfolio/virtual-staging/6-before.webp', 'after' => '/assets/images/portfolio/virtual-staging/6-after.webp', 'b_label' => 'Empty Guest Room', 'a_label' => 'Queen Bed & Nightstands'],
    ['cat' => 'staging', 'service' => 'Virtual Staging', 'title' => 'Outdoor Patio & Deck Staging', 'price' => '$10.00', 'before' => '/assets/images/portfolio/virtual-staging/7-before.webp', 'after' => '/assets/images/portfolio/virtual-staging/7-after.webp', 'b_label' => 'Empty Backyard Deck', 'a_label' => 'Outdoor Furniture & Firepit'],

    // ── Day to Dusk Twilight (6 items) ──
    ['cat' => 'dusk', 'service' => 'Day to Dusk', 'title' => 'Modern Estate Daylight &rarr; Golden Hour Twilight', 'price' => '$10.00', 'before' => '/assets/images/portfolio/day-to-dusk/1-before.webp', 'after' => '/assets/images/portfolio/day-to-dusk/1-after.webp', 'b_label' => 'Noon Daylight', 'a_label' => 'Dramatic Sunset Twilight'],
    ['cat' => 'dusk', 'service' => 'Day to Dusk', 'title' => 'Suburban Home Exterior Sunset Conversion', 'price' => '$10.00', 'before' => '/assets/images/portfolio/day-to-dusk/2-before.webp', 'after' => '/assets/images/portfolio/day-to-dusk/2-after.webp', 'b_label' => 'Overcast Gray Sky', 'a_label' => 'Warm Interior Glow & Dusk'],
    ['cat' => 'dusk', 'service' => 'Day to Dusk', 'title' => 'Luxury Villa Poolside Twilight Ambiance', 'price' => '$10.00', 'before' => '/assets/images/portfolio/day-to-dusk/3-before.webp', 'after' => '/assets/images/portfolio/day-to-dusk/3-after.webp', 'b_label' => 'Bright Sunny Day', 'a_label' => 'Illuminated Pool Twilight'],
    ['cat' => 'dusk', 'service' => 'Day to Dusk', 'title' => 'Front Yard Landscape Night Lighting', 'price' => '$10.00', 'before' => '/assets/images/portfolio/day-to-dusk/4-before.webp', 'after' => '/assets/images/portfolio/day-to-dusk/4-after.webp', 'b_label' => 'Flat Daylight', 'a_label' => 'Warm Pathway & Coach Lights'],
    ['cat' => 'dusk', 'service' => 'Day to Dusk', 'title' => 'Waterfront Property Evening Sunset Transformation', 'price' => '$10.00', 'before' => '/assets/images/portfolio/day-to-dusk/5-before.webp', 'after' => '/assets/images/portfolio/day-to-dusk/5-after.webp', 'b_label' => 'Hazy Day Sky', 'a_label' => 'Vibrant Orange Sunset'],
    ['cat' => 'dusk', 'service' => 'Day to Dusk', 'title' => 'Modern Ranch House Twilight Conversion', 'price' => '$10.00', 'before' => '/assets/images/portfolio/day-to-dusk/6-before.webp', 'after' => '/assets/images/portfolio/day-to-dusk/6-after.webp', 'b_label' => 'Midday Sun', 'a_label' => 'Glowing Windows Twilight'],

    // ── Item Removal & Decluttering (6 items) ──
    ['cat' => 'declutter', 'service' => 'Item Removal', 'title' => 'Driveway Vehicle & Clutter Eradication', 'price' => '$8.00', 'before' => '/assets/images/portfolio/item-removal/1-before.webp', 'after' => '/assets/images/portfolio/item-removal/1-after.webp', 'b_label' => 'Parked Cars & Bins', 'a_label' => 'Clean Clean Driveway'],
    ['cat' => 'declutter', 'service' => 'Item Removal', 'title' => 'Kitchen Countertops Deep Decluttering', 'price' => '$8.00', 'before' => '/assets/images/portfolio/item-removal/2-before.webp', 'after' => '/assets/images/portfolio/item-removal/2-after.webp', 'b_label' => 'Small Appliances & Dishes', 'a_label' => 'Pristine Countertops'],
    ['cat' => 'declutter', 'service' => 'Item Removal', 'title' => 'Living Room Personal Items & Cords Removal', 'price' => '$8.00', 'before' => '/assets/images/portfolio/item-removal/3-before.webp', 'after' => '/assets/images/portfolio/item-removal/3-after.webp', 'b_label' => 'Cluttered Tables & Wires', 'a_label' => 'Showcase-Ready Living Room'],
    ['cat' => 'declutter', 'service' => 'Item Removal', 'title' => 'Backyard Garden Hose & Tools Removal', 'price' => '$8.00', 'before' => '/assets/images/portfolio/item-removal/4-before.webp', 'after' => '/assets/images/portfolio/item-removal/4-after.webp', 'b_label' => 'Yard Clutter & Toys', 'a_label' => 'Manicured Lawn & Garden'],
    ['cat' => 'declutter', 'service' => 'Item Removal', 'title' => 'Bathroom Toiletries & Towels Cleanup', 'price' => '$8.00', 'before' => '/assets/images/portfolio/item-removal/5-before.webp', 'after' => '/assets/images/portfolio/item-removal/5-after.webp', 'b_label' => 'Messy Vanity Counter', 'a_label' => 'Spa-Like Luxury Vanity'],
    ['cat' => 'declutter', 'service' => 'Item Removal', 'title' => 'Garage Storage Boxes & Junk Removal', 'price' => '$8.00', 'before' => '/assets/images/portfolio/item-removal/6-before.webp', 'after' => '/assets/images/portfolio/item-removal/6-after.webp', 'b_label' => 'Cluttered Packed Garage', 'a_label' => 'Clean Polished Garage'],

    // ── Virtual Renovation (6 items) ──
    ['cat' => 'renovation', 'service' => 'Virtual Renovation', 'title' => 'Dated Kitchen &rarr; Modern Quartz & Shaker Cabinets', 'price' => '$25.00', 'before' => '/assets/images/portfolio/renovation/1-before.webp', 'after' => '/assets/images/portfolio/renovation/1-after.webp', 'b_label' => 'Old Oak Cabinets', 'a_label' => 'Modern White Shaker'],
    ['cat' => 'renovation', 'service' => 'Virtual Renovation', 'title' => 'Carpet Replacement &rarr; Luxury Hardwood Flooring', 'price' => '$25.00', 'before' => '/assets/images/portfolio/renovation/2-before.webp', 'after' => '/assets/images/portfolio/renovation/2-after.webp', 'b_label' => 'Stained Beige Carpet', 'a_label' => 'Polished Oak Hardwood'],
    ['cat' => 'renovation', 'service' => 'Virtual Renovation', 'title' => 'Exterior Siding & Modern Paint Renovation', 'price' => '$25.00', 'before' => '/assets/images/portfolio/renovation/3-before.webp', 'after' => '/assets/images/portfolio/renovation/3-after.webp', 'b_label' => 'Weathered Brown Siding', 'a_label' => 'Modern Charcoal & White'],
    ['cat' => 'renovation', 'service' => 'Virtual Renovation', 'title' => 'Bathroom Tile & Modern Glass Shower Remodel', 'price' => '$25.00', 'before' => '/assets/images/portfolio/renovation/4-before.webp', 'after' => '/assets/images/portfolio/renovation/4-after.webp', 'b_label' => 'Dated 90s Tile', 'a_label' => 'Frameless Glass & Marble'],

    // ── Virtual Twilight (6 items) ──
    ['cat' => 'twilight', 'service' => 'Virtual Twilight', 'title' => 'Sunset Illumination & Interior Lighting Glow', 'price' => '$10.00', 'before' => '/assets/images/portfolio/twilight/1-before.webp', 'after' => '/assets/images/portfolio/twilight/1-after.webp', 'b_label' => 'Flat Daylight Shot', 'a_label' => 'Rich Blue Hour Twilight'],
    ['cat' => 'twilight', 'service' => 'Virtual Twilight', 'title' => 'Backyard Pool Light & Sunset Sky Replacement', 'price' => '$10.00', 'before' => '/assets/images/portfolio/twilight/2-before.webp', 'after' => '/assets/images/portfolio/twilight/2-after.webp', 'b_label' => 'Cloudy Afternoon', 'a_label' => 'Glowing Sunset Reflections'],
];

// Filter items by selected service
$filteredItems = array_filter($portfolioItems, function($item) use ($activeService) {
    if ($activeService === 'all') return true;
    return $item['cat'] === $activeService;
});
$filteredItems = array_values($filteredItems);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Interactive Portfolio &amp; Before/After Gallery — Estate HDR</title>
<meta name="description" content="Explore our interactive before/after real estate photo retouching, virtual staging, day to dusk conversions, item removal, and 4K video editing portfolio.">
<link rel="canonical" href="https://estatehdr.com/portfolio">
<!-- Fonts -->
<?= renderSeoHeadTags() ?>
<link rel="preconnect" href="https://fonts.googleapis.com">
<?= renderSeoHeadTags() ?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap" onload="this.onload=null;this.rel='stylesheet'">
<noscript>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap">
</noscript>
<link rel="stylesheet" href="/assets/css/bundle.css?v=<?= file_exists(ROOT_PATH . '/assets/css/bundle.css') ? filemtime(ROOT_PATH . '/assets/css/bundle.css') : time() ?>">
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/includes/public-header.php'; ?>

<!-- HERO HEADER -->
<header class="pt-36 pb-12 px-6 border-b border-dark-border/40 bg-gradient-to-b from-dark-card/60 to-dark text-center">
  <div class="max-w-4xl mx-auto">
    <div class="section-tag mb-3">Interactive Master Gallery</div>
    <h1 class="text-3xl sm:text-5xl font-black text-white leading-tight">Before &amp; After Transformations</h1>
    <p class="text-gray-300 text-base sm:text-lg mt-4 max-w-2xl mx-auto font-medium leading-relaxed">
      Drag the sliders on any photo below to inspect our window pulls, color fidelity, realistic virtual staging, and architectural precision.
    </p>

    <!-- Filter Buttons -->
    <div class="flex flex-wrap items-center justify-center gap-2.5 mt-8 text-xs font-bold">
      <a href="?service=all" class="px-4 py-2.5 rounded-xl transition-all <?= $activeService === 'all' ? 'bg-gold text-dark font-black shadow-glow scale-105' : 'bg-dark border border-dark-border text-gray-300 hover:text-white hover:border-gold/50' ?>">All Works (<?= count($portfolioItems) ?>)</a>
      <a href="?service=hdr" class="px-4 py-2.5 rounded-xl transition-all <?= $activeService === 'hdr' ? 'bg-gold text-dark font-black shadow-glow scale-105' : 'bg-dark border border-dark-border text-gray-300 hover:text-white hover:border-gold/50' ?>">HDR Flambient (12)</a>
      <a href="?service=staging" class="px-4 py-2.5 rounded-xl transition-all <?= $activeService === 'staging' ? 'bg-gold text-dark font-black shadow-glow scale-105' : 'bg-dark border border-dark-border text-gray-300 hover:text-white hover:border-gold/50' ?>">Virtual Staging (7)</a>
      <a href="?service=dusk" class="px-4 py-2.5 rounded-xl transition-all <?= $activeService === 'dusk' ? 'bg-gold text-dark font-black shadow-glow scale-105' : 'bg-dark border border-dark-border text-gray-300 hover:text-white hover:border-gold/50' ?>">Day to Dusk (6)</a>
      <a href="?service=declutter" class="px-4 py-2.5 rounded-xl transition-all <?= $activeService === 'declutter' ? 'bg-gold text-dark font-black shadow-glow scale-105' : 'bg-dark border border-dark-border text-gray-300 hover:text-white hover:border-gold/50' ?>">Item Removal (6)</a>
      <a href="?service=renovation" class="px-4 py-2.5 rounded-xl transition-all <?= $activeService === 'renovation' ? 'bg-gold text-dark font-black shadow-glow scale-105' : 'bg-dark border border-dark-border text-gray-300 hover:text-white hover:border-gold/50' ?>">Renovation (4)</a>
      <a href="?service=twilight" class="px-4 py-2.5 rounded-xl transition-all <?= $activeService === 'twilight' ? 'bg-gold text-dark font-black shadow-glow scale-105' : 'bg-dark border border-dark-border text-gray-300 hover:text-white hover:border-gold/50' ?>">Twilight (2)</a>
      <a href="?service=video" class="px-4 py-2.5 rounded-xl transition-all <?= $activeService === 'video' ? 'bg-gold text-dark font-black shadow-glow scale-105' : 'bg-dark border border-dark-border text-gray-300 hover:text-white hover:border-gold/50' ?>">4K Video Tours</a>
    </div>
  </div>
</header>

<main class="flex-1 max-w-7xl mx-auto px-6 py-12 w-full space-y-12">
  
  <?php if ($activeService !== 'video'): ?>
  <!-- Dynamic Interactive Before/After Gallery Cards -->
  <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start" id="portfolioGrid">
    <?php foreach ($filteredItems as $idx => $item): 
      $isHidden = ($idx >= 8 && $activeService === 'all');
    ?>
    <div class="portfolio-card <?= $isHidden ? 'portfolio-card-hidden hidden' : '' ?> glass-card rounded-3xl p-6 border border-dark-border shadow-2xl space-y-4 hover:border-gold/30 transition-all bg-[#111118]">
      <div class="flex items-center justify-between">
        <div>
          <span class="text-xs text-gold font-bold uppercase tracking-wider"><?= htmlspecialchars($item['service']) ?></span>
          <h3 class="text-base sm:text-lg font-bold text-white"><?= htmlspecialchars($item['title']) ?></h3>
        </div>
        <span class="badge badge-delivered font-mono text-xs"><?= htmlspecialchars($item['price']) ?></span>
      </div>

      <!-- Interactive Before/After Slider Container -->
      <div class="ba-container relative rounded-2xl overflow-hidden aspect-[16/10] glass-card cursor-ew-resize select-none border border-dark-border hover:border-gold/30 transition-colors shadow-lg" data-ba>
        <!-- Before Layer -->
        <div class="ba-before absolute inset-0 flex items-center justify-center bg-dark">
          <img loading="<?= $idx < 2 ? 'eager' : 'lazy' ?>" decoding="async" width="600" height="375" src="<?= htmlspecialchars($item['before']) ?>" class="w-full h-full object-cover pointer-events-none" alt="<?= htmlspecialchars($item['title']) ?> - Before">
        </div>

        <!-- After Layer -->
        <div class="ba-after absolute inset-0 flex items-center justify-center bg-dark" style="clip-path: inset(0 50% 0 0)">
          <img loading="<?= $idx < 2 ? 'eager' : 'lazy' ?>" decoding="async" width="600" height="375" src="<?= htmlspecialchars($item['after']) ?>" class="w-full h-full object-cover pointer-events-none" alt="<?= htmlspecialchars($item['title']) ?> - After">
        </div>

        <!-- Divider Line & Handle -->
        <div class="ba-divider absolute inset-y-0 flex items-center" style="left:50%">
          <div class="w-0.5 h-full bg-white/90 shadow-lg"></div>
          <div class="absolute w-8 h-8 rounded-full bg-white shadow-2xl flex items-center justify-center -translate-x-1/2 border border-dark/10">
            <svg class="w-3.5 h-3.5 text-dark" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M8 9l-4 3 4 3M16 9l4 3-4 3"/>
            </svg>
          </div>
        </div>

        <!-- Badges -->
        <div class="absolute top-2.5 left-2.5 px-2.5 py-1 bg-black/80 backdrop-blur-md rounded-md text-[11px] font-bold text-gray-200 pointer-events-none uppercase tracking-wider border border-white/10">
          BEFORE
        </div>
        <div class="absolute top-2.5 right-2.5 px-2.5 py-1 bg-gold/95 backdrop-blur-md rounded-md text-[11px] font-black text-dark pointer-events-none uppercase tracking-wider shadow-sm">
          AFTER
        </div>
      </div>
      
      <div class="flex justify-between text-xs text-gray-300 font-mono font-bold px-1">
        <span class="flex items-center gap-1"><span class="text-gold">←</span> <?= htmlspecialchars($item['b_label']) ?></span> 
        <span class="flex items-center gap-1"><?= htmlspecialchars($item['a_label']) ?> <span class="text-gold">→</span></span>
      </div>
    </div>
    <?php endforeach; ?>

    <?php if ($activeService === 'all' && count($filteredItems) > 8): ?>
    <div id="loadMoreWrap" class="col-span-1 lg:col-span-2 text-center py-6">
      <button type="button" onclick="document.querySelectorAll('.portfolio-card-hidden').forEach(el=>el.classList.remove('hidden')); this.parentElement.remove();" class="btn-gold py-3.5 px-8 text-xs font-black shadow-glow inline-flex items-center gap-2">
        <span>📂</span> <span>Load More Transformations (<?= count($filteredItems) - 8 ?> More) &darr;</span>
      </button>
    </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <!-- 4K Video Showcase Section (High-Performance Facades) -->
  <?php if ($activeService === 'all' || $activeService === 'video'): ?>
  <div class="pt-8 border-t border-dark-border">
    <div class="text-center max-w-2xl mx-auto mb-10">
      <div class="section-tag mb-2">Cinematic Media</div>
      <h2 class="text-3xl font-black text-white">4K Real Estate Video Editing Showcase</h2>
      <p class="text-gray-300 text-sm mt-2">Smooth gimbal stabilization, speed-ramping, HDR sky enhancement, and licensed soundtrack sync.</p>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <?php foreach ($videoItems as $vid): 
        $ytId = getYoutubeVideoId($vid['url']);
        $embedSrc = !empty($ytId) ? ('https://www.youtube-nocookie.com/embed/' . $ytId . '?autoplay=1&rel=0') : getYoutubeEmbedUrl($vid['url']);
      ?>
      <div class="glass-card rounded-3xl p-5 border border-dark-border shadow-2xl space-y-3 bg-[#111118]">
        <div class="aspect-video w-full rounded-2xl overflow-hidden bg-dark border border-dark-border relative group cursor-pointer" onclick="this.innerHTML='<iframe class=\'w-full h-full\' src=\'<?= $embedSrc ?>\' title=\'<?= htmlspecialchars($vid['title'], ENT_QUOTES) ?>\' frameborder=\'0\' allow=\'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\' allowfullscreen></iframe>'">
          <?php if (!empty($ytId)): ?>
            <img src="https://i.ytimg.com/vi/<?= $ytId ?>/hqdefault.jpg" alt="<?= htmlspecialchars($vid['title']) ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform" loading="lazy" width="480" height="360">
            <div class="absolute inset-0 bg-black/40 group-hover:bg-black/20 flex items-center justify-center transition-colors">
              <div class="w-14 h-14 rounded-full bg-gold text-dark flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform">
                <svg class="w-6 h-6 fill-current translate-x-0.5" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
              </div>
            </div>
            <div class="absolute bottom-2.5 right-2.5 px-2.5 py-0.5 bg-black/80 rounded-md text-[10px] font-mono text-gold font-bold">▶ Click to Play 4K</div>
          <?php else: ?>
            <iframe loading="lazy" class="w-full h-full" src="<?= htmlspecialchars(getYoutubeEmbedUrl($vid['url'])) ?>" title="<?= htmlspecialchars($vid['title']) ?>" frameborder="0" allowfullscreen></iframe>
          <?php endif; ?>
        </div>
        <div class="flex items-center justify-between pt-1">
          <h4 class="font-bold text-white text-sm"><?= htmlspecialchars($vid['title']) ?></h4>
          <span class="text-xs font-mono text-gold font-bold"><?= htmlspecialchars($vid['price']) ?></span>
        </div>
        <p class="text-xs text-gray-300"><?= htmlspecialchars($vid['desc']) ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- Order CTA Banner -->
  <div class="glass-card rounded-3xl p-8 sm:p-12 border border-gold/30 shadow-2xl text-center bg-gradient-to-br from-gold/10 via-dark-card to-dark">
    <h2 class="text-2xl sm:text-3xl font-black text-white mb-2">Ready to Upgrade Your Real Estate Media?</h2>
    <p class="text-gray-300 text-sm max-w-xl mx-auto mb-6">
      Send your raw bracketed exposures today and receive finished, MLS-ready photos in 24 hours.
    </p>
    <div class="flex flex-col sm:flex-row items-center justify-center gap-4">
      <a href="/register.php" class="btn-gold py-3 px-8 text-sm font-bold shadow-glow">Start Free Trial &rarr;</a>
      <a href="https://wa.me/447706068176" target="_blank" class="btn-ghost py-3 px-6 text-sm text-emerald-400 hover:text-emerald-300 border-emerald-500/30" rel="noopener noreferrer">💬 WhatsApp Inquiries</a>
    </div>
  </div>

</main>

<!-- FOOTER -->
<footer class="border-t border-dark-border py-12 px-6 bg-dark">
  <div class="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-gray-400">
    <p>&copy; <?= date('Y') ?> Estate HDR. All rights reserved. Professional Real Estate Media Retouching.</p>
    <div class="flex items-center gap-5 text-gray-400">
      <a href="<?= FACEBOOK_LINK ?>" target="_blank" class="hover:text-blue-400 transition-colors" rel="noopener noreferrer">Facebook</a>
      <a href="<?= INSTAGRAM_LINK ?>" target="_blank" class="hover:text-pink-400 transition-colors" rel="noopener noreferrer">Instagram</a>
      <a href="<?= LINKEDIN_LINK ?>" target="_blank" class="hover:text-blue-300 transition-colors" rel="noopener noreferrer">LinkedIn</a>
      <a href="<?= WHATSAPP_LINK ?>" target="_blank" class="hover:text-emerald-400 transition-colors" rel="noopener noreferrer">WhatsApp</a>
      <a href="/terms.php" class="hover:text-gold transition-colors">Terms</a>
      <a href="/privacy.php" class="hover:text-gold transition-colors">Privacy</a>
      <a href="/sitemap.xml" class="hover:text-gold transition-colors">Sitemap.xml</a>
      <a href="/contact.php" class="hover:text-gold transition-colors">Contact</a>
    </div>
  </div>
</footer>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
// Precision Universal Before/After Slider Engine (120Hz Accelerated)
function initSliders(scope) {
  if (window.initEstateHDRSliders) {
    window.initEstateHDRSliders(scope);
    return;
  }
  const root = scope || document;
  root.querySelectorAll('[data-ba]').forEach(container => {
    if (container.hasAttribute('data-slider-ready')) return;
    container.setAttribute('data-slider-ready', 'true');

    const after   = container.querySelector('.ba-after');
    const divider = container.querySelector('.ba-divider');
    if (!after || !divider) return;

    let dragging = false;
    let cachedRect = null;
    const move = (x) => {
      if (!cachedRect) cachedRect = container.getBoundingClientRect();
      if (cachedRect.width === 0) return;
      const pct  = Math.min(Math.max(((x - cachedRect.left) / cachedRect.width) * 100, 0), 100);
      requestAnimationFrame(() => {
        divider.style.left = pct + '%';
        after.style.clipPath = `inset(0 ${100 - pct}% 0 0)`;
      });
    };
    divider.addEventListener('pointerdown', (e) => {
      dragging = true;
      cachedRect = container.getBoundingClientRect();
      divider.setPointerCapture?.(e.pointerId);
    }, {passive: true});
    window.addEventListener('pointermove', e => { if (dragging) move(e.clientX); }, {passive:true});
    window.addEventListener('pointerup', (e) => {
      dragging = false;
      cachedRect = null;
      divider.releasePointerCapture?.(e.pointerId);
    }, {passive: true});
    container.addEventListener('click', e => move(e.clientX));

    divider.style.left = '50%';
    after.style.clipPath = 'inset(0 50% 0 0)';
  });
}

document.addEventListener('DOMContentLoaded', () => initSliders());
window.addEventListener('load', () => initSliders());
initSliders();
</script>
<?php require_once __DIR__ . '/includes/chat-widgets.php'; ?>
</body>
</html>
