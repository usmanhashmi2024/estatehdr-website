"""
Estate HDR - Social Media Content & Copywriting Engine
Generates viral, high-converting, pain-point driven social media posts
specifically engineered for Real Estate Photography, HDR Window Pulls,
Virtual Staging, Day-to-Dusk, and Outsourcing.
"""

import json
import random
import sys
from typing import Dict, List, Optional
from datetime import datetime

# Ensure utf-8 encoding for Windows terminal
try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

PILLARS = [
    "hdr_window_pull",
    "virtual_staging",
    "day_to_dusk",
    "object_removal",
    "photographer_outsourcing_turnaround"
]

TOPIC_DATA = {
    "hdr_window_pull": {
        "title": "HDR Exposure Fusion & Crystal-Clear Window Pulls",
        "pain_points": [
            "Blown-out white windows that completely erase gorgeous backyard, ocean, or mountain views.",
            "Muddy indoor shadows and radioactive orange/yellow color casts on ceilings from tungsten lights.",
            "Harsh flash reflections and fake-looking HDR halos that scream 'cheap amateur edit'."
        ],
        "hooks": [
            "Real estate photographers: Are your interior photos suffering from 'nuclear white windows'?",
            "Buyers don't pay for white squares on the wall — they pay for the VIEW. But is your camera blowing it out?",
            "Why do 80% of listing photos look like cartoon HDR? Here's the truth about window pulls."
        ],
        "solutions": [
            "Estate HDR's manual bracket blending delivers true-to-life interior illumination while locking in 100% crisp window views.",
            "We balance ambient warmth and flash seamlessly — preserving natural architectural textures without weird neon tinting.",
            "Zero halos, crisp vertical lines, and 24-hour delivery straight to your inbox."
        ],
        "cta": "Test our window pull quality with 3 free trial edits on estatehdr.com (No credit card needed).",
        "hashtags": [
            "#realestatephotography", "#realestatephotographer", "#realestatephotoediting",
            "#windowpull", "#flambient", "#hdrphotography", "#realestatemarketing",
            "#luxuryrealestate", "#listingagent", "#estatehdr", "#interiorphotography",
            "#propertyphotography", "#realtorlife", "#realestateagent", "#photoretouching"
        ]
    },
    "virtual_staging": {
        "title": "High-Impact 3D Virtual Staging",
        "pain_points": [
            "Vacant homes feel cold, small, and uninviting — sitting on MLS 40% longer than staged homes.",
            "Physical staging costs $2,500 to $5,000+ per month, which sellers simply don't want to pay.",
            "Cheap 2D virtual staging looks like floating clipart and kills credibility with serious buyers."
        ],
        "hooks": [
            "An empty room feels 30% smaller to home buyers scrolling Zillow at midnight. Here is the fix.",
            "Sellers don't want to spend $3,000 on physical furniture staging. What's your alternative?",
            "Vacant listing sitting stale on the market? Virtual staging transforms cold drywall into a dream home."
        ],
        "solutions": [
            "Estate HDR provides photorealistic 3D virtual staging matched to true architectural perspective, natural shadow casting, and modern buyer demographics.",
            "Transform empty living rooms, master bedrooms, and patios for under $25 per image instead of thousands in physical staging.",
            "Delivered in high-resolution, MLS-compliant formats ready for instant upload."
        ],
        "cta": "Turn your vacant listing into an offer magnet. Claim 3 free sample edits at estatehdr.com.",
        "hashtags": [
            "#virtualstaging", "#realestatemarketing", "#realestateagent", "#realtor",
            "#vacanthome", "#realestatephotographer", "#staginghomes", "#interiordesign",
            "#realestatephotography", "#propertylisting", "#homeforsale", "#estatehdr",
            "#realtorsofinstagram", "#luxurylisting", "#realestatelife"
        ]
    },
    "day_to_dusk": {
        "title": "Day-to-Dusk (Twilight) Conversions",
        "pain_points": [
            "Overcast skies, gray clouds, and dull afternoon lighting ruin the luxury curb appeal of hero shots.",
            "Scheduling physical on-site twilight shoots costs photographers extra appointments and realtors extra fees ($150-$300).",
            "Missing the sunset golden hour because the shoot ran late or weather turned bad."
        ],
        "hooks": [
            "Grey, overcast skies on your shoot day? Don't cancel or reschedule the client.",
            "Twilight hero shots get 3x more clicks on Zillow. But who has time to sit on-site until 8:30 PM?",
            "How to turn a dull 2:00 PM overcast exterior into a warm, glowing million-dollar twilight."
        ],
        "solutions": [
            "Estate HDR turns standard daylight exterior shots into breathtaking twilight photos with warm glowing interior windows and custom sunset skies.",
            "We illuminate landscape lights, porch lanterns, and pool reflections with hyper-realistic lighting physics.",
            "Save hundreds of dollars and hours of waiting on-site with our 24-hour turn Day-to-Dusk service."
        ],
        "cta": "Upgrade your next exterior hero shot. Experience the magic with free test edits at estatehdr.com.",
        "hashtags": [
            "#daytodusk", "#twilightphotography", "#realestatephotography", "#curbappeal",
            "#realestatephotographer", "#photoediting", "#realestatemarketing", "#luxuryhomes",
            "#realtors", "#estatehdr", "#architecturalphotography", "#exteriorphotography",
            "#realestatesales", "#listingagent", "#propertyphotos"
        ]
    },
    "object_removal": {
        "title": "Item, Clutter & Debris Removal",
        "pain_points": [
            "Messy tenants leaving laundry, dirty dishes, cars in the driveway, and pet items on shoot day.",
            "Ugly power lines, construction dumpsters, and garden hoses ruining clean exterior lines.",
            "Photographers spending 45+ minutes manually clone-stamping in Photoshop when they should be out shooting."
        ],
        "hooks": [
            "Shoot day nightmare: The tenants didn't clean up, and the driveway has 3 cars parked on it.",
            "Photographers: Stop wasting 1 hour clone-stamping garden hoses, powerlines, and pet toys.",
            "Clutter kills home value perceptions. Here is how clean listing photos protect the asking price."
        ],
        "solutions": [
            "Estate HDR uses advanced texture synthesis and architectural inpainting to remove cars, personal family photos, power lines, and clutter seamlessly.",
            "We reconstruct original flooring, lawns, and wall textures underneath without visible smudges or artifacts.",
            "Keep your clients thrilled and your MLS listings looking pristine."
        ],
        "cta": "Need clean, distraction-free listing photos? Check out our portfolio and free trial at estatehdr.com.",
        "hashtags": [
            "#objectremoval", "#photoediting", "#realestatephotographer", "#cleanphotos",
            "#realestatephotography", "#realtortips", "#propertymarketing", "#estatehdr",
            "#photoretouching", "#listingphotos", "#realestateediting", "#realtorlife"
        ]
    },
    "photographer_outsourcing_turnaround": {
        "title": "24-Hour Turnaround & Photographer Outsourcing",
        "pain_points": [
            "Staying awake until 2:00 AM editing brackets instead of booking more high-paying shoots.",
            "Late delivery by unreliable offshore freelancers causing angry calls from real estate agents.",
            "Inconsistent color grading across multiple shoot days that confuses listing presentations."
        ],
        "hooks": [
            "Photographers: Are you running a photography business, or are you an unpaid full-time photo editor?",
            "What if you could shoot 3 houses today and have all MLS-ready deliverables ready by tomorrow morning?",
            "The #1 reason top real estate photographers hit an income ceiling is spending nights editing brackets."
        ],
        "solutions": [
            "Estate HDR gives you a dedicated post-production team with guaranteed 24-hour turnaround.",
            "Strict Quality Assurance matching your custom style, camera profiles, and color preferences every single time.",
            "Free up 15-20 hours a week to double your client shoots and scale your photography business."
        ],
        "cta": "Stop editing at midnight. Send us your RAW brackets today and get 3 free edits at estatehdr.com.",
        "hashtags": [
            "#realestatephotographer", "#realestatephotography", "#photographybusiness",
            "#photooutsourcing", "#realestateediting", "#estatehdr", "#photographerlife",
            "#scaleyourbusiness", "#realtorpartner", "#commercialphotography", "#propertymedia"
        ]
    }
}

class ContentEngine:
    def __init__(self, config_path: str = "config.json"):
        self.config = {}
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                self.config = json.load(f)
        except Exception:
            pass

    def get_pillar_for_slot(self, slot: str = "morning") -> str:
        day_of_year = datetime.now().timetuple().tm_yday
        if slot == "morning":
            idx = (day_of_year * 2) % len(PILLARS)
        else:
            idx = (day_of_year * 2 + 1) % len(PILLARS)
        return PILLARS[idx]

    def generate_post(self, pillar_key: Optional[str] = None, slot: str = "morning", platform: str = "all") -> Dict:
        if not pillar_key or pillar_key not in TOPIC_DATA:
            pillar_key = self.get_pillar_for_slot(slot)

        data = TOPIC_DATA[pillar_key]
        hook = random.choice(data["hooks"])
        pain_point = random.choice(data["pain_points"])
        solution = random.choice(data["solutions"])
        cta = data["cta"]
        hashtags = data["hashtags"]
        
        # Build platform-specific formatted variants
        linkedin_copy = self._format_linkedin(hook, pain_point, solution, cta, hashtags[:9])
        instagram_copy = self._format_instagram(hook, pain_point, solution, cta, hashtags[:18])
        facebook_copy = self._format_facebook(hook, pain_point, solution, cta, hashtags[:6])
        youtube_copy = self._format_youtube(hook, pain_point, solution, cta, hashtags[:5])

        return {
            "pillar": pillar_key,
            "title": data["title"],
            "slot": slot,
            "linkedin": linkedin_copy,
            "instagram": instagram_copy,
            "facebook": facebook_copy,
            "youtube": youtube_copy,
            "hashtags": hashtags
        }

    def _format_linkedin(self, hook: str, pain: str, sol: str, cta: str, tags: List[str]) -> str:
        return (
            f"{hook}\n\n"
            f"Here is what happens on 80% of listing shoots:\n"
            f"⚠️ The Challenge: {pain}\n\n"
            f"When home buyers browse listings online, photos are the first and only filter. "
            f"Sub-par editing doesn't just hurt the listing — it hurts the photographer's reputation with top agents.\n\n"
            f"✅ How Estate HDR Solves This:\n"
            f"{sol}\n\n"
            f"Consistency, crisp details, and strict 24-hour delivery.\n\n"
            f"👉 Next Step: {cta}\n\n"
            f"{' '.join(tags)}"
        )

    def _format_instagram(self, hook: str, pain: str, sol: str, cta: str, tags: List[str]) -> str:
        return (
            f"🔥 {hook}\n\n"
            f"Let's talk about the biggest headache in real estate media:\n"
            f"❌ {pain}\n\n"
            f"✨ The Estate HDR Difference:\n"
            f"💎 {sol}\n\n"
            f"⚡ Guaranteed 24-hour turnaround\n"
            f"⚡ Strict MLS quality checks\n"
            f"⚡ True-to-life architectural colors\n\n"
            f"👇 {cta}\n"
            f"Link in bio 🔗 or DM us 'EDIT' to start.\n\n"
            f".\n.\n.\n"
            f"{' '.join(tags)}"
        )

    def _format_facebook(self, hook: str, pain: str, sol: str, cta: str, tags: List[str]) -> str:
        return (
            f"{hook}\n\n"
            f"As real estate media pros know, buyers judge a home in under 2 seconds.\n"
            f"Common issue: {pain}\n\n"
            f"At Estate HDR, our editing team handles the hard work:\n"
            f"{sol}\n\n"
            f"Check it out here: https://estatehdr.com\n"
            f"{cta}\n\n"
            f"{' '.join(tags)}"
        )

    def _format_youtube(self, hook: str, pain: str, sol: str, cta: str, tags: List[str]) -> str:
        return (
            f"📸 Real Estate Photography & Editing Tip:\n\n"
            f"{hook}\n\n"
            f"The Problem: {pain}\n"
            f"The Solution: {sol}\n\n"
            f"Check out our full editing pipeline at https://estatehdr.com\n\n"
            f"{' '.join(tags)}"
        )

if __name__ == "__main__":
    engine = ContentEngine()
    post = engine.generate_post(slot="morning")
    print("=== TEST GENERATION FOR LINKEDIN ===")
    print(post["linkedin"])
    print("\n=== TEST GENERATION FOR INSTAGRAM ===")
    print(post["instagram"])
