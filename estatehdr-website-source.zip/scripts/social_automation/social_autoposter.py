"""
Estate HDR - Master Social Media Autoposter
Orchestrates content generation, topic rotation, platform dispatching, and logging.
Can run standalone via CLI or automated via Antigravity Cron Sidecar.
"""

import os
import sys
import json
import argparse
import logging
from datetime import datetime
from content_engine import ContentEngine
from publishers import LinkedInPublisher, FacebookPublisher, InstagramPublisher, AyrsharePublisher

try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("EstateHDRSocial")

CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.json")
HISTORY_PATH = os.path.join(os.path.dirname(__file__), "social_post_history.json")

def load_config() -> dict:
    if not os.path.exists(CONFIG_PATH):
        logger.warning("config.json not found, falling back to template.")
        tmpl = os.path.join(os.path.dirname(__file__), "config.template.json")
        if os.path.exists(tmpl):
            with open(tmpl, "r", encoding="utf-8") as f:
                return json.load(f)
        return {}
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def log_post_event(record: dict):
    history = []
    if os.path.exists(HISTORY_PATH):
        try:
            with open(HISTORY_PATH, "r", encoding="utf-8") as f:
                history = json.load(f)
        except Exception:
            history = []
    history.append(record)
    # Keep last 100 posts
    history = history[-100:]
    with open(HISTORY_PATH, "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2, ensure_ascii=False)

def run_autoposter(slot: str = "morning", topic: str = None, dry_run: bool = None, platform: str = "all"):
    config = load_config()
    general_cfg = config.get("general", {})
    
    if dry_run is None:
        dry_run = general_cfg.get("dry_run", True)

    engine = ContentEngine(CONFIG_PATH)
    post_data = engine.generate_post(pillar_key=topic, slot=slot, platform=platform)

    print("\n" + "="*70)
    print(f"🚀 ESTATE HDR SOCIAL AUTOPOSTER | Slot: {slot.upper()} | Mode: {'DRY RUN' if dry_run else 'LIVE PRODUCTION'}")
    print(f"📌 Pillar: {post_data['title']} ({post_data['pillar']})")
    print("="*70 + "\n")

    results = {}
    
    # 1. Unified Ayrshare check
    unified_cfg = config.get("unified_aggregator", {})
    if unified_cfg.get("use_unified", False):
        ayr = AyrsharePublisher(api_key=unified_cfg.get("api_key", ""), dry_run=dry_run)
        platforms_to_send = ["facebook", "instagram", "linkedin"]
        res = ayr.publish_all(post_data["linkedin"], platforms=platforms_to_send)
        results["unified"] = res
        print(f"📡 Unified Broadcast: {res}")
    else:
        # 2. LinkedIn
        if platform in ["all", "linkedin"]:
            li_cfg = config.get("linkedin", {})
            li_pub = LinkedInPublisher(li_cfg, dry_run=dry_run)
            
            # Company Page
            res_comp = li_pub.publish_company(post_data["linkedin"])
            results["linkedin_company"] = res_comp
            print(f"💼 LinkedIn Company: {res_comp.get('status')} - {res_comp.get('message', res_comp.get('text_preview', ''))}")
            
            # Personal Profile
            res_pers = li_pub.publish_personal(post_data["linkedin"])
            results["linkedin_personal"] = res_pers
            print(f"👤 LinkedIn Personal: {res_pers.get('status')} - {res_pers.get('message', res_pers.get('text_preview', ''))}")

        # 3. Facebook
        if platform in ["all", "facebook"]:
            fb_cfg = config.get("facebook", {})
            fb_pub = FacebookPublisher(fb_cfg, dry_run=dry_run)
            res_fb = fb_pub.publish(post_data["facebook"])
            results["facebook"] = res_fb
            print(f"📘 Facebook Page: {res_fb.get('status')} - {res_fb.get('message', res_fb.get('text_preview', ''))}")

        # 4. Instagram
        if platform in ["all", "instagram"]:
            ig_cfg = config.get("instagram", {})
            ig_pub = InstagramPublisher(ig_cfg, dry_run=dry_run)
            # Default placeholder image URL from Estate HDR logo or hero
            sample_img = "https://estatehdr.com/assets/images/og-image.jpg"
            res_ig = ig_pub.publish(post_data["instagram"], image_url=sample_img)
            results["instagram"] = res_ig
            print(f"📸 Instagram: {res_ig.get('status')} - {res_ig.get('message', res_ig.get('text_preview', ''))}")

    # Record history
    event_record = {
        "timestamp": datetime.now().isoformat(),
        "slot": slot,
        "pillar": post_data["pillar"],
        "dry_run": dry_run,
        "results": results,
        "content_preview": {
            "title": post_data["title"],
            "linkedin_preview": post_data["linkedin"][:200] + "..."
        }
    }
    log_post_event(event_record)

    print("\n" + "-"*70)
    print("✅ Autoposter execution completed successfully.")
    print(f"📝 Post preview & results recorded in {os.path.basename(HISTORY_PATH)}")
    print("-"*70 + "\n")
    return results

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Estate HDR Social Autoposter")
    parser.add_argument("--slot", choices=["morning", "evening"], default="morning", help="Posting slot (morning/evening)")
    parser.add_argument("--topic", default=None, help="Force specific topic pillar (hdr_window_pull, virtual_staging, day_to_dusk, etc.)")
    parser.add_argument("--dry-run", action="store_true", default=None, help="Run simulation without making actual API calls")
    parser.add_argument("--live", action="store_true", help="Force live production posting (overrides dry-run)")
    parser.add_argument("--platform", choices=["all", "linkedin", "facebook", "instagram"], default="all", help="Target platform")
    
    args = parser.parse_args()
    
    dry_run_flag = None
    if args.live:
        dry_run_flag = False
    elif args.dry_run:
        dry_run_flag = True

    run_autoposter(slot=args.slot, topic=args.topic, dry_run=dry_run_flag, platform=args.platform)
