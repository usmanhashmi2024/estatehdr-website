"""
Estate HDR - Social Media Multi-Platform Publishers
Handles API interactions with LinkedIn, Facebook, Instagram, and Unified Aggregators.
Includes robust Dry-Run simulation, logging, and error handling.
"""

import os
import sys
import json
import logging
from typing import Dict, Any, Optional

try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

try:
    import requests
except ImportError:
    requests = None

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("SocialPublisher")

class BasePublisher:
    def __init__(self, dry_run: bool = True):
        self.dry_run = dry_run

class LinkedInPublisher(BasePublisher):
    def __init__(self, config: Dict, dry_run: bool = True):
        super().__init__(dry_run)
        self.company_cfg = config.get("company_page", {})
        self.personal_cfg = config.get("personal_profile", {})

    def publish_company(self, text: str, image_url: Optional[str] = None) -> Dict[str, Any]:
        if not self.company_cfg.get("enabled"):
            return {"status": "skipped", "message": "LinkedIn Company posting is disabled in config."}

        token = self.company_cfg.get("access_token")
        org_id = self.company_cfg.get("organization_id")

        if self.dry_run or not token or not org_id:
            logger.info("[DRY RUN] LinkedIn Company Page post generated:\n%s", text[:120] + "...")
            return {"status": "dry_run", "platform": "linkedin_company", "text_preview": text[:120]}

        headers = {
            "Authorization": f"Bearer {token}",
            "X-Restli-Protocol-Version": "2.0.0",
            "Content-Type": "application/json"
        }
        author = f"urn:li:organization:{org_id}"
        payload = {
            "author": author,
            "lifecycleState": "PUBLISHED",
            "specificContent": {
                "com.linkedin.ugc.ShareContent": {
                    "shareCommentary": {"text": text},
                    "shareMediaCategory": "NONE"
                }
            },
            "visibility": {"com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"}
        }

        try:
            res = requests.post("https://api.linkedin.com/v2/ugcPosts", json=payload, headers=headers, timeout=20)
            if res.status_code in [200, 201]:
                return {"status": "success", "platform": "linkedin_company", "id": res.json().get("id")}
            else:
                return {"status": "error", "code": res.status_code, "response": res.text}
        except Exception as e:
            return {"status": "exception", "error": str(e)}

    def publish_personal(self, text: str, image_url: Optional[str] = None) -> Dict[str, Any]:
        if not self.personal_cfg.get("enabled"):
            return {"status": "skipped", "message": "LinkedIn Personal posting is disabled in config."}

        token = self.personal_cfg.get("access_token")
        person_urn = self.personal_cfg.get("person_urn")

        if self.dry_run or not token or not person_urn:
            logger.info("[DRY RUN] LinkedIn Personal Profile post simulated:\n%s", text[:120] + "...")
            return {"status": "dry_run", "platform": "linkedin_personal", "text_preview": text[:120]}

        headers = {
            "Authorization": f"Bearer {token}",
            "X-Restli-Protocol-Version": "2.0.0",
            "Content-Type": "application/json"
        }
        payload = {
            "author": person_urn,
            "lifecycleState": "PUBLISHED",
            "specificContent": {
                "com.linkedin.ugc.ShareContent": {
                    "shareCommentary": {"text": text},
                    "shareMediaCategory": "NONE"
                }
            },
            "visibility": {"com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"}
        }

        try:
            res = requests.post("https://api.linkedin.com/v2/ugcPosts", json=payload, headers=headers, timeout=20)
            if res.status_code in [200, 201]:
                return {"status": "success", "platform": "linkedin_personal", "id": res.json().get("id")}
            else:
                return {"status": "error", "code": res.status_code, "response": res.text}
        except Exception as e:
            return {"status": "exception", "error": str(e)}

class FacebookPublisher(BasePublisher):
    def __init__(self, config: Dict, dry_run: bool = True):
        super().__init__(dry_run)
        self.config = config

    def publish(self, text: str, image_url: Optional[str] = None) -> Dict[str, Any]:
        if not self.config.get("enabled"):
            return {"status": "skipped", "message": "Facebook posting is disabled in config."}

        page_id = self.config.get("page_id")
        token = self.config.get("page_access_token")

        if self.dry_run or not page_id or not token:
            logger.info("[DRY RUN] Facebook Page post simulated:\n%s", text[:120] + "...")
            return {"status": "dry_run", "platform": "facebook", "text_preview": text[:120]}

        url = f"https://graph.facebook.com/v19.0/{page_id}/feed"
        payload = {"message": text, "access_token": token}
        if image_url:
            url = f"https://graph.facebook.com/v19.0/{page_id}/photos"
            payload = {"caption": text, "url": image_url, "access_token": token}

        try:
            res = requests.post(url, data=payload, timeout=20)
            if res.status_code in [200, 201]:
                return {"status": "success", "platform": "facebook", "id": res.json().get("id")}
            else:
                return {"status": "error", "code": res.status_code, "response": res.text}
        except Exception as e:
            return {"status": "exception", "error": str(e)}

class InstagramPublisher(BasePublisher):
    def __init__(self, config: Dict, dry_run: bool = True):
        super().__init__(dry_run)
        self.config = config

    def publish(self, caption: str, image_url: str) -> Dict[str, Any]:
        if not self.config.get("enabled"):
            return {"status": "skipped", "message": "Instagram posting is disabled in config."}

        ig_user_id = self.config.get("ig_user_id")
        token = self.config.get("access_token")

        if self.dry_run or not ig_user_id or not token or not image_url:
            logger.info("[DRY RUN] Instagram post simulated:\n%s", caption[:120] + "...")
            return {"status": "dry_run", "platform": "instagram", "text_preview": caption[:120]}

        # Step 1: Create media container
        step1_url = f"https://graph.facebook.com/v19.0/{ig_user_id}/media"
        step1_payload = {
            "image_url": image_url,
            "caption": caption,
            "access_token": token
        }

        try:
            res1 = requests.post(step1_url, data=step1_payload, timeout=20)
            if res1.status_code not in [200, 201]:
                return {"status": "error", "step": "container_creation", "response": res1.text}
            
            creation_id = res1.json().get("id")

            # Step 2: Publish container
            step2_url = f"https://graph.facebook.com/v19.0/{ig_user_id}/media_publish"
            step2_payload = {
                "creation_id": creation_id,
                "access_token": token
            }
            res2 = requests.post(step2_url, data=step2_payload, timeout=20)
            if res2.status_code in [200, 201]:
                return {"status": "success", "platform": "instagram", "id": res2.json().get("id")}
            else:
                return {"status": "error", "step": "media_publish", "response": res2.text}
        except Exception as e:
            return {"status": "exception", "error": str(e)}

class AyrsharePublisher(BasePublisher):
    """Unified social posting via Ayrshare API (Post to LinkedIn, FB, IG in 1 call)."""
    def __init__(self, api_key: str, dry_run: bool = True):
        super().__init__(dry_run)
        self.api_key = api_key

    def publish_all(self, post_text: str, platforms: list, media_urls: list = None) -> Dict[str, Any]:
        if self.dry_run or not self.api_key:
            logger.info("[DRY RUN] Unified Ayrshare post simulated for: %s", platforms)
            return {"status": "dry_run", "platforms": platforms, "preview": post_text[:120]}

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        payload = {
            "post": post_text,
            "platforms": platforms
        }
        if media_urls:
            payload["mediaUrls"] = media_urls

        try:
            res = requests.post("https://app.ayrshare.com/api/post", json=payload, headers=headers, timeout=25)
            return res.json()
        except Exception as e:
            return {"status": "exception", "error": str(e)}
