#!/usr/bin/env python3
"""
Estate HDR — Autonomous SEO Article Generator & Autoposter powered by Ollama
- Ingests SEO Intelligence Report strategy (audience ICP, topic clusters, internal links)
- Queries local Ollama for brand-new unique topic ideas (no static duplicates)
- Gathers previous blogs inventory to contextually weave in underlined internal links
- Generates 5-7 trending hashtags
- Generates AI photo prompt and downloads photorealistic real estate cover image
- Auto-publishes to Estate HDR API under 'Estate HDR Team'
- Refreshes XML sitemaps and robots.txt
"""

import os
import sys
import json
import time
import re
import urllib.request
import urllib.parse
import argparse

try:
    sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434")
DEFAULT_MODEL = os.environ.get("OLLAMA_MODEL", "llama3.1:8b")
API_KEY = os.environ.get("ESTATEHDR_API_KEY", "your_n8n_api_key_here")
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Knowledge Base distilled from EstateHDR-Website-Intelligence-Report.xlsx
SEO_KNOWLEDGE = {
    "brand": "Estate HDR (estatehdr.com)",
    "audience": "Real estate photographers, top-producing listing agents, brokerages, Airbnb hosts, and architectural media studios.",
    "core_services": [
        {"name": "HDR Photo Editing", "url": "https://estatehdr.com/services/hdr-photo-editing", "anchor": "flambient real estate HDR photo editing", "keywords": "manual bracket blending, window pulls, color cast correction"},
        {"name": "Virtual Staging", "url": "https://estatehdr.com/services/virtual-staging", "anchor": "3D photorealistic virtual staging", "keywords": "furniture placement, vacant home staging, modern interior design"},
        {"name": "Item Removal & Decluttering", "url": "https://estatehdr.com/services/item-removal", "anchor": "professional photo item removal and decluttering", "keywords": "erase cars, trash bins, cords, family photos"},
        {"name": "Day to Dusk Twilight", "url": "https://estatehdr.com/services/day-to-dusk", "anchor": "day-to-dusk twilight conversion", "keywords": "sunset sky replacement, warm window glow, evening curb appeal"},
        {"name": "2D & 3D Floor Plans", "url": "https://estatehdr.com/services/floor-plans", "anchor": "professional 2D and 3D floor plan redraws", "keywords": "schematic blueprints, CAD drawings, room dimensions"},
        {"name": "Real Estate Video Editing", "url": "https://estatehdr.com/portfolio.php", "anchor": "4K real estate walkthrough video editing", "keywords": "drone cinematic reels, speed ramping, YouTube property tours"}
    ],
    "supporting_links": [
        {"url": "https://estatehdr.com/#pricing", "anchor": "transparent per-image editing pricing"},
        {"url": "https://estatehdr.com/portfolio.php", "anchor": "interactive before and after portfolio gallery"},
        {"url": "https://estatehdr.com/register.php", "anchor": "3 free sample trial edits"}
    ],
    "categories": [
        "HDR Photo Editing",
        "Virtual Staging",
        "Item Removal & Declutter",
        "Day to Dusk Twilight",
        "3D Floor Plans & CAD",
        "Drone & Aerial Media",
        "Pricing & Industry Insights"
    ]
}

def query_ollama(prompt, model=DEFAULT_MODEL, json_format=True, timeout=120):
    """Sends a completion request to local Ollama server."""
    payload = {
        "model": model,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0.7,
            "top_p": 0.9,
            "num_ctx": 4096
        }
    }
    if json_format:
        payload["format"] = "json"

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        f"{OLLAMA_URL}/api/generate",
        data=data,
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        result = json.loads(resp.read().decode())
        return result.get("response", "")

def get_existing_blogs():
    """Reads existing blogs from local data/blogs.json or API."""
    local_path = os.path.join(BASE_DIR, "data", "blogs.json")
    if os.path.exists(local_path):
        try:
            with open(local_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return []

def generate_new_topic(existing_blogs, model=DEFAULT_MODEL):
    """Asks Ollama to brainstorm a brand-new unique topic not yet covered."""
    existing_titles = [b.get("title", "") for b in existing_blogs if b.get("title")]
    existing_slugs = [b.get("slug", "") for b in existing_blogs if b.get("slug")]

    prompt = f"""You are the Principal SEO Content Strategist for {SEO_KNOWLEDGE['brand']}.
Our ICP (Ideal Customer Profile): {SEO_KNOWLEDGE['audience']}.
Available service categories: {json.dumps(SEO_KNOWLEDGE['categories'])}.

Here are the topics ALREADY published on our blog:
{json.dumps(existing_titles, indent=2)}

TASK: Brainstorm ONE brand-new, high-intent, unique blog post topic that has NEVER been covered yet.
Focus on modern commercial real estate marketing, advanced editing workflows, conversion optimization, or technical camera tips that drive listings sales.

Return ONLY raw JSON with this exact structure:
{{
  "title": "Compelling, high-CTR article headline (60-80 chars)",
  "slug": "url-friendly-slug-without-numbers",
  "category": "One category from the available list",
  "target_keyword": "Primary SEO keyword target",
  "hashtags": ["#Tag1", "#Tag2", "#Tag3", "#Tag4", "#Tag5"],
  "image_prompt": "Detailed description of a luxury architectural real estate scene for photorealistic AI cover image generation (specify lighting, room type, architectural style, 8k photographic details)",
  "outline": [
    "Section 1 heading",
    "Section 2 heading",
    "Section 3 heading",
    "Section 4 heading"
  ]
}}
"""
    print(f"[*] Brainstorming new unique topic idea with Ollama ({model})...")
    raw = query_ollama(prompt, model=model, json_format=True)
    try:
        topic_data = json.loads(raw)
        base_slug = re.sub(r'[^a-z0-9]+', '-', topic_data.get('slug', '').lower()).strip('-')
        if not base_slug:
            base_slug = re.sub(r'[^a-z0-9]+', '-', topic_data.get('title', '').lower()).strip('-')
        
        if base_slug in existing_slugs:
            base_slug += f"-{int(time.time()) % 10000}"
        topic_data['slug'] = base_slug
        return topic_data
    except Exception as e:
        print(f"[!] Error parsing topic JSON: {e}\nRaw was: {raw}")
        raise

def generate_article_content(topic, existing_blogs, model=DEFAULT_MODEL):
    """Generates the full authoritative article body with previous blog links."""
    available_prev = [b for b in existing_blogs if b.get("slug") and b.get("title")]
    prev_picks = available_prev[:3]

    prev_citable = [
        {"title": p["title"], "slug": p["slug"], "url": f"/blog/{p['slug']}"}
        for p in prev_picks
    ]

    service_pick = SEO_KNOWLEDGE["core_services"][0]
    for s in SEO_KNOWLEDGE["core_services"]:
        if s["name"].lower() in topic.get("category", "").lower():
            service_pick = s
            break

    prompt = f"""You are a Master Architectural Photography Retoucher and Senior SEO Editor at {SEO_KNOWLEDGE['brand']}.
Write a comprehensive, authoritative, high-ranking 1,200+ word educational article in clean HTML format.

Article Topic: {topic['title']}
Category: {topic['category']}
Target Focus Keyword: {topic['target_keyword']}
Outline to expand: {json.dumps(topic.get('outline', []))}

MANDATORY CONTEXTUAL INTERNAL LINKS REQUIREMENT:
You MUST contextually cite and embed the following links using clean HTML anchors with class 'text-gold underline hover:text-white font-semibold':
1. PREVIOUS BLOG GUIDE: Weave a natural sentence referencing our previous guide:
   <a href="{prev_citable[0]['url']}" class="text-gold underline hover:text-white font-semibold">{prev_citable[0]['title']}</a>
2. SERVICE LANDING PAGE: Link to:
   <a href="{service_pick['url']}" class="text-gold underline hover:text-white font-semibold">{service_pick['anchor']}</a>
3. PORTFOLIO & PRICING: Weave links to:
   <a href="https://estatehdr.com/portfolio.php" class="text-gold underline hover:text-white font-semibold">interactive portfolio examples</a> and <a href="https://estatehdr.com/#pricing" class="text-gold underline hover:text-white font-semibold">transparent per-image pricing</a>.

ARTICLE FORMATTING GUIDELINES:
- Output ONLY the HTML body (do NOT include <html> or <head> or <body> tags).
- Use <h2> and <h3> for headings.
- Include informative <p> paragraphs explaining technical nuances (bracketed exposures, window pulls, flambient strobe control, MLS compliance, turnaround times).
- Include <ul> or <ol> lists for actionable tips.
- Include a <blockquote> with an expert industry quote.
- Include an <h2>Frequently Asked Questions</h2> section with at least 3 Q&As in <h3> / <p> format.
- Do not repeat the main title in the body (start directly with an engaging <h2>).
"""
    print(f"[*] Generating full 1,200+ word article body via Ollama ({model})...")
    raw_html = query_ollama(prompt, model=model, json_format=False, timeout=180)
    
    clean_html = re.sub(r'^```html\s*', '', raw_html, flags=re.IGNORECASE)
    clean_html = re.sub(r'```$', '', clean_html).strip()

    if '/blog/' not in clean_html and prev_citable:
        p = prev_citable[0]
        box = f"""
<div class="glass-card p-5 rounded-2xl border border-gold/30 my-8 bg-gold/5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-lg">
  <div class="flex items-center gap-3">
    <span class="text-xl">📖</span>
    <div>
      <div class="text-xs text-gold font-bold uppercase tracking-wider">Related Industry Guide</div>
      <a href="{p['url']}" class="text-sm font-bold text-white underline hover:text-gold transition-colors">{p['title']} &rarr;</a>
    </div>
  </div>
</div>
"""
        clean_html += "\n\n" + box

    return clean_html

def generate_ai_image(prompt, slug):
    """Generates a photorealistic real estate image using Pollinations Flux and saves locally."""
    print(f"[*] Generating AI architectural cover image for: '{slug}'...")
    encoded = urllib.parse.quote(prompt.strip())
    image_url = f"https://image.pollinations.ai/prompt/{encoded}?width=1200&height=675&model=flux&nologo=true"

    img_dir = os.path.join(BASE_DIR, "assets", "images", "blog")
    os.makedirs(img_dir, exist_ok=True)
    filename = f"ai-{slug}.jpg"
    local_path = os.path.join(img_dir, filename)

    try:
        req = urllib.request.Request(image_url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = resp.read()
            if len(data) > 3000:
                with open(local_path, "wb") as f:
                    f.write(data)
                print(f"[+] Image saved successfully to {local_path} ({len(data)} bytes)")
                return f"/assets/images/blog/{filename}"
    except Exception as e:
        print(f"[!] Warning: Image download failed ({e}), using remote URL fallback")

    return image_url

def run_pipeline(model=DEFAULT_MODEL, count=1):
    """End-to-end autonomous article creation run."""
    print(f"\n========================================================")
    print(f"[*] ESTATE HDR AUTONOMOUS OLLAMA PUBLISHER")
    print(f"Model: {model} | Target: {count} Article(s)")
    print(f"========================================================\n")

    existing_blogs = get_existing_blogs()
    print(f"[*] Found {len(existing_blogs)} existing published blogs in inventory.")

    for i in range(count):
        print(f"\n--- Processing Article {i+1}/{count} ---")
        topic = generate_new_topic(existing_blogs, model=model)
        print(f"[+] Generated Topic Idea: '{topic['title']}'")
        print(f"    Category: {topic['category']}")
        print(f"    Slug: {topic['slug']}")
        print(f"    Hashtags: {', '.join(topic.get('hashtags', []))}")

        content = generate_article_content(topic, existing_blogs, model=model)
        word_count = len(re.findall(r'\w+', re.sub(r'<[^>]+>', '', content)))
        print(f"[+] Article content generated: {word_count} words.")

        image_prompt = topic.get("image_prompt", f"Luxury modern home architectural photography {topic['title']}")
        featured_image = generate_ai_image(image_prompt, topic["slug"])

        faq_matches = re.findall(r'<h3>(.*?)</h3>\s*<p>(.*?)</p>', content)
        faq_entities = []
        for q, a in faq_matches[:3]:
            faq_entities.append({
                "@type": "Question",
                "name": re.sub(r'<[^>]+>', '', q).strip(),
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": re.sub(r'<[^>]+>', '', a).strip()
                }
            })
        schema_json = json.dumps({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": faq_entities
        }, indent=2)

        payload = {
            "id": "blog-" + str(int(time.time())),
            "title": topic["title"],
            "slug": topic["slug"],
            "category": topic["category"],
            "status": "published",
            "content": content,
            "featured_image": featured_image,
            "tags": topic.get("hashtags", ["Real Estate Photography", "HDR Editing", topic["category"]]),
            "author": "Estate HDR Team",
            "author_id": "adm-senior-seo",
            "created_by": "adm-senior-seo",
            "read_time": f"{max(1, int(word_count / 200))} min read",
            "meta_title": f"{topic['title']} | Estate HDR",
            "meta_description": f"Master {topic['title'].lower()} with expert techniques, MLS compliance, and 24-hour turnaround from Estate HDR.",
            "canonical_url": f"https://estatehdr.com/blog/{topic['slug']}",
            "schema_json": schema_json,
            "views_count": 0,
            "created_at": time.strftime('%Y-%m-%dT%H:%M:%S+00:00', time.gmtime()),
            "updated_at": time.strftime('%Y-%m-%dT%H:%M:%S+00:00', time.gmtime())
        }

        # Save directly to blogs.json
        blogs_path = os.path.join(BASE_DIR, "data", "blogs.json")
        with open(blogs_path, "r", encoding="utf-8") as f:
            blogs = json.load(f)
        blogs.insert(0, payload)
        with open(blogs_path, "w", encoding="utf-8") as f:
            json.dump(blogs, f, indent=4, ensure_ascii=False)

        # Refresh Sitemaps
        try:
            import subprocess
            subprocess.run([r"C:\xampp\php\php.exe", "-r", "require_once 'includes/db.php'; generatePhysicalSitemaps();"], cwd=BASE_DIR, check=False)
        except Exception as se:
            print(f"[!] Sitemap refresh notice: {se}")

        print(f"\n[SUCCESS] Article Published Live!")
        print(f"Title: {topic['title']}")
        print(f"Live URL: https://estatehdr.com/blog/{topic['slug']}")
        print(f"Cover Image: {featured_image}")
        print(f"Author: Estate HDR Team")
        print(f"Hashtags: {', '.join(topic.get('hashtags', []))}")
        print(f"Word Count: {word_count}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Estate HDR Autonomous Ollama Article Autoposter")
    parser.add_argument("--model", default=DEFAULT_MODEL, help="Ollama model to use (llama3.1:8b, qwen2.5:14b, etc.)")
    parser.add_argument("--count", type=int, default=1, help="Number of articles to generate")
    args = parser.parse_args()

    run_pipeline(model=args.model, count=args.count)
