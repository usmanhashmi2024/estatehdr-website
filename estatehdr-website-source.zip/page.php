<?php
/**
 * Estate HDR — Dynamic Frontend Page Template Engine
 * Supports Default, Full-Width, and Minimal Landing Page Layouts
 */
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';

$slug = trim($_GET['slug'] ?? 'about-us');
$page = getPageSeo($slug);

if (!$page) {
    header('Location: /');
    exit;
}

$isDraft = (($page['status'] ?? 'published') === 'draft');
$canPreviewDraft = isAdminLoggedIn();

if ($isDraft && !$canPreviewDraft) {
    http_response_code(404);
    die('<h2 style="color:white;background:#0A0A0F;font-family:sans-serif;padding:60px;text-align:center;">404 — This page is currently an unpublished draft.</h2>');
}

$template = $page['template'] ?? 'default';
$pageTitle = htmlspecialchars($page['meta_title'] ?? $page['title'] ?? 'Estate HDR');
$pageDesc  = htmlspecialchars($page['meta_description'] ?? '');
$canonUrl  = htmlspecialchars(!empty($page['canonical_url']) ? $page['canonical_url'] : (BASE_URL . '/page.php?slug=' . urlencode($page['slug'])));
$ogImage   = htmlspecialchars(!empty($page['og_image']) ? $page['og_image'] : (!empty($page['featured_image']) ? $page['featured_image'] : (BASE_URL . '/assets/images/portfolio/hdr/1-after.jpg')));
$robots    = htmlspecialchars($page['robots'] ?? 'index, follow');
$isLanding = ($template === 'landing_page');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<meta name="description" content="<?= $pageDesc ?>">
<meta name="robots" content="<?= $robots ?>">
<link rel="canonical" href="<?= $canonUrl ?>">

<!-- Open Graph / Social Sharing -->
<meta property="og:type"        content="website">
<meta property="og:url"         content="<?= $canonUrl ?>">
<meta property="og:title"       content="<?= $pageTitle ?>">
<meta property="og:description" content="<?= $pageDesc ?>">
<meta property="og:image"       content="<?= $ogImage ?>">
<!-- Twitter Card -->
<meta name="twitter:card"        content="summary_large_image">
<meta name="twitter:title"       content="<?= $pageTitle ?>">
<meta name="twitter:description" content="<?= $pageDesc ?>">
<meta name="twitter:image"       content="<?= $ogImage ?>">
<?= renderSeoHeadTags() ?>

<!-- Custom Schema Markup (JSON-LD) -->
<?php if (!empty($page['schema_json'])): ?>
<script type="application/ld+json" nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
<?= $page['schema_json'] ?>
</script>
<?php endif; ?>

<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap" onload="this.onload=null;this.rel='stylesheet'">
<noscript>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap">
</noscript>
<!-- Tailwind CSS -->
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
tailwind.config = {
  theme: {
    extend: {
      colors: {
        gold: { DEFAULT: '#C9A84C', light: '#E8C97B', dark: '#9A7A2E' },
        dark: { DEFAULT: '#0A0A0F', card: '#111118', border: '#1E1E2E' },
      },
      fontFamily: {
        sans:    ['Inter', 'sans-serif'],
        display: ['Playfair Display', 'serif'],
      },
    }
  }
}
</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php if ($isDraft): ?>
<div class="bg-amber-500/90 text-dark px-6 py-2.5 text-center font-bold text-xs sticky top-0 z-[100] shadow-lg flex items-center justify-center gap-2">
  <span>⚠️</span> <span>DRAFT PREVIEW MODE — This page is currently unpublished and hidden from public visitors.</span>
  <a href="/admin/page-edit.php?slug=<?= urlencode($page['slug']) ?>" class="underline ml-2 text-dark font-black">Edit Page &rarr;</a>
</div>
<?php endif; ?>

<?php if (!$isLanding): ?>
<!-- Public Top Navigation -->
<?php require_once __DIR__ . '/includes/public-header.php'; ?>
<?php endif; ?>

<!-- PAGE HERO / HEADER -->
<header class="<?= $isLanding ? 'pt-16 pb-8' : 'pt-36 pb-12' ?> px-6 border-b border-dark-border/40 bg-gradient-to-b from-dark-card/60 to-dark">
  <div class="<?= $template === 'full_width' ? 'max-w-7xl' : 'max-w-4xl' ?> mx-auto text-center">
    <div class="section-tag mb-3">Estate HDR Official</div>
    <h1 class="text-3xl sm:text-4xl lg:text-5xl font-black text-white leading-tight">
      <?= htmlspecialchars($page['title'] ?? $page['page_name']) ?>
    </h1>
    <?php if (!empty($page['meta_description'])): ?>
      <p class="text-gray-400 text-sm max-w-2xl mx-auto mt-4 leading-relaxed">
        <?= htmlspecialchars($page['meta_description']) ?>
      </p>
    <?php endif; ?>
  </div>
</header>

<!-- PAGE BODY CONTENT -->
<main class="flex-1 px-6 py-12">
  <div class="<?= $template === 'full_width' ? 'max-w-7xl' : 'max-w-4xl' ?> mx-auto">
    
    <?php if (!empty($page['featured_image']) && !$isLanding): ?>
    <div class="rounded-3xl overflow-hidden mb-10 border border-dark-border shadow-2xl aspect-[21/9] bg-dark">
      <img src="<?= htmlspecialchars($page['featured_image']) ?>" alt="<?= htmlspecialchars($page['title'] ?? $page['page_name']) ?>" class="w-full h-full object-cover">
    </div>
    <?php endif; ?>

    <div class="prose prose-invert max-w-none article-content text-[#F1F5F9] text-base sm:text-lg leading-[1.85] space-y-6">
      <?= $page['content'] ?? '<p>Page content coming soon...</p>' ?>
    </div>

    <!-- Call to Action Banner -->
    <div class="glass-card rounded-3xl p-8 sm:p-10 my-16 border border-gold/30 shadow-2xl text-center bg-gradient-to-br from-gold/10 via-dark-card to-dark">
      <h3 class="text-2xl font-bold text-white mb-2">Ready to Elevate Your Real Estate Marketing?</h3>
      <p class="text-gray-400 text-sm max-w-lg mx-auto mb-6">
        Test our quality with 24-hour turnaround HDR bracket editing, virtual staging, and day to dusk enhancement.
      </p>
      <div class="flex flex-col sm:flex-row gap-4 justify-center">
        <a href="/login.php" class="btn-gold py-3 px-8 text-sm font-bold shadow-glow">Access Client Portal &rarr;</a>
        <a href="https://wa.me/447706068176" target="_blank" class="btn-ghost py-3 px-6 text-sm text-emerald-400 hover:text-emerald-300">💬 Chat on WhatsApp</a>
      </div>
    </div>
  </div>
</main>

<?php if (!$isLanding): ?>
<!-- Footer -->
<footer class="border-t border-dark-border py-12 px-6 bg-dark">
  <div class="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-gray-500">
    <p>&copy; <?= date('Y') ?> Estate HDR. All rights reserved.</p>
    <div class="flex items-center gap-5 text-gray-400">
      <a href="<?= FACEBOOK_LINK ?>" target="_blank" class="hover:text-blue-400">Facebook</a>
      <a href="<?= INSTAGRAM_LINK ?>" target="_blank" class="hover:text-pink-400">Instagram</a>
      <a href="<?= LINKEDIN_LINK ?>" target="_blank" class="hover:text-blue-300">LinkedIn</a>
      <a href="<?= WHATSAPP_LINK ?>" target="_blank" class="hover:text-emerald-400">WhatsApp</a>
      <a href="/sitemap.xml" class="hover:text-gold">Sitemap.xml</a>
      <a href="/contact.php" class="hover:text-gold">Contact</a>
    </div>
  </div>
</footer>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/chat-widgets.php'; ?>
</body>
</html>
