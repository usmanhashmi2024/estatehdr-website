# Technical Requirements Document (TRD)
# Estate HDR — Team & Retoucher Mobile Application Architecture

**App Name:** Estate HDR Team Workstation  
**Document Version:** 1.0.0  
**Status:** Approved for Engineering Implementation  
**Architecture:** Cross-Platform Native Mobile (Flutter / React Native)  
**Author:** Estate HDR Principal Systems Architect  

---

## 1. Architecture & Technology Stack

```
┌────────────────────────────────────────────────────────┐
│               ESTATE HDR TEAM APP (FLUTTER)            │
│ • UI Layer: Flutter 3.24+ (Impeller Rendering Engine)  │
│ • State Management: Riverpod 2.5 + WebSocket Sync      │
│ • Audio Engine: just_audio (Client Voice Playback)     │
│ • Local Cache: Isar DB / SQLite (Offline Briefs & SOP) │
│ • Secure Vault: flutter_secure_storage                 │
│ • Realtime Queue: WebSockets (web_socket_channel)      │
│ • Push: FCM v1 (High-Priority Audio Alert Channels)   │
└───────────────────────────┬────────────────────────────┘
                            │ HTTPS / WSS
                            ▼
┌────────────────────────────────────────────────────────┐
│               ESTATE HDR BACKEND & REDIS CORE          │
│ • Concurrency Lock: Redis 7.2 Distributed Mutex        │
│ • Primary DB: MySQL 8.0 / PostgreSQL 16 (ACID)         │
│ • Media Storage: AWS S3 / Cloudflare R2                │
│ • SLA Engine: Celery / Node.js Distributed Cron Workers│
└────────────────────────────────────────────────────────┘
```

### 1.1 Technology Selection
- **Framework:** **Flutter 3.24+ (Dart 3.5)** for high-velocity cross-platform deployment.
- **State Management:** Riverpod 2.5 with stream providers for real-time job queue updates.
- **Audio Playback:** `just_audio` with streaming cache for client voice notes.
- **Concurrency & Locking:** Redis `SETNX` distributed locks on backend to guarantee atomic 1-tap claiming.
- **Push Notification Engine:** FCM with native Android `NotificationChannel` configured for `IMPORTANCE_HIGH` with custom sound chimes.

---

## 2. Team Mobile REST & WebSocket API Specifications

### 2.1 Team Authentication & Shift APIs
```
POST /api/v1/team/auth/login
Request:  { "email": "editor@estatehdr.com", "password": "EditorSecretPassword", "device_type": "android" }
Response: { 
  "status": "success", 
  "access_token": "eyJ...", 
  "role": "photo_editor",
  "shift_status": "on_shift",
  "permissions": ["claim_orders", "upload_deliverables", "resolve_amendments"] 
}

POST /api/v1/team/shift/status
Request:  { "status": "on_shift" } // Options: on_shift, in_production, on_break, off_shift
Response: { "status": "success", "active_since": "2026-09-16T08:00:00Z" }
```

### 2.2 Real-Time Queue & Atomic Claiming API
```
GET /api/v1/team/queue
Response: [
  {
    "order_id": 4895,
    "order_number": "EHDR-2026-4895",
    "service_type": "hdr_photo_editing",
    "photo_count": 30,
    "turnaround_tier": "rush_6h",
    "sla_deadline_at": "2026-09-16T18:00:00Z",
    "payout_amount": 37.50,
    "client_preset": "natural_luxury"
  }
]

POST /api/v1/team/orders/{id}/claim
Request:  {}
Response: { 
  "status": "success", 
  "message": "Order 4895 locked and claimed successfully.",
  "claimed_at": "2026-09-16T13:50:00Z",
  "sla_deadline_at": "2026-09-16T18:00:00Z"
}
// If already claimed by another editor:
// HTTP 409 Conflict: { "status": "error", "message": "Order already claimed by Editor #402." }
```

### 2.3 Deliverables Upload & QC Submission API
```
POST /api/v1/team/orders/{id}/upload-deliverable
Request: {
  "photo_index": 1,
  "photo_title": "Living Room HDR",
  "before_image_url": "https://cdn.estatehdr.com/orders/4895/1-before.webp",
  "after_image_url": "https://cdn.estatehdr.com/orders/4895/1-after.webp",
  "high_res_mls_url": "https://cdn.estatehdr.com/deliverables/4895/1-mls.webp",
  "high_res_print_url": "https://cdn.estatehdr.com/deliverables/4895/1-print.jpg"
}
Response: { "status": "success", "deliverable_id": 9012 }

POST /api/v1/team/orders/{id}/submit-qc
Request: {
  "self_qc_passed": true,
  "checklist_confirmed": ["verticals_straight", "windows_pulled", "colors_neutral", "sky_matched", "dust_removed"],
  "editor_notes": "Living room window view blended with bracket #3."
}
Response: { "status": "success", "status": "pending_qc", "submitted_at": "2026-09-16T15:30:00Z" }
```

### 2.4 Supervisor QC Review API
```
POST /api/v1/team/qc/review
Request: {
  "order_id": 4895,
  "action": "approve", // or "reject"
  "rating": 5,
  "feedback_notes": "Flawless window pull and natural ceiling tones."
}
Response: { "status": "success", "order_status": "ready_for_review" }
```

---

## 3. Atomic Order Claiming Architecture (Redis Mutex)

```
[Editor Taps "Claim Job"]
            │
            ▼
[API Server Receives Request]
            │
            ▼
[Execute Redis Mutex: SET order:lock:{id} {editor_id} NX EX 30]
            │
    ┌───────┴───────┐
    ▼ (Success: Lock Acquired)           ▼ (Fail: Key Exists)
[DB Transaction:                      [Return HTTP 409 Conflict]
 UPDATE orders SET editor_id = ?,      "Order already claimed."
 status = 'in_progress',
 claimed_at = NOW()
 WHERE id = ? AND editor_id IS NULL]
            │
            ▼
[Broadcast WebSocket Event: 'QUEUE_ORDER_REMOVED' {order_id}]
```

---

## 4. Visual Pin Mapping Coordinate Engine

To ensure pins placed on a client mobile device (varying screen dimensions) render with mathematical precision on the editor's device:

```dart
// Coordinate Translation Engine (Dart / Flutter)
Offset calculateCanvasPinPosition(double pinXPct, double pinYPct, Size canvasSize) {
  final double renderX = (pinXPct / 100.0) * canvasSize.width;
  final double renderY = (pinYPct / 100.0) * canvasSize.height;
  return Offset(renderX, renderY);
}
```

---

## 5. Team Push Notification Architecture (FCM High Priority)

```json
{
  "message": {
    "token": "eX8m_editor_fcm_token...",
    "notification": {
      "title": "⚡ Urgent 6h Rush Order Available!",
      "body": "30 Photos - Luxury HDR + Virtual Staging ($37.50 Payout). Tap to claim."
    },
    "data": {
      "click_action": "FLUTTER_NOTIFICATION_CLICK",
      "type": "NEW_JOB_AVAILABLE",
      "order_id": "4895",
      "urgency": "rush_6h",
      "payout": "37.50"
    },
    "android": {
      "priority": "HIGH",
      "notification": {
        "channel_id": "rush_orders_channel",
        "sound": "rush_alert.mp3",
        "default_vibrate_timings": true
      }
    }
  }
}
```

---

## 6. Security, Testing & Internal Deployment

- **Role-Based Token Verification:** API Gateway inspects JWT `role` claim; non-team roles attempting access receive HTTP 403 Forbidden.
- **Watermarking Engine:** All deliverables previewed in the Team App carry subtle dynamic watermarks (`Editor ID + Timestamp`) to protect unreleased client media.
- **Enterprise Distribution:** Distributed internally via **Apple TestFlight** and **Firebase App Distribution / Google Play Internal App Sharing**.
