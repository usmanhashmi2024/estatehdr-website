<?php
/**
 * Estate HDR — CRM Leads & Client Intelligence CSV Export Engine
 * Generates email marketing-ready RFC 4180 CSV files with UTF-8 BOM for Microsoft Excel & Google Sheets.
 */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

requireManagerOrAdmin();

// Release session lock
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

$exportType = trim($_GET['type'] ?? 'all'); // 'all', 'clients', 'leads', 'hot'
$filenameDate = date('Y-m-d_His');
$filename = "estatehdr_leads_export_{$exportType}_{$filenameDate}.csv";

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Pragma: no-cache');
header('Expires: 0');

// Open output stream
$output = fopen('php://output', 'w');

// Output UTF-8 BOM so Excel opens symbols and international names correctly
fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));

// CSV Header Columns optimized for Email Marketing Platforms (Mailchimp, Klaviyo, Brevo, HubSpot)
$headers = [
    'Lead ID',
    'Record Type',
    'Full Name',
    'Email Address',
    'Phone Number',
    'Company / Brokerage',
    'Country',
    'City',
    'Lead Score',
    'Lead Stage / Band',
    'Service of Interest',
    'Total Pageviews',
    'Time Spent (Minutes)',
    'Landing Page',
    'Lead Source / Referrer',
    'First Seen Date',
    'Last Active Date',
    'Assigned Agent',
    'Notes / Tags'
];
fputcsv($output, $headers);

$records = [];
$seenEmails = [];

// 1. Load Registered Clients
$clients = getUsers();
if (in_array($exportType, ['all', 'clients'])) {
    foreach ($clients as $c) {
        $email = strtolower(trim($c['email'] ?? ''));
        if (empty($email)) continue;
        $seenEmails[$email] = true;

        $records[] = [
            $c['id'] ?? 'CLI-' . rand(1000, 9999),
            'Registered Client',
            $c['name'] ?? 'Client',
            $email,
            $c['phone'] ?? '',
            $c['company'] ?? '',
            $c['country'] ?? 'United States',
            $c['city'] ?? '',
            '100', // Clients have max score
            'Hot Customer',
            'Full Service Client',
            '10+',
            '15',
            '/dashboard.php',
            'Direct / Organic',
            date('Y-m-d', strtotime($c['created_at'] ?? 'now')),
            date('Y-m-d', strtotime($c['created_at'] ?? 'now')),
            'Customer Success Team',
            'Active Registered Client; ' . ($c['notes'] ?? '')
        ];
    }
}

// 2. Load CRM Leads (data/leads.json & data/contacts.json)
$leads = readJson(DATA_PATH . 'leads.json');
if (in_array($exportType, ['all', 'leads', 'hot'])) {
    foreach ($leads as $l) {
        $email = strtolower(trim($l['email'] ?? ''));
        if (!empty($email) && isset($seenEmails[$email])) continue; // Deduplicate
        if (!empty($email)) $seenEmails[$email] = true;

        $score = intval($l['score'] ?? ($l['lead_score'] ?? 50));
        $band = $l['band'] ?? ($score >= 70 ? 'Hot Lead' : ($score >= 40 ? 'Warm Lead' : 'Cold Lead'));

        if ($exportType === 'hot' && $score < 70) continue;

        $records[] = [
            $l['id'] ?? ('LEAD-' . substr(md5($email ?: rand()), 0, 6)),
            'CRM Lead',
            $l['name'] ?? 'Lead Contact',
            $email,
            $l['phone'] ?? '',
            $l['company'] ?? '',
            $l['country'] ?? 'United Kingdom',
            $l['city'] ?? '',
            $score,
            $band,
            $l['service'] ?? ($l['service_type'] ?? 'HDR Photography'),
            $l['hits'] ?? 1,
            round(($l['time_spent'] ?? 60) / 60, 1),
            $l['page'] ?? ($l['current_page'] ?? '/'),
            $l['source'] ?? ($l['referrer'] ?? 'Website Form'),
            date('Y-m-d', strtotime($l['created_at'] ?? 'now')),
            date('Y-m-d', strtotime($l['last_seen'] ?? 'now')),
            $l['assigned_agent'] ?? 'Sales Rep',
            $l['notes'] ?? 'CRM Inbound Lead'
        ];
    }
}

// 3. Load Contact Messages (data/contacts.json)
$contacts = readJson(DATA_PATH . 'contacts.json');
if (in_array($exportType, ['all', 'leads'])) {
    foreach ($contacts as $con) {
        $email = strtolower(trim($con['email'] ?? ''));
        if (!empty($email) && isset($seenEmails[$email])) continue;
        if (!empty($email)) $seenEmails[$email] = true;

        $records[] = [
            $con['id'] ?? ('CON-' . rand(100, 999)),
            'Contact Form Inquiry',
            $con['name'] ?? 'Inquirer',
            $email,
            $con['phone'] ?? '',
            $con['company'] ?? '',
            $con['country'] ?? 'United States',
            $con['city'] ?? '',
            '75',
            'Hot Lead',
            $con['service'] ?? 'Photo Editing Inquiry',
            '2',
            '3.5',
            '/contact.php',
            'Contact Us Page',
            date('Y-m-d', strtotime($con['created_at'] ?? 'now')),
            date('Y-m-d', strtotime($con['created_at'] ?? 'now')),
            'Support Team',
            $con['message'] ?? 'Direct Contact Inquiry'
        ];
    }
}

// 4. Load Scored Visitors (data/visitors.json)
$visitors = readJson(DATA_PATH . 'visitors.json');
if (in_array($exportType, ['all', 'leads', 'hot'])) {
    foreach ($visitors as $vid => $v) {
        $email = strtolower(trim($v['email'] ?? ''));
        if (!empty($email) && isset($seenEmails[$email])) continue;
        if (!empty($email)) $seenEmails[$email] = true;

        $score = intval($v['lead_score'] ?? 0);
        if ($score < 20 && empty($email) && $exportType !== 'all') continue;
        if ($exportType === 'hot' && $score < 70) continue;

        $name = !empty($v['name']) ? $v['name'] : (!empty($email) ? strstr($email, '@', true) : "Visitor #{$vid}");

        $records[] = [
            $vid,
            !empty($email) ? 'Identified Prospect' : 'Anonymous Prospect',
            $name,
            $email ?: 'N/A (Anonymous Tracking)',
            $v['phone'] ?? 'N/A',
            $v['company'] ?? '',
            $v['country'] ?? 'United Kingdom',
            $v['city'] ?? '',
            $score,
            $v['lead_band'] ?? ($score >= 70 ? 'Hot Lead' : ($score >= 40 ? 'Warm' : 'Browsing')),
            $v['service_interest'] ?? 'Architectural Photo Editing',
            $v['page_views'] ?? ($v['hits'] ?? 1),
            round(($v['time_spent'] ?? 0) / 60, 1),
            $v['landing_page'] ?? ($v['current_page'] ?? '/'),
            $v['referrer'] ?? 'Direct Visit',
            date('Y-m-d', strtotime($v['first_seen'] ?? 'now')),
            date('Y-m-d', strtotime($v['last_seen'] ?? 'now')),
            $v['assigned_agent'] ?? 'Automated Router',
            "IP: " . ($v['ip'] ?? '') . "; Device: " . ($v['device'] ?? 'Desktop')
        ];
    }
}

// Write records to CSV
foreach ($records as $row) {
    fputcsv($output, $row);
}

fclose($output);
exit;
