<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireAdmin();

$currentAdmin = currentAdminUser();
$isOwner = isOwner();
$isSeniorSeo = (($currentAdmin['id'] ?? '') === 'adm-senior-seo' || strtolower($currentAdmin['email'] ?? '') === 'senior.seo@estatehdr.com');
$isRegularSeo = (!$isOwner && !$isSeniorSeo && in_array('seo_manager', getAdminRoles()));

// Handle Delete Post
if (isset($_GET['delete'])) {
    $delId = trim($_GET['delete']);
    $all = getAllBlogsAdmin();
    foreach ($all as $b) {
        if ($b['id'] === $delId || $b['slug'] === $delId) {
            $creator = $b['created_by'] ?? $b['author_id'] ?? '';
            $author = strtolower($b['author'] ?? '');
            if ($isRegularSeo && ($creator === 'adm-senior-seo' || str_contains($author, 'senior seo'))) {
                setFlash('error', 'Access Restricted: You cannot delete Senior SEO publications.');
                header('Location: /admin/posts.php');
                exit;
            }
            break;
        }
    }
    deleteBlog($delId);
    setFlash('success', 'Blog article deleted successfully.');
    header('Location: /admin/posts.php');
    exit;
}

$allPosts = getAllBlogsAdmin();

// Isolate Senior SEO Lead's exclusive automated articles from regular SEO manager
if ($isRegularSeo) {
    $allPosts = array_values(array_filter($allPosts, function($p) {
        $creator = $p['created_by'] ?? $p['author_id'] ?? '';
        $author = strtolower($p['author'] ?? '');
        if ($creator === 'adm-senior-seo' || str_contains($author, 'senior seo')) {
            return false; // Hidden from regular SEO manager
        }
        return true;
    }));
}
$filterStatus = trim($_GET['status'] ?? 'all');
$searchKw     = strtolower(trim($_GET['q'] ?? ''));

$filtered = array_filter($allPosts, function($p) use ($filterStatus, $searchKw) {
    if ($filterStatus !== 'all') {
        $st = $p['status'] ?? 'published';
        if ($st !== $filterStatus) return false;
    }
    if ($searchKw !== '') {
        $matches = str_contains(strtolower($p['title']), $searchKw) ||
                   str_contains(strtolower($p['category'] ?? ''), $searchKw);
        if (!$matches) return false;
    }
    return true;
});
$filtered = array_values($filtered);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Blog Posts CMS — Estate HDR Admin</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8">
  <?= renderFlash() ?>

  <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
    <div>
      <div class="section-tag mb-1">Content Marketing &amp; SEO</div>
      <h1 class="text-2xl sm:text-3xl font-black text-white">BLOG POSTS &amp; ARTICLES CMS</h1>
      <p class="text-gray-400 text-xs mt-1">Publish rich educational guides, service case studies, and scheduled real estate photography articles.</p>
    </div>

    <a href="/admin/post-edit.php" class="btn-gold py-2.5 px-6 text-xs font-bold shadow-glow inline-flex items-center gap-2">
      <span>+</span> <span>Add New Blog Post</span>
    </a>
  </div>

  <!-- Filter Tabs & Search Bar -->
  <div class="glass-card rounded-2xl p-5 mb-6 border border-dark-border shadow-xl flex flex-wrap items-center justify-between gap-4">
    <div class="flex items-center gap-2 text-xs font-bold uppercase tracking-wider">
      <a href="?status=all" class="px-3 py-1.5 rounded-lg <?= $filterStatus === 'all' ? 'bg-gold text-dark font-black' : 'text-gray-400 hover:text-white bg-dark' ?>">
        All (<?= count($allPosts) ?>)
      </a>
      <a href="?status=published" class="px-3 py-1.5 rounded-lg <?= $filterStatus === 'published' ? 'bg-gold text-dark font-black' : 'text-gray-400 hover:text-white bg-dark' ?>">
        Published
      </a>
      <a href="?status=draft" class="px-3 py-1.5 rounded-lg <?= $filterStatus === 'draft' ? 'bg-gold text-dark font-black' : 'text-gray-400 hover:text-white bg-dark' ?>">
        Drafts
      </a>
      <a href="?status=scheduled" class="px-3 py-1.5 rounded-lg <?= $filterStatus === 'scheduled' ? 'bg-gold text-dark font-black' : 'text-gray-400 hover:text-white bg-dark' ?>">
        Scheduled
      </a>
    </div>

    <form method="GET" class="flex items-center gap-2">
      <input type="hidden" name="status" value="<?= htmlspecialchars($filterStatus) ?>">
      <input type="text" name="q" value="<?= htmlspecialchars($_GET['q'] ?? '') ?>" class="form-input text-xs py-1.5 px-3 w-64" placeholder="Search by title or category...">
      <button type="submit" class="btn-ghost py-1.5 px-3 text-xs font-bold">Search</button>
    </form>
  </div>

  <!-- Posts Table -->
  <div class="glass-card rounded-2xl overflow-hidden border border-dark-border shadow-2xl">
    <div class="p-4 border-b border-dark-border flex items-center justify-between">
      <h3 class="text-xs font-bold text-white uppercase tracking-wider">ARTICLES LIST</h3>
      <span class="text-xs text-gray-400 font-mono"><?= count($filtered) ?> articles</span>
    </div>

    <?php if (empty($filtered)): ?>
    <div class="p-16 text-center text-gray-500 text-sm">
      <div class="text-4xl mb-2">📝</div>
      <p class="text-white font-bold mb-1">No articles found</p>
      <a href="/admin/post-edit.php" class="btn-gold py-2 px-5 text-xs font-bold shadow-glow mt-3 inline-block">+ Create Your First Post</a>
    </div>
    <?php else: ?>
    <div class="overflow-x-auto">
      <table class="dashboard-table w-full text-left text-xs">
        <thead>
          <tr>
            <th>Article Title</th>
            <th>Category</th>
            <th>Status</th>
            <th>Author</th>
            <th>Date / Scheduled</th>
            <th class="text-center">Sitemap</th>
            <th class="text-right">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($filtered as $post): 
            $status = $post['status'] ?? 'published';
          ?>
          <tr>
            <td class="font-bold text-white max-w-sm">
              <div class="text-white font-bold line-clamp-1"><?= !empty(trim($post['title'] ?? '')) ? htmlspecialchars($post['title']) : '<span class="text-gray-500 italic font-normal">(Untitled Post)</span>' ?></div>
              <div class="text-xs text-gold/70 font-mono mt-0.5">/blog/<?= htmlspecialchars($post['slug'] ?? '') ?></div>
            </td>
            <td>
              <span class="px-2.5 py-1 rounded-md bg-dark border border-dark-border text-gold text-xs font-semibold">
                <?= htmlspecialchars($post['category'] ?? 'General') ?>
              </span>
            </td>
            <td>
              <span class="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase <?= $status === 'published' ? 'bg-emerald-500/20 text-emerald-300' : ($status === 'scheduled' ? 'bg-blue-500/20 text-blue-300' : 'bg-amber-500/20 text-amber-300') ?>">
                <?= ucfirst($status) ?>
              </span>
            </td>
            <td class="text-gray-300">
              <?php
                $authorName = getPostAuthorDisplayName($post);
                $isSenior = (($post['created_by'] ?? '') === 'adm-senior-seo' || $authorName === 'Estate HDR Team');
              ?>
              <span class="inline-flex items-center gap-1.5">
                <span class="w-1.5 h-1.5 rounded-full <?= $isSenior ? 'bg-gold' : 'bg-emerald-400' ?>"></span>
                <span class="<?= $isSenior ? 'text-gray-300' : 'text-emerald-300 font-medium' ?>"><?= htmlspecialchars($authorName) ?></span>
              </span>
            </td>
            <td class="text-gray-400 font-mono">
              <?php if ($status === 'scheduled' && !empty($post['scheduled_at'])): ?>
                <span class="text-blue-400">🕒 <?= date('M j, Y H:i', strtotime($post['scheduled_at'])) ?></span>
              <?php else: ?>
                <?= date('M j, Y', strtotime($post['created_at'])) ?>
              <?php endif; ?>
            </td>
            <td class="text-center">
              <?php if (!empty($post['exclude_sitemap'])): ?>
                <span class="text-amber-400 text-xs">Excluded</span>
              <?php else: ?>
                <span class="text-green-400 text-xs">Included</span>
              <?php endif; ?>
            </td>
            <td class="text-right">
              <div class="flex items-center justify-end gap-2">
                <a href="<?= !empty($post['slug']) ? ('/blog/' . urlencode($post['slug'])) : ('/admin/post-edit.php?id=' . urlencode($post['id'])) ?>" target="_blank" class="btn-ghost py-1 px-2.5 text-xs text-gray-400 hover:text-white" title="View Public Post">
                  View ↗
                </a>
                <a href="/admin/post-edit.php?id=<?= urlencode($post['id']) ?>" class="btn-gold py-1 px-3 text-xs font-bold shadow-glow">
                  Edit
                </a>
                <a href="?delete=<?= urlencode($post['id']) ?>" data-confirm="Are you sure you want to delete this article?" class="btn-ghost py-1 px-2 text-xs text-red-400 hover:border-red-400" title="Delete Post">
                  ✕
                </a>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>
</main>
</body>
</html>
