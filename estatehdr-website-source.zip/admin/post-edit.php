<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireSeoManagerOrAdmin();

$postId = trim($_GET['id'] ?? '');
$isEditing = !empty($postId);
$post = null;

if ($isEditing) {
    $all = getAllBlogsAdmin();
    foreach ($all as $b) {
        if ($b['id'] === $postId || $b['slug'] === $postId) {
            $post = $b;
            break;
        }
    }
}

$postCategories = getPostCategories();
$serverMediaImages = function_exists('getServerMediaImages') ? getServerMediaImages() : [];
$blogImagesCount = count(array_filter($serverMediaImages, fn($i) => ($i['folder'] ?? '') === 'blog'));
$uploadsImagesCount = count(array_filter($serverMediaImages, fn($i) => ($i['folder'] ?? '') === 'uploads'));
$portfolioImagesCount = count(array_filter($serverMediaImages, fn($i) => ($i['folder'] ?? '') === 'portfolio'));
$totalImagesCount = count($serverMediaImages);

$currentAdmin = currentAdminUser();
$isOwner = isOwner();
$isSeniorSeo = (($currentAdmin['id'] ?? '') === 'adm-senior-seo' || strtolower($currentAdmin['email'] ?? '') === 'senior.seo@estatehdr.com');
$isRegularSeo = (!$isOwner && !$isSeniorSeo && in_array('seo_manager', getAdminRoles()));

// Enforce isolation: regular SEO manager cannot edit Senior SEO publications
if ($isEditing && $post && $isRegularSeo) {
    $creator = $post['created_by'] ?? $post['author_id'] ?? '';
    $author = strtolower($post['author'] ?? '');
    if ($creator === 'adm-senior-seo' || str_contains($author, 'senior seo')) {
        setFlash('error', 'Access Restricted: This publication is managed exclusively by Senior SEO Operations.');
        header('Location: /admin/posts.php');
        exit;
    }
}

function sanitizeEditorArticleHtml(string $rawContent): string {
    if (!preg_match('/<([a-z1-6]+)\b[^>]*>/i', $rawContent)) {
        return $rawContent;
    }
    $content = $rawContent;
    $content = preg_replace('/<!--\s*(?:Start|End)Fragment\s*-->/i', '', $content);
    $content = preg_replace('/<!--\s*\/?wp:[^>]*-->/i', '', $content);
    $content = preg_replace('~<table\b[^>]*>\s*<tbody>\s*<tr[^>]*>\s*<td\s+width=["\']\d+["\'][^>]*>(?:(?!<table).)*?<\/td>\s*<\/tr>\s*<\/tbody>\s*<\/table>~is', '', $content);
    $content = preg_replace('~<table\b[^>]*>\s*<tbody>\s*<tr>\s*<td\s+width=["\']\d+["\'][^>]*>(?:(?!<table).)*?<\/td>\s*<\/tr>~is', '', $content);
    $content = preg_replace('~<tr[^>]*>\s*<td\s+width=["\']\d+["\'][^>]*>(?:(?!<table).)*?<\/td>\s*<\/tr>\s*<\/tbody>\s*<\/table>~is', '', $content);
    $content = preg_replace('~<p>\s*<style\b[^>]*>.*?<\/style>\s*<\/p>~is', '', $content);
    $content = preg_replace('~<style\b[^>]*>.*?<\/style>~is', '', $content);
    $content = preg_replace('/\s+class=["\'](?:MsoNormal|MsoListBullet[A-Za-z0-9]*|MsoListNumber[A-Za-z0-9]*)["\']/i', '', $content);
    $content = preg_replace('/\s+lang=["\'][^"\']+["\']/i', '', $content);
    $content = preg_replace('/\s+style=["\'][^"\']*mso-[^"\']*["\']/i', '', $content);
    $content = preg_replace('/<b\s+style=["\']mso-[^"\']*["\']>/i', '<b>', $content);
    $content = preg_replace('/bis_skin_checked=["\'][^"\']*["\']/i', '', $content);
    $content = preg_replace('~<p[^>]*>\s*(<(?:ul|ol)\b[^>]*>.*?<\/(?:ul|ol)>)\s*<\/p>~is', '$1', $content);
    $content = preg_replace('~<a\b([^>]*)>\s*(?:<span>)?\s*<a\b[^>]*>(.*?)<\/a>\s*(.*?)(?:<\/span>)?\s*<\/a>~is', '<a $1>$2 $3</a>', $content);
    $content = preg_replace('~<span\s+style=["\'][^"\']*font-size:\s*0\.95rem[^"\']*["\']>(.*?)<\/span>~is', '$1', $content);
    $content = preg_replace('~<span\s*>\s*<\/span>~i', '', $content);
    $content = preg_replace('~<p\s*>\s*(?:<br\s*\/?>|&nbsp;|\s)*<\/p>~i', '', $content);
    $content = preg_replace('~<p>\s*&nbsp;\s*<\/p>~i', '', $content);
    return trim($content);
}

// Handle Save POST (Supports standard multipart, URL-encoded, and JSON AJAX payloads)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $isAjax = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
           || (!empty($_SERVER['CONTENT_TYPE']) && str_contains($_SERVER['CONTENT_TYPE'], 'application/json'))
           || isset($_POST['ajax_save']);

    // Support JSON payload if submitted via fetch application/json
    $rawInput = file_get_contents('php://input');
    if (!empty($rawInput)) {
        $jsonInput = json_decode($rawInput, true);
        if (is_array($jsonInput)) {
            $_POST = array_merge($_POST, $jsonInput);
        }
    }

    // CSRF verification with friendly token regeneration
    $token = $_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (empty($token) || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        $freshToken = csrfToken();
        if ($isAjax) {
            header('Content-Type: application/json; charset=utf-8');
            http_response_code(200); // 200 with code prevents browser error page navigation
            echo json_encode([
                'success'        => false,
                'code'           => 'CSRF_EXPIRED',
                'error'          => 'Your editing session or security token refreshed. Auto-renewing session...',
                'new_csrf_token' => $freshToken
            ]);
            exit;
        } else {
            setFlash('error', 'Session refreshed. Please click Publish / Save again.');
            header('Location: ' . ($_SERVER['REQUEST_URI'] ?: '/admin/posts.php'));
            exit;
        }
    }

    // Decode Base64 content & schema if sent by client (WAF / ModSecurity Immune)
    $rawContent = '';
    if (!empty($_POST['content_b64'])) {
        $rawContent = base64_decode($_POST['content_b64']);
    } elseif (isset($_POST['content'])) {
        $rawContent = $_POST['content'];
    }

    $rawSchema = '';
    if (!empty($_POST['schema_json_b64'])) {
        $rawSchema = base64_decode($_POST['schema_json_b64']);
    } elseif (isset($_POST['schema_json'])) {
        $rawSchema = $_POST['schema_json'];
    }

    $postData = [
        'id'               => $isEditing ? $post['id'] : ('blog-' . time()),
        'title'            => trim($_POST['title'] ?? ''),
        'slug'             => trim($_POST['slug'] ?? ''),
        'excerpt'          => trim($_POST['excerpt'] ?? ''),
        'content'          => sanitizeEditorArticleHtml($rawContent),
        'category'         => trim($_POST['category'] ?? 'HDR Photo Editing'),
        'tags'             => trim($_POST['tags'] ?? ''),
        'featured_image'   => trim($_POST['featured_image'] ?? ''),
        'author'           => !empty(trim($_POST['author'] ?? '')) ? trim($_POST['author']) : ($isSeniorSeo ? 'Estate HDR Team' : ($currentAdmin['name'] ?? 'SEO & Content Manager')),
        'author_id'        => $isEditing ? ($post['author_id'] ?? ($currentAdmin['id'] ?? '')) : ($currentAdmin['id'] ?? ''),
        'created_by'       => $isEditing ? ($post['created_by'] ?? ($currentAdmin['id'] ?? '')) : ($currentAdmin['id'] ?? ''),
        'read_time'        => trim($_POST['read_time'] ?? '5 min read'),
        'status'           => $_POST['status'] ?? 'published',
        'scheduled_at'     => trim($_POST['scheduled_at'] ?? ''),
        'meta_title'       => trim($_POST['meta_title'] ?? ''),
        'meta_description' => trim($_POST['meta_description'] ?? ''),
        'canonical_url'    => trim($_POST['canonical_url'] ?? ''),
        'robots'           => $_POST['robots'] ?? 'index, follow',
        'exclude_sitemap'  => isset($_POST['exclude_sitemap']),
        'schema_json'      => trim($rawSchema),
        'created_at'       => $isEditing ? ($post['created_at'] ?? date('c')) : date('c')
    ];

    if (empty($postData['meta_title'])) $postData['meta_title'] = $postData['title'];
    if (empty($postData['excerpt']) && !empty($postData['meta_description'])) $postData['excerpt'] = $postData['meta_description'];
    if (empty($postData['excerpt']) && !empty($postData['content'])) {
        $postData['excerpt'] = mb_substr(trim(preg_replace('/\s+/', ' ', strip_tags($postData['content']))), 0, 160) . '...';
    }
    if (empty($postData['meta_description'])) $postData['meta_description'] = $postData['excerpt'];

    $saved = saveBlog($postData);
    $statusText = $saved['status'] === 'draft' ? 'saved as Draft' : 'published live';
    $msg = 'Blog article "' . htmlspecialchars($saved['title']) . '" ' . $statusText . ' successfully!';
    setFlash('success', $msg);

    $isDraft = ($saved['status'] === 'draft' || ($_POST['status'] ?? '') === 'draft');
    $redirectUrl = $isDraft 
        ? ('/admin/post-edit.php?id=' . urlencode($saved['id']) . '&saved=draft')
        : '/admin/posts.php';

    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'success'     => true,
            'id'          => $saved['id'],
            'status'      => $saved['status'],
            'title'       => $saved['title'],
            'redirect'    => $redirectUrl,
            'message'     => $msg,
            'csrf_token'  => csrfToken()
        ]);
        exit;
    }

    header('Location: ' . $redirectUrl);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta name="csrf-token" content="<?= csrfToken() ?>">
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">window.CSRF_TOKEN = '<?= csrfToken() ?>';</script>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $isEditing ? 'Edit Post: ' . htmlspecialchars($post['title']) : 'Add New Blog Post' ?> — Estate HDR</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
<style nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
/* Visual WYSIWYG Editor Styles */
#editorVisual, #editorVisualFullscreen {
  min-height: 420px;
  max-height: 850px;
  overflow-y: auto;
  outline: none;
  font-family: 'Inter', system-ui, -apple-system, sans-serif;
  color: #E2E8F0;
  line-height: 1.75;
}
#editorVisual:focus, #editorVisualFullscreen:focus { border-color: #C9A84C; }

/* ── Clear Visual Headings with Badges ── */
#editorVisual h1, #editorVisualFullscreen h1 {
  font-size: 2rem !important;
  font-weight: 800 !important;
  margin: 1.5rem 0 0.6rem !important;
  color: #FFFFFF !important;
  border-bottom: 2px solid rgba(201, 168, 76, 0.4) !important;
  padding-bottom: 0.35rem !important;
}
#editorVisual h1::before, #editorVisualFullscreen h1::before {
  content: "H1 Main Heading";
  display: inline-block;
  font-size: 11px;
  font-family: ui-monospace, SFMono-Regular, monospace;
  font-weight: 800;
  text-transform: uppercase;
  background: rgba(201, 168, 76, 0.25);
  color: #C9A84C;
  border: 1px solid rgba(201, 168, 76, 0.5);
  padding: 2px 8px;
  border-radius: 6px;
  margin-right: 10px;
  vertical-align: middle;
  user-select: none;
}

#editorVisual h2, #editorVisualFullscreen h2 {
  font-size: 1.6rem !important;
  font-weight: 800 !important;
  margin: 1.35rem 0 0.5rem !important;
  color: #F5D77F !important;
  border-left: 4px solid #F5D77F !important;
  padding-left: 10px !important;
}
#editorVisual h2::before, #editorVisualFullscreen h2::before {
  content: "H2 Section";
  display: inline-block;
  font-size: 10px;
  font-family: ui-monospace, SFMono-Regular, monospace;
  font-weight: 800;
  text-transform: uppercase;
  background: rgba(245, 215, 127, 0.2);
  color: #F5D77F;
  border: 1px solid rgba(245, 215, 127, 0.4);
  padding: 1px 7px;
  border-radius: 6px;
  margin-right: 8px;
  vertical-align: middle;
  user-select: none;
}

#editorVisual h3, #editorVisualFullscreen h3 {
  font-size: 1.3rem !important;
  font-weight: 700 !important;
  margin: 1.15rem 0 0.4rem !important;
  color: #C9A84C !important;
  border-left: 3px solid #C9A84C !important;
  padding-left: 8px !important;
}
#editorVisual h3::before, #editorVisualFullscreen h3::before {
  content: "H3 Sub-heading";
  display: inline-block;
  font-size: 9px;
  font-family: ui-monospace, SFMono-Regular, monospace;
  font-weight: 800;
  text-transform: uppercase;
  background: rgba(201, 168, 76, 0.15);
  color: #C9A84C;
  border: 1px solid rgba(201, 168, 76, 0.3);
  padding: 1px 6px;
  border-radius: 5px;
  margin-right: 8px;
  vertical-align: middle;
  user-select: none;
}

#editorVisual h4, #editorVisualFullscreen h4 {
  font-size: 1.1rem !important;
  font-weight: 700 !important;
  margin: 0.85rem 0 0.3rem !important;
  color: #E2E8F0 !important;
}
#editorVisual h4::before, #editorVisualFullscreen h4::before {
  content: "H4";
  display: inline-block;
  font-size: 9px;
  font-family: ui-monospace, SFMono-Regular, monospace;
  font-weight: 800;
  background: rgba(255, 255, 255, 0.15);
  color: #E2E8F0;
  border: 1px solid rgba(255, 255, 255, 0.3);
  padding: 1px 5px;
  border-radius: 4px;
  margin-right: 6px;
  vertical-align: middle;
  user-select: none;
}

#editorVisual p, #editorVisualFullscreen p, #editorVisual div:not(.grid):not(.glass-card):not(.schema-embed-badge), #editorVisualFullscreen div:not(.grid):not(.glass-card):not(.schema-embed-badge) { margin-top: 0 !important; margin-bottom: 0.65rem !important; line-height: 1.65 !important; color: #E2E8F0; }
#editorVisual blockquote, #editorVisualFullscreen blockquote { border-left: 4px solid #C9A84C; background: rgba(22, 22, 34, 0.4); padding: 1rem 1.25rem; margin: 1.25rem 0; font-style: italic; color: #CBD5E1; border-radius: 0 0.75rem 0.75rem 0; }
#editorVisual ul, #editorVisualFullscreen ul { list-style-type: disc; margin-left: 1.5rem; margin-bottom: 0.85rem; }
#editorVisual ol, #editorVisualFullscreen ol { list-style-type: decimal; margin-left: 1.5rem; margin-bottom: 0.85rem; }
#editorVisual table, #editorVisualFullscreen table { width: 100% !important; border-collapse: collapse !important; margin: 1.25rem 0 !important; border: 1px solid #2D2D3F !important; border-radius: 0.75rem !important; overflow: hidden !important; background: #0E0E16 !important; color: #F1F5F9 !important; }
#editorVisual th, #editorVisual td, #editorVisualFullscreen th, #editorVisualFullscreen td { border: 1px solid #2D2D3F !important; padding: 0.75rem 0.9rem !important; text-align: left !important; }
#editorVisual th, #editorVisualFullscreen th { background: #161622 !important; color: #C9A84C !important; font-weight: bold !important; text-transform: uppercase !important; font-size: 0.75rem !important; letter-spacing: 0.05em !important; }
#editorVisual td, #editorVisualFullscreen td { background: #0E0E16 !important; color: #F1F5F9 !important; font-size: 0.875rem !important; line-height: 1.5 !important; }
#editorVisual tr:nth-child(even) td, #editorVisualFullscreen tr:nth-child(even) td { background: #14141F !important; }
#editorVisual img, #editorVisualFullscreen img { max-width: 100%; border-radius: 0.75rem; margin: 1rem 0; box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5); }
#editorVisual a, #editorVisualFullscreen a { color: #C9A84C; text-decoration: underline; font-weight: bold; }
#editorVisual hr, #editorVisualFullscreen hr { border: 0; border-top: 1px solid #2A2A3A; margin: 2rem 0; }
html.light #editorVisual, html.light #editorVisualFullscreen { color: #0F172A; background-color: #FFFFFF; }
html.light #editorVisual h1, html.light #editorVisual h2, html.light #editorVisualFullscreen h1, html.light #editorVisualFullscreen h2 { color: #0F172A; }
html.light #editorVisual p, html.light #editorVisualFullscreen p, html.light #editorVisual div, html.light #editorVisualFullscreen div { color: #334155; }
html.light #editorVisual table, html.light #editorVisualFullscreen table { background: #FFFFFF !important; border-color: #CBD5E1 !important; color: #0F172A !important; }
html.light #editorVisual th, html.light #editorVisualFullscreen th { background: #F1F5F9 !important; color: #9A7A2E !important; border-color: #CBD5E1 !important; }
html.light #editorVisual td, html.light #editorVisualFullscreen td { background: #FFFFFF !important; color: #0F172A !important; border-color: #CBD5E1 !important; }
html.light #editorVisual tr:nth-child(even) td, html.light #editorVisualFullscreen tr:nth-child(even) td { background: #F8FAFC !important; }
</style>
</head>
<body class="bg-[#0A0A0F] text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8">
  <?= renderFlash() ?>

  <!-- Top Action Bar with Back Button & Quick Action Buttons -->
  <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-[#1E1E2E]">
    <div class="flex items-center gap-4">
      <a href="/admin/posts.php" class="btn-ghost py-2.5 px-4 text-xs font-bold inline-flex items-center gap-2 border border-[#1E1E2E] hover:border-gold">
        <span>←</span> <span>Back to Posts</span>
      </a>
      <div>
        <h1 class="text-xl sm:text-2xl font-black text-white"><?= $isEditing ? 'Edit Post: ' . htmlspecialchars($post['title']) : 'Add New Blog Post' ?></h1>
        <p class="text-xs text-gray-400">Complete WYSIWYG editor with live formatting, draft saving, and SSR SEO controls.</p>
      </div>
    </div>

    <!-- Quick Action Buttons (Single Consolidated Bar) -->
    <div class="flex items-center gap-3">
      <button type="button" onclick="EstateEditor.openLivePreview('post')" class="btn-ghost py-2.5 px-4 text-xs font-bold text-gold border-gold/40 hover:bg-gold/10 inline-flex items-center gap-1.5 shadow-sm">
        <span>👁️</span> <span>Live Preview</span>
      </button>
      <button type="button" onclick="submitAs('draft')" class="btn-ghost py-2.5 px-5 text-xs font-bold text-gray-300 border-[#2A2A3A] hover:border-gold inline-flex items-center gap-1.5">
        <span>💾</span> <span>Save as Draft</span>
      </button>
      <button type="button" id="topSubmitBtn" onclick="submitAs('published')" class="btn-gold py-2.5 px-6 text-xs font-black shadow-glow inline-flex items-center gap-1.5">
        <span>🚀</span> <span id="topSubmitBtnText"><?= $isEditing ? 'Update & Publish' : 'Publish Article' ?></span>
      </button>
    </div>
  </div>

  <!-- Local Auto-Save & Recovery Alert Banner (Hidden by default, shown if uncommitted local draft exists) -->
  <div id="draftRecoveryBanner" class="hidden mb-6 p-4 rounded-xl bg-gradient-to-r from-amber-950/70 via-amber-900/40 to-[#111118] border border-amber-500/60 shadow-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
    <div class="flex items-center gap-3">
      <div class="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-xl shrink-0">
        🛡️
      </div>
      <div>
        <h4 class="text-sm font-bold text-amber-300 flex items-center gap-2">
          <span>Unsaved Article Draft Recovered!</span>
          <span class="px-2 py-0.5 rounded bg-amber-500/20 text-amber-200 text-[10px] font-mono font-bold uppercase">Crash &amp; Back-button Protection</span>
        </h4>
        <p class="text-xs text-gray-300 mt-0.5">We detected an unsaved local draft from <span id="draftTimeDisplay" class="font-bold text-white"></span>. Your written article was automatically preserved.</p>
      </div>
    </div>
    <div class="flex items-center gap-2 shrink-0">
      <button type="button" onclick="restoreLocalDraft()" class="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-dark font-black text-xs shadow-glow flex items-center gap-1.5 transition-all">
        <span>🔄</span> <span>Restore My Draft</span>
      </button>
      <button type="button" onclick="dismissLocalDraft()" class="px-3 py-2 rounded-lg bg-dark/80 hover:bg-dark text-gray-400 hover:text-white border border-[#2A2A3A] text-xs transition-all">
        ✕ Discard
      </button>
    </div>
  </div>

  <!-- Real-Time Auto-Save & Session Keep-Alive Status Bar -->
  <div class="flex items-center justify-between text-xs text-gray-400 mb-3 px-1">
    <div class="flex items-center gap-2 font-mono text-[11px]">
      <span id="autoSaveIndicatorDot" class="w-2 h-2 rounded-full bg-emerald-400"></span>
      <span id="autoSaveStatusText">Auto-save protection active (local backup every 5s)</span>
    </div>
    <div id="heartbeatStatusText" class="text-[11px] font-mono text-gray-500 flex items-center gap-1">
      <span class="text-emerald-400 font-bold">●</span> <span>Session Active</span>
    </div>
  </div>

  <form id="postForm" method="POST" class="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start w-full">
    <?= csrfField() ?>
    <input type="hidden" id="formStatus" name="status" value="<?= htmlspecialchars($post['status'] ?? 'published') ?>">

    <!-- LEFT COLUMN: MAIN CONTENT & RICH EDITOR (8 OF 12 COLS - NEVER SQUISHES) -->
    <div class="lg:col-span-8 xl:col-span-8 w-full min-w-0 space-y-6">
      

      <!-- Post Title & Slug -->
      <div class="glass-card rounded-2xl p-6 border border-dark-border shadow-xl space-y-4 bg-[#111118]">
        <div>
          <label class="form-label text-xs">Post Title (Main H1) <span class="text-red-400">*</span></label>
          <input type="text" id="postTitle" name="title" value="<?= htmlspecialchars($post['title'] ?? '') ?>" 
                 class="form-input text-base font-bold" placeholder="e.g. 7 Real Estate Photography Trends Dominating 2026" required oninput="syncSlug()">
        </div>

        <div>
          <div class="flex items-center justify-between mb-1">
            <label class="form-label text-xs mb-0">URL Slug / Permalink</label>
            <div class="flex items-center gap-2">
              <button type="button" onclick="regenerateSlugFromTitle()" class="text-[11px] text-amber-400 hover:text-gold flex items-center gap-1 font-semibold" title="Auto-generate clean slug from post title">
                <span>🔄</span> <span>Auto-Generate</span>
              </button>
              <button type="button" onclick="toggleSlugEdit()" id="slugEditToggleBtn" class="text-[11px] text-gray-400 hover:text-white flex items-center gap-1 font-semibold" title="Unlock slug editing">
                <span>✏️</span> <span>Edit URL</span>
              </button>
            </div>
          </div>
          <div class="flex items-center">
            <span class="bg-dark px-3 py-2 text-xs font-mono text-gray-500 border border-r-0 border-dark-border rounded-l-xl select-none">https://estatehdr.com/blog/</span>
            <input type="text" id="postSlug" name="slug" value="<?= htmlspecialchars($post['slug'] ?? '') ?>" 
                   class="form-input text-xs font-mono rounded-l-none" placeholder="real-estate-photography-trends-2026" oninput="updateSlugPreview()">
          </div>
          <p class="text-[11px] text-gray-500 mt-1 font-mono">Preview Link: <a id="slugPreviewLink" href="/blog/<?= htmlspecialchars($post['slug'] ?? '') ?>" target="_blank" class="text-gold hover:underline">/blog/<span id="slugPreviewText"><?= htmlspecialchars($post['slug'] ?? '') ?></span> ↗</a></p>
        </div>

        <div>
          <label class="form-label text-xs">Article Excerpt / Summary</label>
          <?php
          $currentExcerpt = trim($post['excerpt'] ?? '');
          if (empty($currentExcerpt) && !empty($post['meta_description'])) {
              $currentExcerpt = trim($post['meta_description']);
          }
          if (empty($currentExcerpt) && !empty($post['content'])) {
              $currentExcerpt = mb_substr(trim(preg_replace('/\s+/', ' ', strip_tags($post['content']))), 0, 160) . '...';
          }
          ?>
          <textarea id="postExcerpt" name="excerpt" rows="2" class="form-input text-xs resize-y" placeholder="Short preview summary shown on blog archives and Google snippet..."><?= htmlspecialchars($currentExcerpt) ?></textarea>
        </div>
      </div>

      <!-- Rich Block Content Editor -->
      <div class="glass-card rounded-2xl p-6 border border-dark-border shadow-xl space-y-3 bg-[#111118]">
        <div class="flex items-center justify-between border-b border-[#1E1E2E] pb-3">
          <div class="flex items-center gap-2">
            <label class="form-label text-xs font-bold text-white mb-0">Article Body Content</label>
            <span class="px-2 py-0.5 rounded bg-gold/10 text-gold text-[10px] font-bold uppercase">WYSIWYG Pro • Type / for commands</span>
          </div>
          <div class="flex items-center gap-2">
            <button type="button" onclick="EstateEditor.openFullscreenModal()" class="btn-ghost py-1 px-3 text-xs font-bold text-amber-300 border border-amber-500/40 hover:bg-gold hover:text-dark inline-flex items-center gap-1.5 transition-all shadow-sm" title="Expand to Fullscreen Focus Editor">
              <span>⛶</span> <span>Expand Editor</span>
            </button>
            <button type="button" onclick="toggleCodeView()" id="codeViewBtn" class="btn-ghost py-1 px-3 text-xs font-mono text-gold border border-gold/40 hover:bg-gold/10 inline-flex items-center gap-1">
              <span>&lt;/&gt;</span> <span id="codeViewBtnText">HTML View</span>
            </button>
          </div>
        </div>

        <!-- Full Rich Formatting Toolbar -->
        <div id="editorToolbar" class="flex flex-wrap items-center gap-1.5 p-2.5 bg-[#07070B] rounded-xl border border-[#1E1E2E] text-xs">
          <div class="flex items-center gap-1 bg-[#161622] p-1 rounded-lg border border-[#2A2A3A]">
            <select id="editorHeadingSelect" onchange="EstateEditor.applyHeading(this.value)" class="form-select text-xs py-1 px-2.5 font-bold bg-[#0D0D14] text-gold border-[#3A3A4E] rounded-md">
              <option value="p">Paragraph (Normal Text)</option>
              <option value="h1">Heading 1 (H1 - Main Title)</option>
              <option value="h2">Heading 2 (H2 - Main Section)</option>
              <option value="h3">Heading 3 (H3 - Sub-Section)</option>
              <option value="h4">Heading 4 (H4 - Minor Topic)</option>
              <option value="h5">Heading 5 (H5)</option>
              <option value="h6">Heading 6 (H6)</option>
            </select>
            <span id="editorActiveBlockBadge" class="px-2 py-0.5 rounded bg-gold/20 text-gold border border-gold/40 font-mono font-black text-[11px]">P</span>
            <span class="w-[1px] h-4 bg-[#2A2A3A] mx-0.5"></span>
            <button type="button" onclick="EstateEditor.applyHeading('h1')" class="px-2 py-1 rounded bg-[#0D0D14] hover:bg-gold hover:text-dark font-black text-xs text-white border border-[#2A2A3A]" title="Quick Apply Heading 1">H1</button>
            <button type="button" onclick="EstateEditor.applyHeading('h2')" class="px-2 py-1 rounded bg-[#0D0D14] hover:bg-gold hover:text-dark font-black text-xs text-gold border border-gold/40" title="Quick Apply Heading 2">H2</button>
            <button type="button" onclick="EstateEditor.applyHeading('h3')" class="px-2 py-1 rounded bg-[#0D0D14] hover:bg-gold hover:text-dark font-black text-xs text-amber-300 border border-amber-500/30" title="Quick Apply Heading 3">H3</button>
            <button type="button" onclick="EstateEditor.applyHeading('p')" class="px-2 py-1 rounded bg-[#0D0D14] hover:bg-gold hover:text-dark font-bold text-xs text-gray-300 border border-[#2A2A3A]" title="Quick Apply Normal Paragraph">P</button>
          </div>

          <span class="w-[1px] h-5 bg-[#2A2A3A] mx-1"></span>

          <button type="button" onclick="EstateEditor.execCmd('bold')" class="p-1.5 px-2.5 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg font-bold" title="Bold (Ctrl+B)"><strong>B</strong></button>
          <button type="button" onclick="EstateEditor.execCmd('italic')" class="p-1.5 px-2.5 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg italic" title="Italic (Ctrl+I)"><em>I</em></button>
          <button type="button" onclick="EstateEditor.execCmd('underline')" class="p-1.5 px-2.5 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg underline" title="Underline (Ctrl+U)"><u>U</u></button>
          <button type="button" onclick="EstateEditor.execCmd('strikeThrough')" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg line-through" title="Strikethrough"><s>S</s></button>
          <button type="button" onclick="EstateEditor.execCmd('removeFormat')" class="p-1.5 px-2 bg-[#161622] hover:bg-red-500 hover:text-white rounded-lg" title="Clear Formatting">🧹</button>

          <span class="w-[1px] h-5 bg-[#2A2A3A] mx-1"></span>

          <button type="button" onclick="EstateEditor.execCmd('justifyLeft')" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Align Left">⬅️</button>
          <button type="button" onclick="EstateEditor.execCmd('justifyCenter')" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Align Center">↔️</button>
          <button type="button" onclick="EstateEditor.execCmd('justifyRight')" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Align Right">➡️</button>

          <span class="w-[1px] h-5 bg-[#2A2A3A] mx-1"></span>

          <button type="button" onclick="EstateEditor.execCmd('insertUnorderedList')" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Bullet List">• List</button>
          <button type="button" onclick="EstateEditor.execCmd('insertOrderedList')" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Numbered List">1. List</button>

          <span class="w-[1px] h-5 bg-[#2A2A3A] mx-1"></span>

          <button type="button" onclick="EstateEditor.openLinkModal()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg text-blue-400 font-bold" title="Insert Link">🔗 Link</button>
          <button type="button" onclick="EstateEditor.openImageModal()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Insert Image with Alt Text">🖼️ Image</button>
          <button type="button" onclick="EstateEditor.openVideoModal()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Embed YouTube/Video">🎥 Video</button>
          <button type="button" onclick="EstateEditor.openRawHtmlModal()" class="p-1.5 px-2.5 bg-[#161622] hover:bg-emerald-500 hover:text-dark rounded-lg text-emerald-400 font-mono font-black border border-emerald-500/40 shadow-sm" title="Insert Custom HTML Embed or Schema Markup">&lt;/&gt; Code / Schema</button>
          <button type="button" onclick="EstateEditor.openTableModal()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg font-bold" title="Insert Table">📊 Table</button>
          <button type="button" onclick="EstateEditor.insertBlockquote()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Insert Blockquote">❝ Quote</button>
          <button type="button" onclick="EstateEditor.insertCalloutBox()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg text-amber-400 font-bold" title="Callout Tip Box">💡 Callout</button>
          <button type="button" onclick="EstateEditor.insertHorizontalRule()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Horizontal Divider">➖ Divider</button>
          <button type="button" onclick="EstateEditor.openCtaModal()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg text-gold font-bold" title="Insert Gold CTA Button">🔘 Button</button>
          <span class="w-[1px] h-5 bg-[#2A2A3A] mx-1"></span>
          <button type="button" onclick="EstateEditor.insertComparisonGrid()" class="p-1.5 px-3 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg text-emerald-400 font-bold border border-emerald-500/30 flex items-center gap-1 shadow-sm" title="Insert 2-Column Comparison Grid (Traditional vs Estate HDR)">
            <span>📊</span> <span>Comparison Grid</span>
          </button>
          <button type="button" onclick="EstateEditor.insertCtaBox()" class="p-1.5 px-3 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg text-gold font-bold border border-gold/40 flex items-center gap-1 shadow-sm" title="Insert 24h Turnaround Call-to-Action Banner Box">
            <span>📢</span> <span>CTA Banner</span>
          </button>
        </div>

        <?php
          // User requested totally blank body section for new posts (no demo text or auto-injected cards)
          $loadedContent = $post['content'] ?? '';
        ?>
        <!-- Live Visual Contenteditable Surface (Populated via JS to isolate internal DOM) -->
        <div id="editorVisual" contenteditable="true" class="form-input text-sm p-4 rounded-xl border border-[#1E1E2E] bg-[#07070B] min-h-[380px] focus:ring-1 focus:ring-gold" oninput="EstateEditor.syncVisualToTextarea()"></div>

        <!-- Raw HTML Textarea (Synced & Toggleable) -->
        <textarea id="postContent" name="content" rows="18" class="hidden form-input text-xs font-mono resize-y leading-relaxed bg-[#07070B]" 
                  placeholder="Raw HTML code..." oninput="EstateEditor.syncTextareaToVisual()"><?= htmlspecialchars($loadedContent, ENT_QUOTES, 'UTF-8') ?></textarea>
      </div>

      
      <!-- Live Readability & SEO Score Card -->
      <div class="glass-card rounded-2xl p-6 border border-emerald-500/30 shadow-xl space-y-4 bg-gradient-to-br from-[#111118] to-[#0A0A0F]">
        <div class="flex items-center justify-between border-b border-[#1E1E2E] pb-3">
          <div class="flex items-center gap-2">
            <span class="text-xl">📊</span>
            <div>
              <h3 class="text-sm font-black text-white">Content Readability &amp; SEO Health</h3>
              <p class="text-gray-400 text-xs">Real-time Flesch Reading Ease &amp; Google scanability auditor.</p>
            </div>
          </div>
          <span id="readabilityScoreDisplay" class="text-base font-mono font-black text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-xl border border-emerald-500/30">85 / 100</span>
        </div>

        <div>
          <div id="readabilityLabelDisplay" class="text-xs font-bold text-emerald-400">🟢 Good — Very Easy to Read &amp; Fast to Scan</div>
          <div id="readabilityStatsDisplay" class="text-xs font-mono text-gray-400 mt-1">Total Words: 0 | Sentences: 0 | Avg Words/Sentence: 0.0</div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
          <div class="p-3 rounded-xl bg-dark/60 border border-[#1E1E2E] flex items-center gap-2">
            <span>✅</span> <span>High Typography Contrast (95%+)</span>
          </div>
          <div class="p-3 rounded-xl bg-dark/60 border border-[#1E1E2E] flex items-center gap-2">
            <span>✅</span> <span>H1-H6 Subheading Hierarchy</span>
          </div>
          <div class="p-3 rounded-xl bg-dark/60 border border-[#1E1E2E] flex items-center gap-2">
            <span>✅</span> <span>Scannable Bullet &amp; Table Formatting</span>
          </div>
          <div class="p-3 rounded-xl bg-dark/60 border border-[#1E1E2E] flex items-center gap-2">
            <span>✅</span> <span>Mobile-Optimized Line Heights</span>
          </div>
        </div>
      </div>

      <!-- Advanced On-Page SEO Card -->
      <div class="glass-card rounded-2xl p-6 border border-gold/30 shadow-xl space-y-5 bg-gradient-to-br from-dark-card to-dark">
        <div class="border-b border-dark-border pb-3 flex items-center justify-between">
          <div>
            <h3 class="text-sm font-bold text-white flex items-center gap-2">
              <span>🚀</span> <span>Search Engine Optimization (Google / SSR Pure Indexable)</span>
            </h3>
            <p class="text-gray-400 text-xs mt-0.5">SSR pure HTML meta tags, OpenGraph social cards &amp; Structured JSON-LD schema.</p>
          </div>
          <span class="section-tag">SSR 100% Indexable</span>
        </div>

        <div>
          <div class="flex items-center justify-between mb-1">
            <label class="form-label text-xs">SEO Meta Title (Title Tag)</label>
            <span id="titleCount" class="text-xs font-mono font-bold text-gray-400">0 / 60 chars</span>
          </div>
          <input type="text" id="postMetaTitle" name="meta_title" value="<?= htmlspecialchars($post['meta_title'] ?? '') ?>" class="form-input text-sm" placeholder="e.g. 7 Real Estate Photography Trends Dominating 2026 | Estate HDR" oninput="updateCounters()">
        </div>

        <div>
          <div class="flex items-center justify-between mb-1">
            <label class="form-label text-xs">SEO Meta Description</label>
            <span id="descCount" class="text-xs font-mono font-bold text-gray-400">0 / 160 chars</span>
          </div>
          <textarea id="postMetaDesc" name="meta_description" rows="2" class="form-input text-sm resize-y" placeholder="Short description shown in Google search result snippet..." oninput="updateCounters()"><?= htmlspecialchars($post['meta_description'] ?? '') ?></textarea>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label class="form-label text-xs">Robots Meta Directive</label>
            <select name="robots" class="form-select text-xs">
              <option value="index, follow" <?= ($post['robots'] ?? '') === 'index, follow' ? 'selected' : '' ?>>index, follow (Allow Google Indexing)</option>
              <option value="noindex, follow" <?= ($post['robots'] ?? '') === 'noindex, follow' ? 'selected' : '' ?>>noindex, follow (Hide From Google)</option>
            </select>
          </div>

          <div>
            <label class="form-label text-xs">Canonical URL Override</label>
            <input type="url" name="canonical_url" value="<?= htmlspecialchars($post['canonical_url'] ?? '') ?>" class="form-input text-xs font-mono" placeholder="https://estatehdr.com/blog/...">
          </div>
        </div>

        <div class="pt-3 border-t border-dark-border flex items-center justify-between">
          <div>
            <div class="text-xs font-bold text-white">Exclude from XML Sitemap</div>
            <div class="text-xs text-gray-400">Hide this article from auto-generated sitemap.xml</div>
          </div>
          <input type="checkbox" name="exclude_sitemap" value="1" <?= !empty($post['exclude_sitemap']) ? 'checked' : '' ?> class="w-4 h-4 text-gold rounded border-dark-border bg-dark">
        </div>

        <div>
          <div class="flex flex-wrap items-center justify-between gap-2 mb-1.5">
            <label class="form-label text-xs">Custom JSON-LD Structured Data Schema</label>
            <div class="flex flex-wrap gap-1.5">
              <button type="button" onclick="insertCardSchemaTemplate('faq')" class="btn-ghost py-0.5 px-2 text-[10px] font-bold border-gold/40 text-gold hover:bg-gold/10">+ FAQ</button>
              <button type="button" onclick="insertCardSchemaTemplate('article')" class="btn-ghost py-0.5 px-2 text-[10px] font-bold border-blue-500/40 text-blue-400 hover:bg-blue-500/10">+ Article</button>
              <button type="button" onclick="insertCardSchemaTemplate('business')" class="btn-ghost py-0.5 px-2 text-[10px] font-bold border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/10">+ Agency</button>
              <button type="button" onclick="insertCardSchemaTemplate('howto')" class="btn-ghost py-0.5 px-2 text-[10px] font-bold border-purple-500/40 text-purple-400 hover:bg-purple-500/10">+ How-To</button>
            </div>
          </div>
          <textarea id="postSchemaJson" name="schema_json" rows="4" class="form-input text-xs font-mono text-amber-300 resize-y" placeholder='{
  "@context": "https://schema.org",
  "@type": "BlogPosting",
  "headline": "Post Title"
}'><?= htmlspecialchars($post['schema_json'] ?? '') ?></textarea>
          <p class="text-[11px] text-gray-500 mt-1">💡 Click any template above to auto-generate valid JSON-LD schema with post title &amp; author.</p>
        </div>
      </div>

    </div>

    <!-- RIGHT COLUMN: SIDEBAR & PUBLISHING (4 OF 12 COLS - NEVER SQUISHES) -->
    <div class="lg:col-span-4 xl:col-span-4 w-full min-w-0 space-y-6">
      
      <!-- 1. Featured Image & Social OG Card (TOP OF SIDEBAR - 1-CLICK REPLACE) -->
      <div class="glass-card rounded-2xl p-6 border border-gold/40 shadow-xl space-y-4 bg-[#111118]">
        <div class="flex items-center justify-between border-b border-dark-border pb-2">
          <div class="flex items-center gap-2">
            <span class="text-base">📸</span>
            <h3 class="text-xs font-bold text-white uppercase tracking-wider">Featured Cover Image</h3>
          </div>
          <span class="text-[10px] text-gold font-mono font-bold bg-gold/10 px-2 py-0.5 rounded border border-gold/30">16:9 HD</span>
        </div>
        
        <!-- Auto-Fit Live Cover Preview (Shows true 1200x628 or any aspect ratio without cropping) -->
        <div class="relative rounded-xl overflow-hidden border border-dark-border bg-dark/80 aspect-[16/9] shadow-inner flex items-center justify-center p-1">
          <img id="coverPreview" src="<?= htmlspecialchars($post['featured_image'] ?? '') ?>" alt="Cover Preview" class="<?= empty($post['featured_image']) ? 'hidden' : '' ?> w-full h-full object-contain">
          <div id="coverPlaceholder" class="<?= !empty($post['featured_image']) ? 'hidden' : '' ?> text-center p-4 text-gray-500 text-xs">
            <span class="text-2xl block mb-1">🖼️</span>
            <span>No featured image selected</span>
          </div>
        </div>

        <!-- Clean Action Buttons (Upload from PC or Choose from Server Gallery) -->
        <div class="grid grid-cols-2 gap-2.5">
          <button type="button" onclick="triggerDirectCoverUpload(event)" class="btn-gold py-2.5 px-3 text-xs font-black text-center inline-flex items-center justify-center gap-1.5 shadow-glow">
            <span>📁</span> <span>Upload Image</span>
          </button>
          <button type="button" onclick="openServerGalleryModal('cover')" class="btn-ghost py-2.5 px-3 text-xs font-bold text-center text-gray-200 hover:text-white border-[#2A2A3A] hover:border-gold inline-flex items-center justify-center gap-1.5">
            <span>🖼️</span> <span>Choose from Gallery</span>
          </button>
        </div>

        <!-- Native File Input (Off-screen accessible, never display:none so .click() works universally) -->
        <input type="file" id="featuredImgFileInput" accept="image/*" style="position: absolute; left: -9999px; top: -9999px; width: 1px; height: 1px; opacity: 0; pointer-events: none;" tabindex="-1" aria-hidden="true">

        <!-- Compact Drag & Drop Zone -->
        <div id="featuredImgDropzone" class="border-2 border-dashed border-[#2A2A3A] hover:border-gold rounded-xl p-3 text-center cursor-pointer transition-colors bg-dark/60">
          <div class="font-bold text-white text-xs mb-0.5">Or drag &amp; drop image here</div>
          <div class="text-[10px] text-gray-400">JPG, PNG, WebP • Auto-saved to storage</div>
        </div>

        <div id="featuredImgUploadProgress" class="hidden text-center py-1">
          <div class="inline-flex items-center gap-2 text-gold font-mono text-xs">
            <span class="animate-spin text-sm">⏳</span> Uploading image...
          </div>
        </div>

        <!-- Image Path Input & Custom Name -->
        <div class="space-y-3 pt-2 border-t border-[#1E1E2E]">
          <div>
            <div class="flex items-center justify-between mb-1">
              <label class="form-label text-xs mb-0">Image Path / URL</label>
              <button type="button" onclick="setCoverImage('')" class="text-[10px] text-gray-500 hover:text-red-400 font-mono">Remove Image</button>
            </div>
            <input type="text" id="featuredImgInput" name="featured_image" value="<?= htmlspecialchars($post['featured_image'] ?? '') ?>" class="form-input text-xs font-mono" placeholder="/assets/images/blog/your-image.jpg" oninput="updateCoverPreview()">
          </div>
          <div>
            <label class="form-label text-xs mb-1">Custom File Name Slug (Optional)</label>
            <input type="text" id="featuredImgCustomName" class="form-input text-xs font-mono" placeholder="e.g. ai-virtual-staging-furniture">
          </div>
        </div>
      </div>

      <!-- 2. Publishing Controls Card -->
      <div class="glass-card rounded-2xl p-6 border border-dark-border shadow-xl space-y-4 bg-[#111118]">
        <div class="flex items-center justify-between border-b border-dark-border pb-2">
          <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider">Publishing Status</h3>
          <span id="sidebarStatusBadge" class="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider <?= ($post['status'] ?? '') === 'draft' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : (($post['status'] ?? '') === 'scheduled' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30') ?>">
            <?= ($post['status'] ?? '') === 'draft' ? 'Draft' : (($post['status'] ?? '') === 'scheduled' ? 'Scheduled' : 'Live') ?>
          </span>
        </div>

        <div>
          <label class="form-label text-xs">Status</label>
          <select name="status_select" id="postStatusSelect" class="form-select text-sm" onchange="updatePublishingState(this.value)">
            <option value="published" <?= ($post['status'] ?? '') === 'published' ? 'selected' : '' ?>>Published (Live Immediately)</option>
            <option value="draft" <?= ($post['status'] ?? '') === 'draft' ? 'selected' : '' ?>>Draft (Saved Privately)</option>
            <option value="scheduled" <?= ($post['status'] ?? '') === 'scheduled' ? 'selected' : '' ?>>Scheduled (Future Release)</option>
          </select>
        </div>

        <div id="scheduledBox" class="<?= ($post['status'] ?? '') === 'scheduled' ? '' : 'hidden' ?>">
          <label class="form-label text-xs">Publish Date &amp; Time</label>
          <input type="datetime-local" name="scheduled_at" value="<?= htmlspecialchars($post['scheduled_at'] ?? '') ?>" class="form-input text-xs font-mono">
        </div>

        <?php
          $defaultAuthorVal = $isSeniorSeo ? 'Estate HDR Team' : ($currentAdmin['name'] ?? 'SEO & Content Manager');
          $currentAuthorVal = $post['author'] ?? $defaultAuthorVal;
        ?>
        <div>
          <div class="flex items-center justify-between mb-1">
            <label class="form-label text-xs mb-0">Author Name</label>
            <div class="flex items-center gap-2">
              <button type="button" onclick="document.getElementById('postAuthorInput').value='Estate HDR Team'" class="text-[10px] text-gold hover:underline font-mono">Team Name</button>
              <?php if (!empty($currentAdmin['name']) && !$isSeniorSeo): ?>
                <button type="button" onclick="document.getElementById('postAuthorInput').value=<?= json_encode($currentAdmin['name']) ?>" class="text-[10px] text-emerald-400 hover:underline font-mono">My Name (<?= htmlspecialchars($currentAdmin['name']) ?>)</button>
              <?php endif; ?>
            </div>
          </div>
          <input type="text" id="postAuthorInput" name="author" value="<?= htmlspecialchars($currentAuthorVal) ?>" class="form-input text-xs" placeholder="e.g. <?= htmlspecialchars($currentAdmin['name'] ?? 'Author Name') ?> or Estate HDR Team">
          <p class="text-[10px] text-gray-500 mt-1">
            <?= $isSeniorSeo ? 'Senior SEO articles automatically use <strong class="text-gold">Estate HDR Team</strong>.' : 'Your personal author name will be displayed on this blog post.' ?>
          </p>
        </div>

        <div>
          <label class="form-label text-xs">Estimated Read Time</label>
          <input type="text" name="read_time" value="<?= htmlspecialchars($post['read_time'] ?? '5 min read') ?>" class="form-input text-xs" placeholder="e.g. 4 min read">
        </div>
      </div>

      <!-- 3. Categories & Taxonomy Card -->
      <div class="glass-card rounded-2xl p-6 border border-dark-border shadow-xl space-y-4 bg-[#111118]">
        <div class="flex items-center justify-between border-b border-dark-border pb-2">
          <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider">Category &amp; Taxonomy</h3>
          <a href="/admin/categories.php?tab=post" target="_blank" class="text-[11px] text-gold hover:underline font-bold">Manage ↗</a>
        </div>

        <div>
          <label class="form-label text-xs">Primary Category</label>
          <select name="category" id="postCategorySelect" class="form-select text-sm">
            <?php foreach ($postCategories as $c): ?>
              <option value="<?= htmlspecialchars($c['name']) ?>" <?= ($post['category'] ?? '') === $c['name'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($c['name']) ?>
              </option>
            <?php endforeach; ?>
            <?php if (empty($postCategories)): ?>
              <option value="HDR Photo Editing">HDR Photo Editing</option>
              <option value="Virtual Staging">Virtual Staging</option>
              <option value="Drone &amp; Aerial">Drone &amp; Aerial</option>
            <?php endif; ?>
          </select>
        </div>

        <!-- Quick Add Custom Category -->
        <div class="pt-2 border-t border-[#1E1E2E]">
          <div id="quickAddCatBox" class="hidden space-y-2">
            <input type="text" id="quickCatName" class="form-input text-xs" placeholder="New blog category name...">
            <div class="flex gap-2">
              <button type="button" onclick="quickAddPostCategory()" class="btn-gold py-1.5 px-3 text-xs font-bold flex-1">Add Category</button>
              <button type="button" onclick="document.getElementById('quickAddCatBox').classList.add('hidden')" class="btn-ghost py-1.5 px-2 text-xs">Cancel</button>
            </div>
          </div>
          <button type="button" onclick="document.getElementById('quickAddCatBox').classList.toggle('hidden')" class="text-xs font-bold text-gold hover:underline inline-flex items-center gap-1 mt-1">
            <span>+</span> <span>Add Custom Category</span>
          </button>
        </div>

        <div>
          <label class="form-label text-xs">Tags <span class="text-gray-400 font-normal">(Press comma <kbd class="text-gold font-mono bg-dark px-1 rounded border border-gold/30">,</kbd> or Enter to add)</span></label>
          <?php
          $tagsDisplay = '';
          if (isset($post['tags'])) {
              $tagsDisplay = is_array($post['tags']) ? implode(', ', $post['tags']) : (string)$post['tags'];
          }
          ?>
          <input type="hidden" name="tags" id="postTagsHidden" value="<?= htmlspecialchars($tagsDisplay) ?>">
          <div id="tagPillsWrapper" onclick="document.getElementById('tagInputBox').focus()" class="form-input min-h-[46px] p-2 flex flex-wrap items-center gap-1.5 cursor-text bg-[#0A0A0F] border border-[#1E1E2E] rounded-xl focus-within:border-gold transition-colors">
            <div id="tagPillsList" class="flex flex-wrap items-center gap-1.5"></div>
            <input type="text" id="tagInputBox" class="bg-transparent text-xs text-white outline-none flex-1 min-w-[130px] p-1 placeholder-gray-500" placeholder="Type tag & comma...">
          </div>
          <p class="text-[10px] text-gray-500 mt-1">Example: real estate, hdr photography, staging (instant badge on comma)</p>
        </div>

        <!-- Sidebar Quick Action Buttons -->
        <div class="pt-4 border-t border-[#1E1E2E] flex flex-col gap-2.5">
          <button type="button" onclick="submitAs('published')" class="btn-gold w-full py-3 text-xs font-black shadow-glow inline-flex items-center justify-center gap-2">
            <span>🚀</span> <span><?= $isEditing ? 'Update & Publish' : 'Publish Article' ?></span>
          </button>
          <div class="grid grid-cols-2 gap-2">
            <button type="button" onclick="submitAs('draft')" class="btn-ghost py-2 text-xs font-bold text-gray-300 border-[#2A2A3A] hover:border-gold inline-flex items-center justify-center gap-1.5">
              <span>💾</span> <span>Save Draft</span>
            </button>
            <button type="button" onclick="EstateEditor.openLivePreview('post')" class="btn-ghost py-2 text-xs font-bold text-gold border-gold/40 hover:bg-gold/10 inline-flex items-center justify-center gap-1.5">
              <span>👁️</span> <span>Live Preview</span>
            </button>
          </div>
        </div>
      </div>

    </div>
  </form>

  <!-- SERVER MEDIA GALLERY MODAL (Scans Blog Folder & Server Media) -->
  <div id="serverGalleryModal" class="fixed inset-0 z-[10000] hidden bg-black/80 backdrop-blur-sm flex items-center justify-center p-4" style="display: none;" onclick="if(event.target===this)closeServerGalleryModal()">
    <div class="bg-[#111118] border border-gold/40 rounded-2xl w-full max-w-5xl p-6 shadow-2xl space-y-4 max-h-[90vh] flex flex-col">
      <div class="flex items-center justify-between border-b border-[#1E1E2E] pb-3">
        <div class="flex items-center gap-2.5">
          <span class="text-2xl">🖼️</span>
          <div>
            <h3 class="text-base font-black text-white">Server Media Gallery</h3>
            <p class="text-xs text-gray-400">All photos from your server's <span class="text-gold font-bold">/assets/images/blog/</span> folder, uploads, and studio library</p>
          </div>
        </div>
        <button type="button" onclick="closeServerGalleryModal()" class="text-gray-400 hover:text-white font-bold text-2xl px-2">&times;</button>
      </div>

      <!-- Filter Tabs & Search Bar -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#1E1E2E] pb-3">
        <div class="flex flex-wrap gap-2 text-xs" id="galleryFilterTabs">
          <button type="button" onclick="filterServerGallery('blog')" class="gallery-tab-btn py-1.5 px-3.5 rounded-lg font-bold bg-gold text-dark transition-all" data-folder="blog">📁 Blog Folder (<?= $blogImagesCount ?>)</button>
          <button type="button" onclick="filterServerGallery('all')" class="gallery-tab-btn py-1.5 px-3.5 rounded-lg font-bold text-gray-300 hover:text-white bg-dark border border-[#1E1E2E] transition-all" data-folder="all">🌟 All Images (<?= $totalImagesCount ?>)</button>
          <button type="button" onclick="filterServerGallery('uploads')" class="gallery-tab-btn py-1.5 px-3.5 rounded-lg font-bold text-gray-300 hover:text-white bg-dark border border-[#1E1E2E] transition-all" data-folder="uploads">📤 Uploads (<?= $uploadsImagesCount ?>)</button>
          <button type="button" onclick="filterServerGallery('portfolio')" class="gallery-tab-btn py-1.5 px-3.5 rounded-lg font-bold text-gray-300 hover:text-white bg-dark border border-[#1E1E2E] transition-all" data-folder="portfolio">🛋️ Studio Portfolio (<?= $portfolioImagesCount ?>)</button>
        </div>
        <div class="relative w-full sm:w-64">
          <input type="text" id="gallerySearchInput" placeholder="Filter by name..." oninput="searchServerGallery(this.value)" class="form-input text-xs py-1.5 px-3 pr-8 w-full bg-dark/80 border-[#2A2A3A] rounded-lg text-white placeholder-gray-500">
          <span class="absolute right-2.5 top-2 text-xs text-gray-500">🔍</span>
        </div>
      </div>

      <!-- Gallery Grid -->
      <div class="flex-1 overflow-y-auto pr-1 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3.5 py-2 min-h-[340px]" id="galleryImageGrid">
        <!-- Rendered via JS -->
      </div>

      <div class="pt-3 border-t border-[#1E1E2E] flex items-center justify-between">
        <span class="text-xs text-gray-500 font-mono">⚡ 1-click select • Sets Cover &amp; previews instantly in 16:9 HD</span>
        <div class="flex items-center gap-2">
          <button type="button" onclick="triggerDirectCoverUpload(event); closeServerGalleryModal();" class="btn-gold py-1.5 px-3.5 text-xs font-bold shadow-sm inline-flex items-center gap-1">
            <span>📁</span> <span>Upload New from PC</span>
          </button>
          <button type="button" onclick="closeServerGalleryModal()" class="btn-ghost py-1.5 px-4 text-xs font-bold border-[#2A2A3A]">Close</button>
        </div>
      </div>
    </div>
  </div>
  <div id="studioGalleryModal" style="display:none;" class="hidden"></div>

</main>

<script src="/assets/js/editor-pro.js?v=<?= file_exists(ROOT_PATH . '/assets/js/editor-pro.js') ? filemtime(ROOT_PATH . '/assets/js/editor-pro.js') : time() ?>"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
// ── Global Local-Draft Storage Key ──
const CURRENT_POST_ID = '<?= htmlspecialchars($post['id'] ?? 'new', ENT_QUOTES, 'UTF-8') ?>';
const DRAFT_STORAGE_KEY = 'estatehdr_draft_post_' + CURRENT_POST_ID;
let isFormSubmitting = false;
let autoSaveTimer = null;
let lastAutoSaveTime = null;

// ── Save Current Form State to LocalStorage (Crash / Nav Prevention) ──
function saveDraftToLocalStorage() {
  if (isFormSubmitting) return;

  const title = (document.getElementById('postTitle')?.value || '').trim();
  const slug = (document.getElementById('postSlug')?.value || '').trim();
  const excerpt = (document.getElementById('postExcerpt')?.value || '').trim();
  
  // Extract content from visual editor or textarea
  let content = '';
  const code = document.getElementById('postContent');
  const visual = document.getElementById('editorVisual');
  if (code && !code.classList.contains('hidden')) {
    content = code.value || '';
  } else if (visual) {
    content = visual.innerHTML || '';
  }

  // Only store if there's actual content or title written
  if (!title && !content) return;

  const draftData = {
    postId: CURRENT_POST_ID,
    title: title,
    slug: slug,
    excerpt: excerpt,
    content: content,
    category: document.getElementById('postCategorySelect')?.value || '',
    tags: (window.EstateTags && Array.isArray(EstateTags.tags)) ? EstateTags.tags.join(', ') : (document.getElementById('postTagsHidden')?.value || ''),
    featured_image: document.getElementById('featuredImgInput')?.value || '',
    author: document.querySelector('input[name="author"]')?.value || '',
    status: document.getElementById('formStatus')?.value || 'published',
    meta_title: document.getElementById('postMetaTitle')?.value || '',
    meta_description: document.getElementById('postMetaDesc')?.value || '',
    canonical_url: document.getElementById('postCanonicalUrl')?.value || '',
    robots: document.getElementById('postRobots')?.value || 'index, follow',
    schema_json: document.getElementById('postSchemaJson')?.value || '',
    savedAt: Date.now()
  };

  try {
    localStorage.setItem(DRAFT_STORAGE_KEY, JSON.stringify(draftData));
    lastAutoSaveTime = new Date();
    const statusText = document.getElementById('autoSaveStatusText');
    const dot = document.getElementById('autoSaveIndicatorDot');
    if (statusText) {
      statusText.textContent = `Auto-saved locally at ${lastAutoSaveTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`;
    }
    if (dot) {
      dot.classList.remove('bg-gray-500');
      dot.classList.add('bg-emerald-400');
    }
  } catch (e) {
    console.warn('LocalStorage save error:', e);
  }
}

// ── Check & Prompt for Local Draft Recovery on Load ──
function checkAndPromptLocalDraft() {
  try {
    const raw = localStorage.getItem(DRAFT_STORAGE_KEY);
    if (!raw) return;
    const draft = JSON.parse(raw);
    if (!draft || (!draft.title && !draft.content)) return;

    const visual = document.getElementById('editorVisual');
    const currentHtml = (visual ? visual.innerHTML.trim() : '');
    const currentTitle = (document.getElementById('postTitle')?.value || '').trim();

    // If editor has literally nothing (like when user hit Back button after 403), auto-restore immediately!
    const isEditorEmpty = (!currentTitle && (!currentHtml || currentHtml === '<p><br></p>' || currentHtml === '<p></p>' || currentHtml === '<br>'));

    if (isEditorEmpty) {
      restoreLocalDraft(true); // silent auto-restore
      return;
    }

    // Otherwise, if draft exists and has content, show recovery banner
    const banner = document.getElementById('draftRecoveryBanner');
    const timeDisplay = document.getElementById('draftTimeDisplay');
    if (banner && timeDisplay && draft.savedAt) {
      const d = new Date(draft.savedAt);
      timeDisplay.textContent = d.toLocaleString();
      banner.classList.remove('hidden');
    }
  } catch (e) {
    console.warn('Draft check error:', e);
  }
}

// ── Restore Draft into Form & Editor ──
function restoreLocalDraft(silent = false) {
  try {
    const raw = localStorage.getItem(DRAFT_STORAGE_KEY);
    if (!raw) return;
    const draft = JSON.parse(raw);
    if (!draft) return;

    if (draft.title && document.getElementById('postTitle')) {
      document.getElementById('postTitle').value = draft.title;
    }
    if (draft.slug && document.getElementById('postSlug')) {
      document.getElementById('postSlug').value = draft.slug;
      updateSlugPreview();
    }
    if (draft.excerpt && document.getElementById('postExcerpt')) {
      document.getElementById('postExcerpt').value = draft.excerpt;
    }
    if (draft.content) {
      const visual = document.getElementById('editorVisual');
      const textarea = document.getElementById('postContent');
      if (visual) visual.innerHTML = draft.content;
      if (textarea) textarea.value = draft.content;
    }
    if (draft.category && document.getElementById('postCategorySelect')) {
      document.getElementById('postCategorySelect').value = draft.category;
    }
    if (draft.tags && window.EstateTags) {
      EstateTags.tags = draft.tags.split(',').map(t => t.trim()).filter(Boolean);
      EstateTags.sync();
      EstateTags.render();
    }
    if (draft.featured_image && typeof setCoverImage === 'function') {
      setCoverImage(draft.featured_image);
    }
    if (draft.meta_title && document.getElementById('postMetaTitle')) {
      document.getElementById('postMetaTitle').value = draft.meta_title;
    }
    if (draft.meta_description && document.getElementById('postMetaDesc')) {
      document.getElementById('postMetaDesc').value = draft.meta_description;
    }
    if (draft.canonical_url && document.getElementById('postCanonicalUrl')) {
      document.getElementById('postCanonicalUrl').value = draft.canonical_url;
    }
    if (draft.schema_json && document.getElementById('postSchemaJson')) {
      document.getElementById('postSchemaJson').value = draft.schema_json;
    }
    if (draft.status && typeof updatePublishingState === 'function') {
      updatePublishingState(draft.status);
    }

    updateCounters();
    runReadabilityAudit();

    // Hide banner
    const banner = document.getElementById('draftRecoveryBanner');
    if (banner) banner.classList.add('hidden');

    if (!silent) {
      if (window.EstateDialog) {
        EstateDialog.toast('✨ Unsaved draft successfully restored!', 'success');
      } else {
        alert('Unsaved draft successfully restored!');
      }
    }
  } catch (e) {
    console.error('Failed to restore draft:', e);
  }
}

// ── Discard Local Draft ──
function dismissLocalDraft() {
  EstateDialog.confirm('Discard this local draft backup? Your current editor screen will remain unchanged.', 'Discard Draft Backup', {
    icon: '🗑️',
    confirmText: 'Discard Draft',
    danger: true
  }).then(function(confirmed) {
    if (!confirmed) return;
    try {
      localStorage.removeItem(DRAFT_STORAGE_KEY);
    } catch (e) {}
    const banner = document.getElementById('draftRecoveryBanner');
    if (banner) banner.classList.add('hidden');
    EstateDialog.toast('Draft backup discarded.', 'info');
  });
}

// ── Clear Local Draft on Confirmed Server Save ──
function clearLocalDraft() {
  try {
    localStorage.removeItem(DRAFT_STORAGE_KEY);
  } catch (e) {}
  const banner = document.getElementById('draftRecoveryBanner');
  if (banner) banner.classList.add('hidden');
}

// ── Update All CSRF Tokens in Form ──
function updateFormCsrfTokens(newToken) {
  if (!newToken) return;
  window.CSRF_TOKEN = newToken;
  document.querySelectorAll('input[name="csrf_token"]').forEach(el => {
    el.value = newToken;
  });
  const meta = document.querySelector('meta[name="csrf-token"]');
  if (meta) meta.setAttribute('content', newToken);
}

// ── Session Keep-Alive Heartbeat ──
function pingSessionHeartbeat() {
  return fetch('/api/session-ping.php')
    .then(r => r.json())
    .then(data => {
      if (data && data.csrf_token) {
        updateFormCsrfTokens(data.csrf_token);
      }
      const hb = document.getElementById('heartbeatStatusText');
      if (hb && data.ok) {
        hb.innerHTML = `<span class="text-emerald-400 font-bold">●</span> <span>Session Active (${data.user || 'Admin'})</span>`;
      }
      return data;
    })
    .catch(err => {
      console.warn('Session ping error:', err);
    });
}

// ── Fail-Safe Zero-Data-Loss Form Submission (AJAX + WAF Bypass) ──
async function submitAs(status) {
  if (isFormSubmitting) return;

  const topBtn = document.getElementById('topSubmitBtn');
  const topBtnText = document.getElementById('topSubmitBtnText');
  const originalText = topBtnText ? topBtnText.innerHTML : 'Publish Article';

  // 1. Update publishing status
  document.getElementById('formStatus').value = status;
  if (document.getElementById('postStatusSelect')) {
    document.getElementById('postStatusSelect').value = status;
  }
  updatePublishingState(status);

  // 2. Sync visual contenteditable to textarea
  const code = document.getElementById('postContent');
  if (code && !code.classList.contains('hidden')) {
    EstateEditor.syncTextareaToVisual();
  } else {
    EstateEditor.syncVisualToTextarea();
  }

  // 3. Validate required title
  const titleVal = (document.getElementById('postTitle')?.value || '').trim();
  if (!titleVal) {
    if (window.EstateDialog) {
      EstateDialog.alert('Please enter an Article Title before saving or publishing.', 'Missing Title');
    } else {
      alert('Please enter an Article Title before saving or publishing.');
    }
    document.getElementById('postTitle')?.focus();
    return;
  }

  // 4. Force immediate LocalStorage backup before network dispatch
  saveDraftToLocalStorage();

  // 5. Lock UI & show saving indicator
  isFormSubmitting = true;
  if (topBtn) {
    topBtn.disabled = true;
    topBtn.classList.add('opacity-75', 'cursor-not-allowed');
  }
  if (topBtnText) {
    topBtnText.innerHTML = `<span class="inline-block animate-spin mr-1">⏳</span> Saving...`;
  }

  const form = document.getElementById('postForm');
  const formData = new FormData(form);
  formData.append('ajax_save', '1');

  // WAF & ModSecurity Safe Encoding:
  // Base64 encode HTML content and schema to completely bypass Hostinger ModSecurity XSS/SQLi false-positives
  const rawContent = formData.get('content') || '';
  const rawSchema = formData.get('schema_json') || '';
  try {
    formData.set('content_b64', btoa(unescape(encodeURIComponent(rawContent))));
    formData.delete('content'); // Remove plaintext HTML so WAF cannot inspect/block it
  } catch (e) {
    console.warn('content b64 error:', e);
  }
  try {
    if (rawSchema) {
      formData.set('schema_json_b64', btoa(unescape(encodeURIComponent(rawSchema))));
      formData.delete('schema_json');
    }
  } catch (e) {
    console.warn('schema b64 error:', e);
  }

  // Ensure fresh CSRF token
  if (window.CSRF_TOKEN) {
    formData.set('csrf_token', window.CSRF_TOKEN);
  }

  try {
    const postUrl = window.location.href;
    let resp = await fetch(postUrl, {
      method: 'POST',
      headers: {
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRF-TOKEN': window.CSRF_TOKEN || ''
      },
      body: formData
    });

    // If server returned 403 or server error, DO NOT NAVIGATE! Stay on page!
    if (!resp.ok) {
      console.warn('POST response error: HTTP ' + resp.status + '. Attempting session renewal & JSON fallback...');
      
      // Ping session heartbeat to renew CSRF token
      const ping = await pingSessionHeartbeat();
      const freshCsrf = ping?.csrf_token || window.CSRF_TOKEN;

      // Prepare JSON payload (ModSecurity CRS filters often allow application/json while blocking form-data)
      const jsonPayload = {};
      formData.forEach((val, key) => { jsonPayload[key] = val; });
      jsonPayload['csrf_token'] = freshCsrf;

      resp = await fetch(postUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest',
          'X-CSRF-TOKEN': freshCsrf || ''
        },
        body: JSON.stringify(jsonPayload)
      });
    }

    if (!resp.ok) {
      throw new Error(`Server returned HTTP ${resp.status} (Security / WAF check). Your article is 100% SAFE and saved in local draft recovery.`);
    }

    const data = await resp.json();

    if (data.success) {
      // Clear local draft only on verified server save
      clearLocalDraft();

      if (data.csrf_token) {
        updateFormCsrfTokens(data.csrf_token);
      }

      if (window.EstateDialog) {
        EstateDialog.toast(data.message || 'Article saved successfully!', 'success');
      }

      // Smooth redirect
      setTimeout(() => {
        window.location.href = data.redirect || '/admin/posts.php';
      }, 700);

    } else if (data.code === 'CSRF_EXPIRED' && data.new_csrf_token) {
      // Auto-renewed token, retry once seamlessly
      updateFormCsrfTokens(data.new_csrf_token);
      if (topBtnText) topBtnText.innerHTML = `Renewed Session. Saving...`;
      isFormSubmitting = false;
      setTimeout(() => submitAs(status), 400);

    } else {
      throw new Error(data.error || 'Server reported an error saving article.');
    }

  } catch (err) {
    console.error('Save failed:', err);
    isFormSubmitting = false;

    if (topBtn) {
      topBtn.disabled = false;
      topBtn.classList.remove('opacity-75', 'cursor-not-allowed');
    }
    if (topBtnText) {
      topBtnText.innerHTML = originalText;
    }

    // Prominently reassure the author that NO CONTENT WAS LOST
    const safeMsg = `
      <div class="space-y-3">
        <p class="text-sm text-red-300 font-bold">${err.message}</p>
        <div class="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-xs text-emerald-200">
          <strong class="text-emerald-400 block mb-1">🛡️ Article Content Protected:</strong>
          None of your written words were lost. Everything is preserved in this editor and backed up in your browser. You can click <strong>Save as Draft</strong> or <strong>Publish</strong> again.
        </div>
      </div>
    `;

    if (window.EstateDialog) {
      EstateDialog.alert(safeMsg, '⚠️ Save Notice (Content Preserved)');
    } else {
      alert('Save Notice: ' + err.message + '\n\nDon\'t worry: Your article content is 100% safe in the editor!');
    }
  }
}

function submitCurrentForm() {
  submitAs(document.getElementById('formStatus')?.value || 'published');
}

function updatePublishingState(status) {
  document.getElementById('formStatus').value = status;
  const badge = document.getElementById('sidebarStatusBadge');
  const topBtnText = document.getElementById('topSubmitBtnText');
  const scheduledBox = document.getElementById('scheduledBox');

  if (scheduledBox) {
    scheduledBox.classList.toggle('hidden', status !== 'scheduled');
  }

  if (status === 'draft') {
    if (badge) {
      badge.className = 'px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30';
      badge.textContent = 'Draft';
    }
    if (topBtnText) topBtnText.textContent = 'Save as Draft';
  } else if (status === 'scheduled') {
    if (badge) {
      badge.className = 'px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-purple-500/20 text-purple-300 border border-purple-500/30';
      badge.textContent = 'Scheduled';
    }
    if (topBtnText) topBtnText.textContent = 'Schedule Article';
  } else {
    if (badge) {
      badge.className = 'px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30';
      badge.textContent = 'Live';
    }
    if (topBtnText) topBtnText.textContent = '<?= $isEditing ? 'Update & Publish' : 'Publish Article' ?>';
  }
}

function toggleCodeView() {
  const visual = document.getElementById('editorVisual');
  const code = document.getElementById('postContent');
  const btnText = document.getElementById('codeViewBtnText');
  const toolbar = document.getElementById('editorToolbar');

  if (code.classList.contains('hidden')) {
    EstateEditor.syncVisualToTextarea();
    visual.classList.add('hidden');
    toolbar.classList.add('opacity-40', 'pointer-events-none');
    code.classList.remove('hidden');
    btnText.textContent = 'Visual View';
  } else {
    EstateEditor.syncTextareaToVisual();
    code.classList.add('hidden');
    visual.classList.remove('hidden');
    toolbar.classList.remove('opacity-40', 'pointer-events-none');
    btnText.textContent = 'HTML View';
  }
}

function updateSlugPreview() {
  const slugInput = document.getElementById('postSlug');
  const slugVal = (slugInput ? slugInput.value : '').trim();
  const previewText = document.getElementById('slugPreviewText');
  const previewLink = document.getElementById('slugPreviewLink');
  if (previewText) previewText.textContent = slugVal;
  if (previewLink) previewLink.href = '/blog/' + slugVal;
}

function toggleSlugEdit() {
  const slugInput = document.getElementById('postSlug');
  if (!slugInput) return;
  slugInput.dataset.manual = 'true';
  slugInput.focus();
  slugInput.select();
  if (window.EstateDialog) {
    EstateDialog.toast('URL Slug is editable.', 'info');
  }
}

function regenerateSlugFromTitle() {
  const title = (document.getElementById('postTitle').value || '').trim();
  const slugInput = document.getElementById('postSlug');
  if (!slugInput) return;
  const newSlug = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  slugInput.value = newSlug;
  slugInput.dataset.manual = 'true';
  updateSlugPreview();
  if (window.EstateDialog) {
    EstateDialog.toast('Generated URL slug: ' + newSlug, 'success');
  }
}

function syncSlug() {
  const title = document.getElementById('postTitle').value;
  const slugInput = document.getElementById('postSlug');
  if (!slugInput.dataset.manual) {
    slugInput.value = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
    updateSlugPreview();
  }
  const metaTitle = document.getElementById('postMetaTitle');
  if (!metaTitle.value || metaTitle.value.startsWith(title.substring(0, 10))) {
    metaTitle.value = title ? `${title} | Estate HDR` : '';
    updateCounters();
  }
}

document.getElementById('postSlug').addEventListener('input', function() {
  this.dataset.manual = 'true';
  updateSlugPreview();
});

// ── Interactive Tag Pills Component ──
const EstateTags = {
  tags: [],
  init() {
    const hidden = document.getElementById('postTagsHidden');
    const rawVal = hidden ? hidden.value : '';
    this.tags = rawVal.split(',').map(t => t.trim()).filter(t => t.length > 0);
    this.render();

    const inputBox = document.getElementById('tagInputBox');
    if (!inputBox) return;

    inputBox.addEventListener('keydown', (e) => {
      if (e.key === ',' || e.key === 'Enter') {
        e.preventDefault();
        this.addTagFromInput();
      } else if (e.key === 'Backspace' && inputBox.value === '' && this.tags.length > 0) {
        this.removeTag(this.tags.length - 1);
      }
    });

    inputBox.addEventListener('blur', () => {
      this.addTagFromInput();
    });

    inputBox.addEventListener('paste', (e) => {
      setTimeout(() => this.addTagFromInput(), 50);
    });
  },

  addTagFromInput() {
    const inputBox = document.getElementById('tagInputBox');
    if (!inputBox) return;
    const raw = inputBox.value;
    const parts = raw.split(',').map(s => s.trim().replace(/^#/, '')).filter(Boolean);
    parts.forEach(p => {
      if (!this.tags.includes(p)) {
        this.tags.push(p);
      }
    });
    inputBox.value = '';
    this.sync();
    this.render();
  },

  removeTag(idx) {
    this.tags.splice(idx, 1);
    this.sync();
    this.render();
  },

  sync() {
    const hidden = document.getElementById('postTagsHidden');
    if (hidden) hidden.value = this.tags.join(', ');
  },

  render() {
    const list = document.getElementById('tagPillsList');
    if (!list) return;
    list.innerHTML = '';
    this.tags.forEach((tag, idx) => {
      const pill = document.createElement('span');
      pill.className = 'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-gold/15 text-gold border border-gold/30 text-xs font-bold font-mono shadow-sm group';
      pill.innerHTML = `<span>#${this.escapeHtml(tag)}</span><button type="button" onclick="EstateTags.removeTag(${idx})" class="text-gold/60 hover:text-red-400 hover:scale-125 font-bold transition-all px-0.5 leading-none" title="Remove tag">&times;</button>`;
      list.appendChild(pill);
    });
  },

  escapeHtml(str) {
    return (str || '').replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[m]);
  }
};

function updateCounters() {
  const titleVal = document.getElementById('postMetaTitle').value;
  const descVal = document.getElementById('postMetaDesc').value;
  document.getElementById('titleCount').textContent = `${titleVal.length} / 60 chars`;
  document.getElementById('descCount').textContent = `${descVal.length} / 160 chars`;
}

function setCoverImage(url, title = '') {
  const input = document.getElementById('featuredImgInput');
  const preview = document.getElementById('coverPreview');
  const placeholder = document.getElementById('coverPlaceholder');

  const cleanUrl = (url || '').trim();
  if (input) input.value = cleanUrl;
  if (preview) {
    if (cleanUrl) {
      preview.src = cleanUrl;
      preview.classList.remove('hidden');
      if (placeholder) placeholder.classList.add('hidden');
      preview.onerror = () => {
        preview.classList.add('hidden');
        if (placeholder) placeholder.classList.remove('hidden');
      };
    } else {
      preview.src = '';
      preview.classList.add('hidden');
      if (placeholder) placeholder.classList.remove('hidden');
    }
  }
}

function updateCoverPreview() {
  const url = (document.getElementById('featuredImgInput').value || '').trim();
  setCoverImage(url);
}

function triggerDirectCoverUpload(e) {
  if (e && e.preventDefault) e.preventDefault();
  const fileInput = document.getElementById('featuredImgFileInput');
  if (fileInput) {
    fileInput.value = ''; // Always clear previous selection so picking same file fires change event
    fileInput.click();
  } else {
    console.error('featuredImgFileInput not found');
  }
}
window.triggerDirectCoverUpload = triggerDirectCoverUpload;

function uploadCoverImageFile(file) {
  if (!file) return;
  const customNameInput = document.getElementById('featuredImgCustomName');
  const customName = customNameInput ? customNameInput.value.trim() : '';
  const prog = document.getElementById('featuredImgUploadProgress');
  if (prog) {
    prog.classList.remove('hidden');
    prog.style.display = 'block';
  }

  const formData = new FormData();
  formData.append('image', file);
  if (customName) formData.append('custom_name', customName);
  const csrf = '<?= csrfToken() ?>';
  formData.append('csrf_token', csrf);

  fetch('/api/upload-image.php', {
    method: 'POST',
    headers: {
      'X-CSRF-TOKEN': csrf
    },
    body: formData
  })
  .then(r => r.json())
  .then(data => {
    if (prog) {
      prog.classList.add('hidden');
      prog.style.display = 'none';
    }
    const fileInput = document.getElementById('featuredImgFileInput');
    if (fileInput) fileInput.value = '';
    if (data.success && data.url) {
      setCoverImage(data.url);
      if (window.EstateDialog) {
        EstateDialog.toast('✅ Cover image uploaded and updated successfully!', 'success');
      } else {
        alert('Cover image uploaded and updated successfully!');
      }
    } else {
      alert(data.error || 'Upload failed');
    }
  })
  .catch(err => {
    if (prog) {
      prog.classList.add('hidden');
      prog.style.display = 'none';
    }
    const fileInput = document.getElementById('featuredImgFileInput');
    if (fileInput) fileInput.value = '';
    alert('Upload error: ' + err.message);
  });
}
window.uploadCoverImageFile = uploadCoverImageFile;

// Dynamic Server Media Images (Populated from server blog folder, uploads, and studio portfolio)
let SERVER_MEDIA_IMAGES = <?= json_encode($serverMediaImages, JSON_UNESCAPED_SLASHES) ?>;
let currentGalleryFolder = 'blog'; // Default to server blog folder!
let currentGallerySearch = '';
let galleryTargetMode = 'cover'; // 'cover' or 'editor'
let currentEditorImgTarget = null;

function openServerGalleryModal(target = 'cover') {
  galleryTargetMode = (typeof target === 'string') ? target : 'cover';
  currentGalleryFolder = 'blog'; // Always default to Blog folder when opened
  currentGallerySearch = '';
  const searchInput = document.getElementById('gallerySearchInput');
  if (searchInput) searchInput.value = '';
  renderServerGallery();
  const modal = document.getElementById('serverGalleryModal');
  if (modal) {
    modal.style.display = 'flex';
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  }
}
window.openServerGalleryModal = openServerGalleryModal;
window.openStudioGalleryModal = openServerGalleryModal; // Backward-compatible alias

function closeServerGalleryModal() {
  const modal = document.getElementById('serverGalleryModal');
  if (modal) {
    modal.style.display = 'none';
    modal.classList.add('hidden');
    document.body.style.overflow = '';
  }
}
window.closeServerGalleryModal = closeServerGalleryModal;
window.closeStudioGalleryModal = closeServerGalleryModal; // Backward-compatible alias

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    closeServerGalleryModal();
  }
});

function filterServerGallery(folder) {
  currentGalleryFolder = folder;
  document.querySelectorAll('#galleryFilterTabs .gallery-tab-btn').forEach(btn => {
    if (btn.dataset.folder === folder) {
      btn.className = 'gallery-tab-btn py-1.5 px-3.5 rounded-lg font-bold bg-gold text-dark transition-all';
    } else {
      btn.className = 'gallery-tab-btn py-1.5 px-3.5 rounded-lg font-bold text-gray-300 hover:text-white bg-dark border border-[#1E1E2E] transition-all';
    }
  });
  renderServerGallery();
}
window.filterServerGallery = filterServerGallery;

function searchServerGallery(query) {
  currentGallerySearch = (query || '').toLowerCase().trim();
  renderServerGallery();
}
window.searchServerGallery = searchServerGallery;

function renderServerGallery() {
  const grid = document.getElementById('galleryImageGrid');
  if (!grid) return;
  grid.innerHTML = '';

  let list = Array.isArray(SERVER_MEDIA_IMAGES) ? SERVER_MEDIA_IMAGES : [];
  if (currentGalleryFolder !== 'all') {
    list = list.filter(img => img.folder === currentGalleryFolder);
  }
  if (currentGallerySearch) {
    list = list.filter(img => {
      const title = (img.title || '').toLowerCase();
      const fn = (img.filename || '').toLowerCase();
      return title.includes(currentGallerySearch) || fn.includes(currentGallerySearch);
    });
  }

  if (list.length === 0) {
    grid.innerHTML = `
      <div class="col-span-full py-16 text-center">
        <div class="text-4xl mb-2">📁</div>
        <p class="text-sm font-bold text-gray-300">No images found in this folder</p>
        <p class="text-xs text-gray-500 mt-1">Upload an image or check another folder tab above.</p>
      </div>
    `;
    return;
  }

  list.forEach(item => {
    const card = document.createElement('div');
    card.className = 'group relative rounded-xl overflow-hidden border border-[#2A2A3A] hover:border-gold cursor-pointer bg-[#0D0D14] transition-all hover:scale-[1.02] shadow-md flex flex-col';
    card.onclick = () => selectGalleryImage(item.url, item.title || item.filename);

    const sizeFormatted = item.size ? `${Math.round(item.size / 1024)} KB` : '';

    card.innerHTML = `
      <div class="aspect-[16/9] w-full overflow-hidden bg-dark">
        <img src="${item.url}" alt="${item.title || item.filename}" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" onerror="this.src='/assets/images/portfolio/hdr/1-after.jpg'">
      </div>
      <div class="p-2.5 bg-[#111118] border-t border-[#1E1E2E] flex-1 flex flex-col justify-between">
        <div class="text-[11px] font-bold text-white truncate" title="${item.title || item.filename}">${item.title || item.filename}</div>
        <div class="flex items-center justify-between text-[9px] text-gray-400 mt-1 font-mono">
          <span class="text-gold font-bold uppercase">${item.category || item.folder}</span>
          <span>${sizeFormatted}</span>
        </div>
      </div>
      <div class="absolute inset-0 bg-gold/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
        <span class="px-3 py-1 bg-gold text-dark font-black text-xs rounded-lg shadow-lg">Select Photo ✓</span>
      </div>
    `;
    grid.appendChild(card);
  });
}
window.renderServerGallery = renderServerGallery;

function selectGalleryImage(url, title) {
  if (galleryTargetMode === 'cover') {
    setCoverImage(url, title);
    closeServerGalleryModal();
    if (window.EstateDialog) {
      EstateDialog.toast(`✨ Set Cover: ${title}`, 'success');
    }
  } else if (galleryTargetMode === 'editor') {
    if (currentEditorImgTarget) {
      currentEditorImgTarget.src = url;
      currentEditorImgTarget.alt = title;
      currentEditorImgTarget = null;
      if (typeof EstateEditor !== 'undefined' && EstateEditor.syncVisualToTextarea) {
        EstateEditor.syncVisualToTextarea();
      }
    } else {
      if (typeof EstateEditor !== 'undefined' && EstateEditor.insertHtmlAtSelection) {
        EstateEditor.insertHtmlAtSelection(`<img src="${url}" alt="${title}" class="w-full rounded-2xl my-6 shadow-xl object-cover">`);
      }
    }
    closeServerGalleryModal();
    if (window.EstateDialog) {
      EstateDialog.toast(`✨ Inserted into article: ${title}`, 'success');
    }
  }
}
window.selectGalleryImage = selectGalleryImage;

function quickAddPostCategory() {
  const name = document.getElementById('quickCatName').value.trim();
  if (!name) return;

  const select = document.getElementById('postCategorySelect');
  const opt = document.createElement('option');
  opt.value = name;
  opt.textContent = name;
  opt.selected = true;
  select.appendChild(opt);

  // Send AJAX to create in background
  const formData = new FormData();
  formData.append('name', name);
  formData.append('type', 'post');
  formData.append('csrf_token', '<?= csrfToken() ?>');

  fetch('/admin/categories.php', { method: 'POST', body: formData });

  document.getElementById('quickCatName').value = '';
  document.getElementById('quickAddCatBox').classList.add('hidden');
}

function runReadabilityAudit() {
  const content = document.getElementById('editorVisual') ? document.getElementById('editorVisual').innerText : '';
  const words = content.trim().split(/\s+/).filter(w => w.length > 0);
  const wordCount = words.length;
  const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 0);
  const sentenceCount = sentences.length || 1;
  const avgWordsPerSentence = (wordCount / sentenceCount).toFixed(1);

  let readabilityScore = Math.max(0, Math.min(100, Math.round(206.835 - (1.015 * avgWordsPerSentence) - 30)));
  if (wordCount < 30) readabilityScore = 85;

  let readabilityLabel = '🟢 Good — Very Easy to Read & Fast to Scan';
  let scoreColor = 'text-emerald-400';
  if (readabilityScore < 50) {
    readabilityLabel = '🔴 Complex — Consider shorter sentences';
    scoreColor = 'text-red-400';
  } else if (readabilityScore < 70) {
    readabilityLabel = '🟡 Fairly Readable — Standard Web Reading';
    scoreColor = 'text-amber-400';
  }

  const scoreElem = document.getElementById('readabilityScoreDisplay');
  const labelElem = document.getElementById('readabilityLabelDisplay');
  const statsElem = document.getElementById('readabilityStatsDisplay');

  if (scoreElem) scoreElem.textContent = `${readabilityScore} / 100`;
  if (labelElem) {
    labelElem.textContent = readabilityLabel;
    labelElem.className = `text-xs font-bold ${scoreColor} mt-1`;
  }
  if (statsElem) {
    statsElem.textContent = `Total Words: ${wordCount} | Sentences: ${sentenceCount} | Avg Words/Sentence: ${avgWordsPerSentence}`;
  }
}

function insertCardSchemaTemplate(type) {
  const title = document.getElementById('postTitle').value || 'Estate HDR Professional Real Estate Photo Editing';
  const author = document.querySelector('input[name="author"]').value || 'Estate HDR Editorial Team';
  const dateStr = new Date().toISOString().split('T')[0];
  let schemaObj = {};

  if (type === 'faq') {
    schemaObj = {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "How quickly can Estate HDR edit my photos?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Standard guaranteed delivery is within 12 to 24 hours, with urgent rush options."
          }
        },
        {
          "@type": "Question",
          "name": "What services are included in real estate photo enhancement?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "HDR blending, window pulls, sky replacement, lawn enhancement, perspective straightening, and TV/fireplace additions."
          }
        }
      ]
    };
  } else if (type === 'article') {
    schemaObj = {
      "@context": "https://schema.org",
      "@type": "BlogPosting",
      "headline": title,
      "description": document.getElementById('postMetaDesc').value || "Professional real estate photography tips and insights.",
      "author": {
        "@type": "Organization",
        "name": author
      },
      "publisher": {
        "@type": "Organization",
        "name": "Estate HDR",
        "logo": {
          "@type": "ImageObject",
          "url": "https://estatehdr.com/assets/images/logo.png"
        }
      },
      "datePublished": dateStr,
      "dateModified": dateStr
    };
  } else if (type === 'business') {
    schemaObj = {
      "@context": "https://schema.org",
      "@type": "ProfessionalService",
      "name": "Estate HDR",
      "image": "https://estatehdr.com/assets/images/portfolio/hdr/1-after.jpg",
      "url": "https://estatehdr.com",
      "telephone": "+44 770 606 8176",
      "priceRange": "$0.68 - $15.00",
      "address": {
        "@type": "PostalAddress",
        "addressCountry": "US"
      }
    };
  } else if (type === 'howto') {
    schemaObj = {
      "@context": "https://schema.org",
      "@type": "HowTo",
      "name": `How to Master: ${title}`,
      "step": [
        {
          "@type": "HowToStep",
          "name": "Step 1: Capture Multiple Exposures",
          "text": "Set exposure bracketing on camera tripod at -2, 0, +2 EV."
        },
        {
          "@type": "HowToStep",
          "name": "Step 2: Submit to Estate HDR Portal",
          "text": "Submit RAW photos and receive guaranteed edited photos in 12 hours."
        }
      ]
    };
  }

  const area = document.getElementById('postSchemaJson');
  if (area) {
    area.value = JSON.stringify(schemaObj, null, 2);
    if (window.EstateDialog) {
      EstateDialog.toast(`✨ ${type.toUpperCase()} Schema template generated!`, 'success');
    }
  }
}

// Inline Image Actions for Editor Images
function setupEditorImageInspector() {
  const visual = document.getElementById('editorVisual');
  if (!visual) return;

  visual.addEventListener('click', (e) => {
    if (e.target.tagName === 'IMG') {
      const img = e.target;
      currentEditorImgTarget = img;
      
      // Highlight clicked image
      visual.querySelectorAll('img').forEach(i => i.style.outline = 'none');
      img.style.outline = '3px solid #C9A84C';
      img.style.outlineOffset = '3px';

      // Create or update floating quick bar
      let bar = document.getElementById('inlineImgQuickBar');
      if (!bar) {
        bar = document.createElement('div');
        bar.id = 'inlineImgQuickBar';
        bar.className = 'fixed z-[9999] bg-[#111118] border border-gold/50 rounded-xl p-1.5 shadow-2xl flex items-center gap-1.5 text-xs text-white';
        document.body.appendChild(bar);
      }

      const rect = img.getBoundingClientRect();
      bar.style.top = `${Math.max(10, rect.top - 46)}px`;
      bar.style.left = `${Math.max(10, rect.left)}px`;
      bar.classList.remove('hidden');

      bar.innerHTML = `
        <span class="text-gold font-bold px-1.5 text-[11px]">Selected Image:</span>
        <button type="button" id="inlineImgReplaceUploadBtn" class="px-2 py-1 bg-gold text-dark font-bold rounded-lg hover:bg-gold-light text-[11px] flex items-center gap-1">
          <span>📁</span> <span>Upload</span>
        </button>
        <button type="button" id="inlineImgReplaceGalleryBtn" class="px-2 py-1 bg-[#1E1E2E] hover:bg-gold hover:text-dark text-white font-bold rounded-lg text-[11px] flex items-center gap-1">
          <span>🖼️</span> <span>Gallery</span>
        </button>
        <button type="button" id="inlineImgDeleteBtn" class="px-2 py-1 bg-red-500/20 hover:bg-red-500 text-red-300 hover:text-white font-bold rounded-lg text-[11px]">
          <span>🗑️</span>
        </button>
        <button type="button" id="inlineImgCloseBtn" class="px-1.5 py-1 text-gray-400 hover:text-white font-bold text-[11px]">&times;</button>
      `;

      document.getElementById('inlineImgReplaceUploadBtn').onclick = () => {
        const inp = document.createElement('input');
        inp.type = 'file';
        inp.accept = 'image/*';
        inp.onchange = () => {
          if (inp.files && inp.files[0]) {
            const formData = new FormData();
            formData.append('image', inp.files[0]);
            formData.append('csrf_token', '<?= csrfToken() ?>');
            fetch('/api/upload-image.php', { method: 'POST', body: formData })
              .then(r => r.json())
              .then(d => {
                if (d.success) {
                  img.src = d.url;
                  EstateEditor.syncVisualToTextarea();
                  bar.classList.add('hidden');
                  img.style.outline = 'none';
                  if (window.EstateDialog) EstateDialog.toast('Image replaced successfully!', 'success');
                } else {
                  alert(d.error || 'Upload failed');
                }
              });
          }
        };
        inp.click();
      };

      document.getElementById('inlineImgReplaceGalleryBtn').onclick = () => {
        openServerGalleryModal('editor');
        bar.classList.add('hidden');
        img.style.outline = 'none';
      };

      document.getElementById('inlineImgDeleteBtn').onclick = () => {
        const doRemove = () => {
          img.remove();
          EstateEditor.syncVisualToTextarea();
          bar.classList.add('hidden');
        };
        if (window.EstateDialog) {
          EstateDialog.confirm('Delete this image from the article?', 'Delete Image', { danger: true, confirmText: '🗑️ Delete Image' }).then(ok => {
            if (ok) doRemove();
          });
        } else {
          doRemove();
        }
      };

      document.getElementById('inlineImgCloseBtn').onclick = () => {
        bar.classList.add('hidden');
        img.style.outline = 'none';
      };
    } else {
      const bar = document.getElementById('inlineImgQuickBar');
      if (bar) bar.classList.add('hidden');
      visual.querySelectorAll('img').forEach(i => i.style.outline = 'none');
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  window.EstateEditorMode = 'post';
  EstateEditor.init({
    editorId: 'editorVisual',
    textareaId: 'postContent'
  });

  // Safely populate editorVisual from postContent textarea to keep outer DOM 100% isolated
  const postContentEl = document.getElementById('postContent');
  const editorVisualEl = document.getElementById('editorVisual');
  if (postContentEl && editorVisualEl && postContentEl.value) {
    editorVisualEl.innerHTML = postContentEl.value;
  }

  updateCounters();
  runReadabilityAudit();
  EstateTags.init();
  updateSlugPreview();

  // Initialize Featured Cover Drag & Drop and File Input
  const fileInput = document.getElementById('featuredImgFileInput');
  if (fileInput) {
    fileInput.addEventListener('change', () => {
      if (fileInput.files && fileInput.files[0]) {
        uploadCoverImageFile(fileInput.files[0]);
      }
    });
  }

  const dropzone = document.getElementById('featuredImgDropzone');
  if (dropzone) {
    dropzone.addEventListener('click', () => triggerDirectCoverUpload());
    dropzone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropzone.classList.add('border-gold', 'bg-gold/10');
    });
    dropzone.addEventListener('dragleave', () => {
      dropzone.classList.remove('border-gold', 'bg-gold/10');
    });
    dropzone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropzone.classList.remove('border-gold', 'bg-gold/10');
      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        uploadCoverImageFile(e.dataTransfer.files[0]);
      }
    });
  }

  // Setup click-to-replace on images inside the article
  setupEditorImageInspector();

  // Attach explicit click bindings to ensure 100% responsiveness across all browsers
  document.querySelectorAll('[onclick*="triggerDirectCoverUpload"]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      triggerDirectCoverUpload(e);
    });
  });
  document.querySelectorAll('[onclick*="openServerGalleryModal"], [onclick*="openStudioGalleryModal"]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      openServerGalleryModal('cover');
    });
  });

  // 1. Check for unsaved LocalStorage draft on load (Crash & Back-button recovery)
  checkAndPromptLocalDraft();

  // 2. Start Session Keep-Alive Heartbeat (Pings every 2 minutes so session & CSRF never die)
  pingSessionHeartbeat();
  setInterval(pingSessionHeartbeat, 120000);

  // 3. Debounced Auto-Save on any text input or formatting change
  const formEl = document.getElementById('postForm');
  if (formEl) {
    formEl.addEventListener('input', () => {
      clearTimeout(autoSaveTimer);
      autoSaveTimer = setTimeout(saveDraftToLocalStorage, 2500);
    });
  }
  const editorEl = document.getElementById('editorVisual');
  if (editorEl) {
    editorEl.addEventListener('input', () => {
      clearTimeout(autoSaveTimer);
      autoSaveTimer = setTimeout(saveDraftToLocalStorage, 2500);
    });
  }

  // 4. Periodic auto-save every 5 seconds
  setInterval(saveDraftToLocalStorage, 5000);

  // 5. Unsaved changes warning if user attempts to leave tab or close browser
  window.addEventListener('beforeunload', (e) => {
    if (!isFormSubmitting) {
      saveDraftToLocalStorage();
    }
  });
});
</script>

</body>
</html>