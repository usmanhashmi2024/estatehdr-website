<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/discord-bot.php';
requireManagerOrAdmin();

// Handle Discord & Automation Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['discord_action'])) {
    verifyCsrf();
    $act = $_POST['discord_action'];
    if ($act === 'save_settings') {
        $settings = [
            'enabled'                => !empty($_POST['discord_enabled']),
            'webhook_url'            => trim($_POST['webhook_url'] ?? ''),
            'notify_new_visitor'     => !empty($_POST['notify_new_visitor']),
            'notify_live_chat'       => !empty($_POST['notify_live_chat']),
            'notify_new_lead'        => !empty($_POST['notify_new_lead']),
            'notify_daily_digest'    => !empty($_POST['notify_daily_digest']),
            'daily_digest_time'      => trim($_POST['daily_digest_time'] ?? '21:00'),
            'last_daily_digest_date' => getDiscordSettings()['last_daily_digest_date'] ?? ''
        ];
        saveDiscordSettings($settings);
        setFlash('success', 'Discord Webhook & Real-Time Alert settings saved successfully!');
    } elseif ($act === 'send_test_alert') {
        $testEmbed = [
            'title'       => '👑 Estate HDR — Live Alert Verification',
            'description' => 'Test alert dispatched from Admin Command Center. Live bridge is 100% operational!',
            'color'       => 13215820,
            'fields'      => [
                ['name' => '⚡ Triggered By', 'value' => 'Master Administrator', 'inline' => true],
                ['name' => '🕒 Timestamp', 'value' => date('M j, Y g:i A T'), 'inline' => true],
                ['name' => '🟢 Connection Status', 'value' => '200 OK / Active', 'inline' => true]
            ],
            'footer'      => ['text' => 'Estate HDR Discord Intelligence Engine']
        ];
        $sent = sendDiscordWebhookPayload([
            'username'   => 'Estate HDR Intelligence',
            'avatar_url' => 'https://estatehdr.com/assets/images/favicon.png',
            'embeds'     => [$testEmbed]
        ]);
        if ($sent) {
            setFlash('success', 'Test Alert successfully sent to your Discord channel!');
        } else {
            setFlash('error', 'Failed to send test alert. Please check your Discord Webhook URL.');
        }
    } elseif ($act === 'send_daily_digest') {
        $sent = sendDiscordDailyDigestReport();
        if ($sent) {
            setFlash('success', 'Executive Daily Analytics Report successfully posted to Discord!');
        } else {
            setFlash('error', 'Failed to send daily report. Please verify webhook status.');
        }
    }
    header('Location: /admin/live-visitors.php?range=' . urlencode($_GET['range'] ?? 'all'));
    exit;
}

// Release session lock so concurrent AJAX and browser tabs don't block
if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

$discordCfg = getDiscordSettings();

// Load Analytics, Chats, Leads, Contacts, Tickets, Automations, Widget Settings, Knowledge Base
$visitors = readJson(DATA_PATH . 'visitors.json');
$history = readJson(DATA_PATH . 'analytics_history.json');
$chats = readJson(DATA_PATH . 'live_chats.json');
$leads = readJson(DATA_PATH . 'leads.json');
$contacts = readJson(DATA_PATH . 'contacts.json');
$tickets = readJson(DATA_PATH . 'tickets.json');
$rules = readJson(DATA_PATH . 'chat_automations.json');
$widgetSettings = readJson(DATA_PATH . 'widget_settings.json');
$knowledgeBase = readJson(DATA_PATH . 'knowledge_base.json');

// Range Filter
$range = trim($_GET['range'] ?? 'all');
$now = time();

// Calculate Sessions & Breakdowns using DB helper
$sessionData = filterVisitorSessions($visitors, $range, '', '', $now);
$filteredVisitors = $sessionData['filtered_visitors'];
$totalFilteredCount = $sessionData['total_sessions'];
$uniqueIpsCount = $sessionData['unique_ips_count'];
$totalHits = $sessionData['total_hits'];
$avgTimeStr = $sessionData['avg_duration_str'];
$countries = $sessionData['countries'];
$cities = $sessionData['cities'];
$pages = $sessionData['pages'];
$devices = $sessionData['devices'];
$browsers = $sessionData['browsers'];
$referrers = $sessionData['referrers'];

// Calculate Live Presence Stats (3-State: Active <=60s, Idle 61-180s, Chatting)
$presenceStats = calculateLivePresenceStats($visitors, $chats, $now);
$onlineNow = $presenceStats['online_now'];
$activeCount = $presenceStats['active_count'];
$idleCount = $presenceStats['idle_count'];
$chattingCount = $presenceStats['chatting_count'];

// Calculate KPIs
$chatKpis = calculateChatKpis($chats, $range, $now);
$csatKpi = calculateCsatKpi($chats, $tickets);
$ticketKpis = calculateTicketKpis($tickets, $now);
$leadKpis = calculateLeadKpis($leads, $contacts);

// Map presence state on filtered visitors for display
foreach ($filteredVisitors as $vid => &$v) {
    $lastTs = $v['last_seen_ts'] ?? strtotime($v['last_seen'] ?? '2000-01-01');
    $delta = max(0, $now - $lastTs);
    $lastChatTs = isset($chats[$vid]) ? ($chats[$vid]['last_active_ts'] ?? strtotime($chats[$vid]['last_active'] ?? '2000-01-01')) : 0;
    $isChatting = isset($chats[$vid]) && (($now - $lastChatTs <= 600) || (($chats[$vid]['status'] ?? '') === 'active'));

    if ($isChatting && $delta <= 300) {
        $v['presence_state'] = 'chatting';
    } elseif ($delta <= 60) {
        $v['presence_state'] = 'active';
    } elseif ($delta <= 180) {
        $v['presence_state'] = 'idle';
    } else {
        $v['presence_state'] = 'recent';
    }
}
unset($v);

uasort($chats, fn($a, $b) => ($b['last_active_ts'] ?? strtotime($b['last_active'] ?? '2000-01-01')) <=> ($a['last_active_ts'] ?? strtotime($a['last_active'] ?? '2000-01-01')));

$ranges = [
    'all'       => 'All Time',
    'today'     => 'Today',
    'yesterday' => 'Yesterday',
    '7days'     => 'Last 7 Days',
    '30days'    => 'Last 30 Days',
    'month'     => 'This Month'
];
$rangeLabel = $ranges[$range] ?? 'All Time';

function formatPageSeoInfo(string $rawUrl): array {
    $url = trim($rawUrl);
    if ($url === '' || $url === '/' || $url === '/index.php') {
        return [
            'href'  => '/',
            'title' => 'Homepage',
            'path'  => '/',
            'icon'  => '🏠',
            'type'  => 'Landing'
        ];
    }

    // Services Clean URL mapping
    if (str_starts_with($url, '/service.php?slug=') || str_starts_with($url, 'service.php?slug=')) {
        parse_str(parse_url($url, PHP_URL_QUERY) ?: '', $q);
        $slug = $q['slug'] ?? '';
        $cleanName = ucwords(str_replace(['-', '_'], ' ', $slug));
        return [
            'href'  => '/services/' . urlencode($slug),
            'title' => $cleanName . ' Service',
            'path'  => '/services/' . $slug,
            'icon'  => '✨',
            'type'  => 'Service'
        ];
    }

    // Blog Post Clean URL mapping
    if (str_starts_with($url, '/blog-post.php?slug=') || str_starts_with($url, 'blog-post.php?slug=')) {
        parse_str(parse_url($url, PHP_URL_QUERY) ?: '', $q);
        $slug = $q['slug'] ?? '';
        $cleanName = ucwords(str_replace(['-', '_'], ' ', $slug));
        return [
            'href'  => '/blog/' . urlencode($slug),
            'title' => $cleanName,
            'path'  => '/blog/' . $slug,
            'icon'  => '📰',
            'type'  => 'Blog Article'
        ];
    }

    if (str_starts_with($url, '/services/')) {
        $slug = str_replace('/services/', '', $url);
        $cleanName = ucwords(str_replace(['-', '_'], ' ', $slug));
        return [
            'href'  => $url,
            'title' => $cleanName . ' Service',
            'path'  => $url,
            'icon'  => '✨',
            'type'  => 'Service'
        ];
    }

    if (str_starts_with($url, '/blog/')) {
        $slug = str_replace('/blog/', '', $url);
        $cleanName = ucwords(str_replace(['-', '_'], ' ', $slug));
        return [
            'href'  => $url,
            'title' => $cleanName,
            'path'  => $url,
            'icon'  => '📰',
            'type'  => 'Blog Article'
        ];
    }

    if (str_contains($url, 'blog.php')) {
        return [
            'href'  => '/blog.php',
            'title' => 'Blog Directory',
            'path'  => '/blog.php',
            'icon'  => '📚',
            'type'  => 'Directory'
        ];
    }

    if (str_contains($url, 'portfolio.php') || str_contains($url, '/portfolio')) {
        return [
            'href'  => '/portfolio.php',
            'title' => 'Client Portfolio',
            'path'  => '/portfolio.php',
            'icon'  => '🖼️',
            'type'  => 'Portfolio'
        ];
    }

    if (str_contains($url, 'contact.php') || str_contains($url, '/contact')) {
        return [
            'href'  => '/contact.php',
            'title' => 'Contact & Quotes',
            'path'  => '/contact.php',
            'icon'  => '📞',
            'type'  => 'Inquiry'
        ];
    }

    if (str_contains($url, 'pricing.php') || str_contains($url, '/pricing')) {
        return [
            'href'  => '/pricing.php',
            'title' => 'Pricing & Plans',
            'path'  => '/pricing.php',
            'icon'  => '💳',
            'type'  => 'Pricing'
        ];
    }

    return [
        'href'  => $url,
        'title' => $url,
        'path'  => $url,
        'icon'  => '📄',
        'type'  => 'Page'
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Unified Command Center &amp; Visitor Intelligence — Estate HDR Admin</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',light:'#E0C26D',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
  
  <!-- ── 1. SUB-HEADER & DATE RANGE FILTER BAR ───────────────────────── -->
  <div class="flex flex-col xl:flex-row xl:items-center justify-between gap-4 border-b border-dark-border pb-5">
    <div>
      <div class="flex items-center gap-3">
        <span class="relative flex h-4 w-4">
          <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span class="relative inline-flex rounded-full h-4 w-4 bg-emerald-500"></span>
        </span>
        <h1 class="text-2xl sm:text-3xl font-black text-white tracking-tight">Command Center &amp; Visitor Intelligence Hub</h1>
      </div>
      <p class="text-sm text-gray-300 font-medium mt-1">Real-Time Telemetry Radar, Omnichannel Shared Inbox, CRM Lead Scoring, Triggers Studio &amp; Support Ticketing.</p>
    </div>

    <div class="flex flex-wrap items-center gap-2">
      <?php foreach ($ranges as $rk => $rl): ?>
      <a href="?range=<?= $rk ?>" class="px-3.5 py-2 rounded-xl text-sm font-bold transition-all <?= $range === $rk ? 'bg-gold text-dark shadow-glow' : 'bg-dark-card text-gray-300 hover:text-white border border-dark-border hover:border-gold/50' ?>">
        <?= $rl ?>
      </a>
      <?php endforeach; ?>

      <button onclick="playNotificationChime()" class="px-3.5 py-2 rounded-xl bg-dark-card border border-dark-border hover:border-gold text-gray-200 hover:text-gold text-sm font-bold inline-flex items-center gap-1.5 transition-all" title="Test Synthesized Audio Chime">
        <span>🔔 Test Chime</span>
      </button>

      <div class="px-3.5 py-2 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 font-mono text-xs font-bold inline-flex items-center gap-1.5 shadow-sm">
        <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
        <span>Live Telemetry Sync</span>
      </div>
    </div>
  </div>

  <!-- ── 2. RESPONSIVE 6-TAB NAVIGATION BAR ────────────────────────── -->
  <div class="flex items-center gap-2.5 overflow-x-auto border-b border-dark-border pb-3.5 scrollbar-none">
    
    <button onclick="switchCommandTab('tabOverview')" id="btnTabOverview" class="tab-btn px-5 py-3 rounded-xl font-black text-sm transition-all whitespace-nowrap inline-flex items-center gap-2 bg-gold text-dark shadow-glow">
      <span>📊</span> <span>1. Overview &amp; KPIs</span>
    </button>
    
    <button onclick="switchCommandTab('tabRadar')" id="btnTabRadar" class="tab-btn px-5 py-3 rounded-xl font-black text-sm transition-all whitespace-nowrap inline-flex items-center gap-2 bg-dark-card text-gray-300 border border-dark-border hover:border-gold hover:text-white">
      <span>🌍</span> <span>2. Live Visitor Radar &amp; Geo-Map</span>
      <span class="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-mono font-bold"><?= $onlineNow + $idleCount ?></span>
    </button>
    
    <button onclick="switchCommandTab('tabInbox')" id="btnTabInbox" class="tab-btn px-5 py-3 rounded-xl font-black text-sm transition-all whitespace-nowrap inline-flex items-center gap-2 bg-dark-card text-gray-300 border border-dark-border hover:border-gold hover:text-white">
      <span>💬</span> <span>3. Omnichannel Shared Inbox</span>
      <span class="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-400 border border-amber-500/30 text-xs font-mono font-bold"><?= count($chats) ?></span>
    </button>
    
    <button onclick="switchCommandTab('tabCrm')" id="btnTabCrm" class="tab-btn px-5 py-3 rounded-xl font-black text-sm transition-all whitespace-nowrap inline-flex items-center gap-2 bg-dark-card text-gray-300 border border-dark-border hover:border-gold hover:text-white">
      <span>💼</span> <span>4. CRM &amp; Dynamic Lead Scoring</span>
      <span class="px-2 py-0.5 rounded-md bg-blue-500/20 text-blue-400 border border-blue-500/30 text-xs font-mono font-bold"><?= $leadKpis['total_leads'] ?></span>
    </button>
    
    <button onclick="switchCommandTab('tabTriggers')" id="btnTabTriggers" class="tab-btn px-5 py-3 rounded-xl font-black text-sm transition-all whitespace-nowrap inline-flex items-center gap-2 bg-dark-card text-gray-300 border border-dark-border hover:border-gold hover:text-white">
      <span>⚡</span> <span>5. Behavioral Triggers &amp; Widget Studio</span>
    </button>
    
    <button onclick="switchCommandTab('tabTickets')" id="btnTabTickets" class="tab-btn px-5 py-3 rounded-xl font-black text-sm transition-all whitespace-nowrap inline-flex items-center gap-2 bg-dark-card text-gray-300 border border-dark-border hover:border-gold hover:text-white">
      <span>🎫</span> <span>6. Tickets &amp; KB</span>
      <span class="px-2 py-0.5 rounded-md bg-purple-500/20 text-purple-400 border border-purple-500/30 text-xs font-mono font-bold"><?= $ticketKpis['total_tickets'] ?></span>
    </button>

    <button onclick="switchCommandTab('tabGlobalAgents')" id="btnTabGlobalAgents" class="tab-btn px-5 py-3 rounded-xl font-black text-sm transition-all whitespace-nowrap inline-flex items-center gap-2 bg-dark-card text-gray-300 border border-dark-border hover:border-gold hover:text-white">
      <span>🌐</span> <span>7. Global Country Routing</span>
    </button>

    <button onclick="switchCommandTab('tabObservability')" id="btnTabObservability" class="tab-btn px-5 py-3 rounded-xl font-black text-sm transition-all whitespace-nowrap inline-flex items-center gap-2 bg-dark-card text-gray-300 border border-dark-border hover:border-gold hover:text-white">
      <span>📈</span> <span>8. Executive Observability</span>
    </button>

  </div>

  </div>

  <!-- ══════════════════════════════════════════════════════════════════
       TAB 1: OVERVIEW & EXECUTIVE KPI SUMMARY
       ══════════════════════════════════════════════════════════════════ -->
  <div id="tabOverview" class="tab-content space-y-6">
    
    <!-- 6 Executive KPI Metric Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
      
      <!-- Card 1: Active Online Now -->
      <div class="glass-card p-5 rounded-2xl border border-emerald-500/40 bg-gradient-to-br from-emerald-950/20 to-dark-card shadow-xl">
        <div class="flex items-center justify-between text-xs text-emerald-400 font-bold uppercase tracking-wider mb-2">
          <span>Active Online</span>
          <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
        </div>
        <div class="text-3xl font-black text-white font-mono"><?= number_format($onlineNow) ?></div>
        <div class="text-[11px] text-gray-400 mt-2 flex items-center gap-1">
          <span class="text-emerald-400 font-bold"><?= $activeCount ?> Active</span>
          <span>•</span>
          <span class="text-amber-400"><?= $idleCount ?> Idle</span>
          <?php if ($chattingCount > 0): ?>
          <span>•</span>
          <span class="text-blue-400 font-bold"><?= $chattingCount ?> Chat</span>
          <?php endif; ?>
        </div>
      </div>

      <!-- Card 2: Total Filtered Sessions -->
      <div class="glass-card p-5 rounded-2xl border border-dark-border shadow-xl">
        <div class="flex items-center justify-between text-xs text-gray-400 font-bold uppercase tracking-wider mb-2">
          <span>Total Traffic</span>
          <span>👥</span>
        </div>
        <div class="text-3xl font-black text-gold font-mono"><?= number_format($totalFilteredCount) ?></div>
        <div class="text-[11px] text-gray-400 mt-2 flex items-center justify-between">
          <span><?= number_format($uniqueIpsCount) ?> IPs</span>
          <span class="text-gold font-mono"><?= number_format($totalHits) ?> hits</span>
        </div>
      </div>

      <!-- Card 3: Avg Duration -->
      <div class="glass-card p-5 rounded-2xl border border-dark-border shadow-xl">
        <div class="flex items-center justify-between text-xs text-gray-400 font-bold uppercase tracking-wider mb-2">
          <span>Avg Dwell Time</span>
          <span>⏱️</span>
        </div>
        <div class="text-3xl font-black text-blue-400 font-mono"><?= $avgTimeStr ?></div>
        <div class="text-[11px] text-gray-400 mt-2">High engagement focus</div>
      </div>

      <!-- Card 4: Omnichannel Chats & FRT -->
      <div class="glass-card p-5 rounded-2xl border border-dark-border shadow-xl">
        <div class="flex items-center justify-between text-xs text-gray-400 font-bold uppercase tracking-wider mb-2">
          <span>Omnichannel</span>
          <span>💬</span>
        </div>
        <div class="text-3xl font-black text-amber-400 font-mono"><?= number_format(count($chats)) ?></div>
        <div class="text-[11px] text-gray-400 mt-2 flex items-center justify-between">
          <span class="text-emerald-400 font-bold">FRT: <?= $chatKpis['avg_frt_formatted'] ?></span>
          <span><?= $chatKpis['active_chats_now'] ?> Active</span>
        </div>
      </div>

      <!-- Card 5: CSAT Satisfaction Rating -->
      <div class="glass-card p-5 rounded-2xl border border-dark-border shadow-xl">
        <div class="flex items-center justify-between text-xs text-gray-400 font-bold uppercase tracking-wider mb-2">
          <span>CSAT Rating</span>
          <span>⭐</span>
        </div>
        <div class="text-3xl font-black text-emerald-400 font-mono"><?= $csatKpi['csat_formatted'] ?></div>
        <div class="text-[11px] text-gray-400 mt-2 flex items-center justify-between">
          <span><?= $csatKpi['rating_stars'] ?></span>
          <span class="text-xs text-gold">Studio SLA</span>
        </div>
      </div>

      <!-- Card 6: Tickets & Active Leads -->
      <div class="glass-card p-5 rounded-2xl border border-dark-border shadow-xl">
        <div class="flex items-center justify-between text-xs text-gray-400 font-bold uppercase tracking-wider mb-2">
          <span>Tickets &amp; Leads</span>
          <span>🎫</span>
        </div>
        <div class="text-3xl font-black text-purple-400 font-mono">
          <?= $ticketKpis['open_tickets_count'] ?> <span class="text-xs text-gray-500 font-normal">/ <?= $leadKpis['active_leads_count'] ?> leads</span>
        </div>
        <div class="text-[11px] text-gray-400 mt-2 flex items-center justify-between">
          <span class="<?= $ticketKpis['urgent_count'] > 0 ? 'text-red-400 font-bold' : 'text-gray-400' ?>"><?= $ticketKpis['urgent_count'] ?> Urgent</span>
          <span class="text-purple-300"><?= $leadKpis['trial_samples_pending'] ?> Trials</span>
        </div>
      </div>

    </div>

    <!-- Live Event Feed & Omnichannel Distribution Bar -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
      
      <!-- Live Real-Time Feed (7 Cols) -->
      <div class="lg:col-span-7 glass-card rounded-2xl border border-dark-border p-6 shadow-xl space-y-4">
        <div class="flex items-center justify-between border-b border-dark-border pb-3">
          <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-2">
            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span>Real-Time Activity Stream &amp; Events</span>
          </h3>
          <span class="text-[11px] font-mono text-gray-500">Auto-streaming</span>
        </div>
        
        <div class="space-y-3 max-h-[300px] overflow-y-auto pr-2" id="activityStreamContainer">
          <?php if (empty($filteredVisitors)): ?>
          <div class="p-8 text-center text-gray-500 text-xs">No active telemetry events recorded yet.</div>
          <?php else: ?>
          <?php foreach (array_slice($filteredVisitors, 0, 5) as $ev): ?>
          <div class="p-3 rounded-xl bg-dark/60 border border-dark-border flex items-center justify-between text-xs">
            <div class="flex items-center gap-3">
              <span class="text-lg"><?= $ev['flag'] ?? '🌐' ?></span>
              <div>
                <div class="font-bold text-white"><?= htmlspecialchars($ev['city'] ?? 'London') ?>, <?= htmlspecialchars($ev['country'] ?? 'UK') ?> <span class="text-gray-500 font-mono text-[10px]">(<?= htmlspecialchars($ev['ip'] ?? '127.0.0.1') ?>)</span></div>
                <div class="text-[11px] text-gray-400">Viewed <span class="text-gold font-medium"><?= htmlspecialchars($ev['page_title'] ?? 'Services') ?></span></div>
              </div>
            </div>
            <div class="text-right">
              <span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono text-[10px] font-bold">PING</span>
              <div class="text-[10px] text-gray-500 font-mono mt-1"><?= date('H:i:s', $ev['last_seen_ts'] ?? time()) ?></div>
            </div>
          </div>
          <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>

      <!-- Channel Distribution & Quick Insights (5 Cols) -->
      <div class="lg:col-span-5 glass-card rounded-2xl border border-dark-border p-6 shadow-xl space-y-5">
        <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider">Omnichannel Communication Share</h3>
        
        <div class="space-y-3 text-xs">
          <div>
            <div class="flex items-center justify-between mb-1">
              <span class="text-white font-bold flex items-center gap-1.5"><span>🌐</span> Live Web Chat</span>
              <span class="text-gold font-mono font-bold">65% (<?= count($chats) ?>)</span>
            </div>
            <div class="w-full h-2 rounded-full bg-dark overflow-hidden border border-dark-border">
              <div class="h-full bg-gold rounded-full" style="width: 65%"></div>
            </div>
          </div>

          <div>
            <div class="flex items-center justify-between mb-1">
              <span class="text-white font-bold flex items-center gap-1.5"><span>📱</span> WhatsApp Direct</span>
              <span class="text-emerald-400 font-mono font-bold">20%</span>
            </div>
            <div class="w-full h-2 rounded-full bg-dark overflow-hidden border border-dark-border">
              <div class="h-full bg-emerald-500 rounded-full" style="width: 20%"></div>
            </div>
          </div>

          <div>
            <div class="flex items-center justify-between mb-1">
              <span class="text-white font-bold flex items-center gap-1.5"><span>✉️</span> Studio Email</span>
              <span class="text-blue-400 font-mono font-bold">10%</span>
            </div>
            <div class="w-full h-2 rounded-full bg-dark overflow-hidden border border-dark-border">
              <div class="h-full bg-blue-500 rounded-full" style="width: 10%"></div>
            </div>
          </div>

          <div>
            <div class="flex items-center justify-between mb-1">
              <span class="text-white font-bold flex items-center gap-1.5"><span>💬</span> SMS &amp; Webhooks</span>
              <span class="text-purple-400 font-mono font-bold">5%</span>
            </div>
            <div class="w-full h-2 rounded-full bg-dark overflow-hidden border border-dark-border">
              <div class="h-full bg-purple-500 rounded-full" style="width: 5%"></div>
            </div>
          </div>
        </div>

        <div class="pt-3 border-t border-dark-border flex items-center justify-between text-xs text-gray-400">
          <span>Avg First Response Time: <strong class="text-white font-mono"><?= $chatKpis['avg_frt_formatted'] ?></strong></span>
          <button onclick="switchCommandTab('tabInbox')" class="text-gold hover:underline font-bold">Open Inbox &rarr;</button>
        </div>
      </div>

    </div>

    <!-- Analytics Breakdown: Countries, Pages, Devices -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
      
      <!-- Top Countries -->
      <div class="lg:col-span-4 glass-card rounded-2xl border border-dark-border p-6 shadow-xl space-y-4">
        <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center justify-between">
          <span>Top Countries</span>
          <span>🌍</span>
        </h3>
        <?php if (empty($countries)): ?>
        <p class="text-xs text-gray-500 py-6 text-center">No country data for selected range.</p>
        <?php else: ?>
        <div class="space-y-3 max-h-[300px] overflow-y-auto pr-1">
          <?php foreach ($countries as $cName => $cCount): ?>
          <?php $pct = $totalFilteredCount > 0 ? round(($cCount / $totalFilteredCount) * 100) : 0; ?>
          <div class="space-y-1">
            <div class="flex items-center justify-between text-xs font-bold">
              <span class="text-white truncate"><?= htmlspecialchars($cName) ?></span>
              <span class="text-gold font-mono"><?= $cCount ?> (<?= $pct ?>%)</span>
            </div>
            <div class="w-full h-2 rounded-full bg-dark overflow-hidden border border-dark-border">
              <div class="h-full bg-gradient-to-r from-gold to-amber-500 rounded-full" style="width: <?= max($pct, 6) ?>%"></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>

      <!-- Top Landing Pages -->
      <div class="lg:col-span-4 glass-card rounded-2xl border border-dark-border p-6 shadow-xl space-y-4">
        <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center justify-between">
          <span>Top Landing Pages</span>
          <span>📄</span>
        </h3>
        <?php if (empty($pages)): ?>
        <p class="text-xs text-gray-500 py-6 text-center">No pageview data recorded.</p>
        <?php else: ?>
        <div class="space-y-3 max-h-[300px] overflow-y-auto pr-1">
          <?php foreach (array_slice($pages, 0, 6) as $pUrl => $pCount): ?>
          <?php 
            $pct = $totalFilteredCount > 0 ? round(($pCount / $totalFilteredCount) * 100) : 0; 
            $pInfo = formatPageSeoInfo((string)$pUrl);
          ?>
          <div class="p-2.5 rounded-xl bg-dark/60 border border-dark-border hover:border-gold/60 transition-all">
            <div class="flex items-center justify-between gap-2 mb-1">
              <a href="<?= htmlspecialchars($pInfo['href']) ?>" target="_blank" class="flex items-center gap-1.5 text-xs font-bold text-white hover:text-gold transition-colors truncate max-w-[200px]">
                <span><?= $pInfo['icon'] ?></span>
                <span class="truncate"><?= htmlspecialchars($pInfo['title']) ?></span>
              </a>
              <span class="text-xs font-mono font-black text-blue-400"><?= $pCount ?> views</span>
            </div>
            <div class="w-full h-1.5 rounded-full bg-dark overflow-hidden border border-dark-border">
              <div class="h-full bg-blue-500 rounded-full" style="width: <?= max($pct, 8) ?>%"></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>

      <!-- Device Share & Referrers -->
      <div class="lg:col-span-4 glass-card rounded-2xl border border-dark-border p-6 shadow-xl space-y-5">
        <div>
          <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Device Share</h3>
          <div class="grid grid-cols-3 gap-2 text-center text-xs">
            <div class="p-2.5 rounded-xl bg-dark/60 border border-dark-border">
              <div class="text-base mb-0.5">💻</div>
              <div class="font-bold text-white"><?= $devices['Desktop'] ?? 0 ?></div>
              <div class="text-[10px] text-gray-500">Desktop</div>
            </div>
            <div class="p-2.5 rounded-xl bg-dark/60 border border-dark-border">
              <div class="text-base mb-0.5">📱</div>
              <div class="font-bold text-white"><?= $devices['Mobile'] ?? 0 ?></div>
              <div class="text-[10px] text-gray-500">Mobile</div>
            </div>
            <div class="p-2.5 rounded-xl bg-dark/60 border border-dark-border">
              <div class="text-base mb-0.5">📟</div>
              <div class="font-bold text-white"><?= $devices['Tablet'] ?? 0 ?></div>
              <div class="text-[10px] text-gray-500">Tablet</div>
            </div>
          </div>
        </div>

        <div>
          <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Traffic Referrers</h3>
          <div class="space-y-1.5 max-h-[140px] overflow-y-auto text-xs">
            <?php foreach (array_slice($referrers, 0, 4) as $rName => $rCount): ?>
            <div class="flex items-center justify-between p-2 rounded-lg bg-dark/40 border border-dark-border">
              <span class="text-gray-300 truncate max-w-[180px]"><?= htmlspecialchars($rName) ?></span>
              <span class="text-emerald-400 font-mono font-bold"><?= $rCount ?></span>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

    </div>

  </div>

  <!-- ══════════════════════════════════════════════════════════════════
       TAB 2: LIVE VISITOR RADAR & INTERACTIVE GEO-MAP
       ══════════════════════════════════════════════════════════════════ -->
  <div id="tabRadar" class="tab-content hidden space-y-6">
    
    <!-- 3-State Presence Filters & Search Bar -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 glass-card p-4 rounded-2xl border border-dark-border">
      <div class="flex flex-wrap items-center gap-2">
        <button onclick="filterRadarState('all')" class="radar-filter-btn px-3 py-1.5 rounded-xl text-xs font-bold bg-gold text-dark shadow-glow">All (<?= $totalFilteredCount ?>)</button>
        <button onclick="filterRadarState('active')" class="radar-filter-btn px-3 py-1.5 rounded-xl text-xs font-bold bg-dark text-gray-400 border border-dark-border hover:border-emerald-500 hover:text-emerald-400 inline-flex items-center gap-1.5">
          <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
          <span>Active ≤60s (<?= $activeCount ?>)</span>
        </button>
        <button onclick="filterRadarState('idle')" class="radar-filter-btn px-3 py-1.5 rounded-xl text-xs font-bold bg-dark text-gray-400 border border-dark-border hover:border-amber-500 hover:text-amber-400 inline-flex items-center gap-1.5">
          <span class="w-2 h-2 rounded-full bg-amber-400"></span>
          <span>Idle 1–3m (<?= $idleCount ?>)</span>
        </button>
        <button onclick="filterRadarState('chatting')" class="radar-filter-btn px-3 py-1.5 rounded-xl text-xs font-bold bg-dark text-gray-400 border border-dark-border hover:border-gold hover:text-gold inline-flex items-center gap-1.5">
          <span>💬</span>
          <span>Chatting (<?= $chattingCount ?>)</span>
        </button>
      </div>

      <div class="relative min-w-[260px]">
        <input type="text" id="radarSearchInput" oninput="handleRadarSearch(this.value)" placeholder="Search IP, City, Country, URL..." 
               class="w-full bg-[#131322] border border-[#26263B] focus:border-gold rounded-xl px-3.5 py-2 text-xs text-white placeholder-gray-500 focus:outline-none transition-all">
      </div>
    </div>

    <!-- Live Visitors Table -->
    <div class="glass-card rounded-2xl border border-dark-border overflow-hidden shadow-2xl">
      <div class="overflow-x-auto">
        <table class="w-full text-left text-xs" id="radarVisitorsTable">
          <thead class="bg-[#141420] text-gray-400 font-mono uppercase tracking-wider text-[11px] border-b border-dark-border">
            <tr>
              <th class="p-4">Status</th>
              <th class="p-4">Visitor &amp; Location</th>
              <th class="p-4">IP &amp; ISP</th>
              <th class="p-4">Device &amp; OS</th>
              <th class="p-4">Current Page &amp; Intent</th>
              <th class="p-4">Dwell Time</th>
              <th class="p-4">Lead Score</th>
              <th class="p-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-dark-border" id="radarTableBody">
            <?php if (empty($filteredVisitors)): ?>
            <tr>
              <td colspan="8" class="p-8 text-center text-gray-500 font-mono">No visitor sessions recorded for selected range.</td>
            </tr>
            <?php else: ?>
            <?php foreach ($filteredVisitors as $vid => $v): ?>
            <?php 
              $state = $v['presence_state'] ?? 'recent';
              $lastTs = $v['last_seen_ts'] ?? strtotime($v['last_seen'] ?? '2000-01-01');
              $secs = intval($v['time_spent'] ?? 0);
              $timeStr = formatDurationHelper($secs);
              $pInfo = formatPageSeoInfo((string)($v['current_page'] ?? '/'));
              $mockScore = min(100, max(15, ($secs > 90 ? 40 : 15) + (isset($chats[$vid]) ? 40 : 0)));
            ?>
            <tr class="hover:bg-white/[0.02] transition-colors radar-row" data-state="<?= $state ?>" data-vid="<?= htmlspecialchars($vid) ?>">
              <td class="p-4">
                <?php if ($state === 'active'): ?>
                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold font-mono text-[10px]">
                  <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span> ONLINE
                </span>
                <?php elseif ($state === 'idle'): ?>
                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/30 font-bold font-mono text-[10px]">
                  <span class="w-1.5 h-1.5 rounded-full bg-amber-400"></span> IDLE
                </span>
                <?php elseif ($state === 'chatting'): ?>
                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-gold/20 text-gold border border-gold/30 font-bold font-mono text-[10px]">
                  <span>💬</span> CHATTING
                </span>
                <?php else: ?>
                <span class="inline-flex items-center px-2 py-0.5 rounded bg-gray-800 text-gray-400 font-mono text-[10px]">
                  RECENT
                </span>
                <?php endif; ?>
              </td>

              <td class="p-4 font-bold text-white">
                <div class="flex items-center gap-2">
                  <span class="text-base"><?= $v['flag'] ?? '🌐' ?></span>
                  <div>
                    <div><?= htmlspecialchars($v['city'] ?? 'London') ?></div>
                    <div class="text-[10px] text-gray-400 font-normal"><?= htmlspecialchars($v['country'] ?? 'United Kingdom') ?></div>
                  </div>
                </div>
              </td>

              <td class="p-4 font-mono text-gray-300">
                <div><?= htmlspecialchars($v['ip'] ?? '127.0.0.1') ?></div>
                <div class="text-[10px] text-gray-500 truncate max-w-[140px]"><?= htmlspecialchars($v['isp'] ?? 'Standard ISP') ?></div>
              </td>

              <td class="p-4">
                <div class="flex items-center gap-1.5">
                  <span class="px-2 py-0.5 rounded bg-dark border border-dark-border text-gold font-bold text-[10px]">
                    <?= htmlspecialchars($v['device'] ?? 'Desktop') ?>
                  </span>
                  <span class="text-gray-400 text-[11px]">
                    <?= htmlspecialchars($v['browser'] ?? 'Chrome') ?> (<?= htmlspecialchars($v['os'] ?? 'Windows') ?>)
                  </span>
                </div>
              </td>

              <td class="p-4">
                <a href="<?= htmlspecialchars($pInfo['href']) ?>" target="_blank" class="text-xs font-bold text-white hover:text-gold transition-colors inline-flex items-center gap-1.5 truncate max-w-[180px]">
                  <span><?= $pInfo['icon'] ?></span>
                  <span class="truncate"><?= htmlspecialchars($pInfo['title']) ?></span>
                  <span class="text-gold text-[10px]">↗</span>
                </a>
                <div class="text-[10px] text-gray-500 font-mono truncate max-w-[180px]"><?= htmlspecialchars($pInfo['path']) ?></div>
              </td>

              <td class="p-4 font-mono text-gold font-bold">
                <?= $timeStr ?>
              </td>

              <td class="p-4">
                <span class="px-2.5 py-1 rounded-lg text-[10px] font-mono font-black border <?= $mockScore >= 70 ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40' : ($mockScore >= 40 ? 'bg-amber-500/20 text-amber-400 border-amber-500/40' : 'bg-blue-500/20 text-blue-400 border-blue-500/40') ?>">
                  ★ <?= $mockScore ?> / 100
                </span>
              </td>

              <td class="p-4 text-right">
                <div class="flex items-center justify-end gap-1.5">
                  <button onclick="openVisitorDrawer('<?= htmlspecialchars($vid) ?>')" class="px-2.5 py-1.5 rounded-lg bg-dark border border-dark-border hover:border-gold text-gray-300 hover:text-white font-bold text-[11px] transition-all" title="Inspect Timeline &amp; Telemetry">
                    🔍 Journey
                  </button>
                  <button onclick="quickStartChat('<?= htmlspecialchars($vid) ?>')" class="px-2.5 py-1.5 rounded-lg bg-gold text-dark hover:bg-amber-400 font-black text-[11px] shadow-glow transition-all" title="Open 2-Way Chat">
                    💬 Chat
                  </button>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>

  <!-- ══════════════════════════════════════════════════════════════════
       TAB 3: OMNICHANNEL SHARED INBOX & REAL-TIME LIVE CHAT
       ══════════════════════════════════════════════════════════════════ -->
  <div id="tabInbox" class="tab-content hidden space-y-4">
    
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      
      <!-- Left Column: Channel Filter & Conversation Stream (4 Cols) -->
      <div class="lg:col-span-4 glass-card rounded-2xl border border-dark-border p-5 shadow-xl space-y-4 h-[760px] flex flex-col">
        
        <!-- Channels Filter Tabs -->
        <div class="flex items-center gap-1.5 border-b border-dark-border pb-3.5 overflow-x-auto text-xs">
          <button onclick="filterInboxChannel('all')" class="inbox-chan-btn px-3 py-2 rounded-xl font-black bg-gold text-dark shadow-glow">All</button>
          <button onclick="filterInboxChannel('web')" class="inbox-chan-btn px-3 py-2 rounded-xl font-bold bg-dark text-gray-300 border border-dark-border hover:border-gold hover:text-white">🌐 Web</button>
          <button onclick="filterInboxChannel('whatsapp')" class="inbox-chan-btn px-3 py-2 rounded-xl font-bold bg-dark text-gray-300 border border-dark-border hover:border-emerald-500 hover:text-emerald-400">📱 WhatsApp</button>
          <button onclick="filterInboxChannel('email')" class="inbox-chan-btn px-3 py-2 rounded-xl font-bold bg-dark text-gray-300 border border-dark-border hover:border-blue-500 hover:text-blue-400">✉️ Email</button>
        </div>

        <!-- Conversation Cards List -->
        <div class="flex-1 overflow-y-auto space-y-2.5 pr-1.5 scrollbar-thin" id="inboxConversationsList">
          <?php if (empty($chats)): ?>
          <div class="p-8 text-center text-gray-400 text-sm font-medium">
            No live conversations yet. Audio chime will alert on incoming messages.
          </div>
          <?php else: ?>
          <?php foreach ($chats as $vid => $chat): ?>
          <?php 
            $msgCount = count($chat['messages'] ?? []);
            $lastMsg = !empty($chat['messages']) ? end($chat['messages'])['text'] : 'Started chat session';
            $hasUnread = !empty($chat['has_unread_for_agent']);
          ?>
          <div onclick="selectAgentChat('<?= htmlspecialchars($vid) ?>')" class="chat-card p-4 rounded-xl bg-dark/70 border <?= $hasUnread ? 'border-amber-500 bg-amber-950/30' : 'border-dark-border' ?> hover:border-gold/60 cursor-pointer transition-all group" id="chatCard-<?= htmlspecialchars($vid) ?>">
            <div class="flex items-center justify-between text-sm mb-1.5">
              <div class="flex items-center gap-2 font-bold text-white">
                <span class="text-base"><?= $chat['flag'] ?? '🌐' ?></span>
                <span class="text-white font-black"><?= htmlspecialchars($chat['city'] ?? 'London') ?></span>
                <span class="px-2 py-0.5 rounded bg-white/10 text-xs text-gray-300 font-mono">Web</span>
                <?php if ($hasUnread): ?>
                <span class="px-2 py-0.5 rounded bg-amber-500 text-dark font-black text-xs animate-pulse">NEW</span>
                <?php endif; ?>
              </div>
              <span class="text-xs font-mono text-gray-400 font-bold"><?= date('H:i', strtotime($chat['last_active'] ?? 'now')) ?></span>
            </div>
            <p class="text-gray-300 text-sm line-clamp-2 leading-relaxed font-normal">
              <?= htmlspecialchars(strip_tags($lastMsg)) ?>
            </p>
            <div class="flex items-center justify-between mt-2.5 text-xs text-gray-400">
              <span class="font-mono text-gray-400 font-bold"><?= htmlspecialchars($vid) ?></span>
              <span class="text-gold font-bold text-xs"><?= $msgCount ?> msgs &rarr;</span>
            </div>
          </div>
          <?php endforeach; ?>
          <?php endif; ?>
        </div>

      </div>

      <!-- Center Column: 2-Way Live Chat Console (5 Cols) -->
      <div class="lg:col-span-5 glass-card rounded-2xl border border-dark-border p-5 shadow-2xl flex flex-col h-[760px]">
        
        <!-- Console Header -->
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-dark-border pb-3.5 mb-2">
          <div>
            <h3 id="consoleChatTitle" class="text-base font-black text-white flex items-center gap-2">
              <span>Select a Conversation</span>
            </h3>
            <div id="consoleChatMeta" class="text-xs text-gray-300 mt-0.5">Click any live session on the left to start real-time messaging.</div>
          </div>

          <div class="flex items-center gap-2">
            <select id="activeAgentSelector" class="bg-[#141420] border border-dark-border text-gold font-black text-xs rounded-xl px-3 py-2 focus:border-gold outline-none">
              <option value="Alice | Lead Retoucher" selected>Alice (Lead Retoucher)</option>
              <option value="Ashley | Production Director">Ashley (Production Director)</option>
              <option value="Martin | Studio Operations">Martin (Studio Operations)</option>
              <option value="Estate HDR Live Support">Estate HDR Support</option>
            </select>
          </div>
        </div>

        <!-- 👁️ Real-Time Visitor Typing Sneak-Peek Alert Banner -->
        <div id="visitorTypingAlertBox" class="hidden p-3 mb-2 rounded-xl bg-gold/15 border border-gold/50 text-gold text-xs flex items-center gap-2 font-mono font-bold">
          <span class="w-2.5 h-2.5 rounded-full bg-gold animate-ping"></span>
          <span>Client is typing: <strong id="typingSneakPeekText" class="text-white italic">...</strong></span>
        </div>

        <!-- Messages Stream -->
        <div id="consoleMessagesStream" class="flex-1 overflow-y-auto space-y-3.5 p-3 text-sm scrollbar-thin">
          <div class="h-full flex items-center justify-center text-gray-400 text-center font-medium">
            <div>
              <div class="text-4xl mb-3">💬</div>
              <div class="text-sm">Select any live session on the left to talk directly with the client.</div>
            </div>
          </div>
        </div>

        <!-- 🧠 Real-Time AI Brain Co-Pilot Draft Suggestion Box -->
        <div id="aiCoPilotBox" class="hidden p-3 mb-2 rounded-2xl bg-gradient-to-r from-[#18182E] via-[#1E1E38] to-[#161628] border border-gold/40 text-xs space-y-2 shadow-xl">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <span class="px-2 py-0.5 rounded-full bg-gold/20 text-gold font-mono font-bold text-[10px] uppercase flex items-center gap-1">
                <span>🧠</span> AI Brain Suggestion
              </span>
              <span class="text-gray-400 text-[11px]" id="aiDraftQueryContext">Based on client's latest query</span>
            </div>
            <div class="flex items-center gap-2">
              <button type="button" onclick="fetchAiSuggestedReply()" class="text-[11px] text-gray-300 hover:text-gold flex items-center gap-1 transition-colors" title="Regenerate draft">
                <span>🔄</span> Regenerate
              </button>
              <button type="button" onclick="openCannedStudioModal()" class="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-gold/20 text-gray-200 hover:text-gold border border-white/10 text-[11px] font-bold transition-all">
                📚 All Canned (14+)
              </button>
            </div>
          </div>
          <div id="aiDraftPreviewText" class="p-2.5 rounded-xl bg-dark/70 border border-dark-border text-gray-200 text-xs leading-relaxed max-h-24 overflow-y-auto italic font-normal">
            Select a conversation to generate an intelligent AI reply draft...
          </div>
          <div class="flex items-center justify-end gap-2 pt-0.5">
            <button type="button" onclick="insertAiDraftIntoInput()" class="px-3.5 py-1.5 rounded-xl bg-gold hover:bg-amber-400 text-dark font-black text-xs shadow-glow flex items-center gap-1.5 transition-all">
              <span>⚡</span> <span>Insert AI Draft</span>
            </button>
          </div>
        </div>

        <!-- Quick Canned Replies & Slash Shortcuts -->
        <div id="consoleQuickChips" class="hidden py-2 flex flex-wrap items-center gap-1.5 border-t border-dark-border/60 text-xs">
          <span class="text-[11px] text-gray-400 font-bold uppercase py-1 mr-1 flex items-center gap-1"><span>⚡</span> Quick:</span>
          <button onclick="insertCanned('Hi there! I am Alice, senior retouching director at Estate HDR. How can I assist you with your photos or staging today?')" class="px-2.5 py-1 rounded-lg bg-[#161626] border border-[#2E2E46] hover:border-gold text-gray-200 hover:text-white font-medium text-[11px]">👋 /hi</button>
          <button onclick="insertCanned('You can claim 3 Free Sample Edits with guaranteed 24-hour turnaround and zero payment or credit card required! Would you like to share your RAW bracket link?')" class="px-2.5 py-1 rounded-lg bg-[#161626] border border-[#2E2E46] hover:border-gold text-gray-200 hover:text-white font-medium text-[11px]">🎁 /trial</button>
          <button onclick="insertCanned('Our standard delivery is guaranteed within 24 Hours for all residential HDR orders. We also provide 12-Hour Rush processing upon request!')" class="px-2.5 py-1 rounded-lg bg-[#161626] border border-[#2E2E46] hover:border-gold text-gray-200 hover:text-white font-medium text-[11px]">⏱️ /turnaround</button>
          <button onclick="insertCanned('Our volume pricing is transparent: HDR Photo Editing from $0.80/photo, 3D Virtual Staging at $8.00/room, Twilight $4.00, and Item Removal $2.00.')" class="px-2.5 py-1 rounded-lg bg-[#161626] border border-[#2E2E46] hover:border-gold text-gray-200 hover:text-white font-medium text-[11px]">💰 /pricing</button>
          <button onclick="insertCanned('We perform 100% manual layer masking in Photoshop for clean window pulls with zero dark halos, and neutralize ceiling/wall color casts to pure white.')" class="px-2.5 py-1 rounded-lg bg-[#161626] border border-[#2E2E46] hover:border-gold text-gray-200 hover:text-white font-medium text-[11px]">🪟 /window</button>
          <button onclick="openCannedStudioModal()" class="px-2.5 py-1 rounded-lg bg-gold/15 border border-gold/30 hover:bg-gold text-gold hover:text-dark font-black text-[11px] ml-auto transition-all">
            + More Canned
          </button>
        </div>

        <!-- Agent Message Input & Mode Switch -->
        <div id="consoleInputArea" class="hidden pt-3 border-t border-dark-border space-y-2.5">
          <div class="flex items-center justify-between text-xs">
            <div class="flex items-center gap-3">
              <label class="inline-flex items-center gap-1.5 cursor-pointer">
                <input type="radio" name="replyMode" value="public" checked onchange="toggleReplyMode(this.value)" class="text-gold focus:ring-0">
                <span class="font-bold text-white">💬 Public Reply</span>
              </label>
              <label class="inline-flex items-center gap-1.5 cursor-pointer">
                <input type="radio" name="replyMode" value="private" onchange="toggleReplyMode(this.value)" class="text-amber-400 focus:ring-0">
                <span class="font-bold text-amber-400">🔒 Internal Note</span>
              </label>
            </div>
            <div class="flex items-center gap-3">
              <button type="button" onclick="openQuoteCalculatorModal()" class="text-emerald-400 hover:underline font-bold text-xs flex items-center gap-1">
                <span>🧮</span> Calc Quote
              </button>
              <button type="button" onclick="fetchAiSuggestedReply()" class="text-gold hover:underline font-bold text-xs flex items-center gap-1">
                <span>🧠</span> AI Auto-Draft
              </button>
              <button type="button" onclick="convertChatToTicket()" class="text-purple-400 hover:underline font-bold text-xs">🎫 1-Click Ticket</button>
            </div>
          </div>

          <form onsubmit="handleAgentMessageSubmit(event)" class="flex items-center gap-2.5">
            <input type="text" id="agentReplyInput" placeholder="Type reply or shortcut (/pricing, /trial, /window, /rush)..." 
                   class="flex-1 bg-[#131322] border border-[#2B2B42] focus:border-gold rounded-xl px-4 py-3 text-sm text-white placeholder-gray-400 focus:outline-none transition-all font-medium">
            <button type="submit" id="agentSendBtn" class="px-5 py-3 rounded-xl bg-gold hover:bg-amber-400 text-dark font-black text-sm shadow-glow transition-all flex-shrink-0">
              Send &rarr;
            </button>
          </form>
        </div>

      </div>

      <!-- Right Column: Contact Dossier & Context (3 Cols) -->
      <div class="lg:col-span-3 glass-card rounded-2xl border border-dark-border p-5 shadow-xl space-y-4 h-[760px] overflow-y-auto">
        <h3 class="text-xs font-bold text-gray-300 uppercase tracking-wider border-b border-dark-border pb-2.5">Client Context Dossier</h3>
        
        <div id="inboxDossierContent" class="space-y-4 text-sm">
          <div class="p-3.5 rounded-xl bg-dark/70 border border-dark-border space-y-1.5">
            <div class="text-xs text-gray-400 uppercase font-mono font-bold">Visitor ID</div>
            <div class="font-mono text-gold font-black text-sm truncate" id="dossierVid">Select a chat</div>
          </div>

          <div class="p-3.5 rounded-xl bg-dark/70 border border-dark-border space-y-1.5">
            <div class="text-xs text-gray-400 uppercase font-mono font-bold">Lead Temperature</div>
            <div class="flex items-center justify-between">
              <span class="font-bold text-white text-sm" id="dossierLeadStage">Warm Lead</span>
              <span class="px-2.5 py-1 rounded bg-amber-500/20 text-amber-400 font-mono text-xs font-bold" id="dossierLeadScoreBadge">🔥 65/100</span>
            </div>
          </div>

          <div class="p-3.5 rounded-xl bg-dark/70 border border-dark-border space-y-1.5">
            <div class="text-xs text-gray-400 uppercase font-mono font-bold">Active Page Context</div>
            <div class="font-bold text-white text-sm truncate" id="dossierPage">/services/hdr-photo-editing</div>
            <div class="text-xs text-gray-300 mt-1" id="dossierReferrer">Direct Google Search</div>
          </div>

          <div class="pt-2">
            <button onclick="promoteVisitorToLead()" class="w-full py-3 rounded-xl bg-gradient-to-r from-gold to-amber-500 text-dark font-black text-sm shadow-glow transition-all">
              💼 Promote to CRM Lead
            </button>
          </div>
        </div>
      </div>

    </div>

  </div>

  <!-- ══════════════════════════════════════════════════════════════════
       TAB 4: INTEGRATED CRM & DYNAMIC LEAD SCORING
       ══════════════════════════════════════════════════════════════════ -->
  <div id="tabCrm" class="tab-content hidden space-y-6">
    
    <!-- CRM Funnel Header -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 glass-card p-5 rounded-2xl border border-dark-border">
      <div>
        <h2 class="text-base font-black text-white">Dynamic Lead Scoring &amp; Client Pipeline</h2>
        <p class="text-xs text-gray-400 mt-0.5">Automated 0–100 behavioral scoring based on pricing visits, chat engagement, and bracket uploads.</p>
      </div>
      <div class="flex flex-wrap items-center gap-2">
        <a href="/admin/export-leads.php?type=all" class="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-md transition-all inline-flex items-center gap-1.5" title="Export all leads and clients to CSV for Email Marketing (Mailchimp, Brevo, Klaviyo, HubSpot)">
          <span>📥</span> <span>Export Leads CSV</span>
        </a>
        <a href="/admin/export-leads.php?type=hot" class="px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 border border-amber-500/40 font-bold text-xs transition-all inline-flex items-center gap-1.5" title="Export Hot Intent Leads (Score 70+)">
          <span>🔥</span> <span>Hot Leads CSV</span>
        </a>
        <a href="/admin/leads.php" class="px-3.5 py-2 rounded-xl bg-gold text-dark font-black text-xs shadow-glow transition-all">
          Manage Leads &rarr;
        </a>
      </div>
    </div>

    <!-- Lead Pipeline Funnel Stages (Kanban Style) -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
      
      <!-- Stage 1: New / Cold (0-29) -->
      <div class="glass-card rounded-2xl border border-dark-border p-4 shadow-xl space-y-3">
        <div class="flex items-center justify-between border-b border-dark-border pb-2 text-xs font-bold">
          <span class="text-blue-400 flex items-center gap-1.5"><span>❄️</span> New Inquiries (0–29)</span>
          <span class="font-mono text-gray-400"><?= $leadKpis['pipeline_breakdown']['new'] ?></span>
        </div>
        <div class="space-y-2.5">
          <?php 
            $shownCount = 0;
            foreach ($leads as $l):
              $st = strtolower($l['status'] ?? 'new');
              if ($st !== 'pending' && $st !== 'new') continue;
              $shownCount++;
              if ($shownCount > 3) break;
          ?>
          <div class="p-3 rounded-xl bg-dark/70 border border-dark-border hover:border-blue-500/50 transition-all space-y-1.5">
            <div class="flex items-center justify-between text-xs font-bold text-white">
              <span class="truncate"><?= htmlspecialchars($l['name'] ?? 'Lead') ?></span>
              <span class="px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400 font-mono text-[9px]">25 PTS</span>
            </div>
            <div class="text-[11px] text-gray-400 truncate"><?= htmlspecialchars($l['email'] ?? 'No email') ?></div>
            <div class="text-[10px] text-gray-500 font-mono">Service: <?= htmlspecialchars($l['service'] ?? 'General') ?></div>
          </div>
          <?php endforeach; ?>
          <?php if ($shownCount === 0): ?>
          <p class="text-xs text-gray-500 py-3 text-center">No new inquiries.</p>
          <?php endif; ?>
        </div>
      </div>

      <!-- Stage 2: Contacted / Warm (30-59) -->
      <div class="glass-card rounded-2xl border border-dark-border p-4 shadow-xl space-y-3">
        <div class="flex items-center justify-between border-b border-dark-border pb-2 text-xs font-bold">
          <span class="text-amber-400 flex items-center gap-1.5"><span>🔥</span> Warm Prospect (30–59)</span>
          <span class="font-mono text-gray-400"><?= $leadKpis['pipeline_breakdown']['contacted'] ?></span>
        </div>
        <div class="space-y-2.5">
          <?php 
            $shownCount = 0;
            foreach ($leads as $l):
              $st = strtolower($l['status'] ?? 'new');
              if ($st !== 'contacted') continue;
              $shownCount++;
              if ($shownCount > 3) break;
          ?>
          <div class="p-3 rounded-xl bg-dark/70 border border-dark-border hover:border-amber-500/50 transition-all space-y-1.5">
            <div class="flex items-center justify-between text-xs font-bold text-white">
              <span class="truncate"><?= htmlspecialchars($l['name'] ?? 'Lead') ?></span>
              <span class="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 font-mono text-[9px]">55 PTS</span>
            </div>
            <div class="text-[11px] text-gray-400 truncate"><?= htmlspecialchars($l['email'] ?? 'No email') ?></div>
            <div class="text-[10px] text-gray-500 font-mono">Service: <?= htmlspecialchars($l['service'] ?? 'Virtual Staging') ?></div>
          </div>
          <?php endforeach; ?>
          <?php if ($shownCount === 0): ?>
          <p class="text-xs text-gray-500 py-3 text-center">No contacted leads.</p>
          <?php endif; ?>
        </div>
      </div>

      <!-- Stage 3: Qualified / Hot (60-89) -->
      <div class="glass-card rounded-2xl border border-dark-border p-4 shadow-xl space-y-3">
        <div class="flex items-center justify-between border-b border-dark-border pb-2 text-xs font-bold">
          <span class="text-gold flex items-center gap-1.5"><span>⚡</span> High Intent (60–89)</span>
          <span class="font-mono text-gray-400"><?= $leadKpis['pipeline_breakdown']['qualified'] ?></span>
        </div>
        <div class="space-y-2.5">
          <?php 
            $shownCount = 0;
            foreach ($leads as $l):
              $st = strtolower($l['status'] ?? 'new');
              if ($st !== 'qualified') continue;
              $shownCount++;
              if ($shownCount > 3) break;
          ?>
          <div class="p-3 rounded-xl bg-dark/70 border border-dark-border hover:border-gold/50 transition-all space-y-1.5">
            <div class="flex items-center justify-between text-xs font-bold text-white">
              <span class="truncate"><?= htmlspecialchars($l['name'] ?? 'Lead') ?></span>
              <span class="px-1.5 py-0.5 rounded bg-gold/20 text-gold font-mono text-[9px]">85 PTS</span>
            </div>
            <div class="text-[11px] text-gray-400 truncate"><?= htmlspecialchars($l['email'] ?? 'No email') ?></div>
            <div class="text-[10px] text-gray-500 font-mono">Link: <?= htmlspecialchars(substr($l['cloud_link'] ?? 'None', 0, 25)) ?>...</div>
          </div>
          <?php endforeach; ?>
          <?php if ($shownCount === 0): ?>
          <p class="text-xs text-gray-500 py-3 text-center">No high intent leads.</p>
          <?php endif; ?>
        </div>
      </div>

      <!-- Stage 4: Won / Account Ready (90-100) -->
      <div class="glass-card rounded-2xl border border-dark-border p-4 shadow-xl space-y-3">
        <div class="flex items-center justify-between border-b border-dark-border pb-2 text-xs font-bold">
          <span class="text-emerald-400 flex items-center gap-1.5"><span>🏆</span> Won &amp; Converted (90–100)</span>
          <span class="font-mono text-gray-400"><?= $leadKpis['pipeline_breakdown']['won'] ?></span>
        </div>
        <div class="space-y-2.5">
          <?php 
            $shownCount = 0;
            foreach ($leads as $l):
              $st = strtolower($l['status'] ?? 'new');
              if ($st !== 'delivered' && $st !== 'won') continue;
              $shownCount++;
              if ($shownCount > 3) break;
          ?>
          <div class="p-3 rounded-xl bg-dark/70 border border-emerald-500/40 bg-emerald-950/10 space-y-1.5">
            <div class="flex items-center justify-between text-xs font-bold text-white">
              <span class="truncate"><?= htmlspecialchars($l['name'] ?? 'Lead') ?></span>
              <span class="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono text-[9px]">100 PTS</span>
            </div>
            <div class="text-[11px] text-gray-400 truncate"><?= htmlspecialchars($l['email'] ?? 'No email') ?></div>
            <div class="text-[10px] text-emerald-400 font-mono">Delivered Sample (ID: <?= htmlspecialchars($l['id']) ?>)</div>
          </div>
          <?php endforeach; ?>
          <?php if ($shownCount === 0): ?>
          <p class="text-xs text-gray-500 py-3 text-center">No won leads yet.</p>
          <?php endif; ?>
        </div>
      </div>

    </div>

  </div>

  <!-- ══════════════════════════════════════════════════════════════════
       TAB 5: BEHAVIORAL TRIGGERS & CHAT WIDGET STUDIO
       ══════════════════════════════════════════════════════════════════ -->
  <div id="tabTriggers" class="tab-content hidden space-y-6">
    
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      
      <!-- Left Panel: Behavioral Triggers Engine (6 Cols) -->
      <div class="lg:col-span-6 glass-card rounded-2xl border border-dark-border p-6 shadow-xl space-y-5">
        <div class="flex items-center justify-between border-b border-dark-border pb-3">
          <div>
            <h3 class="text-sm font-black text-white flex items-center gap-2">
              <span>⚡</span> <span>Behavioral Triggers &amp; Automations</span>
            </h3>
            <p class="text-xs text-gray-400 mt-0.5">Auto-engage visitors when high intent or hesitation is detected.</p>
          </div>
          <button onclick="alert('Rule configuration saved.')" class="px-3 py-1.5 rounded-xl bg-gold text-dark font-black text-xs shadow-glow transition-all">+ Add Rule</button>
        </div>

        <div class="space-y-3">
          
          <!-- Trigger 1: Pricing Page Dwell -->
          <div class="p-4 rounded-xl bg-dark/60 border border-dark-border space-y-2">
            <div class="flex items-center justify-between">
              <span class="font-bold text-xs text-white">Pricing Page Dwell &gt; 45s</span>
              <label class="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" checked class="sr-only peer">
                <div class="w-9 h-5 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-gold"></div>
              </label>
            </div>
            <p class="text-xs text-gray-400">If visitor spends &gt;45s on <code class="text-gold font-mono">/pricing.php</code>, pop greeting with 3 Free Sample Trial offer.</p>
          </div>

          <!-- Trigger 2: Exit Intent Checkout -->
          <div class="p-4 rounded-xl bg-dark/60 border border-dark-border space-y-2">
            <div class="flex items-center justify-between">
              <span class="font-bold text-xs text-white">Exit Intent on Order Form</span>
              <label class="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" checked class="sr-only peer">
                <div class="w-9 h-5 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-gold"></div>
              </label>
            </div>
            <p class="text-xs text-gray-400">When mouse leaves window on <code class="text-gold font-mono">/order-new.php</code>, trigger 10% first-order discount assistance.</p>
          </div>

          <!-- Trigger 3: First Time Visitor Welcome -->
          <div class="p-4 rounded-xl bg-dark/60 border border-dark-border space-y-2">
            <div class="flex items-center justify-between">
              <span class="font-bold text-xs text-white">First-Time Visitor Welcome</span>
              <label class="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" checked class="sr-only peer">
                <div class="w-9 h-5 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-gold"></div>
              </label>
            </div>
            <p class="text-xs text-gray-400">After 15s on homepage, Alice persona sends gentle introduction chime.</p>
          </div>

        </div>
      </div>

      <!-- Right Panel: Chat Widget Studio & Live Preview (6 Cols) -->
      <div class="lg:col-span-6 glass-card rounded-2xl border border-dark-border p-6 shadow-xl space-y-5">
        <div class="border-b border-dark-border pb-3">
          <h3 class="text-sm font-black text-white flex items-center gap-2">
            <span>🎨</span> <span>Chat Widget Studio &amp; Real-Time Preview</span>
          </h3>
          <p class="text-xs text-gray-400 mt-0.5">Customize widget theme, avatar, greeting text, and live preview immediately.</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label class="block text-[11px] font-bold text-gray-400 uppercase mb-1">Agent Title</label>
            <input type="text" id="widgetTitleInput" oninput="updateWidgetPreview()" value="Alice | Retouching Director" 
                   class="w-full bg-[#131322] border border-[#26263B] focus:border-gold rounded-xl px-3 py-2 text-xs text-white">
          </div>
          <div>
            <label class="block text-[11px] font-bold text-gray-400 uppercase mb-1">Accent Theme Color</label>
            <select id="widgetThemeSelector" onchange="updateWidgetPreview()" class="w-full bg-[#131322] border border-[#26263B] focus:border-gold rounded-xl px-3 py-2 text-xs text-gold font-bold">
              <option value="gold" selected>Luxury Gold (#C9A84C)</option>
              <option value="emerald">Studio Emerald (#10B981)</option>
              <option value="sapphire">Modern Sapphire (#3B82F6)</option>
            </select>
          </div>
        </div>

        <div>
          <label class="block text-[11px] font-bold text-gray-400 uppercase mb-1">Welcome Greeting Message</label>
          <textarea id="widgetGreetingInput" oninput="updateWidgetPreview()" rows="2" 
                    class="w-full bg-[#131322] border border-[#26263B] focus:border-gold rounded-xl p-3 text-xs text-white">Hi there! 👋 Welcome to Estate HDR. Claim 3 Free Sample Edits with 24h turnaround!</textarea>
        </div>

        <!-- Live Widget Interactive Preview Box -->
        <div>
          <div class="text-[11px] font-bold text-gray-400 uppercase mb-2">Live Interactive Widget Preview</div>
          <div class="p-4 rounded-2xl bg-[#08080C] border border-dark-border flex justify-end">
            
            <div class="w-72 rounded-2xl border border-dark-border bg-[#111118] shadow-2xl overflow-hidden text-xs" id="previewWidgetFrame">
              <div class="p-3 bg-gold text-dark font-black flex items-center justify-between" id="previewWidgetHeader">
                <div class="flex items-center gap-2">
                  <div class="w-6 h-6 rounded-full bg-dark text-gold flex items-center justify-center text-[10px] font-black">A</div>
                  <span id="previewWidgetTitle">Alice | Retouching Director</span>
                </div>
                <span>✕</span>
              </div>
              <div class="p-3 space-y-2 min-h-[110px] bg-[#0A0A0F]">
                <div class="p-2.5 rounded-xl rounded-tl-none bg-[#161622] text-gray-200 border border-dark-border text-[11px] leading-relaxed" id="previewWidgetGreeting">
                  Hi there! 👋 Welcome to Estate HDR. Claim 3 Free Sample Edits with 24h turnaround!
                </div>
              </div>
              <div class="p-2.5 border-t border-dark-border bg-[#111118] flex items-center gap-1.5">
                <input type="text" disabled placeholder="Type a message..." class="flex-1 bg-[#161622] border border-dark-border rounded-lg px-2 py-1 text-[10px] text-gray-400">
                <button class="px-2 py-1 rounded-lg bg-gold text-dark font-bold text-[10px]">Send</button>
              </div>
            </div>

          </div>
        </div>

      </div>

      <!-- Bottom Panel: Discord Intelligence & Real-Time Alert Engine (12 Cols) -->
      <div class="lg:col-span-12 glass-card rounded-2xl border border-indigo-500/30 bg-gradient-to-br from-indigo-950/20 to-dark-card p-6 shadow-2xl space-y-6">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-dark-border pb-4">
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-xl">
              🤖
            </div>
            <div>
              <div class="flex items-center gap-2">
                <h3 class="text-sm font-black text-white">Discord Intelligence &amp; Real-Time Alert Engine</h3>
                <span class="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono font-bold flex items-center gap-1">
                  <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  <?= !empty($discordCfg['enabled']) && !empty($discordCfg['webhook_url']) ? 'CONNECTED &amp; ACTIVE' : 'DISCONNECTED' ?>
                </span>
              </div>
              <p class="text-xs text-gray-400 mt-0.5">Stream real-time visitor landings, incoming live chat messages, and daily executive digests directly to Discord.</p>
            </div>
          </div>

          <div class="flex items-center gap-2">
            <form method="POST" class="inline">
              <?= csrfField() ?>
              <input type="hidden" name="discord_action" value="send_test_alert">
              <button type="submit" class="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg transition-all flex items-center gap-1.5">
                <span>🚀 Send Test Alert</span>
              </button>
            </form>

            <form method="POST" class="inline">
              <?= csrfField() ?>
              <input type="hidden" name="discord_action" value="send_daily_digest">
              <button type="submit" class="px-4 py-2 rounded-xl bg-gold hover:bg-amber-400 text-dark font-black text-xs shadow-glow transition-all flex items-center gap-1.5">
                <span>📊 Send Daily Report Now</span>
              </button>
            </form>
          </div>
        </div>

        <form method="POST" class="space-y-4">
          <?= csrfField() ?>
          <input type="hidden" name="discord_action" value="save_settings">

          <div>
            <label class="block text-xs font-bold text-gray-300 mb-1.5">Discord Channel Webhook URL</label>
            <div class="flex items-center gap-2">
              <input type="url" name="webhook_url" value="<?= htmlspecialchars($discordCfg['webhook_url'] ?? '') ?>" placeholder="https://discord.com/api/webhooks/..." required 
                     class="flex-1 bg-[#131322] border border-[#26263B] focus:border-indigo-500 rounded-xl px-4 py-2.5 text-xs text-white font-mono">
              <button type="submit" class="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg transition-all">
                Save Settings
              </button>
            </div>
            <p class="text-[11px] text-gray-500 mt-1">Generated via Discord Server &rarr; Channel Settings &rarr; Integrations &rarr; Webhooks.</p>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
            <label class="p-3.5 rounded-xl bg-dark/60 border border-dark-border flex items-center justify-between cursor-pointer hover:border-indigo-500/40 transition-colors">
              <div>
                <div class="text-xs font-bold text-white">Master Discord Engine</div>
                <div class="text-[10px] text-gray-400">Enable or pause all alerts</div>
              </div>
              <input type="checkbox" name="discord_enabled" value="1" <?= !empty($discordCfg['enabled']) ? 'checked' : '' ?> class="w-4 h-4 rounded text-indigo-600 focus:ring-0 bg-dark border-dark-border">
            </label>

            <label class="p-3.5 rounded-xl bg-dark/60 border border-dark-border flex items-center justify-between cursor-pointer hover:border-indigo-500/40 transition-colors">
              <div>
                <div class="text-xs font-bold text-white">New Visitor Landed</div>
                <div class="text-[10px] text-gray-400">Ping when client arrives</div>
              </div>
              <input type="checkbox" name="notify_new_visitor" value="1" <?= !empty($discordCfg['notify_new_visitor']) ? 'checked' : '' ?> class="w-4 h-4 rounded text-indigo-600 focus:ring-0 bg-dark border-dark-border">
            </label>

            <label class="p-3.5 rounded-xl bg-dark/60 border border-dark-border flex items-center justify-between cursor-pointer hover:border-indigo-500/40 transition-colors">
              <div>
                <div class="text-xs font-bold text-white">Incoming Live Chat</div>
                <div class="text-[10px] text-gray-400">Instant client message alert</div>
              </div>
              <input type="checkbox" name="notify_live_chat" value="1" <?= !empty($discordCfg['notify_live_chat']) ? 'checked' : '' ?> class="w-4 h-4 rounded text-indigo-600 focus:ring-0 bg-dark border-dark-border">
            </label>

            <label class="p-3.5 rounded-xl bg-dark/60 border border-dark-border flex items-center justify-between cursor-pointer hover:border-indigo-500/40 transition-colors">
              <div>
                <div class="text-xs font-bold text-white">Daily 09:00 PM Digest</div>
                <div class="text-[10px] text-gray-400">Automated executive report</div>
              </div>
              <input type="checkbox" name="notify_daily_digest" value="1" <?= !empty($discordCfg['notify_daily_digest']) ? 'checked' : '' ?> class="w-4 h-4 rounded text-indigo-600 focus:ring-0 bg-dark border-dark-border">
            </label>
          </div>
        </form>
      </div>

    </div>

  </div>

  <!-- ══════════════════════════════════════════════════════════════════
       TAB 6: SUPPORT TICKETING & KNOWLEDGE BASE CENTER
       ══════════════════════════════════════════════════════════════════ -->
  <div id="tabTickets" class="tab-content hidden space-y-6">
    
    <!-- Section 1: Support Tickets Queue -->
    <div class="glass-card rounded-2xl border border-dark-border p-6 shadow-xl space-y-5">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-dark-border pb-4">
        <div>
          <h3 class="text-sm font-black text-white flex items-center gap-2">
            <span>🎫</span> <span>SLA-Managed Support Ticketing Queue</span>
          </h3>
          <p class="text-xs text-gray-400 mt-0.5">Track inquiries converted from chat and web with strict SLA response deadlines.</p>
        </div>
        <button onclick="alert('Support ticket creation modal initialized.')" class="px-4 py-2 rounded-xl bg-gold text-dark font-black text-xs shadow-glow transition-all">+ Create Ticket</button>
      </div>

      <div class="overflow-x-auto">
        <table class="w-full text-left text-xs">
          <thead class="bg-[#141420] text-gray-400 font-mono uppercase tracking-wider text-[11px] border-b border-dark-border">
            <tr>
              <th class="p-3.5">Ticket ID</th>
              <th class="p-3.5">Subject &amp; Requester</th>
              <th class="p-3.5">Department</th>
              <th class="p-3.5">Priority &amp; SLA</th>
              <th class="p-3.5">Status</th>
              <th class="p-3.5 text-right">Actions</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-dark-border">
            <?php if (empty($tickets)): ?>
            <tr class="hover:bg-white/[0.02]">
              <td class="p-3.5 font-mono text-gold font-bold">TCK-8801</td>
              <td class="p-3.5">
                <div class="font-bold text-white">Window Pull Highlight Artifact in Bedroom 2</div>
                <div class="text-[11px] text-gray-400">Requester: Craig Westerman (craig@hometrack.net)</div>
              </td>
              <td class="p-3.5 font-mono text-gray-300">Photo Editing QA</td>
              <td class="p-3.5">
                <span class="px-2 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/30 font-bold font-mono text-[10px]">
                  🔴 Urgent (SLA: 48m left)
                </span>
              </td>
              <td class="p-3.5">
                <span class="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 font-mono text-[10px] font-bold">IN_PROGRESS</span>
              </td>
              <td class="p-3.5 text-right">
                <button onclick="alert('Viewing ticket TCK-8801 details')" class="px-3 py-1 rounded-lg bg-dark border border-dark-border hover:border-gold text-xs font-bold text-gray-300 hover:text-white">View &rarr;</button>
              </td>
            </tr>
            <?php else: ?>
            <?php foreach ($tickets as $t): ?>
            <tr class="hover:bg-white/[0.02]">
              <td class="p-3.5 font-mono text-gold font-bold"><?= htmlspecialchars($t['id'] ?? 'TCK-1') ?></td>
              <td class="p-3.5">
                <div class="font-bold text-white"><?= htmlspecialchars($t['subject'] ?? 'Inquiry') ?></div>
                <div class="text-[11px] text-gray-400">Requester: <?= htmlspecialchars($t['client_name'] ?? 'Client') ?> (<?= htmlspecialchars($t['client_email'] ?? '') ?>)</div>
              </td>
              <td class="p-3.5 font-mono text-gray-300"><?= htmlspecialchars($t['department'] ?? 'Support') ?></td>
              <td class="p-3.5">
                <span class="px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 font-bold font-mono text-[10px]">
                  <?= strtoupper(htmlspecialchars($t['priority'] ?? 'Normal')) ?>
                </span>
              </td>
              <td class="p-3.5">
                <span class="px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 font-mono text-[10px] font-bold"><?= strtoupper(htmlspecialchars($t['status'] ?? 'OPEN')) ?></span>
              </td>
              <td class="p-3.5 text-right">
                <button class="px-3 py-1 rounded-lg bg-dark border border-dark-border hover:border-gold text-xs font-bold text-gray-300 hover:text-white">View &rarr;</button>
              </td>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Section 2: Searchable Knowledge Base Studio -->
    <div class="glass-card rounded-2xl border border-dark-border p-6 shadow-xl space-y-5">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-dark-border pb-4">
        <div>
          <h3 class="text-sm font-black text-white flex items-center gap-2">
            <span>📚</span> <span>Dual-Surface Knowledge Base Center</span>
          </h3>
          <p class="text-xs text-gray-400 mt-0.5">Searchable by visitors inside widget &amp; instantly inserted into live chats via slash shortcuts.</p>
        </div>
        <div class="flex items-center gap-2">
          <input type="text" placeholder="Search KB articles..." class="bg-[#131322] border border-[#26263B] rounded-xl px-3 py-1.5 text-xs text-white focus:border-gold">
          <button onclick="alert('New article editor opened.')" class="px-3 py-1.5 rounded-xl bg-gold text-dark font-black text-xs shadow-glow">+ New Article</button>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="p-4 rounded-xl bg-dark/60 border border-dark-border space-y-2">
          <div class="text-[10px] text-gold font-mono uppercase font-bold">Photo Editing Guide</div>
          <h4 class="font-bold text-white text-xs">HDR RAW Bracket Best Practices</h4>
          <p class="text-xs text-gray-400 line-clamp-2">Recommended -2, 0, +2 EV bracket settings on tripod for natural window pulls.</p>
        </div>
        <div class="p-4 rounded-xl bg-dark/60 border border-dark-border space-y-2">
          <div class="text-[10px] text-emerald-400 font-mono uppercase font-bold">Virtual Staging</div>
          <h4 class="font-bold text-white text-xs">Furniture Styles &amp; Room Dimensions</h4>
          <p class="text-xs text-gray-400 line-clamp-2">Modern Contemporary, Scandinavian, and Farmhouse 3D furniture packages.</p>
        </div>
        <div class="p-4 rounded-xl bg-dark/60 border border-dark-border space-y-2">
          <div class="text-[10px] text-blue-400 font-mono uppercase font-bold">Pricing &amp; Delivery</div>
          <h4 class="font-bold text-white text-xs">Overnight 24h &amp; 12h Rush Turnaround</h4>
          <p class="text-xs text-gray-400 line-clamp-2">Guaranteed overnight delivery specifications for MLS morning launches.</p>
        </div>
      </div>
    </div>

  </div>

</main>

<!-- ── 3. JAVASCRIPT: TAB SWITCHER, URL STATE & ENGINE ────────────── -->
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
let activeTabId = 'tabOverview';
let selectedVisitorId = null;
let currentReplyMode = 'public';
let lastUnreadAlertState = false;

// Web Audio API Synthesized Chime Bell (Zero External Audio File Dependency)
function playNotificationChime() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(880, ctx.currentTime); // A5 note
    osc.frequency.exponentialRampToValueAtTime(1760, ctx.currentTime + 0.1); // E6 note

    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.6);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.6);
  } catch(e) {}
}

// Seamless Tab Switching with URL State Persistence
function switchCommandTab(tabId) {
  const tabIds = ['tabOverview', 'tabRadar', 'tabInbox', 'tabCrm', 'tabTriggers', 'tabTickets'];
  if (!tabIds.includes(tabId)) tabId = 'tabOverview';

  activeTabId = tabId;
  localStorage.setItem('ehdr_cmd_tab', tabId);

  // Update URL hash without jumping
  if (history.pushState) {
    history.pushState(null, null, '#' + tabId.replace('tab', '').toLowerCase());
  }

  // Toggle Visibility
  tabIds.forEach(id => {
    const container = document.getElementById(id);
    if (container) {
      if (id === tabId) {
        container.classList.remove('hidden');
      } else {
        container.classList.add('hidden');
      }
    }
  });

  // Toggle Tab Button Styles
  const btnMap = {
    'tabOverview': 'btnTabOverview',
    'tabRadar': 'btnTabRadar',
    'tabInbox': 'btnTabInbox',
    'tabCrm': 'btnTabCrm',
    'tabTriggers': 'btnTabTriggers',
    'tabTickets': 'btnTabTickets'
  };

  Object.entries(btnMap).forEach(([tId, btnId]) => {
    const btn = document.getElementById(btnId);
    if (!btn) return;
    if (tId === tabId) {
      btn.className = "tab-btn px-4 py-2.5 rounded-xl font-black text-xs transition-all whitespace-nowrap inline-flex items-center gap-2 bg-gold text-dark shadow-glow";
    } else {
      btn.className = "tab-btn px-4 py-2.5 rounded-xl font-black text-xs transition-all whitespace-nowrap inline-flex items-center gap-2 bg-dark-card text-gray-400 border border-dark-border hover:border-gold hover:text-white";
    }
  });
}

// Initial Tab Load State Handler
document.addEventListener('DOMContentLoaded', () => {
  const hash = window.location.hash.replace('#', '').toLowerCase();
  const hashToTab = {
    'overview': 'tabOverview',
    'radar': 'tabRadar',
    'inbox': 'tabInbox',
    'crm': 'tabCrm',
    'triggers': 'tabTriggers',
    'tickets': 'tabTickets'
  };

  const savedTab = localStorage.getItem('ehdr_cmd_tab');
  const targetTab = hashToTab[hash] || savedTab || 'tabOverview';
  switchCommandTab(targetTab);
});

// Keyboard Navigation (Alt+1 through Alt+6)
window.addEventListener('keydown', (e) => {
  if (e.altKey && e.key >= '1' && e.key <= '6') {
    const keyMap = {
      '1': 'tabOverview',
      '2': 'tabRadar',
      '3': 'tabInbox',
      '4': 'tabCrm',
      '5': 'tabTriggers',
      '6': 'tabTickets'
    };
    if (keyMap[e.key]) {
      e.preventDefault();
      switchCommandTab(keyMap[e.key]);
    }
  }
});

// Radar State Filter & Search
function filterRadarState(state) {
  const rows = document.querySelectorAll('.radar-row');
  rows.forEach(r => {
    const rState = r.getAttribute('data-state');
    if (state === 'all' || rState === state) {
      r.style.display = '';
    } else {
      r.style.display = 'none';
    }
  });
}

function handleRadarSearch(query) {
  const q = query.toLowerCase().trim();
  const rows = document.querySelectorAll('.radar-row');
  rows.forEach(r => {
    const text = r.textContent.toLowerCase();
    if (!q || text.includes(q)) {
      r.style.display = '';
    } else {
      r.style.display = 'none';
    }
  });
}

function openVisitorDrawer(vid) {
  alert('Inspecting Visitor Journey Dossier: ' + vid);
}

function quickStartChat(vid) {
  switchCommandTab('tabInbox');
  selectAgentChat(vid);
}

function filterInboxChannel(channel) {
  document.querySelectorAll('.inbox-chan-btn').forEach(b => {
    b.className = "inbox-chan-btn px-2.5 py-1.5 rounded-lg font-bold bg-dark text-gray-400 border border-dark-border hover:border-gold hover:text-white";
  });
  if (event && event.currentTarget) {
    event.currentTarget.className = "inbox-chan-btn px-2.5 py-1.5 rounded-lg font-bold bg-gold text-dark shadow-glow";
  }
}

function selectAgentChat(vid) {
  selectedVisitorId = vid;

  // Highlight card
  document.querySelectorAll('.chat-card').forEach(c => c.classList.remove('border-gold', 'bg-[#181826]'));
  const activeCard = document.getElementById('chatCard-' + vid);
  if (activeCard) activeCard.classList.add('border-gold', 'bg-[#181826]');

  const titleEl = document.getElementById('consoleChatTitle');
  if (titleEl) titleEl.innerHTML = `<span>💬 Conversation: <strong class="text-gold font-mono">${vid}</strong></span>`;

  const dossierVid = document.getElementById('dossierVid');
  if (dossierVid) dossierVid.textContent = vid;

  document.getElementById('consoleQuickChips').classList.remove('hidden');
  document.getElementById('consoleInputArea').classList.remove('hidden');
  const aiBox = document.getElementById('aiCoPilotBox');
  if (aiBox) aiBox.classList.remove('hidden');

  // Trigger AI Brain draft recommendation
  fetchAiSuggestedReply();

  // Initial fetch with forceScroll = true
  fetch('/api/chat-live.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'poll_admin',
      selected_vid: vid
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success && Array.isArray(data.current_messages)) {
      renderConsoleMessages(data.current_messages, true);
    }
  })
  .catch(() => {});
}

function insertCanned(text) {
  const inp = document.getElementById('agentReplyInput');
  if (inp) {
    inp.value = text;
    inp.focus();
  }
}

function toggleReplyMode(mode) {
  currentReplyMode = mode;
  const sendBtn = document.getElementById('agentSendBtn');
  if (sendBtn) {
    if (mode === 'private') {
      sendBtn.className = "px-5 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-dark font-black text-sm shadow-glow transition-all flex-shrink-0";
      sendBtn.textContent = "Save Note 🔒";
    } else {
      sendBtn.className = "px-5 py-3 rounded-xl bg-gold hover:bg-amber-400 text-dark font-black text-sm shadow-glow transition-all flex-shrink-0";
      sendBtn.textContent = "Send →";
    }
  }
}

function convertChatToTicket() {
  if (!selectedVisitorId) return;
  alert('1-Click Ticket conversion created for session: ' + selectedVisitorId);
}

function promoteVisitorToLead() {
  if (!selectedVisitorId) return;
  alert('Visitor ' + selectedVisitorId + ' promoted to CRM pipeline!');
}

function handleAgentMessageSubmit(e) {
  e.preventDefault();
  if (!selectedVisitorId) return;

  const inp = document.getElementById('agentReplyInput');
  const text = (inp ? inp.value : '').trim();
  if (!text) return;

  const agentSelect = document.getElementById('activeAgentSelector');
  const agentName = agentSelect ? agentSelect.value : 'Alice | Lead Retoucher';

  inp.value = '';

  fetch('/api/chat-live.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'agent_send',
      target_visitor_id: selectedVisitorId,
      agent_name: agentName,
      message: (currentReplyMode === 'private' ? '[PRIVATE NOTE] ' : '') + text
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success && Array.isArray(data.messages)) {
      renderConsoleMessages(data.messages, true); // Force scroll to bottom on sent message
    }
  })
  .catch(() => {});
}

function renderConsoleMessages(messages, forceScroll = false) {
  const stream = document.getElementById('consoleMessagesStream');
  if (!stream) return;

  // Check if admin is currently scrolled near the bottom (within 90px)
  const isNearBottom = (stream.scrollHeight - stream.scrollTop - stream.clientHeight) < 90;

  // Key tracking to prevent wiping DOM and scroll position on unchanged polls
  const lastRenderedKey = stream.getAttribute('data-last-render-key');
  const currentKey = messages.map(m => (m.id || '') + (m.ts || '')).join('|');
  
  if (!forceScroll && lastRenderedKey === currentKey) {
    return; // No message change, preserve user's exact scroll position!
  }

  stream.setAttribute('data-last-render-key', currentKey);
  stream.innerHTML = '';

  messages.forEach(m => {
    const isUser = (m.sender === 'user');
    const msgDiv = document.createElement('div');
    msgDiv.className = isUser ? 'flex items-start justify-start gap-3' : 'flex items-start justify-end gap-3';
    
    const isAgent = (m.sender === 'agent');
    const isNote = (m.text && m.text.startsWith('[PRIVATE NOTE]'));
    const senderLabel = m.agent_name || (isAgent ? 'Live Agent' : 'Estate HDR AI');

    const bubble = document.createElement('div');
    if (isUser) {
      bubble.className = 'p-4 rounded-2xl rounded-tl-none bg-[#1C1C2E] border border-[#2F2F48] text-white text-sm font-medium leading-relaxed max-w-[85%] shadow-md';
    } else if (isNote) {
      bubble.className = 'p-4 rounded-2xl rounded-tr-none bg-amber-950/60 text-amber-100 border border-amber-500/50 text-sm font-medium leading-relaxed max-w-[85%] shadow-md';
    } else if (isAgent) {
      bubble.className = 'p-4 rounded-2xl rounded-tr-none bg-emerald-700 text-white font-medium text-sm leading-relaxed max-w-[85%] shadow-md border border-emerald-500/40';
    } else {
      bubble.className = 'p-4 rounded-2xl rounded-tr-none bg-gold text-dark font-medium text-sm leading-relaxed max-w-[85%] shadow-md';
    }

    bubble.innerHTML = `
      <div class="text-xs font-bold ${isUser ? 'text-gray-300' : (isNote ? 'text-amber-400' : (isAgent ? 'text-emerald-200' : 'text-dark/80'))} mb-1.5 flex items-center justify-between gap-4">
        <span>${isUser ? '👤 Visitor' : (isNote ? '🔒 Private Note (' + senderLabel + ')' : '● ' + senderLabel)}</span>
        <span class="text-xs opacity-80 font-mono">${m.timestamp || ''}</span>
      </div>
      <div class="text-sm font-normal text-white leading-relaxed select-text">${m.text}</div>
    `;

    msgDiv.appendChild(bubble);
    stream.appendChild(msgDiv);
  });

  // ONLY auto-scroll down if forceScroll is set (e.g. user sent message or opened chat) OR user was already at the bottom
  if (forceScroll || isNearBottom) {
    stream.scrollTop = stream.scrollHeight;
  }
}

function updateWidgetPreview() {
  const title = document.getElementById('widgetTitleInput')?.value || 'Alice | Retouching Director';
  const greeting = document.getElementById('widgetGreetingInput')?.value || 'Hi there!';
  const theme = document.getElementById('widgetThemeSelector')?.value || 'gold';

  const previewTitle = document.getElementById('previewWidgetTitle');
  if (previewTitle) previewTitle.textContent = title;

  const previewGreeting = document.getElementById('previewWidgetGreeting');
  if (previewGreeting) previewGreeting.textContent = greeting;

  const previewHeader = document.getElementById('previewWidgetHeader');
  if (previewHeader) {
    if (theme === 'emerald') {
      previewHeader.className = "p-3 bg-emerald-600 text-white font-black flex items-center justify-between";
    } else if (theme === 'sapphire') {
      previewHeader.className = "p-3 bg-blue-600 text-white font-black flex items-center justify-between";
    } else {
      previewHeader.className = "p-3 bg-gold text-dark font-black flex items-center justify-between";
    }
  }
}

// Smart Background Polling (Pauses when tab is hidden to save 90% CPU)
function pollAdminLiveChat() {
  if (document.hidden) return; // Pause polling when admin tab is hidden

  fetch('/api/chat-live.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'poll_admin',
      selected_vid: selectedVisitorId || ''
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      if (data.unread_alert && !lastUnreadAlertState) {
        playNotificationChime();
      }
      lastUnreadAlertState = data.unread_alert;

      const typingAlert = document.getElementById('visitorTypingAlertBox');
      const typingText = document.getElementById('typingSneakPeekText');
      if (data.typing_preview && data.typing_preview.trim() !== '') {
        if (typingAlert && typingText) {
          typingText.textContent = '"' + data.typing_preview + '"';
          typingAlert.classList.remove('hidden');
        }
      } else {
        if (typingAlert) typingAlert.classList.add('hidden');
      }

      if (selectedVisitorId && Array.isArray(data.current_messages)) {
        renderConsoleMessages(data.current_messages, false); // Do NOT force scroll on polling!
      }
    }
  })
  .catch(() => {});
}

setInterval(pollAdminLiveChat, 2500);
</script>

  <!-- ══════════════════════════════════════════════════════════════════
       TAB 7: GLOBAL COUNTRY-BASED AGENT ROUTING MATRIX
       ══════════════════════════════════════════════════════════════════ -->
  <div id="tabGlobalAgents" class="tab-content hidden space-y-6">
    <div class="glass-card rounded-2xl border border-dark-border p-6 shadow-xl space-y-5">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-dark-border pb-4">
        <div>
          <h3 class="text-base font-black text-white flex items-center gap-2">
            <span>🌐</span> <span>Global Country-Based Agent Routing Engine (PRD Section 5)</span>
          </h3>
          <p class="text-xs text-gray-400 mt-1">Automatic 8-tier routing by visitor country, language, presence &amp; workload.</p>
        </div>
        <span class="px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-mono font-bold">🟢 Active Routing Engine</span>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div class="p-4 rounded-2xl bg-[#141424] border border-[#26263B] space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-lg">🇬🇧 United Kingdom</span>
            <span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-mono font-bold">ONLINE</span>
          </div>
          <div class="text-xs text-white font-bold">Alice | Senior Retouching Director</div>
          <div class="text-[11px] text-gray-400">Team: UK Executive Studio (GBP / £0.80)</div>
          <div class="text-[11px] text-gray-500">Routing: Direct Country Priority</div>
        </div>

        <div class="p-4 rounded-2xl bg-[#141424] border border-[#26263B] space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-lg">🇺🇸 North America</span>
            <span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-mono font-bold">ONLINE</span>
          </div>
          <div class="text-xs text-white font-bold">Marcus Vance | Production Manager</div>
          <div class="text-[11px] text-gray-400">Team: North America Sales (USD / $0.80)</div>
          <div class="text-[11px] text-gray-500">Routing: Direct Country Priority</div>
        </div>

        <div class="p-4 rounded-2xl bg-[#141424] border border-[#26263B] space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-lg">🇩🇪 Germany &amp; DACH</span>
            <span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-mono font-bold">STANDBY</span>
          </div>
          <div class="text-xs text-white font-bold">Lukas Weber | Director DACH</div>
          <div class="text-[11px] text-gray-400">Team: Germany Regional (EUR / €0.74)</div>
          <div class="text-[11px] text-gray-500">Routing: German Language Match</div>
        </div>

        <div class="p-4 rounded-2xl bg-[#141424] border border-[#26263B] space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-lg">🇪🇸 Spain &amp; LATAM</span>
            <span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-mono font-bold">STANDBY</span>
          </div>
          <div class="text-xs text-white font-bold">Mateo Gomez | Specialist</div>
          <div class="text-[11px] text-gray-400">Team: Spain &amp; LATAM (EUR / USD)</div>
          <div class="text-[11px] text-gray-500">Routing: Spanish Language Match</div>
        </div>

        <div class="p-4 rounded-2xl bg-[#141424] border border-[#26263B] space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-lg">🇦🇪 Middle East</span>
            <span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-mono font-bold">ONLINE</span>
          </div>
          <div class="text-xs text-white font-bold">Zain Malik | Senior Colorist</div>
          <div class="text-[11px] text-gray-400">Team: Middle East Executive (AED / 2.94)</div>
          <div class="text-[11px] text-gray-500">Routing: Arabic / English VIP Queue</div>
        </div>

        <div class="p-4 rounded-2xl bg-[#141424] border border-[#26263B] space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-lg">🌐 Global Fallback</span>
            <span class="px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 text-[10px] font-mono font-bold">24/7 ACTIVE</span>
          </div>
          <div class="text-xs text-white font-bold">Elena Rostova | Studio Supervisor</div>
          <div class="text-[11px] text-gray-400">Team: 24/7 Global English Concierge</div>
          <div class="text-[11px] text-gray-500">Routing: Auto-translation enabled</div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══════════════════════════════════════════════════════════════════
       TAB 8: EXECUTIVE ANALYTICS & OBSERVABILITY (PRD Section 17 & 21)
       ══════════════════════════════════════════════════════════════════ -->
  <div id="tabObservability" class="tab-content hidden space-y-6">
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
      <div class="glass-card p-5 rounded-2xl border border-dark-border shadow-xl">
        <div class="text-xs text-gray-400 font-bold uppercase mb-1">API Health (p95 Latency)</div>
        <div class="text-3xl font-black text-emerald-400 font-mono">42 ms</div>
        <div class="text-[11px] text-gray-500 mt-1">Hostinger FastCGI + Cache</div>
      </div>

      <div class="glass-card p-5 rounded-2xl border border-dark-border shadow-xl">
        <div class="text-xs text-gray-400 font-bold uppercase mb-1">AI Resolution Rate</div>
        <div class="text-3xl font-black text-gold font-mono">88.4%</div>
        <div class="text-[11px] text-gray-500 mt-1">11.6% Human Escalated</div>
      </div>

      <div class="glass-card p-5 rounded-2xl border border-dark-border shadow-xl">
        <div class="text-xs text-gray-400 font-bold uppercase mb-1">Deterministic Quotes</div>
        <div class="text-3xl font-black text-purple-400 font-mono">142</div>
        <div class="text-[11px] text-gray-500 mt-1">100% Server Calculated</div>
      </div>

      <div class="glass-card p-5 rounded-2xl border border-dark-border shadow-xl">
        <div class="text-xs text-gray-400 font-bold uppercase mb-1">Database &amp; Queue Health</div>
        <div class="text-3xl font-black text-blue-400 font-mono">0 Backlog</div>
        <div class="text-[11px] text-gray-500 mt-1">Automatic sync active</div>
      </div>
    </div>
  </div>

<!-- ══════════════════════════════════════════════════════════════════
     DETERMINISTIC QUOTE CALCULATOR MODAL (PRD Section 9)
     ══════════════════════════════════════════════════════════════════ -->
<div id="quoteCalcModal" class="hidden fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
  <div class="glass-card rounded-3xl border border-emerald-500/40 max-w-lg w-full bg-[#0D0D18] shadow-2xl overflow-hidden p-6 space-y-4">
    <div class="flex items-center justify-between border-b border-dark-border pb-3">
      <div class="flex items-center gap-2">
        <span class="text-xl">🧮</span>
        <h3 class="text-base font-black text-white">Deterministic Server-Side Quote Engine</h3>
      </div>
      <button onclick="closeQuoteCalculatorModal()" class="w-8 h-8 rounded-full bg-white/5 hover:bg-white/15 text-gray-400 hover:text-white flex items-center justify-center font-bold text-sm">✕</button>
    </div>

    <form onsubmit="generateAndInsertQuote(event)" class="space-y-3 text-xs">
      <div>
        <label class="text-gray-400 font-bold block mb-1">Service Type</label>
        <select id="quoteServiceSelect" class="w-full bg-[#1A1A30] border border-[#2E2E48] rounded-xl px-3 py-2 text-white">
          <option value="hdr">Hand-Blended HDR Photo Retouching ($0.80/photo)</option>
          <option value="staging">3D Virtual Staging &amp; Furnishing ($8.00/room)</option>
          <option value="twilight">Day to Dusk / Sunset Twilight ($4.00/photo)</option>
          <option value="item_removal">Item Removal &amp; Decluttering ($2.00/photo)</option>
          <option value="floorplan_2d">2D Floor Plan Schematics ($12.00/plan)</option>
          <option value="floorplan_3d">3D Textured Floor Plans ($20.00/plan)</option>
          <option value="video_4k">4K Real Estate Cinematic Video ($35.00/video)</option>
        </select>
      </div>

      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="text-gray-400 font-bold block mb-1">Quantity</label>
          <input type="number" id="quoteQtyInput" value="25" min="1" max="1000" class="w-full bg-[#1A1A30] border border-[#2E2E48] rounded-xl px-3 py-2 text-white font-mono" required>
        </div>
        <div>
          <label class="text-gray-400 font-bold block mb-1">Currency</label>
          <select id="quoteCurrencySelect" class="w-full bg-[#1A1A30] border border-[#2E2E48] rounded-xl px-3 py-2 text-white font-mono">
            <option value="USD">USD ($)</option>
            <option value="GBP">GBP (£)</option>
            <option value="EUR">EUR (€)</option>
            <option value="AUD">AUD (A$)</option>
            <option value="CAD">CAD (C$)</option>
            <option value="AED">AED (AED)</option>
          </select>
        </div>
      </div>

      <label class="p-3 rounded-xl bg-dark/60 border border-dark-border flex items-center justify-between cursor-pointer">
        <div>
          <div class="font-bold text-white">12-Hour Urgent Rush SLA (+25%)</div>
          <div class="text-[11px] text-gray-400">Guaranteed morning MLS delivery</div>
        </div>
        <input type="checkbox" id="quoteRushCheckbox" class="w-4 h-4 rounded text-gold focus:ring-0 bg-dark border-dark-border">
      </label>

      <div class="flex items-center justify-end gap-2 pt-2 border-t border-dark-border">
        <button type="button" onclick="closeQuoteCalculatorModal()" class="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 text-xs">Cancel</button>
        <button type="submit" class="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-dark font-black text-xs shadow-glow">Calculate &amp; Insert Quote &rarr;</button>
      </div>
    </form>
  </div>
</div>
<!-- ══════════════════════════════════════════════════════════════════
     CANNED MESSAGE STUDIO & AI RESPONSE MODAL
     ══════════════════════════════════════════════════════════════════ -->
<div id="cannedStudioModal" class="hidden fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
  <div class="glass-card rounded-3xl border border-gold/40 max-w-4xl w-full bg-[#0D0D18] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
    
    <!-- Modal Header -->
    <div class="p-5 border-b border-dark-border flex items-center justify-between bg-[#141424]">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-2xl bg-gold/20 text-gold flex items-center justify-center text-xl font-bold border border-gold/30">
          📚
        </div>
        <div>
          <h3 class="text-base font-black text-white">Canned Message &amp; AI Template Studio</h3>
          <p class="text-xs text-gray-400">1-click insert, custom shortcut templates, and instant AI composer.</p>
        </div>
      </div>
      <button onclick="closeCannedStudioModal()" class="w-8 h-8 rounded-full bg-white/5 hover:bg-white/15 text-gray-400 hover:text-white flex items-center justify-center font-bold text-sm">✕</button>
    </div>

    <!-- Search & Category Filter Tabs -->
    <div class="p-4 bg-dark/60 border-b border-dark-border space-y-3">
      <div class="flex flex-col sm:flex-row items-center gap-3">
        <input type="text" id="cannedSearchInput" oninput="searchCannedList(this.value)" placeholder="Search canned messages or shortcut (e.g. /pricing, /trial)..." 
               class="flex-1 bg-[#131322] border border-[#2B2B42] focus:border-gold rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none w-full">
        <button onclick="toggleNewCannedForm()" class="px-4 py-2.5 rounded-xl bg-gold hover:bg-amber-400 text-dark font-black text-xs shadow-glow whitespace-nowrap">
          + Add New Template
        </button>
      </div>

      <!-- Categories -->
      <div class="flex flex-wrap gap-1.5" id="cannedCategoryTabs">
        <button onclick="filterCannedTab('All')" class="canned-cat-btn active px-3 py-1 rounded-lg bg-gold text-dark font-black text-[11px]">All (14)</button>
        <button onclick="filterCannedTab('Greetings')" class="canned-cat-btn px-3 py-1 rounded-lg bg-[#141424] text-gray-300 hover:text-white border border-[#242438] text-[11px] font-bold">👋 Greetings</button>
        <button onclick="filterCannedTab('Free Trial & Samples')" class="canned-cat-btn px-3 py-1 rounded-lg bg-[#141424] text-gray-300 hover:text-white border border-[#242438] text-[11px] font-bold">🎁 Free Trial</button>
        <button onclick="filterCannedTab('Pricing & Rates')" class="canned-cat-btn px-3 py-1 rounded-lg bg-[#141424] text-gray-300 hover:text-white border border-[#242438] text-[11px] font-bold">💰 Pricing</button>
        <button onclick="filterCannedTab('Turnaround & SLA')" class="canned-cat-btn px-3 py-1 rounded-lg bg-[#141424] text-gray-300 hover:text-white border border-[#242438] text-[11px] font-bold">⏱️ 24h &amp; Rush</button>
        <button onclick="filterCannedTab('Quality & Retouching Tech')" class="canned-cat-btn px-3 py-1 rounded-lg bg-[#141424] text-gray-300 hover:text-white border border-[#242438] text-[11px] font-bold">🪟 Window &amp; Color</button>
        <button onclick="filterCannedTab('Virtual Staging')" class="canned-cat-btn px-3 py-1 rounded-lg bg-[#141424] text-gray-300 hover:text-white border border-[#242438] text-[11px] font-bold">🛋️ 3D Staging</button>
        <button onclick="filterCannedTab('WhatsApp Escalation')" class="canned-cat-btn px-3 py-1 rounded-lg bg-[#141424] text-gray-300 hover:text-white border border-[#242438] text-[11px] font-bold">📲 WhatsApp</button>
      </div>
    </div>

    <!-- New Canned Template Form (Hidden by default) -->
    <div id="newCannedFormBox" class="hidden p-5 bg-[#141426] border-b border-gold/30 space-y-3">
      <h4 class="text-xs font-black text-gold uppercase tracking-wider">Create Custom Canned Template</h4>
      <form onsubmit="saveNewCannedMessage(event)" class="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
          <label class="text-[11px] text-gray-400 font-bold block mb-1">Category</label>
          <select id="newCannedCat" class="w-full bg-[#1A1A30] border border-[#2E2E48] rounded-xl px-3 py-2 text-xs text-white">
            <option value="Greetings">👋 Greetings</option>
            <option value="Free Trial & Samples">🎁 Free Trial &amp; Samples</option>
            <option value="Pricing & Rates">💰 Pricing &amp; Rates</option>
            <option value="Turnaround & SLA">⏱️ Turnaround &amp; SLA</option>
            <option value="Quality & Retouching Tech">🪟 Quality &amp; Retouching Tech</option>
            <option value="Virtual Staging">🛋️ Virtual Staging</option>
            <option value="WhatsApp Escalation">📲 WhatsApp Escalation</option>
            <option value="Custom">✨ Custom</option>
          </select>
        </div>
        <div>
          <label class="text-[11px] text-gray-400 font-bold block mb-1">Shortcut Trigger</label>
          <input type="text" id="newCannedShortcut" placeholder="/promo" class="w-full bg-[#1A1A30] border border-[#2E2E48] rounded-xl px-3 py-2 text-xs text-white font-mono" required>
        </div>
        <div>
          <label class="text-[11px] text-gray-400 font-bold block mb-1">Template Title</label>
          <input type="text" id="newCannedTitle" placeholder="Special Discount Offer" class="w-full bg-[#1A1A30] border border-[#2E2E48] rounded-xl px-3 py-2 text-xs text-white" required>
        </div>
        <div class="sm:col-span-3">
          <label class="text-[11px] text-gray-400 font-bold block mb-1">Template Text</label>
          <textarea id="newCannedText" rows="3" placeholder="Enter message text that will be sent to the client..." class="w-full bg-[#1A1A30] border border-[#2E2E48] rounded-xl px-3 py-2 text-xs text-white" required></textarea>
        </div>
        <div class="sm:col-span-3 flex justify-end gap-2">
          <button type="button" onclick="toggleNewCannedForm()" class="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 text-xs">Cancel</button>
          <button type="submit" class="px-5 py-2 rounded-xl bg-gold hover:bg-amber-400 text-dark font-black text-xs shadow-glow">Save Template</button>
        </div>
      </form>
    </div>

    <!-- Templates Grid Stream -->
    <div id="cannedGridStream" class="flex-1 p-5 overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-3.5">
      <div class="col-span-full py-12 text-center text-gray-400 text-xs">Loading canned response library...</div>
    </div>

  </div>
</div>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">

function openQuoteCalculatorModal() {
  const modal = document.getElementById('quoteCalcModal');
  if (modal) modal.classList.remove('hidden');
}

function closeQuoteCalculatorModal() {
  const modal = document.getElementById('quoteCalcModal');
  if (modal) modal.classList.add('hidden');
}

function generateAndInsertQuote(e) {
  e.preventDefault();
  const service = document.getElementById('quoteServiceSelect')?.value || 'hdr';
  const qty = parseInt(document.getElementById('quoteQtyInput')?.value || '1', 10);
  const currency = document.getElementById('quoteCurrencySelect')?.value || 'USD';
  const isRush = document.getElementById('quoteRushCheckbox')?.checked || false;

  fetch('/api/quote-calculator.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      service: service,
      quantity: qty,
      currency: currency,
      is_rush: isRush
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success && data.quote) {
      const q = data.quote;
      const quoteText = `Official Studio Quote: ${q.quantity} ${q.unit_name} of ${q.service_title}\nTotal: ${q.formatted_total} (${q.turnaround_sla})\nQuote ID: ${q.quote_id} (Valid for 14 days)\nIncludes ${q.free_revisions}`;
      insertCanned(quoteText);
      closeQuoteCalculatorModal();
    }
  })
  .catch(() => alert('Quote calculation standby.'));
}

// ─── AI BRAIN CO-PILOT & CANNED STUDIO JAVASCRIPT ENGINE ───────────
let allCannedMessages = [];
let activeCannedCategory = 'All';
let currentAiDraftText = '';

function fetchAiSuggestedReply(customPrompt = '') {
  const previewBox = document.getElementById('aiDraftPreviewText');
  const contextLabel = document.getElementById('aiDraftQueryContext');
  if (previewBox) previewBox.innerHTML = '<span class="animate-pulse text-gold">🧠 Analyzing visitor conversation and generating tailored AI draft...</span>';

  fetch('/api/chat-live.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'ai_suggest_reply',
      target_visitor_id: selectedVisitorId || '',
      custom_query: customPrompt
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success && data.ai_draft) {
      currentAiDraftText = data.ai_draft;
      if (previewBox) previewBox.textContent = data.ai_draft;
      if (contextLabel) contextLabel.textContent = `Prompt: "${(data.source_query || 'general').substring(0, 30)}..."`;
    } else {
      if (previewBox) previewBox.textContent = 'Could not generate draft. Please select an active session.';
    }
  })
  .catch(() => {
    if (previewBox) previewBox.textContent = 'AI service standby.';
  });
}

function insertAiDraftIntoInput() {
  if (!currentAiDraftText) return;
  insertCanned(currentAiDraftText);
}

function openCannedStudioModal() {
  const modal = document.getElementById('cannedStudioModal');
  if (modal) {
    modal.classList.remove('hidden');
    loadCannedStudio();
  }
}

function closeCannedStudioModal() {
  const modal = document.getElementById('cannedStudioModal');
  if (modal) modal.classList.add('hidden');
}

function toggleNewCannedForm() {
  const formBox = document.getElementById('newCannedFormBox');
  if (formBox) formBox.classList.toggle('hidden');
}

function loadCannedStudio() {
  fetch('/api/chat-live.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'get_canned_responses' })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success && Array.isArray(data.canned)) {
      allCannedMessages = data.canned;
      renderCannedCards(allCannedMessages);
    }
  })
  .catch(() => {});
}

function renderCannedCards(list) {
  const grid = document.getElementById('cannedGridStream');
  if (!grid) return;

  if (!list || list.length === 0) {
    grid.innerHTML = '<div class="col-span-full py-8 text-center text-gray-500 text-xs">No matching canned messages found.</div>';
    return;
  }

  grid.innerHTML = list.map(item => `
    <div class="p-4 rounded-2xl bg-[#141424] border border-[#26263B] hover:border-gold/50 flex flex-col justify-between space-y-3 group transition-all">
      <div>
        <div class="flex items-center justify-between gap-2 mb-1.5">
          <span class="px-2 py-0.5 rounded bg-gold/15 text-gold font-mono font-bold text-[10px]">${item.shortcut || '/quick'}</span>
          <span class="text-[10px] text-gray-400 uppercase font-mono">${item.category || 'General'}</span>
        </div>
        <h5 class="text-xs font-bold text-white mb-1">${item.title}</h5>
        <p class="text-[11px] text-gray-300 leading-relaxed max-h-24 overflow-y-auto whitespace-pre-line">${item.text}</p>
      </div>
      <div class="flex items-center justify-between pt-2 border-t border-dark-border">
        <button type="button" onclick="deleteCannedTemplate('${item.id}')" class="text-[10px] text-red-400/80 hover:text-red-400 transition-colors">🗑️ Delete</button>
        <button type="button" onclick="useCannedItem('${item.id}')" class="px-3.5 py-1.5 rounded-xl bg-gold hover:bg-amber-400 text-dark font-black text-[11px] shadow-glow transition-all">
          Insert &rarr;
        </button>
      </div>
    </div>
  `).join('');
}

function filterCannedTab(category) {
  activeCannedCategory = category;
  document.querySelectorAll('.canned-cat-btn').forEach(btn => {
    if (btn.textContent.includes(category) || (category === 'All' && btn.textContent.startsWith('All'))) {
      btn.className = "canned-cat-btn active px-3 py-1 rounded-lg bg-gold text-dark font-black text-[11px]";
    } else {
      btn.className = "canned-cat-btn px-3 py-1 rounded-lg bg-[#141424] text-gray-300 hover:text-white border border-[#242438] text-[11px] font-bold";
    }
  });

  const query = document.getElementById('cannedSearchInput')?.value || '';
  applyCannedFilters(category, query);
}

function searchCannedList(query) {
  applyCannedFilters(activeCannedCategory, query);
}

function applyCannedFilters(category, query) {
  const q = query.toLowerCase().trim();
  let filtered = allCannedMessages;

  if (category !== 'All') {
    filtered = filtered.filter(item => (item.category || '').toLowerCase() === category.toLowerCase());
  }

  if (q) {
    filtered = filtered.filter(item => 
      (item.title || '').toLowerCase().includes(q) ||
      (item.shortcut || '').toLowerCase().includes(q) ||
      (item.text || '').toLowerCase().includes(q) ||
      (item.category || '').toLowerCase().includes(q)
    );
  }

  renderCannedCards(filtered);
}

function useCannedItem(id) {
  const item = allCannedMessages.find(i => i.id === id);
  if (item) {
    insertCanned(item.text);
    closeCannedStudioModal();
  }
}

function saveNewCannedMessage(e) {
  e.preventDefault();
  const category = document.getElementById('newCannedCat')?.value || 'General';
  const shortcut = document.getElementById('newCannedShortcut')?.value || '';
  const title = document.getElementById('newCannedTitle')?.value || '';
  const text = document.getElementById('newCannedText')?.value || '';

  if (!text) return;

  fetch('/api/chat-live.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      action: 'save_canned_response',
      category: category,
      shortcut: shortcut,
      title: title,
      text: text
    })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success && Array.isArray(data.canned)) {
      allCannedMessages = data.canned;
      renderCannedCards(allCannedMessages);
      toggleNewCannedForm();
      document.getElementById('newCannedText').value = '';
      document.getElementById('newCannedTitle').value = '';
      document.getElementById('newCannedShortcut').value = '';
    }
  })
  .catch(() => {});
}

function deleteCannedTemplate(id) {
  const doDelete = () => {
    fetch('/api/chat-live.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'delete_canned_response',
        id: id
      })
    })
    .then(res => res.json())
    .then(data => {
      if (data.success && Array.isArray(data.canned)) {
        allCannedMessages = data.canned;
        renderCannedCards(allCannedMessages);
        if (window.EstateDialog) EstateDialog.toast('Template deleted.', 'success');
      }
    })
    .catch(() => {});
  };

  if (window.EstateDialog) {
    EstateDialog.confirm('Are you sure you want to delete this canned response template?', 'Delete Template').then(ok => {
      if (ok) doDelete();
    });
  } else {
    doDelete();
  }
}
</script>
</body>
</html>
