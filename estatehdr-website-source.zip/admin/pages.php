<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireSeoManagerOrAdmin();

// Handle Quick Toggle Status
if (isset($_GET['toggle_status'])) {
    $toggleId = trim($_GET['toggle_status']);
    $pages = getPagesSeo();
    foreach ($pages as &$p) {
        if ($p['id'] === $toggleId || $p['slug'] === $toggleId) {
            $newStatus = ($p['status'] ?? 'published') === 'published' ? 'draft' : 'published';
            $p['status'] = $newStatus;
            $p['updated_at'] = date('c');
            setFlash('success', 'Page "' . htmlspecialchars($p['page_name'] ?? $p['title']) . '" changed to ' . ucfirst($newStatus) . '.');
            break;
        }
    }
    savePagesSeo($pages);
    header('Location: /admin/pages.php');
    exit;
}

// Handle Delete Page
if (isset($_GET['delete'])) {
    $delId = trim($_GET['delete']);
    deletePage($delId);
    setFlash('success', 'Page deleted successfully.');
    header('Location: /admin/pages.php');
    exit;
}

$allPages = getPagesSeoHierarchical();
$filterStatus = trim($_GET['status'] ?? 'all');
$searchKw     = strtolower(trim($_GET['q'] ?? ''));

$pages = array_filter($allPages, function($p) use ($filterStatus, $searchKw) {
    if ($filterStatus !== 'all') {
        $st = $p['status'] ?? 'published';
        if ($st !== $filterStatus) return false;
    }
    if ($searchKw !== '') {
        $matches = str_contains(strtolower($p['title'] ?? ''), $searchKw) ||
                   str_contains(strtolower($p['page_name'] ?? ''), $searchKw) ||
                   str_contains(strtolower($p['slug'] ?? ''), $searchKw);
        if (!$matches) return false;
    }
    return true;
});
$pages = array_values($pages);

$currentAdmin = currentAdminUser();
$adminRoles   = getAdminRoles();
$isSeoOnly    = in_array('seo_manager', $adminRoles) && !in_array('owner', $adminRoles) && !in_array('manager', $adminRoles);
$backUrl      = $isSeoOnly ? '/admin/pages.php' : '/admin/';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Static Pages Manager — Estate HDR Admin</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8">
  <?= renderFlash() ?>

  <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
    <div>
      <div class="section-tag mb-1">Static Content &amp; Hierarchy</div>
      <h1 class="text-2xl sm:text-3xl font-black text-white">ALL PAGES MANAGEMENT</h1>
      <p class="text-gray-400 text-xs mt-1">Manage static structural pages, parent hierarchy, templates, draft status, and real-time on-page SEO validation scores.</p>
    </div>

    <div class="flex items-center gap-3">
      <a href="/admin/page-edit.php" class="btn-gold py-2.5 px-6 text-xs font-bold shadow-glow inline-flex items-center gap-2">
        <span>+</span> <span>Add New Page</span>
      </a>
    </div>
  </div>

  <!-- Filter Tabs & Search Bar -->
  <div class="glass-card rounded-2xl p-5 mb-6 border border-dark-border shadow-xl flex flex-wrap items-center justify-between gap-4">
    <div class="flex items-center gap-2 text-xs font-bold uppercase tracking-wider">
      <a href="?status=all" class="px-3 py-1.5 rounded-lg <?= $filterStatus === 'all' ? 'bg-gold text-dark font-black' : 'text-gray-400 hover:text-white bg-dark' ?>">
        All (<?= count($allPages) ?>)
      </a>
      <a href="?status=published" class="px-3 py-1.5 rounded-lg <?= $filterStatus === 'published' ? 'bg-gold text-dark font-black' : 'text-gray-400 hover:text-white bg-dark' ?>">
        Published (<?= count(array_filter($allPages, fn($p) => ($p['status'] ?? 'published') === 'published')) ?>)
      </a>
      <a href="?status=draft" class="px-3 py-1.5 rounded-lg <?= $filterStatus === 'draft' ? 'bg-gold text-dark font-black' : 'text-gray-400 hover:text-white bg-dark' ?>">
        Drafts (<?= count(array_filter($allPages, fn($p) => ($p['status'] ?? 'published') === 'draft')) ?>)
      </a>
    </div>

    <form method="GET" class="flex items-center gap-2">
      <input type="hidden" name="status" value="<?= htmlspecialchars($filterStatus) ?>">
      <input type="text" name="q" value="<?= htmlspecialchars($_GET['q'] ?? '') ?>" class="form-input text-xs py-1.5 px-3 w-64" placeholder="Search pages...">
      <button type="submit" class="btn-ghost py-1.5 px-3 text-xs font-bold">Search</button>
    </form>
  </div>

  <!-- Pages Data Table with Traffic Light Indicators -->
  <div class="glass-card rounded-2xl overflow-hidden border border-dark-border shadow-2xl">
    <div class="p-4 border-b border-dark-border flex items-center justify-between">
      <div class="flex items-center gap-4 text-xs">
        <h3 class="font-bold text-white uppercase tracking-wider">PAGES DIRECTORY</h3>
        <span class="text-gray-400 font-mono"><?= count($pages) ?> pages shown</span>
      </div>

      <!-- Traffic Light Legend -->
      <div class="flex items-center gap-4 text-xs text-gray-400">
        <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-emerald-500/50 shadow-sm"></span> 🟢 Good SEO</span>
        <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-amber-500 shadow-amber-500/50 shadow-sm"></span> 🟡 Needs Attention</span>
        <span class="flex items-center gap-1.5"><span class="w-2.5 h-2.5 rounded-full bg-red-500 shadow-red-500/50 shadow-sm"></span> 🔴 Missing Tags</span>
      </div>
    </div>

    <div class="overflow-x-auto">
      <table class="dashboard-table w-full text-left text-xs">
        <thead>
          <tr>
            <th>Page Title</th>
            <th>Author</th>
            <th>Template</th>
            <th>Status</th>
            <th>Date / Last Edited</th>
            <th class="text-center">SEO Status</th>
            <th class="text-right">Quick Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($pages as $p): 
            $seoScore = calculateSeoScore($p);
            $hasParent = !empty($p['parent_id']);
            $previewUrl = $p['url_path'] ?? ('/page.php?slug=' . urlencode($p['slug']));
            $status = $p['status'] ?? 'published';
          ?>
          <tr class="hover:bg-white/[0.02]">
            <td>
              <div class="flex items-center gap-2">
                <?php if ($hasParent): ?>
                  <span class="text-gold font-mono text-sm ml-2">↳</span>
                <?php endif; ?>
                <div>
                  <div class="font-bold text-white text-sm hover:text-gold transition-colors">
                    <a href="/admin/page-edit.php?slug=<?= urlencode($p['slug']) ?>">
                      <?= htmlspecialchars($p['page_name'] ?? $p['title']) ?>
                    </a>
                  </div>
                  <div class="text-xs text-gray-500 font-mono mt-0.5"><?= htmlspecialchars($previewUrl) ?></div>
                </div>
              </div>
            </td>
            <td class="text-gray-300">
              <?= htmlspecialchars($p['author'] ?? 'SEO Manager') ?>
            </td>
            <td>
              <span class="px-2.5 py-0.5 rounded-md bg-dark border border-dark-border text-gray-300 font-mono text-xs">
                <?= ucfirst(str_replace('_', ' ', $p['template'] ?? 'default')) ?>
              </span>
            </td>
            <td>
              <?php if ($status === 'published'): ?>
                <a href="?toggle_status=<?= urlencode($p['id'] ?? $p['slug']) ?>" title="Click to unpublish (switch to draft)" class="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 inline-flex items-center gap-1 hover:opacity-80">
                  <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> Published
                </a>
              <?php else: ?>
                <a href="?toggle_status=<?= urlencode($p['id'] ?? $p['slug']) ?>" title="Click to publish live" class="px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/40 inline-flex items-center gap-1 hover:opacity-80">
                  <span class="w-1.5 h-1.5 rounded-full bg-amber-400"></span> Draft
                </a>
              <?php endif; ?>
            </td>
            <td class="text-gray-400 font-mono">
              <?= date('M j, Y', strtotime($p['updated_at'] ?? $p['created_at'])) ?>
            </td>
            <td class="text-center">
              <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-dark border border-dark-border" title="<?= implode('; ', $seoScore['issues']) ?: 'All Meta Tags Optimized' ?>">
                <span class="w-2.5 h-2.5 rounded-full <?= $seoScore['dotClass'] ?> animate-pulse"></span>
                <span class="font-bold text-xs uppercase <?= $seoScore['status'] === 'green' ? 'text-emerald-400' : ($seoScore['status'] === 'yellow' ? 'text-amber-400' : 'text-red-400') ?>">
                  <?= $seoScore['score'] ?>% (<?= $seoScore['label'] ?>)
                </span>
              </div>
            </td>
            <td class="text-right">
              <div class="flex items-center justify-end gap-2">
                <a href="<?= htmlspecialchars($previewUrl) ?>" target="_blank" class="btn-ghost py-1 px-2.5 text-xs text-gray-300 hover:text-white" title="View Page">
                  View ↗
                </a>
                <a href="/admin/page-edit.php?slug=<?= urlencode($p['slug']) ?>" class="btn-gold py-1 px-3 text-xs font-bold shadow-glow">
                  Edit
                </a>
                <?php if ($p['slug'] !== 'home'): ?>
                <a href="?delete=<?= urlencode($p['id'] ?? $p['slug']) ?>" data-confirm="Are you sure you want to delete this page?" class="btn-ghost py-1 px-2 text-xs text-red-400 hover:border-red-400" title="Delete Page">
                  ✕
                </a>
                <?php endif; ?>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</main>
</body>
</html>
