<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireSeoManagerOrAdmin();

$activeTab = trim($_GET['tab'] ?? 'post');
if (!in_array($activeTab, ['page', 'post'])) {
    $activeTab = 'post';
}

$allCategories = getCategories();
$pageCategories = getPageCategories();
$postCategories = getPostCategories();

// Handle Add / Edit Category
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = trim($_POST['action'] ?? 'add');
    $type   = in_array($_POST['type'] ?? '', ['page', 'post']) ? $_POST['type'] : $activeTab;
    $name   = trim($_POST['name'] ?? '');
    $slug   = trim($_POST['slug'] ?? '');
    $parentId = trim($_POST['parent_id'] ?? '');
    $desc   = trim($_POST['description'] ?? '');

    if ($action === 'edit') {
        $editId = trim($_POST['category_id'] ?? '');
        if (!empty($editId) && !empty($name)) {
            updateCategory($editId, [
                'name'        => $name,
                'slug'        => $slug,
                'parent_id'   => $parentId,
                'description' => $desc,
                'type'        => $type
            ]);
            setFlash('success', 'Category "' . htmlspecialchars($name) . '" updated successfully!');
        }
    } else {
        if (!empty($name)) {
            addCategory($name, $slug, $parentId, $desc, $type);
            setFlash('success', ucfirst($type) . ' Category "' . htmlspecialchars($name) . '" created successfully!');
        }
    }
    header('Location: /admin/categories.php?tab=' . urlencode($type));
    exit;
}

// Handle Delete Category
if (isset($_GET['delete'])) {
    $delId = trim($_GET['delete']);
    deleteCategory($delId);
    setFlash('success', 'Category deleted successfully.');
    header('Location: /admin/categories.php?tab=' . urlencode($activeTab));
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Taxonomies &amp; Categories — Estate HDR Admin</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8">
  <?= renderFlash() ?>

  <!-- Header & Description -->
  <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
    <div>
      <div class="section-tag mb-1">Content Structure &amp; Taxonomy</div>
      <h1 class="text-2xl sm:text-3xl font-black text-white uppercase tracking-tight">CATEGORIES &amp; TAXONOMIES</h1>
      <p class="text-gray-400 text-xs mt-1">Organize static pages and blog articles into dedicated hierarchical taxonomy buckets for optimal Google indexing.</p>
    </div>

    <!-- 2-Tab Filter Switcher -->
    <div class="inline-flex p-1.5 rounded-2xl bg-[#111118] border border-[#1E1E2E] shadow-xl self-start md:self-auto">
      <button type="button" onclick="switchTab('post')" id="tabBtnPost" class="px-5 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 <?= $activeTab === 'post' ? 'bg-gold text-dark shadow-glow' : 'text-gray-400 hover:text-white' ?>">
        <span>📝 Blog Categories</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] <?= $activeTab === 'post' ? 'bg-dark/30 text-dark' : 'bg-[#1E1E2E] text-gold' ?> font-mono font-bold"><?= count($postCategories) ?></span>
      </button>

      <button type="button" onclick="switchTab('page')" id="tabBtnPage" class="px-5 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 <?= $activeTab === 'page' ? 'bg-gold text-dark shadow-glow' : 'text-gray-400 hover:text-white' ?>">
        <span>📄 Page Categories</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] <?= $activeTab === 'page' ? 'bg-dark/30 text-dark' : 'bg-[#1E1E2E] text-gold' ?> font-mono font-bold"><?= count($pageCategories) ?></span>
      </button>
    </div>
  </div>

  <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
    
    <!-- LEFT: Add Category Form (5 Cols) -->
    <div class="lg:col-span-5 glass-card rounded-2xl p-6 border border-dark-border shadow-xl bg-[#111118]">
      <div class="flex items-center justify-between border-b border-[#1E1E2E] pb-3 mb-4">
        <h2 class="text-sm font-bold text-white flex items-center gap-2">
          <span>+</span> <span id="formTitleText">Add New <?= $activeTab === 'page' ? 'Page' : 'Blog' ?> Category</span>
        </h2>
        <span id="formBadgeText" class="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider <?= $activeTab === 'page' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' : 'bg-gold/20 text-gold border border-gold/30' ?>">
          <?= $activeTab === 'page' ? 'Static Pages' : 'Blog Posts' ?>
        </span>
      </div>

      <form method="POST" id="categoryForm" class="space-y-4">
        <?= csrfField() ?>
        <input type="hidden" name="action" id="formAction" value="add">
        <input type="hidden" name="category_id" id="formCategoryId" value="">
        <input type="hidden" name="type" id="formType" value="<?= htmlspecialchars($activeTab) ?>">

        <div>
          <label class="form-label text-xs">Category Name <span class="text-red-400">*</span></label>
          <input type="text" id="catNameInput" name="name" class="form-input text-sm" placeholder="e.g. Drone &amp; Aerial Photography" required oninput="autoGenerateSlug(this.value)">
        </div>

        <div>
          <label class="form-label text-xs">URL Slug</label>
          <input type="text" id="catSlugInput" name="slug" class="form-input text-xs font-mono" placeholder="drone-aerial-photography">
        </div>

        <div>
          <label class="form-label text-xs">Parent Category (Optional)</label>
          <select name="parent_id" id="catParentSelect" class="form-select text-xs">
            <option value="">None (Top-Level Category)</option>
            <!-- Populated via JavaScript dynamically based on active tab -->
          </select>
        </div>

        <div>
          <label class="form-label text-xs">Description</label>
          <textarea name="description" id="catDescInput" rows="3" class="form-input text-xs resize-y" placeholder="Brief description for SEO archives and meta taxonomy..."></textarea>
        </div>

        <div class="pt-2 flex items-center gap-3">
          <button type="submit" id="submitBtn" class="btn-gold w-full py-2.5 text-xs font-black shadow-glow flex items-center justify-center gap-1.5">
            <span id="submitBtnIcon">➕</span> <span id="submitBtnText">Create <?= $activeTab === 'page' ? 'Page' : 'Blog' ?> Category &rarr;</span>
          </button>
          <button type="button" id="cancelEditBtn" onclick="resetForm()" class="hidden btn-ghost py-2.5 px-4 text-xs font-bold border-[#2A2A3A] hover:border-red-400">
            Cancel
          </button>
        </div>
      </form>
    </div>

    <!-- RIGHT: Categories List (7 Cols) -->
    <div class="lg:col-span-7 glass-card rounded-2xl overflow-hidden border border-dark-border shadow-xl bg-[#111118]">
      
      <!-- BLOG CATEGORIES PANEL -->
      <div id="panelPost" class="<?= $activeTab === 'post' ? '' : 'hidden' ?>">
        <div class="p-4 border-b border-dark-border flex items-center justify-between bg-[#161622]/60">
          <div class="flex items-center gap-2">
            <span class="text-base">📝</span>
            <h3 class="text-xs font-black text-white uppercase tracking-wider">BLOG POST CATEGORIES</h3>
          </div>
          <span class="text-xs text-gold font-mono font-bold"><?= count($postCategories) ?> categories</span>
        </div>

        <div class="overflow-x-auto">
          <table class="dashboard-table w-full text-left text-xs">
            <thead>
              <tr>
                <th>Category Name</th>
                <th>Slug</th>
                <th>Description</th>
                <th class="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($postCategories)): ?>
              <tr>
                <td colspan="4" class="p-6 text-center text-gray-500 text-xs">No blog categories created yet.</td>
              </tr>
              <?php else: ?>
                <?php foreach ($postCategories as $cat): ?>
                <tr class="hover:bg-white/[0.02] transition-colors">
                  <td class="font-bold text-white">
                    <div class="flex items-center gap-2">
                      <?php if (!empty($cat['parent_id'])): ?>
                        <span class="text-gray-500 font-mono">↳</span>
                      <?php endif; ?>
                      <span><?= htmlspecialchars($cat['name']) ?></span>
                    </div>
                  </td>
                  <td class="font-mono text-gold text-[11px]">
                    /blog/category/<?= htmlspecialchars($cat['slug']) ?>
                  </td>
                  <td class="text-gray-400 max-w-xs truncate text-[11px]">
                    <?= htmlspecialchars($cat['description'] ?: '—') ?>
                  </td>
                  <td class="text-right whitespace-nowrap">
                    <button type="button" onclick='editCategory(<?= json_encode($cat) ?>)' class="text-gold hover:text-white text-xs font-bold mr-3 inline-flex items-center gap-0.5">
                      ✏️ Edit
                    </button>
                    <a href="?delete=<?= urlencode($cat['id']) ?>&tab=post" data-confirm="Delete blog category &quot;<?= htmlspecialchars(addslashes($cat['name'])) ?>&quot;?" class="text-red-400 hover:text-red-300 text-xs font-bold inline-flex items-center gap-0.5">
                      🗑️ Delete
                    </a>
                  </td>
                </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- PAGE CATEGORIES PANEL -->
      <div id="panelPage" class="<?= $activeTab === 'page' ? '' : 'hidden' ?>">
        <div class="p-4 border-b border-dark-border flex items-center justify-between bg-[#161622]/60">
          <div class="flex items-center gap-2">
            <span class="text-base">📄</span>
            <h3 class="text-xs font-black text-white uppercase tracking-wider">STATIC PAGE CATEGORIES</h3>
          </div>
          <span class="text-xs text-blue-400 font-mono font-bold"><?= count($pageCategories) ?> categories</span>
        </div>

        <div class="overflow-x-auto">
          <table class="dashboard-table w-full text-left text-xs">
            <thead>
              <tr>
                <th>Category Name</th>
                <th>Slug</th>
                <th>Description</th>
                <th class="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($pageCategories)): ?>
              <tr>
                <td colspan="4" class="p-6 text-center text-gray-500 text-xs">No page categories created yet.</td>
              </tr>
              <?php else: ?>
                <?php foreach ($pageCategories as $cat): ?>
                <tr class="hover:bg-white/[0.02] transition-colors">
                  <td class="font-bold text-white">
                    <div class="flex items-center gap-2">
                      <?php if (!empty($cat['parent_id'])): ?>
                        <span class="text-gray-500 font-mono">↳</span>
                      <?php endif; ?>
                      <span><?= htmlspecialchars($cat['name']) ?></span>
                    </div>
                  </td>
                  <td class="font-mono text-blue-400 text-[11px]">
                    /pages/<?= htmlspecialchars($cat['slug']) ?>
                  </td>
                  <td class="text-gray-400 max-w-xs truncate text-[11px]">
                    <?= htmlspecialchars($cat['description'] ?: '—') ?>
                  </td>
                  <td class="text-right whitespace-nowrap">
                    <button type="button" onclick='editCategory(<?= json_encode($cat) ?>)' class="text-gold hover:text-white text-xs font-bold mr-3 inline-flex items-center gap-0.5">
                      ✏️ Edit
                    </button>
                    <a href="?delete=<?= urlencode($cat['id']) ?>&tab=page" data-confirm="Delete page category &quot;<?= htmlspecialchars(addslashes($cat['name'])) ?>&quot;?" class="text-red-400 hover:text-red-300 text-xs font-bold inline-flex items-center gap-0.5">
                      🗑️ Delete
                    </a>
                  </td>
                </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>

  </div>
</main>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
const pageCategories = <?= json_encode($pageCategories) ?>;
const postCategories = <?= json_encode($postCategories) ?>;
let currentTab = '<?= $activeTab ?>';

function updateParentOptions(selectedParentId = '') {
  const select = document.getElementById('catParentSelect');
  select.innerHTML = '<option value="">None (Top-Level Category)</option>';
  
  const currentList = currentTab === 'page' ? pageCategories : postCategories;
  currentList.forEach(c => {
    if (!c.parent_id) {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = c.name;
      if (c.id === selectedParentId) opt.selected = true;
      select.appendChild(opt);
    }
  });
}

function switchTab(tab) {
  currentTab = tab;
  document.getElementById('formType').value = tab;
  
  const isPage = (tab === 'page');
  document.getElementById('tabBtnPost').className = `px-5 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${!isPage ? 'bg-gold text-dark shadow-glow' : 'text-gray-400 hover:text-white'}`;
  document.getElementById('tabBtnPage').className = `px-5 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${isPage ? 'bg-gold text-dark shadow-glow' : 'text-gray-400 hover:text-white'}`;

  document.getElementById('panelPost').classList.toggle('hidden', isPage);
  document.getElementById('panelPage').classList.toggle('hidden', !isPage);

  document.getElementById('formTitleText').textContent = `Add New ${isPage ? 'Page' : 'Blog'} Category`;
  document.getElementById('formBadgeText').textContent = isPage ? 'Static Pages' : 'Blog Posts';
  document.getElementById('formBadgeText').className = `px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${isPage ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' : 'bg-gold/20 text-gold border border-gold/30'}`;

  document.getElementById('submitBtnText').textContent = `Create ${isPage ? 'Page' : 'Blog'} Category →`;

  resetForm();
  updateParentOptions();

  // Update URL without reload
  const url = new URL(window.location);
  url.searchParams.set('tab', tab);
  window.history.replaceState({}, '', url);
}

function autoGenerateSlug(name) {
  const slugInput = document.getElementById('catSlugInput');
  if (!slugInput.dataset.manual) {
    slugInput.value = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  }
}

document.getElementById('catSlugInput').addEventListener('input', function() {
  this.dataset.manual = 'true';
});

function editCategory(cat) {
  document.getElementById('formAction').value = 'edit';
  document.getElementById('formCategoryId').value = cat.id;
  document.getElementById('catNameInput').value = cat.name;
  document.getElementById('catSlugInput').value = cat.slug;
  document.getElementById('catSlugInput').dataset.manual = 'true';
  document.getElementById('catDescInput').value = cat.description || '';
  
  if (cat.type && cat.type !== currentTab) {
    switchTab(cat.type);
  }

  updateParentOptions(cat.parent_id || '');
  
  document.getElementById('formTitleText').textContent = `Edit Category: ${cat.name}`;
  document.getElementById('submitBtnIcon').textContent = '💾';
  document.getElementById('submitBtnText').textContent = 'Update Category Changes';
  document.getElementById('cancelEditBtn').classList.remove('hidden');

  document.getElementById('categoryForm').scrollIntoView({ behavior: 'smooth' });
}

function resetForm() {
  document.getElementById('formAction').value = 'add';
  document.getElementById('formCategoryId').value = '';
  document.getElementById('catNameInput').value = '';
  document.getElementById('catSlugInput').value = '';
  document.getElementById('catSlugInput').dataset.manual = '';
  document.getElementById('catDescInput').value = '';
  
  const isPage = (currentTab === 'page');
  document.getElementById('formTitleText').textContent = `Add New ${isPage ? 'Page' : 'Blog'} Category`;
  document.getElementById('submitBtnIcon').textContent = '➕';
  document.getElementById('submitBtnText').textContent = `Create ${isPage ? 'Page' : 'Blog'} Category →`;
  document.getElementById('cancelEditBtn').classList.add('hidden');
  
  updateParentOptions();
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
  updateParentOptions();
});
</script>

</body>
</html>

