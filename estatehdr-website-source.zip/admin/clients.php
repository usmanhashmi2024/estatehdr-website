<?php
error_reporting(E_ALL & ~E_NOTICE);
@ini_set('display_errors', '1');

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireManagerOrAdmin();

// ── Fallback Helpers (Prevents missing deleteUser error) ──────────────────────
if (!function_exists('deleteUser')) {
    function deleteUser(string $userId): bool {
        $file = defined('USERS_FILE') ? USERS_FILE : (DATA_PATH . 'users.json');
        if (!file_exists($file)) return false;
        $users = json_decode(@file_get_contents($file), true) ?: [];
        $filtered = array_values(array_filter($users, fn($u) => ($u['id'] ?? '') !== $userId));
        $res = (bool)@file_put_contents($file, json_encode($filtered, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX);
        $prefPath = (defined('PREFERENCES_PATH') ? PREFERENCES_PATH : (DATA_PATH . 'preferences/')) . $userId . '.json';
        if (file_exists($prefPath)) @unlink($prefPath);
        return $res;
    }
}


// Handle Edit Client Details POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_client_details'])) {
    verifyCsrf();
    $cid     = trim($_POST['client_id'] ?? '');
    $name    = trim($_POST['name'] ?? '');
    $company = trim($_POST['company'] ?? '');
    $phone   = trim($_POST['phone'] ?? '');
    $country = trim($_POST['country'] ?? '');
    $newPass = trim($_POST['new_password'] ?? '');
    $isActive = isset($_POST['is_active']);

    if (empty($cid) || empty($name)) {
        setFlash('error', 'Client Name is required.');
    } else {
        updateUserProfile($cid, $name, $phone, $company, $country, '', $isActive);
        if (!empty($newPass)) {
            updateUserPassword($cid, $newPass);
        }
        setFlash('success', 'Client profile for "' . htmlspecialchars($name) . '" updated successfully!');
    }
    header('Location: /admin/clients.php');
    exit;
}


// Handle Delete Client (Owner / God Rights)
if (isset($_GET['delete'])) {
    if (!isOwner()) {
        setFlash('error', 'Access Denied: Only the Owner/CEO can delete client accounts.');
        header('Location: /admin/clients.php');
        exit;
    }
    $delId = trim($_GET['delete']);
    if (deleteUser($delId)) {
        setFlash('success', "Client account {$delId} was permanently deleted.");
    } else {
        setFlash('error', "Could not delete client {$delId}.");
    }
    header('Location: /admin/clients.php');
    exit;
}


// Handle Balance Adjustment & Payment Recording POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adjust_balance'])) {
    verifyCsrf();
    $clientId = trim($_POST['client_id'] ?? '');
    $adjustmentType = trim($_POST['adjustment_type'] ?? 'record_payment');
    $currentBalance = (float)($_POST['current_balance'] ?? 0.0);
    $paymentAmount  = (float)($_POST['payment_amount'] ?? 0.0);
    $directBalance  = (float)($_POST['direct_balance'] ?? 0.0);
    $paymentMethod  = trim($_POST['payment_method'] ?? 'PayPal') ?: 'PayPal';
    $paymentNote    = trim($_POST['payment_note'] ?? 'Account charges updated by admin');

    $finalBalance = $currentBalance;

    if ($adjustmentType === 'record_payment' && $paymentAmount > 0) {
        // e.g. Client owed $200 (currentBalance=200), pays $100 -> new balance = 200 - 100 = $100
        $finalBalance = max(0.0, $currentBalance - $paymentAmount);
        $note = !empty($paymentNote) ? $paymentNote : ("Payment of $" . number_format($paymentAmount, 2) . " received via " . $paymentMethod);
        addLedgerEntry($clientId, null, 'payment', $paymentAmount, $paymentMethod, $note);
    } elseif ($adjustmentType === 'direct_set') {
        $finalBalance = $directBalance;
        $diff = $directBalance - $currentBalance;
        $note = !empty($paymentNote) ? $paymentNote : ("Direct balance adjustment to $" . number_format($finalBalance, 2));
        if ($diff > 0) {
            addLedgerEntry($clientId, null, 'billed', $diff, 'Manual Adjustment', $note);
        } elseif ($diff < 0) {
            addLedgerEntry($clientId, null, 'payment', abs($diff), 'Manual Adjustment', $note);
        }
    }

    updateClientBalance($clientId, $finalBalance);

    $statusMsg = $finalBalance > 0 ? ("US -$" . number_format($finalBalance, 2) . " (Still Due)") : "US $0.00 (Cleared)";
    setFlash('success', 'Payment / Charges for client ' . htmlspecialchars($clientId) . ' updated successfully! Current Due: ' . $statusMsg);
    header('Location: /admin/clients.php');
    exit;
}

// Automatically self-heal any unbilled delivered orders or out-of-sync ledger records
if (function_exists('reconcileAllOrdersLedger')) {
    reconcileAllOrdersLedger();
}

$allUsers  = getUsers();
$allOrders = getAllOrders();
$allLedger = getLedger();

// Map orders & ledger stats per client
$clientStats = [];
foreach ($allUsers as $u) {
    $uid = $u['id'];
    $balance = getUserBalance($uid);
    $ordersCount = count(array_filter($allOrders, fn($o) => ($o['user_id'] ?? '') === $uid));
    
    // Check saas_orders count if higher
    $saasFile = defined('SAAS_ORDERS_FILE') ? SAAS_ORDERS_FILE : (DATA_PATH . 'saas_orders.json');
    if (file_exists($saasFile)) {
        $saasOrders = readJson($saasFile) ?: [];
        $saasCount = count(array_filter($saasOrders, fn($so) => ($so['user_id'] ?? $so['client_id'] ?? '') === $uid || strcasecmp($so['client_email'] ?? '', $u['email'] ?? '') === 0));
        $ordersCount = max($ordersCount, $saasCount);
    }

    $clientStats[$uid] = [
        'orders_count' => $ordersCount,
        'balance'      => $balance,
    ];
}

$search = trim($_GET['q'] ?? '');
if ($search !== '') {
    $kw = strtolower($search);
    $allUsers = array_filter($allUsers, function($u) use ($kw) {
        return str_contains(strtolower($u['name']), $kw) ||
               str_contains(strtolower($u['email']), $kw) ||
               str_contains(strtolower($u['phone'] ?? ''), $kw);
    });
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Clients CRM &amp; Charges — Estate HDR Admin</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-[#0A0A0F] text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8">
  <!-- Back Navigation -->
  <div class="mb-4">
    <a href="/admin/" class="btn-ghost py-2 px-4 text-xs font-bold inline-flex items-center gap-2 border border-[#1E1E2E] hover:border-gold rounded-xl">
      <span>←</span> <span>Back to Dashboard</span>
    </a>
  </div>
  <?= renderFlash() ?>

  <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
    <div>
      <div class="section-tag mb-1">Customer CRM &amp; Ledger Audit</div>
      <h1 class="text-3xl font-black text-white">CLIENTS DIRECTORY &amp; CHARGES</h1>
      <p class="text-gray-400 text-sm mt-1">Manage client profiles, record partial/full wire &amp; card payments, and adjust pending charges (+ / - credit).</p>
    </div>

    <div class="flex items-center gap-3">
      <a href="/admin/export-leads.php?type=clients" class="py-3 px-5 text-sm font-bold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white shadow-md inline-flex items-center gap-2 transition-all" title="Export all client emails and contact info to CSV for Email Marketing">
        <span>📥</span> <span>Export Clients (CSV)</span>
      </a>
      <a href="/admin/client-new.php" class="btn-gold py-3 px-6 text-sm font-bold shadow-glow inline-flex items-center gap-2 rounded-xl">
        <span>+</span> <span>Add New Client</span>
      </a>
    </div>
  </div>

  <!-- Search Filter -->
  <div class="glass-card rounded-2xl p-5 mb-6 border border-[#1E1E2E] flex items-center justify-between gap-4 bg-[#111118]">
    <form method="GET" class="flex items-center gap-3 w-full max-w-md">
      <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" class="form-input text-sm py-2.5 px-4" placeholder="Search by name, email, or phone...">
      <button type="submit" class="btn-gold py-2.5 px-5 text-xs font-bold">Search</button>
      <?php if ($search): ?><a href="/admin/clients.php" class="text-xs text-gray-400 hover:text-white">Clear</a><?php endif; ?>
    </form>
    <div class="text-sm text-gray-400 font-mono"><?= count($allUsers) ?> registered agency accounts</div>
  </div>

  <!-- Clients Data Table -->
  <div class="glass-card rounded-2xl overflow-hidden border border-[#1E1E2E] shadow-2xl bg-[#111118]">
    <div class="overflow-x-auto">
      <table class="dashboard-table w-full text-left text-sm">
        <thead>
          <tr>
            <th>CLIENT ID / NAME</th>
            <th>EMAIL &amp; PHONE</th>
            <th>COMPANY</th>
            <th>TOTAL ORDERS</th>
            <th>CLIENT CHARGES &amp; BALANCE</th>
            <th class="text-right">ACTIONS</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($allUsers as $client): 
            $cid = $client['id'];
            $stats = $clientStats[$cid] ?? ['orders_count' => 0, 'balance' => ['outstanding_balance' => 0.0, 'net_balance' => 0.0]];
            $bal = isset($client['balance']) ? (float)$client['balance'] : (float)($stats['balance']['net_balance'] ?? ($stats['balance']['outstanding_balance'] ?? 0.0));
            
            if ($bal > 0) {
                $pillCls = 'bg-red-600/20 text-red-400 border border-red-500/40';
                $pillText = 'US -$' . number_format($bal, 2) . ' (Due)';
            } elseif ($bal < 0) {
                $pillCls = 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40';
                $pillText = 'US +$' . number_format(abs($bal), 2) . ' (Credit)';
            } else {
                $pillCls = 'bg-blue-600/20 text-blue-400 border border-blue-500/40';
                $pillText = 'US $0.00 (Clear)';
            }
          ?>
          <tr class="hover:bg-white/[0.02]">
            <td>
              <div class="font-bold text-white text-base"><?= htmlspecialchars($client['name']) ?></div>
              <div class="text-xs font-mono text-gold font-bold mt-0.5">CID: <?= htmlspecialchars($cid) ?></div>
            </td>
            <td>
              <div class="text-gray-300 font-mono"><?= htmlspecialchars($client['email']) ?></div>
              <div class="text-xs text-gray-400 font-mono"><?= htmlspecialchars($client['phone'] ?? '—') ?></div>
            </td>
            <td class="text-gray-300">
              <?= htmlspecialchars($client['company'] ?? 'Independent Agency') ?>
            </td>
            <td class="font-mono text-white font-bold">
              <?= (int)$stats['orders_count'] ?> jobs
            </td>
            <td>
              <span class="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-mono font-black shadow-sm <?= $pillCls ?>">
                <?= $pillText ?>
              </span>
            </td>
            <td class="text-right">
              <div class="flex items-center justify-end gap-2.5">
                <button onclick='openAdjustBalanceModal("<?= $cid ?>", "<?= htmlspecialchars($client['name'], ENT_QUOTES) ?>", <?= (float)$bal ?>)' class="btn-ghost py-2 px-3.5 text-xs font-bold text-gold border-gold/40 hover:bg-gold/10" title="Adjust Charges / Record Payment">
                  💰 Adjust Charges &amp; Pay
                </button>
                <a href="/admin/invoice.php?client_id=<?= urlencode($cid) ?>" class="btn-ghost py-2 px-3.5 text-xs font-bold text-sky-400 border-sky-500/40 hover:bg-sky-500/10 inline-flex items-center gap-1.5" title="Generate, Edit &amp; Email Official PDF Invoice">
                  <span>📄</span> <span>Invoice &amp; Pay Link</span>
                </a>
                <a href="/admin/order-new.php?client_id=<?= urlencode($cid) ?>" class="btn-gold py-2 px-4 text-xs font-bold shadow-glow">
                  + Proxy Order
                </a>
                <button type="button" onclick='openEditClientModal(<?= json_encode($client, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>)' class="p-2 rounded-xl bg-dark border border-dark-border text-blue-400 hover:text-blue-300 hover:border-blue-500/40 transition-all" title="Edit Client Profile">
                  ✏️
                </button>
                <?php if (isOwner()): ?>
                  <button type="button" onclick="openDeleteClientModal('<?= htmlspecialchars($cid, ENT_QUOTES) ?>', '<?= htmlspecialchars($client['name'], ENT_QUOTES) ?>', '<?= htmlspecialchars($client['email'], ENT_QUOTES) ?>')" class="p-2 rounded-xl bg-dark border border-dark-border text-gray-400 hover:text-red-400 hover:border-red-500/40 transition-all" title="Delete Client Account">
                    🗑️
                  </button>
                <?php endif; ?>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</main>

<!-- Advanced Adjust Charges & Payment Modal -->
<div id="balanceModal" class="hidden fixed inset-0 z-50 bg-dark/80 backdrop-blur-md flex items-center justify-center p-4">
  <div class="glass-card rounded-2xl p-6 sm:p-8 max-w-lg w-full border border-gold/40 shadow-2xl space-y-5 bg-[#111118]">
    <div class="flex items-center justify-between border-b border-[#1E1E2E] pb-3">
      <h3 class="text-lg font-black text-white flex items-center gap-2">
        <span>💰</span> <span>Adjust Client Charges &amp; Record Payment</span>
      </h3>
      <button onclick="closeBalanceModal()" class="text-gray-400 hover:text-white text-xl font-bold">&times;</button>
    </div>

    <form method="POST" class="space-y-4" oninput="calculateRemaining()">
      <?= csrfField() ?>
      <input type="hidden" name="adjust_balance" value="1">
      <input type="hidden" id="modalClientId" name="client_id" value="">
      <input type="hidden" id="modalCurrentBalanceRaw" name="current_balance" value="0.0">

      <!-- Current Client Summary -->
      <div class="p-4 rounded-xl bg-[#0D0D14] border border-[#1E1E2E] flex items-center justify-between">
        <div>
          <div class="text-xs text-gray-400 uppercase font-bold">Client Account</div>
          <div id="modalClientNameDisplay" class="text-sm font-bold text-white mt-0.5">Sarah Agency (CL-1002)</div>
        </div>
        <div class="text-right">
          <div class="text-xs text-gray-400 uppercase font-bold">Current Unpaid Charges</div>
          <div id="modalCurrentDueDisplay" class="text-base font-mono font-black text-red-400 mt-0.5">US -$100.00</div>
        </div>
      </div>

      <!-- Action Mode Switcher -->
      <div>
        <label class="form-label text-xs">Adjustment Method</label>
        <div class="grid grid-cols-2 gap-3 text-xs font-bold">
          <label class="flex items-center gap-2 p-3 rounded-xl bg-[#1A1A24] border border-[#2A2A3A] cursor-pointer hover:border-gold/40">
            <input type="radio" name="adjustment_type" value="record_payment" id="modeRecordPayment" checked onchange="toggleMode()" class="accent-gold">
            <span>💵 Record Payment Received</span>
          </label>
          <label class="flex items-center gap-2 p-3 rounded-xl bg-[#1A1A24] border border-[#2A2A3A] cursor-pointer hover:border-gold/40">
            <input type="radio" name="adjustment_type" value="direct_set" id="modeDirectSet" onchange="toggleMode()" class="accent-gold">
            <span>⚙️ Direct Set (+ / -)</span>
          </label>
        </div>
      </div>

      <!-- Method 1: Record Payment Received -->
      <div id="recordPaymentSection" class="space-y-3">
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label class="form-label text-xs font-bold">Payment Received ($ USD) <span class="text-red-400">*</span></label>
            <input type="number" step="0.01" id="paymentAmountInput" name="payment_amount" class="form-input text-base font-mono font-black text-emerald-400" placeholder="e.g. 60.00">
          </div>
          <div>
            <label class="form-label text-xs font-bold">Payment Method</label>
            <select name="payment_method" class="form-select text-xs py-2 bg-[#141422] font-semibold text-white">
              <option value="PayPal">🅿️ PayPal (Default)</option>
              <option value="Payoneer">🟠 Payoneer</option>
              <option value="Wise">🟢 Wise (TransferWise)</option>
              <option value="Bank Transfer">🏛️ Bank Transfer / Wire</option>
              <option value="Stripe / Card">💳 Stripe / Card</option>
              <option value="Direct Cash">💵 Direct Cash / Cheque</option>
            </select>
          </div>
        </div>
        <div class="p-3 rounded-xl bg-blue-600/10 border border-blue-500/30 text-xs text-blue-300 font-mono">
          <span>Remaining Charges After Payment: </span>
          <strong id="remainingPreview" class="text-white font-black">$0.00</strong>
        </div>
      </div>

      <!-- Method 2: Direct Set Balance -->
      <div id="directSetSection" class="hidden space-y-3">
        <div>
          <label class="form-label text-xs">Direct Set Balance ($ USD)</label>
          <input type="number" step="0.01" id="directBalanceInput" name="direct_balance" class="form-input text-base font-mono font-black text-gold" placeholder="Positive for Due, Negative for Credit">
          <p class="text-gray-500 text-[11px] mt-1">Example: <strong>40.00</strong> = Client owes $40. <strong>-20.00</strong> = Client has $20 prepaid credit.</p>
        </div>
      </div>

      <!-- Audit Note -->
      <div>
        <label class="form-label text-xs">Transaction / Audit Note</label>
        <input type="text" name="payment_note" class="form-input text-xs" placeholder="e.g. Received $60 via Stripe / Wire Transfer on Aug 21">
      </div>

      <div class="flex items-center justify-end gap-3 pt-3 border-t border-[#1E1E2E]">
        <button type="button" onclick="closeBalanceModal()" class="btn-ghost py-2.5 px-5 text-xs">Cancel</button>
        <button type="submit" class="btn-gold py-2.5 px-7 text-xs font-black shadow-glow">Update &amp; Save Charges</button>
      </div>
    </form>
  </div>
</div>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
let clientCurrentBal = 0.0;

function openAdjustBalanceModal(cid, name, currentBal) {
  clientCurrentBal = parseFloat(currentBal) || 0.0;
  document.getElementById('modalClientId').value = cid;
  document.getElementById('modalClientNameDisplay').textContent = `${name} (${cid})`;
  document.getElementById('modalCurrentBalanceRaw').value = clientCurrentBal.toFixed(2);
  
  if (clientCurrentBal > 0) {
    document.getElementById('modalCurrentDueDisplay').textContent = `US -$${clientCurrentBal.toFixed(2)} (Due)`;
    document.getElementById('modalCurrentDueDisplay').className = 'text-base font-mono font-black text-red-400 mt-0.5';
  } else if (clientCurrentBal < 0) {
    document.getElementById('modalCurrentDueDisplay').textContent = `US +$${Math.abs(clientCurrentBal).toFixed(2)} (Credit)`;
    document.getElementById('modalCurrentDueDisplay').className = 'text-base font-mono font-black text-emerald-400 mt-0.5';
  } else {
    document.getElementById('modalCurrentDueDisplay').textContent = `US $0.00 (Clear)`;
    document.getElementById('modalCurrentDueDisplay').className = 'text-base font-mono font-black text-blue-400 mt-0.5';
  }

  document.getElementById('paymentAmountInput').value = '';
  document.getElementById('directBalanceInput').value = clientCurrentBal.toFixed(2);
  document.getElementById('modeRecordPayment').checked = true;
  toggleMode();
  calculateRemaining();

  document.getElementById('balanceModal').classList.remove('hidden');
}

function closeBalanceModal() {
  document.getElementById('balanceModal').classList.add('hidden');
}

function toggleMode() {
  const isRecordPayment = document.getElementById('modeRecordPayment').checked;
  document.getElementById('recordPaymentSection').classList.toggle('hidden', !isRecordPayment);
  document.getElementById('directSetSection').classList.toggle('hidden', isRecordPayment);
}

function calculateRemaining() {
  const paid = parseFloat(document.getElementById('paymentAmountInput').value) || 0.0;
  const rem = clientCurrentBal - paid;
  const preview = document.getElementById('remainingPreview');
  if (rem > 0) {
    preview.textContent = `US -$${rem.toFixed(2)} (Still Due)`;
    preview.className = 'text-red-400 font-black';
  } else if (rem < 0) {
    preview.textContent = `US +$${Math.abs(rem).toFixed(2)} (Overpaid Credit)`;
    preview.className = 'text-emerald-400 font-black';
  } else {
    preview.textContent = `US $0.00 (Fully Settled)`;
    preview.className = 'text-blue-400 font-black';
  }
}
</script>

<!-- CUSTOM DELETE CLIENT MODAL (God Mode) -->
<div id="deleteClientModal" class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 max-w-md w-full border border-red-500/50 shadow-2xl space-y-4">
    <div class="flex items-center gap-3">
      <div class="w-10 h-10 rounded-2xl bg-red-600/20 border border-red-500 flex items-center justify-center text-red-400 text-xl font-black">
        ⚠️
      </div>
      <div>
        <h3 class="text-base font-black text-white">Delete Client Account?</h3>
        <p class="text-xs text-gray-400">Permanently delete client login and profile records.</p>
      </div>
    </div>

    <div class="p-3.5 rounded-2xl bg-red-950/30 border border-red-800/50 text-xs text-red-200 space-y-1">
      <div>Client: <strong id="deleteClientName" class="text-white"></strong> (<span id="deleteClientId" class="font-mono text-gold font-bold"></span>)</div>
      <div class="text-[11px] text-gray-400 font-mono" id="deleteClientEmail"></div>
    </div>

    <div class="flex items-center justify-end gap-3 pt-2">
      <button type="button" onclick="closeDeleteClientModal()" class="btn-ghost py-2.5 px-4 text-xs font-bold">Cancel</button>
      <a id="confirmDeleteClientBtn" href="#" class="py-2.5 px-5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs shadow-lg transition-all inline-flex items-center gap-1.5">
        <span>🗑️ Yes, Delete Client</span>
      </a>
    </div>
  </div>
</div>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
function openDeleteClientModal(cid, name, email) {
  document.getElementById('deleteClientId').textContent = cid;
  document.getElementById('deleteClientName').textContent = name;
  document.getElementById('deleteClientEmail').textContent = email;
  document.getElementById('confirmDeleteClientBtn').href = '/admin/clients.php?delete=' + encodeURIComponent(cid);
  document.getElementById('deleteClientModal').classList.remove('hidden');
}

function closeDeleteClientModal() {
  document.getElementById('deleteClientModal').classList.add('hidden');
}
</script>


<!-- CUSTOM EDIT CLIENT MODAL -->
<div id="editClientModal" class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 sm:p-8 max-w-lg w-full border border-blue-500/40 shadow-2xl space-y-5">
    <div class="flex items-center justify-between border-b border-dark-border pb-3">
      <h3 class="text-base font-black text-white flex items-center gap-2">
        <span>✏️</span> <span>Edit Client Profile</span>
      </h3>
      <button type="button" onclick="closeEditClientModal()" class="text-gray-400 hover:text-white text-lg">&times;</button>
    </div>

    <form method="POST" action="/admin/clients.php" class="space-y-4">
      <?= csrfField() ?>
      <input type="hidden" name="edit_client_details" value="1">
      <input type="hidden" name="client_id" id="editClientId">

      <div>
        <label class="form-label text-xs">Primary Contact Name <span class="text-red-400">*</span></label>
        <input type="text" name="name" id="editClientName" class="form-input text-xs py-2 bg-[#161622] w-full" required>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label class="form-label text-xs">Agency / Company</label>
          <input type="text" name="company" id="editClientCompany" class="form-input text-xs py-2 bg-[#161622] w-full">
        </div>
        <div>
          <label class="form-label text-xs">Phone / WhatsApp</label>
          <input type="text" name="phone" id="editClientPhone" class="form-input text-xs py-2 bg-[#161622] w-full">
        </div>
      </div>

      <div>
        <label class="form-label text-xs">Country / Region</label>
        <input type="text" name="country" id="editClientCountry" class="form-input text-xs py-2 bg-[#161622] w-full">
      </div>

      <div>
        <label class="form-label text-xs">Reset Client Password (Optional)</label>
        <input type="password" name="new_password" class="form-input text-xs py-2 bg-[#161622] w-full" placeholder="Leave blank to keep unchanged" autocomplete="new-password">
      </div>

      <div class="flex items-center justify-end gap-3 pt-2 border-t border-dark-border">
        <button type="button" onclick="closeEditClientModal()" class="btn-ghost py-2.5 px-4 text-xs font-bold">Cancel</button>
        <button type="submit" class="btn-gold py-2.5 px-6 text-xs font-black shadow-glow">Save Client Changes</button>
      </div>
    </form>
  </div>
</div>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
function openEditClientModal(client) {
  if (!client) return;
  document.getElementById('editClientId').value = client.id || '';
  document.getElementById('editClientName').value = client.name || '';
  document.getElementById('editClientCompany').value = client.company || '';
  document.getElementById('editClientPhone').value = client.phone || '';
  document.getElementById('editClientCountry').value = client.country || 'United States';
  document.getElementById('editClientModal').classList.remove('hidden');
}
function closeEditClientModal() {
  document.getElementById('editClientModal').classList.add('hidden');
}
</script>

</body>
</html>
