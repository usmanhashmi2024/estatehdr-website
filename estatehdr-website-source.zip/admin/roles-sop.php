<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireAdmin();

$currentAdmin = currentAdminUser();
$adminRoles   = getAdminRoles();
$isOwner          = in_array('owner', $adminRoles) || in_array('super_admin', $adminRoles);
$isManagerOnly    = (in_array('manager', $adminRoles) || in_array('production_manager', $adminRoles)) && !$isOwner;
$isSupervisorOnly = in_array('supervisor', $adminRoles) && !$isManagerOnly && !$isOwner;
$isTeamLeadOnly   = in_array('team_lead', $adminRoles) && !$isSupervisorOnly && !$isManagerOnly && !$isOwner;
$isPhotoEditor    = (in_array('photo_editor', $adminRoles) || in_array('editor', $adminRoles)) && !$isManagerOnly && !$isOwner && !$isSupervisorOnly && !$isTeamLeadOnly;
$isHR             = in_array('hr', $adminRoles) && !$isManagerOnly && !$isOwner;
$isSeoManager     = in_array('seo_manager', $adminRoles) && !$isManagerOnly && !$isOwner;

$activeTab = trim($_GET['tab'] ?? '');

$backUrl = '/admin/';
$backLabel = 'Back to Dashboard';

// Strict Role Tab Lockdown & Back Target
if ($isPhotoEditor) {
    $activeTab = 'editor';
    $backUrl   = '/admin/editor-dashboard.php';
    $backLabel = 'Back to My Workspace';
} elseif ($isTeamLeadOnly) {
    $activeTab = 'teamlead';
    $backUrl   = '/admin/teamlead-dashboard.php';
    $backLabel = 'Back to Team Lead Hub';
} elseif ($isSupervisorOnly) {
    $activeTab = 'supervisor';
    $backUrl   = '/admin/supervisor-dashboard.php';
    $backLabel = 'Back to Supervisor Center';
} elseif ($isManagerOnly) {
    $activeTab = 'manager';
    $backUrl   = '/admin/manager-dashboard.php';
    $backLabel = 'Back to Manager Analytics';
} elseif ($isHR) {
    $activeTab = 'hr';
    $backUrl   = '/admin/hr-dashboard.php';
    $backLabel = 'Back to HR Portal';
} elseif ($isSeoManager) {
    $activeTab = 'seo';
    $backUrl   = '/admin/pages.php';
    $backLabel = 'Back to Pages CMS';
} elseif ($isOwner) {
    if (empty($activeTab)) $activeTab = 'overview';
    $backUrl   = '/admin/users.php';
    $backLabel = 'Back to Staff Directory';
} elseif (empty($activeTab)) {
    $activeTab = 'overview';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Production Roles &amp; SOP Handbook — Estate HDR</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
<style nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
@media print {
  body { background: #fff !important; color: #000 !important; }
  nav, footer, .no-print { display: none !important; }
  .glass-card { background: #fff !important; border: 1px solid #ddd !important; box-shadow: none !important; color: #000 !important; }
  .text-white { color: #000 !important; }
  .text-gray-300, .text-gray-400 { color: #444 !important; }
}
</style>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8 space-y-8">
  
  <!-- Back & Header Actions -->
  <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
    <a href="<?= htmlspecialchars($backUrl) ?>" class="btn-ghost py-2 px-4 text-xs font-bold inline-flex items-center gap-2 border border-[#1E1E2E] hover:border-gold rounded-xl">
      <span>←</span> <span><?= htmlspecialchars($backLabel) ?></span>
    </a>

    <div class="flex items-center gap-3 no-print">
      <button onclick="window.print()" class="btn-ghost py-2 px-4 text-xs font-bold inline-flex items-center gap-2 border border-[#1E1E2E] hover:border-gold rounded-xl">
        <span>🖨️</span> <span>Print / Save PDF SOP</span>
      </button>
    </div>
  </div>

  <!-- Hero Title Card -->
  <div class="glass-card rounded-3xl p-8 sm:p-10 border border-gold/30 shadow-2xl bg-gradient-to-br from-gold/10 via-[#111118] to-[#0A0A0F]">
    <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
      <div>
        <div class="section-tag mb-2">Company Operational SOP &amp; Organizational Structure</div>
        <h1 class="text-3xl sm:text-4xl font-black text-white">Real Estate Photo Editing Production Company</h1>
        <p class="text-gray-300 text-sm mt-3 max-w-3xl">
          Official roles, core responsibilities, daily workflow matrices, KPIs, and escalation protocols.
        </p>
      </div>
      <div class="flex flex-wrap gap-2 text-xs font-mono">
        <span class="px-3 py-1.5 rounded-xl bg-dark/80 border border-dark-border text-gold font-bold">🏢 Production</span>
        <span class="px-3 py-1.5 rounded-xl bg-dark/80 border border-dark-border text-emerald-400 font-bold">🔍 Quality Control</span>
        <span class="px-3 py-1.5 rounded-xl bg-dark/80 border border-dark-border text-blue-400 font-bold">⚙️ Operations</span>
        <span class="px-3 py-1.5 rounded-xl bg-dark/80 border border-dark-border text-purple-400 font-bold">👥 HR &amp; Admin</span>
      </div>
    </div>
  </div>

  <!-- Role Navigation Tabs (Strictly Filtered by Access Role — Only CEO / Owner sees all tabs) -->
  <div class="flex flex-wrap items-center gap-2 border-b border-dark-border pb-4 no-print text-xs font-bold">
    <?php if ($isOwner): ?>
      <!-- ONLY CEO / Owner sees all organizational tabs -->
      <a href="?tab=overview" class="px-4 py-2.5 rounded-xl transition-all <?= $activeTab === 'overview' ? 'bg-gold text-dark font-black shadow-glow' : 'bg-dark border border-dark-border text-gray-300 hover:text-white' ?>">🏛️ Hierarchy &amp; Workflow</a>
      <a href="?tab=editor" class="px-4 py-2.5 rounded-xl transition-all <?= $activeTab === 'editor' ? 'bg-gold text-dark font-black shadow-glow' : 'bg-dark border border-dark-border text-gray-300 hover:text-white' ?>">1. Photo Editor SOP</a>
      <a href="?tab=teamlead" class="px-4 py-2.5 rounded-xl transition-all <?= $activeTab === 'teamlead' ? 'bg-gold text-dark font-black shadow-glow' : 'bg-dark border border-dark-border text-gray-300 hover:text-white' ?>">2. Team Lead SOP</a>
      <a href="?tab=supervisor" class="px-4 py-2.5 rounded-xl transition-all <?= $activeTab === 'supervisor' ? 'bg-gold text-dark font-black shadow-glow' : 'bg-dark border border-dark-border text-gray-300 hover:text-white' ?>">3. Supervisor SOP</a>
      <a href="?tab=manager" class="px-4 py-2.5 rounded-xl transition-all <?= $activeTab === 'manager' ? 'bg-gold text-dark font-black shadow-glow' : 'bg-dark border border-dark-border text-gray-300 hover:text-white' ?>">4. Production Manager SOP</a>
      <a href="?tab=hr" class="px-4 py-2.5 rounded-xl transition-all <?= $activeTab === 'hr' ? 'bg-gold text-dark font-black shadow-glow' : 'bg-dark border border-dark-border text-gray-300 hover:text-white' ?>">5. HR Department SOP</a>
      <a href="?tab=seo" class="px-4 py-2.5 rounded-xl transition-all <?= $activeTab === 'seo' ? 'bg-gold text-dark font-black shadow-glow' : 'bg-dark border border-dark-border text-gray-300 hover:text-white' ?>">🌐 SEO &amp; Content SOP</a>
      <a href="?tab=escalation" class="px-4 py-2.5 rounded-xl transition-all <?= $activeTab === 'escalation' ? 'bg-gold text-dark font-black shadow-glow' : 'bg-dark border border-dark-border text-gray-300 hover:text-white' ?>">🚨 Escalation &amp; Rules</a>

    <?php elseif ($isManagerOnly): ?>
      <!-- Production Manager sees ONLY Manager SOP -->
      <a href="?tab=manager" class="px-4 py-2.5 rounded-xl bg-gold text-dark font-black shadow-glow">4. Production Manager SOP</a>

    <?php elseif ($isSupervisorOnly): ?>
      <!-- Supervisor sees ONLY Supervisor SOP -->
      <a href="?tab=supervisor" class="px-4 py-2.5 rounded-xl bg-gold text-dark font-black shadow-glow">3. Supervisor SOP</a>

    <?php elseif ($isTeamLeadOnly): ?>
      <!-- Team Lead sees ONLY Team Lead SOP -->
      <a href="?tab=teamlead" class="px-4 py-2.5 rounded-xl bg-gold text-dark font-black shadow-glow">2. Team Lead SOP</a>

    <?php elseif ($isPhotoEditor): ?>
      <!-- Photo Editor sees ONLY Photo Editor SOP -->
      <a href="?tab=editor" class="px-4 py-2.5 rounded-xl bg-gold text-dark font-black shadow-glow">1. Photo Editor SOP</a>

    <?php elseif ($isHR): ?>
      <!-- HR sees ONLY HR Department SOP -->
      <a href="?tab=hr" class="px-4 py-2.5 rounded-xl bg-gold text-dark font-black shadow-glow">5. HR Department SOP</a>

    <?php elseif ($isSeoManager): ?>
      <!-- SEO Manager sees ONLY SEO SOP -->
      <a href="?tab=seo" class="px-4 py-2.5 rounded-xl bg-gold text-dark font-black shadow-glow">🌐 SEO &amp; Content Manager SOP</a>
    <?php endif; ?>
  </div>

  <!-- TAB CONTENT -->

  <?php if ($activeTab === 'overview'): ?>
  <!-- ══════════ OVERVIEW & HIERARCHY ══════════ -->
  <div class="space-y-8">
    
    <!-- Complete Company Hierarchy -->
    <div class="glass-card rounded-3xl p-8 border border-dark-border shadow-2xl space-y-6">
      <div class="flex items-center gap-3">
        <span class="text-2xl">🏛️</span>
        <div>
          <h2 class="text-xl font-bold text-white">Complete Company Hierarchy</h2>
          <p class="text-xs text-gray-400">Clear reporting structure from CEO down to Photo Editors, with independent HR support.</p>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-5 gap-4 text-center">
        <div class="p-5 rounded-2xl bg-[#161622] border-2 border-gold shadow-glow">
          <span class="text-xs text-gold font-bold uppercase tracking-wider block">Executive Level</span>
          <h3 class="text-lg font-black text-white mt-1">CEO / Director</h3>
          <p class="text-xs text-gray-400 mt-2">Executive Leadership &amp; Strategy</p>
        </div>
        <div class="p-5 rounded-2xl bg-[#161622] border border-blue-500/40">
          <span class="text-xs text-blue-400 font-bold uppercase tracking-wider block">Operations Head</span>
          <h3 class="text-lg font-black text-white mt-1">Production Manager</h3>
          <p class="text-xs text-gray-400 mt-2">Overall Operations &amp; Capacity</p>
        </div>
        <div class="p-5 rounded-2xl bg-[#161622] border border-purple-500/40">
          <span class="text-xs text-purple-400 font-bold uppercase tracking-wider block">Middle Management</span>
          <h3 class="text-lg font-black text-white mt-1">Supervisors</h3>
          <p class="text-xs text-gray-400 mt-2">Cross-Team QA &amp; Production Flow</p>
        </div>
        <div class="p-5 rounded-2xl bg-[#161622] border border-emerald-500/40">
          <span class="text-xs text-emerald-400 font-bold uppercase tracking-wider block">Working Leadership</span>
          <h3 class="text-lg font-black text-white mt-1">Team Leads</h3>
          <p class="text-xs text-gray-400 mt-2">Daily Assignment &amp; Technical QC</p>
        </div>
        <div class="p-5 rounded-2xl bg-[#161622] border border-gray-600">
          <span class="text-xs text-gray-400 font-bold uppercase tracking-wider block">Core Production</span>
          <h3 class="text-lg font-black text-white mt-1">Photo Editors</h3>
          <p class="text-xs text-gray-400 mt-2">Professional Execution &amp; Self-QC</p>
        </div>
      </div>

      <div class="p-4 rounded-2xl bg-purple-950/30 border border-purple-500/30 flex items-center justify-between gap-4">
        <div class="flex items-center gap-3">
          <span class="text-2xl">👥</span>
          <div>
            <h4 class="text-sm font-bold text-white">HR Department (Independent Support Entity)</h4>
            <p class="text-xs text-gray-300">HR production hierarchy ka direct part nahi hota. HR independently employees, hiring, attendance, policies aur employee relations handle karta hai.</p>
          </div>
        </div>
        <span class="badge bg-purple-500/20 text-purple-300 border border-purple-500/40 text-xs px-3 py-1 font-bold">HR Support</span>
      </div>
    </div>

    <!-- 9-Step Production Workflow Diagram -->
    <div class="glass-card rounded-3xl p-8 border border-dark-border shadow-2xl space-y-6">
      <div class="flex items-center gap-3">
        <span class="text-2xl">🔄</span>
        <div>
          <h2 class="text-xl font-bold text-white">9-Step Official Production Workflow</h2>
          <p class="text-xs text-gray-400">Step-by-step order processing from initial intake to client delivery and revision handling.</p>
        </div>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-9 gap-2 text-center text-xs">
        <div class="p-3 rounded-xl bg-dark/80 border border-dark-border">
          <span class="text-gold font-bold block mb-1">Step 1</span>
          <strong class="text-white block">Job Received</strong>
        </div>
        <div class="p-3 rounded-xl bg-dark/80 border border-dark-border">
          <span class="text-gold font-bold block mb-1">Step 2</span>
          <strong class="text-white block">Job Verification</strong>
        </div>
        <div class="p-3 rounded-xl bg-dark/80 border border-dark-border">
          <span class="text-gold font-bold block mb-1">Step 3</span>
          <strong class="text-white block">Job Assignment</strong>
        </div>
        <div class="p-3 rounded-xl bg-dark/80 border border-dark-border">
          <span class="text-gold font-bold block mb-1">Step 4</span>
          <strong class="text-white block">Editing</strong>
        </div>
        <div class="p-3 rounded-xl bg-dark/80 border border-dark-border">
          <span class="text-gold font-bold block mb-1">Step 5</span>
          <strong class="text-white block">Team Lead QC</strong>
        </div>
        <div class="p-3 rounded-xl bg-dark/80 border border-dark-border">
          <span class="text-gold font-bold block mb-1">Step 6</span>
          <strong class="text-white block">Supervisor QC</strong>
        </div>
        <div class="p-3 rounded-xl bg-dark/80 border border-dark-border">
          <span class="text-gold font-bold block mb-1">Step 7</span>
          <strong class="text-white block">Final QA</strong>
        </div>
        <div class="p-3 rounded-xl bg-dark/80 border border-dark-border">
          <span class="text-gold font-bold block mb-1">Step 8</span>
          <strong class="text-white block">Delivery</strong>
        </div>
        <div class="p-3 rounded-xl bg-dark/80 border border-dark-border">
          <span class="text-gold font-bold block mb-1">Step 9</span>
          <strong class="text-white block">Revision Handling</strong>
        </div>
      </div>
    </div>

    <!-- Golden Rules of Roles -->
    <div class="glass-card rounded-3xl p-8 border border-dark-border shadow-2xl space-y-4 bg-gradient-to-r from-[#111118] to-[#161622]">
      <h3 class="text-lg font-bold text-white flex items-center gap-2"><span>⭐</span> Simple Golden Rules of Each Role</h3>
      <div class="grid grid-cols-1 sm:grid-cols-5 gap-4 text-xs font-mono">
        <div class="p-4 rounded-xl bg-dark/80 border border-dark-border">
          <strong class="text-gold block mb-1">Editor:</strong>
          <span>"Do the Work" — Assigned photos accurately edit karna.</span>
        </div>
        <div class="p-4 rounded-xl bg-dark/80 border border-dark-border">
          <strong class="text-emerald-400 block mb-1">Team Lead:</strong>
          <span>"Lead the Team" — Team ko accurately &amp; efficiently chalana.</span>
        </div>
        <div class="p-4 rounded-xl bg-dark/80 border border-dark-border">
          <strong class="text-purple-400 block mb-1">Supervisor:</strong>
          <span>"Control the Teams" — Multiple teams ki production &amp; QA control karna.</span>
        </div>
        <div class="p-4 rounded-xl bg-dark/80 border border-dark-border">
          <strong class="text-blue-400 block mb-1">Manager:</strong>
          <span>"Manage Production" — Poori production operation ko efficiently run karna.</span>
        </div>
        <div class="p-4 rounded-xl bg-dark/80 border border-dark-border">
          <strong class="text-pink-400 block mb-1">HR:</strong>
          <span>"Manage People" — Employees aur HR system ko professionally manage karna.</span>
        </div>
      </div>
    </div>

  </div>
  <?php endif; ?>

  <?php if ($activeTab === 'editor'): ?>
  <!-- ══════════ 1. PHOTO EDITOR ══════════ -->
  <div class="glass-card rounded-3xl p-8 sm:p-10 border border-dark-border shadow-2xl space-y-8">
    <div class="flex items-center justify-between border-b border-dark-border pb-6">
      <div class="flex items-center gap-4">
        <div class="w-12 h-12 rounded-2xl bg-gold/10 text-gold font-black flex items-center justify-center text-xl border border-gold/30">1</div>
        <div>
          <h2 class="text-2xl font-black text-white">PHOTO EDITOR</h2>
          <p class="text-xs text-gray-400">Reports To: <strong class="text-gold">Team Lead</strong> | Core Technical Execution</p>
        </div>
      </div>
      <span class="badge badge-delivered text-xs">Production Department</span>
    </div>

    <div class="space-y-4">
      <h3 class="text-base font-bold text-gold uppercase tracking-wider">Main Purpose</h3>
      <p class="text-gray-300 text-sm leading-relaxed">
        Photo Editor ka primary responsibility client/photographer ki provided images ko company ke required editing standards aur client-specific requirements ke according professionally edit karna hai.
      </p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
      <div class="p-6 rounded-2xl bg-dark/80 border border-dark-border space-y-3">
        <h4 class="text-sm font-bold text-white flex items-center gap-2"><span>🎨</span> Technical Photo Editing Core Scope</h4>
        <ul class="text-xs text-gray-300 space-y-2 list-disc pl-4">
          <li>HDR photo editing &amp; Flambient editing</li>
          <li>Single exposure enhancement &amp; Brightness correction</li>
          <li>White balance correction &amp; Color tone adjustments</li>
          <li>Window pull / window masking &amp; Sky replacement</li>
          <li>Lawn/grass enhancement &amp; Twilight enhancement</li>
          <li>Object removal, Dust/spot removal, Reflection removal</li>
          <li>Perspective correction &amp; Vertical/Horizontal straightening</li>
          <li>TV screen replacement &amp; Fireplace replacement</li>
          <li>Final resizing &amp; exporting according to client specifications</li>
        </ul>
      </div>

      <div class="p-6 rounded-2xl bg-dark/80 border border-dark-border space-y-4">
        <div>
          <h4 class="text-sm font-bold text-white flex items-center gap-2"><span>🎯</span> Client-Specific Style Compliance</h4>
          <p class="text-xs text-gray-400 mt-1">Har client ki Style, Brightness, Color preference, Sky preference, Window-pull style, Sharpening level, aur File naming convention follow karna lazmi hai.</p>
        </div>

        <div class="pt-2">
          <h4 class="text-sm font-bold text-white flex items-center gap-2"><span>🔍</span> Editor Mandatory Self-QC Checklist</h4>
          <p class="text-xs text-gray-400 mt-1">Images submit karne se pehle Dimensions, Orientation, Straight lines, Masking edges, File sequence, aur Export resolution 100% check karein.</p>
        </div>

        <div class="pt-2">
          <h4 class="text-sm font-bold text-gold flex items-center gap-2"><span>📊</span> Editor KPIs</h4>
          <p class="text-xs text-gray-300">Images/Day, Turnaround Time (TAT), Revision %, Error Rate %, Quality Score, Attendance/Punctuality.</p>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <?php if ($activeTab === 'teamlead'): ?>
  <!-- ══════════ 2. TEAM LEAD ══════════ -->
  <div class="glass-card rounded-3xl p-8 sm:p-10 border border-dark-border shadow-2xl space-y-8">
    <div class="flex items-center justify-between border-b border-dark-border pb-6">
      <div class="flex items-center gap-4">
        <div class="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 font-black flex items-center justify-center text-xl border border-emerald-500/30">2</div>
        <div>
          <h2 class="text-2xl font-black text-white">TEAM LEAD</h2>
          <p class="text-xs text-gray-400">Reports To: <strong class="text-gold">Supervisor</strong> | Manages: <strong class="text-white">Photo Editors</strong></p>
        </div>
      </div>
      <span class="badge badge-in-progress text-xs">Working Leader</span>
    </div>

    <div class="space-y-4">
      <h3 class="text-base font-bold text-emerald-400 uppercase tracking-wider">Main Purpose</h3>
      <p class="text-gray-300 text-sm leading-relaxed">
        Team Lead editors ki daily production ko manage karta hai aur ensure karta hai ke team quality aur deadline dono maintain kare. Team Lead ek <strong>working leader</strong> hota hai — yani zarurat par khud bhi editing karta hai aur team ko bhi lead karta hai.
      </p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
      <div class="p-6 rounded-2xl bg-dark/80 border border-dark-border space-y-3">
        <h4 class="text-sm font-bold text-white flex items-center gap-2"><span>📋</span> Daily Production Management</h4>
        <ul class="text-xs text-gray-300 space-y-2 list-disc pl-4">
          <li>Team ko daily jobs assign karna aur workload distribute karna</li>
          <li>Priority &amp; Urgent rush jobs identify aur assign karna</li>
          <li>Deadlines monitor karna aur pending work track karna</li>
          <li>Completed work verify karna aur random sample QC karna</li>
          <li>New editors ko onboarding aur workflow training dena</li>
        </ul>
      </div>

      <div class="p-6 rounded-2xl bg-dark/80 border border-dark-border space-y-4">
        <div>
          <h4 class="text-sm font-bold text-white flex items-center gap-2"><span>🛡️</span> Technical Support &amp; Escalation</h4>
          <p class="text-xs text-gray-400 mt-1">Difficult photos par guidance dena. Agar editor issue solve na kar sake: <strong>Editor → Team Lead → Supervisor</strong>. Pehle khud solve karne ki koshish karna.</p>
        </div>

        <div class="pt-2">
          <h4 class="text-sm font-bold text-emerald-400 flex items-center gap-2"><span>📊</span> Team Lead KPIs</h4>
          <p class="text-xs text-gray-300">Team Productivity, Team Quality Score, Revision %, On-Time Delivery %, Team Error Rate, Training Effectiveness.</p>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <?php if ($activeTab === 'supervisor'): ?>
  <!-- ══════════ 3. SUPERVISOR ══════════ -->
  <div class="glass-card rounded-3xl p-8 sm:p-10 border border-dark-border shadow-2xl space-y-8">
    <div class="flex items-center justify-between border-b border-dark-border pb-6">
      <div class="flex items-center gap-4">
        <div class="w-12 h-12 rounded-2xl bg-purple-500/10 text-purple-400 font-black flex items-center justify-center text-xl border border-purple-500/30">3</div>
        <div>
          <h2 class="text-2xl font-black text-white">SUPERVISOR</h2>
          <p class="text-xs text-gray-400">Reports To: <strong class="text-gold">Production Manager</strong> | Manages: <strong class="text-white">Team Leads</strong></p>
        </div>
      </div>
      <span class="badge bg-purple-500/20 text-purple-300 border border-purple-500/40 text-xs font-bold">Quality &amp; Operations Control</span>
    </div>

    <div class="space-y-4">
      <h3 class="text-base font-bold text-purple-400 uppercase tracking-wider">Main Purpose</h3>
      <p class="text-gray-300 text-sm leading-relaxed">
        Supervisor multiple teams/team leads ki production, quality aur daily operations ko monitor karta hai. Supervisor ka focus individual images se zyada <strong>overall production control, capacity balance, aur QA audits</strong> par hota hai.
      </p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
      <div class="p-6 rounded-2xl bg-dark/80 border border-dark-border space-y-3">
        <h4 class="text-sm font-bold text-white flex items-center gap-2"><span>🔍</span> Quality Assurance &amp; Audits</h4>
        <ul class="text-xs text-gray-300 space-y-2 list-disc pl-4">
          <li>Multiple teams ki random quality audits karna</li>
          <li>Client complaints aur revision trends analyze karna</li>
          <li>Repeated editing errors identify karke QA guidelines update karna</li>
          <li>Capacity Management: Aaj kitna workload hai aur kitni capacity available hai monitor karna</li>
          <li>Daily/weekly production and TAT compliance reporting generate karna</li>
        </ul>
      </div>

      <div class="p-6 rounded-2xl bg-dark/80 border border-dark-border space-y-4">
        <div>
          <h4 class="text-sm font-bold text-white flex items-center gap-2"><span>⚡</span> Escalation Handling</h4>
          <p class="text-xs text-gray-400 mt-1"><strong>Editor → Team Lead → Supervisor → Manager</strong>. Supervisor sirf problems forward nahi karega; operational solution provide karega.</p>
        </div>

        <div class="pt-2">
          <h4 class="text-sm font-bold text-purple-400 flex items-center gap-2"><span>📊</span> Supervisor KPIs</h4>
          <p class="text-xs text-gray-300">Overall Production Efficiency, TAT Compliance, Department Quality Score, Capacity Utilization %, Escalation Resolution Time.</p>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <?php if ($activeTab === 'manager'): ?>
  <!-- ══════════ 4. PRODUCTION MANAGER ══════════ -->
  <div class="glass-card rounded-3xl p-8 sm:p-10 border border-dark-border shadow-2xl space-y-8">
    <div class="flex items-center justify-between border-b border-dark-border pb-6">
      <div class="flex items-center gap-4">
        <div class="w-12 h-12 rounded-2xl bg-blue-500/10 text-blue-400 font-black flex items-center justify-center text-xl border border-blue-500/30">4</div>
        <div>
          <h2 class="text-2xl font-black text-white">PRODUCTION / OPERATIONS MANAGER</h2>
          <p class="text-xs text-gray-400">Reports To: <strong class="text-gold">CEO / Director</strong> | Manages: <strong class="text-white">Supervisors + Production Dept</strong></p>
        </div>
      </div>
      <span class="badge bg-blue-500/20 text-blue-300 border border-blue-500/40 text-xs font-bold">Operational Leadership</span>
    </div>

    <div class="space-y-4">
      <h3 class="text-base font-bold text-blue-400 uppercase tracking-wider">Main Purpose</h3>
      <p class="text-gray-300 text-sm leading-relaxed">
        Manager poori production operation ka responsible hota hai. Manager ka formula focus hota hai: <strong>People + Production + Quality + Delivery + Client Requirements + Cost + Efficiency</strong>.
      </p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
      <div class="p-6 rounded-2xl bg-dark/80 border border-dark-border space-y-3">
        <h4 class="text-sm font-bold text-white flex items-center gap-2"><span>📈</span> Production &amp; Capacity Planning</h4>
        <ul class="text-xs text-gray-300 space-y-2 list-disc pl-4">
          <li>Daily/weekly workload forecasting aur staff capacity planning</li>
          <li>Peak season workload management aur shift allocation</li>
          <li>End-to-end 9-stage workflow optimization (Zero bottlenecks)</li>
          <li>Client SOP creation, repeated feedback analysis &amp; updates</li>
          <li>Process Improvement: Automation, AI tools, cost reduction</li>
          <li>Hiring requests: HR ko exact manpower requirements submit karna</li>
        </ul>
      </div>

      <div class="p-6 rounded-2xl bg-dark/80 border border-dark-border space-y-4">
        <div>
          <h4 class="text-sm font-bold text-white flex items-center gap-2"><span>👔</span> Executive Reporting</h4>
          <p class="text-xs text-gray-400 mt-1">CEO ko daily/monthly comprehensive reporting: Total Jobs, Images, TAT, Quality %, Revision %, Client Satisfaction &amp; Profitability.</p>
        </div>

        <div class="pt-2">
          <h4 class="text-sm font-bold text-blue-400 flex items-center gap-2"><span>📊</span> Manager KPIs</h4>
          <p class="text-xs text-gray-300">Overall Production Efficiency, Client Satisfaction %, On-Time Delivery %, Employee Retention %, Cost Efficiency, Capacity Utilization %.</p>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>

  <?php if ($activeTab === 'hr'): ?>
  <!-- ══════════ 5. HR — HUMAN RESOURCES ══════════ -->
  <div class="glass-card rounded-3xl p-8 sm:p-10 border border-dark-border shadow-2xl space-y-8">
    <div class="flex items-center justify-between border-b border-dark-border pb-6">
      <div class="flex items-center gap-4">
        <div class="w-12 h-12 rounded-2xl bg-pink-500/10 text-pink-400 font-black flex items-center justify-center text-xl border border-pink-500/30">5</div>
        <div>
          <h2 class="text-2xl font-black text-white">HUMAN RESOURCES (HR)</h2>
          <p class="text-xs text-gray-400">Reports To: <strong class="text-gold">Director / CEO</strong> | Independent HR Administration</p>
        </div>
      </div>
      <span class="badge bg-pink-500/20 text-pink-300 border border-pink-500/40 text-xs font-bold">HR &amp; People Operations</span>
    </div>

    <div class="space-y-4">
      <h3 class="text-base font-bold text-pink-400 uppercase tracking-wider">Main Purpose</h3>
      <p class="text-gray-300 text-sm leading-relaxed">
        HR ka primary responsibility employees ko hire, manage, develop aur company policies ke according professionally administer karna hai. (HR production ka direct manager nahi hota).
      </p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
      <div class="p-6 rounded-2xl bg-dark/80 border border-dark-border space-y-3">
        <h4 class="text-sm font-bold text-white flex items-center gap-2"><span>👥</span> Core HR Responsibilities</h4>
        <ul class="text-xs text-gray-300 space-y-2 list-disc pl-4">
          <li><strong>Recruitment:</strong> Job ads, CV screening, initial interviews, onboarding</li>
          <li><strong>Employee Onboarding:</strong> Agreements, attendance setup, policies, payroll files</li>
          <li><strong>Attendance &amp; Leave:</strong> Records, late tracking, leave balance administration</li>
          <li><strong>Performance Management:</strong> Appraisals, disciplinary documentation</li>
          <li><strong>Employee Relations:</strong> Grievance handling, workplace conflicts, professional conduct</li>
          <li><strong>Payroll Coordination:</strong> Salary records, attendance deductions, overtime, bonuses</li>
        </ul>
      </div>

      <div class="p-6 rounded-2xl bg-dark/80 border border-dark-border space-y-4">
        <div>
          <h4 class="text-sm font-bold text-white flex items-center gap-2"><span>🔄</span> Technical Hiring Workflow</h4>
          <p class="text-xs text-gray-400 mt-1">Production Manager requirement dega (e.g. "Need 5 Real Estate Photo Editors"). HR candidates shortlist karega, jabke technical test <strong>Team Lead / Supervisor / Manager</strong> conduct karenge.</p>
        </div>

        <div class="pt-2">
          <h4 class="text-sm font-bold text-pink-400 flex items-center gap-2"><span>📊</span> HR KPIs</h4>
          <p class="text-xs text-gray-300">Employee Retention %, Hiring Time, Attendance %, Employee Satisfaction %, Recruitment Success %, Policy Compliance.</p>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>


  <?php if ($activeTab === 'seo'): ?>
  <!-- ══════════ SEO & CONTENT MANAGER SOP ══════════ -->
  <div class="space-y-8">
    <div class="glass-card rounded-3xl p-8 sm:p-10 border border-gold/40 shadow-2xl space-y-6">
      
      <!-- Role Badge & Purpose -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-dark-border pb-6">
        <div>
          <div class="flex items-center gap-3">
            <span class="w-10 h-10 rounded-2xl bg-gold/20 text-gold flex items-center justify-center font-black text-lg border border-gold/40">🌐</span>
            <div>
              <h2 class="text-2xl font-black text-white">SEO &amp; CONTENT MANAGER SOP</h2>
              <p class="text-xs text-gray-400 mt-0.5">Independent Growth &amp; Search Visibility Division</p>
            </div>
          </div>
        </div>
        <div class="flex items-center gap-2">
          <span class="px-3 py-1.5 rounded-xl bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-bold">Independent Specialist</span>
          <span class="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold">Direct CEO Reporting</span>
        </div>
      </div>

      <!-- Golden Rule Banner: Complete Independence from Production & HR -->
      <div class="p-6 rounded-2xl bg-blue-950/30 border border-blue-500/40 space-y-2">
        <h3 class="text-sm font-black text-blue-300 flex items-center gap-2">
          <span>🛡️</span> <span>Organizational Independence &amp; Boundary Protocol</span>
        </h3>
        <p class="text-xs text-gray-200 leading-relaxed">
          <strong>SEO Manager ka daily production team se koi talluq nahi hai:</strong> SEO Manager Photo Editors, Team Leads, Supervisors, ya HR ke routine order workflow aur administrative channels mein shamil nahi hota. SEO Manager ek dedicated digital marketing &amp; search authority role hai jo direct website visibility, organic lead acquisition, aur search engine dominance par kaam karta hai.
        </p>
      </div>

      <!-- Purpose & Core Matrix Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
        
        <!-- Main Purpose -->
        <div class="p-6 rounded-2xl bg-dark/80 border border-dark-border space-y-3">
          <h4 class="text-sm font-bold text-gold flex items-center gap-2"><span>🎯</span> Main Purpose</h4>
          <p class="text-xs text-gray-300 leading-relaxed">
            Estate HDR website ko Google, Bing, aur AI search engines (ChatGPT Search, Perplexity, Gemini) ke top search results par rank karwana. High-intent real estate photographers, agencies, aur media companies ko organic search ke zariye attract karna aur conversion-ready leads generate karna.
          </p>
        </div>

        <!-- Reporting & Scope -->
        <div class="p-6 rounded-2xl bg-dark/80 border border-dark-border space-y-3">
          <h4 class="text-sm font-bold text-emerald-400 flex items-center gap-2"><span>📊</span> Scope of Authority</h4>
          <ul class="text-xs text-gray-300 space-y-1.5 list-disc pl-4">
            <li>Static Pages (About, Services, Case Studies) Content &amp; Meta Tuning</li>
            <li>Blog Articles CMS (Keyword research, writing, publishing, drafting)</li>
            <li>Taxonomies &amp; Category Structuring (<code class="text-gold">noindex</code> protection for tags)</li>
            <li>XML Sitemap Maintenance &amp; Google / Bing Ping Dispatching</li>
          </ul>
        </div>
      </div>

      <!-- Detailed SOP Breakdown -->
      <div class="space-y-6 pt-4">
        <h3 class="text-lg font-black text-white flex items-center gap-2"><span>📋</span> Official Daily &amp; Weekly SEO Procedures</h3>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <!-- 1. On-Page SEO -->
          <div class="p-5 rounded-2xl bg-[#111118] border border-dark-border space-y-2.5">
            <div class="font-bold text-gold flex items-center gap-1.5">
              <span>1️⃣</span> <span>On-Page SEO Optimization</span>
            </div>
            <ul class="text-gray-300 space-y-1.5 list-disc pl-4">
              <li>Meta Titles strictly between <strong>30 to 60 characters</strong> with primary keyword in front.</li>
              <li>Meta Descriptions between <strong>70 to 160 characters</strong> with clear CTA.</li>
              <li>Heading structure: Exact 1 H1 per page, followed by logical H2 &rarr; H3 sequence.</li>
              <li>Every image must have descriptive <strong>ALT text</strong> containing real estate editing keywords.</li>
              <li>Internal links to service offerings with descriptive anchor text.</li>
            </ul>
          </div>

          <!-- 2. Content & Blog Strategy -->
          <div class="p-5 rounded-2xl bg-[#111118] border border-dark-border space-y-2.5">
            <div class="font-bold text-emerald-400 flex items-center gap-1.5">
              <span>2️⃣</span> <span>Content Creation &amp; Drafts</span>
            </div>
            <ul class="text-gray-300 space-y-1.5 list-disc pl-4">
              <li>Use <strong>Save as Draft</strong> for articles undergoing research or review.</li>
              <li>Publish comprehensive guides (e.g. <em>HDR vs Flambient</em>, <em>Virtual Staging ROI</em>, <em>Dusk Conversion Techniques</em>).</li>
              <li>Ensure high Flesch Reading Ease score with clear subheadings, bullet points, and comparison tables.</li>
              <li>Set Featured Image for rich Open Graph preview across WhatsApp &amp; Social Media.</li>
            </ul>
          </div>

          <!-- 3. Technical SEO & Schema -->
          <div class="p-5 rounded-2xl bg-[#111118] border border-dark-border space-y-2.5">
            <div class="font-bold text-purple-400 flex items-center gap-1.5">
              <span>3️⃣</span> <span>Technical SEO &amp; Schema</span>
            </div>
            <ul class="text-gray-300 space-y-1.5 list-disc pl-4">
              <li>Verify JSON-LD Structured Data Schema (<code class="text-gold">Organization</code>, <code class="text-gold">Article</code>, <code class="text-gold">LocalBusiness</code>).</li>
              <li>Ensure canonical URLs prevent duplicate URL indexing.</li>
              <li>Monitor dynamic <code class="text-gold">sitemap.xml</code> regularly to confirm all newly published pages are indexed.</li>
              <li>Dispatch manual ping submissions to Google &amp; Bing whenever major content hubs are published.</li>
            </ul>
          </div>
        </div>
      </div>

      <!-- Key Performance Indicators (KPIs) -->
      <div class="p-6 rounded-2xl bg-gradient-to-r from-gold/10 via-[#111118] to-dark border border-gold/30 space-y-4">
        <h4 class="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <span>🏆</span> <span>SEO Manager Key Performance Indicators (KPIs)</span>
        </h4>
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center font-mono">
          <div class="p-3 rounded-xl bg-dark/60 border border-dark-border">
            <div class="text-lg font-black text-gold">Top 3</div>
            <div class="text-[11px] text-gray-400 mt-0.5">Target Keyword Positions</div>
          </div>
          <div class="p-3 rounded-xl bg-dark/60 border border-dark-border">
            <div class="text-lg font-black text-emerald-400">+25% MoM</div>
            <div class="text-[11px] text-gray-400 mt-0.5">Organic Search Clicks</div>
          </div>
          <div class="p-3 rounded-xl bg-dark/60 border border-dark-border">
            <div class="text-lg font-black text-blue-400">100%</div>
            <div class="text-[11px] text-gray-400 mt-0.5">Valid XML Sitemap Index</div>
          </div>
          <div class="p-3 rounded-xl bg-dark/60 border border-dark-border">
            <div class="text-lg font-black text-purple-400">90%+</div>
            <div class="text-[11px] text-gray-400 mt-0.5">On-Page Health Score</div>
          </div>
        </div>
      </div>

    </div>
  </div>
  <?php endif; ?>

  <?php if ($activeTab === 'escalation'): ?>
  <!-- ══════════ ESCALATION & RULES ══════════ -->
  <div class="glass-card rounded-3xl p-8 sm:p-10 border border-dark-border shadow-2xl space-y-8">
    <div class="border-b border-dark-border pb-6">
      <h2 class="text-2xl font-black text-white flex items-center gap-2"><span>🚨</span> Complete Escalation Matrix &amp; Communication Protocols</h2>
      <p class="text-xs text-gray-400 mt-1">Structured chains of resolution to eliminate confusion and maintain operational stability.</p>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <!-- Technical / Work Escalation -->
      <div class="p-6 rounded-2xl bg-dark/80 border border-dark-border space-y-4">
        <h3 class="text-base font-bold text-gold flex items-center gap-2"><span>⚙️</span> Production / Technical Issue Chain</h3>
        
        <div class="space-y-3 text-xs font-mono">
          <div class="p-3 rounded-xl bg-[#111118] border border-dark-border flex items-center justify-between">
            <span class="text-white font-bold">1. Photo Editor</span>
            <span class="text-gray-400">Identifies difficult photo / missing file</span>
          </div>
          <div class="text-center text-gold font-bold">↓ (Technical Guidance)</div>
          <div class="p-3 rounded-xl bg-[#111118] border border-emerald-500/30 flex items-center justify-between">
            <span class="text-emerald-400 font-bold">2. Team Lead</span>
            <span class="text-gray-400">Solves technical mistake / reassigns</span>
          </div>
          <div class="text-center text-gold font-bold">↓ (Workload / Quality Balance)</div>
          <div class="p-3 rounded-xl bg-[#111118] border border-purple-500/30 flex items-center justify-between">
            <span class="text-purple-400 font-bold">3. Supervisor</span>
            <span class="text-gray-400">Reallocates cross-team capacity</span>
          </div>
          <div class="text-center text-gold font-bold">↓ (Major Client / Policy Decision)</div>
          <div class="p-3 rounded-xl bg-[#111118] border border-blue-500/30 flex items-center justify-between">
            <span class="text-blue-400 font-bold">4. Production Manager</span>
            <span class="text-gray-400">Client SOP update / Process change</span>
          </div>
          <div class="text-center text-gold font-bold">↓ (Executive Intervention)</div>
          <div class="p-3 rounded-xl bg-[#111118] border border-gold flex items-center justify-between shadow-glow">
            <span class="text-gold font-bold">5. CEO / Director</span>
            <span class="text-white">Final strategic decision</span>
          </div>
        </div>
      </div>

      <!-- Employee / HR Escalation -->
      <div class="p-6 rounded-2xl bg-dark/80 border border-dark-border space-y-4">
        <h3 class="text-base font-bold text-pink-400 flex items-center gap-2"><span>👥</span> Employee Grievance / Disciplinary Chain</h3>
        
        <div class="space-y-3 text-xs font-mono">
          <div class="p-3 rounded-xl bg-[#111118] border border-dark-border flex items-center justify-between">
            <span class="text-white font-bold">Employee</span>
            <span class="text-gray-400">Raises workplace concern / grievance</span>
          </div>
          <div class="text-center text-pink-400 font-bold">↓ (Initial Discussion)</div>
          <div class="p-3 rounded-xl bg-[#111118] border border-dark-border flex items-center justify-between">
            <span class="text-white font-bold">Team Lead / Supervisor</span>
            <span class="text-gray-400">Initial operational review</span>
          </div>
          <div class="text-center text-pink-400 font-bold">↓ (Operational Endorsement)</div>
          <div class="p-3 rounded-xl bg-[#111118] border border-blue-500/30 flex items-center justify-between">
            <span class="text-blue-400 font-bold">Production Manager</span>
            <span class="text-gray-400">Reviews impact &amp; forwards to HR</span>
          </div>
          <div class="text-center text-pink-400 font-bold">↓ (Formal Investigation &amp; Policy)</div>
          <div class="p-3 rounded-xl bg-[#111118] border border-pink-500/40 flex items-center justify-between shadow-glow">
            <span class="text-pink-400 font-bold">HR Department</span>
            <span class="text-pink-300">Official documentation &amp; resolution</span>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>

</main>

<footer class="border-t border-dark-border py-8 px-6 bg-dark no-print">
  <div class="max-w-[1850px] mx-auto flex justify-between items-center text-xs text-gray-400">
    <span>&copy; <?= date('Y') ?> Estate HDR Production Operations. Confidential Internal SOP.</span>
    <a href="<?= htmlspecialchars($backUrl) ?>" class="text-gold hover:underline"><?= htmlspecialchars($backLabel) ?> &rarr;</a>
  </div>
</footer>

</body>
</html>
