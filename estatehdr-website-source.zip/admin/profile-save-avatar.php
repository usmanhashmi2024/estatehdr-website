<?php
/**
 * Estate HDR — Admin Profile Save Avatar Endpoint
 * Bridges blueprint spec with avatar processing subsystem
 */
require_once __DIR__ . '/../api/upload-avatar.php';
