<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireAdmin();

// Handle Submit Amendment Resolution POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'resolve_amendment') {
    verifyCsrf();
    $orderId         = trim($_POST['order_id'] ?? '');
    $cloudLink       = trim($_POST['cloud_link'] ?? '');
    $resolutionNotes = trim($_POST['resolution_notes'] ?? '');
    $deliveredCount  = (int)($_POST['delivered_images_count'] ?? 0);
    $sendClientEmail = isset($_POST['send_client_email']);

    if (empty($orderId)) {
        setFlash('error', 'Invalid Order ID.');
    } elseif (empty($cloudLink)) {
        setFlash('error', 'Please provide the high-res delivered files / cloud link.');
    } else {
        $resolved = deliverAmendmentResolution($orderId, $cloudLink, $resolutionNotes, $deliveredCount, $sendClientEmail);
        if ($resolved) {
            $emailNotice = $sendClientEmail ? " and official 'Amendment Done' notification email was dispatched to the client" : "";
            setFlash('success', "🎉 Amendment for Job #" . strtoupper($orderId) . " successfully completed{$emailNotice}!");
        } else {
            setFlash('error', "Could not resolve amendment for Job #" . strtoupper($orderId) . ". Please check order record.");
        }
    }
    header('Location: /admin/amendments.php');
    exit;
}

$amendments = getAllAmendmentOrders();
$users = getUsers();
$userMap = [];
foreach ($users as $u) { $userMap[$u['id']] = $u; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Amendment Requests Queue — Estate HDR Admin</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8">
  <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
    <div>
      <div class="section-tag mb-1 text-gold font-bold uppercase tracking-wider text-xs">Priority QA &amp; Revisions</div>
      <h1 class="text-2xl sm:text-3xl font-black text-white flex items-center gap-3">
        <span>AMENDMENT REQUESTS QUEUE</span>
        <span class="text-xs px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/40 font-mono font-bold">
          <?= count($amendments) ?> Active
        </span>
      </h1>
      <p class="text-gray-400 text-xs mt-1">Every revision requested by clients with explicit Job ID tracking, real-time Discord notifications, and 1-click "View &amp; Submit" client email notifications.</p>
    </div>

    <div class="flex items-center gap-3">
      <a href="/admin/orders.php" class="px-4 py-2 rounded-xl bg-dark-card border border-dark-border text-xs text-gray-300 hover:text-white hover:border-gold/40 transition-all font-bold">
        &larr; All Orders
      </a>
      <a href="/admin/order-new.php" class="btn-gold py-2 px-4 text-xs font-bold shadow-glow">
        + New Order
      </a>
    </div>
  </div>

  <?php if (empty($amendments)): ?>
  <div class="glass-card rounded-2xl p-16 text-center text-gray-500 text-sm border border-emerald-500/30 bg-emerald-950/10 shadow-2xl">
    <div class="text-5xl mb-3">🎉</div>
    <h3 class="text-white font-black text-lg mb-1">All Amendments Cleared!</h3>
    <p class="text-xs text-gray-400 max-w-md mx-auto">There are currently zero pending revisions requested by any client. When a client requests an amendment, it will immediately alert Discord and populate here.</p>
  </div>
  <?php else: ?>
  <div class="space-y-5">
    <?php foreach ($amendments as $order): 
      $client = $userMap[$order['user_id']] ?? null;
      $lastAmendment = null;
      if (!empty($order['messages']) && is_array($order['messages'])) {
          foreach (array_reverse($order['messages']) as $m) {
              if ($m['type'] === 'amendment') {
                  $lastAmendment = $m;
                  break;
              }
          }
      }
      $orderIdUpper = strtoupper($order['id']);
      $clientName = $order['client_name'] ?? ($client['name'] ?? 'Client');
      $clientEmail = $order['client_email'] ?? ($client['email'] ?? '');
      $currentDeliveryLink = $order['final_cloud_link'] ?? ($order['delivery_url'] ?? ($order['cloud_link'] ?? ''));
      $delImagesCount = (int)($order['delivered_images_count'] ?? ($order['final_image_count'] ?? ($order['raw_images_count'] ?? 1)));
      $amendmentText = $lastAmendment['content'] ?? ($order['amendment_notes'] ?? 'Visual revisions requested.');
    ?>
    <div class="glass-card rounded-2xl p-6 border-2 border-amber-500/40 shadow-2xl bg-gradient-to-r from-amber-950/20 via-dark-card to-dark transition-all hover:border-amber-500/70">
      <div class="flex flex-col lg:flex-row lg:items-start justify-between gap-6">
        
        <!-- Left: Order & Amendment Details -->
        <div class="space-y-3 flex-1 min-w-0">
          <div class="flex items-center gap-2.5 flex-wrap text-xs">
            <span class="font-mono font-black px-3 py-1 rounded-lg bg-gold text-dark shadow-sm">
              JOB ID: #<?= $orderIdUpper ?>
            </span>
            <span class="font-mono text-gray-300 bg-dark px-2.5 py-1 rounded-lg border border-dark-border">
              CLIENT ID: <?= strtoupper($client['id'] ?? ($order['user_id'] ?? 'CL-1001')) ?>
            </span>
            <span class="text-white font-bold flex items-center gap-1.5">
              <span>👤</span> <span><?= htmlspecialchars($clientName) ?></span>
              <?php if (!empty($clientEmail)): ?>
                <span class="text-gray-400 font-mono text-[11px]">(<?= htmlspecialchars($clientEmail) ?>)</span>
              <?php endif; ?>
            </span>
            <span class="px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/30 text-[10px] font-bold uppercase">
              <?= htmlspecialchars($order['service_type'] ?? 'HDR Photo Editing') ?>
            </span>
            <span class="text-amber-400/90 text-[11px] font-mono ml-auto">
              🕒 <?= date('M j, Y g:i A', strtotime($lastAmendment['timestamp'] ?? $order['updated_at'])) ?>
            </span>
          </div>

          <h3 class="text-xl font-black text-white leading-snug">
            <?= htmlspecialchars($order['property_name'] ?? 'Real Estate Property') ?>
          </h3>

          <!-- Amendment Notes Box -->
          <div class="bg-[#0B0B14] rounded-xl p-4 border border-amber-500/30 space-y-2">
            <div class="flex items-center justify-between text-xs font-bold text-amber-400">
              <span class="flex items-center gap-1.5">
                <i class="fas fa-pencil-alt text-xs"></i>
                <span>Client Revision Request:</span>
              </span>
              <span class="text-[10px] text-gray-400 font-mono uppercase">Ticket Note</span>
            </div>
            <div class="text-xs text-gray-200 font-sans leading-relaxed whitespace-pre-wrap">
              <?= htmlspecialchars($amendmentText) ?>
            </div>
          </div>

          <?php if (!empty($order['annotations'])): ?>
          <div class="flex items-center gap-2 text-xs text-amber-300 bg-amber-500/10 border border-amber-500/20 px-3 py-1.5 rounded-lg w-fit">
            <span>📍</span>
            <span><strong><?= count($order['annotations']) ?> Pinpoint Visual Annotation(s)</strong> attached to images</span>
          </div>
          <?php endif; ?>
        </div>

        <!-- Right: Actions (View & Submit Resolution) -->
        <div class="flex flex-col sm:flex-row lg:flex-col items-stretch lg:items-end gap-2.5 flex-shrink-0 w-full lg:w-64 pt-2 lg:pt-0 border-t lg:border-t-0 border-white/5">
          <!-- Direct View & Submit Button -->
          <button 
            type="button"
            onclick="openSubmitAmendmentModal(<?= htmlspecialchars(json_encode([
              'order_id' => $order['id'],
              'property_name' => $order['property_name'] ?? '',
              'client_name' => $clientName,
              'client_email' => $clientEmail,
              'cloud_link' => $currentDeliveryLink,
              'delivered_count' => $delImagesCount,
              'amendment_notes' => $amendmentText
            ])) ?>)"
            class="btn-gold py-3 px-5 text-xs font-black shadow-glow text-center flex items-center justify-center gap-2 rounded-xl"
            title="Open Resolution form and dispatch client notification email"
          >
            <span>✅</span>
            <span>View &amp; Submit Amend</span>
          </button>

          <!-- Open Job in Admin View -->
          <a 
            href="/admin/order-view.php?id=<?= urlencode($order['id']) ?>" 
            class="px-4 py-2.5 rounded-xl bg-dark/80 hover:bg-white/10 text-gray-300 hover:text-white border border-dark-border hover:border-gold/40 text-xs font-bold transition-all text-center flex items-center justify-center gap-1.5"
          >
            <span>👁️</span>
            <span>Inspect Job &amp; Files &rarr;</span>
          </a>

          <?php if (!empty($currentDeliveryLink)): ?>
          <a 
            href="<?= htmlspecialchars($currentDeliveryLink) ?>" 
            target="_blank" 
            rel="noopener noreferrer"
            class="text-[11px] text-gold hover:underline font-mono text-center flex items-center justify-center gap-1 mt-1"
          >
            <span>☁️ Previous Delivery Link ↗</span>
          </a>
          <?php endif; ?>
        </div>

      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</main>

<!-- ── RESOLUTION & CLIENT NOTIFICATION MODAL ─────────────────────── -->
<div id="amendmentSubmitModal" class="fixed inset-0 z-50 bg-black/80 backdrop-blur-md hidden flex items-center justify-center p-4">
  <div class="glass-card rounded-3xl border border-gold/40 bg-[#0E0E18] w-full max-w-2xl overflow-hidden shadow-2xl animate-fade-in flex flex-col max-h-[92vh]">
    
    <!-- Modal Header -->
    <div class="p-5 sm:p-6 bg-gradient-to-r from-amber-950/40 via-dark-card to-dark border-b border-gold/20 flex items-center justify-between">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-2xl bg-gold/20 text-gold border border-gold/30 flex items-center justify-center text-lg font-black">
          ✅
        </div>
        <div>
          <h2 class="text-base sm:text-lg font-black text-white flex items-center gap-2">
            <span>Submit Amendment Resolution</span>
          </h2>
          <p class="text-xs text-gray-400 font-mono" id="modalOrderRef">Job #ORD-0000</p>
        </div>
      </div>
      <button type="button" onclick="closeSubmitAmendmentModal()" class="w-8 h-8 rounded-full bg-white/5 hover:bg-white/15 text-gray-400 hover:text-white flex items-center justify-center transition-all font-bold">
        ✕
      </button>
    </div>

    <!-- Modal Form Body -->
    <form method="POST" action="/admin/amendments.php" class="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="resolve_amendment">
      <input type="hidden" name="order_id" id="modalOrderId" value="">

      <!-- Client Request Summary Box -->
      <div class="bg-[#12121E] rounded-xl p-3.5 border border-amber-500/30 text-xs">
        <div class="text-[11px] font-bold text-amber-400 uppercase tracking-wider mb-1 flex items-center gap-1.5">
          <span>📝 Client's Original Amendment Request:</span>
        </div>
        <p class="text-gray-300 leading-relaxed font-sans italic" id="modalAmendmentNotes">
          Loading client notes...
        </p>
      </div>

      <!-- Revised Delivery Link (Dropbox / Drive / WeTransfer) -->
      <div>
        <label class="block text-xs font-bold text-gold uppercase tracking-wider mb-1.5">
          ☁️ Revised High-Res Files Link <span class="text-red-400">*</span>
        </label>
        <input 
          type="url" 
          name="cloud_link" 
          id="modalCloudLink" 
          required 
          placeholder="https://www.dropbox.com/scl/fo/... or Google Drive link"
          class="w-full bg-[#141422] border border-[#2D2D44] focus:border-gold rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-500 outline-none transition-all"
        >
        <p class="text-[11px] text-gray-400 mt-1">This link will be sent directly to the client in the "Amendment Done" email for 1-click download.</p>
      </div>

      <!-- Delivered Count & Property Info -->
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="block text-xs font-bold text-gray-300 uppercase tracking-wider mb-1.5">
            📸 Delivered Images Count
          </label>
          <input 
            type="number" 
            name="delivered_images_count" 
            id="modalDeliveredCount" 
            min="1" 
            value="1" 
            class="w-full bg-[#141422] border border-[#2D2D44] focus:border-gold rounded-xl px-4 py-2 text-xs text-white outline-none"
          >
        </div>
        <div>
          <label class="block text-xs font-bold text-gray-300 uppercase tracking-wider mb-1.5">
            👤 Client Recipient
          </label>
          <input 
            type="text" 
            id="modalClientDisplay" 
            readonly 
            class="w-full bg-[#0A0A10] border border-[#1E1E2E] rounded-xl px-4 py-2 text-xs text-gray-400 font-mono outline-none"
          >
        </div>
      </div>

      <!-- Resolution Notes to Client -->
      <div>
        <label class="block text-xs font-bold text-white uppercase tracking-wider mb-1.5">
          ✍️ Resolution Notes for Client <span class="text-gray-400 font-normal lowercase">(included in email &amp; ticket)</span>
        </label>
        <textarea 
          name="resolution_notes" 
          id="modalResolutionNotes" 
          rows="3" 
          required
          class="w-full bg-[#141422] border border-[#2D2D44] focus:border-gold rounded-xl p-3 text-xs text-white placeholder-gray-500 outline-none transition-all leading-relaxed"
          placeholder="Describe the adjustments completed (e.g. Window pull exposures revised, vertical perspective straightened, sky replacement adjusted)..."
        ></textarea>
      </div>

      <!-- Client Email Notification Option -->
      <div class="bg-emerald-950/20 border border-emerald-500/40 rounded-xl p-3.5 flex items-start gap-3">
        <input 
          type="checkbox" 
          name="send_client_email" 
          id="modalSendClientEmail" 
          value="1" 
          checked 
          class="w-4 h-4 rounded text-gold focus:ring-gold bg-[#141422] border-[#2D2D44] mt-0.5"
        >
        <label for="modalSendClientEmail" class="text-xs text-emerald-300 font-semibold cursor-pointer">
          <span class="font-bold text-white">Send "Amendment Completed" Email to Client</span>
          <span class="block text-[11px] text-emerald-400/80 font-normal mt-0.5">
            Dispatches our branded luxury email with a direct "Download Revised Photos" button, summary of revisions, and 100% free satisfaction guarantee.
          </span>
        </label>
      </div>

      <!-- Modal Footer -->
      <div class="pt-4 border-t border-white/5 flex items-center justify-end gap-3">
        <button 
          type="button" 
          onclick="closeSubmitAmendmentModal()" 
          class="px-5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-bold text-gray-300 transition-all"
        >
          Cancel
        </button>
        <button 
          type="submit" 
          class="btn-gold py-2.5 px-6 text-xs font-black shadow-glow flex items-center gap-2 rounded-xl"
        >
          <span>🚀</span>
          <span>Submit &amp; Notify Client</span>
        </button>
      </div>
    </form>
  </div>
</div>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
function openSubmitAmendmentModal(data) {
  document.getElementById('modalOrderId').value = data.order_id || '';
  document.getElementById('modalOrderRef').textContent = 'Job #' + (data.order_id || '').toUpperCase() + ' • ' + (data.property_name || 'Property');
  document.getElementById('modalAmendmentNotes').textContent = data.amendment_notes || 'Visual corrections requested.';
  document.getElementById('modalCloudLink').value = data.cloud_link || '';
  document.getElementById('modalDeliveredCount').value = data.delivered_count || 1;
  document.getElementById('modalClientDisplay').value = (data.client_name || 'Client') + ' <' + (data.client_email || 'client@email.com') + '>';
  
  // Set default polite, professional resolution notes
  document.getElementById('modalResolutionNotes').value = "We have completed your requested amendments and revised the images according to your notes. All window pulls, lighting balances, and color adjustments have been verified to our luxury architectural standard. Your high-resolution files are ready for download.";

  const modal = document.getElementById('amendmentSubmitModal');
  modal.classList.remove('hidden');
}

function closeSubmitAmendmentModal() {
  const modal = document.getElementById('amendmentSubmitModal');
  modal.classList.add('hidden');
}

// Close on backdrop click
document.getElementById('amendmentSubmitModal').addEventListener('click', function(e) {
  if (e.target === this) closeSubmitAmendmentModal();
});
</script>
</body>
</html>
