<?php
@ini_set('display_errors', '1');
error_reporting(E_ALL & ~E_NOTICE);
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/saas-db.php';
require_once __DIR__ . '/../includes/services/TurnaroundService.php';
requireAdmin();

// ── Handle God-Mode Delete Order (Owner / Super Admin) ────────────────────────
if (isset($_GET['delete_order_id'])) {
    if (!isOwner()) {
        setFlash('error', 'Only Owner/CEO has permission to delete production orders.');
        header("Location: /admin/supervisor-dashboard.php");
        exit;
    }
    $delOid  = trim($_GET['delete_order_id']);
    $rawOid  = preg_replace('/^TRIAL-/i', '', $delOid);
    $trialOid = 'TRIAL-' . strtoupper($rawOid);

    // 1) Remove from SaaS pipeline (saas_orders.json)
    $saasFile = DATA_PATH . 'saas_orders.json';
    if (file_exists($saasFile)) {
        $saasOrders = json_decode(file_get_contents($saasFile), true) ?: [];
        $saasOrders = array_values(array_filter($saasOrders, function($o) use ($delOid, $rawOid, $trialOid) {
            $oid = $o['id'] ?? '';
            if (strcasecmp($oid, $delOid) === 0) return false;
            if (strcasecmp($oid, $rawOid) === 0) return false;
            if (strcasecmp($oid, $trialOid) === 0) return false;
            return true;
        }));
        file_put_contents($saasFile, json_encode($saasOrders, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
    }

    // 2) Remove from leads.json
    $leadsFile = defined('LEADS_FILE') ? LEADS_FILE : (rtrim(DATA_PATH, '/') . '/leads.json');
    if (file_exists($leadsFile)) {
        $leads = json_decode(file_get_contents($leadsFile), true) ?: [];
        $leads = array_values(array_filter($leads, function($l) use ($delOid, $rawOid, $trialOid) {
            $lid = $l['id'] ?? '';
            if (strcasecmp($lid, $delOid) === 0) return false;
            if (strcasecmp($lid, $rawOid) === 0) return false;
            if (strcasecmp($lid, $trialOid) === 0) return false;
            if (strcasecmp('TRIAL-' . $lid, $trialOid) === 0) return false;
            return true;
        }));
        file_put_contents($leadsFile, json_encode($leads, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
    }

    // 3) Remove from main client orders storage
    deleteOrder($delOid);

    setFlash('success', "Order #{$delOid} permanently removed from all queues.");
    header("Location: /admin/supervisor-dashboard.php");
    exit;
}


// Handle Bulk Clear All SaaS Pipeline Orders
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['bulk_clear_saas_pipeline'])) {
    verifyCsrf();
    if (!isOwner()) {
        setFlash('error', 'Access Denied: Only the CEO/Owner can bulk-clear the pipeline.');
        header('Location: /admin/supervisor-dashboard.php');
        exit;
    }
    $saasOrdersFile = DATA_PATH . 'saas_orders.json';
    if (file_exists($saasOrdersFile)) {
        file_put_contents($saasOrdersFile, json_encode([], JSON_PRETTY_PRINT), LOCK_EX);
    }
    setFlash('success', 'Production pipeline cleared! All SaaS orders removed from the queue.');
    header('Location: /admin/supervisor-dashboard.php');
    exit;
}

$currentAdmin = currentAdminUser();
$adminRoles   = getAdminRoles();

$allEmployees = (array)(getSaaSEmployees() ?: []);
$teamLeads    = array_values(array_filter($allEmployees, fn($e) => is_array($e) && (($e['role'] ?? '') === 'Team Lead')));
$editors      = array_values(array_filter($allEmployees, fn($e) => is_array($e) && (($e['role'] ?? '') === 'Photo Editor')));

// ── 1. POST: Assign Team Lead to Order ──────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_team_lead'])) {
    verifyCsrf();
    $orderId = trim($_POST['order_id'] ?? '');
    $tlId    = trim($_POST['tl_id'] ?? '');
    
    $tlName = 'Production Team Lead';
    foreach ($teamLeads as $tl) {
        if ($tl['user_id'] === $tlId || $tl['id'] === $tlId) {
            $tlName = $tl['name'];
            break;
        }
    }
    
    $orders = getSaaSOrders();
    foreach ($orders as &$o) {
        if ($o['id'] === $orderId) {
            $o['assigned_tl_id']   = $tlId;
            $o['assigned_tl_name'] = $tlName;
            $o['status']           = 'assigned_tl';
            $o['updated_at']       = date('c');
            saveSaaSOrders($orders);
            logSaaSEvent($currentAdmin['id'] ?? 'adm-3', "Supervisor assigned order to Team Lead: $tlName", $orderId, ['tl_id' => $tlId]);
            
            // Sync status to legacy client order
            $leg = getOrder($orderId);
            if ($leg) {
                $leg['status'] = 'in_progress';
                $leg['updated_at'] = date('c');
                saveOrder($leg);
            }
            break;
        }
    }
    setFlash('success', "Order #$orderId successfully assigned to Team Lead: $tlName!");
    header("Location: /admin/supervisor-dashboard.php");
    exit;
}

// ── 2. POST: Dispatch Delivery to Client (Watermarked vs Final Photos) ──────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dispatch_delivery'])) {
    verifyCsrf();
    $orderId      = trim($_POST['order_id'] ?? '');
    $dispatchType = trim($_POST['dispatch_type'] ?? 'final'); // 'watermark' or 'final'
    $watermarkUrl = trim($_POST['watermark_url'] ?? '');
    $deliveryUrl  = trim($_POST['delivery_url'] ?? '');
    $method       = trim($_POST['delivery_method'] ?? 'email');
    $customPrice  = (float)($_POST['price_amount'] ?? 0);

    $isWatermarkDispatch = ($dispatchType === 'watermark' || $dispatchType === 'watermarked');

    if ($isWatermarkDispatch && empty($watermarkUrl)) {
        setFlash('error', 'Please provide a valid Watermark Photos Link (Dropbox or Google Drive) before sending watermark proofs.');
        header("Location: /admin/supervisor-dashboard.php");
        exit;
    }

    if (!$isWatermarkDispatch && empty($deliveryUrl)) {
        setFlash('error', 'Please provide a valid Final Photos Link (Without Watermark) before sending final deliverables.');
        header("Location: /admin/supervisor-dashboard.php");
        exit;
    }

    $orders = getSaaSOrders();
    $targetOrder = null;
    $activeUrl = $isWatermarkDispatch ? $watermarkUrl : $deliveryUrl;

    foreach ($orders as &$o) {
        if ($o['id'] === $orderId) {
            if (!empty($watermarkUrl)) $o['watermark_url'] = $watermarkUrl;
            if (!empty($deliveryUrl))  $o['delivery_url']  = $deliveryUrl;
            
            if ($isWatermarkDispatch) {
                $o['status']          = 'watermarked_delivered';
                $o['watermarked_at']  = date('c');
                $o['watermark_sent']  = true;
            } else {
                $o['status']            = 'sent_client';
                $o['delivered_at']      = date('c');
                $o['final_delivered_at']= date('c');
            }
            $o['updated_at'] = date('c');
            if ($customPrice > 0) $o['price_amount'] = $customPrice;
            
            if (!isset($o['deliveries'])) $o['deliveries'] = [];
            $o['deliveries'][] = [
                'delivery_number' => count($o['deliveries']) + 1,
                'sent_by'         => $currentAdmin['name'] ?? 'Supervisor',
                'sent_at'         => date('c'),
                'type'            => $isWatermarkDispatch ? 'Watermarked Proofs' : 'Final Deliverables',
                'method'          => ucfirst($method),
                'recipient'       => $o['client_email'] ?? $o['client_phone'] ?? 'Client',
                'watermark_url'   => $watermarkUrl,
                'delivery_url'    => $deliveryUrl,
                'active_url'      => $activeUrl,
                'status'          => 'Sent'
            ];
            
            $targetOrder = $o;
            saveSaaSOrders($orders);
            logSaaSEvent($currentAdmin['id'] ?? 'adm-3', "Supervisor dispatched " . ($isWatermarkDispatch ? "Watermarked Proofs" : "Final Photos (No Watermark)") . " via " . ucfirst($method), $orderId, [
                'watermark_url' => $watermarkUrl,
                'delivery_url'  => $deliveryUrl,
                'dispatch_type' => $dispatchType
            ]);
            break;
        }
    }
    
    // Sync to legacy client order
    $leg = getOrder($orderId);
    $finalDeliveredCount = (int)($targetOrder['final_image_count'] ?? $targetOrder['photo_count'] ?? 10);
    if ($leg && $targetOrder) {
        if (!empty($watermarkUrl)) $leg['watermark_url'] = $watermarkUrl;
        if (!empty($deliveryUrl))  $leg['final_cloud_link'] = $deliveryUrl;
        
        if ($isWatermarkDispatch) {
            $leg['status'] = 'watermarked_delivered';
            $leg['messages'][] = [
                'id'         => generateId(),
                'sender'     => 'admin',
                'type'       => 'watermark_proof',
                'content'    => "Watermarked photo proofs are ready for review!\n\nWatermark Proofs Link: " . $watermarkUrl . "\n\nPlease review your photos. Upon payment verification, clean final photos (without watermark) will be unlocked and sent immediately.",
                'cloud_link' => $watermarkUrl,
                'timestamp'  => date('c'),
            ];
        } else {
            $leg['status']                 = 'delivered';
            $leg['delivered_images_count'] = $finalDeliveredCount;
            $leg['messages'][] = [
                'id'         => generateId(),
                'sender'     => 'admin',
                'type'       => 'delivery',
                'content'    => "Your final photos (without watermark) are delivered and ready for download!\n\nDownload Link: " . $deliveryUrl,
                'cloud_link' => $deliveryUrl,
                'timestamp'  => date('c'),
            ];
        }
        if ($customPrice > 0) $leg['billed_amount'] = $customPrice;
        $leg['updated_at'] = date('c');
        saveOrder($leg);
    }
    
    // Automatically log financial transaction to ledger and update client's account balance
    $isTrial = !empty($targetOrder['is_trial']) 
        || (($targetOrder['order_type'] ?? '') === 'free_trial') 
        || (!empty($leg['is_trial'])) 
        || (($leg['order_type'] ?? '') === 'free_trial') 
        || stripos($orderId, 'TRIAL-') === 0;

    if ($isTrial) {
        $customPrice = 0.0;
        $billedToLog = 0.0;
        if ($leg) {
            $leg['billed_amount'] = 0.0;
            $leg['is_trial']      = true;
            $leg['order_type']    = 'free_trial';
            saveOrder($leg);
        }
        syncOrderBillingToLedger($orderId, 0.0, $finalDeliveredCount, "Order #{$orderId} (Free Trial)");
    } else {
        $billedToLog = $customPrice > 0 ? $customPrice : (float)($targetOrder['price_amount'] ?? $leg['billed_amount'] ?? 0.0);
        if ($billedToLog > 0) {
            syncOrderBillingToLedger(
                $orderId, 
                $billedToLog, 
                $finalDeliveredCount, 
                "Order #{$orderId}: " . ($targetOrder['property_name'] ?? 'Property')
            );
        }
    }
    
    // If order was a Free Trial Lead, update data/leads.json too!
    if (!empty($targetOrder['lead_id']) || !empty($targetOrder['is_trial']) || $isTrial) {
        $leadId = $targetOrder['lead_id'] ?? str_replace('TRIAL-', '', $orderId);
        if (function_exists('updateLeadDelivery')) {
            updateLeadDelivery(strtolower($leadId), $activeUrl);
        }
    }

    // Dispatch Luxury Golden Invoice & Delivery Email to client with full multi-source fallback
    $deliveryClientEmail = trim($targetOrder['client_email'] ?? ($leg['client_email'] ?? ''));
    if (empty($deliveryClientEmail) && !empty($leg['user_id']) && function_exists('getUserById')) {
        $u = getUserById($leg['user_id']);
        if ($u && !empty($u['email'])) {
            $deliveryClientEmail = trim($u['email']);
        }
    }
    if (empty($deliveryClientEmail) && !empty($targetOrder['client_id']) && function_exists('getUserById')) {
        $u = getUserById($targetOrder['client_id']);
        if ($u && !empty($u['email'])) {
            $deliveryClientEmail = trim($u['email']);
        }
    }

    if ($targetOrder) {
        $targetOrder['client_email'] = $deliveryClientEmail;
        if (empty($targetOrder['client_name']) && !empty($leg['client_name'])) {
            $targetOrder['client_name'] = $leg['client_name'];
        }
    }

    $emailSent = false;
    if (!empty($deliveryClientEmail) && function_exists('sendOrderDeliveryInvoiceEmail')) {
        $emailSent = sendOrderDeliveryInvoiceEmail(
            $targetOrder ?: ($leg ?: ['id' => $orderId]), 
            $billedToLog, 
            $activeUrl, 
            $finalDeliveredCount, 
            $dispatchType
        );
    }

    if ($emailSent) {
        if ($isTrial) {
            setFlash('success', "Order #$orderId successfully delivered! Complimentary Free Trial notification ($0.00) sent to " . htmlspecialchars($deliveryClientEmail) . ".");
        } elseif ($isWatermarkDispatch) {
            setFlash('success', "Order #$orderId: Watermarked photo proofs successfully sent to " . htmlspecialchars($deliveryClientEmail) . "! Client notified to review proofs and complete PayPal payment (\$" . number_format($billedToLog, 2) . ") to unlock final clean files.");
        } else {
            setFlash('success', "Order #$orderId: Final clean photos (without watermark) successfully delivered to " . htmlspecialchars($deliveryClientEmail) . "!");
        }
    } else {
        if ($isWatermarkDispatch) {
            setFlash('success', "Order #$orderId marked with Watermarked Proofs! Proof link saved to client portal.");
        } else {
            setFlash('success', "Order #$orderId marked as Final Delivered! Clean download link saved to client portal.");
        }
    }
    
    header("Location: /admin/supervisor-dashboard.php");
    exit;
}

// ── 2B. POST: Mark Order as Paid (Immediate PayPal / Bank Clearance) ─────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_order_paid'])) {
    verifyCsrf();
    $orderId    = trim($_POST['order_id'] ?? '');
    $paidAmount = (float)($_POST['paid_amount'] ?? 0.0);
    if (!empty($orderId) && function_exists('markOrderPaid')) {
        markOrderPaid($orderId, $paidAmount > 0 ? $paidAmount : null, 'PayPal', 'Direct payment confirmed by Supervisor');
        logSaaSEvent($currentAdmin['id'] ?? 'adm-3', "Supervisor recorded Order #$orderId as PAID", $orderId, ['paid_amount' => $paidAmount]);
        setFlash('success', "Order #$orderId successfully marked as PAID! Financial ledger updated and Final Delivery is now unlocked.");
    }
    header("Location: /admin/supervisor-dashboard.php");
    exit;
}

// On-demand reconciliation of delivered orders with financial ledger
if (isset($_GET['reconcile']) && function_exists('reconcileAllOrdersLedger')) {
    $synced = reconcileAllOrdersLedger();
    setFlash('success', "Production pipeline reconciled with billing ledger ({$synced} order(s) updated).");
    header("Location: /admin/supervisor-dashboard.php");
    exit;
}

$allOrders = (array)(getSaaSOrders() ?: []);

// ── Metrics & Categorization ────────────────────────────────────────────────
$todayStr      = date('Y-m-d');
$newIntake     = array_values(array_filter($allOrders, fn($o) => (in_array($o['status'] ?? '', ['new', 'received', 'pending']) || empty($o['assigned_tl_id'])) && !in_array($o['status'] ?? '', ['completed','sent_client','delivered','approved','ready_delivery','watermarked_delivered'])));
$readyDelivery = array_values(array_filter($allOrders, fn($o) => in_array($o['status'] ?? '', ['approved', 'ready_delivery', 'watermarked_delivered'])));
$totalActive   = count(array_filter($allOrders, fn($o) => !in_array($o['status'] ?? '', ['completed','sent_client','delivered','cancelled'])));
$inRevision    = count(array_filter($allOrders, fn($o) => ($o['status'] ?? '') === 'revision_required'));
$deliveredAll  = count(array_filter($allOrders, fn($o) => in_array($o['status'] ?? '', ['completed','sent_client','delivered'])));

// Categorization Counts for Tabs
$categoryCounts = [
    'all'             => count($allOrders),
    'pending'         => 0,
    'in_production'   => 0,
    'ready_delivery'  => 0,
    'delivered'       => 0,
    'free_trial'      => 0,
    'live_order'      => 0,
    'cleared'         => 0,
    'due'             => 0,
];

$categorizedSupervisorOrders = [];
foreach ($allOrders as $o) {
    $st = strtolower($o['status'] ?? 'pending');
    $fin = function_exists('getOrderFinancialStatus') ? getOrderFinancialStatus($o) : [
        'is_trial' => false,
        'category_badge' => '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/40">⚡ LIVE ORDER</span>',
        'cleared' => false,
        'payment_status' => 'pending',
        'payment_badge' => '<span class="text-gray-400 font-mono">—</span>'
    ];

    if (in_array($st, ['new', 'received', 'pending']) || empty($o['assigned_tl_id'])) {
        $wfCat = 'pending';
    } elseif (in_array($st, ['approved', 'ready_delivery', 'watermarked_delivered'])) {
        $wfCat = 'ready_delivery';
    } elseif (in_array($st, ['sent_client', 'completed', 'delivered'])) {
        $wfCat = 'delivered';
    } else {
        $wfCat = 'in_production';
    }

    $isTrial = !empty($fin['is_trial']);
    $isCleared = !empty($fin['cleared']);
    $hasDue = (($fin['payment_status'] ?? '') === 'pending');

    $categoryCounts[$wfCat]++;
    if ($isTrial) {
        $categoryCounts['free_trial']++;
    } else {
        $categoryCounts['live_order']++;
    }

    if ($isCleared) {
        $categoryCounts['cleared']++;
    }
    if ($hasDue) {
        $categoryCounts['due']++;
    }

    $dur = TurnaroundService::calculateOrderDurations($o);

    $categorizedSupervisorOrders[] = [
        'order'     => $o,
        'fin'       => $fin,
        'wf_cat'    => $wfCat,
        'type_cat'  => $isTrial ? 'free_trial' : 'live_order',
        'pay_cat'   => $isCleared ? 'cleared' : ($hasDue ? 'due' : 'in_production'),
        'durations' => $dur
    ];
}

$velocityMetrics = TurnaroundService::getAggregateVelocity($allOrders);

$initialSupervisorCat = trim($_GET['cat'] ?? 'all');
if (!array_key_exists($initialSupervisorCat, $categoryCounts)) {
    $initialSupervisorCat = 'all';
}

// Count Online Team Leads
$tlOnlineCount = 0;
$tlStats = [];
foreach ($teamLeads as $tl) {
    $uid = $tl['user_id'] ?? $tl['id'];
    $presence = getStaffOnlinePresence($tl);
    if ($presence['is_online']) $tlOnlineCount++;
    
    $assigned  = array_filter($allOrders, fn($o) => ($o['assigned_tl_id'] ?? '') === $uid || ($o['assigned_tl_id'] ?? '') === $tl['id']);
    $completed = array_filter($assigned, fn($o) => in_array($o['status'] ?? '', ['approved','sent_client','completed']));
    $inProcess = array_filter($assigned, fn($o) => in_array($o['status'] ?? '', ['assigned_editor','in_process','submitted_qa','resubmitted']));
    $revision  = array_filter($assigned, fn($o) => ($o['status'] ?? '') === 'revision_required');
    
    $tlStats[$uid] = [
        'info'       => $tl,
        'presence'   => $presence,
        'assigned'   => count($assigned),
        'completed'  => count($completed),
        'in_process' => count($inProcess),
        'revision'   => count($revision)
    ];
}
$tlOfflineCount = count($teamLeads) - $tlOnlineCount;

// Count Online Editors
$edOnlineCount = 0;
$editorStats = [];
foreach ($editors as $ed) {
    $uid = $ed['user_id'] ?? $ed['id'];
    $presence = getStaffOnlinePresence($ed);
    if ($presence['is_online']) $edOnlineCount++;
    
    $assigned  = array_filter($allOrders, fn($o) => ($o['assigned_editor_id'] ?? '') === $uid || ($o['assigned_editor_id'] ?? '') === $ed['id']);
    $completed = array_filter($assigned, fn($o) => in_array($o['status'] ?? '', ['approved','sent_client','completed']));
    $inProcess = array_filter($assigned, fn($o) => in_array($o['status'] ?? '', ['in_process']));
    $totalImages = array_sum(array_map(fn($o) => $o['final_image_count'] ?? $o['photo_count'] ?? 0,
        array_filter($assigned, fn($o) => in_array($o['status'] ?? '', ['approved','sent_client','completed']))));
    
    $currentJob = null;
    foreach ($allOrders as $ord) {
        if (($ord['locked_by_id'] ?? '') === $uid || ($ord['assigned_editor_id'] ?? '') === $uid && ($ord['status'] ?? '') === 'in_process') {
            $currentJob = $ord['id'];
            break;
        }
    }
    
    $editorStats[$uid] = [
        'info'         => $ed,
        'presence'     => $presence,
        'current_job'  => $currentJob,
        'assigned'     => count($assigned),
        'completed'    => count($completed),
        'in_process'   => count($inProcess),
        'total_images' => $totalImages,
        'quality'      => $ed['quality_score'] ?? 97.0
    ];
}
$edOfflineCount = count($editors) - $edOnlineCount;

// Active View Mode from Header Navbar URL
$currentView = trim($_GET['view'] ?? 'daily'); // 'daily' | 'teamleads' | 'editors'
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $currentView === 'teamleads' ? 'Team Leads Directory' : ($currentView === 'editors' ? 'Photo Editors Directory' : 'Daily Properties') ?> — Supervisor Portal — Estate HDR</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php
require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8 space-y-8">
  <?= renderFlash() ?>

  <!-- ── PAGE HEADER ──────────────────────────────────────────────── -->
  <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
    <div>
      <div class="section-tag mb-1">Production Monitoring &amp; Operations Control</div>
      <h1 class="text-2xl sm:text-3xl font-black text-white">
        <?php
if ($currentView === 'teamleads'): ?>
          🛡️ TEAM LEADS DIRECTORY &amp; REAL-TIME PRESENCE
        <?php
elseif ($currentView === 'editors'): ?>
          🎨 PHOTO EDITORS DIRECTORY &amp; REAL-TIME PRESENCE
        <?php
else: ?>
          📋 DAILY PROPERTIES &amp; PRODUCTION PIPELINE
        <?php
endif; ?>
      </h1>
      <p class="text-gray-400 text-xs mt-1">
        <?php
if ($currentView === 'teamleads'): ?>
          Track Team Lead shifts, online/offline availability, workload distribution, and QA throughput.
        <?php
elseif ($currentView === 'editors'): ?>
          Track Photo Editor live shifts, active job processing, monthly images completed, and quality ratings.
        <?php
else: ?>
          Manage order intake, Team Lead assignments, QA approvals, and client delivery dispatching.
        <?php
endif; ?>
      </p>
    </div>
  </div>

  <!-- ── KPI COUNTERS ────────────────────────────────────────────── -->
  <div class="grid grid-cols-2 sm:grid-cols-6 gap-4">
    <!-- New Intake -->
    <div class="glass-card rounded-2xl p-4 border border-amber-500/40 bg-amber-950/10 space-y-1">
      <span class="text-[11px] text-amber-400 uppercase font-bold">New Intake</span>
      <div class="text-2xl font-black text-white"><?= count($newIntake) ?></div>
      <span class="text-[10px] text-amber-300 font-bold">Assign to TL &darr;</span>
    </div>
    <!-- Ready for Delivery -->
    <div class="glass-card rounded-2xl p-4 border border-emerald-500/40 bg-emerald-950/10 space-y-1">
      <span class="text-[11px] text-emerald-400 uppercase font-bold">Ready Delivery</span>
      <div class="text-2xl font-black text-emerald-300"><?= count($readyDelivery) ?></div>
      <span class="text-[10px] text-emerald-400 font-bold">QA Approved &darr;</span>
    </div>
    <!-- Active Pipeline -->
    <div class="glass-card rounded-2xl p-4 border border-blue-500/30 bg-blue-950/10 space-y-1">
      <span class="text-[11px] text-blue-400 uppercase font-bold">Active Orders</span>
      <div class="text-2xl font-black text-blue-300"><?= $totalActive ?></div>
      <span class="text-[10px] text-gray-400">In production</span>
    </div>
    <!-- Team Leads Online -->
    <div class="glass-card rounded-2xl p-4 border border-emerald-500/40 bg-emerald-950/10 space-y-1">
      <span class="text-[11px] text-emerald-400 uppercase font-bold">TLs Online</span>
      <div class="text-2xl font-black text-emerald-300 flex items-center gap-1.5">
        <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
        <span><?= $tlOnlineCount ?> <span class="text-xs text-gray-400 font-normal">/ <?= count($teamLeads) ?></span></span>
      </div>
      <span class="text-[10px] text-gray-400 font-mono"><?= $tlOfflineCount ?> offline</span>
    </div>
    <!-- Editors Online -->
    <div class="glass-card rounded-2xl p-4 border border-emerald-500/40 bg-emerald-950/10 space-y-1">
      <span class="text-[11px] text-emerald-400 uppercase font-bold">Editors Online</span>
      <div class="text-2xl font-black text-emerald-300 flex items-center gap-1.5">
        <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
        <span><?= $edOnlineCount ?> <span class="text-xs text-gray-400 font-normal">/ <?= count($editors) ?></span></span>
      </div>
      <span class="text-[10px] text-gray-400 font-mono"><?= $edOfflineCount ?> offline</span>
    </div>
    <!-- Delivered -->
    <div class="glass-card rounded-2xl p-4 border border-purple-500/30 space-y-1">
      <span class="text-[11px] text-purple-400 uppercase font-bold">Delivered</span>
      <div class="text-2xl font-black text-purple-300"><?= $deliveredAll ?></div>
      <span class="text-[10px] text-gray-400">Total completed</span>
    </div>
    <!-- Avg Editor Edit Velocity -->
    <div class="glass-card rounded-2xl p-4 border border-blue-500/40 bg-blue-950/20 space-y-1">
      <span class="text-[11px] text-blue-400 uppercase font-bold flex items-center gap-1"><span>⏱️</span> <span>Avg Editor Speed</span></span>
      <div class="text-2xl font-black text-blue-300 font-mono"><?= $velocityMetrics['avg_editor_duration_formatted'] ?></div>
      <span class="text-[10px] text-gray-400">Job lock &rarr; QA Submit</span>
    </div>
    <!-- Avg Team Lead QA Speed -->
    <div class="glass-card rounded-2xl p-4 border border-emerald-500/40 bg-emerald-950/20 space-y-1">
      <span class="text-[11px] text-emerald-400 uppercase font-bold flex items-center gap-1"><span>🛡️</span> <span>Avg TL QA Review</span></span>
      <div class="text-2xl font-black text-emerald-300 font-mono"><?= $velocityMetrics['avg_qa_duration_formatted'] ?></div>
      <span class="text-[10px] text-gray-400">QA Submit &rarr; Approved</span>
    </div>
  </div>

  <?php
if ($currentView === 'teamleads'): ?>
  <!-- ══════════════════════════════════════════════════════════════ -->
  <!-- ── TEAM LEADS DIRECTORY & REAL-TIME PRESENCE ──────────────── -->
  <!-- ══════════════════════════════════════════════════════════════ -->
  <div class="glass-card rounded-3xl border border-dark-border shadow-2xl overflow-hidden space-y-4 p-6">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-dark-border pb-4">
      <div class="flex items-center gap-3">
        <span class="text-2xl">🛡️</span>
        <div>
          <h3 class="text-base font-black text-white uppercase tracking-wider">ALL TEAM LEADS &amp; REAL-TIME PRESENCE</h3>
          <p class="text-xs text-gray-400">Live active status, shift schedules, assigned workload, and QA throughput per Team Lead.</p>
        </div>
      </div>
      
      <!-- Online / Offline Counter Pill -->
      <div class="flex items-center gap-2 text-xs font-mono">
        <span class="px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold inline-flex items-center gap-1.5">
          <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span><?= $tlOnlineCount ?> ONLINE NOW</span>
        </span>
        <span class="px-3 py-1 rounded-xl bg-gray-500/20 text-gray-400 border border-gray-500/40 font-bold">
          <?= $tlOfflineCount ?> OFFLINE
        </span>
      </div>
    </div>

    <div class="overflow-x-auto">
      <table class="dashboard-table w-full text-xs">
        <thead>
          <tr>
            <th>TEAM LEAD</th>
            <th>LIVE PRESENCE</th>
            <th>SHIFT &amp; HOURS</th>
            <th class="text-center">ASSIGNED JOBS</th>
            <th class="text-center">IN PROCESS</th>
            <th class="text-center">IN REVISION</th>
            <th class="text-center">QA APPROVED</th>
            <th class="text-right">QUALITY SCORE</th>
          </tr>
        </thead>
        <tbody>
          <?php
foreach ($tlStats as $uid => $stat): 
            $tl = $stat['info'];
            $pres = $stat['presence'];
          ?>
          <tr class="hover:bg-white/[0.02]">
            <td>
              <div class="flex items-center gap-3">
                <div class="w-8 h-8 rounded-full bg-gold/20 text-gold flex items-center justify-center font-black text-xs border border-gold/40">
                  <?= strtoupper(substr($tl['name'], 0, 2)) ?>
                </div>
                <div>
                  <div class="font-bold text-white text-sm"><?= htmlspecialchars($tl['name']) ?></div>
                  <div class="text-gray-400 text-[11px] font-mono"><?= htmlspecialchars($tl['email']) ?> &bull; <?= htmlspecialchars($tl['phone'] ?? '') ?></div>
                </div>
              </div>
            </td>
            <td>
              <span class="px-2.5 py-1 rounded-full text-[11px] font-bold border inline-flex items-center gap-1.5 <?= $pres['badge_class'] ?>">
                <span class="w-2 h-2 rounded-full <?= $pres['dot_class'] ?>"></span>
                <span><?= $pres['label'] ?></span>
                <span class="text-[10px] opacity-75">(<?= $pres['time_ago'] ?>)</span>
              </span>
            </td>
            <td class="text-gray-300">
              <span class="px-2 py-0.5 rounded bg-dark border border-dark-border font-mono text-[11px] text-gray-300">
                <?= htmlspecialchars($tl['shift'] ?? 'Day Shift') ?>
              </span>
            </td>
            <td class="text-center font-mono font-bold text-white text-sm"><?= $stat['assigned'] ?></td>
            <td class="text-center font-mono font-bold text-blue-400 text-sm"><?= $stat['in_process'] ?></td>
            <td class="text-center font-mono font-bold text-red-400 text-sm"><?= $stat['revision'] ?></td>
            <td class="text-center font-mono font-bold text-emerald-400 text-sm"><?= $stat['completed'] ?></td>
            <td class="text-right">
              <span class="font-mono font-black text-gold text-sm"><?= $tl['quality_score'] ?? 98.0 ?>%</span>
            </td>
          </tr>
          <?php
endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <?php
elseif ($currentView === 'editors'): ?>
  <!-- ══════════════════════════════════════════════════════════════ -->
  <!-- ── PHOTO EDITORS DIRECTORY & REAL-TIME PRESENCE ───────────── -->
  <!-- ══════════════════════════════════════════════════════════════ -->
  <div class="glass-card rounded-3xl border border-dark-border shadow-2xl overflow-hidden space-y-4 p-6">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-dark-border pb-4">
      <div class="flex items-center gap-3">
        <span class="text-2xl">🎨</span>
        <div>
          <h3 class="text-base font-black text-white uppercase tracking-wider">ALL PHOTO EDITORS &amp; REAL-TIME PRESENCE</h3>
          <p class="text-xs text-gray-400">Live active status, ongoing job locking, monthly image counts, and quality tracking.</p>
        </div>
      </div>
      
      <!-- Online / Offline Counter Pill -->
      <div class="flex items-center gap-2 text-xs font-mono">
        <span class="px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold inline-flex items-center gap-1.5">
          <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span><?= $edOnlineCount ?> ONLINE NOW</span>
        </span>
        <span class="px-3 py-1 rounded-xl bg-gray-500/20 text-gray-400 border border-gray-500/40 font-bold">
          <?= $edOfflineCount ?> OFFLINE
        </span>
      </div>
    </div>

    <div class="overflow-x-auto">
      <table class="dashboard-table w-full text-xs">
        <thead>
          <tr>
            <th>PHOTO EDITOR</th>
            <th>LIVE PRESENCE</th>
            <th>CURRENT ACTIVITY</th>
            <th>SHIFT</th>
            <th class="text-center">ASSIGNED</th>
            <th class="text-center">ACTIVE</th>
            <th class="text-center">COMPLETED</th>
            <th class="text-center">IMAGES DONE</th>
            <th class="text-right">QUALITY SCORE</th>
          </tr>
        </thead>
        <tbody>
          <?php
foreach ($editorStats as $uid => $stat): 
            $ed = $stat['info'];
            $pres = $stat['presence'];
          ?>
          <tr class="hover:bg-white/[0.02]">
            <td>
              <div class="flex items-center gap-3">
                <div class="w-8 h-8 rounded-full bg-purple-500/20 text-purple-300 flex items-center justify-center font-black text-xs border border-purple-500/40">
                  <?= strtoupper(substr($ed['name'], 0, 2)) ?>
                </div>
                <div>
                  <div class="font-bold text-white text-sm"><?= htmlspecialchars($ed['name']) ?></div>
                  <div class="text-gray-400 text-[11px] font-mono"><?= htmlspecialchars($ed['email']) ?></div>
                </div>
              </div>
            </td>
            <td>
              <span class="px-2.5 py-1 rounded-full text-[11px] font-bold border inline-flex items-center gap-1.5 <?= $pres['badge_class'] ?>">
                <span class="w-2 h-2 rounded-full <?= $pres['dot_class'] ?>"></span>
                <span><?= $pres['label'] ?></span>
                <span class="text-[10px] opacity-75">(<?= $pres['time_ago'] ?>)</span>
              </span>
            </td>
            <td>
              <?php
if (!empty($stat['current_job'])): ?>
                <span class="px-2.5 py-1 rounded-xl bg-blue-500/20 text-blue-300 border border-blue-500/40 text-[11px] font-bold font-mono inline-flex items-center gap-1">
                  <span>⚡</span> <span>Editing #<?= htmlspecialchars($stat['current_job']) ?></span>
                </span>
              <?php
elseif ($pres['is_online']): ?>
                <span class="px-2.5 py-1 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[11px] font-bold">
                  ✓ Available for Job
                </span>
              <?php
else: ?>
                <span class="text-gray-500 text-[11px] italic">Not on shift</span>
              <?php
endif; ?>
            </td>
            <td class="text-gray-300 font-mono text-[11px]">
              <?= htmlspecialchars($ed['shift'] ?? 'Day Shift') ?>
            </td>
            <td class="text-center font-mono font-bold text-white text-sm"><?= $stat['assigned'] ?></td>
            <td class="text-center font-mono font-bold text-blue-400 text-sm"><?= $stat['in_process'] ?></td>
            <td class="text-center font-mono font-bold text-emerald-400 text-sm"><?= $stat['completed'] ?></td>
            <td class="text-center font-mono font-black text-gold text-sm"><?= number_format($stat['total_images']) ?> 📸</td>
            <td class="text-right">
              <span class="font-mono font-black text-emerald-400 text-sm"><?= $stat['quality'] ?>%</span>
            </td>
          </tr>
          <?php
endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <?php
else: ?>
  <!-- ══════════════════════════════════════════════════════════════ -->
  <!-- ── DAILY PROPERTIES & MASTER PIPELINE ─────────────────────── -->
  <!-- ══════════════════════════════════════════════════════════════ -->

  <!-- 1. NEW INTAKE SECTION (ASSIGN TO TEAM LEAD) -->
  <?php
if (!empty($newIntake)): ?>
  <div class="glass-card rounded-3xl border border-amber-500/50 bg-amber-950/10 shadow-2xl p-6 space-y-4">
    <div class="flex items-center justify-between border-b border-amber-500/30 pb-4">
      <div class="flex items-center gap-2">
        <span class="text-xl animate-bounce">📥</span>
        <div>
          <h3 class="text-base font-black text-white">NEW CLIENT ORDERS — AWAITING TEAM LEAD ASSIGNMENT</h3>
          <p class="text-xs text-amber-200/80">Select a Team Lead to assign each incoming job.</p>
        </div>
      </div>
      <span class="px-3 py-1 rounded-full bg-amber-500/20 text-amber-400 font-bold text-xs border border-amber-500/40">
        <?= count($newIntake) ?> Orders Pending Assignment
      </span>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      <?php
foreach ($newIntake as $o): ?>
      <div class="p-5 rounded-2xl bg-dark/90 border border-amber-500/30 space-y-3">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <span class="font-mono font-bold text-gold text-sm"><?= htmlspecialchars($o['id']) ?></span>
            <?php
            $isTrialIntake = !empty($o['is_trial']) || (($o['order_type'] ?? '') === 'free_trial');
            if ($isTrialIntake): ?>
              <span class="px-2 py-0.5 rounded text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm">🎁 FREE TRIAL ($0.00)</span>
            <?php else: ?>
              <span class="px-2 py-0.5 rounded text-[10px] font-black bg-blue-500/20 text-blue-300 border border-blue-500/40 shadow-sm">⚡ LIVE ORDER</span>
            <?php endif; ?>
          </div>
          <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">NEW ORDER</span>
            <?php
if (isOwner()): ?>
            <a href="/admin/supervisor-dashboard.php?delete_order_id=<?= urlencode($o['id']) ?>"
               data-confirm="Delete order <?= addslashes(htmlspecialchars($o['id'], ENT_QUOTES)) ?>? This CANNOT be undone!"
               class="p-1 rounded-lg bg-red-600/20 hover:bg-red-600/40 text-red-400 border border-red-500/40 text-[10px] font-black transition-all inline-flex items-center"
               title="Delete this order permanently">
              Delete
            </a>
            <?php
endif; ?>
        </div>
        <div>
          <div class="font-bold text-white text-sm"><?= htmlspecialchars($o['property_name']) ?></div>
          <div class="text-gray-400 text-xs mt-0.5"><?= htmlspecialchars($o['editing_type']) ?> &bull; <strong class="text-white"><?= $o['photo_count'] ?> Photos</strong></div>
        </div>
        
        <?php
if (!empty($o['input_storage_path'])): ?>
        <div class="text-xs">
          <a href="<?= htmlspecialchars($o['input_storage_path']) ?>" target="_blank" class="text-blue-400 hover:underline inline-flex items-center gap-1 font-mono">
            <span>📁</span> <span>Source Raw Files ↗</span>
          </a>
        </div>
        <?php
endif; ?>

        <!-- Assign Team Lead Form -->
        <form method="POST" class="pt-2 border-t border-dark-border space-y-2">
          <?= csrfField() ?>
          <input type="hidden" name="assign_team_lead" value="1">
          <input type="hidden" name="order_id" value="<?= htmlspecialchars($o['id']) ?>">
          
          <label class="form-label text-[11px] font-bold text-gray-300">Assign to Team Lead:</label>
          <div class="flex gap-2">
            <select name="tl_id" required class="form-select text-xs py-1.5 px-2.5 bg-[#161622] border-[#2A2A3A] rounded-xl flex-1 text-white">
              <?php
foreach ($teamLeads as $tl): 
                $tlUid = $tl['user_id'] ?? $tl['id'];
                $tlPresence = getStaffOnlinePresence($tl);
                $tlActiveCount = count(array_filter($allOrders, fn($ord) => (($ord['assigned_tl_id'] ?? '') === $tlUid || ($ord['assigned_tl_id'] ?? '') === $tl['id']) && !in_array($ord['status'] ?? '', ['completed','sent_client'])));
              ?>
                <option value="<?= htmlspecialchars($tlUid) ?>">
                  <?= $tlPresence['is_online'] ? '🟢' : '⚪' ?> <?= htmlspecialchars($tl['name']) ?> (<?= $tlActiveCount ?> active)
                </option>
              <?php
endforeach; ?>
            </select>
            <button type="submit" class="btn-gold py-1.5 px-3 text-xs font-black shadow-glow whitespace-nowrap">
              Assign &rarr;
            </button>
          </div>
        </form>
      </div>
      <?php
endforeach; ?>
    </div>
  </div>
  <?php
endif; ?>

  <!-- 2. READY FOR DELIVERY SECTION (DUAL LINKS: WATERMARK PROOF & FINAL PHOTOS) -->
  <?php
if (!empty($readyDelivery)): ?>
  <div class="glass-card rounded-3xl border border-emerald-500/50 bg-emerald-950/10 shadow-2xl p-6 space-y-4">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-emerald-500/30 pb-4">
      <div class="flex items-center gap-2.5">
        <span class="text-2xl animate-pulse">🚀</span>
        <div>
          <h3 class="text-base font-black text-white flex items-center gap-2">
            <span>READY FOR CLIENT DELIVERY — DUAL LINK WORKFLOW</span>
            <span class="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold uppercase">TL QA Approved</span>
          </h3>
          <p class="text-xs text-emerald-200/80">Send <strong>Watermarked Proofs</strong> first to secure client payment, then dispatch <strong>Final Photos (Without Watermark)</strong> once paid.</p>
        </div>
      </div>
      <span class="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-xs border border-emerald-500/40 self-start sm:self-auto">
        <?= count($readyDelivery) ?> In Delivery Stage
      </span>
    </div>

    <div class="space-y-4">
      <?php
foreach ($readyDelivery as $o): 
        $clientPhoneClean = preg_replace('/[^0-9]/', '', $o['client_phone'] ?? '');
        $isWatermarkSent  = (($o['status'] ?? '') === 'watermarked_delivered') || !empty($o['watermark_sent']);
        $finStatus        = function_exists('getOrderFinancialStatus') ? getOrderFinancialStatus($o) : [];
        $isCleared        = !empty($finStatus['cleared']);
        $isTrialReady     = !empty($o['is_trial']) || (($o['order_type'] ?? '') === 'free_trial') || stripos($o['id'] ?? '', 'TRIAL-') === 0;
        $orderBilledPrice = (float)($o['price_amount'] ?? ($o['billed_amount'] ?? 0.0));
        
        $currentWatermarkUrl = $o['watermark_url'] ?? '';
        $currentDeliveryUrl  = $o['delivery_url'] ?? ($o['final_cloud_link'] ?? '');
        
        $waWatermarkMsg = urlencode("Hi " . ($o['client_name'] ?? 'Client') . "! Your watermarked photo proofs for '" . ($o['property_name'] ?? 'Property') . "' are ready for review: " . ($currentWatermarkUrl ?: '[PASTE_WATERMARK_LINK]') . " - Please review and send PayPal payment of $" . number_format($orderBilledPrice, 2) . " USD to unlock clean final deliverables. Thank you, Estate HDR");
        $waFinalMsg = urlencode("Hi " . ($o['client_name'] ?? 'Client') . "! Your final clean photos (without watermark) for '" . ($o['property_name'] ?? 'Property') . "' are ready for download: " . ($currentDeliveryUrl ?: '[PASTE_FINAL_LINK]') . " - Thank you for choosing Estate HDR!");
      ?>
      <div class="p-6 rounded-2xl bg-dark/95 border <?= $isWatermarkSent ? 'border-amber-500/50 bg-amber-950/10' : 'border-emerald-500/30' ?> space-y-4 shadow-xl">
        <div class="flex flex-col sm:flex-row justify-between gap-3 border-b border-dark-border pb-3">
          <div>
            <div class="flex flex-wrap items-center gap-2">
              <span class="font-mono font-bold text-gold text-base"><?= htmlspecialchars($o['id']) ?></span>
              
              <?php if ($isTrialReady): ?>
                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm">🎁 FREE TRIAL ($0.00 COMPLIMENTARY)</span>
              <?php elseif ($isCleared): ?>
                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-sm">✅ PAID &bull; CLEARED ($<?= number_format($orderBilledPrice, 2) ?>)</span>
              <?php else: ?>
                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm">⏳ PAYMENT PENDING ($<?= number_format($orderBilledPrice, 2) ?> USD)</span>
              <?php endif; ?>

              <?php if ($isWatermarkSent): ?>
                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-blue-500/20 text-blue-300 border border-blue-500/40 animate-pulse">💧 WATERMARKED PROOFS SENT</span>
              <?php endif; ?>
            </div>

            <span class="font-bold text-white text-base mt-1 block"><?= htmlspecialchars($o['property_name']) ?></span>
            <div class="text-xs text-gray-400 mt-0.5">
              Client: <strong class="text-white"><?= htmlspecialchars($o['client_name']) ?></strong> 
              (<?= htmlspecialchars($o['client_email']) ?> &bull; <?= htmlspecialchars($o['client_phone']) ?>)
            </div>
          </div>

          <div class="flex flex-col items-start sm:items-end gap-1.5">
            <span class="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-xs font-bold">
              ✓ QA Approved by <?= htmlspecialchars($o['assigned_tl_name'] ?? 'Team Lead') ?>
            </span>
            
            <?php if (!$isCleared && !$isTrialReady): ?>
            <form method="POST" class="inline">
              <?= csrfField() ?>
              <input type="hidden" name="mark_order_paid" value="1">
              <input type="hidden" name="order_id" value="<?= htmlspecialchars($o['id']) ?>">
              <input type="hidden" name="paid_amount" value="<?= $orderBilledPrice ?>">
              <button type="submit" class="text-[11px] font-black text-emerald-300 hover:text-white bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 px-3 py-1 rounded-lg transition-all inline-flex items-center gap-1 shadow-sm" title="Mark order as paid and unlock final delivery">
                <span>💰</span> <span>1-Click Mark Paid ($<?= number_format($orderBilledPrice, 2) ?>)</span>
              </button>
            </form>
            <?php endif; ?>
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
          <div class="p-3 rounded-xl bg-[#111118] border border-dark-border">
            <span class="text-gray-400 block">Editor Output Path (Internal):</span>
            <strong class="text-gold text-sm break-all"><?= htmlspecialchars($o['output_storage_path'] ?: 'Check internal storage server') ?></strong>
          </div>
          <div class="p-3 rounded-xl bg-[#111118] border border-dark-border">
            <span class="text-gray-400 block">Delivered Photos Count:</span>
            <strong class="text-emerald-400 text-sm"><?= $o['final_image_count'] ?? $o['photo_count'] ?> Retouched Images</strong>
          </div>
        </div>

        <!-- ── DUAL LINK DISPATCH FORM ── -->
        <form method="POST" class="pt-3 border-t border-dark-border space-y-4">
          <?= csrfField() ?>
          <input type="hidden" name="dispatch_delivery" value="1">
          <input type="hidden" name="order_id" value="<?= htmlspecialchars($o['id']) ?>">
          
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <!-- 1. WATERMARK PHOTOS LINK -->
            <div class="p-3.5 rounded-xl bg-[#11131d] border border-amber-500/30 space-y-1.5">
              <div class="flex items-center justify-between">
                <label class="form-label text-xs font-bold text-amber-300 flex items-center gap-1.5">
                  <span>💧</span> <span>1. Watermark Photos Link (Proofing / Review)</span>
                </label>
                <?php if (!empty($currentWatermarkUrl)): ?>
                  <a href="<?= htmlspecialchars($currentWatermarkUrl) ?>" target="_blank" class="text-[11px] text-amber-400 hover:underline">Inspect ↗</a>
                <?php endif; ?>
              </div>
              <input type="url" name="watermark_url" value="<?= htmlspecialchars($currentWatermarkUrl) ?>"
                     placeholder="https://drive.google.com/drive/folders/... (With Watermark)"
                     class="form-input text-xs w-full bg-[#0a0c14] text-white border-amber-500/40 focus:border-amber-400">
              <span class="text-[10px] text-gray-400 block">Send to client first for quality approval and payment prompt.</span>
            </div>

            <!-- 2. FINAL CLEAN PHOTOS LINK -->
            <div class="p-3.5 rounded-xl bg-[#111718] border border-emerald-500/30 space-y-1.5">
              <div class="flex items-center justify-between">
                <label class="form-label text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                  <span>✨</span> <span>2. Final Photos Link (Without Watermark)</span>
                </label>
                <?php if (!empty($currentDeliveryUrl)): ?>
                  <a href="<?= htmlspecialchars($currentDeliveryUrl) ?>" target="_blank" class="text-[11px] text-emerald-400 hover:underline">Inspect ↗</a>
                <?php endif; ?>
              </div>
              <input type="url" name="delivery_url" value="<?= htmlspecialchars($currentDeliveryUrl) ?>"
                     placeholder="https://drive.google.com/drive/folders/... (Clean deliverables - No Watermark)"
                     class="form-input text-xs w-full bg-[#0a0c14] text-white border-emerald-500/40 focus:border-emerald-400">
              <span class="text-[10px] text-gray-400 block">Send to client immediately once payment is verified or cleared.</span>
            </div>
          </div>

          <!-- Billed Amount Row -->
          <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
            <div class="sm:col-span-1">
              <label class="form-label text-xs font-bold <?= $isTrialReady ? 'text-amber-300' : 'text-gray-300' ?>">Order Billed Amount ($)</label>
              <?php if ($isTrialReady): ?>
                <input type="text" name="price_amount" value="0.00" readonly
                       class="form-input text-xs w-full mt-1 bg-[#161622] text-emerald-400 font-bold border-amber-500/40 cursor-not-allowed">
              <?php else: ?>
                <input type="number" step="0.01" name="price_amount" value="<?= htmlspecialchars((string)($orderBilledPrice > 0 ? $orderBilledPrice : '')) ?>"
                       class="form-input text-xs w-full mt-1 bg-[#111118] text-white">
              <?php endif; ?>
            </div>

            <div class="sm:col-span-2 text-xs text-gray-400 pt-5">
              Method: Automatically dispatches official branded notification email with PayPal link and updates client portal thread.
            </div>
          </div>

          <!-- ── 2 ACTION DISPATCH BUTTONS ── -->
          <div class="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-dark-border">
            <div class="flex flex-wrap items-center gap-2.5">
              <!-- BUTTON 1: WATERMARK DISPATCH -->
              <button type="submit" name="dispatch_type" value="watermark" 
                      class="py-2.5 px-5 text-xs font-bold text-amber-300 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 rounded-xl inline-flex items-center gap-2 shadow-sm transition-all">
                <span>💧</span> <span>Send Watermarked Photos to Client</span>
              </button>

              <!-- BUTTON 2: FINAL CLEAN DISPATCH -->
              <button type="submit" name="dispatch_type" value="final" 
                      class="btn-gold py-2.5 px-6 text-xs font-black shadow-glow inline-flex items-center gap-2 transition-all">
                <span>✨</span> <span>Send Final Photos (Without Watermark)</span>
              </button>
            </div>

            <!-- WhatsApp helper links -->
            <?php if (!empty($clientPhoneClean)): ?>
            <div class="flex items-center gap-3 text-xs">
              <a href="https://wa.me/<?= $clientPhoneClean ?>?text=<?= $waWatermarkMsg ?>" target="_blank" class="text-amber-300 hover:underline font-bold inline-flex items-center gap-1" title="Send Watermark Proof message via WhatsApp">
                <span>💬</span> <span>WA Proof ↗</span>
              </a>
              <span class="text-gray-600">&bull;</span>
              <a href="https://wa.me/<?= $clientPhoneClean ?>?text=<?= $waFinalMsg ?>" target="_blank" class="text-emerald-400 hover:underline font-bold inline-flex items-center gap-1" title="Send Final Clean Photos message via WhatsApp">
                <span>💬</span> <span>WA Final ↗</span>
              </a>
            </div>
            <?php endif; ?>
          </div>
        </form>
      </div>
      <?php
endforeach; ?>
    </div>
  </div>
  <?php
endif; ?>

  <!-- 3. MASTER PRODUCTION PIPELINE & CATEGORIES TABLE (DAILY PROPERTIES) -->
  <div class="glass-card rounded-3xl border border-dark-border shadow-2xl overflow-hidden space-y-4 p-6">
    <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-dark-border pb-4">
      <div>
        <h3 class="font-black text-white uppercase text-base tracking-wider flex items-center gap-2">
          <span>📋</span> <span>MASTER PRODUCTION PIPELINE &amp; CATEGORIES</span>
        </h3>
        <p class="text-xs text-gray-400 mt-0.5">Filter by workflow pipeline stage, commercial category (Free Trial vs Live Orders), or payment clearance.</p>
      </div>

      <div class="flex items-center gap-2.5">
        <a href="/admin/supervisor-dashboard.php?reconcile=1" class="py-2 px-3 rounded-xl bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 border border-blue-500/30 text-xs font-bold transition-all inline-flex items-center gap-1.5" title="Reconcile delivered orders with billing ledger">
          <span>🔄</span> <span>Sync Delivered</span>
        </a>
        <div class="w-full sm:w-64">
          <input type="text" id="supervisorSearchInput" onkeyup="filterSupervisorOrders()" placeholder="Search order ID, property, client..." class="form-input text-xs py-2 px-3 bg-[#111118] border-dark-border rounded-xl w-full text-white placeholder-gray-500">
        </div>
      </div>
    </div>

    <!-- Category Tabs Bar -->
    <div class="flex flex-wrap items-center gap-2 pt-1 pb-1">
      <button type="button" onclick="setSupervisorCategory('all')" id="supCatBtn-all" class="sup-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-gold text-black shadow-lg shadow-gold/20">
        <span>📋 All Properties</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-black/30 text-black sup-count-badge"><?= $categoryCounts['all'] ?></span>
      </button>

      <button type="button" onclick="setSupervisorCategory('pending')" id="supCatBtn-pending" class="sup-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-transparent text-gray-400 hover:text-white hover:bg-white/5">
        <span>⏳ Pending Intake</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 sup-count-badge"><?= $categoryCounts['pending'] ?></span>
      </button>

      <button type="button" onclick="setSupervisorCategory('in_production')" id="supCatBtn-in_production" class="sup-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-transparent text-gray-400 hover:text-white hover:bg-white/5">
        <span>⚙️ In Production</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-500/20 text-blue-300 sup-count-badge"><?= $categoryCounts['in_production'] ?></span>
      </button>

      <button type="button" onclick="setSupervisorCategory('ready_delivery')" id="supCatBtn-ready_delivery" class="sup-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-transparent text-gray-400 hover:text-white hover:bg-white/5">
        <span>🚀 Ready Delivery</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-300 sup-count-badge"><?= $categoryCounts['ready_delivery'] ?></span>
      </button>

      <button type="button" onclick="setSupervisorCategory('delivered')" id="supCatBtn-delivered" class="sup-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-transparent text-gray-400 hover:text-white hover:bg-white/5">
        <span>✅ Delivered</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-purple-500/20 text-purple-300 sup-count-badge"><?= $categoryCounts['delivered'] ?></span>
      </button>

      <div class="h-6 w-px bg-dark-border mx-1 hidden sm:block"></div>

      <button type="button" onclick="setSupervisorCategory('free_trial')" id="supCatBtn-free_trial" class="sup-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-transparent text-gray-400 hover:text-white hover:bg-white/5">
        <span>🎁 Free Trials</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 sup-count-badge"><?= $categoryCounts['free_trial'] ?></span>
      </button>

      <button type="button" onclick="setSupervisorCategory('live_order')" id="supCatBtn-live_order" class="sup-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-transparent text-gray-400 hover:text-white hover:bg-white/5">
        <span>⚡ Live Orders</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-500/20 text-blue-300 sup-count-badge"><?= $categoryCounts['live_order'] ?></span>
      </button>

      <button type="button" onclick="setSupervisorCategory('cleared')" id="supCatBtn-cleared" class="sup-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-transparent text-gray-400 hover:text-white hover:bg-white/5">
        <span>💰 Cleared / Paid</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-green-500/20 text-green-300 sup-count-badge"><?= $categoryCounts['cleared'] ?></span>
      </button>

      <button type="button" onclick="setSupervisorCategory('due')" id="supCatBtn-due" class="sup-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-transparent text-gray-400 hover:text-white hover:bg-white/5">
        <span>⏳ Balance Due</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 sup-count-badge"><?= $categoryCounts['due'] ?></span>
      </button>
    </div>

    <!-- Table -->
    <div class="overflow-x-auto">
      <table class="dashboard-table w-full text-left text-xs" id="supervisorOrdersTable">
        <thead>
          <tr class="border-b border-dark-border bg-[#141420]">
            <th class="py-3 px-3">ORDER ID</th>
            <th class="py-3 px-3">PROPERTY &amp; CLIENT</th>
            <th class="py-3 px-3">CATEGORY</th>
            <th class="py-3 px-3">CLEARANCE</th>
            <th class="py-3 px-3">PHOTOS</th>
            <th class="py-3 px-3">ASSIGNED TL</th>
            <th class="py-3 px-3">ASSIGNED EDITOR</th>
            <th class="py-3 px-3">WORKFLOW STATUS</th>
            <th class="py-3 px-3">⏱️ EDITOR TIME</th>
            <th class="py-3 px-3">🛡️ QA TIME</th>
            <th class="py-3 px-3">DEADLINE</th>
            <th class="py-3 px-3 text-right">ACTION</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-dark-border">
          <?php foreach ($categorizedSupervisorOrders as $item):
            $o = $item['order'];
            $fin = $item['fin'];
            $wfCat = $item['wf_cat'];
            $typeCat = $item['type_cat'];
            $payCat = $item['pay_cat'];
            $s = strtolower($o['status'] ?? 'pending');
            $dur = TurnaroundService::calculateOrderDurations($o);
          ?>
          <tr class="hover:bg-white/[0.02] transition-colors sup-order-row"
              data-wf-cat="<?= htmlspecialchars($wfCat) ?>"
              data-type-cat="<?= htmlspecialchars($typeCat) ?>"
              data-pay-cat="<?= htmlspecialchars($payCat) ?>">
            
            <!-- ORDER ID -->
            <td class="py-3 px-3 font-mono font-bold text-gold">
              <a href="/admin/order-view.php?id=<?= urlencode($o['order_id'] ?? $o['id']) ?>" class="hover:underline">
                <?= htmlspecialchars($o['id']) ?>
              </a>
            </td>

            <!-- PROPERTY & CLIENT -->
            <td class="py-3 px-3">
              <div class="font-bold text-white text-xs"><?= htmlspecialchars($o['property_name'] ?? $o['property_ref'] ?? '—') ?></div>
              <div class="text-gray-400 text-[11px] mt-0.5">
                Client: <span class="text-gray-300 font-medium"><?= htmlspecialchars($o['client_name'] ?? 'Client') ?></span>
                <?php if (!empty($o['client_email'])): ?>
                  <span class="text-gray-500 font-mono text-[10px]">&bull; <?= htmlspecialchars($o['client_email']) ?></span>
                <?php endif; ?>
              </div>
            </td>

            <!-- CATEGORY BADGE -->
            <td class="py-3 px-3 whitespace-nowrap">
              <?= $fin['category_badge'] ?>
            </td>

            <!-- CLEARANCE / PAYMENT STATUS -->
            <td class="py-3 px-3 whitespace-nowrap">
              <?= $fin['payment_badge'] ?>
            </td>

            <!-- PHOTOS -->
            <td class="py-3 px-3 font-mono font-bold text-white">
              <?= $o['photo_count'] ?? 0 ?>
              <?php if (!empty($o['final_image_count'])): ?>
                <span class="text-emerald-400 font-bold">&rarr; <?= $o['final_image_count'] ?></span>
              <?php endif; ?>
            </td>

            <!-- ASSIGNED TL -->
            <td class="py-3 px-3 whitespace-nowrap">
              <?php if (!empty($o['assigned_tl_name'])): ?>
                <span class="font-bold text-white"><?= htmlspecialchars($o['assigned_tl_name']) ?></span>
              <?php else: ?>
                <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">Unassigned</span>
              <?php endif; ?>
            </td>

            <!-- ASSIGNED EDITOR -->
            <td class="py-3 px-3 whitespace-nowrap">
              <?php if (!empty($o['assigned_editor_name'])): ?>
                <span class="font-bold text-blue-300"><?= htmlspecialchars($o['assigned_editor_name']) ?></span>
                <?php if (!empty($o['locked_by_id'])): ?>
                  <span class="ml-1 text-[10px] text-blue-400 font-bold">● Editing</span>
                <?php endif; ?>
              <?php else: ?>
                <span class="text-gray-500 italic text-[11px]">Not assigned</span>
              <?php endif; ?>
            </td>

            <!-- WORKFLOW STATUS -->
            <td class="py-3 px-3 whitespace-nowrap">
              <?php if ($s === 'revision_required'): ?>
                <span class="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/40 font-bold text-[10px] animate-pulse">REVISION REQ.</span>
              <?php elseif ($s === 'watermarked_delivered'): ?>
                <span class="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold text-[10px]">💧 WATERMARK SENT</span>
              <?php elseif (in_array($s, ['approved', 'ready_delivery'])): ?>
                <span class="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold text-[10px]">✓ READY FOR DELIVERY</span>
              <?php elseif (in_array($s, ['sent_client', 'completed', 'delivered'])): ?>
                <span class="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/40 font-bold text-[10px]">✓ DELIVERED</span>
              <?php elseif (in_array($s, ['submitted_qa','resubmitted'])): ?>
                <span class="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/40 font-bold text-[10px]">QA REVIEW</span>
              <?php elseif ($s === 'in_process'): ?>
                <span class="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/40 font-bold text-[10px]">IN PROCESS</span>
              <?php else: ?>
                <span class="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold text-[10px]"><?= strtoupper(str_replace('_', ' ', $s)) ?></span>
              <?php endif; ?>
            </td>

            <!-- ⏱️ EDITOR TIME -->
            <td class="py-3 px-3 whitespace-nowrap">
              <span class="inline-flex items-center gap-1 font-mono text-[11px] <?= $dur['editor_badge_class'] ?>">
                <?= htmlspecialchars($dur['editor_duration_formatted']) ?>
                <?php if ($dur['editor_active']): ?>
                  <span class="inline-block w-1.5 h-1.5 rounded-full bg-blue-400 animate-ping"></span>
                <?php endif; ?>
              </span>
            </td>

            <!-- 🛡️ QA TIME -->
            <td class="py-3 px-3 whitespace-nowrap">
              <span class="inline-flex items-center gap-1 font-mono text-[11px] <?= $dur['qa_badge_class'] ?>">
                <?= htmlspecialchars($dur['qa_duration_formatted']) ?>
                <?php if ($dur['qa_active']): ?>
                  <span class="inline-block w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping"></span>
                <?php endif; ?>
              </span>
            </td>

            <!-- DEADLINE -->
            <td class="py-3 px-3 font-mono text-gray-400 whitespace-nowrap">
              <?= date('M j, H:i', strtotime($o['deadline'] ?? 'now')) ?>
            </td>

            <!-- ACTIONS -->
            <td class="py-3 px-3 text-right whitespace-nowrap">
              <div class="flex items-center justify-end gap-1.5">
                <button type="button" 
                        onclick="openSupervisorDispatchModal(<?= htmlspecialchars(json_encode([
                          'id'             => $o['id'],
                          'property_name'  => $o['property_name'] ?? ($o['property_ref'] ?? 'Property'),
                          'client_name'    => $o['client_name'] ?? 'Client',
                          'client_email'   => $o['client_email'] ?? '',
                          'client_phone'   => $o['client_phone'] ?? '',
                          'watermark_url'  => $o['watermark_url'] ?? '',
                          'delivery_url'   => $o['delivery_url'] ?? ($o['final_cloud_link'] ?? ''),
                          'price_amount'   => (float)($o['price_amount'] ?? ($o['billed_amount'] ?? 0)),
                          'status'         => $o['status'] ?? 'pending',
                          'payment_status' => $fin['payment_status'] ?? ($o['payment_status'] ?? 'pending'),
                          'is_trial'       => !empty($fin['is_trial']),
                          'cleared'        => !empty($fin['cleared']),
                        ]), ENT_QUOTES, 'UTF-8') ?>)" 
                        class="py-1 px-2.5 text-[11px] font-bold rounded-lg border border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/10 inline-flex items-center gap-1 shadow-sm transition-all"
                        title="Dispatch Watermark or Final Delivery Links">
                  <span>🚀</span> <span>Dispatch</span>
                </button>
                <a href="/admin/order-view.php?id=<?= urlencode($o['order_id'] ?? $o['id']) ?>" class="btn-ghost py-1 px-2.5 text-[11px] font-bold border border-dark-border text-gray-300 hover:text-white rounded-lg">
                  View
                </a>
                <?php if (isOwner()): ?>
                <button type="button" onclick="openDeleteOrderGodModal('<?= htmlspecialchars($o['id'], ENT_QUOTES) ?>', '<?= htmlspecialchars($o['property_ref'] ?? $o['property_name'] ?? $o['id'], ENT_QUOTES) ?>')" class="btn-ghost py-1 px-2 text-[11px] font-bold text-red-400 border border-red-500/30 hover:bg-red-500/10 rounded-lg" title="Delete Order">
                  Delete
                </button>
                <?php endif; ?>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
          <tr id="supervisorEmptyRow" class="hidden">
            <td colspan="12" class="py-12 text-center text-gray-500 text-xs">
              No orders found matching this category filter.
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  <?php
endif; ?>

</main>

<!-- DUAL LINK SUPERVISOR DISPATCH MODAL -->
<div id="supervisorDispatchModal" class="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 sm:p-8 max-w-xl w-full border border-emerald-500/50 shadow-2xl space-y-5 bg-[#0e111a]">
    <div class="flex items-center justify-between border-b border-dark-border pb-4">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-300 text-xl font-bold">
          🚀
        </div>
        <div>
          <h3 class="text-base font-black text-white flex items-center gap-2">
            <span>Dispatch Delivery Links</span>
            <span id="sdm_display_id" class="text-xs font-mono text-gold font-bold"></span>
          </h3>
          <p class="text-xs text-gray-400">Send Watermarked Proof or Final Clean Photos to client.</p>
        </div>
      </div>
      <button type="button" onclick="closeSupervisorDispatchModal()" class="text-gray-400 hover:text-white text-xl font-bold p-1">&times;</button>
    </div>

    <!-- Order summary & Payment clearance card -->
    <div class="p-4 rounded-2xl bg-[#141824] border border-dark-border space-y-2 text-xs">
      <div class="flex flex-wrap items-center justify-between gap-2">
        <strong id="sdm_display_prop" class="text-white text-sm font-bold"></strong>
        <div id="sdm_payment_status"></div>
      </div>
      <div id="sdm_display_client" class="text-gray-400"></div>
    </div>

    <!-- Dispatch Form -->
    <form method="POST" action="/admin/supervisor-dashboard.php" class="space-y-4 text-xs">
      <?= csrfField() ?>
      <input type="hidden" name="dispatch_delivery" value="1">
      <input type="hidden" name="order_id" id="sdm_order_id" value="">
      
      <!-- Watermark Proof Link Input -->
      <div class="p-3.5 rounded-xl bg-[#131622] border border-amber-500/30 space-y-1.5">
        <label class="form-label text-xs font-bold text-amber-300 flex items-center gap-1.5">
          <span>💧</span> <span>1. Watermark Photos Link (Proofing / Review)</span>
        </label>
        <input type="url" name="watermark_url" id="sdm_watermark_url"
               placeholder="https://drive.google.com/drive/folders/... (With Watermark)"
               class="form-input text-xs w-full bg-[#0a0c14] text-white border-amber-500/40 focus:border-amber-400">
        <span class="text-[10px] text-gray-400 block">Deliver proof for review &amp; prompt client for PayPal payment.</span>
      </div>

      <!-- Final Clean Photos Link Input -->
      <div class="p-3.5 rounded-xl bg-[#11191a] border border-emerald-500/30 space-y-1.5">
        <label class="form-label text-xs font-bold text-emerald-300 flex items-center gap-1.5">
          <span>✨</span> <span>2. Final Photos Link (Without Watermark)</span>
        </label>
        <input type="url" name="delivery_url" id="sdm_delivery_url"
               placeholder="https://drive.google.com/drive/folders/... (Clean High-Res Deliverables)"
               class="form-input text-xs w-full bg-[#0a0c14] text-white border-emerald-500/40 focus:border-emerald-400">
        <span class="text-[10px] text-gray-400 block">Deliver once client payment is confirmed and verified.</span>
      </div>

      <div class="grid grid-cols-2 gap-3 items-center">
        <div>
          <label class="form-label text-xs font-bold text-gray-300">Order Billed Amount ($)</label>
          <input type="number" step="0.01" name="price_amount" id="sdm_price_amount"
                 class="form-input text-xs w-full mt-1 bg-[#111118] text-white">
        </div>
        <div class="pt-5 text-right">
          <button type="button" id="sdm_mark_paid_btn" class="py-2 px-3 text-xs font-black text-emerald-300 bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 rounded-xl transition-all inline-flex items-center gap-1.5">
            <span>💰</span> <span>1-Click Mark Paid</span>
          </button>
        </div>
      </div>

      <!-- Action Buttons -->
      <div class="pt-3 border-t border-dark-border flex flex-wrap items-center justify-between gap-3">
        <button type="button" onclick="closeSupervisorDispatchModal()" class="btn-ghost py-2.5 px-4 text-xs font-bold">
          Cancel
        </button>

        <div class="flex items-center gap-2.5">
          <button type="submit" name="dispatch_type" value="watermark"
                  class="py-2.5 px-4 text-xs font-bold text-amber-300 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 rounded-xl inline-flex items-center gap-1.5 transition-all">
            <span>💧</span> <span>Send Watermarked</span>
          </button>

          <button type="submit" name="dispatch_type" value="final"
                  class="btn-gold py-2.5 px-5 text-xs font-black shadow-glow inline-flex items-center gap-1.5 transition-all">
            <span>✨</span> <span>Send Final (Clean)</span>
          </button>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- Hidden Quick Pay Form -->
<form id="sdm_quick_pay_form" method="POST" action="/admin/supervisor-dashboard.php" class="hidden">
  <?= csrfField() ?>
  <input type="hidden" name="mark_order_paid" value="1">
  <input type="hidden" name="order_id" id="sdm_quick_pay_order_id" value="">
  <input type="hidden" name="paid_amount" id="sdm_quick_pay_amount" value="">
</form>

<!-- BULK CLEAR ALL PIPELINE MODAL -->
<div id="bulkClearPipelineModal" class="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 sm:p-8 max-w-md w-full border border-red-500/50 shadow-2xl space-y-5">
    <div class="flex items-center gap-3.5 border-b border-dark-border pb-4">
      <div class="w-12 h-12 rounded-2xl bg-red-600/20 border border-red-500 flex items-center justify-center text-red-400 text-2xl font-black">
        &#127353;
      </div>
      <div>
        <h3 class="text-lg font-black text-red-400">Clear All SaaS Pipeline Orders</h3>
        <p class="text-xs text-gray-400">Permanently wipe all orders from production queue.</p>
      </div>
    </div>
    <div class="p-4 rounded-2xl bg-red-950/40 border border-red-800/60 text-xs text-red-200 space-y-2">
      <p><strong>Warning:</strong> This will permanently delete ALL <?= count($allOrders) ?> orders from the Supervisor Production Pipeline.</p>
      <p class="text-gray-400">Client portal orders remain in separate storage.</p>
    </div>
    <form method="POST" action="/admin/supervisor-dashboard.php" class="flex items-center justify-end gap-3 pt-2">
      <?= csrfField() ?>
      <input type="hidden" name="bulk_clear_saas_pipeline" value="1">
      <button type="button" onclick="closeBulkClearPipelineModal()" class="btn-ghost py-2.5 px-4 text-xs font-bold">Cancel</button>
      <button type="submit" class="py-2.5 px-6 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs shadow-lg transition-all flex items-center gap-1.5">
        <span>&#127353; Yes, Clear All Pipeline</span>
      </button>
    </form>
  </div>
</div>

<!-- CUSTOM GOD-MODE DELETE ORDER MODAL -->
<div id="deleteOrderGodModal" class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 max-w-md w-full border border-red-500/50 shadow-2xl space-y-4">
    <div class="flex items-center gap-3">
      <div class="w-10 h-10 rounded-2xl bg-red-600/20 border border-red-500 flex items-center justify-center text-red-400 text-xl font-black">
        🗑️
      </div>
      <div>
        <h3 class="text-base font-black text-white">Delete Order from Production?</h3>
        <p class="text-xs text-gray-400">Permanently purge this order from all queues.</p>
      </div>
    </div>

    <div class="p-3.5 rounded-2xl bg-red-950/30 border border-red-800/50 text-xs text-red-200">
      Order: <strong id="deleteOrderDisplayTitle" class="text-white"></strong> (<span id="deleteOrderDisplayId" class="font-mono text-gold font-bold"></span>)
    </div>

    <div class="flex items-center justify-end gap-3 pt-2">
      <button type="button" onclick="closeDeleteOrderGodModal()" class="btn-ghost py-2.5 px-4 text-xs font-bold">Cancel</button>
      <a id="confirmDeleteOrderGodBtn" href="#" class="py-2.5 px-5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs shadow-lg transition-all inline-flex items-center gap-1.5">
        <span>🗑️ Yes, Delete Order</span>
      </a>
    </div>
  </div>
</div>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
let currentSupCategory = '<?= htmlspecialchars($initialSupervisorCat, ENT_QUOTES) ?>';

function setSupervisorCategory(cat) {
  currentSupCategory = cat;

  document.querySelectorAll('.sup-cat-btn').forEach(btn => {
    btn.className = 'sup-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-transparent text-gray-400 hover:text-white hover:bg-white/5';
    const badge = btn.querySelector('.sup-count-badge');
    if (badge) {
      badge.classList.remove('bg-black/30', 'text-black');
    }
  });

  const activeBtn = document.getElementById('supCatBtn-' + cat);
  if (activeBtn) {
    if (cat === 'pending' || cat === 'due' || cat === 'free_trial') {
      activeBtn.className = 'sup-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-amber-500 text-black shadow-lg shadow-amber-500/20';
    } else if (cat === 'cleared' || cat === 'ready_delivery') {
      activeBtn.className = 'sup-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-emerald-500 text-black shadow-lg shadow-emerald-500/20';
    } else if (cat === 'delivered') {
      activeBtn.className = 'sup-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-purple-500 text-black shadow-lg shadow-purple-500/20';
    } else if (cat === 'live_order' || cat === 'in_production') {
      activeBtn.className = 'sup-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-blue-500 text-white shadow-lg shadow-blue-500/20';
    } else {
      activeBtn.className = 'sup-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-gold text-black shadow-lg shadow-gold/20';
    }
    const badge = activeBtn.querySelector('.sup-count-badge');
    if (badge) {
      badge.classList.add('bg-black/30', 'text-black');
    }
  }

  // Update URL without reload
  const url = new URL(window.location);
  url.searchParams.set('cat', cat);
  window.history.replaceState({}, '', url);

  filterSupervisorOrders();
}

function filterSupervisorOrders() {
  const query = (document.getElementById('supervisorSearchInput')?.value || '').toLowerCase().trim();
  const rows = document.querySelectorAll('#supervisorOrdersTable tbody tr.sup-order-row');
  let visibleCount = 0;

  rows.forEach(row => {
    const wfCat   = row.getAttribute('data-wf-cat') || '';
    const typeCat = row.getAttribute('data-type-cat') || '';
    const payCat  = row.getAttribute('data-pay-cat') || '';
    const text    = row.textContent.toLowerCase();

    let matchesCat = false;
    if (currentSupCategory === 'all') matchesCat = true;
    else if (currentSupCategory === wfCat) matchesCat = true;
    else if (currentSupCategory === typeCat) matchesCat = true;
    else if (currentSupCategory === payCat) matchesCat = true;

    const matchesQuery = !query || text.includes(query);

    if (matchesCat && matchesQuery) {
      row.style.display = '';
      visibleCount++;
    } else {
      row.style.display = 'none';
    }
  });

  const emptyRow = document.getElementById('supervisorEmptyRow');
  if (emptyRow) {
    emptyRow.style.display = (visibleCount === 0) ? '' : 'none';
  }
}

// Initial category filter trigger
if (currentSupCategory !== 'all') {
  setSupervisorCategory(currentSupCategory);
}

function openSupervisorDispatchModal(data) {
  document.getElementById('sdm_order_id').value = data.id || '';
  document.getElementById('sdm_display_id').textContent = '#' + (data.id || '');
  document.getElementById('sdm_display_prop').textContent = data.property_name || 'Property';
  document.getElementById('sdm_display_client').textContent = (data.client_name || 'Client') + (data.client_email ? (' (' + data.client_email + ')') : '');
  document.getElementById('sdm_watermark_url').value = data.watermark_url || '';
  document.getElementById('sdm_delivery_url').value = data.delivery_url || '';
  document.getElementById('sdm_price_amount').value = data.price_amount > 0 ? data.price_amount : '';
  
  const statusEl = document.getElementById('sdm_payment_status');
  if (data.is_trial) {
    statusEl.innerHTML = '<span class="px-2 py-0.5 rounded text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/40">🎁 FREE TRIAL ($0.00)</span>';
  } else if (data.cleared) {
    statusEl.innerHTML = '<span class="px-2 py-0.5 rounded text-[10px] font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">✅ PAID &bull; CLEARED</span>';
  } else {
    statusEl.innerHTML = '<span class="px-2 py-0.5 rounded text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/40">⏳ PAYMENT PENDING ($' + Number(data.price_amount || 0).toFixed(2) + ' USD)</span>';
  }

  const markPaidBtn = document.getElementById('sdm_mark_paid_btn');
  if (markPaidBtn) {
    if (!data.cleared && !data.is_trial) {
      markPaidBtn.style.display = 'inline-flex';
      markPaidBtn.onclick = function() {
        document.getElementById('sdm_quick_pay_order_id').value = data.id || '';
        document.getElementById('sdm_quick_pay_amount').value = data.price_amount || 0;
        document.getElementById('sdm_quick_pay_form').submit();
      };
    } else {
      markPaidBtn.style.display = 'none';
    }
  }

  document.getElementById('supervisorDispatchModal').classList.remove('hidden');
}

function closeSupervisorDispatchModal() {
  document.getElementById('supervisorDispatchModal').classList.add('hidden');
}

function openDeleteOrderGodModal(oid, title) {
  document.getElementById('deleteOrderDisplayId').textContent = '#' + oid;
  document.getElementById('deleteOrderDisplayTitle').textContent = title;
  document.getElementById('confirmDeleteOrderGodBtn').href = '/admin/supervisor-dashboard.php?delete_order_id=' + encodeURIComponent(oid);
  document.getElementById('deleteOrderGodModal').classList.remove('hidden');
}
function closeDeleteOrderGodModal() {
  document.getElementById('deleteOrderGodModal').classList.add('hidden');
}
function openBulkClearPipelineModal() {
  document.getElementById('bulkClearPipelineModal').classList.remove('hidden');
}
function closeBulkClearPipelineModal() {
  document.getElementById('bulkClearPipelineModal').classList.add('hidden');
}
</script>

</body>
</html>
