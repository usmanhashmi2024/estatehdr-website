<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/saas-db.php';
requireAdmin();

$currentAdmin = currentAdminUser();
$adminRoles   = getAdminRoles();
$isOwner      = in_array('owner', $adminRoles) || in_array('super_admin', $adminRoles);
$isHR         = in_array('hr', $adminRoles) || $isOwner;

if (!$isHR) {
    setFlash('error', 'Access Denied: Restricted to Human Resources Department.');
    header("Location: /admin/");
    exit;
}

$empId = trim($_GET['id'] ?? '');
$docType = trim($_GET['type'] ?? 'salary_slip'); // 'salary_slip' | 'bank_letter' | 'nda' | 'offer_letter' | 'termination'

$employees = getSaaSEmployees();
$employee = null;
foreach ($employees as $e) {
    if (($e['id'] ?? '') === $empId || ($e['user_id'] ?? '') === $empId) {
        $employee = $e;
        break;
    }
}

if (!$employee) {
    // Default to first employee if none selected
    $employee = !empty($employees) ? $employees[0] : [
        'id' => 'EMP-001', 'name' => 'John Retoucher', 'role' => 'Photo Editor', 'email' => 'editor@estatehdr.com', 'phone' => '+44 770 606 8176', 'basic_salary' => 650, 'rent_allowance' => 80, 'other_allowances' => 40, 'net_salary' => 770
    ];
}

$basicSalary     = (float)($employee['basic_salary'] ?? 650.0);
$rentAllowance   = (float)($employee['rent_allowance'] ?? 80.0);
$otherAllowances = (float)($employee['other_allowances'] ?? 40.0);
$bonus           = (float)($employee['bonus'] ?? 50.0);
$deductions      = (float)($employee['deductions'] ?? 0.0);
$netSalary       = (float)($employee['net_salary'] ?? ($basicSalary + $rentAllowance + $otherAllowances + $bonus - $deductions));
$docDate         = date('F j, Y');
$refNumber       = 'REF: EH-HR-' . date('Ym') . '-' . strtoupper(substr(md5($employee['id'] ?? 'EMP'), 0, 6));
$monthName       = date('F Y');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= strtoupper(str_replace('_', ' ', $docType)) ?> — <?= htmlspecialchars($employee['name']) ?> — Estate HDR HR</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&family=Inter:wght@400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<style nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
/* Document Sheet Styling */
.doc-sheet {
  position: relative;
  background: #ffffff;
  color: #111827;
  font-family: 'Inter', sans-serif;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
  min-height: 1050px;
}

/* 15% Opacity Watermark */
.doc-watermark {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%) rotate(-25deg);
  opacity: 0.07;
  pointer-events: none;
  z-index: 1;
  width: 550px;
  text-align: center;
  user-select: none;
}

.doc-content {
  position: relative;
  z-index: 10;
}

@media print {
  /* 1. Hide Website Headers, Navbars, Buttons and Controls */
  header, nav, footer, .no-print, .no-print * {
    display: none !important;
    visibility: hidden !important;
    height: 0 !important;
    max-height: 0 !important;
    margin: 0 !important;
    padding: 0 !important;
    border: none !important;
    overflow: hidden !important;
  }
  
  /* 2. Reset Body & Page Container */
  html, body {
    background: #ffffff !important;
    color: #111827 !important;
    margin: 0 !important;
    padding: 0 !important;
    width: 100% !important;
    height: auto !important;
    min-height: auto !important;
    font-size: 12pt !important;
  }
  
  main {
    display: block !important;
    visibility: visible !important;
    padding: 0 !important;
    margin: 0 !important;
    max-width: 100% !important;
    width: 100% !important;
  }
  
  .grid {
    display: block !important;
  }
  
  .lg\:col-span-4 {
    display: none !important;
  }
  
  .lg\:col-span-8 {
    display: block !important;
    visibility: visible !important;
    width: 100% !important;
    max-width: 100% !important;
    padding: 0 !important;
    margin: 0 !important;
  }
  
  /* 3. Pristine A4 Document Sheet */
  .doc-sheet {
    display: block !important;
    visibility: visible !important;
    box-shadow: none !important;
    border: none !important;
    margin: 0 auto !important;
    padding: 8mm 12mm !important;
    width: 100% !important;
    max-width: 100% !important;
    min-height: auto !important;
    background: #ffffff !important;
    color: #111827 !important;
    page-break-inside: avoid !important;
    break-inside: avoid !important;
  }
  
  .doc-content {
    display: block !important;
    visibility: visible !important;
  }

  .doc-watermark {
    opacity: 0.12 !important;
    display: flex !important;
    visibility: visible !important;
  }

  @page {
    margin: 8mm 10mm 8mm 10mm;
    size: A4 portrait;
  }
}
</style>
</head>
<body class="bg-[#0A0A0F] min-h-screen py-8 text-white">

  <!-- ── TOP TOOLBAR & SWITCHER (NO PRINT) ────────────────────────── -->
  <div class="max-w-[900px] mx-auto mb-6 px-4 no-print space-y-4">
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
      <a href="/admin/hr-dashboard.php" class="inline-flex items-center gap-2 text-xs font-bold text-gray-300 hover:text-gold bg-[#111118] px-4 py-2 rounded-xl border border-[#1E1E2E]">
        <span>←</span> <span>Back to HR Portal</span>
      </a>

      <div class="flex items-center gap-3">
        <button onclick="window.print()" class="bg-gradient-to-r from-amber-500 to-gold text-dark font-black px-6 py-2.5 rounded-xl text-xs shadow-lg inline-flex items-center gap-2 hover:opacity-90">
          <span>🖨️</span> <span>Print / Save as PDF Document</span>
        </button>
      </div>
    </div>

    <!-- Document Type Switcher Tabs -->
    <div class="flex flex-wrap gap-2 p-2 bg-[#111118] rounded-2xl border border-[#1E1E2E] text-xs font-bold">
      <a href="?id=<?= urlencode($employee['id']) ?>&type=salary_slip" class="px-3.5 py-2 rounded-xl transition-all <?= $docType === 'salary_slip' ? 'bg-gold text-dark font-black' : 'text-gray-300 hover:text-white' ?>">
        💰 Monthly Salary Slip
      </a>
      <a href="?id=<?= urlencode($employee['id']) ?>&type=bank_letter" class="px-3.5 py-2 rounded-xl transition-all <?= $docType === 'bank_letter' ? 'bg-gold text-dark font-black' : 'text-gray-300 hover:text-white' ?>">
        🏦 Bank Account Letter
      </a>
      <a href="?id=<?= urlencode($employee['id']) ?>&type=offer_letter" class="px-3.5 py-2 rounded-xl transition-all <?= $docType === 'offer_letter' ? 'bg-gold text-dark font-black' : 'text-gray-300 hover:text-white' ?>">
        ✉️ Employment Offer Letter
      </a>
      <a href="?id=<?= urlencode($employee['id']) ?>&type=nda" class="px-3.5 py-2 rounded-xl transition-all <?= $docType === 'nda' ? 'bg-gold text-dark font-black' : 'text-gray-300 hover:text-white' ?>">
        📜 Confidentiality NDA
      </a>
      <a href="?id=<?= urlencode($employee['id']) ?>&type=termination" class="px-3.5 py-2 rounded-xl transition-all <?= $docType === 'termination' ? 'bg-red-600 text-white font-black' : 'text-gray-300 hover:text-white' ?>">
        ⚠️ Termination Letter
      </a>
    </div>
  </div>

  <!-- ── OFFICIAL DOCUMENT SHEET (A4) ──────────────────────────────── -->
  <div class="max-w-[850px] mx-auto doc-sheet rounded-3xl p-10 sm:p-14 overflow-hidden border border-gray-200">
    
    <!-- 15% OPACITY ESTATE HDR WATERMARK -->
    <div class="doc-watermark flex flex-col items-center justify-center">
      <img src="/assets/images/Black.png" alt="Estate HDR" class="w-60 sm:w-64 h-auto object-contain mx-auto mb-2 opacity-90">
      <div class="text-xs font-mono tracking-widest text-black font-black uppercase">Official Verified Corporate Document</div>
    </div>

    <div class="doc-content space-y-8">
      
      <!-- ── 1. CORPORATE LETTERHEAD HEADER ────────────────────────── -->
      <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b-2 border-[#C9A84C] pb-6">
        <div>
          <div class="flex items-center gap-3">
            <img src="/assets/images/Black.png" alt="Estate HDR" class="h-9 sm:h-10 w-auto max-w-[190px] object-contain">
            <span class="text-[10px] uppercase font-black tracking-widest px-2.5 py-1 rounded bg-amber-100 text-amber-900 border border-amber-300">
              Corporate HR Division
            </span>
          </div>
          <p class="text-[11px] text-gray-800 font-mono font-bold mt-1">Premium Real Estate Photo Retouching &amp; Virtual Media SaaS</p>
          <p class="text-[10px] text-gray-500 font-mono">UK Reg: EH-789021 • London &bull; Worldwide Delivery Hubs</p>
        </div>

        <div class="text-right text-[11px] font-mono text-gray-600 space-y-0.5">
          <div class="font-bold text-gray-900"><?= $refNumber ?></div>
          <div>Date: <strong class="text-gray-900"><?= $docDate ?></strong></div>
          <div>Contact: <span class="text-gray-900">hr@estatehdr.com</span></div>
          <div>Portal: <span class="text-gray-900">www.estatehdr.com</span></div>
        </div>
      </div>

      <!-- ══════════════════════════════════════════════════════════════ -->
      <!-- ── DOCUMENT 1: MONTHLY SALARY SLIP ────────────────────────── -->
      <!-- ══════════════════════════════════════════════════════════════ -->
      <?php if ($docType === 'salary_slip'): ?>
      
      <div class="text-center space-y-1">
        <h2 class="text-xl font-black tracking-wide text-gray-900 uppercase">OFFICIAL MONTHLY SALARY PAYSLIP</h2>
        <p class="text-xs font-mono text-gray-600">Pay Period: <strong><?= $monthName ?></strong> &bull; Currency: <strong>USD ($)</strong></p>
      </div>

      <!-- Employee Info Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-gray-50 border border-gray-200 text-xs font-mono">
        <div><span class="text-gray-500 block">Employee ID:</span><strong class="text-gray-900"><?= htmlspecialchars($employee['id']) ?></strong></div>
        <div><span class="text-gray-500 block">Employee Name:</span><strong class="text-gray-900"><?= htmlspecialchars($employee['name']) ?></strong></div>
        <div><span class="text-gray-500 block">Designation:</span><strong class="text-gray-900"><?= htmlspecialchars($employee['role']) ?></strong></div>
        <div><span class="text-gray-500 block">Shift / Department:</span><strong class="text-gray-900"><?= htmlspecialchars($employee['department'] ?? 'Production') ?></strong></div>
      </div>

      <!-- Earnings & Deductions Table -->
      <div class="overflow-hidden rounded-xl border border-gray-200">
        <table class="w-full text-xs text-left">
          <thead class="bg-gray-100 text-gray-700 font-bold border-b border-gray-200">
            <tr>
              <th class="p-3">EARNINGS &amp; ALLOWANCES</th>
              <th class="p-3 text-right">AMOUNT ($)</th>
              <th class="p-3 border-l border-gray-200">DEDUCTIONS &amp; TAXES</th>
              <th class="p-3 text-right">AMOUNT ($)</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-100 font-mono">
            <tr>
              <td class="p-3">Basic Salary</td>
              <td class="p-3 text-right font-bold">$<?= number_format($basicSalary, 2) ?></td>
              <td class="p-3 border-l border-gray-200">Income Tax / Levies</td>
              <td class="p-3 text-right text-red-600">$0.00</td>
            </tr>
            <tr>
              <td class="p-3">House Rent Allowance</td>
              <td class="p-3 text-right font-bold">$<?= number_format($rentAllowance, 2) ?></td>
              <td class="p-3 border-l border-gray-200">Fine / Policy Deductions</td>
              <td class="p-3 text-right text-red-600">$<?= number_format($deductions, 2) ?></td>
            </tr>
            <tr>
              <td class="p-3">Utilities &amp; Work Allowance</td>
              <td class="p-3 text-right font-bold">$<?= number_format($otherAllowances, 2) ?></td>
              <td class="p-3 border-l border-gray-200">Other Deductions</td>
              <td class="p-3 text-right text-red-600">$0.00</td>
            </tr>
            <tr>
              <td class="p-3">Performance Bonus &amp; Quality Incentive</td>
              <td class="p-3 text-right font-bold text-emerald-700">$<?= number_format($bonus, 2) ?></td>
              <td class="p-3 border-l border-gray-200">Advance Salary Adjustment</td>
              <td class="p-3 text-right text-red-600">$0.00</td>
            </tr>
          </tbody>
          <tfoot class="bg-gray-50 border-t-2 border-gray-300 font-bold">
            <tr>
              <td class="p-3 text-gray-800">TOTAL GROSS EARNINGS:</td>
              <td class="p-3 text-right text-gray-900 font-mono">$<?= number_format($basicSalary + $rentAllowance + $otherAllowances + $bonus, 2) ?></td>
              <td class="p-3 border-l border-gray-200 text-gray-800">TOTAL DEDUCTIONS:</td>
              <td class="p-3 text-right text-red-600 font-mono">$<?= number_format($deductions, 2) ?></td>
            </tr>
          </tfoot>
        </table>
      </div>

      <!-- Net Payable Summary -->
      <div class="p-5 rounded-2xl bg-amber-50/70 border-2 border-[#C9A84C] flex items-center justify-between">
        <div>
          <span class="text-xs text-amber-900 font-bold uppercase tracking-wider">TOTAL NET PAYABLE SALARY:</span>
          <p class="text-[11px] text-gray-600 font-mono mt-0.5">Dispatched directly to verified corporate salary account.</p>
        </div>
        <div class="text-right">
          <div class="text-2xl font-black text-gray-900 font-mono">$<?= number_format($netSalary, 2) ?> USD</div>
          <span class="text-[10px] font-bold text-emerald-800 uppercase px-2 py-0.5 rounded bg-emerald-100 border border-emerald-300">
            ✓ Disbursed &amp; Approved
          </span>
        </div>
      </div>

      <!-- ══════════════════════════════════════════════════════════════ -->
      <!-- ── DOCUMENT 2: BANK ACCOUNT OPENING LETTER ────────────────── -->
      <!-- ══════════════════════════════════════════════════════════════ -->
      <?php elseif ($docType === 'bank_letter'): ?>

      <div class="space-y-4 text-xs leading-relaxed text-gray-800">
        <div class="space-y-1">
          <p class="font-bold text-gray-900">To,</p>
          <p class="font-bold text-gray-900">The Branch Manager,</p>
          <p class="text-gray-700">Authorized Banking Partner / Branch,</p>
        </div>

        <div class="pt-2 border-b border-gray-300 pb-2">
          <h3 class="text-sm font-black text-gray-900 uppercase">SUBJECT: REQUEST FOR OPENING CORPORATE SALARY ACCOUNT</h3>
        </div>

        <p>Dear Sir / Madam,</p>

        <p>
          This is to officially confirm and certify that <strong>Mr./Ms. <?= htmlspecialchars($employee['name']) ?></strong> 
          (Employee ID: <strong><?= htmlspecialchars($employee['id']) ?></strong>, Contact: <strong><?= htmlspecialchars($employee['phone'] ?? 'N/A') ?></strong>)
          is a bona fide, full-time permanent employee of <strong>Estate HDR</strong>, serving in the capacity of 
          <strong><?= htmlspecialchars($employee['role']) ?></strong> in our <strong><?= htmlspecialchars($employee['department'] ?? 'Production') ?> Department</strong>.
        </p>

        <div class="p-4 rounded-xl bg-gray-50 border border-gray-200 space-y-1 font-mono text-[11px]">
          <div>• <strong>Employee Full Name:</strong> <?= htmlspecialchars($employee['name']) ?></div>
          <div>• <strong>Designation:</strong> <?= htmlspecialchars($employee['role']) ?></div>
          <div>• <strong>Employee ID:</strong> <?= htmlspecialchars($employee['id']) ?></div>
          <div>• <strong>Official Email:</strong> <?= htmlspecialchars($employee['email']) ?></div>
          <div>• <strong>Monthly Net Compensation:</strong> $<?= number_format($netSalary, 2) ?> USD</div>
          <div>• <strong>Employment Status:</strong> Active / Full-Time</div>
        </div>

        <p>
          We request your esteemed financial institution to facilitate the opening of an individual <strong>Corporate Salary Account</strong> 
          for the aforementioned employee at your earliest convenience to enable monthly automated salary disbursements.
        </p>

        <p>
          Estate HDR takes full responsibility for routing the regular monthly salary remittances directly into this account. 
          Should you require any further validation or official documentation, please do not hesitate to contact our HR Department at <strong>hr@estatehdr.com</strong>.
        </p>

        <p class="pt-2">Thank you for your valued cooperation.</p>
      </div>

      <!-- ══════════════════════════════════════════════════════════════ -->
      <!-- ── DOCUMENT 3: EMPLOYMENT OFFER LETTER ────────────────────── -->
      <!-- ══════════════════════════════════════════════════════════════ -->
      <?php elseif ($docType === 'offer_letter'): ?>

      <div class="space-y-4 text-xs leading-relaxed text-gray-800">
        <div>
          <p class="font-bold text-gray-900">To: <strong><?= htmlspecialchars($employee['name']) ?></strong></p>
          <p class="text-gray-600 font-mono"><?= htmlspecialchars($employee['email']) ?> &bull; <?= htmlspecialchars($employee['phone'] ?? '') ?></p>
        </div>

        <div class="border-b border-gray-300 pb-2">
          <h3 class="text-sm font-black text-gray-900 uppercase">OFFICIAL APPOINTMENT &amp; EMPLOYMENT OFFER LETTER</h3>
        </div>

        <p>Dear <strong><?= htmlspecialchars($employee['name']) ?></strong>,</p>

        <p>
          On behalf of <strong>Estate HDR</strong>, we are pleased to extend this formal offer of employment for the position of 
          <strong><?= htmlspecialchars($employee['role']) ?></strong>. We were thoroughly impressed with your technical skills, portfolio demonstration, and passion for real estate image excellence.
        </p>

        <div class="p-4 rounded-xl bg-gray-50 border border-gray-200 space-y-2 font-mono text-[11px]">
          <div>• <strong>Designation:</strong> <?= htmlspecialchars($employee['role']) ?></div>
          <div>• <strong>Department:</strong> <?= htmlspecialchars($employee['department'] ?? 'Production') ?></div>
          <div>• <strong>Assigned Shift:</strong> <?= htmlspecialchars($employee['shift'] ?? 'Morning (09:00 AM - 06:00 PM)') ?></div>
          <div>• <strong>Monthly Basic Salary:</strong> $<?= number_format($basicSalary, 2) ?> USD</div>
          <div>• <strong>Allowances (Rent &amp; Utilities):</strong> $<?= number_format($rentAllowance + $otherAllowances, 2) ?> USD</div>
          <div>• <strong>Total Monthly Net Compensation:</strong> $<?= number_format($netSalary, 2) ?> USD</div>
          <div>• <strong>Probation Period:</strong> 3 Months (Standard Evaluation)</div>
        </div>

        <p>
          In this role, you will be expected to adhere to the company's Standard Operating Procedures (SOP), maintain strict client privacy, 
          and deliver high-caliber real estate visual content.
        </p>

        <p>
          Please sign and return the duplicate copy of this letter along with the Non-Disclosure Agreement (NDA) to confirm your formal acceptance.
        </p>
      </div>

      <!-- ══════════════════════════════════════════════════════════════ -->
      <!-- ── DOCUMENT 4: NON-DISCLOSURE AGREEMENT (NDA) ─────────────── -->
      <!-- ══════════════════════════════════════════════════════════════ -->
      <?php elseif ($docType === 'nda'): ?>

      <div class="space-y-4 text-xs leading-relaxed text-gray-800">
        <div class="text-center border-b border-gray-300 pb-2">
          <h3 class="text-sm font-black text-gray-900 uppercase">EMPLOYEE CONFIDENTIALITY &amp; NON-DISCLOSURE AGREEMENT (NDA)</h3>
          <p class="text-[10px] text-gray-500 font-mono">Strict Client Privacy, Raw Media &amp; Proprietary Algorithms Protection</p>
        </div>

        <p>
          This Agreement is entered into on this day <strong><?= $docDate ?></strong>, by and between <strong>Estate HDR</strong> ("Company") 
          and <strong><?= htmlspecialchars($employee['name']) ?></strong> (Employee ID: <strong><?= htmlspecialchars($employee['id']) ?></strong>, "Recipient").
        </p>

        <div class="space-y-3">
          <div>
            <strong class="text-gray-900">1. Definition of Confidential Information:</strong>
            <p class="text-gray-700 mt-0.5">
              Includes but is not limited to client raw unedited property photographs, property addresses, client pricing schedules, 
              internal editing actions/presets, client contact information, and proprietary production workflows.
            </p>
          </div>

          <div>
            <strong class="text-gray-900">2. Privacy Shield &amp; Non-Circumvention:</strong>
            <p class="text-gray-700 mt-0.5">
              The Recipient agrees never to contact, solicit, or bypass Estate HDR clients directly. All client data must remain strictly 
              within the encrypted Estate HDR SaaS portal.
            </p>
          </div>

          <div>
            <strong class="text-gray-900">3. Media Exclusivity:</strong>
            <p class="text-gray-700 mt-0.5">
              Raw and edited photos processed by the Recipient remain the exclusive intellectual property of the Company and its licensed real estate clients. 
              No unauthorized public posting, sharing, or distribution is permitted without written authorization.
            </p>
          </div>

          <div>
            <strong class="text-gray-900">4. Legal Remedies &amp; Enforcement:</strong>
            <p class="text-gray-700 mt-0.5">
              Breach of this Agreement will result in immediate termination, forfeiture of dues, and appropriate legal action under applicable corporate jurisdiction.
            </p>
          </div>
        </div>
      </div>

      <!-- ══════════════════════════════════════════════════════════════ -->
      <!-- ── DOCUMENT 5: EMPLOYMENT TERMINATION / RELIEVING LETTER ──── -->
      <!-- ══════════════════════════════════════════════════════════════ -->
      <?php elseif ($docType === 'termination'): ?>

      <div class="space-y-4 text-xs leading-relaxed text-gray-800">
        <div>
          <p class="font-bold text-gray-900">To: <strong><?= htmlspecialchars($employee['name']) ?></strong></p>
          <p class="text-gray-600 font-mono">Employee ID: <?= htmlspecialchars($employee['id']) ?> &bull; <?= htmlspecialchars($employee['email']) ?></p>
        </div>

        <div class="border-b border-red-300 pb-2">
          <h3 class="text-sm font-black text-red-700 uppercase">OFFICIAL EMPLOYMENT TERMINATION / RELIEVING NOTICE</h3>
        </div>

        <p>Dear <strong><?= htmlspecialchars($employee['name']) ?></strong>,</p>

        <p>
          This letter serves as formal notification that your employment with <strong>Estate HDR</strong> as 
          <strong><?= htmlspecialchars($employee['role']) ?></strong> is being officially concluded effective <strong><?= $docDate ?></strong>.
        </p>

        <div class="p-4 rounded-xl bg-red-50 border border-red-200 space-y-2 font-mono text-[11px]">
          <div>• <strong>Last Working Day:</strong> <?= $docDate ?></div>
          <div>• <strong>Reason for Separation:</strong> Operational Realignment / Performance Evaluation</div>
          <div>• <strong>Full &amp; Final Settlement:</strong> Will be processed within standard 14 business days</div>
          <div>• <strong>Confidentiality Obligations:</strong> NDA terms remain perpetually binding post-employment</div>
        </div>

        <p>
          You are requested to return all company assets, credentials, and software licenses to the IT &amp; HR Department immediately. 
          We wish you success in your future endeavors.
        </p>
      </div>

      <?php endif; ?>

      <!-- ── 5. OFFICIAL SIGNATURES & CORPORATE STAMP ───────────────── -->
      <div class="pt-10 border-t-2 border-gray-200 grid grid-cols-3 gap-6 text-center text-xs font-mono">
        
        <!-- HR Signature -->
        <div class="space-y-2">
          <div class="h-14 flex items-end justify-center">
            <span class="font-serif italic text-base text-gray-800 font-bold border-b border-gray-400 pb-1 px-4">
              Sarah Jenkins
            </span>
          </div>
          <div class="font-bold text-gray-900">Head of Human Resources</div>
          <div class="text-[10px] text-gray-500">Estate HDR HR Division</div>
        </div>

        <!-- Official Seal -->
        <div class="flex flex-col items-center justify-center">
          <div class="w-20 h-20 rounded-full border-2 border-dashed border-[#C9A84C] flex flex-col items-center justify-center p-1 text-center bg-amber-50/50">
            <span class="text-[8px] font-black text-[#C9A84C] uppercase tracking-tighter">ESTATE HDR</span>
            <span class="text-[7px] text-gray-600 font-bold">OFFICIAL SEAL</span>
            <span class="text-[6px] text-gray-400">VERIFIED</span>
          </div>
          <span class="text-[9px] text-gray-400 mt-1">Official Corporate Stamp</span>
        </div>

        <!-- Employee Acknowledgment -->
        <div class="space-y-2">
          <div class="h-14 flex items-end justify-center">
            <span class="border-b border-gray-400 w-32 inline-block"></span>
          </div>
          <div class="font-bold text-gray-900"><?= htmlspecialchars($employee['name']) ?></div>
          <div class="text-[10px] text-gray-500">Employee Signature &amp; Date</div>
        </div>

      </div>

    </div>
  </div>

</body>
</html>
