<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireManagerOrAdmin();

// Handle Lead Delivery POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deliver_lead'])) {
    verifyCsrf();
    $leadId = trim($_POST['lead_id'] ?? '');
    $finalLink = trim($_POST['final_cloud_link'] ?? '');
    $clientEmail = trim($_POST['client_email'] ?? '');
    $clientName = trim($_POST['client_name'] ?? '');
    $sendEmail = isset($_POST['send_email']);

    if (!empty($leadId) && !empty($finalLink)) {
        updateLeadDelivery($leadId, $finalLink);
        
        if ($sendEmail && filter_var($clientEmail, FILTER_VALIDATE_EMAIL)) {
            $subject = "Your Free Trial Photos Are Ready! — Estate HDR";
            $body = "Hi {$clientName},\n\nYour edited real estate sample photos have been processed by our retouching team.\n\nDownload Link: {$finalLink}\n\nIf you have any feedback or wish to place full agency orders, feel free to reply to this email or chat with us on WhatsApp.\n\nBest Regards,\nEstate HDR Production Team";
            @mail($clientEmail, $subject, $body, "From: info@estatehdr.com\r\nReply-To: info@estatehdr.com");
        }

        setFlash('success', 'Final output link saved and sent to client successfully!');
        header('Location: /admin/leads.php');
        exit;
    }
}

$leads = getLeads();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Free Trial Leads Fulfillment — Estate HDR Admin</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8">
  <!-- Back Navigation -->
  <div class="mb-4">
    <a href="/admin/" class="btn-ghost py-2 px-4 text-xs font-bold inline-flex items-center gap-2 border border-[#1E1E2E] hover:border-gold rounded-xl">
      <span>←</span> <span>Back to Dashboard</span>
    </a>
  </div>
  <?= renderFlash() ?>
  <?= renderFlash() ?>

  <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
    <div>
      <div class="section-tag mb-1">Prospect Inquiries &amp; Trial Submissions</div>
      <h1 class="text-2xl sm:text-3xl font-black text-white">FREE TRIAL LEADS FULFILLMENT</h1>
      <p class="text-gray-400 text-xs mt-1">Review raw bracket submissions from non-registered prospects, upload final finished photos, and dispatch directly via Email &amp; WhatsApp.</p>
    </div>
  </div>

  <!-- Leads Table -->
  <div class="glass-card rounded-2xl overflow-hidden border border-dark-border shadow-2xl">
    <div class="p-4 border-b border-dark-border flex items-center justify-between">
      <h3 class="text-xs font-bold text-white uppercase tracking-wider">INCOMING TRIAL QUEUE</h3>
      <span class="text-xs text-gray-400 font-mono"><?= count($leads) ?> total inquiries</span>
    </div>

    <div class="overflow-x-auto">
      <table class="dashboard-table w-full text-left text-xs">
        <thead>
          <tr>
            <th>CLIENT NAME</th>
            <th>CONTACT DETAILS</th>
            <th>SERVICE REQUESTED</th>
            <th>RAW INPUT LINK</th>
            <th>STATUS</th>
            <th class="text-right">DELIVER OUTPUT</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($leads)): ?>
            <tr><td colspan="6" class="p-8 text-center text-gray-500">No trial leads submitted yet.</td></tr>
          <?php else: ?>
            <?php foreach ($leads as $lead): 
              $isDelivered = ($lead['status'] ?? '') === 'delivered';
            ?>
            <tr class="hover:bg-white/[0.02]">
              <td>
                <div class="font-bold text-white text-sm"><?= htmlspecialchars($lead['name']) ?></div>
                <div class="text-xs text-gray-500 font-mono"><?= date('M j, Y h:i A', strtotime($lead['created_at'])) ?></div>
              </td>
              <td>
                <div class="text-gold font-mono"><?= htmlspecialchars($lead['email']) ?></div>
                <div class="text-gray-400 font-mono text-xs"><?= htmlspecialchars($lead['phone'] ?? '—') ?></div>
              </td>
              <td>
                <span class="px-2.5 py-1 rounded-md bg-dark border border-dark-border font-semibold text-gray-300">
                  <?= htmlspecialchars($lead['service'] ?? 'General Inquiry') ?>
                </span>
              </td>
              <td>
                <?php if (!empty($lead['sample_cloud_link'])): ?>
                  <a href="<?= htmlspecialchars($lead['sample_cloud_link']) ?>" target="_blank" class="btn-ghost py-1 px-2.5 text-xs text-emerald-400 border-emerald-500/30 hover:border-emerald-400 inline-flex items-center gap-1">
                    <span>⬇ Raw Photos</span> ↗
                  </a>
                <?php else: ?>
                  <span class="text-gray-500 text-xs">No cloud link</span>
                <?php endif; ?>
              </td>
              <td>
                <span class="badge <?= $isDelivered ? 'badge-completed' : 'badge-pending' ?>">
                  <?= $isDelivered ? '✓ Delivered' : '⏳ Pending' ?>
                </span>
              </td>
              <td class="text-right">
                <button onclick='openDeliverModal(<?= json_encode($lead) ?>)' class="btn-gold py-1.5 px-3 text-xs font-bold shadow-glow inline-flex items-center gap-1.5">
                  <span>🚀</span> <span>Deliver Final Output</span>
                </button>
              </td>
            </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</main>

<!-- Delivery Action Modal (Email + WhatsApp) -->
<div id="deliverModal" class="hidden fixed inset-0 z-50 bg-dark/80 backdrop-blur-md flex items-center justify-center p-4">
  <div class="glass-card rounded-2xl p-6 sm:p-8 max-w-lg w-full border border-gold/40 shadow-2xl space-y-5">
    <div class="flex items-center justify-between border-b border-dark-border pb-3">
      <h3 class="text-lg font-bold text-white flex items-center gap-2">
        <span>🚀</span> <span>Deliver Final Trial Outputs</span>
      </h3>
      <button onclick="closeDeliverModal()" class="text-gray-400 hover:text-white text-lg">&times;</button>
    </div>

    <form method="POST" id="deliverForm" class="space-y-4">
      <?= csrfField() ?>
      <input type="hidden" name="deliver_lead" value="1">
      <input type="hidden" id="modalLeadId" name="lead_id" value="">
      <input type="hidden" id="modalClientEmail" name="client_email" value="">
      <input type="hidden" id="modalClientName" name="client_name" value="">
      <input type="hidden" id="modalClientPhone" name="client_phone" value="">

      <div>
        <label class="form-label text-xs text-gray-300">Client</label>
        <div id="modalClientDisplay" class="text-sm font-bold text-gold font-mono">Craig Westerman (craig@hometrack.net)</div>
      </div>

      <div>
        <label class="form-label text-xs">Final Completed Photos / Video URL <span class="text-red-400">*</span></label>
        <input type="url" id="finalCloudLinkInput" name="final_cloud_link" class="form-input text-xs font-mono" placeholder="https://www.dropbox.com/s/... or WeTransfer link" required>
      </div>

      <div class="pt-2 border-t border-dark-border space-y-3">
        <label class="flex items-center gap-2 text-xs text-gray-300 cursor-pointer">
          <input type="checkbox" name="send_email" value="1" checked class="rounded text-gold">
          <span>📧 Send Formatted Delivery Email to Client</span>
        </label>
      </div>

      <!-- Quick Action Buttons -->
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
        <button type="submit" class="btn-gold py-2.5 text-xs font-bold shadow-glow text-center">
          💾 Save &amp; Dispatch Email
        </button>

        <button type="button" onclick="triggerWhatsAppSend()" class="btn-ghost py-2.5 text-xs font-bold text-emerald-400 border-emerald-500/40 hover:bg-emerald-500/10 text-center flex items-center justify-center gap-2">
          <span>💬 Send via WhatsApp</span> ↗
        </button>
      </div>
    </form>
  </div>
</div>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
let currentLead = null;

function openDeliverModal(lead) {
  currentLead = lead;
  document.getElementById('modalLeadId').value = lead.id;
  document.getElementById('modalClientEmail').value = lead.email;
  document.getElementById('modalClientName').value = lead.name;
  document.getElementById('modalClientPhone').value = lead.phone || '';
  document.getElementById('modalClientDisplay').textContent = `${lead.name} (${lead.email} | ${lead.phone || 'No phone'})`;
  document.getElementById('finalCloudLinkInput').value = lead.final_cloud_link || '';
  document.getElementById('deliverModal').classList.remove('hidden');
}

function closeDeliverModal() {
  document.getElementById('deliverModal').classList.add('hidden');
}

function triggerWhatsAppSend() {
  const link = document.getElementById('finalCloudLinkInput').value.trim();
  if (!link) {
    if (window.EstateDialog) EstateDialog.toast('Please enter the final photos cloud link first!', 'error');
    else alert('Please enter the final photos cloud link first!');
    return;
  }
  const phone = (currentLead.phone || '').replace(/[^0-9]/g, '');
  const msg = encodeURIComponent(`Hi ${currentLead.name}! Your free trial sample photos from Estate HDR are ready for review.\n\nDownload Link: ${link}\n\nLet us know if you need any adjustments!`);
  
  if (phone) {
    window.open(`https://wa.me/${phone}?text=${msg}`, '_blank');
  } else {
    window.open(`https://wa.me/?text=${msg}`, '_blank');
  }
}
</script>
</body>
</html>
