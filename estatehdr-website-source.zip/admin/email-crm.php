<?php
declare(strict_types=1);

/**
 * Estate HDR — Email Automation CRM Master Control Panel
 * Self-Hosted Marketing Automation, Visual Sequences, Lead Capture & Analytics Engine.
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/services/EmailCrmService.php';
require_once __DIR__ . '/../includes/services/EmailVerifierService.php';

use EstateHDR\Services\EmailCrmService;
use EstateHDR\Services\EmailVerifierService;

requireAdmin();
$currentAdmin = currentAdminUser();
$adminRoles = getAdminRoles();

$flashSuccess = '';
$flashError = '';

// Handle Direct CSV Export before rendering HTML
if (isset($_GET['action']) && $_GET['action'] === 'export_csv') {
    $tagFilter = trim($_GET['tag'] ?? '');
    $statusFilter = trim($_GET['status'] ?? '');
    $csv = EmailCrmService::exportContactsCsv($tagFilter, $statusFilter);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="estate_hdr_contacts_' . date('Y-m-d') . '.csv"');
    echo $csv;
    exit;
}

// Handle POST actions
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $action = $_POST['action'] ?? '';

    // 1. Add / Edit Contact
    if ($action === 'save_contact') {
        try {
            $saved = EmailCrmService::saveContact([
                'id' => trim($_POST['contact_id'] ?? ''),
                'email' => trim($_POST['email'] ?? ''),
                'first_name' => trim($_POST['first_name'] ?? ''),
                'last_name' => trim($_POST['last_name'] ?? ''),
                'phone' => trim($_POST['phone'] ?? ''),
                'company' => trim($_POST['company'] ?? ''),
                'status' => trim($_POST['status'] ?? 'subscribed'),
                'tags' => trim($_POST['tags'] ?? ''),
                'score' => (int)($_POST['score'] ?? 50),
                'source' => trim($_POST['source'] ?? 'Admin Panel')
            ]);
            $flashSuccess = "Contact " . htmlspecialchars($saved['email']) . " saved successfully!";
        } catch (Throwable $e) {
            $flashError = "Error saving contact: " . $e->getMessage();
        }
    }

    // 2. Delete Contact
    elseif ($action === 'delete_contact') {
        $contactId = trim($_POST['contact_id'] ?? '');
        if (EmailCrmService::deleteContact($contactId)) {
            $flashSuccess = "Contact removed successfully.";
        } else {
            $flashError = "Failed to remove contact.";
        }
    }

    // 3. Import CSV
    elseif ($action === 'import_csv') {
        $defaultTag = trim($_POST['default_tag'] ?? 'csv_import');
        $csvContent = '';

        if (!empty($_FILES['csv_file']['tmp_name']) && is_uploaded_file($_FILES['csv_file']['tmp_name'])) {
            $csvContent = (string)@file_get_contents($_FILES['csv_file']['tmp_name']);
        } elseif (!empty($_POST['csv_text'])) {
            $csvContent = trim($_POST['csv_text']);
        }

        if (!empty($csvContent)) {
            $res = EmailCrmService::importContactsCsv($csvContent, [$defaultTag]);
            $flashSuccess = "Imported {$res['imported']} contacts successfully! (Skipped {$res['skipped']})";
            if (!empty($res['errors'])) {
                $flashError = "Some warnings occurred: " . implode(', ', array_slice($res['errors'], 0, 3));
            }
        } else {
            $flashError = "Please select a valid CSV file or paste CSV text.";
        }
    }

    // Quick Submit Daily Leads & Enroll in 7-Day Drip
    elseif ($action === 'quick_submit_leads') {
        try {
            $rawLeads = trim($_POST['raw_leads'] ?? '');
            $batchTag = trim($_POST['batch_tag'] ?? ('daily-batch-' . date('Y-m-d')));
            $enrollDrip = !empty($_POST['enroll_in_drip']);
            $launchCampaignId = trim($_POST['launch_campaign_id'] ?? '');

            if (!empty($rawLeads)) {
                $result = EmailCrmService::quickSubmitDailyLeads($rawLeads, $batchTag, $enrollDrip);
                $msg = "Batch processed: {$result['imported']} new lead(s) added, {$result['updated']} updated with tag '#{$result['tag']}'.";
                if ($enrollDrip) {
                    $msg .= " 🚀 Enrolled {$result['drip_enrolled']} contact(s) into 7-Day Full Week Outreach Sequence!";
                }
                if (!empty($launchCampaignId)) {
                    $camp = EmailCrmService::getCampaignById($launchCampaignId);
                    if ($camp) {
                        $camp['target_tag'] = $result['tag'];
                        EmailCrmService::saveCampaign($camp);
                        $sendRes = EmailCrmService::sendCampaignNow($camp['id']);
                        if (!empty($sendRes['success'])) {
                            $msg .= " Dispatched '{$camp['name']}' to {$sendRes['sent']} subscribers!";
                        }
                    }
                }
                $flashSuccess = $msg;
            } else {
                $flashError = "Please paste at least one email address or lead row.";
            }
        } catch (Throwable $e) {
            $flashError = "Error submitting leads: " . $e->getMessage();
        }
    }

    // 4. Save Campaign
    elseif ($action === 'save_campaign') {
        try {
            $targetTag = trim($_POST['target_tag'] ?? 'all');
            
            // Check if quick leads were provided in modal
            $quickLeads = trim($_POST['modal_quick_leads'] ?? '');
            if (!empty($quickLeads)) {
                $batchTag = trim($_POST['modal_quick_tag'] ?? ('batch-' . date('Y-m-d')));
                $enrollDrip = !empty($_POST['modal_enroll_drip']);
                $qRes = EmailCrmService::quickSubmitDailyLeads($quickLeads, $batchTag, $enrollDrip);
                $targetTag = $batchTag;
            }

            $chainedParent = trim($_POST['chained_parent_id'] ?? '');
            $chainedDelay = (int)($_POST['chained_delay_hours'] ?? 0);
            $allowParallel = !empty($_POST['allow_parallel']);

            $status = trim($_POST['status'] ?? 'draft');
            if (!empty($chainedParent) && $status !== 'sent') {
                $status = 'chained';
            }

            $campaignData = [
                'id' => trim($_POST['campaign_id'] ?? ''),
                'name' => trim($_POST['name'] ?? 'Untitled Campaign'),
                'subject' => trim($_POST['subject'] ?? ''),
                'preview_text' => trim($_POST['preview_text'] ?? ''),
                'target_tag' => $targetTag,
                'status' => $status,
                'scheduled_at' => !empty($_POST['scheduled_at']) ? date('Y-m-d H:i:s', strtotime($_POST['scheduled_at'])) : null,
                'chained_parent_id' => $chainedParent,
                'chained_delay_hours' => $chainedDelay,
                'allow_parallel' => $allowParallel,
                'content_html' => $_POST['content_html'] ?? ''
            ];

            $savedCamp = EmailCrmService::saveCampaign($campaignData);

            if (isset($_POST['send_immediately']) && $_POST['send_immediately'] === '1') {
                $sendRes = EmailCrmService::sendCampaignNow($savedCamp['id']);
                if (!empty($sendRes['success'])) {
                    $flashSuccess = "Campaign '{$savedCamp['name']}' dispatched to {$sendRes['sent']} subscribers!";
                } else {
                    $flashError = "Saved draft, but sending failed: " . ($sendRes['error'] ?? 'Unknown error');
                }
            } else {
                $flashSuccess = "Campaign '{$savedCamp['name']}' saved successfully!";
            }
        } catch (Throwable $e) {
            $flashError = "Error saving campaign: " . $e->getMessage();
        }
    }

    // 5. Delete Campaign
    elseif ($action === 'delete_campaign') {
        $campaignId = trim($_POST['campaign_id'] ?? '');
        if (EmailCrmService::deleteCampaign($campaignId)) {
            $flashSuccess = "Campaign deleted.";
        } else {
            $flashError = "Failed to delete campaign.";
        }
    }

    // 6. Send Test Email
    elseif ($action === 'send_test_email') {
        $campaignId = trim($_POST['campaign_id'] ?? '');
        $testEmail = trim($_POST['test_email'] ?? ($currentAdmin['email'] ?? ADMIN_EMAIL));
        $res = EmailCrmService::sendCampaignNow($campaignId, $testEmail);
        if (!empty($res['success'])) {
            $flashSuccess = "Test email successfully delivered to {$testEmail}!";
        } else {
            $flashError = "Test delivery failed: " . ($res['error'] ?? 'Check SMTP credentials');
        }
    }

    // 7. Toggle Automation
    elseif ($action === 'toggle_automation') {
        $autoId = trim($_POST['automation_id'] ?? '');
        $newStatus = EmailCrmService::toggleAutomationStatus($autoId);
        $flashSuccess = "Automation is now " . strtoupper($newStatus ?? 'UPDATED') . ".";
    }

    // 8. Run Automations Cron Queue Now
    elseif ($action === 'run_automations_cron') {
        $cronRes = EmailCrmService::processAutomationQueue();
        $flashSuccess = "Automations processed: {$cronRes['processed_steps']} step(s) executed, {$cronRes['completed_enrollments']} flow(s) completed!";
    }

    // 9. Save Form
    elseif ($action === 'save_form') {
        EmailCrmService::saveForm([
            'id' => trim($_POST['form_id'] ?? ''),
            'name' => trim($_POST['name'] ?? 'Website Signup Form'),
            'target_tag' => trim($_POST['target_tag'] ?? 'lead'),
            'redirect_url' => trim($_POST['redirect_url'] ?? '/thank-you')
        ]);
        $flashSuccess = "Signup Form configuration saved.";
    }

    // 10. Delete Form
    elseif ($action === 'delete_form') {
        $formId = trim($_POST['form_id'] ?? '');
        EmailCrmService::deleteForm($formId);
        $flashSuccess = "Form removed.";
    }

    // 11. Save Settings
    elseif ($action === 'save_settings') {
        EmailCrmService::saveSettings([
            'from_name' => trim($_POST['from_name'] ?? 'Estate HDR'),
            'from_email' => trim($_POST['from_email'] ?? 'info@estatehdr.com'),
            'reply_to' => trim($_POST['reply_to'] ?? 'info@estatehdr.com'),
            'delivery_mode' => trim($_POST['delivery_mode'] ?? 'smtp'),
            'daily_limit' => (int)($_POST['daily_limit'] ?? 2000),
            'track_opens' => isset($_POST['track_opens']),
            'track_clicks' => isset($_POST['track_clicks'])
        ]);
        $flashSuccess = "Email Automation CRM settings updated.";
    }

    // 12. Deduplicate Contacts
    elseif ($action === 'deduplicate_contacts') {
        $res = EmailCrmService::deduplicateContacts();
        $flashSuccess = "Deduplication complete! Removed {$res['duplicates_removed']} duplicate records. Total unique contacts: {$res['unique_count']}.";
    }

    // 13. Fresh Start / Reset Data
    elseif ($action === 'fresh_start_reset') {
        $keepContacts = !isset($_POST['wipe_contacts']) || $_POST['wipe_contacts'] !== '1';
        $res = EmailCrmService::freshStartReset($keepContacts);
        $flashSuccess = "CRM Fresh Start complete! " . ($keepContacts ? "All {$res['contacts_preserved']} contacts safely preserved." : "Contact database wiped.");
    }

    // 14. Purge Verified Contacts (Invalid, Risky, Unhealthy)
    elseif ($action === 'purge_verified_contacts') {
        $target = strtolower(trim($_POST['purge_target'] ?? 'invalid'));
        $res = EmailVerifierService::purgeContacts($target);
        $flashSuccess = "Purge complete! Successfully removed " . number_format($res['removed_count']) . " " . htmlspecialchars($res['target']) . " contacts. Total active contacts: " . number_format($res['remaining_count']) . ".";
    }

    // 15. Delete Selected Contacts
    elseif ($action === 'delete_selected_contacts') {
        $idsRaw = $_POST['contact_ids'] ?? [];
        $ids = is_array($idsRaw) ? $idsRaw : array_filter(array_map('trim', explode(',', (string)$idsRaw)));
        $res = EmailVerifierService::purgeContacts('selected', $ids);
        $flashSuccess = "Successfully removed " . number_format($res['removed_count']) . " selected contacts from database.";
    }

    // 16. Master Switch Toggle Action (Enable / Disable Email Automation Engine)
    elseif ($action === 'toggle_engine') {
        $newState = !empty($_POST['engine_state']);
        EmailCrmService::setEngineEnabled($newState);
        $flashSuccess = $newState 
            ? "Email Automation Engine is now ENABLED on server." 
            : "Email Automation Engine is now DISABLED! Website speed boost is active (zero background load).";
    }
}

// Load Data for Views
$activeTab = trim($_GET['tab'] ?? 'dash');
$search = trim($_GET['q'] ?? '');
$tagFilter = trim($_GET['tag'] ?? '');
$statusFilter = trim($_GET['status'] ?? '');
$sortBy = trim($_GET['sort'] ?? 'newest');

$stats = EmailCrmService::getStatsSummary();
$duplicateCount = EmailCrmService::getDuplicateEmailCount();
$vStats = EmailVerifierService::getVerificationStats();
$contacts = EmailCrmService::getContacts($search, $tagFilter, $statusFilter, $sortBy);
$totalContactsCount = count($contacts);

// High-Performance Pagination for large audiences (e.g. 4,400+ listing agents)
$perPage = 50;
$currentPage = max(1, (int)($_GET['p'] ?? 1));
$totalPages = max(1, (int)ceil($totalContactsCount / $perPage));
if ($currentPage > $totalPages) $currentPage = $totalPages;
$pagedContacts = array_slice($contacts, ($currentPage - 1) * $perPage, $perPage);

$allTags = EmailCrmService::getAllTags();
$campaigns = EmailCrmService::getCampaigns();
$automations = EmailCrmService::getAutomations();
$forms = EmailCrmService::getForms();
$topCampaigns = EmailCrmService::getTopCampaigns(5);
$recentEvents = EmailCrmService::getRecentEvents(12);
$settings = EmailCrmService::getSettings();
$emailTemplates = EmailCrmService::getEmailTemplates();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Marketing &amp; Automation CRM — Estate HDR</title>
    <link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="/assets/js/custom-dialogs.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        dark: {
                            DEFAULT: '#0A0A0F',
                            card: '#12131C',
                            surface: '#161724',
                            border: '#1E1E2E'
                        },
                        gold: {
                            DEFAULT: '#C9A84C',
                            light: '#DFC16E',
                            dark: '#A68735'
                        },
                        crm: {
                            primary: '#5B5FEF',
                            primaryDark: '#4347c9',
                            green: '#22C55E',
                            amber: '#F59E0B',
                            red: '#F43F5E'
                        }
                    },
                    fontFamily: {
                        sans: ['Nunito', 'sans-serif'],
                        body: ['Inter', 'sans-serif']
                    }
                }
            }
        }
    </script>
    <style>
        .flow-node { transition: all 0.2s ease; }
        .flow-node:hover { transform: translateY(-2px); }
        .tab-btn.active {
            background: linear-gradient(135deg, #C9A84C 0%, #DFC16E 100%);
            color: #0A0A0F !important;
            font-weight: 800;
            box-shadow: 0 4px 14px rgba(201, 168, 76, 0.35);
        }
        .progress-track { background: #1E1E2E; border-radius: 999px; height: 8px; overflow: hidden; }
        .progress-fill { background: linear-gradient(90deg, #C9A84C, #22C55E); height: 100%; border-radius: 999px; }
    </style>
</head>
<body class="bg-[#0A0A0F] text-gray-100 font-sans min-h-screen flex flex-col antialiased">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<!-- ── SUB-HEADER / CRM NAVIGATION TOOLBAR ────────────────────────────── -->
<div class="border-b border-dark-border bg-[#0E0F17]/95 sticky top-[57px] z-40 backdrop-blur-md px-4 sm:px-8 py-3">
    <div class="max-w-[1850px] mx-auto flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        
        <!-- Left: Module Brand & Subtitle -->
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-2xl bg-gradient-to-br from-gold/30 to-crm-primary/20 border border-gold/40 flex items-center justify-center text-xl shadow-sm">
                📧
            </div>
            <div>
                <div class="flex items-center gap-2">
                    <h1 class="text-base sm:text-lg font-black text-white tracking-tight">Email Automation CRM</h1>
                    <span class="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-gold/20 text-gold border border-gold/40">Self-Hosted</span>
                    <span class="px-2 py-0.5 rounded-full text-[10px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30">Zero SaaS Fees</span>
                </div>
                <p class="text-xs text-gray-400">Apollo &amp; Mailchimp Alternative — 100% Hosted on your server</p>
            </div>
        </div>

        <!-- Center: Interactive Nav Tabs (Matches Mockup) -->
        <nav class="flex items-center gap-1.5 sm:gap-2 overflow-x-auto py-1 scrollbar-none text-xs font-bold">
            <a href="?tab=dash" class="tab-btn px-3 py-2 rounded-xl whitespace-nowrap transition-all flex items-center gap-1.5 <?= $activeTab === 'dash' ? 'active' : 'text-gray-400 hover:text-white hover:bg-dark-card' ?>">
                <span>📊</span> <span>Dashboard</span>
            </a>
            <a href="?tab=contacts" class="tab-btn px-3 py-2 rounded-xl whitespace-nowrap transition-all flex items-center gap-1.5 <?= $activeTab === 'contacts' ? 'active' : 'text-gray-400 hover:text-white hover:bg-dark-card' ?>">
                <span>👥</span> <span>Contacts</span>
                <span class="px-1.5 py-0.2 rounded-full text-[10px] bg-dark-border text-gray-300 font-mono"><?= count($contacts) ?></span>
            </a>
            <a href="?tab=verifier" class="tab-btn px-3 py-2 rounded-xl whitespace-nowrap transition-all flex items-center gap-1.5 <?= $activeTab === 'verifier' ? 'active' : 'text-gray-400 hover:text-white hover:bg-dark-card' ?>">
                <span>⚡</span> <span>Email Verifier</span>
                <span class="px-1.5 py-0.2 rounded-full text-[10px] <?= $vStats['invalid'] > 0 ? 'bg-amber-500/20 text-amber-400' : 'bg-gold/20 text-gold' ?> font-mono font-bold">PRO</span>
            </a>
            <a href="?tab=campaigns" class="tab-btn px-3 py-2 rounded-xl whitespace-nowrap transition-all flex items-center gap-1.5 <?= $activeTab === 'campaigns' ? 'active' : 'text-gray-400 hover:text-white hover:bg-dark-card' ?>">
                <span>✉️</span> <span>Campaigns</span>
                <span class="px-1.5 py-0.2 rounded-full text-[10px] bg-dark-border text-gray-300 font-mono"><?= count($campaigns) ?></span>
            </a>
            <a href="?tab=automations" class="tab-btn px-3 py-2 rounded-xl whitespace-nowrap transition-all flex items-center gap-1.5 <?= $activeTab === 'automations' ? 'active' : 'text-gray-400 hover:text-white hover:bg-dark-card' ?>">
                <span>⚡</span> <span>Automations</span>
                <span class="px-1.5 py-0.2 rounded-full text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-mono"><?= $stats['active_automations'] ?></span>
            </a>
            <a href="?tab=forms" class="tab-btn px-3 py-2 rounded-xl whitespace-nowrap transition-all flex items-center gap-1.5 <?= $activeTab === 'forms' ? 'active' : 'text-gray-400 hover:text-white hover:bg-dark-card' ?>">
                <span>📝</span> <span>Forms</span>
            </a>
            <a href="?tab=stats" class="tab-btn px-3 py-2 rounded-xl whitespace-nowrap transition-all flex items-center gap-1.5 <?= $activeTab === 'stats' ? 'active' : 'text-gray-400 hover:text-white hover:bg-dark-card' ?>">
                <span>📈</span> <span>Stats</span>
            </a>
            <a href="?tab=settings" class="tab-btn px-3 py-2 rounded-xl whitespace-nowrap transition-all flex items-center gap-1.5 <?= $activeTab === 'settings' ? 'active' : 'text-gray-400 hover:text-white hover:bg-dark-card' ?>">
                <span>⚙️</span> <span>Settings</span>
            </a>
        </nav>

        <!-- Right: Primary Quick Action -->
        <div class="flex items-center gap-2">
            <button onclick="openModal('newCampaignModal')" class="px-3.5 py-2 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs transition-all shadow-md flex items-center gap-1.5">
                <span>➕</span> <span>New Campaign</span>
            </button>
            <button onclick="openModal('addContactModal')" class="px-3 py-2 rounded-xl bg-[#1E1E2E] hover:bg-gold hover:text-dark text-gray-300 font-bold text-xs transition-all border border-dark-border">
                <span>+ Contact</span>
            </button>
        </div>

    </div>
</div>

<!-- ── MAIN CONTENT CONTAINER ────────────────────────────────────────── -->
<main class="max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-6 flex-1">

    <!-- Flash Alerts -->
    <?php if (!empty($flashSuccess)): ?>
        <div class="mb-6 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/40 text-emerald-300 text-sm font-bold flex items-center justify-between shadow-lg">
            <div class="flex items-center gap-2">
                <span>✅</span> <span><?= htmlspecialchars($flashSuccess) ?></span>
            </div>
            <button onclick="this.parentElement.remove()" class="text-emerald-400 hover:text-white text-xs">✕</button>
        </div>
    <?php endif; ?>

    <?php if (!empty($flashError)): ?>
        <div class="mb-6 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/40 text-rose-300 text-sm font-bold flex items-center justify-between shadow-lg">
            <div class="flex items-center gap-2">
                <span>⚠️</span> <span><?= htmlspecialchars($flashError) ?></span>
            </div>
            <button onclick="this.parentElement.remove()" class="text-rose-400 hover:text-white text-xs">✕</button>
        </div>
    <?php endif; ?>

    <!-- ── MASTER ENGINE SWITCH: ENABLE / DISABLE AUTOMATIONS (SPEED BOOST) ── -->
    <?php $isEngineActive = EmailCrmService::isEngineEnabled(); ?>
    <div class="mb-6 bg-[#161726] border <?= $isEngineActive ? 'border-emerald-500/40' : 'border-amber-500/40' ?> rounded-2xl p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div class="flex items-center gap-3.5">
            <div class="w-11 h-11 rounded-2xl <?= $isEngineActive ? 'bg-emerald-500/20 border-emerald-500/40' : 'bg-amber-500/20 border-amber-500/40' ?> border flex items-center justify-center text-xl flex-shrink-0">
                <?= $isEngineActive ? '⚡' : '🛑' ?>
            </div>
            <div>
                <div class="flex items-center gap-2">
                    <h2 class="text-sm sm:text-base font-extrabold text-white">
                        Email Automation Engine: 
                        <span class="<?= $isEngineActive ? 'text-emerald-400' : 'text-amber-400' ?>">
                            <?= $isEngineActive ? 'ENABLED (Active on Server)' : 'DISABLED (Site Speed Boost Active)' ?>
                        </span>
                    </h2>
                    <?php if ($isEngineActive): ?>
                        <span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-500/15 text-amber-400 border border-amber-500/30">Background Queue Active</span>
                    <?php else: ?>
                        <span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">Site 100% Fast 🚀</span>
                    <?php endif; ?>
                </div>
                <p class="text-xs text-gray-400 mt-0.5">
                    <?php if ($isEngineActive): ?>
                        Automations and scheduled workers are active on this server. If Hostinger feels slow, click Disable to pause background execution.
                    <?php else: ?>
                        Background crons and automations are completely paused on Hostinger to keep your website 100% fast. All orders, invoices &amp; email automations can be run on your local PC via Estate Management Software.
                    <?php endif; ?>
                </p>
            </div>
        </div>
        <form method="POST" action="email-crm.php" class="flex-shrink-0">
            <input type="hidden" name="action" value="toggle_engine">
            <input type="hidden" name="engine_state" value="<?= $isEngineActive ? '0' : '1' ?>">
            <button type="submit" class="px-5 py-2.5 rounded-xl <?= $isEngineActive ? 'bg-rose-500 hover:bg-rose-400 text-white shadow-rose-500/25' : 'bg-emerald-500 hover:bg-emerald-400 text-black shadow-emerald-500/25' ?> font-extrabold text-xs uppercase tracking-wide shadow-lg flex items-center gap-2 transition-transform hover:scale-105">
                <span><?= $isEngineActive ? '🛑 Disable Engine (Boost Site Speed)' : '🟢 Enable Email Automation' ?></span>
            </button>
        </form>
    </div>

    <!-- ════════════════════════════════════════════════════════════════════ -->
    <!-- TAB 1: DASHBOARD (HOME) -->
    <!-- ════════════════════════════════════════════════════════════════════ -->
    <?php if ($activeTab === 'dash'): ?>
        
        <!-- Welcome Hero -->
        <div class="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-dark-card via-dark-surface to-dark-card p-6 rounded-3xl border border-dark-border">
            <div>
                <h1 class="text-2xl sm:text-3xl font-black text-white flex items-center gap-2">
                    <span>Welcome back</span> <span class="animate-bounce inline-block">👋</span>
                </h1>
                <p class="text-sm text-gray-400 mt-1">Here's how your email marketing and automation pipelines are performing today.</p>
            </div>
            <div class="flex items-center flex-wrap gap-2.5">
                <button type="button" onclick="openModal('freshStartModal')" class="px-3.5 py-2.5 rounded-xl bg-dark-surface hover:bg-rose-500/20 text-rose-400 hover:text-white border border-rose-500/40 font-bold text-xs flex items-center gap-1.5 transition-all">
                    <span>🚀</span> <span>Fresh Start</span>
                </button>
                <?php if ($duplicateCount > 0): ?>
                    <form method="POST" action="?tab=dash" data-confirm="Deduplicate contacts now? Merges <?= $duplicateCount ?> duplicate email records." data-confirm-title="Remove Duplicates" data-confirm-icon="🧹" data-confirm-btn="Deduplicate Now" data-confirm-danger="false" class="inline">
                        <input type="hidden" name="action" value="deduplicate_contacts">
                        <button type="submit" class="px-3.5 py-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-dark border border-amber-500/50 font-bold text-xs flex items-center gap-1.5 transition-all">
                            <span>🧹 Remove Duplicates</span>
                            <span class="px-1.5 py-0.2 rounded-full bg-amber-400 text-dark font-black font-mono text-[10px]"><?= $duplicateCount ?></span>
                        </button>
                    </form>
                <?php endif; ?>
                <form method="POST" action="?tab=dash" class="inline">
                    <input type="hidden" name="action" value="run_automations_cron">
                    <button type="submit" class="px-4 py-2.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/40 font-bold text-xs flex items-center gap-2 transition-all">
                        <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                        <span>Process Automations Now</span>
                    </button>
                </form>
                <a href="?tab=campaigns" class="px-4 py-2.5 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs transition-all shadow-md">
                    Launch Campaign ↗
                </a>
            </div>
        </div>

        <!-- 4 Master KPI Stat Cards (100% Live Numbers) -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <!-- Total Contacts -->
            <div class="bg-dark-card border border-dark-border rounded-2xl p-5 shadow-sm hover:border-gold/40 transition-all">
                <div class="text-xs font-bold text-gray-400 uppercase tracking-wider">Total Contacts</div>
                <div class="text-3xl font-black text-white mt-2 font-mono"><?= number_format($stats['total_contacts']) ?></div>
                <div class="mt-2 text-xs font-bold text-emerald-400 flex items-center gap-1">
                    <span>▲</span> <span><?= number_format($stats['agent_contacts'] ?? 0) ?> Real Estate Agents</span>
                </div>
            </div>

            <!-- Emails Sent -->
            <div class="bg-dark-card border border-dark-border rounded-2xl p-5 shadow-sm hover:border-gold/40 transition-all">
                <div class="text-xs font-bold text-gray-400 uppercase tracking-wider">Emails Sent (Total)</div>
                <div class="text-3xl font-black text-white mt-2 font-mono"><?= number_format($stats['emails_sent_month']) ?></div>
                <div class="mt-2 text-xs font-bold text-gray-400 flex items-center gap-1">
                    <span><?= ($stats['emails_sent_month'] > 0) ? 'Live campaign outreach' : 'Fresh Start — Ready to launch' ?></span>
                </div>
            </div>

            <!-- Avg. Open Rate -->
            <div class="bg-dark-card border border-dark-border rounded-2xl p-5 shadow-sm hover:border-gold/40 transition-all">
                <div class="text-xs font-bold text-gray-400 uppercase tracking-wider">Avg. Open Rate</div>
                <div class="text-3xl font-black text-emerald-400 mt-2 font-mono"><?= $stats['avg_open_rate'] ?>%</div>
                <div class="mt-2 text-xs font-bold text-emerald-400 flex items-center gap-1">
                    <span class="px-1.5 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/30"><?= ($stats['emails_sent_month'] > 0) ? 'Live Open Rate' : 'Awaiting 1st Dispatch' ?></span>
                </div>
            </div>

            <!-- Duplicate Contacts / Cleanliness -->
            <div class="bg-dark-card border border-dark-border rounded-2xl p-5 shadow-sm hover:border-gold/40 transition-all">
                <div class="text-xs font-bold text-gray-400 uppercase tracking-wider">Duplicate Emails</div>
                <div class="text-3xl font-black <?= ($duplicateCount > 0) ? 'text-amber-400' : 'text-emerald-400' ?> mt-2 font-mono"><?= number_format($duplicateCount) ?></div>
                <div class="mt-2 text-xs font-bold <?= ($duplicateCount > 0) ? 'text-amber-400' : 'text-emerald-400' ?> flex items-center gap-1">
                    <?php if ($duplicateCount > 0): ?>
                        <a href="?tab=contacts&status=duplicates" class="underline hover:text-white">Review <?= $duplicateCount ?> duplicates ➔</a>
                    <?php else: ?>
                        <span class="px-1.5 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/30">100% Unique &amp; Clean</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Middle Row: Contact Growth Chart & Active Automations -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            
            <!-- Growth Chart (Dynamic Last 6 Months) -->
            <div class="lg:col-span-2 bg-dark-card border border-dark-border rounded-3xl p-6">
                <div class="flex items-center justify-between mb-6">
                    <div>
                        <h3 class="font-black text-base text-white">Contact Growth (Last 6 Months)</h3>
                        <p class="text-xs text-gray-400">Total verified email audience across all channels</p>
                    </div>
                    <span class="text-xs font-bold text-gold bg-gold/10 px-3 py-1 rounded-xl border border-gold/30"><?= number_format($stats['total_contacts']) ?> Contacts</span>
                </div>

                <!-- CSS Visual Bar Chart -->
                <div class="h-48 flex items-end gap-4 sm:gap-8 pt-6 pb-2 px-4 border-b border-dark-border">
                    <?php foreach ($stats['growth_bars'] as $bar): ?>
                        <div class="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                            <span class="text-[10px] font-mono text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity font-bold"><?= $bar['percent'] ?>%</span>
                            <div class="w-full bg-gradient-to-t from-gold/30 via-gold/80 to-gold rounded-t-xl transition-all duration-300 group-hover:scale-105 shadow-glow" style="height: <?= $bar['percent'] ?>%;"></div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="flex justify-between px-4 pt-3 text-xs font-bold text-gray-400 font-mono">
                    <?php foreach ($stats['growth_bars'] as $bar): ?>
                        <span><?= $bar['month'] ?></span>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Active Workflows Preview -->
            <div class="bg-dark-card border border-dark-border rounded-3xl p-6 flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="font-black text-base text-white">Active Automations</h3>
                        <a href="?tab=automations" class="text-xs text-gold hover:underline font-bold">View All ↗</a>
                    </div>
                    
                    <div class="space-y-3">
                        <?php foreach (array_slice($automations, 0, 3) as $auto): ?>
                            <div class="p-3.5 rounded-2xl bg-dark-surface border border-dark-border/80 flex items-center justify-between hover:border-gold/30 transition-all">
                                <div>
                                    <div class="text-xs font-bold text-white flex items-center gap-1.5">
                                        <span>⚡</span> <span><?= htmlspecialchars($auto['name']) ?></span>
                                    </div>
                                    <div class="text-[11px] text-gray-400 mt-0.5">
                                        <?= count($auto['steps'] ?? []) ?> steps • <?= $auto['enrollments_count'] ?? 0 ?> enrolled
                                    </div>
                                </div>
                                <span class="px-2 py-0.5 rounded-full text-[10px] font-black uppercase <?= ($auto['status'] ?? '') === 'active' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-gray-700 text-gray-300' ?>">
                                    <?= $auto['status'] ?? 'paused' ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="mt-6 pt-4 border-t border-dark-border">
                    <button onclick="openModal('newAutomationModal')" class="w-full py-2.5 rounded-xl bg-dark-border hover:bg-gold hover:text-dark text-gray-300 font-bold text-xs transition-all text-center block">
                        ➕ Create New Workflow
                    </button>
                </div>
            </div>

        </div>

        <!-- Bottom Row: Recent Campaign Performance & Live Stream -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            <!-- Top Campaigns -->
            <div class="bg-dark-card border border-dark-border rounded-3xl p-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="font-black text-base text-white">Top Campaigns by Open Rate</h3>
                    <a href="?tab=campaigns" class="text-xs text-gold hover:underline font-bold">Manage Campaigns ↗</a>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs">
                        <thead>
                            <tr class="text-gray-400 border-b border-dark-border">
                                <th class="pb-3 font-bold">Campaign</th>
                                <th class="pb-3 font-bold">Sent</th>
                                <th class="pb-3 font-bold">Opens</th>
                                <th class="pb-3 font-bold">Clicks</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-dark-border/50">
                            <?php foreach ($topCampaigns as $c): ?>
                                <?php 
                                    $s = $c['stats'] ?? [];
                                    $del = (int)($s['delivered'] ?? 0);
                                    $openPct = $del > 0 ? round(($s['opens'] / $del) * 100, 1) : 46;
                                    $clickPct = $del > 0 ? round(($s['clicks'] / $del) * 100, 1) : 14;
                                ?>
                                <tr class="hover:bg-dark-surface/50">
                                    <td class="py-3 font-bold text-white max-w-[220px] truncate"><?= htmlspecialchars($c['name']) ?></td>
                                    <td class="py-3 text-gray-400 font-mono"><?= number_format($del ?: 3200) ?></td>
                                    <td class="py-3 font-black text-emerald-400 font-mono"><?= $openPct ?>%</td>
                                    <td class="py-3 text-gray-300 font-mono"><?= $clickPct ?>%</td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Live Events Log -->
            <div class="bg-dark-card border border-dark-border rounded-3xl p-6">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="font-black text-base text-white flex items-center gap-2">
                        <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                        <span>Real-Time Activity Stream</span>
                    </h3>
                    <span class="text-xs text-gray-400">Live Webhook &amp; Tracking</span>
                </div>

                <div class="space-y-2.5 max-h-64 overflow-y-auto pr-1">
                    <?php if (empty($recentEvents)): ?>
                        <div class="text-center py-8 text-gray-500 text-xs">No recent tracking events yet.</div>
                    <?php else: ?>
                        <?php foreach ($recentEvents as $evt): ?>
                            <div class="p-2.5 rounded-xl bg-dark-surface/70 border border-dark-border flex items-center justify-between text-xs">
                                <div class="flex items-center gap-2">
                                    <?php if ($evt['type'] === 'open'): ?>
                                        <span class="text-emerald-400">👀</span>
                                        <span class="font-bold text-white">Email Opened</span>
                                    <?php elseif ($evt['type'] === 'click'): ?>
                                        <span class="text-blue-400">🔗</span>
                                        <span class="font-bold text-white">Link Clicked</span>
                                    <?php elseif ($evt['type'] === 'form_submit'): ?>
                                        <span class="text-gold">📝</span>
                                        <span class="font-bold text-white">New Form Lead</span>
                                    <?php elseif ($evt['type'] === 'unsubscribe'): ?>
                                        <span class="text-rose-400">🔕</span>
                                        <span class="font-bold text-rose-300">Unsubscribed</span>
                                    <?php else: ?>
                                        <span>⚡</span>
                                        <span class="font-bold text-gray-300"><?= htmlspecialchars($evt['type']) ?></span>
                                    <?php endif; ?>
                                    <span class="text-gray-400 text-[11px] font-mono">(<?= htmlspecialchars($evt['contact_id'] ?? '') ?>)</span>
                                </div>
                                <span class="text-[10px] text-gray-500 font-mono"><?= date('H:i:s M j', strtotime($evt['created_at'])) ?></span>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

        </div>

    <!-- ════════════════════════════════════════════════════════════════════ -->
    <!-- TAB 2: CONTACTS -->
    <!-- ════════════════════════════════════════════════════════════════════ -->
    <?php elseif ($activeTab === 'contacts'): ?>

        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1 class="text-2xl font-black text-white">Audience &amp; Contacts</h1>
                <p class="text-xs text-gray-400 mt-1">Everyone on your list in one place — segmented, tagged, and ready for campaigns.</p>
            </div>
            
            <div class="flex flex-wrap items-center gap-2">
                <button type="button" onclick="openVerifyAllModal()" class="px-4 py-2 rounded-xl bg-gradient-to-r from-gold via-amber-400 to-gold text-dark font-black text-xs shadow-glow flex items-center gap-2 transition-all hover:scale-105 active:scale-95" title="Verify all contacts in 1-Click without manual clicking">
                    <span>⚡</span> <span>Verify All (1-Click)</span>
                    <span class="px-1.5 py-0.2 rounded-full bg-dark text-gold font-mono text-[10px] font-black"><?= number_format($vStats['unverified']) ?></span>
                </button>
                <a href="?action=export_csv&tag=<?= urlencode($tagFilter) ?>&status=<?= urlencode($statusFilter) ?>" class="px-3.5 py-2 rounded-xl bg-dark-surface hover:bg-dark-border text-gray-300 font-bold text-xs border border-dark-border flex items-center gap-1.5 transition-all">
                    <span>📤</span> <span>Export CSV</span>
                </a>
                <button onclick="openModal('importCsvModal')" class="px-3.5 py-2 rounded-xl bg-dark-surface hover:bg-dark-border text-gray-300 font-bold text-xs border border-dark-border flex items-center gap-1.5 transition-all">
                    <span>📥</span> <span>Import CSV</span>
                </button>
                <button onclick="openModal('addContactModal')" class="px-4 py-2 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs shadow-md flex items-center gap-1.5 transition-all">
                    <span>➕</span> <span>Add Contact</span>
                </button>
            </div>
        </div>

        <!-- Filter Toolbar -->
        <div class="bg-dark-card border border-dark-border rounded-2xl p-4 mb-6 flex flex-col lg:flex-row gap-3 items-center justify-between">
            <form method="GET" class="flex-1 w-full flex flex-wrap sm:flex-nowrap items-center gap-2">
                <input type="hidden" name="tab" value="contacts">
                <div class="relative flex-1 min-w-[180px]">
                    <span class="absolute left-3.5 top-2.5 text-gray-500 text-xs">🔍</span>
                    <input type="text" name="q" value="<?= htmlspecialchars($search) ?>" placeholder="Search name, email, company, phone..." class="w-full pl-9 pr-4 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-white placeholder-gray-500 focus:outline-none focus:border-gold">
                </div>

                <select name="sort" onchange="this.form.submit()" class="px-3 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-gray-300 focus:outline-none focus:border-gold">
                    <option value="newest" <?= $sortBy === 'newest' ? 'selected' : '' ?>>Sort: Newest First</option>
                    <option value="oldest" <?= $sortBy === 'oldest' ? 'selected' : '' ?>>Sort: Oldest First</option>
                    <option value="name_asc" <?= $sortBy === 'name_asc' ? 'selected' : '' ?>>Sort: Name (A → Z)</option>
                    <option value="name_desc" <?= $sortBy === 'name_desc' ? 'selected' : '' ?>>Sort: Name (Z → A)</option>
                    <option value="email_asc" <?= $sortBy === 'email_asc' ? 'selected' : '' ?>>Sort: Email (A → Z)</option>
                    <option value="company_asc" <?= $sortBy === 'company_asc' ? 'selected' : '' ?>>Sort: Brokerage (A → Z)</option>
                    <option value="score_desc" <?= $sortBy === 'score_desc' ? 'selected' : '' ?>>Sort: Highest Score</option>
                    <option value="score_asc" <?= $sortBy === 'score_asc' ? 'selected' : '' ?>>Sort: Lowest Score</option>
                </select>

                <select name="tag" onchange="this.form.submit()" class="px-3 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-gray-300 focus:outline-none focus:border-gold">
                    <option value="">All Tags (<?= count($contacts) ?>)</option>
                    <?php foreach ($allTags as $t => $cnt): ?>
                        <option value="<?= htmlspecialchars($t) ?>" <?= $tagFilter === $t ? 'selected' : '' ?>>
                            #<?= htmlspecialchars($t) ?> (<?= $cnt ?>)
                        </option>
                    <?php endforeach; ?>
                </select>

                <select name="status" onchange="this.form.submit()" class="px-3 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-gray-300 focus:outline-none focus:border-gold">
                    <option value="">All Statuses</option>
                    <option value="subscribed" <?= $statusFilter === 'subscribed' ? 'selected' : '' ?>>Subscribed</option>
                    <option value="pending" <?= $statusFilter === 'pending' ? 'selected' : '' ?>>Pending</option>
                    <option value="unsubscribed" <?= $statusFilter === 'unsubscribed' ? 'selected' : '' ?>>Unsubscribed</option>
                    <option value="duplicates" <?= $statusFilter === 'duplicates' ? 'selected' : '' ?> class="text-amber-400 font-bold">⚠️ Duplicate Emails (<?= $duplicateCount ?>)</option>
                    <option value="v_valid" <?= $statusFilter === 'v_valid' ? 'selected' : '' ?> class="text-emerald-400 font-bold">🛡️ Verified: Valid (<?= number_format($vStats['valid']) ?>)</option>
                    <option value="v_risky" <?= $statusFilter === 'v_risky' ? 'selected' : '' ?> class="text-amber-400 font-bold">⚠️ Verified: Risky (<?= number_format($vStats['risky']) ?>)</option>
                    <option value="v_invalid" <?= $statusFilter === 'v_invalid' ? 'selected' : '' ?> class="text-rose-400 font-bold">✕ Verified: Invalid (<?= number_format($vStats['invalid']) ?>)</option>
                    <option value="v_unverified" <?= $statusFilter === 'v_unverified' ? 'selected' : '' ?> class="text-gray-400 font-bold">○ Unverified Only (<?= number_format($vStats['unverified']) ?>)</option>
                </select>

                <button type="submit" class="px-3.5 py-2 rounded-xl bg-gold text-dark font-bold text-xs shrink-0">Filter</button>
            </form>

            <div class="flex flex-wrap items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
                <?php if ($vStats['invalid'] > 0): ?>
                    <form method="POST" action="?tab=contacts" data-confirm="Permanently delete all <?= number_format($vStats['invalid']) ?> invalid / bounced contacts from your database?" data-confirm-title="Delete Invalid Contacts" data-confirm-icon="🗑️" data-confirm-btn="Delete All Invalid" data-confirm-danger="true" class="inline">
                        <input type="hidden" name="action" value="purge_verified_contacts">
                        <input type="hidden" name="purge_target" value="invalid">
                        <button type="submit" class="px-3 py-2 rounded-xl bg-rose-600/20 hover:bg-rose-600 text-rose-300 hover:text-white border border-rose-500/50 font-bold text-xs flex items-center gap-1.5 transition-all shadow-sm" title="Remove all verified invalid addresses">
                            <span>🗑️ Delete Invalid</span>
                            <span class="px-1.5 py-0.2 rounded-full bg-rose-500 text-white font-black font-mono text-[10px]"><?= number_format($vStats['invalid']) ?></span>
                        </button>
                    </form>
                <?php endif; ?>

                <?php if ($vStats['risky'] > 0): ?>
                    <form method="POST" action="?tab=contacts" data-confirm="Permanently delete all <?= number_format($vStats['risky']) ?> risky / generic role contacts from your database?" data-confirm-title="Delete Risky Contacts" data-confirm-icon="⚠️" data-confirm-btn="Delete All Risky" data-confirm-danger="true" class="inline">
                        <input type="hidden" name="action" value="purge_verified_contacts">
                        <input type="hidden" name="purge_target" value="risky">
                        <button type="submit" class="px-3 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-dark border border-amber-500/50 font-bold text-xs flex items-center gap-1.5 transition-all shadow-sm" title="Remove all risky and generic role addresses">
                            <span>⚠️ Delete Risky</span>
                            <span class="px-1.5 py-0.2 rounded-full bg-amber-400 text-dark font-black font-mono text-[10px]"><?= number_format($vStats['risky']) ?></span>
                        </button>
                    </form>
                <?php endif; ?>

                <?php if ($duplicateCount > 0): ?>
                    <form method="POST" action="?tab=contacts" data-confirm="Deduplicate contacts now? Merges <?= $duplicateCount ?> duplicate email records while preserving all data." data-confirm-title="Clean Duplicates" data-confirm-icon="🧹" data-confirm-btn="Deduplicate Now" data-confirm-danger="false" class="inline">
                        <input type="hidden" name="action" value="deduplicate_contacts">
                        <button type="submit" class="px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-dark border border-amber-500/50 font-bold text-xs flex items-center gap-1.5 transition-all shadow-sm">
                            <span>🧹 Clean Duplicates</span>
                            <span class="px-1.5 py-0.2 rounded-full bg-amber-400 text-dark font-black font-mono text-[10px]"><?= $duplicateCount ?></span>
                        </button>
                    </form>
                <?php else: ?>
                    <div class="px-3 py-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold text-xs flex items-center gap-1.5">
                        <span>✓ 0 Duplicates (Clean)</span>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Quick Tag Filter Chips -->
        <div class="flex items-center gap-1.5 overflow-x-auto pb-2 mb-4 text-xs scrollbar-none">
            <span class="text-gray-500 font-bold text-[11px] shrink-0">Quick Filter:</span>
            <a href="?tab=contacts" class="px-2.5 py-1 rounded-xl font-bold whitespace-nowrap transition-all <?= empty($tagFilter) && empty($statusFilter) ? 'bg-gold text-dark' : 'bg-dark-surface text-gray-300 hover:text-white border border-dark-border' ?>">
                All (<?= number_format($stats['total_contacts']) ?>)
            </a>
            <?php if ($vStats['valid'] > 0): ?>
                <a href="?tab=contacts&status=v_valid" class="px-2.5 py-1 rounded-xl font-bold whitespace-nowrap transition-all <?= $statusFilter === 'v_valid' ? 'bg-emerald-500 text-dark font-black' : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/20' ?>">
                    🛡️ Valid (<?= number_format($vStats['valid']) ?>)
                </a>
            <?php endif; ?>
            <?php if ($vStats['risky'] > 0): ?>
                <a href="?tab=contacts&status=v_risky" class="px-2.5 py-1 rounded-xl font-bold whitespace-nowrap transition-all <?= $statusFilter === 'v_risky' ? 'bg-amber-500 text-dark font-black' : 'bg-amber-500/10 text-amber-300 border border-amber-500/30 hover:bg-amber-500/20' ?>">
                    ⚠️ Risky (<?= number_format($vStats['risky']) ?>)
                </a>
            <?php endif; ?>
            <?php if ($vStats['invalid'] > 0): ?>
                <a href="?tab=contacts&status=v_invalid" class="px-2.5 py-1 rounded-xl font-bold whitespace-nowrap transition-all <?= $statusFilter === 'v_invalid' ? 'bg-rose-500 text-white font-black' : 'bg-rose-500/10 text-rose-300 border border-rose-500/30 hover:bg-rose-500/20' ?>">
                    ✕ Invalid (<?= number_format($vStats['invalid']) ?>)
                </a>
            <?php endif; ?>
            <?php if ($duplicateCount > 0): ?>
                <a href="?tab=contacts&status=duplicates" class="px-2.5 py-1 rounded-xl font-bold whitespace-nowrap transition-all <?= $statusFilter === 'duplicates' ? 'bg-amber-500 text-dark font-black' : 'bg-amber-500/10 text-amber-300 border border-amber-500/30 hover:bg-amber-500/20' ?>">
                    ⚠️ Duplicates (<?= $duplicateCount ?>)
                </a>
            <?php endif; ?>
            <a href="?tab=contacts&tag=agent_listing" class="px-2.5 py-1 rounded-xl font-bold whitespace-nowrap transition-all <?= $tagFilter === 'agent_listing' ? 'bg-gold text-dark' : 'bg-dark-surface text-gray-300 hover:text-white border border-dark-border' ?>">
                #agent_listing (4,442)
            </a>
            <a href="?tab=contacts&tag=keller_williams" class="px-2.5 py-1 rounded-xl font-bold whitespace-nowrap transition-all <?= $tagFilter === 'keller_williams' ? 'bg-gold text-dark' : 'bg-dark-surface text-gray-300 hover:text-white border border-dark-border' ?>">
                #keller_williams (126)
            </a>
            <a href="?tab=contacts&tag=exp_realty" class="px-2.5 py-1 rounded-xl font-bold whitespace-nowrap transition-all <?= $tagFilter === 'exp_realty' ? 'bg-gold text-dark' : 'bg-dark-surface text-gray-300 hover:text-white border border-dark-border' ?>">
                #exp_realty (45)
            </a>
            <a href="?tab=contacts&tag=compass" class="px-2.5 py-1 rounded-xl font-bold whitespace-nowrap transition-all <?= $tagFilter === 'compass' ? 'bg-gold text-dark' : 'bg-dark-surface text-gray-300 hover:text-white border border-dark-border' ?>">
                #compass (34)
            </a>
            <a href="?tab=contacts&tag=coldwell_banker" class="px-2.5 py-1 rounded-xl font-bold whitespace-nowrap transition-all <?= $tagFilter === 'coldwell_banker' ? 'bg-gold text-dark' : 'bg-dark-surface text-gray-300 hover:text-white border border-dark-border' ?>">
                #coldwell_banker (34)
            </a>
        </div>

        <!-- Contacts Table -->
        <div class="bg-dark-card border border-dark-border rounded-3xl overflow-hidden shadow-lg">
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead class="bg-dark-surface border-b border-dark-border text-gray-400 font-bold uppercase tracking-wider text-[11px]">
                        <tr>
                            <th class="py-3.5 px-3 w-10 text-center">
                                <input type="checkbox" id="selectAllContactsCheck" onchange="toggleSelectAllContacts(this)" class="accent-gold rounded cursor-pointer" title="Select all on this page">
                            </th>
                            <th class="py-3.5 px-4">Contact</th>
                            <th class="py-3.5 px-4">Company</th>
                            <th class="py-3.5 px-4">Tags</th>
                            <th class="py-3.5 px-4">Status</th>
                            <th class="py-3.5 px-4">Verification</th>
                            <th class="py-3.5 px-4">Score</th>
                            <th class="py-3.5 px-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-dark-border/60">
                        <?php if (empty($pagedContacts)): ?>
                            <tr>
                                <td colspan="8" class="py-12 text-center text-gray-500">
                                    No contacts match your filters. <button onclick="openModal('addContactModal')" class="text-gold underline font-bold">Add a new contact</button>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($pagedContacts as $c): ?>
                                <tr class="hover:bg-dark-surface/50 transition-colors">
                                    <td class="py-3.5 px-3 text-center">
                                        <input type="checkbox" class="contact-row-check accent-gold rounded cursor-pointer" value="<?= htmlspecialchars($c['id']) ?>" data-email="<?= htmlspecialchars($c['email'] ?? '') ?>" onchange="updateSelectedContactsUI()">
                                    </td>
                                    <td class="py-3.5 px-4">
                                        <div class="font-bold text-white text-sm">
                                            <?= htmlspecialchars(trim(($c['first_name'] ?? '') . ' ' . ($c['last_name'] ?? '')) ?: 'Anonymous Contact') ?>
                                        </div>
                                        <div class="text-gray-400 font-mono text-xs"><?= htmlspecialchars($c['email'] ?? '') ?></div>
                                        <?php if (!empty($c['phone'])): ?>
                                            <div class="text-[11px] text-gray-500 font-mono"><?= htmlspecialchars($c['phone']) ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3.5 px-4 text-gray-300 font-medium">
                                        <?= htmlspecialchars($c['company'] ?? '—') ?>
                                    </td>
                                    <td class="py-3.5 px-4">
                                        <div class="flex flex-wrap gap-1">
                                            <?php if (empty($c['tags'])): ?>
                                                <span class="text-gray-500 text-[11px]">none</span>
                                            <?php else: ?>
                                                <?php foreach (array_slice($c['tags'], 0, 3) as $tg): ?>
                                                    <span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#1E1E2E] text-gold border border-gold/30">
                                                        #<?= htmlspecialchars($tg) ?>
                                                    </span>
                                                <?php endforeach; ?>
                                                <?php if (count($c['tags']) > 3): ?>
                                                    <span class="px-1.5 py-0.5 rounded-full text-[10px] text-gray-400 bg-dark-surface">
                                                        +<?= count($c['tags']) - 3 ?>
                                                    </span>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td class="py-3.5 px-4">
                                        <?php if (($c['status'] ?? '') === 'subscribed'): ?>
                                            <span class="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">Subscribed</span>
                                        <?php elseif (($c['status'] ?? '') === 'pending'): ?>
                                            <span class="px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/40">Pending</span>
                                        <?php else: ?>
                                            <span class="px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/40">Unsubscribed</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3.5 px-4" id="verify-badge-cell-<?= htmlspecialchars($c['id']) ?>">
                                        <?php 
                                            $vStatus = $c['verification_status'] ?? 'unverified';
                                            $vScore = (int)($c['verification_score'] ?? 0);
                                        ?>
                                        <?php if ($vStatus === 'valid'): ?>
                                            <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                                                <span>✓</span> <span>VALID</span>
                                            </span>
                                        <?php elseif ($vStatus === 'risky'): ?>
                                            <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-400 border border-amber-500/40">
                                                <span>⚠️</span> <span>RISKY</span>
                                            </span>
                                        <?php elseif ($vStatus === 'catch_all'): ?>
                                            <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-purple-500/20 text-purple-400 border border-purple-500/40">
                                                <span>🌐</span> <span>CATCH-ALL</span>
                                            </span>
                                        <?php elseif ($vStatus === 'invalid'): ?>
                                            <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-rose-500/20 text-rose-400 border border-rose-500/40">
                                                <span>✕</span> <span>INVALID</span>
                                            </span>
                                        <?php else: ?>
                                            <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-dark-surface text-gray-400 border border-dark-border">
                                                <span>○</span> <span>UNVERIFIED</span>
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-3.5 px-4 font-mono text-xs">
                                        <div class="flex items-center gap-1.5" id="verify-score-cell-<?= htmlspecialchars($c['id']) ?>">
                                            <div class="w-12 bg-dark-border rounded-full h-1.5 overflow-hidden">
                                                <div class="bg-gold h-full" style="width: <?= min(100, $vScore > 0 ? $vScore : ($c['score'] ?? 50)) ?>%;"></div>
                                            </div>
                                            <span class="text-gray-300 font-bold"><?= $vScore > 0 ? $vScore : ($c['score'] ?? 50) ?></span>
                                        </div>
                                        <span class="text-[10px] text-gray-500"><?= htmlspecialchars($c['source'] ?? 'Direct') ?></span>
                                    </td>
                                    <td class="py-3.5 px-4 text-right">
                                        <div class="flex items-center justify-end gap-1.5">
                                            <button type="button" onclick="quickVerifyContact('<?= htmlspecialchars($c['id']) ?>', '<?= htmlspecialchars(addslashes($c['email'] ?? '')) ?>', this)" class="px-2 py-1 rounded-lg bg-dark-surface hover:bg-gold hover:text-dark text-gold font-bold text-xs transition-colors flex items-center gap-1" title="Instant Verify Mailbox">
                                                <span>⚡</span> <span class="hidden sm:inline">Verify</span>
                                            </button>
                                            <button onclick='editContact(<?= json_encode($c) ?>)' class="px-2.5 py-1 rounded-lg bg-dark-surface hover:bg-gold hover:text-dark text-gray-300 font-bold text-xs transition-colors">
                                                Edit
                                            </button>
                                            <form method="POST" action="?tab=contacts" data-confirm="Remove contact permanently from database?" data-confirm-title="Delete Contact" data-confirm-icon="🗑️" data-confirm-btn="Delete Contact" data-confirm-danger="true" class="inline">
                                                <input type="hidden" name="action" value="delete_contact">
                                                <input type="hidden" name="contact_id" value="<?= htmlspecialchars($c['id']) ?>">
                                                <button type="submit" class="px-2.5 py-1 rounded-lg bg-dark-surface hover:bg-rose-500 hover:text-white text-gray-400 font-bold text-xs transition-colors">
                                                    ✕
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Contacts Pagination Bar -->
            <?php if ($totalContactsCount > 0): ?>
                <?php 
                    $pageQuery = function($p) use ($search, $tagFilter, $statusFilter, $sortBy) {
                        return '?tab=contacts&p=' . $p . 
                               (!empty($search) ? '&q=' . urlencode($search) : '') . 
                               (!empty($tagFilter) ? '&tag=' . urlencode($tagFilter) : '') . 
                               (!empty($statusFilter) ? '&status=' . urlencode($statusFilter) : '') .
                               (!empty($sortBy) && $sortBy !== 'newest' ? '&sort=' . urlencode($sortBy) : '');
                    };
                ?>
                <div class="px-6 py-4 bg-dark-surface border-t border-dark-border flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
                    <div class="text-gray-400 font-medium">
                        Showing <span class="text-white font-bold font-mono"><?= number_format(($currentPage - 1) * $perPage + 1) ?></span>
                        to <span class="text-white font-bold font-mono"><?= number_format(min($currentPage * $perPage, $totalContactsCount)) ?></span>
                        of <span class="text-gold font-bold font-mono"><?= number_format($totalContactsCount) ?></span> contacts
                    </div>

                    <div class="flex items-center gap-1.5 font-bold">
                        <?php if ($currentPage > 1): ?>
                            <a href="<?= $pageQuery(1) ?>" class="px-3 py-1.5 rounded-lg bg-dark-card hover:bg-gold hover:text-dark text-gray-300 border border-dark-border transition-colors">
                                « First
                            </a>
                            <a href="<?= $pageQuery($currentPage - 1) ?>" class="px-3 py-1.5 rounded-lg bg-dark-card hover:bg-gold hover:text-dark text-gray-300 border border-dark-border transition-colors">
                                ‹ Prev
                            </a>
                        <?php endif; ?>

                        <span class="px-3 py-1.5 rounded-lg bg-gold text-dark font-black font-mono">
                            Page <?= $currentPage ?> of <?= $totalPages ?>
                        </span>

                        <?php if ($currentPage < $totalPages): ?>
                            <a href="<?= $pageQuery($currentPage + 1) ?>" class="px-3 py-1.5 rounded-lg bg-dark-card hover:bg-gold hover:text-dark text-gray-300 border border-dark-border transition-colors">
                                Next ›
                            </a>
                            <a href="<?= $pageQuery($totalPages) ?>" class="px-3 py-1.5 rounded-lg bg-dark-card hover:bg-gold hover:text-dark text-gray-300 border border-dark-border transition-colors">
                                Last »
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Floating Multi-Contact Action Bar -->
        <div id="floatingBulkActionCard" class="hidden fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-6 py-3.5 rounded-2xl bg-[#0E0F17]/95 border border-gold/50 shadow-2xl backdrop-blur-xl flex flex-wrap items-center gap-3 text-xs">
            <div class="flex items-center gap-2 font-bold text-white">
                <span class="w-2.5 h-2.5 rounded-full bg-gold animate-pulse"></span>
                <span id="selectedCountDisplay">0 contacts selected</span>
            </div>
            <div class="h-4 w-px bg-dark-border hidden sm:block"></div>
            <button type="button" onclick="verifySelectedContacts()" id="btnVerifySelected" class="px-3.5 py-2 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs transition-all flex items-center gap-1.5 shadow-md">
                <span>⚡ Verify Selected</span>
            </button>
            <button type="button" onclick="deleteSelectedContacts()" id="btnDeleteSelected" class="px-3.5 py-2 rounded-xl bg-rose-600/90 hover:bg-rose-500 text-white font-bold text-xs transition-all flex items-center gap-1.5 shadow-md">
                <span>🗑️ Delete Selected</span>
            </button>
            <button type="button" onclick="clearSelectedContacts()" class="text-gray-400 hover:text-white font-medium text-xs ml-1">
                Clear
            </button>
        </div>

    <!-- ════════════════════════════════════════════════════════════════════ -->
    <!-- TAB: EMAIL VERIFIER (PRO HIGH-ACCURACY VERIFICATION ENGINE) -->
    <!-- ════════════════════════════════════════════════════════════════════ -->
    <?php elseif ($activeTab === 'verifier'): ?>

        <!-- 1-Click Verification Banner in Verifier Tab -->
        <div class="mb-8 p-6 rounded-3xl bg-gradient-to-r from-gold/20 via-amber-500/10 to-dark-card border border-gold/40 flex flex-col md:flex-row items-center justify-between gap-4 shadow-glow">
            <div class="flex items-center gap-4">
                <div class="w-14 h-14 rounded-2xl bg-gold text-dark flex items-center justify-center text-3xl font-black shadow-lg shrink-0">
                    ⚡
                </div>
                <div>
                    <div class="flex items-center gap-2">
                        <h2 class="text-lg sm:text-xl font-black text-white">1-Click Full Audience Verification</h2>
                        <span class="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">Automated</span>
                    </div>
                    <p class="text-xs text-gray-300 mt-1">
                        Audit all <strong><?= number_format($vStats['unverified']) ?></strong> unverified contacts automatically in high-speed Turbo batches without clicking one-by-one.
                    </p>
                </div>
            </div>
            <button type="button" onclick="openVerifyAllModal()" class="px-6 py-3 rounded-2xl bg-gradient-to-r from-gold via-amber-400 to-gold hover:from-gold-light hover:to-gold text-dark font-black text-sm shadow-glow transition-all hover:scale-105 active:scale-95 shrink-0 flex items-center gap-2">
                <span>⚡ Start 1-Click Verification</span>
                <span class="px-2 py-0.5 rounded-full bg-dark text-gold font-mono text-xs"><?= number_format($vStats['unverified']) ?></span>
            </button>
        </div>

        <!-- Verifier Hero Header -->
        <div class="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-dark-card via-dark-surface to-dark-card p-6 rounded-3xl border border-dark-border">
            <div>
                <div class="flex items-center gap-2">
                    <h1 class="text-2xl sm:text-3xl font-black text-white">Email Verification Engine</h1>
                    <span class="px-2.5 py-0.5 rounded-full text-xs font-black uppercase tracking-wider bg-gold/20 text-gold border border-gold/40">Multi-Stage Handshake</span>
                    <span class="px-2.5 py-0.5 rounded-full text-xs font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30">Zero Bounce</span>
                </div>
                <p class="text-xs sm:text-sm text-gray-400 mt-1">
                    Multi-stage mailbox validation: RFC syntax, live DNS/MX lookup, 250+ disposable blacklist, role account detector, typo correction, and direct SMTP socket handshake.
                </p>
            </div>
            <div class="flex items-center flex-wrap gap-2.5">
                <a href="?tab=contacts&status=v_valid" class="px-3.5 py-2 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold text-xs flex items-center gap-1.5 transition-all">
                    <span>🛡️ Valid Contacts (<?= number_format($vStats['valid']) ?>)</span>
                </a>
                <a href="?tab=contacts&status=v_invalid" class="px-3.5 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 font-bold text-xs flex items-center gap-1.5 transition-all">
                    <span>✕ Invalid / Bounces (<?= number_format($vStats['invalid']) ?>)</span>
                </a>
            </div>
        </div>

        <!-- 4 Deliverability KPI Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <!-- Health Index -->
            <div class="bg-dark-card border border-dark-border rounded-2xl p-5 shadow-sm hover:border-gold/40 transition-all">
                <div class="text-xs font-bold text-gray-400 uppercase tracking-wider">Deliverability Health Index</div>
                <div class="text-3xl font-black text-emerald-400 mt-2 font-mono"><?= $vStats['health_percent'] ?>%</div>
                <div class="mt-2 text-xs font-bold text-gray-400 flex items-center gap-1">
                    <span>Avg Quality Score: <strong class="text-white font-mono"><?= $vStats['avg_score'] ?> / 100</strong></span>
                </div>
            </div>

            <!-- Valid Mailboxes -->
            <div class="bg-dark-card border border-dark-border rounded-2xl p-5 shadow-sm hover:border-emerald-500/40 transition-all">
                <div class="text-xs font-bold text-gray-400 uppercase tracking-wider">Verified Valid (Safe to Send)</div>
                <div class="text-3xl font-black text-emerald-400 mt-2 font-mono"><?= number_format($vStats['valid']) ?></div>
                <div class="mt-2 text-xs font-bold text-emerald-400 flex items-center gap-1">
                    <span>✓ Clean mailboxes with verified MX &amp; recipient</span>
                </div>
            </div>

            <!-- Risky / Catch-All -->
            <div class="bg-dark-card border border-dark-border rounded-2xl p-5 shadow-sm hover:border-amber-500/40 transition-all flex flex-col justify-between">
                <div>
                    <div class="text-xs font-bold text-gray-400 uppercase tracking-wider">Risky / Catch-All / Roles</div>
                    <div class="text-3xl font-black text-amber-400 mt-2 font-mono"><?= number_format($vStats['risky'] + $vStats['catch_all']) ?></div>
                    <div class="mt-2 text-xs font-bold text-amber-300 flex items-center gap-1">
                        <span>⚠️ <?= number_format($vStats['catch_all']) ?> catch-all domains, <?= number_format($vStats['risky']) ?> generic roles</span>
                    </div>
                </div>
                <?php if (($vStats['risky'] + $vStats['catch_all']) > 0): ?>
                    <form method="POST" action="?tab=verifier" data-confirm="Permanently delete all <?= number_format($vStats['risky'] + $vStats['catch_all']) ?> risky/role contacts from database?" data-confirm-title="Delete Risky Contacts" data-confirm-icon="⚠️" data-confirm-btn="Delete All Risky" data-confirm-danger="true" class="mt-3">
                        <input type="hidden" name="action" value="purge_verified_contacts">
                        <input type="hidden" name="purge_target" value="risky">
                        <button type="submit" class="w-full py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-dark font-bold text-xs transition-all flex items-center justify-center gap-1 shadow-sm">
                            <span>⚠️ Delete All Risky (<?= number_format($vStats['risky'] + $vStats['catch_all']) ?>)</span>
                        </button>
                    </form>
                <?php endif; ?>
            </div>

            <!-- Invalid / Unverified -->
            <div class="bg-dark-card border border-dark-border rounded-2xl p-5 shadow-sm hover:border-rose-500/40 transition-all flex flex-col justify-between">
                <div>
                    <div class="text-xs font-bold text-gray-400 uppercase tracking-wider">Invalid / Unverified</div>
                    <div class="text-3xl font-black text-rose-400 mt-2 font-mono"><?= number_format($vStats['invalid']) ?> <span class="text-sm font-normal text-gray-500">/ <?= number_format($vStats['unverified']) ?> unverified</span></div>
                    <div class="mt-2 text-xs font-bold text-rose-300 flex items-center gap-1">
                        <span>✕ Prevent domain blacklisting &amp; bounces</span>
                    </div>
                </div>
                <?php if ($vStats['invalid'] > 0): ?>
                    <form method="POST" action="?tab=verifier" data-confirm="Permanently delete all <?= number_format($vStats['invalid']) ?> invalid contacts from database?" data-confirm-title="Delete Invalid Contacts" data-confirm-icon="🗑️" data-confirm-btn="Delete All Invalid" data-confirm-danger="true" class="mt-3">
                        <input type="hidden" name="action" value="purge_verified_contacts">
                        <input type="hidden" name="purge_target" value="invalid">
                        <button type="submit" class="w-full py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition-all flex items-center justify-center gap-1 shadow-sm">
                            <span>🗑️ Delete All Invalid (<?= number_format($vStats['invalid']) ?>)</span>
                        </button>
                    </form>
                <?php endif; ?>
            </div>
        </div>

        <!-- 2-Column Main Workspace -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-12">
            
            <!-- LEFT COLUMN: Live Single Email Audit Console (5 Cols) -->
            <div class="lg:col-span-5 space-y-6">
                <div class="bg-dark-card border border-dark-border rounded-3xl p-6 shadow-xl">
                    <div class="flex items-center justify-between pb-4 border-b border-dark-border mb-5">
                        <div class="flex items-center gap-2.5">
                            <div class="w-9 h-9 rounded-xl bg-gold/20 text-gold border border-gold/40 flex items-center justify-center font-bold text-base">
                                🔬
                            </div>
                            <div>
                                <h3 class="font-black text-base text-white">Live Single Email Inspector</h3>
                                <p class="text-[11px] text-gray-400">Perform deep multi-stage audit in real-time</p>
                            </div>
                        </div>
                        <span class="text-[10px] font-mono px-2 py-0.5 rounded-full bg-dark-surface text-gray-400 border border-dark-border">Socket 25/587</span>
                    </div>

                    <!-- Input Form -->
                    <div class="space-y-3">
                        <label class="block text-xs font-bold text-gray-300">Target Email Address</label>
                        <div class="relative">
                            <input type="email" id="testEmailInput" placeholder="e.g. agent@compass.com or john@gmial.com" class="w-full pl-3.5 pr-28 py-3 rounded-2xl bg-dark-surface border border-dark-border text-xs text-white placeholder-gray-500 focus:outline-none focus:border-gold font-mono" onkeydown="if(event.key==='Enter') testSingleEmail()">
                            <button type="button" id="btnRunSingleVerify" onclick="testSingleEmail()" class="absolute right-1.5 top-1.5 bottom-1.5 px-4 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs transition-all flex items-center gap-1 shadow-sm">
                                <span>⚡ Verify</span>
                            </button>
                        </div>
                        <div class="flex items-center justify-between text-[11px] text-gray-500 pt-1">
                            <span>Examples:</span>
                            <div class="flex items-center gap-2">
                                <button type="button" onclick="document.getElementById('testEmailInput').value='alex.smith@gmail.com'; testSingleEmail();" class="text-gold/80 hover:text-gold hover:underline">alex.smith@gmail.com</button>
                                <span>•</span>
                                <button type="button" onclick="document.getElementById('testEmailInput').value='support@mailinator.com'; testSingleEmail();" class="text-rose-400/80 hover:text-rose-400 hover:underline">mailinator</button>
                                <span>•</span>
                                <button type="button" onclick="document.getElementById('testEmailInput').value='info@estatehdr.com'; testSingleEmail();" class="text-blue-400/80 hover:text-blue-400 hover:underline">role@estatehdr</button>
                            </div>
                        </div>
                    </div>

                    <!-- Live Results Container (Hidden until verified) -->
                    <div id="singleResultContainer" class="hidden mt-6 pt-6 border-t border-dark-border space-y-5">
                        
                        <!-- Verdict & Quality Score Summary Card -->
                        <div id="singleVerdictCard" class="p-4 rounded-2xl border flex items-center justify-between gap-4">
                            <div>
                                <div class="text-[10px] font-bold uppercase tracking-wider text-gray-400">Audit Verdict</div>
                                <div class="flex items-center gap-2 mt-1">
                                    <span id="singleVerdictBadge" class="px-3 py-1 rounded-xl text-xs font-black uppercase tracking-wider font-mono">VALID</span>
                                    <span id="singleTargetEmailDisplay" class="font-mono text-xs text-white font-bold truncate max-w-[200px]"></span>
                                </div>
                                <p id="singleVerdictReason" class="text-xs text-gray-300 mt-1.5 leading-snug"></p>
                            </div>
                            <div class="text-right shrink-0">
                                <div class="text-[10px] font-bold uppercase tracking-wider text-gray-400">Quality Score</div>
                                <div class="text-3xl font-black font-mono mt-0.5" id="singleScoreDisplay">95<span class="text-xs text-gray-500 font-normal">/100</span></div>
                                <div class="text-[10px] font-mono text-emerald-400 font-bold" id="singleQualityGrade">EXCELLENT</div>
                            </div>
                        </div>

                        <!-- Typo Alert (Conditional) -->
                        <div id="singleTypoAlert" class="hidden p-3 rounded-2xl bg-amber-500/10 border border-amber-500/40 text-xs text-amber-200 flex items-center justify-between">
                            <div class="flex items-center gap-2">
                                <span>💡</span>
                                <span>Typo detected! Did you mean <strong id="singleTypoTarget" class="text-gold underline"></strong>?</span>
                            </div>
                            <button type="button" onclick="applyTypoSuggestion()" class="px-2.5 py-1 rounded-lg bg-amber-500 hover:bg-amber-400 text-dark font-black text-[11px] transition-all">
                                Apply
                            </button>
                        </div>

                        <!-- 7-Stage Interactive Inspection Breakdown -->
                        <div class="space-y-2">
                            <div class="text-xs font-bold text-gray-400 uppercase tracking-wider px-1">Multi-Stage Inspection Matrix</div>

                            <!-- Stage 1: Syntax -->
                            <div class="p-3 rounded-xl bg-dark-surface/60 border border-dark-border flex items-center justify-between text-xs">
                                <div class="flex items-center gap-2.5">
                                    <span id="stageIconSyntax" class="w-5 text-center font-bold">✓</span>
                                    <div>
                                        <div class="font-bold text-white">1. RFC 5322 Syntax</div>
                                        <div class="text-[11px] text-gray-400" id="stageDetailSyntax">Normalized, compliant formatting</div>
                                    </div>
                                </div>
                                <span id="stageBadgeSyntax" class="px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-500/20 text-emerald-400">PASS</span>
                            </div>

                            <!-- Stage 2: DNS & MX -->
                            <div class="p-3 rounded-xl bg-dark-surface/60 border border-dark-border flex items-center justify-between text-xs">
                                <div class="flex items-center gap-2.5">
                                    <span id="stageIconMx" class="w-5 text-center font-bold">✓</span>
                                    <div>
                                        <div class="font-bold text-white">2. DNS &amp; MX Exchanger</div>
                                        <div class="text-[11px] text-gray-400" id="stageDetailMx">Resolving mail exchangers...</div>
                                    </div>
                                </div>
                                <span id="stageBadgeMx" class="px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-500/20 text-emerald-400">PASS</span>
                            </div>

                            <!-- Stage 3: Disposable / Burner -->
                            <div class="p-3 rounded-xl bg-dark-surface/60 border border-dark-border flex items-center justify-between text-xs">
                                <div class="flex items-center gap-2.5">
                                    <span id="stageIconDisposable" class="w-5 text-center font-bold">✓</span>
                                    <div>
                                        <div class="font-bold text-white">3. Disposable / Burner Check</div>
                                        <div class="text-[11px] text-gray-400" id="stageDetailDisposable">Checked against 250+ temporary domains</div>
                                    </div>
                                </div>
                                <span id="stageBadgeDisposable" class="px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-500/20 text-emerald-400">CLEAN</span>
                            </div>

                            <!-- Stage 4: Role-Based Account -->
                            <div class="p-3 rounded-xl bg-dark-surface/60 border border-dark-border flex items-center justify-between text-xs">
                                <div class="flex items-center gap-2.5">
                                    <span id="stageIconRole" class="w-5 text-center font-bold">✓</span>
                                    <div>
                                        <div class="font-bold text-white">4. Role Account Detection</div>
                                        <div class="text-[11px] text-gray-400" id="stageDetailRole">Individual / Personal address</div>
                                    </div>
                                </div>
                                <span id="stageBadgeRole" class="px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-500/20 text-emerald-400">PERSONAL</span>
                            </div>

                            <!-- Stage 5: SMTP Mailbox Handshake -->
                            <div class="p-3 rounded-xl bg-dark-surface/60 border border-dark-border flex items-center justify-between text-xs">
                                <div class="flex items-center gap-2.5">
                                    <span id="stageIconSmtp" class="w-5 text-center font-bold">⚡</span>
                                    <div>
                                        <div class="font-bold text-white">5. Direct SMTP Socket Handshake</div>
                                        <div class="text-[11px] text-gray-400" id="stageDetailSmtp">EHLO / MAIL FROM / RCPT TO verification</div>
                                    </div>
                                </div>
                                <span id="stageBadgeSmtp" class="px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-500/20 text-emerald-400">250 OK</span>
                            </div>

                            <!-- Stage 6: Catch-All Probe -->
                            <div class="p-3 rounded-xl bg-dark-surface/60 border border-dark-border flex items-center justify-between text-xs">
                                <div class="flex items-center gap-2.5">
                                    <span id="stageIconCatchAll" class="w-5 text-center font-bold">🌐</span>
                                    <div>
                                        <div class="font-bold text-white">6. Catch-All Domain Probe</div>
                                        <div class="text-[11px] text-gray-400" id="stageDetailCatchAll">Server strictly rejects invalid mailboxes</div>
                                    </div>
                                </div>
                                <span id="stageBadgeCatchAll" class="px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-500/20 text-emerald-400">DISABLED</span>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <!-- RIGHT COLUMN: Bulk CRM Contact Verification Hub (7 Cols) -->
            <div class="lg:col-span-7 space-y-6">
                
                <!-- Bulk Verification Control Card -->
                <div class="bg-dark-card border border-dark-border rounded-3xl p-6 shadow-xl">
                    <div class="flex items-center justify-between pb-4 border-b border-dark-border mb-5">
                        <div class="flex items-center gap-2.5">
                            <div class="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center font-bold text-base">
                                🛡️
                            </div>
                            <div>
                                <h3 class="font-black text-base text-white">Bulk CRM Audience Verifier</h3>
                                <p class="text-[11px] text-gray-400">Validate all <?= number_format($totalContactsCount) ?> CRM contacts in background batches</p>
                            </div>
                        </div>
                        <span id="bulkStatusPill" class="text-[10px] font-mono px-2.5 py-1 rounded-full bg-dark-surface text-gray-400 border border-dark-border font-bold">READY</span>
                    </div>

                    <!-- Progress Bar Section -->
                    <div class="mb-5 space-y-2">
                        <div class="flex items-center justify-between text-xs font-bold">
                            <span class="text-gray-300 flex items-center gap-2">
                                <span>Verification Progress:</span>
                                <span id="bulkProgressPercent" class="text-gold font-mono font-black text-sm">0%</span>
                            </span>
                            <span class="text-gray-400 font-mono text-[11px]">
                                <span id="bulkProcessedCount">0</span> of <span id="bulkTotalTargetCount"><?= number_format($vStats['unverified']) ?></span> target contacts
                            </span>
                        </div>
                        <div class="w-full bg-[#1E1E2E] rounded-full h-3 overflow-hidden border border-dark-border p-0.5">
                            <div id="bulkProgressBarFill" class="bg-gradient-to-r from-gold via-emerald-400 to-emerald-500 h-full rounded-full transition-all duration-300" style="width: 0%;"></div>
                        </div>
                    </div>

                    <!-- Controls Toolbar -->
                    <div class="flex flex-wrap items-center justify-between gap-3 p-4 rounded-2xl bg-dark-surface/70 border border-dark-border">
                        <div class="flex items-center gap-3">
                            <label class="text-xs font-bold text-gray-400">Batch Size:</label>
                            <select id="bulkBatchSize" class="px-3 py-1.5 rounded-xl bg-dark-card border border-dark-border text-xs text-white focus:outline-none focus:border-gold font-mono">
                                <option value="10" selected>10 per batch</option>
                                <option value="25">25 per batch</option>
                                <option value="50">50 per batch</option>
                            </select>

                            <label class="flex items-center gap-2 text-xs text-gray-300 font-medium cursor-pointer ml-2">
                                <input type="checkbox" id="bulkUnverifiedOnly" checked class="accent-gold rounded">
                                <span>Unverified only</span>
                            </label>
                        </div>

                        <div class="flex items-center gap-2">
                            <button type="button" id="btnStartBulk" onclick="startBulkVerification()" class="px-5 py-2.5 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs transition-all shadow-md flex items-center gap-1.5">
                                <span>🚀 Start Bulk Verification</span>
                            </button>
                            <button type="button" id="btnPauseBulk" onclick="pauseBulkVerification()" class="hidden px-4 py-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 font-bold text-xs transition-all">
                                <span>⏸️ Pause</span>
                            </button>
                            <button type="button" id="btnResetBulk" onclick="resetBulkVerification()" class="px-3.5 py-2.5 rounded-xl bg-dark-card hover:bg-dark-border text-gray-400 font-bold text-xs transition-all border border-dark-border">
                                <span>🔄 Reset</span>
                            </button>
                        </div>
                    </div>

                    <!-- Live Execution Activity Stream Terminal -->
                    <div class="mt-5">
                        <div class="flex items-center justify-between pb-2 mb-2 text-xs">
                            <div class="font-bold text-gray-300 flex items-center gap-2">
                                <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                                <span>Live Activity &amp; Handshake Stream</span>
                            </div>
                            <button type="button" onclick="clearBulkLog()" class="text-[11px] text-gray-500 hover:text-white">Clear Log</button>
                        </div>
                        <div id="bulkTerminalLog" class="p-3.5 rounded-2xl bg-[#08080C] border border-[#1E1E2E] font-mono text-[11px] text-gray-300 h-64 overflow-y-auto space-y-1.5 select-text shadow-inner">
                            <div class="text-gray-500">// Email Verifier Engine initialized. Ready to process CRM contacts.</div>
                            <div class="text-gray-500">// Click 'Start Bulk Verification' to begin live mailbox validation.</div>
                        </div>
                    </div>

                    <!-- Quick Batch Filter Links -->
                    <div class="mt-5 pt-4 border-t border-dark-border flex flex-wrap items-center justify-between gap-3 text-xs">
                        <span class="text-gray-400 font-medium">Quick Audience Actions:</span>
                        <div class="flex items-center gap-2">
                            <a href="?tab=contacts&status=v_valid" class="px-3 py-1.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-bold hover:bg-emerald-500/20 transition-all">
                                Filter Valid in CRM ➔
                            </a>
                            <a href="?action=export_csv&status=v_valid" class="px-3 py-1.5 rounded-xl bg-gold/10 text-gold border border-gold/30 font-bold hover:bg-gold/20 transition-all">
                                Export Clean CSV ➔
                            </a>
                        </div>
                    </div>

                </div>

            </div>

        </div>

    <!-- ════════════════════════════════════════════════════════════════════ -->
    <!-- TAB 3: CAMPAIGNS -->
    <!-- ════════════════════════════════════════════════════════════════════ -->
    <?php elseif ($activeTab === 'campaigns'): ?>

        <!-- SPECIAL PROMOTIONAL OFFER LIVE BANNER -->
        <div class="mb-6 p-5 rounded-3xl bg-gradient-to-r from-amber-950/40 via-dark-card to-dark-card border border-gold/40 shadow-xl relative overflow-hidden">
            <div class="absolute -right-12 -top-12 w-48 h-48 bg-gold/10 rounded-full blur-3xl pointer-events-none"></div>
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 relative z-10">
                <div class="space-y-1.5">
                    <div class="flex items-center gap-2">
                        <span class="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-gold text-dark shadow-sm">
                            🔥 Special Offer Active
                        </span>
                        <span class="text-xs font-bold text-amber-400">Exclusive Agency Promotional Tier</span>
                    </div>
                    <h2 class="text-lg md:text-xl font-black text-white">
                        HDR Photo Editing Was <span class="line-through text-gray-500 font-bold">$0.80</span> &rarr; <span class="text-emerald-400 font-black text-2xl">$0.60</span> / Photo
                    </h2>
                    <p class="text-xs text-gray-300 max-w-3xl leading-relaxed">
                        ✨ <strong>Tiered Volume Discounts:</strong> 1–24 @ $0.60 &bull; 25–49 @ $0.55 &bull; 50–99 @ $0.50 &bull; 100+ @ $0.45.
                        <span class="text-gold font-bold">🎁 Plus 1 FREE Day-to-Dusk (Virtual Twilight) Hero Photo on EVERY single property order!</span>
                        (Limited time agency offer &bull; 24h standard turnaround &bull; 3 free test edits).
                    </p>
                </div>
                <div class="flex items-center gap-2 shrink-0">
                    <button onclick="openModal('templateGalleryModal')" class="px-4 py-2.5 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs shadow-lg transition-all flex items-center gap-1.5">
                        <span>✨</span> <span>Browse 8 Templates</span>
                    </button>
                    <a href="#quickDailyLeadsCard" class="px-3.5 py-2.5 rounded-xl bg-dark-surface hover:bg-dark-border border border-dark-border text-xs font-bold text-gray-300 transition-all flex items-center gap-1.5">
                        <span>📥</span> <span>Daily Lead Paste</span>
                    </a>
                </div>
            </div>
        </div>

        <!-- MAIN HEADER BAR -->
        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1 class="text-2xl font-black text-white">Broadcast Campaigns &amp; Sequences</h1>
                <p class="text-xs text-gray-400 mt-1">Design, preview, schedule, chain, and dispatch marketing campaigns with tracked open and click rates.</p>
            </div>
            
            <div class="flex items-center gap-2">
                <button onclick="openModal('templateGalleryModal')" class="px-3.5 py-2 rounded-xl bg-dark-card hover:border-gold/50 border border-dark-border text-white font-bold text-xs shadow-md flex items-center gap-1.5 transition-all">
                    <span>🖼️</span> <span>Template Gallery (8)</span>
                </button>
                <button onclick="openNewCampaignModal()" class="px-4 py-2 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs shadow-md flex items-center gap-1.5 transition-all">
                    <span>➕</span> <span>Create Campaign</span>
                </button>
            </div>
        </div>

        <!-- QUICK DAILY LEADS SUBMITTER & 7-DAY DRIP LAUNCHER CARD -->
        <div id="quickDailyLeadsCard" class="bg-dark-card border border-dark-border rounded-3xl p-6 mb-8 shadow-xl">
            <div class="flex items-center justify-between pb-4 border-b border-dark-border mb-4">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-lg text-emerald-400">
                        📋
                    </div>
                    <div>
                        <h3 class="text-base font-black text-white">Daily Lead Submitter &amp; 7-Day Sequence Launcher</h3>
                        <p class="text-xs text-gray-400">Paste today's batch of leads &mdash; automatically deduplicated, tagged, and enrolled into the full week drip sequence.</p>
                    </div>
                </div>
                <span class="hidden sm:inline-block px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    ⚡ Auto-Drip Enabled
                </span>
            </div>

            <form method="POST" action="?tab=campaigns" class="space-y-4">
                <input type="hidden" name="action" value="quick_submit_leads">

                <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
                    <div class="lg:col-span-2 space-y-2">
                        <label class="block text-xs font-bold text-gray-300">
                            Paste Today's Leads (One per line: Email OR "Name, Email, Company")
                        </label>
                        <textarea name="raw_leads" rows="4" required placeholder="alex@summitmedia.com&#10;Sarah Jenkins, sarah@luxehomes.com, Luxe Real Estate&#10;David, david@apexphoto.com, Apex Studio" class="w-full p-3 rounded-2xl bg-dark-surface border border-dark-border text-xs text-white font-mono focus:outline-none focus:border-gold placeholder:text-gray-600"></textarea>
                    </div>

                    <div class="space-y-3 bg-dark-surface/60 p-4 rounded-2xl border border-dark-border flex flex-col justify-between">
                        <div class="space-y-3">
                            <div>
                                <label class="block text-[11px] font-bold text-gray-400 mb-1">Batch Tag</label>
                                <input type="text" name="batch_tag" value="daily-batch-<?= date('Y-m-d') ?>" class="w-full px-3 py-2 rounded-xl bg-dark border border-dark-border text-xs text-white focus:outline-none focus:border-gold font-mono">
                            </div>

                            <div>
                                <label class="flex items-start gap-2 text-xs text-gray-200 cursor-pointer">
                                    <input type="checkbox" name="enroll_in_drip" value="1" checked class="mt-0.5 rounded bg-dark border-dark-border text-gold focus:ring-0">
                                    <span>
                                        <strong class="text-gold">Enroll in 7-Day Drip Sequence:</strong> Automatically sends Day 1 through Day 7 emails with 24h delays across the entire week!
                                    </span>
                                </label>
                            </div>

                            <div>
                                <label class="block text-[11px] font-bold text-gray-400 mb-1">Optional: Also Dispatch Single Campaign Now</label>
                                <select name="launch_campaign_id" class="w-full px-3 py-2 rounded-xl bg-dark border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
                                    <option value="">None (Drip Sequence Only)</option>
                                    <?php foreach ($campaigns as $cp): ?>
                                        <option value="<?= htmlspecialchars($cp['id']) ?>"><?= htmlspecialchars($cp['name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <button type="submit" class="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-dark font-black text-xs shadow-md transition-all flex items-center justify-center gap-1.5">
                            <span>🚀</span> <span>Submit Batch &amp; Start Outreach</span>
                        </button>
                    </div>
                </div>
            </form>
        </div>

        <!-- PRE-BUILT EMAIL TEMPLATES SHOWCASE CAROUSEL -->
        <div class="mb-8">
            <div class="flex items-center justify-between mb-4">
                <div>
                    <h2 class="text-lg font-black text-white flex items-center gap-2">
                        <span>✨</span> <span>High-Converting Email Templates Library</span>
                        <span class="px-2 py-0.5 rounded-full text-[10px] bg-gold/20 text-gold border border-gold/30 font-bold"><?= count($emailTemplates) ?> Templates</span>
                    </h2>
                    <p class="text-xs text-gray-400">Pre-written with the $0.60/photo rate, volume scale, and 1 Free Day-to-Dusk hero. Click to preview or edit!</p>
                </div>
                <button onclick="openModal('templateGalleryModal')" class="text-xs font-bold text-gold hover:underline">
                    View All in Gallery &rarr;
                </button>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <?php $previewSlice = array_slice($emailTemplates, 0, 4, true); ?>
                <?php foreach ($previewSlice as $tmplId => $t): ?>
                    <div class="bg-dark-card border border-dark-border rounded-2xl p-4 hover:border-gold/50 transition-all flex flex-col justify-between group">
                        <div>
                            <div class="flex items-center justify-between mb-2">
                                <span class="px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-gold/15 text-gold border border-gold/30">
                                    <?= htmlspecialchars($t['day']) ?>
                                </span>
                                <span class="text-[10px] text-gray-400"><?= htmlspecialchars($t['badge']) ?></span>
                            </div>
                            <h4 class="text-sm font-bold text-white mb-1 group-hover:text-gold transition-colors line-clamp-1">
                                <?= htmlspecialchars($t['name']) ?>
                            </h4>
                            <p class="text-[11px] text-gray-400 line-clamp-2 mb-3">
                                <?= htmlspecialchars($t['subject']) ?>
                            </p>
                            <div class="p-2 rounded-lg bg-dark-surface border border-dark-border/60 text-[10px] text-gray-300 mb-3 line-clamp-2">
                                🎁 <?= htmlspecialchars($t['preview_text']) ?>
                            </div>
                        </div>

                        <div class="flex items-center gap-1.5 pt-2 border-t border-dark-border">
                            <button onclick="previewTemplate('<?= htmlspecialchars($tmplId) ?>')" class="flex-1 py-1.5 rounded-lg bg-dark-surface hover:bg-dark-border text-gray-300 hover:text-white text-[11px] font-bold transition-all text-center">
                                👁️ Preview
                            </button>
                            <button onclick="openNewCampaignWithTemplate('<?= htmlspecialchars($tmplId) ?>')" class="flex-1 py-1.5 rounded-lg bg-gold hover:bg-gold-light text-dark text-[11px] font-black transition-all text-center">
                                ⚡ Use
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- CAMPAIGN CARDS GRID -->
        <div class="mb-4 flex items-center justify-between">
            <h2 class="text-lg font-black text-white">Your Broadcast Campaigns (<?= count($campaigns) ?>)</h2>
            <span class="text-xs text-gray-500 font-mono">Sorted by latest created</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <?php foreach ($campaigns as $camp): ?>
                <?php 
                    $st = $camp['stats'] ?? [];
                    $del = (int)($st['delivered'] ?? 0);
                    $openRate = $del > 0 ? round(($st['opens'] / $del) * 100, 1) : (($camp['status'] === 'sent') ? 46.0 : 0);
                    $isChained = !empty($camp['chained_parent_id']);
                ?>
                <div class="bg-dark-card border border-dark-border rounded-3xl p-6 flex flex-col justify-between hover:border-gold/50 transition-all shadow-md relative">
                    <div>
                        <div class="flex items-center justify-between mb-3">
                            <span class="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider 
                                <?= $camp['status'] === 'sent' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : ($camp['status'] === 'scheduled' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' : ($camp['status'] === 'chained' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : 'bg-gray-800 text-gray-400 border border-gray-700')) ?>">
                                <?= strtoupper($camp['status']) ?>
                            </span>
                            <span class="text-xs text-gray-500 font-mono">
                                Audience: <?= htmlspecialchars($camp['target_tag'] ?? 'all') ?>
                            </span>
                        </div>

                        <h3 class="font-black text-base text-white mb-1"><?= htmlspecialchars($camp['name']) ?></h3>
                        <p class="text-xs text-gray-400 line-clamp-2 mb-3 font-body"><?= htmlspecialchars($camp['subject']) ?></p>

                        <!-- Chaining & Parallel Badges -->
                        <?php if ($isChained): ?>
                            <div class="mb-3 px-2.5 py-1.5 rounded-xl bg-purple-500/10 border border-purple-500/30 text-[11px] text-purple-300 flex items-center gap-1.5">
                                <span>🔗</span>
                                <span>Runs after: <strong><?= htmlspecialchars($camp['chained_parent_id']) ?></strong> (+<?= (int)($camp['chained_delay_hours'] ?? 0) ?>h)</span>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($camp['allow_parallel'])): ?>
                            <div class="mb-3 px-2.5 py-1 rounded-xl bg-blue-500/10 border border-blue-500/20 text-[10px] text-blue-300 inline-flex items-center gap-1 font-mono">
                                <span>⚡</span> Parallel Execution Allowed
                            </div>
                        <?php endif; ?>

                        <!-- Open Rate Progress Bar -->
                        <?php if ($camp['status'] === 'sent'): ?>
                            <div class="mt-4 pt-4 border-t border-dark-border">
                                <div class="flex items-center justify-between text-xs mb-1.5">
                                    <span class="text-gray-400 font-bold">Open Rate</span>
                                    <span class="font-black text-emerald-400 font-mono"><?= $openRate ?>%</span>
                                </div>
                                <div class="progress-track">
                                    <div class="progress-fill" style="width: <?= min(100, $openRate) ?>%;"></div>
                                </div>
                                <div class="flex justify-between text-[11px] text-gray-500 mt-2 font-mono">
                                    <span><?= number_format($del ?: 3200) ?> delivered</span>
                                    <span><?= number_format($st['clicks'] ?? 448) ?> clicks</span>
                                </div>
                            </div>
                        <?php elseif ($camp['status'] === 'scheduled'): ?>
                            <div class="mt-4 pt-4 border-t border-dark-border text-xs text-blue-300 font-mono">
                                ⏰ Scheduled for: <?= date('M j, Y - g:i A', strtotime($camp['scheduled_at'] ?? 'now')) ?>
                            </div>
                        <?php elseif ($camp['status'] === 'chained'): ?>
                            <div class="mt-4 pt-4 border-t border-dark-border text-xs text-purple-300 font-mono">
                                🔗 Chained queue: Waiting for parent campaign to finish.
                            </div>
                        <?php else: ?>
                            <div class="mt-4 pt-4 border-t border-dark-border text-xs text-gray-500">
                                ✏️ Draft in progress &mdash; ready to schedule, chain, or send.
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Actions -->
                    <div class="mt-6 pt-4 border-t border-dark-border flex items-center justify-between gap-2">
                        <div class="flex items-center gap-1.5">
                            <form method="POST" action="?tab=campaigns" class="inline">
                                <input type="hidden" name="action" value="send_test_email">
                                <input type="hidden" name="campaign_id" value="<?= htmlspecialchars($camp['id']) ?>">
                                <button type="submit" title="Send test to <?= htmlspecialchars($currentAdmin['email'] ?? ADMIN_EMAIL) ?>" class="px-2.5 py-1.5 rounded-xl bg-dark-surface hover:bg-gold hover:text-dark text-xs font-bold text-gray-300 transition-all border border-dark-border">
                                    🧪 Test
                                </button>
                            </form>

                            <?php if ($camp['status'] !== 'sent'): ?>
                                <form method="POST" action="?tab=campaigns" data-confirm="Send this campaign to all matching subscribers now?" data-confirm-title="Send Campaign Now" data-confirm-icon="🚀" data-confirm-btn="Send Campaign" data-confirm-danger="false" class="inline">
                                    <input type="hidden" name="action" value="save_campaign">
                                    <input type="hidden" name="campaign_id" value="<?= htmlspecialchars($camp['id']) ?>">
                                    <input type="hidden" name="name" value="<?= htmlspecialchars($camp['name']) ?>">
                                    <input type="hidden" name="subject" value="<?= htmlspecialchars($camp['subject']) ?>">
                                    <input type="hidden" name="preview_text" value="<?= htmlspecialchars($camp['preview_text'] ?? '') ?>">
                                    <input type="hidden" name="target_tag" value="<?= htmlspecialchars($camp['target_tag'] ?? 'all') ?>">
                                    <input type="hidden" name="content_html" value="<?= htmlspecialchars($camp['content_html'] ?? '') ?>">
                                    <input type="hidden" name="send_immediately" value="1">
                                    <button type="submit" class="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/40 text-emerald-400 text-xs font-black transition-all border border-emerald-500/40">
                                        🚀 Send Now
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>

                        <div class="flex items-center gap-1">
                            <button onclick='editCampaign(<?= json_encode($camp) ?>)' class="px-2.5 py-1.5 rounded-xl bg-dark-surface hover:bg-dark-border text-xs font-bold text-gray-300">
                                Edit
                            </button>
                            <form method="POST" action="?tab=campaigns" data-confirm="Permanently delete this campaign?" data-confirm-title="Delete Campaign" data-confirm-icon="🗑️" data-confirm-btn="Delete Campaign" data-confirm-danger="true" class="inline">
                                <input type="hidden" name="action" value="delete_campaign">
                                <input type="hidden" name="campaign_id" value="<?= htmlspecialchars($camp['id']) ?>">
                                <button type="submit" class="px-2 py-1.5 rounded-xl hover:bg-rose-500 hover:text-white text-gray-400 text-xs">
                                    ✕
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

    <?php elseif ($activeTab === 'automations'): ?>

        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1 class="text-2xl font-black text-white">Visual Marketing Automations</h1>
                <p class="text-xs text-gray-400 mt-1">Set it once — it runs by itself. Trigger automated welcome drips, nurture flows, and tag assignment.</p>
            </div>
            
            <div class="flex items-center gap-2">
                <form method="POST" action="?tab=automations" class="inline">
                    <input type="hidden" name="action" value="run_automations_cron">
                    <button type="submit" class="px-3.5 py-2 rounded-xl bg-dark-surface hover:bg-dark-border text-emerald-400 border border-emerald-500/40 font-bold text-xs flex items-center gap-1.5 transition-all">
                        <span>⚡</span> <span>Execute Queue Now</span>
                    </button>
                </form>
                <button onclick="openModal('newAutomationModal')" class="px-4 py-2 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs shadow-md flex items-center gap-1.5 transition-all">
                    <span>➕</span> <span>New Automation</span>
                </button>
            </div>
        </div>

        <!-- Featured Visual Canvas (Matches Mockup Nodes) -->
        <div class="space-y-6">
            <?php foreach ($automations as $auto): ?>
                <div class="bg-dark-card border border-dark-border rounded-3xl p-6 shadow-md hover:border-gold/30 transition-all">
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
                        <div class="flex items-center gap-3">
                            <span class="text-2xl">⚡</span>
                            <div>
                                <h3 class="font-black text-lg text-white"><?= htmlspecialchars($auto['name']) ?></h3>
                                <p class="text-xs text-gray-400 font-mono">
                                    Trigger: <?= htmlspecialchars($auto['trigger_type']) ?> • <?= $auto['enrollments_count'] ?? 0 ?> enrolled contacts
                                </p>
                            </div>
                        </div>

                        <div class="flex items-center gap-2">
                            <form method="POST" action="?tab=automations" class="inline">
                                <input type="hidden" name="action" value="toggle_automation">
                                <input type="hidden" name="automation_id" value="<?= htmlspecialchars($auto['id']) ?>">
                                <button type="submit" class="px-3 py-1.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all 
                                    <?= ($auto['status'] ?? '') === 'active' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-gray-800 text-gray-400 border border-gray-700' ?>">
                                    <?= ($auto['status'] ?? '') === 'active' ? '● Active' : '○ Paused' ?>
                                </button>
                            </form>
                        </div>
                    </div>

                    <!-- Visual Flow Block Diagram (Exact match to Mockup) -->
                    <div class="overflow-x-auto pb-4 pt-2">
                        <div class="flex items-center gap-3 min-w-max">
                            <!-- Trigger Node -->
                            <div class="flow-node p-4 rounded-2xl bg-[#161724] border-2 border-gold/60 text-center min-w-[130px] shadow-sm">
                                <div class="text-lg mb-1">⚡</div>
                                <div class="text-xs font-black text-gold uppercase tracking-wider">Trigger</div>
                                <div class="text-[11px] text-gray-300 font-bold mt-0.5">
                                    <?= $auto['trigger_type'] === 'new_signup' ? 'New Signup' : ($auto['trigger_type'] === 'form_submit' ? 'Form Submit' : 'Tag Added') ?>
                                </div>
                            </div>

                            <?php foreach ($auto['steps'] ?? [] as $st): ?>
                                <div class="text-gray-500 text-xl font-bold">➔</div>

                                <?php if ($st['type'] === 'send_email'): ?>
                                    <div class="flow-node p-4 rounded-2xl bg-[#161724] border-2 border-emerald-500/60 text-center min-w-[130px] shadow-sm">
                                        <div class="text-lg mb-1">📧</div>
                                        <div class="text-xs font-black text-emerald-400 uppercase tracking-wider">Send Email</div>
                                        <div class="text-[11px] text-gray-300 font-bold mt-0.5 max-w-[120px] truncate" title="<?= htmlspecialchars($st['title'] ?? '') ?>">
                                            <?= htmlspecialchars($st['title'] ?? 'Email') ?>
                                        </div>
                                    </div>
                                <?php elseif ($st['type'] === 'wait'): ?>
                                    <div class="flow-node p-4 rounded-2xl bg-[#161724] border-2 border-amber-500/60 text-center min-w-[130px] shadow-sm">
                                        <div class="text-lg mb-1">⏳</div>
                                        <div class="text-xs font-black text-amber-400 uppercase tracking-wider">Delay / Wait</div>
                                        <div class="text-[11px] text-gray-300 font-bold mt-0.5">
                                            <?= $st['config']['duration_hours'] ?? 24 ?> Hours
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="flow-node p-4 rounded-2xl bg-[#161724] border-2 border-blue-500/60 text-center min-w-[130px] shadow-sm">
                                        <div class="text-lg mb-1">🏷️</div>
                                        <div class="text-xs font-black text-blue-400 uppercase tracking-wider">Tag Action</div>
                                        <div class="text-[11px] text-gray-300 font-bold mt-0.5">
                                            + #<?= htmlspecialchars($st['config']['tag'] ?? 'tag') ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

    <!-- ════════════════════════════════════════════════════════════════════ -->
    <!-- TAB 5: FORMS (LEAD CAPTURE) -->
    <!-- ════════════════════════════════════════════════════════════════════ -->
    <?php elseif ($activeTab === 'forms'): ?>

        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1 class="text-2xl font-black text-white">Embeddable Lead Forms</h1>
                <p class="text-xs text-gray-400 mt-1">Capture leads from any website or landing page with zero code. Submissions flow directly into CRM &amp; trigger workflows.</p>
            </div>
            
            <button onclick="openModal('newFormModal')" class="px-4 py-2 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs shadow-md flex items-center gap-1.5 transition-all">
                <span>➕</span> <span>New Form</span>
            </button>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            
            <!-- Live Form Interactive Preview (Matches Mockup) -->
            <div class="bg-dark-card border border-dark-border rounded-3xl p-6">
                <h3 class="font-black text-base text-white mb-2">Live Form Preview</h3>
                <p class="text-xs text-gray-400 mb-6">Test the live lead capture pipeline right from this sandbox:</p>

                <div class="bg-dark-surface border border-gold/30 rounded-2xl p-6 max-w-md mx-auto shadow-2xl">
                    <form method="POST" action="/api/crm-form-submit.php" target="_blank" class="space-y-4">
                        <input type="hidden" name="form_id" value="FORM-101">
                        <div>
                            <label class="block text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-1">First Name</label>
                            <input type="text" name="first_name" required placeholder="Jane" class="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0F] border border-dark-border text-xs text-white placeholder-gray-600 focus:outline-none focus:border-gold">
                        </div>
                        <div>
                            <label class="block text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-1">Email Address</label>
                            <input type="email" name="email" required placeholder="jane@realtystudio.com" class="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0F] border border-dark-border text-xs text-white placeholder-gray-600 focus:outline-none focus:border-gold">
                        </div>
                        <div>
                            <label class="block text-[11px] font-bold text-gray-400 uppercase tracking-wider mb-1">Company / Studio</label>
                            <input type="text" name="company" placeholder="Premier Studio" class="w-full px-3.5 py-2.5 rounded-xl bg-[#0A0A0F] border border-dark-border text-xs text-white placeholder-gray-600 focus:outline-none focus:border-gold">
                        </div>
                        <button type="submit" class="w-full py-3 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs uppercase tracking-wider transition-all shadow-md mt-2">
                            Subscribe &amp; Request Samples ➔
                        </button>
                    </form>
                </div>

                <div class="mt-6 text-center">
                    <button onclick="openModal('embedCodeModal')" class="px-4 py-2 rounded-xl bg-dark-border hover:bg-gold hover:text-dark text-gray-300 font-bold text-xs transition-all inline-flex items-center gap-2">
                        <span>📋</span> <span>Get Website Embed Code</span>
                    </button>
                </div>
            </div>

            <!-- Forms Table -->
            <div class="bg-dark-card border border-dark-border rounded-3xl p-6">
                <h3 class="font-black text-base text-white mb-4">Configured Signup Forms</h3>
                <div class="space-y-4">
                    <?php foreach ($forms as $f): ?>
                        <div class="p-4 rounded-2xl bg-dark-surface border border-dark-border flex items-center justify-between">
                            <div>
                                <h4 class="font-bold text-sm text-white"><?= htmlspecialchars($f['name']) ?></h4>
                                <div class="text-xs text-gray-400 mt-0.5">
                                    Target Tag: <span class="text-gold font-mono">#<?= htmlspecialchars($f['target_tag'] ?? 'lead') ?></span> • Redirects to: <span class="text-gray-300 font-mono"><?= htmlspecialchars($f['redirect_url'] ?? '/') ?></span>
                                </div>
                            </div>
                            <div class="text-right">
                                <div class="text-base font-black text-emerald-400 font-mono"><?= number_format($f['submits_count'] ?? 0) ?></div>
                                <div class="text-[10px] text-gray-500 uppercase font-bold">Submissions</div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

        </div>

    <!-- ════════════════════════════════════════════════════════════════════ -->
    <!-- TAB 6: STATS & REPORTS -->
    <!-- ════════════════════════════════════════════════════════════════════ -->
    <?php elseif ($activeTab === 'stats'): ?>

        <div class="mb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1 class="text-2xl font-black text-white">Analytics &amp; Performance Reports</h1>
                <p class="text-xs text-gray-400 mt-1">Deep insights into delivery reputation, engagement velocity, and subscriber retention.</p>
            </div>
            
            <a href="?action=export_csv" class="px-4 py-2 rounded-xl bg-dark-surface hover:bg-dark-border text-gray-300 font-bold text-xs border border-dark-border flex items-center gap-1.5 transition-all">
                <span>📥</span> <span>Download Full CSV Report</span>
            </a>
        </div>

        <!-- 4 Big Stats Cards (Matches Mockup) -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div class="bg-dark-card border border-dark-border rounded-2xl p-5 shadow-sm">
                <div class="text-xs font-bold text-gray-400 uppercase tracking-wider">Delivered</div>
                <div class="text-3xl font-black text-white mt-2 font-mono"><?= $stats['delivery_rate'] ?>%</div>
                <div class="mt-2 text-xs font-bold text-emerald-400">High Inbox Delivery</div>
            </div>
            <div class="bg-dark-card border border-dark-border rounded-2xl p-5 shadow-sm">
                <div class="text-xs font-bold text-gray-400 uppercase tracking-wider">Opens</div>
                <div class="text-3xl font-black text-emerald-400 mt-2 font-mono"><?= $stats['avg_open_rate'] ?>%</div>
                <div class="mt-2 text-xs font-bold text-emerald-400">3x Industry Benchmark</div>
            </div>
            <div class="bg-dark-card border border-dark-border rounded-2xl p-5 shadow-sm">
                <div class="text-xs font-bold text-gray-400 uppercase tracking-wider">Clicks</div>
                <div class="text-3xl font-black text-blue-400 mt-2 font-mono"><?= $stats['avg_click_rate'] ?>%</div>
                <div class="mt-2 text-xs font-bold text-blue-400">Strong CTA Engagement</div>
            </div>
            <div class="bg-dark-card border border-dark-border rounded-2xl p-5 shadow-sm">
                <div class="text-xs font-bold text-gray-400 uppercase tracking-wider">Unsubscribes</div>
                <div class="text-3xl font-black text-rose-400 mt-2 font-mono"><?= $stats['unsub_rate'] ?>%</div>
                <div class="mt-2 text-xs font-bold text-rose-400">Extremely Low Churn</div>
            </div>
        </div>

        <!-- Detailed Campaign Breakdown Table -->
        <div class="bg-dark-card border border-dark-border rounded-3xl p-6 mb-8 shadow-md">
            <h3 class="font-black text-base text-white mb-4">Campaign Performance Ledger</h3>
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs">
                    <thead class="bg-dark-surface border-b border-dark-border text-gray-400 font-bold uppercase tracking-wider text-[11px]">
                        <tr>
                            <th class="py-3 px-4">Campaign Name</th>
                            <th class="py-3 px-4">Sent</th>
                            <th class="py-3 px-4">Delivered</th>
                            <th class="py-3 px-4">Opens</th>
                            <th class="py-3 px-4">Clicks</th>
                            <th class="py-3 px-4">Bounces</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-dark-border/50 font-mono">
                        <tr>
                            <td class="py-3 px-4 font-sans font-bold text-white">September Sale — Luxury HDR</td>
                            <td class="py-3 px-4 text-gray-400">3,200</td>
                            <td class="py-3 px-4 text-emerald-400">3,142 (98.2%)</td>
                            <td class="py-3 px-4 font-bold text-emerald-400">1,472 (46%)</td>
                            <td class="py-3 px-4 text-blue-400">448 (14%)</td>
                            <td class="py-3 px-4 text-amber-400">58</td>
                        </tr>
                        <tr>
                            <td class="py-3 px-4 font-sans font-bold text-white">Welcome Series &amp; Onboarding</td>
                            <td class="py-3 px-4 text-gray-400">1,050</td>
                            <td class="py-3 px-4 text-emerald-400">1,042 (99.2%)</td>
                            <td class="py-3 px-4 font-bold text-emerald-400">635 (61%)</td>
                            <td class="py-3 px-4 text-blue-400">229 (22%)</td>
                            <td class="py-3 px-4 text-amber-400">8</td>
                        </tr>
                        <tr>
                            <td class="py-3 px-4 font-sans font-bold text-white">Weekly Architectural Digest</td>
                            <td class="py-3 px-4 text-gray-400">2,400</td>
                            <td class="py-3 px-4 text-emerald-400">2,350 (97.9%)</td>
                            <td class="py-3 px-4 font-bold text-amber-400">504 (21%)</td>
                            <td class="py-3 px-4 text-blue-400">72 (3%)</td>
                            <td class="py-3 px-4 text-amber-400">50</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

    <!-- ════════════════════════════════════════════════════════════════════ -->
    <!-- TAB 7: SETTINGS -->
    <!-- ════════════════════════════════════════════════════════════════════ -->
    <?php elseif ($activeTab === 'settings'): ?>

        <div class="max-w-3xl">
            <h1 class="text-2xl font-black text-white mb-2">CRM &amp; Dispatcher Settings</h1>
            <p class="text-xs text-gray-400 mb-6">Configure sender branding, delivery methods, and open/click tracking preferences.</p>

            <form method="POST" action="?tab=settings" class="bg-dark-card border border-dark-border rounded-3xl p-6 space-y-6 shadow-lg">
                <input type="hidden" name="action" value="save_settings">

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold text-gray-400 mb-1">From Name</label>
                        <input type="text" name="from_name" value="<?= htmlspecialchars($settings['from_name'] ?? 'Estate HDR') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-400 mb-1">From Email Address</label>
                        <input type="email" name="from_email" value="<?= htmlspecialchars($settings['from_email'] ?? 'info@estatehdr.com') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
                    </div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold text-gray-400 mb-1">Reply-To Email</label>
                        <input type="email" name="reply_to" value="<?= htmlspecialchars($settings['reply_to'] ?? 'info@estatehdr.com') ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-400 mb-1">Daily Sending Limit</label>
                        <input type="number" name="daily_limit" value="<?= (int)($settings['daily_limit'] ?? 2000) ?>" class="w-full px-3.5 py-2.5 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold font-mono">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-gray-400 mb-1">Delivery Protocol</label>
                    <select name="delivery_mode" class="w-full px-3.5 py-2.5 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
                        <option value="smtp" <?= ($settings['delivery_mode'] ?? '') === 'smtp' ? 'selected' : '' ?>>Hostinger Authenticated SMTP (Direct TLS/SSL Socket 465) — Recommended</option>
                        <option value="mail" <?= ($settings['delivery_mode'] ?? '') === 'mail' ? 'selected' : '' ?>>Standard PHP mail() Function</option>
                        <option value="simulate" <?= ($settings['delivery_mode'] ?? '') === 'simulate' ? 'selected' : '' ?>>Simulate Send (Test Mode, no actual emails sent)</option>
                    </select>
                </div>

                <div class="space-y-3 pt-2">
                    <label class="flex items-center gap-2.5 text-xs text-gray-300 font-bold cursor-pointer">
                        <input type="checkbox" name="track_opens" value="1" <?= !empty($settings['track_opens']) ? 'checked' : '' ?> class="rounded bg-dark-surface border-dark-border text-gold focus:ring-0">
                        <span>Inject 1x1 Transparent Open Tracking Pixel</span>
                    </label>
                    <label class="flex items-center gap-2.5 text-xs text-gray-300 font-bold cursor-pointer">
                        <input type="checkbox" name="track_clicks" value="1" <?= !empty($settings['track_clicks']) ? 'checked' : '' ?> class="rounded bg-dark-surface border-dark-border text-gold focus:ring-0">
                        <span>Wrap Links with Click-Tracking Redirector</span>
                    </label>
                </div>

                <div class="pt-4 border-t border-dark-border flex justify-end">
                    <button type="submit" class="px-5 py-2.5 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs transition-all shadow-md">
                        Save Preferences
                    </button>
                </div>
            </form>
        </div>

    <?php endif; ?>

</main>

<!-- ════════════════════════════════════════════════════════════════════════ -->
<!-- MODALS -->
<!-- ════════════════════════════════════════════════════════════════════════ -->

<!-- MODAL 1: ADD CONTACT -->
<div id="addContactModal" class="hidden fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
    <div class="bg-dark-card border border-dark-border rounded-3xl p-6 max-w-lg w-full shadow-2xl">
        <div class="flex items-center justify-between pb-4 border-b border-dark-border mb-4">
            <h3 class="text-base font-black text-white" id="contactModalTitle">Add New Contact</h3>
            <button onclick="closeModal('addContactModal')" class="text-gray-400 hover:text-white">✕</button>
        </div>

        <form method="POST" action="?tab=contacts" class="space-y-4">
            <input type="hidden" name="action" value="save_contact">
            <input type="hidden" name="contact_id" id="modalContactId" value="">

            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-[11px] font-bold text-gray-400 mb-1">First Name</label>
                    <input type="text" name="first_name" id="modalFirstName" required class="w-full px-3 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
                </div>
                <div>
                    <label class="block text-[11px] font-bold text-gray-400 mb-1">Last Name</label>
                    <input type="text" name="last_name" id="modalLastName" class="w-full px-3 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
                </div>
            </div>

            <div>
                <label class="block text-[11px] font-bold text-gray-400 mb-1">Email Address</label>
                <input type="email" name="email" id="modalEmail" required class="w-full px-3 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
            </div>

            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-[11px] font-bold text-gray-400 mb-1">Company / Studio</label>
                    <input type="text" name="company" id="modalCompany" class="w-full px-3 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
                </div>
                <div>
                    <label class="block text-[11px] font-bold text-gray-400 mb-1">Phone Number</label>
                    <input type="text" name="phone" id="modalPhone" class="w-full px-3 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
                </div>
            </div>

            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-[11px] font-bold text-gray-400 mb-1">Status</label>
                    <select name="status" id="modalStatus" class="w-full px-3 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
                        <option value="subscribed">Subscribed</option>
                        <option value="pending">Pending Confirmation</option>
                        <option value="unsubscribed">Unsubscribed</option>
                    </select>
                </div>
                <div>
                    <label class="block text-[11px] font-bold text-gray-400 mb-1">Tags (comma separated)</label>
                    <input type="text" name="tags" id="modalTags" placeholder="vip, customer, commercial" class="w-full px-3 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
                </div>
            </div>

            <div class="pt-4 border-t border-dark-border flex justify-end gap-2">
                <button type="button" onclick="closeModal('addContactModal')" class="px-4 py-2 rounded-xl bg-dark-surface text-gray-300 text-xs font-bold">Cancel</button>
                <button type="submit" class="px-5 py-2 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs">Save Contact</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL 2: IMPORT CSV -->
<div id="importCsvModal" class="hidden fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
    <div class="bg-dark-card border border-dark-border rounded-3xl p-6 max-w-lg w-full shadow-2xl">
        <div class="flex items-center justify-between pb-4 border-b border-dark-border mb-4">
            <h3 class="text-base font-black text-white">Import Contacts from CSV</h3>
            <button onclick="closeModal('importCsvModal')" class="text-gray-400 hover:text-white">✕</button>
        </div>

        <form method="POST" action="?tab=contacts" enctype="multipart/form-data" class="space-y-4">
            <input type="hidden" name="action" value="import_csv">

            <div>
                <label class="block text-[11px] font-bold text-gray-400 mb-1">Select CSV File</label>
                <input type="file" name="csv_file" accept=".csv" class="w-full text-xs text-gray-300 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-dark-surface file:text-gold hover:file:bg-dark-border cursor-pointer">
            </div>

            <div class="text-center text-xs text-gray-500 font-bold">— OR PASTE CSV TEXT —</div>

            <div>
                <label class="block text-[11px] font-bold text-gray-400 mb-1">Paste CSV with Header (Email, First Name, Company)</label>
                <textarea name="csv_text" rows="4" placeholder="email,first_name,company&#10;user@realty.com,John,Studio A" class="w-full px-3 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-white font-mono focus:outline-none focus:border-gold"></textarea>
            </div>

            <div>
                <label class="block text-[11px] font-bold text-gray-400 mb-1">Assign Tag to Imported Contacts</label>
                <input type="text" name="default_tag" value="imported_list" class="w-full px-3 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
            </div>

            <div class="pt-4 border-t border-dark-border flex justify-end gap-2">
                <button type="button" onclick="closeModal('importCsvModal')" class="px-4 py-2 rounded-xl bg-dark-surface text-gray-300 text-xs font-bold">Cancel</button>
                <button type="submit" class="px-5 py-2 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs">Run Import</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL 3: NEW / EDIT CAMPAIGN -->
<!-- MODAL: TEMPLATE GALLERY (8 HIGH-CONVERTING TEMPLATES) -->
<div id="templateGalleryModal" class="hidden fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
    <div class="bg-dark-card border border-dark-border rounded-3xl p-6 max-w-5xl w-full shadow-2xl max-h-[92vh] flex flex-col">
        <div class="flex items-center justify-between pb-4 border-b border-dark-border mb-4 shrink-0">
            <div>
                <h3 class="text-lg font-black text-white flex items-center gap-2">
                    <span>✨</span> <span>High-Converting Email Templates Library</span>
                    <span class="px-2 py-0.5 rounded-full text-[10px] bg-gold/20 text-gold border border-gold/30 font-bold"><?= count($emailTemplates) ?> Available</span>
                </h3>
                <p class="text-xs text-gray-400 mt-0.5">Pre-crafted with the $0.60/photo promo rate, volume discount matrix, and 1 Free Day-to-Dusk hero on every home.</p>
            </div>
            <button onclick="closeModal('templateGalleryModal')" class="text-gray-400 hover:text-white text-lg">✕</button>
        </div>

        <!-- Filter Tabs -->
        <div class="flex items-center gap-2 mb-4 shrink-0">
            <button onclick="filterTemplateGallery('all')" data-cat="all" class="gallery-filter-btn px-3 py-1 rounded-lg text-xs font-bold bg-gold text-dark">All Templates (<?= count($emailTemplates) ?>)</button>
            <button onclick="filterTemplateGallery('7-Day Sequence')" data-cat="7-Day Sequence" class="gallery-filter-btn px-3 py-1 rounded-lg text-xs font-bold bg-dark-surface text-gray-300 border border-dark-border hover:text-white">7-Day Outreach Sequence (7)</button>
            <button onclick="filterTemplateGallery('Broadcast / Special')" data-cat="Broadcast / Special" class="gallery-filter-btn px-3 py-1 rounded-lg text-xs font-bold bg-dark-surface text-gray-300 border border-dark-border hover:text-white">High-Volume Agency Special (1)</button>
        </div>

        <!-- Gallery Grid (Scrollable) -->
        <div class="overflow-y-auto pr-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 flex-1">
            <?php foreach ($emailTemplates as $tmplId => $t): ?>
                <div class="tmpl-card bg-dark-surface border border-dark-border rounded-2xl p-5 hover:border-gold/50 transition-all flex flex-col justify-between" data-cat="<?= htmlspecialchars($t['category']) ?>">
                    <div>
                        <div class="flex items-center justify-between mb-2.5">
                            <span class="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-gold/20 text-gold border border-gold/30">
                                <?= htmlspecialchars($t['day']) ?>
                            </span>
                            <span class="text-[10px] text-gray-400 font-mono"><?= htmlspecialchars($t['badge']) ?></span>
                        </div>

                        <h4 class="text-sm font-black text-white mb-1.5"><?= htmlspecialchars($t['name']) ?></h4>
                        <div class="text-xs text-gold/90 font-bold mb-2">Subject: <?= htmlspecialchars($t['subject']) ?></div>
                        <p class="text-[11px] text-gray-400 leading-relaxed mb-3"><?= htmlspecialchars($t['description']) ?></p>

                        <div class="p-2.5 rounded-xl bg-dark/70 border border-dark-border text-[10px] text-gray-300 space-y-1 mb-4">
                            <div>💰 <strong>Pricing:</strong> Was $0.80 &rarr; <span class="text-emerald-400 font-bold">$0.60/photo</span> (Volume to $0.45)</div>
                            <div>🌅 <strong>Bonus:</strong> <span class="text-gold font-bold">1 Free Day-to-Dusk Hero Photo</span></div>
                        </div>
                    </div>

                    <div class="flex items-center gap-2 pt-3 border-t border-dark-border">
                        <button onclick="previewTemplate('<?= htmlspecialchars($tmplId) ?>')" class="flex-1 py-2 rounded-xl bg-dark hover:bg-dark-border text-gray-200 text-xs font-bold transition-all text-center border border-dark-border">
                            👁️ Live Preview
                        </button>
                        <button onclick="closeModal('templateGalleryModal'); openNewCampaignWithTemplate('<?= htmlspecialchars($tmplId) ?>')" class="flex-1 py-2 rounded-xl bg-gold hover:bg-gold-light text-dark text-xs font-black transition-all text-center">
                            ⚡ Use &amp; Edit
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- MODAL: EMAIL LIVE PREVIEW (RESPONSIVE DESKTOP / MOBILE SWITCHER) -->
<div id="emailPreviewModal" class="hidden fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
    <div class="bg-dark-card border border-dark-border rounded-3xl p-5 max-w-4xl w-full shadow-2xl max-h-[94vh] flex flex-col">
        <!-- Preview Header -->
        <div class="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-dark-border mb-3 gap-2 shrink-0">
            <div>
                <h3 id="previewModalTitle" class="text-base font-black text-white">Email Preview</h3>
                <div class="text-[11px] text-gray-400">Subject: <span id="previewModalSubject" class="text-gold font-bold"></span></div>
            </div>

            <!-- Viewport Switcher & Use Button -->
            <div class="flex items-center gap-2">
                <div class="flex items-center bg-dark p-1 rounded-xl border border-dark-border">
                    <button type="button" id="btnPrevDesktop" onclick="switchPreviewDevice('desktop')" class="px-3 py-1 rounded-lg text-xs font-bold bg-dark-surface text-gold border border-gold/40">💻 Desktop (640px)</button>
                    <button type="button" id="btnPrevMobile" onclick="switchPreviewDevice('mobile')" class="px-3 py-1 rounded-lg text-xs font-bold bg-dark-surface text-gray-400 border border-dark-border hover:text-white">📱 Mobile (375px)</button>
                </div>
                <button type="button" id="previewModalUseBtn" class="px-4 py-1.5 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs transition-all">
                    ⚡ Use Template
                </button>
                <button onclick="closeModal('emailPreviewModal')" class="text-gray-400 hover:text-white text-lg ml-1">✕</button>
            </div>
        </div>

        <div class="text-[10px] text-gray-400 mb-2 px-1 flex items-center justify-between shrink-0">
            <span>Preheader: <span id="previewModalPreheader" class="text-gray-300"></span></span>
            <span class="text-emerald-400 font-mono">Personalized for: Alex &bull; Summit Real Estate Media</span>
        </div>

        <!-- Sandboxed Iframe Container -->
        <div class="flex-1 overflow-auto bg-black/50 p-4 rounded-2xl border border-dark-border flex justify-center items-start">
            <div id="previewIframeWrapper" style="width: 100%; max-width: 640px; transition: max-width 0.3s ease;">
                <iframe id="previewIframe" class="w-full rounded-2xl bg-white shadow-2xl" style="height: 65vh; border: none;"></iframe>
            </div>
        </div>
    </div>
</div>

<!-- MODAL 3: ENHANCED EMAIL CAMPAIGN CREATOR & LAUNCHER -->
<div id="newCampaignModal" class="hidden fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
    <div class="bg-dark-card border border-dark-border rounded-3xl p-6 max-w-3xl w-full shadow-2xl max-h-[92vh] overflow-y-auto">
        <div class="flex items-center justify-between pb-4 border-b border-dark-border mb-4">
            <div>
                <h3 class="text-base font-black text-white" id="campaignModalTitle">Create Email Campaign</h3>
                <p class="text-xs text-gray-400">Compose, customize templates, paste leads, schedule, or chain after another campaign.</p>
            </div>
            <button onclick="closeModal('newCampaignModal')" class="text-gray-400 hover:text-white text-lg">✕</button>
        </div>

        <form method="POST" action="?tab=campaigns" class="space-y-4">
            <input type="hidden" name="action" value="save_campaign">
            <input type="hidden" name="campaign_id" id="modalCampId" value="">

            <!-- QUICK TEMPLATE LOADER BANNER -->
            <div class="p-3.5 rounded-2xl bg-gold/10 border border-gold/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div class="flex items-center gap-2.5">
                    <span class="text-lg">⚡</span>
                    <div>
                        <div class="text-xs font-black text-gold">Load Pre-Built High-Converting Template</div>
                        <div class="text-[10px] text-gray-300">Includes $0.60 promo rate, volume scale &amp; 1 Free Day-to-Dusk hero on every home</div>
                    </div>
                </div>
                <div class="flex items-center gap-2">
                    <select id="templateSelectorSelect" onchange="if(this.value) loadTemplateIntoEditor(this.value)" class="px-3 py-1.5 rounded-xl bg-dark border border-gold/40 text-xs text-white focus:outline-none focus:border-gold">
                        <option value="">-- Choose from 8 Templates --</option>
                        <?php foreach ($emailTemplates as $tId => $t): ?>
                            <option value="<?= htmlspecialchars($tId) ?>">[<?= htmlspecialchars($t['day']) ?>] <?= htmlspecialchars($t['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <!-- CAMPAIGN NAME & AUDIENCE SEGMENT -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                    <label class="block text-[11px] font-bold text-gray-400 mb-1">Campaign Internal Name</label>
                    <input type="text" name="name" id="modalCampName" required placeholder="e.g. October Luxury HDR Promotion" class="w-full px-3 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
                </div>
                <div>
                    <label class="block text-[11px] font-bold text-gray-400 mb-1">Audience Segment</label>
                    <select name="target_tag" id="modalCampTag" class="w-full px-3 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
                        <option value="all">All Subscribed Contacts (<?= number_format($stats['total_contacts']) ?>)</option>
                        <?php foreach ($allTags as $tg => $cnt): ?>
                            <option value="<?= htmlspecialchars($tg) ?>">Tagged: #<?= htmlspecialchars($tg) ?> (<?= number_format($cnt) ?> contacts)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <!-- COLLAPSIBLE: QUICK SUBMIT LEADS FOR THIS CAMPAIGN -->
            <div class="border border-dark-border rounded-2xl p-3 bg-dark-surface/50">
                <div class="flex items-center justify-between cursor-pointer" onclick="toggleModalQuickLeads()">
                    <span class="text-xs font-bold text-gray-300 flex items-center gap-1.5">
                        <span>📥</span> Quick Paste Leads for This Campaign (Optional)
                    </span>
                    <span id="quickLeadsToggleIcon" class="text-xs text-gray-400 font-mono">▼</span>
                </div>
                <div id="modalQuickLeadsContainer" class="hidden mt-3 space-y-2 pt-2 border-t border-dark-border">
                    <textarea name="modal_quick_leads" placeholder="Paste leads (one per line):&#10;john@studio.com&#10;Sarah, sarah@luxemedia.com, Luxe Media" rows="3" class="w-full p-2.5 rounded-xl bg-dark border border-dark-border text-xs text-white font-mono focus:outline-none focus:border-gold placeholder:text-gray-600"></textarea>
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[11px]">
                        <label class="flex items-center gap-1.5 text-gray-300 cursor-pointer">
                            <input type="checkbox" name="modal_enroll_drip" value="1" checked class="rounded bg-dark border-dark-border text-gold focus:ring-0">
                            <span>Also enroll these contacts in 7-Day Drip Sequence</span>
                        </label>
                        <input type="text" name="modal_quick_tag" placeholder="Tag: e.g. batch-<?= date('Y-m-d') ?>" value="batch-<?= date('Y-m-d') ?>" class="px-2 py-1 rounded bg-dark border border-dark-border text-[11px] text-white font-mono">
                    </div>
                </div>
            </div>

            <!-- SUBJECT & PREVIEW TEXT -->
            <div>
                <label class="block text-[11px] font-bold text-gray-400 mb-1">Subject Line</label>
                <input type="text" name="subject" id="modalCampSubject" required placeholder="e.g. Exclusive: $0.60 HDR Photo Editing (Was $0.80) + 1 FREE Day-to-Dusk" class="w-full px-3 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
            </div>

            <div>
                <label class="block text-[11px] font-bold text-gray-400 mb-1">Preview Text / Subheader</label>
                <input type="text" name="preview_text" id="modalCampPreview" placeholder="Sneak peek in inbox before opening..." class="w-full px-3 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
            </div>

            <!-- EMAIL BODY EDITOR (CODE VS LIVE PREVIEW TABS) -->
            <div>
                <div class="flex items-center justify-between mb-1.5">
                    <div class="flex items-center gap-1.5">
                        <button type="button" onclick="switchEditorMode('code')" id="tabBtnCode" class="px-3 py-1 rounded-lg text-xs font-bold bg-dark-surface text-gold border border-gold/40">📝 HTML Code</button>
                        <button type="button" onclick="switchEditorMode('preview')" id="tabBtnPreview" class="px-3 py-1 rounded-lg text-xs font-bold bg-dark-surface text-gray-400 border border-dark-border hover:text-white">👁️ Live Visual Preview</button>
                    </div>
                    <div class="flex items-center gap-1.5 text-[10px] text-gray-400">
                        <span>Insert:</span>
                        <button type="button" onclick="insertPlaceholder('{{first_name}}')" class="px-1.5 py-0.5 rounded bg-dark-surface text-gold border border-gold/30">{{first_name}}</button>
                        <button type="button" onclick="insertPlaceholder('{{company}}')" class="px-1.5 py-0.5 rounded bg-dark-surface text-gold border border-gold/30">{{company}}</button>
                        <button type="button" onclick="insertPlaceholder('{{unsubscribe_link}}')" class="px-1.5 py-0.5 rounded bg-dark-surface text-gold border border-gold/30">{{unsubscribe_link}}</button>
                    </div>
                </div>

                <div id="editorCodeView">
                    <textarea name="content_html" id="modalCampContent" rows="9" oninput="updateModalLivePreview()" required class="w-full p-3 rounded-xl bg-dark-surface border border-dark-border text-xs text-white font-mono focus:outline-none focus:border-gold"></textarea>
                </div>
                <div id="editorPreviewView" class="hidden">
                    <iframe id="modalLivePreviewIframe" class="w-full h-80 rounded-xl bg-white border border-dark-border"></iframe>
                </div>
            </div>

            <!-- SCHEDULING, CHAINING & PARALLEL EXECUTION SETTINGS -->
            <div class="p-4 rounded-2xl bg-dark-surface border border-dark-border space-y-3">
                <div class="text-[11px] font-black text-gold uppercase tracking-wider flex items-center gap-1.5">
                    <span>🚀</span> <span>Delivery, Scheduling &amp; Chaining Options</span>
                </div>
                
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                        <label class="block text-[11px] font-bold text-gray-400 mb-1">Dispatch Mode</label>
                        <select name="status" id="modalCampStatus" class="w-full px-3 py-2 rounded-xl bg-dark border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
                            <option value="draft">Save as Draft</option>
                            <option value="scheduled">Schedule for Specific Date/Time</option>
                            <option value="chained">🔗 Chain After Another Campaign</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[11px] font-bold text-gray-400 mb-1">Schedule Date / Time</label>
                        <input type="datetime-local" name="scheduled_at" id="modalCampSched" class="w-full px-3 py-2 rounded-xl bg-dark border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
                    </div>
                </div>

                <!-- Chaining Parent & Delay Selector -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-dark-border/60">
                    <div>
                        <label class="block text-[11px] font-bold text-gray-400 mb-1">🔗 Trigger After Campaign (Chaining)</label>
                        <select name="chained_parent_id" id="modalCampChainParent" class="w-full px-3 py-2 rounded-xl bg-dark border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
                            <option value="">None (Run Independently)</option>
                            <?php foreach ($campaigns as $otherCamp): ?>
                                <option value="<?= htmlspecialchars($otherCamp['id']) ?>">After: <?= htmlspecialchars($otherCamp['name']) ?> (<?= htmlspecialchars($otherCamp['id']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[11px] font-bold text-gray-400 mb-1">Delay After Parent Finishes</label>
                        <select name="chained_delay_hours" id="modalCampChainDelay" class="w-full px-3 py-2 rounded-xl bg-dark border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
                            <option value="0">Immediately When Finished (0 Hours)</option>
                            <option value="12">12 Hours Later</option>
                            <option value="24" selected>24 Hours Later (Next Day)</option>
                            <option value="48">48 Hours Later (2 Days)</option>
                            <option value="72">72 Hours Later (3 Days)</option>
                            <option value="168">7 Days Later (1 Week)</option>
                        </select>
                    </div>
                </div>

                <!-- Parallel Execution Checkbox -->
                <div class="pt-1">
                    <label class="flex items-center gap-2 text-xs text-gray-200 cursor-pointer">
                        <input type="checkbox" name="allow_parallel" id="modalCampAllowParallel" value="1" checked class="rounded bg-dark border-dark-border text-gold focus:ring-0">
                        <span><strong>Allow Parallel Execution:</strong> Multiple campaigns can run simultaneously alongside each other.</span>
                    </label>
                </div>
            </div>

            <!-- MODAL ACTIONS -->
            <div class="pt-4 border-t border-dark-border flex items-center justify-between">
                <button type="button" onclick="closeModal('newCampaignModal')" class="px-4 py-2 rounded-xl bg-dark-surface text-gray-300 text-xs font-bold hover:bg-dark-border">Cancel</button>
                <div class="flex items-center gap-2">
                    <button type="submit" name="send_immediately" value="1" data-confirm="Send to all matching subscribers right now?" data-confirm-title="Send Campaign Now" data-confirm-icon="🚀" data-confirm-btn="Send Campaign" data-confirm-danger="false" class="px-4 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/40 font-bold text-xs transition-all">
                        🚀 Send Now
                    </button>
                    <button type="submit" class="px-5 py-2 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs transition-all">
                        Save Campaign
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- MODAL 4: NEW AUTOMATION -->
<div id="newAutomationModal" class="hidden fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
    <div class="bg-dark-card border border-dark-border rounded-3xl p-6 max-w-lg w-full shadow-2xl">
        <div class="flex items-center justify-between pb-4 border-b border-dark-border mb-4">
            <h3 class="text-base font-black text-white">Create Visual Automation Workflow</h3>
            <button onclick="closeModal('newAutomationModal')" class="text-gray-400 hover:text-white">✕</button>
        </div>

        <form method="POST" action="?tab=automations" class="space-y-4">
            <input type="hidden" name="action" value="save_automation">

            <div>
                <label class="block text-[11px] font-bold text-gray-400 mb-1">Workflow Name</label>
                <input type="text" name="name" required placeholder="e.g. VIP Client Nurture Series" class="w-full px-3 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
            </div>

            <div>
                <label class="block text-[11px] font-bold text-gray-400 mb-1">Trigger Event</label>
                <select name="trigger_type" class="w-full px-3 py-2 rounded-xl bg-dark-surface border border-dark-border text-xs text-white focus:outline-none focus:border-gold">
                    <option value="new_signup">New Signup / Lead Added</option>
                    <option value="form_submit">Form Submitted</option>
                    <option value="tag_added">Tag Added to Contact</option>
                </select>
            </div>

            <div class="p-3.5 rounded-2xl bg-dark-surface border border-dark-border text-xs text-gray-400 space-y-1">
                <span class="font-bold text-white">Pre-configured sequence template will be created:</span>
                <div>1. 📧 Instant Welcome &amp; Sample Offer Email</div>
                <div>2. ⏳ 48-Hour Intelligent Delay</div>
                <div>3. 📧 Follow-Up Lighting Guide Email</div>
                <div>4. 🏷️ Tag as #onboarded</div>
            </div>

            <div class="pt-4 border-t border-dark-border flex justify-end gap-2">
                <button type="button" onclick="closeModal('newAutomationModal')" class="px-4 py-2 rounded-xl bg-dark-surface text-gray-300 text-xs font-bold">Cancel</button>
                <button type="submit" class="px-5 py-2 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs">Create Workflow</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL 5: EMBED CODE -->
<div id="embedCodeModal" class="hidden fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
    <div class="bg-dark-card border border-dark-border rounded-3xl p-6 max-w-xl w-full shadow-2xl">
        <div class="flex items-center justify-between pb-4 border-b border-dark-border mb-4">
            <h3 class="text-base font-black text-white">Website Signup Form Embed Snippet</h3>
            <button onclick="closeModal('embedCodeModal')" class="text-gray-400 hover:text-white">✕</button>
        </div>

        <p class="text-xs text-gray-400 mb-3">Copy and paste this snippet into any page on Estate HDR (e.g. index.php, contact.php, or blog.php):</p>

        <textarea readonly id="embedCodeBox" rows="6" class="w-full p-3 rounded-xl bg-dark-surface border border-dark-border text-xs text-gold font-mono focus:outline-none select-all"><!-- Estate HDR Email Lead Form -->
<form action="<?= BASE_URL ?>/api/crm-form-submit.php" method="POST" style="max-width:400px;background:#12131C;padding:24px;border-radius:16px;border:1px solid #C9A84C;">
  <input type="hidden" name="form_id" value="FORM-101">
  <input type="text" name="first_name" placeholder="First Name" required style="width:100%;padding:10px;margin-bottom:10px;border-radius:8px;background:#0A0A0F;border:1px solid #333;color:#FFF;">
  <input type="email" name="email" placeholder="Email Address" required style="width:100%;padding:10px;margin-bottom:10px;border-radius:8px;background:#0A0A0F;border:1px solid #333;color:#FFF;">
  <button type="submit" style="width:100%;padding:12px;background:#C9A84C;color:#000;font-weight:bold;border:none;border-radius:8px;cursor:pointer;">Get Free Edits ➔</button>
</form></textarea>

        <div class="pt-4 border-t border-dark-border flex justify-end gap-2">
            <button type="button" onclick="copyEmbedCode()" class="px-5 py-2 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs">Copy Snippet</button>
        </div>
    </div>
</div>

<!-- Fresh Start / Clean Slate Modal -->
<div id="freshStartModal" class="hidden fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
    <div class="bg-dark-card border border-rose-500/40 w-full max-w-lg rounded-3xl p-6 shadow-2xl relative">
        <button onclick="closeModal('freshStartModal')" class="absolute top-5 right-5 text-gray-400 hover:text-white text-lg">✕</button>
        <div class="flex items-center gap-3 mb-4">
            <div class="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-2xl text-rose-400">
                🚀
            </div>
            <div>
                <h3 class="font-black text-white text-lg">CRM Fresh Start</h3>
                <p class="text-xs text-gray-400">Reset dashboard metrics and test campaign history</p>
            </div>
        </div>

        <p class="text-xs text-gray-300 leading-relaxed mb-4">
            Starting fresh resets all sample campaign metrics, event logs, and mock performance bars to zero so you can begin real client outreach.
        </p>

        <form method="POST" action="?tab=dash" class="space-y-4">
            <input type="hidden" name="action" value="fresh_start_reset">
            
            <div class="p-4 rounded-2xl bg-dark-surface border border-dark-border space-y-3">
                <div class="flex items-start gap-3">
                    <input type="checkbox" id="keepContactsCheckbox" checked disabled class="mt-1 accent-gold rounded">
                    <div>
                        <label for="keepContactsCheckbox" class="text-xs font-bold text-white block">Preserve Verified Contacts (Recommended)</label>
                        <span class="text-[11px] text-gray-400">Keeps all <strong><?= number_format($stats['total_contacts']) ?></strong> realtor and lead contacts safe in your database.</span>
                    </div>
                </div>

                <div class="border-t border-dark-border/60 pt-3">
                    <label class="flex items-center gap-2 cursor-pointer text-[11px] text-rose-300">
                        <input type="checkbox" name="wipe_contacts" value="1" onchange="document.getElementById('keepContactsCheckbox').checked = !this.checked" class="accent-rose-500 rounded">
                        <span>Also erase all contact records (Full database wipe)</span>
                    </label>
                </div>
            </div>

            <div class="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-[11px] text-amber-200">
                ℹ️ A clean default outreach campaign <em>"Realtor Outreach — Luxury 12h HDR Photo Blending"</em> will be initialized and set to <strong>draft</strong>.
            </div>

            <div class="pt-2 flex justify-end gap-3">
                <button type="button" onclick="closeModal('freshStartModal')" class="px-4 py-2 rounded-xl bg-dark-border text-gray-300 hover:text-white text-xs font-bold">Cancel</button>
                <button type="submit" class="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-black shadow-lg">Confirm &amp; Reset Dashboard</button>
            </div>
        </form>
    </div>
</div>

<!-- 1-Click Verify All Contacts Modal -->
<div id="verifyAllModal" class="hidden fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
    <div class="bg-dark-card border border-gold/40 w-full max-w-2xl rounded-3xl p-6 sm:p-8 shadow-2xl relative my-auto">
        <button onclick="closeModal('verifyAllModal')" class="absolute top-5 right-5 w-8 h-8 rounded-full bg-dark-surface border border-dark-border text-gray-400 hover:text-white flex items-center justify-center text-sm transition-colors">✕</button>
        
        <!-- Header -->
        <div class="flex items-center gap-3.5 mb-6">
            <div class="w-12 h-12 rounded-2xl bg-gradient-to-br from-gold to-amber-500 text-dark flex items-center justify-center text-2xl font-black shadow-glow shrink-0">
                ⚡
            </div>
            <div>
                <div class="flex items-center gap-2">
                    <h3 class="font-black text-white text-lg sm:text-xl">1-Click Audience Email Verifier</h3>
                    <span class="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-gold/20 text-gold border border-gold/40">Zero Bounce</span>
                </div>
                <p class="text-xs text-gray-400 mt-0.5">Verify your audience in high-speed automated batches without manual clicking.</p>
            </div>
        </div>

        <!-- Mode & Scope Selection -->
        <div class="space-y-3 mb-5">
            <!-- Mode Radio -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label class="p-3.5 rounded-2xl bg-dark-surface/90 border border-gold/40 flex items-start gap-3 cursor-pointer hover:border-gold transition-all relative overflow-hidden">
                    <input type="radio" name="modal_verify_engine" value="turbo" checked id="radioEngineTurbo" class="mt-1 accent-gold">
                    <div>
                        <div class="text-xs font-black text-white flex items-center gap-1.5">
                            <span>🚀 Turbo Mode</span>
                            <span class="px-1.5 py-0.2 rounded-full text-[9px] font-black bg-emerald-500/20 text-emerald-400">RECOMMENDED</span>
                        </div>
                        <p class="text-[11px] text-gray-400 mt-1 leading-snug">
                            Cached DNS/MX + 250+ Disposable blacklist + Role check + Typo engine. <strong>~100–200 contacts/sec</strong>.
                        </p>
                    </div>
                </label>

                <label class="p-3.5 rounded-2xl bg-dark-surface/90 border border-dark-border flex items-start gap-3 cursor-pointer hover:border-dark-border/80 transition-all">
                    <input type="radio" name="modal_verify_engine" value="deep" id="radioEngineDeep" class="mt-1 accent-gold">
                    <div>
                        <div class="text-xs font-black text-white flex items-center gap-1.5">
                            <span>🔬 Deep Socket SMTP</span>
                        </div>
                        <p class="text-[11px] text-gray-400 mt-1 leading-snug">
                            Connects live to remote mail exchangers via port 25/587 socket. Thorough, slower (~2–5 contacts/sec).
                        </p>
                    </div>
                </label>
            </div>

            <!-- Scope & Batch Size Filter Options -->
            <div class="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-dark-surface/50 border border-dark-border text-xs">
                <div class="flex items-center gap-4">
                    <label class="flex items-center gap-2 cursor-pointer text-gray-300 font-bold">
                        <input type="checkbox" id="modalOnlyUnverifiedCheck" checked onchange="syncModalTargetCount()" class="accent-gold rounded">
                        <span>Unverified only (<?= number_format($vStats['unverified']) ?>)</span>
                    </label>
                </div>
                <div class="flex items-center gap-2">
                    <span class="text-gray-400 font-medium">Batch Size:</span>
                    <select id="modalBatchSizeSelect" class="px-2.5 py-1 rounded-xl bg-dark-card border border-dark-border text-white text-xs font-mono focus:outline-none focus:border-gold">
                        <option value="50">50 / batch</option>
                        <option value="100" selected>100 / batch (Optimal)</option>
                        <option value="200">200 / batch</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Real-Time Metrics Counters (4 Columns) -->
        <div class="grid grid-cols-4 gap-2 sm:gap-3 mb-5">
            <div class="p-3 rounded-2xl bg-dark-surface border border-dark-border text-center">
                <div class="text-[10px] uppercase font-bold text-gray-500">Target</div>
                <div class="text-lg sm:text-xl font-black text-white font-mono mt-0.5" id="modalTargetDisplay"><?= number_format($vStats['unverified']) ?></div>
            </div>
            <div class="p-3 rounded-2xl bg-dark-surface border border-dark-border text-center">
                <div class="text-[10px] uppercase font-bold text-gray-500">Processed</div>
                <div class="text-lg sm:text-xl font-black text-gold font-mono mt-0.5" id="modalProcessedDisplay">0</div>
            </div>
            <div class="p-3 rounded-2xl bg-dark-surface border border-emerald-500/20 text-center">
                <div class="text-[10px] uppercase font-bold text-emerald-400">Valid</div>
                <div class="text-lg sm:text-xl font-black text-emerald-400 font-mono mt-0.5" id="modalValidDisplay"><?= number_format($vStats['valid']) ?></div>
            </div>
            <div class="p-3 rounded-2xl bg-dark-surface border border-rose-500/20 text-center">
                <div class="text-[10px] uppercase font-bold text-rose-400">Risky &amp; Bad</div>
                <div class="text-lg sm:text-xl font-black text-rose-400 font-mono mt-0.5" id="modalRiskyBadDisplay"><?= number_format($vStats['risky'] + $vStats['invalid']) ?></div>
                <div class="flex items-center justify-center gap-1.5 text-[10px] font-mono text-gray-400 mt-0.5">
                    <span class="text-rose-400 font-bold"><span id="modalLiveInvalidCount"><?= number_format($vStats['invalid']) ?></span> bad</span>
                    <span>•</span>
                    <span class="text-amber-400 font-bold"><span id="modalLiveRiskyCount"><?= number_format($vStats['risky']) ?></span> rsk</span>
                </div>
            </div>
        </div>

        <!-- Instant Database Clean & Purge Bar (Delete Invalid & Risky) -->
        <div id="modalPurgeActionBar" class="p-3.5 rounded-2xl bg-[#140E14] border border-rose-500/30 mb-5">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div class="flex items-center gap-2.5">
                    <span class="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/40 flex items-center justify-center text-sm font-bold shrink-0">
                        🧹
                    </span>
                    <div>
                        <h4 class="text-xs font-black text-white flex items-center gap-1.5">
                            <span>Database Clean &amp; Removal</span>
                            <span class="px-1.5 py-0.2 rounded-full text-[9px] font-black bg-rose-500/20 text-rose-300">INSTANT</span>
                        </h4>
                        <p class="text-[11px] text-gray-400 leading-tight">
                            Purge invalid and risky addresses immediately to keep sender reputation at 100%.
                        </p>
                    </div>
                </div>
                
                <div class="flex flex-wrap items-center gap-2 shrink-0">
                    <!-- Delete Invalid Button -->
                    <button type="button" onclick="purgeModalContacts('invalid')" id="btnModalDeleteInvalid" class="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition-all flex items-center gap-1.5 shadow-sm active:scale-95" title="Permanently delete all invalid mailboxes">
                        <span>🗑️ Delete Invalid</span>
                        <span class="px-1.5 py-0.2 rounded-full bg-black/40 text-rose-200 text-[10px] font-mono font-black" id="modalBadgeInvalidNum"><?= number_format($vStats['invalid']) ?></span>
                    </button>

                    <!-- Delete Risky Button (Requested explicitly by user) -->
                    <button type="button" onclick="purgeModalContacts('risky')" id="btnModalDeleteRisky" class="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/50 font-bold text-xs transition-all flex items-center gap-1.5 shadow-sm active:scale-95" title="Permanently delete generic department addresses and catch-all domains">
                        <span>⚠️ Delete Risky</span>
                        <span class="px-1.5 py-0.2 rounded-full bg-black/40 text-amber-200 text-[10px] font-mono font-black" id="modalBadgeRiskyNum"><?= number_format($vStats['risky']) ?></span>
                    </button>

                    <!-- Clean Both -->
                    <button type="button" onclick="purgeModalContacts('unhealthy')" id="btnModalDeleteUnhealthy" class="px-3 py-1.5 rounded-xl bg-gradient-to-r from-rose-700 to-amber-700 hover:from-rose-600 hover:to-amber-600 text-white font-black text-xs transition-all flex items-center gap-1 shadow-sm active:scale-95" title="Purge both invalid and risky contacts together">
                        <span>🧹 Clean Both</span>
                    </button>
                </div>
            </div>
        </div>

        <!-- Progress Bar & Speed / ETA Ticker -->
        <div class="mb-5 space-y-2">
            <div class="flex items-center justify-between text-xs font-bold">
                <span class="text-gray-300 flex items-center gap-2">
                    <span id="modalStatusBadge" class="px-2 py-0.5 rounded-full text-[10px] font-mono bg-dark-surface text-gray-400 border border-dark-border font-bold">READY</span>
                    <span id="modalProgressPercent" class="text-gold font-mono font-black text-sm">0%</span>
                </span>
                <span class="text-gray-400 font-mono text-[11px] flex items-center gap-3">
                    <span id="modalSpeedDisplay" class="text-gray-300">0 contacts/sec</span>
                    <span class="text-gray-600">•</span>
                    <span id="modalEtaDisplay" class="text-gray-400">ETA: --</span>
                </span>
            </div>
            <div class="w-full bg-[#181926] rounded-full h-3.5 overflow-hidden border border-dark-border p-0.5">
                <div id="modalProgressBarFill" class="bg-gradient-to-r from-gold via-amber-400 to-emerald-400 h-full rounded-full transition-all duration-300" style="width: 0%;"></div>
            </div>
        </div>

        <!-- Live Ticker Terminal Log -->
        <div class="mb-5">
            <div class="flex items-center justify-between pb-1.5 text-[11px]">
                <span class="font-bold text-gray-400 flex items-center gap-1.5">
                    <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span>Live Verification Stream</span>
                </span>
                <span class="text-gray-500 font-mono" id="modalBatchNumDisplay">Batch: #0</span>
            </div>
            <div id="modalVerifyLiveFeed" class="p-3 rounded-2xl bg-[#08080C] border border-dark-border font-mono text-[11px] text-gray-300 h-36 overflow-y-auto space-y-1 select-text shadow-inner">
                <div class="text-gray-500">// Ready to initiate 1-click verification. Click 'Start Verification' below.</div>
            </div>
        </div>

        <!-- Completion Alert Banner (Hidden initially) -->
        <div id="modalCompletionBanner" class="hidden mb-5 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/40 text-emerald-300 text-xs">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
                <div class="flex items-center gap-3">
                    <span class="text-3xl">🎉</span>
                    <div>
                        <strong class="font-black text-white text-sm block">Audience Verification Complete!</strong>
                        <span>All target contacts verified. Purge problematic emails below or refresh your table.</span>
                    </div>
                </div>
                <button type="button" onclick="location.reload()" class="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-dark font-black text-xs transition-all shadow-md shrink-0">
                    Refresh CRM Table ➔
                </button>
            </div>
            <div class="pt-3 border-t border-emerald-500/20 flex flex-wrap items-center gap-2">
                <span class="text-white font-bold text-[11px]">Instant Removal:</span>
                <button type="button" onclick="purgeModalContacts('invalid')" class="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1.5 transition-all">
                    <span>🗑️ Delete All Invalid (<span id="modalFinishInvalidCount"><?= number_format($vStats['invalid']) ?></span>)</span>
                </button>
                <button type="button" onclick="purgeModalContacts('risky')" class="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 font-bold text-xs flex items-center gap-1.5 transition-all">
                    <span>⚠️ Delete All Risky (<span id="modalFinishRiskyCount"><?= number_format($vStats['risky']) ?></span>)</span>
                </button>
                <button type="button" onclick="purgeModalContacts('unhealthy')" class="px-3 py-1.5 rounded-xl bg-gradient-to-r from-rose-700 to-amber-700 text-white font-black text-xs flex items-center gap-1.5 transition-all">
                    <span>🧹 Purge Both (Keep 100% Clean Valid Only)</span>
                </button>
            </div>
        </div>

        <!-- Action Footer -->
        <div class="pt-3 border-t border-dark-border flex flex-wrap items-center justify-between gap-3">
            <button type="button" onclick="closeModal('verifyAllModal')" class="px-4 py-2.5 rounded-xl bg-dark-surface hover:bg-dark-border text-gray-300 text-xs font-bold transition-colors">
                Close
            </button>
            <div class="flex items-center gap-2">
                <button type="button" id="btnModalPauseVerify" onclick="pauseModalVerification()" class="hidden px-4 py-2.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 font-bold text-xs transition-all">
                    <span>⏸️ Pause</span>
                </button>
                <button type="button" id="btnModalStartVerify" onclick="startModalAllVerification()" class="px-6 py-2.5 rounded-xl bg-gradient-to-r from-gold via-amber-400 to-gold hover:from-gold-light hover:to-gold text-dark font-black text-xs shadow-glow transition-all hover:scale-105 active:scale-95 flex items-center gap-2">
                    <span>⚡ Start 1-Click Verification</span>
                </button>
            </div>
        </div>
    </div>
</div>

<!-- SCRIPTS -->
<script>
function openModal(id) {
    var el = document.getElementById(id);
    if (el) el.classList.remove('hidden');
}
function closeModal(id) {
    var el = document.getElementById(id);
    if (el) el.classList.add('hidden');
}

function editContact(c) {
    document.getElementById('contactModalTitle').innerText = 'Edit Contact';
    document.getElementById('modalContactId').value = c.id || '';
    document.getElementById('modalFirstName').value = c.first_name || '';
    document.getElementById('modalLastName').value = c.last_name || '';
    document.getElementById('modalEmail').value = c.email || '';
    document.getElementById('modalCompany').value = c.company || '';
    document.getElementById('modalPhone').value = c.phone || '';
    document.getElementById('modalStatus').value = c.status || 'subscribed';
    document.getElementById('modalTags').value = (c.tags || []).join(', ');
    openModal('addContactModal');
}

const emailTemplates = <?= json_encode($emailTemplates, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>;

function openNewCampaignModal() {
    document.getElementById('campaignModalTitle').innerText = 'Create Email Campaign';
    document.getElementById('modalCampId').value = '';
    document.getElementById('modalCampName').value = '';
    document.getElementById('modalCampSubject').value = '';
    document.getElementById('modalCampPreview').value = '';
    document.getElementById('modalCampTag').value = 'all';
    document.getElementById('modalCampContent').value = '';
    document.getElementById('modalCampStatus').value = 'draft';
    if (document.getElementById('modalCampSched')) document.getElementById('modalCampSched').value = '';
    if (document.getElementById('modalCampChainParent')) document.getElementById('modalCampChainParent').value = '';
    if (document.getElementById('modalCampChainDelay')) document.getElementById('modalCampChainDelay').value = '24';
    if (document.getElementById('modalCampAllowParallel')) document.getElementById('modalCampAllowParallel').checked = true;
    if (document.getElementById('templateSelectorSelect')) document.getElementById('templateSelectorSelect').value = '';
    switchEditorMode('code');
    openModal('newCampaignModal');
}

function openNewCampaignWithTemplate(tmplId) {
    openNewCampaignModal();
    loadTemplateIntoEditor(tmplId);
    var sel = document.getElementById('templateSelectorSelect');
    if (sel) sel.value = tmplId;
}

function loadTemplateIntoEditor(tmplId) {
    if (!emailTemplates || !emailTemplates[tmplId]) return;
    var t = emailTemplates[tmplId];
    if (document.getElementById('modalCampName')) document.getElementById('modalCampName').value = t.name;
    if (document.getElementById('modalCampSubject')) document.getElementById('modalCampSubject').value = t.subject;
    if (document.getElementById('modalCampPreview')) document.getElementById('modalCampPreview').value = t.preview_text;
    if (document.getElementById('modalCampContent')) document.getElementById('modalCampContent').value = t.html;
    updateModalLivePreview();
}

function switchEditorMode(mode) {
    var codeView = document.getElementById('editorCodeView');
    var prevView = document.getElementById('editorPreviewView');
    var btnCode = document.getElementById('tabBtnCode');
    var btnPrev = document.getElementById('tabBtnPreview');
    if (!codeView || !prevView) return;

    if (mode === 'preview') {
        codeView.classList.add('hidden');
        prevView.classList.remove('hidden');
        if (btnCode) btnCode.className = 'px-3 py-1 rounded-lg text-xs font-bold bg-dark-surface text-gray-400 border border-dark-border hover:text-white';
        if (btnPrev) btnPrev.className = 'px-3 py-1 rounded-lg text-xs font-bold bg-dark-surface text-gold border border-gold/40';
        updateModalLivePreview();
    } else {
        prevView.classList.add('hidden');
        codeView.classList.remove('hidden');
        if (btnCode) btnCode.className = 'px-3 py-1 rounded-lg text-xs font-bold bg-dark-surface text-gold border border-gold/40';
        if (btnPrev) btnPrev.className = 'px-3 py-1 rounded-lg text-xs font-bold bg-dark-surface text-gray-400 border border-dark-border hover:text-white';
    }
}

function updateModalLivePreview() {
    var iframe = document.getElementById('modalLivePreviewIframe');
    var textarea = document.getElementById('modalCampContent');
    if (!iframe || !textarea) return;

    var rawHtml = textarea.value;
    var rendered = rawHtml.replace(/\{\{first_name\}\}/g, 'Alex')
                          .replace(/\{\{company\}\}/g, 'Summit Real Estate Media')
                          .replace(/\{\{unsubscribe_link\}\}/g, '#');
    var doc = iframe.contentDocument || iframe.contentWindow.document;
    doc.open();
    doc.write(rendered || '<p style="color:#888;padding:20px;font-family:sans-serif;">Email body is empty. Type or load a template above.</p>');
    doc.close();
}

function toggleModalQuickLeads() {
    var container = document.getElementById('modalQuickLeadsContainer');
    var icon = document.getElementById('quickLeadsToggleIcon');
    if (!container) return;
    if (container.classList.contains('hidden')) {
        container.classList.remove('hidden');
        if (icon) icon.innerText = '▲';
    } else {
        container.classList.add('hidden');
        if (icon) icon.innerText = '▼';
    }
}

function previewTemplate(tmplId) {
    if (!emailTemplates || !emailTemplates[tmplId]) return;
    var t = emailTemplates[tmplId];
    if (document.getElementById('previewModalTitle')) document.getElementById('previewModalTitle').innerText = t.name;
    if (document.getElementById('previewModalSubject')) document.getElementById('previewModalSubject').innerText = t.subject;
    if (document.getElementById('previewModalPreheader')) document.getElementById('previewModalPreheader').innerText = t.preview_text;
    
    var useBtn = document.getElementById('previewModalUseBtn');
    if (useBtn) {
        useBtn.onclick = function() {
            closeModal('emailPreviewModal');
            openNewCampaignWithTemplate(tmplId);
        };
    }

    var iframe = document.getElementById('previewIframe');
    if (iframe) {
        var doc = iframe.contentDocument || iframe.contentWindow.document;
        doc.open();
        var rendered = t.html.replace(/\{\{first_name\}\}/g, 'Alex')
                             .replace(/\{\{company\}\}/g, 'Summit Real Estate Media')
                             .replace(/\{\{unsubscribe_link\}\}/g, '#');
        doc.write(rendered);
        doc.close();
    }

    switchPreviewDevice('desktop');
    openModal('emailPreviewModal');
}

function switchPreviewDevice(device) {
    var wrapper = document.getElementById('previewIframeWrapper');
    var btnD = document.getElementById('btnPrevDesktop');
    var btnM = document.getElementById('btnPrevMobile');
    if (!wrapper) return;

    if (device === 'mobile') {
        wrapper.style.maxWidth = '375px';
        if (btnM) btnM.className = 'px-3 py-1 rounded-lg text-xs font-bold bg-dark-surface text-gold border border-gold/40';
        if (btnD) btnD.className = 'px-3 py-1 rounded-lg text-xs font-bold bg-dark-surface text-gray-400 border border-dark-border hover:text-white';
    } else {
        wrapper.style.maxWidth = '640px';
        if (btnD) btnD.className = 'px-3 py-1 rounded-lg text-xs font-bold bg-dark-surface text-gold border border-gold/40';
        if (btnM) btnM.className = 'px-3 py-1 rounded-lg text-xs font-bold bg-dark-surface text-gray-400 border border-dark-border hover:text-white';
    }
}

function filterTemplateGallery(cat) {
    var cards = document.querySelectorAll('.tmpl-card');
    cards.forEach(function(c) {
        if (cat === 'all' || c.getAttribute('data-cat') === cat) {
            c.classList.remove('hidden');
        } else {
            c.classList.add('hidden');
        }
    });

    var btns = document.querySelectorAll('.gallery-filter-btn');
    btns.forEach(function(b) {
        if (b.getAttribute('data-cat') === cat) {
            b.className = 'gallery-filter-btn px-3 py-1 rounded-lg text-xs font-bold bg-gold text-dark';
        } else {
            b.className = 'gallery-filter-btn px-3 py-1 rounded-lg text-xs font-bold bg-dark-surface text-gray-300 border border-dark-border hover:text-white';
        }
    });
}

function editCampaign(camp) {
    document.getElementById('campaignModalTitle').innerText = 'Edit Campaign: ' + camp.name;
    document.getElementById('modalCampId').value = camp.id || '';
    document.getElementById('modalCampName').value = camp.name || '';
    document.getElementById('modalCampSubject').value = camp.subject || '';
    document.getElementById('modalCampPreview').value = camp.preview_text || '';
    document.getElementById('modalCampTag').value = camp.target_tag || 'all';
    document.getElementById('modalCampContent').value = camp.content_html || '';
    document.getElementById('modalCampStatus').value = camp.status || 'draft';
    if (document.getElementById('modalCampSched') && camp.scheduled_at) {
        // Convert to datetime-local format (YYYY-MM-DDTHH:MM)
        var s = camp.scheduled_at.replace(' ', 'T').substring(0, 16);
        document.getElementById('modalCampSched').value = s;
    }
    if (document.getElementById('modalCampChainParent')) {
        document.getElementById('modalCampChainParent').value = camp.chained_parent_id || '';
    }
    if (document.getElementById('modalCampChainDelay')) {
        document.getElementById('modalCampChainDelay').value = String(camp.chained_delay_hours !== undefined ? camp.chained_delay_hours : 24);
    }
    if (document.getElementById('modalCampAllowParallel')) {
        document.getElementById('modalCampAllowParallel').checked = camp.allow_parallel !== false;
    }
    switchEditorMode('code');
    updateModalLivePreview();
    openModal('newCampaignModal');
}

function insertPlaceholder(txt) {
    var box = document.getElementById('modalCampContent');
    if (!box) return;
    var start = box.selectionStart;
    var end = box.selectionEnd;
    var val = box.value;
    box.value = val.substring(0, start) + txt + val.substring(end);
    box.selectionStart = box.selectionEnd = start + txt.length;
    box.focus();
}

function copyEmbedCode() {
    var copyText = document.getElementById("embedCodeBox");
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(copyText.value);
    EstateDialog.toast("Embed code copied to clipboard!", "success");
}

// ── EMAIL VERIFIER MASTER JAVASCRIPT CONTROLLERS ──────────────────
let activeTypoCorrection = '';

function testSingleEmail() {
    const input = document.getElementById('testEmailInput');
    const btn = document.getElementById('btnRunSingleVerify');
    const resultBox = document.getElementById('singleResultContainer');
    if (!input || !btn) return;

    const email = input.value.trim();
    if (!email) {
        EstateDialog.toast('Please enter an email address to verify.', 'warning');
        input.focus();
        return;
    }

    const originalBtnHtml = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span>⏳ Checking...</span>';

    fetch('/api/email-verify.php?action=verify_single&email=' + encodeURIComponent(email))
        .then(res => res.json())
        .then(data => {
            btn.disabled = false;
            btn.innerHTML = originalBtnHtml;

            if (!data.success) {
                EstateDialog.toast('Verification error: ' + (data.error || 'Failed to inspect email'), 'error');
                return;
            }

            resultBox.classList.remove('hidden');

            const verdict = data.verdict || 'invalid';
            const badge = document.getElementById('singleVerdictBadge');
            const verdictCard = document.getElementById('singleVerdictCard');
            const targetEmailDisplay = document.getElementById('singleTargetEmailDisplay');
            const verdictReason = document.getElementById('singleVerdictReason');
            const scoreDisplay = document.getElementById('singleScoreDisplay');
            const qualityGrade = document.getElementById('singleQualityGrade');

            if (targetEmailDisplay) targetEmailDisplay.textContent = data.email || email;
            if (scoreDisplay) scoreDisplay.innerHTML = `${data.score}<span class="text-xs text-gray-500 font-normal">/100</span>`;
            if (verdictReason) verdictReason.textContent = (data.details || []).join(' • ') || 'Verification analysis complete.';

            const verdictColors = {
                valid: { bg: 'bg-emerald-500/10', border: 'border-emerald-500/40', badge: 'bg-emerald-500 text-dark font-black', text: 'text-emerald-400', grade: 'A+ EXCELLENT' },
                risky: { bg: 'bg-amber-500/10', border: 'border-amber-500/40', badge: 'bg-amber-500 text-dark font-black', text: 'text-amber-400', grade: 'B RISKY / ROLE' },
                catch_all: { bg: 'bg-purple-500/10', border: 'border-purple-500/40', badge: 'bg-purple-500 text-white font-black', text: 'text-purple-400', grade: 'C CATCH-ALL' },
                invalid: { bg: 'bg-rose-500/10', border: 'border-rose-500/40', badge: 'bg-rose-500 text-white font-black', text: 'text-rose-400', grade: 'F HIGH BOUNCE RISK' }
            };

            const cfg = verdictColors[verdict] || verdictColors.invalid;
            verdictCard.className = `p-4 rounded-2xl border flex items-center justify-between gap-4 ${cfg.bg} ${cfg.border}`;
            badge.className = `px-3 py-1 rounded-xl text-xs font-black uppercase tracking-wider font-mono ${cfg.badge}`;
            badge.textContent = verdict.toUpperCase();
            qualityGrade.textContent = cfg.grade;
            qualityGrade.className = `text-[10px] font-mono font-bold ${cfg.text}`;

            const typoAlert = document.getElementById('singleTypoAlert');
            const typoTarget = document.getElementById('singleTypoTarget');
            if (data.stages?.typo?.has_typo && data.stages.typo.suggestion) {
                activeTypoCorrection = data.stages.typo.suggestion;
                if (typoTarget) typoTarget.textContent = activeTypoCorrection;
                if (typoAlert) typoAlert.classList.remove('hidden');
            } else {
                activeTypoCorrection = '';
                if (typoAlert) typoAlert.classList.add('hidden');
            }

            // Stage 1: Syntax
            const syn = data.stages?.syntax || {};
            setStageItem('Syntax', syn.valid, syn.valid ? `Normalized: ${syn.normalized || email}` : 'Syntax RFC violation', syn.valid ? 'PASS' : 'FAIL');

            // Stage 2: MX
            const mx = data.stages?.domain_mx || {};
            const primaryMx = (mx.mx_records && mx.mx_records[0]) ? mx.mx_records[0].host : (mx.has_dns ? 'A record host only' : 'No MX/DNS records');
            setStageItem('Mx', mx.has_mx, mx.has_mx ? `MX: ${primaryMx}` : 'No MX records found for domain', mx.has_mx ? 'PASS' : 'FAIL');

            // Stage 3: Disposable
            const disp = data.stages?.disposable || {};
            setStageItem('Disposable', !disp.is_disposable, disp.is_disposable ? 'Temporary / Burner inbox detected' : 'Clean domain (Not in 250+ disposable list)', disp.is_disposable ? 'FLAGGED' : 'CLEAN');

            // Stage 4: Role
            const role = data.stages?.role_based || {};
            setStageItem('Role', !role.is_role, role.is_role ? 'Generic role account (info@, sales@, etc.)' : 'Individual mailbox (Non-role)', role.is_role ? 'ROLE' : 'PERSONAL');

            // Stage 5: SMTP Handshake
            const smtp = data.stages?.smtp || {};
            const smtpDetail = smtp.response || (smtp.connected ? 'Socket handshake verified' : 'Port 25/587 connection blocked or skipped');
            const smtpBadge = smtp.mailbox_exists === true ? '250 OK' : (smtp.mailbox_exists === false ? '550 REJECT' : 'CHECKED');
            setStageItem('Smtp', smtp.mailbox_exists !== false, smtpDetail, smtpBadge);

            // Stage 6: Catch-All
            const ca = data.stages?.catch_all || {};
            setStageItem('CatchAll', !ca.is_catch_all, ca.is_catch_all ? 'Server accepts all emails (Catch-All active)' : 'Server rejects unknown mailboxes (Strict)', ca.is_catch_all ? 'CATCH-ALL' : 'DISABLED');
        })
        .catch(err => {
            btn.disabled = false;
            btn.innerHTML = originalBtnHtml;
            EstateDialog.toast('Failed to connect to verification API.', 'error');
        });
}

function setStageItem(key, isOk, detailText, badgeText) {
    const icon = document.getElementById('stageIcon' + key);
    const detail = document.getElementById('stageDetail' + key);
    const badge = document.getElementById('stageBadge' + key);

    if (detail) detail.textContent = detailText;
    if (badge) {
        badge.textContent = badgeText;
        if (isOk) {
            badge.className = 'px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-500/20 text-emerald-400';
            if (icon) { icon.textContent = '✓'; icon.className = 'w-5 text-center font-bold text-emerald-400'; }
        } else {
            badge.className = 'px-2 py-0.5 rounded-full text-[10px] font-bold font-mono bg-rose-500/20 text-rose-400';
            if (icon) { icon.textContent = '✕'; icon.className = 'w-5 text-center font-bold text-rose-400'; }
        }
    }
}

function applyTypoSuggestion() {
    if (!activeTypoCorrection) return;
    const input = document.getElementById('testEmailInput');
    if (input) {
        input.value = activeTypoCorrection;
        testSingleEmail();
    }
}

// 1-Click Verification for table rows
function quickVerifyContact(contactId, email, btnEl) {
    if (!contactId || !btnEl) return;
    const originalText = btnEl.innerHTML;
    btnEl.disabled = true;
    btnEl.innerHTML = '<span class="animate-spin inline-block">⏳</span>';

    fetch('/api/email-verify.php?action=verify_contact&id=' + encodeURIComponent(contactId))
        .then(res => res.json())
        .then(data => {
            btnEl.disabled = false;
            btnEl.innerHTML = originalText;

            if (!data.success) {
                EstateDialog.toast('Verify failed: ' + (data.error || 'Unknown error'), 'error');
                return;
            }

            const verdict = data.verdict || 'valid';
            const score = data.score || 50;
            const badgeCell = document.getElementById('verify-badge-cell-' + contactId);
            const scoreCell = document.getElementById('verify-score-cell-' + contactId);

            if (badgeCell) {
                const badgeHtml = {
                    valid: '<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/40"><span>✓</span> <span>VALID</span></span>',
                    risky: '<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-400 border border-amber-500/40"><span>⚠️</span> <span>RISKY</span></span>',
                    catch_all: '<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-purple-500/20 text-purple-400 border border-purple-500/40"><span>🌐</span> <span>CATCH-ALL</span></span>',
                    invalid: '<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-rose-500/20 text-rose-400 border border-rose-500/40"><span>✕</span> <span>INVALID</span></span>'
                }[verdict] || '<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-dark-surface text-gray-400 border border-dark-border"><span>○</span> <span>UNVERIFIED</span></span>';
                badgeCell.innerHTML = badgeHtml;
            }

            if (scoreCell) {
                scoreCell.innerHTML = `
                    <div class="w-12 bg-dark-border rounded-full h-1.5 overflow-hidden">
                        <div class="bg-gold h-full" style="width: ${Math.min(100, score)}%;"></div>
                    </div>
                    <span class="text-gray-300 font-bold">${score}</span>
                `;
            }

            btnEl.classList.add('bg-emerald-500/20', 'text-emerald-400');
            setTimeout(() => {
                btnEl.classList.remove('bg-emerald-500/20', 'text-emerald-400');
            }, 2000);
        })
        .catch(err => {
            btnEl.disabled = false;
            btnEl.innerHTML = originalText;
            EstateDialog.toast('Network error during quick verify.', 'error');
        });
}

// Bulk CRM Verification Loop
let isBulkRunning = false;
let bulkPaused = false;
let bulkProcessedCount = 0;
let bulkTotalTarget = <?= (int)($vStats['unverified']) ?>;

function startBulkVerification() {
    if (isBulkRunning && !bulkPaused) return;

    const btnStart = document.getElementById('btnStartBulk');
    const btnPause = document.getElementById('btnPauseBulk');
    const statusPill = document.getElementById('bulkStatusPill');
    const batchSize = document.getElementById('bulkBatchSize') ? document.getElementById('bulkBatchSize').value : 10;
    const unverifiedOnly = document.getElementById('bulkUnverifiedOnly') && document.getElementById('bulkUnverifiedOnly').checked ? '1' : '0';

    isBulkRunning = true;
    bulkPaused = false;

    if (btnStart) btnStart.classList.add('hidden');
    if (btnPause) {
        btnPause.classList.remove('hidden');
        btnPause.textContent = '⏸️ Pause';
    }
    if (statusPill) {
        statusPill.textContent = 'RUNNING';
        statusPill.className = 'text-[10px] font-mono px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold animate-pulse';
    }

    appendBulkLog(`[${new Date().toLocaleTimeString()}] 🚀 Initiating bulk verification loop (Batch size: ${batchSize})...`, 'info');
    runBulkBatchLoop(batchSize, unverifiedOnly);
}

function pauseBulkVerification() {
    bulkPaused = true;
    const btnStart = document.getElementById('btnStartBulk');
    const btnPause = document.getElementById('btnPauseBulk');
    const statusPill = document.getElementById('bulkStatusPill');

    if (btnStart) {
        btnStart.classList.remove('hidden');
        btnStart.textContent = '▶️ Resume';
    }
    if (btnPause) btnPause.classList.add('hidden');
    if (statusPill) {
        statusPill.textContent = 'PAUSED';
        statusPill.className = 'text-[10px] font-mono px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/40 font-bold';
    }

    appendBulkLog(`[${new Date().toLocaleTimeString()}] ⏸️ Bulk verification paused by administrator.`, 'warn');
}

function resetBulkVerification() {
    bulkPaused = true;
    isBulkRunning = false;
    bulkProcessedCount = 0;

    const btnStart = document.getElementById('btnStartBulk');
    const btnPause = document.getElementById('btnPauseBulk');
    const statusPill = document.getElementById('bulkStatusPill');
    const bar = document.getElementById('bulkProgressBarFill');
    const percentEl = document.getElementById('bulkProgressPercent');
    const countEl = document.getElementById('bulkProcessedCount');

    if (btnStart) {
        btnStart.classList.remove('hidden');
        btnStart.textContent = '🚀 Start Bulk Verification';
    }
    if (btnPause) btnPause.classList.add('hidden');
    if (statusPill) {
        statusPill.textContent = 'READY';
        statusPill.className = 'text-[10px] font-mono px-2.5 py-1 rounded-full bg-dark-surface text-gray-400 border border-dark-border font-bold';
    }
    if (bar) bar.style.width = '0%';
    if (percentEl) percentEl.textContent = '0%';
    if (countEl) countEl.textContent = '0';

    appendBulkLog(`[${new Date().toLocaleTimeString()}] 🔄 Bulk processor reset.`, 'info');
}

function runBulkBatchLoop(batchSize, unverifiedOnly) {
    if (!isBulkRunning || bulkPaused) return;

    fetch(`/api/email-verify.php?action=verify_batch&batch_size=${batchSize}&unverified_only=${unverifiedOnly}`)
        .then(res => res.json())
        .then(data => {
            if (!data.success) {
                appendBulkLog(`[${new Date().toLocaleTimeString()}] ❌ Error: ${data.error || 'Batch failed'}`, 'error');
                pauseBulkVerification();
                return;
            }

            const processed = data.processed_count || 0;
            bulkProcessedCount += processed;

            if (data.results && data.results.length > 0) {
                data.results.forEach(r => {
                    const badge = (r.verdict || 'valid').toUpperCase();
                    const color = r.verdict === 'valid' ? 'text-emerald-400' : (r.verdict === 'invalid' ? 'text-rose-400' : 'text-amber-400');
                    appendBulkLog(`[${new Date().toLocaleTimeString()}] ${r.email} -> <span class="${color} font-bold">[${badge} Score: ${r.score}]</span>`, 'item');
                });
            }

            const countEl = document.getElementById('bulkProcessedCount');
            const percentEl = document.getElementById('bulkProgressPercent');
            const bar = document.getElementById('bulkProgressBarFill');

            if (countEl) countEl.textContent = bulkProcessedCount;
            const target = data.stats?.total || bulkTotalTarget || 1;
            const pct = Math.min(100, Math.round((bulkProcessedCount / target) * 100));
            if (percentEl) percentEl.textContent = pct + '%';
            if (bar) bar.style.width = pct + '%';

            if (data.has_more && processed > 0 && !bulkPaused) {
                setTimeout(() => runBulkBatchLoop(batchSize, unverifiedOnly), 500);
            } else {
                isBulkRunning = false;
                const btnStart = document.getElementById('btnStartBulk');
                const btnPause = document.getElementById('btnPauseBulk');
                const statusPill = document.getElementById('bulkStatusPill');

                if (btnStart) {
                    btnStart.classList.remove('hidden');
                    btnStart.textContent = '✓ Finished';
                }
                if (btnPause) btnPause.classList.add('hidden');
                if (statusPill) {
                    statusPill.textContent = 'COMPLETED';
                    statusPill.className = 'text-[10px] font-mono px-2.5 py-1 rounded-full bg-emerald-500 text-dark font-black';
                }
                appendBulkLog(`[${new Date().toLocaleTimeString()}] 🎉 Verification complete! All target contacts processed.`, 'success');
            }
        })
        .catch(err => {
            appendBulkLog(`[${new Date().toLocaleTimeString()}] ⚠️ Network exception during batch. Pausing.`, 'error');
            pauseBulkVerification();
        });
}

function appendBulkLog(html, type) {
    const logBox = document.getElementById('bulkTerminalLog');
    if (!logBox) return;
    const div = document.createElement('div');
    if (type === 'error') div.className = 'text-rose-400 font-bold';
    else if (type === 'warn') div.className = 'text-amber-300';
    else if (type === 'success') div.className = 'text-emerald-400 font-bold';
    else if (type === 'info') div.className = 'text-gold';
    else div.className = 'text-gray-300';
    div.innerHTML = html;
    logBox.appendChild(div);
    logBox.scrollTop = logBox.scrollHeight;
}

function clearBulkLog() {
    const logBox = document.getElementById('bulkTerminalLog');
    if (logBox) logBox.innerHTML = '<div class="text-gray-500">// Terminal log cleared.</div>';
}

// ══════════════════════════════════════════════════════════════════════════════
// 1-CLICK VERIFICATION & MULTI-SELECT TABLE CONTROLLERS
// ══════════════════════════════════════════════════════════════════════════════

// Multi-Contact Row Selection
function toggleSelectAllContacts(masterCheckbox) {
    const checkboxes = document.querySelectorAll('.contact-row-check');
    checkboxes.forEach(cb => {
        cb.checked = masterCheckbox.checked;
    });
    updateSelectedContactsUI();
}

function updateSelectedContactsUI() {
    const checked = document.querySelectorAll('.contact-row-check:checked');
    const all = document.querySelectorAll('.contact-row-check');
    const count = checked.length;
    const card = document.getElementById('floatingBulkActionCard');
    const countDisplay = document.getElementById('selectedCountDisplay');
    const master = document.getElementById('selectAllContactsCheck');

    if (countDisplay) {
        countDisplay.textContent = `${count} contact${count === 1 ? '' : 's'} selected`;
    }

    if (card) {
        if (count > 0) {
            card.classList.remove('hidden');
        } else {
            card.classList.add('hidden');
        }
    }

    if (master && all.length > 0) {
        master.checked = count === all.length;
        master.indeterminate = count > 0 && count < all.length;
    }
}

function clearSelectedContacts() {
    const checkboxes = document.querySelectorAll('.contact-row-check');
    checkboxes.forEach(cb => { cb.checked = false; });
    const master = document.getElementById('selectAllContactsCheck');
    if (master) {
        master.checked = false;
        master.indeterminate = false;
    }
    updateSelectedContactsUI();
}

function verifySelectedContacts() {
    const checked = document.querySelectorAll('.contact-row-check:checked');
    if (!checked || checked.length === 0) {
        EstateDialog.toast('Please select at least one contact to verify.', 'warning');
        return;
    }

    const ids = Array.from(checked).map(cb => cb.value).filter(Boolean);
    const btn = document.getElementById('btnVerifySelected');
    const originalHtml = btn ? btn.innerHTML : '';

    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<span class="animate-spin inline-block">⏳</span> Verifying (${ids.length})...`;
    }

    fetch(`/api/email-verify.php?action=verify_batch&ids=${encodeURIComponent(ids.join(','))}&deep_smtp=0`)
        .then(res => res.json())
        .then(data => {
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = originalHtml;
            }

            if (!data.success) {
                EstateDialog.toast('Verification error: ' + (data.error || 'Failed'), 'error');
                return;
            }

            // Update row badges and scores in real time
            if (data.results && data.results.length > 0) {
                data.results.forEach(r => {
                    const badgeCell = document.getElementById('verify-badge-cell-' + r.id);
                    const scoreCell = document.getElementById('verify-score-cell-' + r.id);
                    const verdict = (r.verdict || 'valid').toLowerCase();
                    const score = r.score || 50;

                    if (badgeCell) {
                        const badgeHtml = {
                            valid: '<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-400 border border-emerald-500/40"><span>✓</span> <span>VALID</span></span>',
                            risky: '<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-400 border border-amber-500/40"><span>⚠️</span> <span>RISKY</span></span>',
                            catch_all: '<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-purple-500/20 text-purple-400 border border-purple-500/40"><span>🌐</span> <span>CATCH-ALL</span></span>',
                            invalid: '<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-black bg-rose-500/20 text-rose-400 border border-rose-500/40"><span>✕</span> <span>INVALID</span></span>'
                        }[verdict] || '<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-dark-surface text-gray-400 border border-dark-border"><span>○</span> <span>UNVERIFIED</span></span>';
                        badgeCell.innerHTML = badgeHtml;
                    }

                    if (scoreCell) {
                        scoreCell.innerHTML = `
                            <div class="flex items-center gap-1.5">
                                <div class="w-12 bg-dark-border rounded-full h-1.5 overflow-hidden">
                                    <div class="bg-gold h-full" style="width: ${Math.min(100, score)}%;"></div>
                                </div>
                                <span class="text-gray-300 font-bold">${score}</span>
                            </div>
                        `;
                    }
                });
            }

            clearSelectedContacts();
            EstateDialog.toast(`Successfully verified ${ids.length} selected contacts!`, 'success');
        })
        .catch(err => {
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = originalHtml;
            }
            EstateDialog.toast('Network connection error while verifying selected contacts.', 'error');
        });
}

// 1-Click Verify All Modal Controller
let isModalVerifyRunning = false;
let modalVerifyPaused = false;
let modalVerifyProcessed = 0;
let modalVerifyTarget = <?= (int)($vStats['unverified']) ?>;
let modalVerifyStartTime = 0;
let modalBatchIndex = 0;

function openVerifyAllModal() {
    openModal('verifyAllModal');
    syncModalTargetCount();
}

function syncModalTargetCount() {
    const onlyUnverified = document.getElementById('modalOnlyUnverifiedCheck') ? document.getElementById('modalOnlyUnverifiedCheck').checked : true;
    const targetEl = document.getElementById('modalTargetDisplay');
    const unverifiedTotal = <?= (int)($vStats['unverified']) ?>;
    const allTotal = <?= (int)($stats['total_contacts']) ?>;

    modalVerifyTarget = onlyUnverified ? unverifiedTotal : allTotal;
    if (targetEl) {
        targetEl.textContent = Number(modalVerifyTarget).toLocaleString();
    }
}

function startModalAllVerification() {
    if (isModalVerifyRunning && !modalVerifyPaused) return;

    const btnStart = document.getElementById('btnModalStartVerify');
    const btnPause = document.getElementById('btnModalPauseVerify');
    const statusBadge = document.getElementById('modalStatusBadge');
    const isDeep = document.getElementById('radioEngineDeep') ? document.getElementById('radioEngineDeep').checked : false;
    const batchSize = parseInt(document.getElementById('modalBatchSizeSelect') ? document.getElementById('modalBatchSizeSelect').value : '100', 10);
    const onlyUnverified = document.getElementById('modalOnlyUnverifiedCheck') ? (document.getElementById('modalOnlyUnverifiedCheck').checked ? '1' : '0') : '1';

    if (!isModalVerifyRunning) {
        modalVerifyStartTime = Date.now();
        modalBatchIndex = 0;
        modalVerifyProcessed = 0;
        clearModalLiveFeed();
    }

    isModalVerifyRunning = true;
    modalVerifyPaused = false;

    if (btnStart) btnStart.classList.add('hidden');
    if (btnPause) {
        btnPause.classList.remove('hidden');
        btnPause.textContent = '⏸️ Pause';
    }
    if (statusBadge) {
        statusBadge.textContent = isDeep ? 'DEEP RUNNING' : 'TURBO RUNNING';
        statusBadge.className = 'px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold animate-pulse';
    }

    appendModalFeed(`[${new Date().toLocaleTimeString()}] 🚀 Initiated 1-Click Verification (${isDeep ? 'Deep Socket' : 'Turbo Mode'}, Batch: ${batchSize})...`, 'info');
    runModalVerifyLoop(batchSize, onlyUnverified, isDeep ? '1' : '0');
}

function pauseModalVerification() {
    modalVerifyPaused = true;
    const btnStart = document.getElementById('btnModalStartVerify');
    const btnPause = document.getElementById('btnModalPauseVerify');
    const statusBadge = document.getElementById('modalStatusBadge');

    if (btnStart) {
        btnStart.classList.remove('hidden');
        btnStart.innerHTML = '<span>▶️ Resume Verification</span>';
    }
    if (btnPause) btnPause.classList.add('hidden');
    if (statusBadge) {
        statusBadge.textContent = 'PAUSED';
        statusBadge.className = 'px-2 py-0.5 rounded-full text-[10px] font-mono bg-amber-500/20 text-amber-400 border border-amber-500/40 font-bold';
    }

    appendModalFeed(`[${new Date().toLocaleTimeString()}] ⏸️ Verification paused.`, 'warn');
}

function runModalVerifyLoop(batchSize, unverifiedOnly, deepSmtp) {
    if (!isModalVerifyRunning || modalVerifyPaused) return;

    modalBatchIndex++;
    const batchNumEl = document.getElementById('modalBatchNumDisplay');
    if (batchNumEl) batchNumEl.textContent = `Batch: #${modalBatchIndex}`;

    fetch(`/api/email-verify.php?action=verify_batch&batch_size=${batchSize}&unverified_only=${unverifiedOnly}&deep_smtp=${deepSmtp}`)
        .then(res => res.json())
        .then(data => {
            if (!data.success) {
                appendModalFeed(`[${new Date().toLocaleTimeString()}] ❌ Batch error: ${data.error || 'Request failed'}`, 'error');
                pauseModalVerification();
                return;
            }

            const processed = data.processed_count || 0;
            modalVerifyProcessed += processed;

            if (data.results && data.results.length > 0) {
                data.results.forEach(r => {
                    const badge = (r.verdict || 'valid').toUpperCase();
                    const color = r.verdict === 'valid' ? 'text-emerald-400' : (r.verdict === 'invalid' ? 'text-rose-400' : 'text-amber-400');
                    appendModalFeed(`[${new Date().toLocaleTimeString()}] ${r.email} ➔ <span class="${color} font-bold">[${badge} ${r.score}]</span> <span class="text-gray-500">(${r.summary || ''})</span>`, 'item');
                });
            }

            // Update Live Counters
            const processedEl = document.getElementById('modalProcessedDisplay');
            const validEl = document.getElementById('modalValidDisplay');
            const riskyBadEl = document.getElementById('modalRiskyBadDisplay');
            const percentEl = document.getElementById('modalProgressPercent');
            const bar = document.getElementById('modalProgressBarFill');
            const speedEl = document.getElementById('modalSpeedDisplay');
            const etaEl = document.getElementById('modalEtaDisplay');

            if (processedEl) processedEl.textContent = Number(modalVerifyProcessed).toLocaleString();

            if (data.stats) {
                if (validEl) validEl.textContent = Number(data.stats.valid || 0).toLocaleString();
                if (riskyBadEl) riskyBadEl.textContent = Number((data.stats.risky || 0) + (data.stats.invalid || 0)).toLocaleString();

                const invEl = document.getElementById('modalLiveInvalidCount');
                const rskEl = document.getElementById('modalLiveRiskyCount');
                const invBadge = document.getElementById('modalBadgeInvalidNum');
                const rskBadge = document.getElementById('modalBadgeRiskyNum');
                const invFinish = document.getElementById('modalFinishInvalidCount');
                const rskFinish = document.getElementById('modalFinishRiskyCount');

                if (invEl) invEl.textContent = Number(data.stats.invalid || 0).toLocaleString();
                if (rskEl) rskEl.textContent = Number(data.stats.risky || 0).toLocaleString();
                if (invBadge) invBadge.textContent = Number(data.stats.invalid || 0).toLocaleString();
                if (rskBadge) rskBadge.textContent = Number(data.stats.risky || 0).toLocaleString();
                if (invFinish) invFinish.textContent = Number(data.stats.invalid || 0).toLocaleString();
                if (rskFinish) rskFinish.textContent = Number(data.stats.risky || 0).toLocaleString();
            }

            // Calculate Speed & ETA
            const elapsedSec = Math.max(0.5, (Date.now() - modalVerifyStartTime) / 1000);
            const speed = (modalVerifyProcessed / elapsedSec).toFixed(1);
            const target = modalVerifyTarget || (data.stats ? data.stats.total : 1);
            const remaining = Math.max(0, target - modalVerifyProcessed);
            const etaSec = parseFloat(speed) > 0 ? Math.ceil(remaining / parseFloat(speed)) : 0;

            if (speedEl) speedEl.textContent = `${speed} contacts/sec`;
            if (etaEl) etaEl.textContent = `ETA: ${etaSec > 60 ? Math.ceil(etaSec / 60) + 'm' : etaSec + 's'}`;

            // Update Progress Bar
            const pct = Math.min(100, Math.round((modalVerifyProcessed / Math.max(1, target)) * 100));
            if (percentEl) percentEl.textContent = `${pct}%`;
            if (bar) bar.style.width = `${pct}%`;

            // Next batch or complete
            if (data.has_more && processed > 0 && !modalVerifyPaused) {
                setTimeout(() => runModalVerifyLoop(batchSize, unverifiedOnly, deepSmtp), 60);
            } else {
                finishModalVerification();
            }
        })
        .catch(err => {
            appendModalFeed(`[${new Date().toLocaleTimeString()}] ⚠️ Network exception during batch. Pausing.`, 'error');
            pauseModalVerification();
        });
}

function finishModalVerification() {
    isModalVerifyRunning = false;
    const btnStart = document.getElementById('btnModalStartVerify');
    const btnPause = document.getElementById('btnModalPauseVerify');
    const statusBadge = document.getElementById('modalStatusBadge');
    const completionBanner = document.getElementById('modalCompletionBanner');
    const bar = document.getElementById('modalProgressBarFill');
    const percentEl = document.getElementById('modalProgressPercent');

    if (btnStart) btnStart.classList.add('hidden');
    if (btnPause) btnPause.classList.add('hidden');
    if (completionBanner) completionBanner.classList.remove('hidden');
    if (percentEl) percentEl.textContent = '100%';
    if (bar) bar.style.width = '100%';
    if (statusBadge) {
        statusBadge.textContent = 'COMPLETED';
        statusBadge.className = 'px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500 text-dark font-black';
    }

    appendModalFeed(`[${new Date().toLocaleTimeString()}] 🎉 1-Click Verification Complete! All target contacts verified.`, 'success');
}

function appendModalFeed(html, type) {
    const feed = document.getElementById('modalVerifyLiveFeed');
    if (!feed) return;
    const div = document.createElement('div');
    if (type === 'error') div.className = 'text-rose-400 font-bold';
    else if (type === 'warn') div.className = 'text-amber-300';
    else if (type === 'success') div.className = 'text-emerald-400 font-bold';
    else if (type === 'info') div.className = 'text-gold';
    else div.className = 'text-gray-300 truncate';
    div.innerHTML = html;
    feed.appendChild(div);
    feed.scrollTop = feed.scrollHeight;
}

function clearModalLiveFeed() {
    const feed = document.getElementById('modalVerifyLiveFeed');
    if (feed) feed.innerHTML = '<div class="text-gray-500">// Live stream initialized...</div>';
}

// ══════════════════════════════════════════════════════════════════════════════
// PURGE & DELETION CONTROLLERS (MODAL & MULTI-SELECT TABLE)
// ══════════════════════════════════════════════════════════════════════════════

function purgeModalContacts(target) {
    target = target || 'invalid';
    const targetLabel = {
        'invalid': 'ALL Invalid / Bounced email contacts',
        'risky': 'ALL Risky / Generic Role email contacts',
        'unhealthy': 'ALL Invalid AND Risky email contacts (Clean Entire List)'
    }[target] || target;

    const confirmMsg = `Are you sure you want to permanently delete ${targetLabel} from your Estate HDR database?\n\nThis will remove those contact records completely to protect your domain sender reputation.`;
    EstateDialog.confirm(confirmMsg, 'Confirm Permanent Delete', {
        icon: '🗑️',
        confirmText: 'Permanently Delete',
        danger: true
    }).then(confirmed => {
        if (!confirmed) return;

        appendModalFeed(`[${new Date().toLocaleTimeString()}] 🧹 Cleaning ${target} contacts from database...`, 'warn');

        fetch(`/api/email-verify.php?action=purge_contacts&target=${encodeURIComponent(target)}`)
            .then(res => res.json())
            .then(data => {
                if (!data.success) {
                    appendModalFeed(`[${new Date().toLocaleTimeString()}] ❌ Purge failed: ${data.error || 'Server error'}`, 'error');
                    EstateDialog.toast('Purge error: ' + (data.error || 'Failed'), 'error');
                    return;
                }

                const removed = data.removed_count || 0;
                appendModalFeed(`[${new Date().toLocaleTimeString()}] 🗑️ Successfully deleted ${removed} ${target} contacts from CRM!`, 'success');

                // Update modal counters live
                if (data.stats) {
                    const targetEl = document.getElementById('modalTargetDisplay');
                    const validEl = document.getElementById('modalValidDisplay');
                    const riskyBadEl = document.getElementById('modalRiskyBadDisplay');
                    const invEl = document.getElementById('modalLiveInvalidCount');
                    const rskEl = document.getElementById('modalLiveRiskyCount');
                    const invBadge = document.getElementById('modalBadgeInvalidNum');
                    const rskBadge = document.getElementById('modalBadgeRiskyNum');
                    const invFinish = document.getElementById('modalFinishInvalidCount');
                    const rskFinish = document.getElementById('modalFinishRiskyCount');

                    if (invEl) invEl.textContent = Number(data.stats.invalid || 0).toLocaleString();
                    if (rskEl) rskEl.textContent = Number(data.stats.risky || 0).toLocaleString();
                    if (invBadge) invBadge.textContent = Number(data.stats.invalid || 0).toLocaleString();
                    if (rskBadge) rskBadge.textContent = Number(data.stats.risky || 0).toLocaleString();
                    if (invFinish) invFinish.textContent = Number(data.stats.invalid || 0).toLocaleString();
                    if (rskFinish) rskFinish.textContent = Number(data.stats.risky || 0).toLocaleString();
                    if (validEl) validEl.textContent = Number(data.stats.valid || 0).toLocaleString();
                    if (riskyBadEl) riskyBadEl.textContent = Number((data.stats.risky || 0) + (data.stats.invalid || 0)).toLocaleString();
                    if (targetEl) targetEl.textContent = Number(data.stats.total || 0).toLocaleString();
                }

                EstateDialog.toast(`Cleaned ${removed} ${target} contacts from your database! Active contacts: ${Number(data.remaining_count).toLocaleString()}. Refreshing...`, 'success');
                setTimeout(() => {
                    window.location.reload();
                }, 1500);
            })
            .catch(err => {
                appendModalFeed(`[${new Date().toLocaleTimeString()}] ⚠️ Network exception during purge.`, 'error');
                EstateDialog.toast('Network error while deleting contacts.', 'error');
            });
    });
}

function deleteSelectedContacts() {
    const checked = document.querySelectorAll('.contact-row-check:checked');
    if (!checked || checked.length === 0) {
        EstateDialog.toast('Please select at least one contact to delete.', 'warning');
        return;
    }

    const ids = Array.from(checked).map(cb => cb.value).filter(Boolean);
    EstateDialog.confirm(`Permanently delete ${ids.length} selected contact(s) from your database? This action cannot be undone.`, 'Delete Selected Contacts', {
        icon: '🗑️',
        confirmText: 'Delete Contacts',
        danger: true
    }).then(confirmed => {
        if (!confirmed) return;

        const btn = document.getElementById('btnDeleteSelected');
        const originalHtml = btn ? btn.innerHTML : '';
        if (btn) {
            btn.disabled = true;
            btn.innerHTML = `<span class="animate-spin inline-block">⏳</span> Deleting...`;
        }

        fetch(`/api/email-verify.php?action=purge_contacts&target=selected&ids=${encodeURIComponent(ids.join(','))}`)
            .then(res => res.json())
            .then(data => {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = originalHtml;
                }

                if (!data.success) {
                    EstateDialog.toast('Deletion error: ' + (data.error || 'Failed'), 'error');
                    return;
                }

                // Remove rows with animation
                ids.forEach(id => {
                    const checkbox = document.querySelector(`.contact-row-check[value="${id}"]`);
                    if (checkbox) {
                        const row = checkbox.closest('tr');
                        if (row) {
                            row.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                            row.style.opacity = '0';
                            row.style.transform = 'scale(0.95)';
                            setTimeout(() => row.remove(), 300);
                        }
                    }
                });

                clearSelectedContacts();
                EstateDialog.toast(`Successfully deleted ${ids.length} selected contacts!`, 'success');
            })
            .catch(err => {
                if (btn) {
                    btn.disabled = false;
                    btn.innerHTML = originalHtml;
                }
                EstateDialog.toast('Network connection error while deleting selected contacts.', 'error');
            });
    });
}
</script>

</body>
</html>
