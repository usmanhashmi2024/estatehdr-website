<?php
/**
 * Estate HDR - Enterprise Sales CRM & Pipeline
 * Enterprise Layer: Sales CRM, Deal Pipeline & Onboarding
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/saas-db.php';

requireAdmin();
$currentAdmin = currentAdminUser();

$crmFile = __DIR__ . '/../data/crm_pipeline.json';
if (!file_exists($crmFile)) {
    $initialLeads = [
        [
            'id' => 'LEAD-101',
            'company' => 'Premier West Realty Media',
            'contact_name' => 'Marcus Vance',
            'email' => 'marcus@premierwest.com',
            'country' => 'United States',
            'stage' => 'Trial', // Lead, Qualified, Trial, Proposal, Won, Active
            'lead_owner' => 'Sara Bilal',
            'est_monthly_photos' => 1200,
            'est_monthly_revenue' => 1800,
            'next_follow_up' => date('Y-m-d', strtotime('+2 days')),
            'notes' => 'Evaluating 3 free sample brackets. Impressed with natural window clarity.',
            'created_at' => date('Y-m-d H:i:s')
        ],
        [
            'id' => 'LEAD-102',
            'company' => 'London Prime Architectural',
            'contact_name' => 'Oliver Wright',
            'email' => 'o.wright@londonprime.co.uk',
            'country' => 'United Kingdom',
            'stage' => 'Proposal',
            'lead_owner' => 'Ahmad Khan',
            'est_monthly_photos' => 2500,
            'est_monthly_revenue' => 4200,
            'next_follow_up' => date('Y-m-d', strtotime('+1 day')),
            'notes' => 'Sent Enterprise Contract draft ($1.40/image with 12h SLA).',
            'created_at' => date('Y-m-d H:i:s')
        ],
        [
            'id' => 'LEAD-103',
            'company' => 'Sydney Coastal Photography',
            'contact_name' => 'Liam Henderson',
            'email' => 'liam@sydneycoastal.com.au',
            'country' => 'Australia',
            'stage' => 'Won',
            'lead_owner' => 'Owner',
            'est_monthly_photos' => 800,
            'est_monthly_revenue' => 1200,
            'next_follow_up' => date('Y-m-d', strtotime('+7 days')),
            'notes' => 'Converted from Free Trial! Onboarding checklist completed.',
            'created_at' => date('Y-m-d H:i:s')
        ]
    ];
    @file_put_contents($crmFile, json_encode($initialLeads, JSON_PRETTY_PRINT));
}

$leads = json_decode(@file_get_contents($crmFile), true) ?: [];

// Handle new lead submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_add_lead'])) {
    $newLead = [
        'id' => 'LEAD-' . (count($leads) + 101),
        'company' => trim($_POST['company'] ?? 'Agency'),
        'contact_name' => trim($_POST['contact_name'] ?? 'Contact'),
        'email' => trim($_POST['email'] ?? ''),
        'country' => trim($_POST['country'] ?? 'United States'),
        'stage' => trim($_POST['stage'] ?? 'Lead'),
        'lead_owner' => $currentAdmin['name'] ?? 'Admin',
        'est_monthly_photos' => (int)($_POST['est_monthly_photos'] ?? 500),
        'est_monthly_revenue' => (float)($_POST['est_monthly_revenue'] ?? 750),
        'next_follow_up' => trim($_POST['next_follow_up'] ?? date('Y-m-d', strtotime('+3 days'))),
        'notes' => trim($_POST['notes'] ?? ''),
        'created_at' => date('Y-m-d H:i:s')
    ];
    $leads[] = $newLead;
    @file_put_contents($crmFile, json_encode($leads, JSON_PRETTY_PRINT));
    setFlash('success', "New enterprise opportunity created for {$newLead['company']}!");
    header("Location: /admin/crm.php");
    exit;
}

$pipelineStages = ['Lead', 'Qualified', 'Trial', 'Proposal', 'Won', 'Active'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enterprise Sales CRM Pipeline — Estate HDR</title>
    <link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
        tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E',light:'#E5C05D'},dark:{DEFAULT:'#0B0E14',card:'#121721',border:'#1F2937'}}}}};
    </script>
    <link rel="stylesheet" href="/assets/css/app.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-[#0B0E14] text-gray-200 font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-6 py-8 space-y-6">
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-gray-800 pb-6">
        <div>
            <div class="text-xs uppercase font-extrabold tracking-widest text-gold mb-1">
                <span>ENTERPRISE ACQUISITION &amp; PIPELINE</span>
            </div>
            <h1 class="text-2xl sm:text-3xl font-black text-white">Sales CRM Pipeline</h1>
            <p class="text-xs text-gray-400 mt-1">Track high-volume photography studios, trial conversions &amp; enterprise contracts.</p>
        </div>

        <button type="button" onclick="document.getElementById('newLeadModal').classList.remove('hidden')" class="px-4 py-2.5 rounded-xl bg-gold hover:bg-gold-light text-black font-bold text-xs shadow-glow transition flex items-center gap-2">
            <i class="fas fa-plus"></i> New Deal / Opportunity
        </button>
    </div>

    <!-- ── MARKETING LEADS QUICK LINK BANNER ──────────────────────── -->
    <div class="p-4 rounded-2xl bg-gradient-to-r from-[#121721] via-[#161B26] to-[#121721] border border-gold/30 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-md">
        <div class="flex items-center gap-3">
            <span class="text-2xl">📬</span>
            <div>
                <div class="text-xs font-black text-white flex items-center gap-2">
                    <span>4,452 Verified Real Estate Listing Agents Loaded in Email CRM</span>
                    <span class="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">Ready for Outreach</span>
                </div>
                <p class="text-[11px] text-gray-400 mt-0.5">Keller Williams, eXp Realty, Compass, Coldwell Banker, RE/MAX and boutique agents segmented and ready for campaigns.</p>
            </div>
        </div>
        <a href="/admin/email-crm.php?tab=contacts" class="px-4 py-2 rounded-xl bg-gold hover:bg-gold-light text-dark font-black text-xs transition-all shadow-sm shrink-0 flex items-center gap-1.5">
            <span>View Agents in Email CRM ➔</span>
        </a>
    </div>

    <!-- ── PIPELINE STAGE COLUMNS ────────────────────────────────────── -->
    <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <?php foreach ($pipelineStages as $stage): 
            $stageLeads = array_filter($leads, fn($l) => strtolower($l['stage']) === strtolower($stage));
            $stageVal = array_sum(array_column($stageLeads, 'est_monthly_revenue'));
        ?>
            <div class="bg-[#121721] rounded-2xl border border-gray-800 p-4 flex flex-col min-h-[480px]">
                <div class="flex justify-between items-center mb-2 pb-2 border-b border-gray-800">
                    <h3 class="text-xs font-black uppercase tracking-wider text-white"><?= $stage ?></h3>
                    <span class="text-[10px] px-2 py-0.5 rounded-full bg-gold/10 text-gold font-bold font-mono">
                        <?= count($stageLeads) ?>
                    </span>
                </div>
                <div class="text-[11px] text-gray-400 mb-3 font-mono">
                    $<?= number_format($stageVal) ?> / mo
                </div>

                <div class="space-y-3 flex-1 overflow-y-auto">
                    <?php if (empty($stageLeads)): ?>
                        <div class="p-4 text-center text-gray-600 text-[11px] italic">No active deals</div>
                    <?php else: ?>
                        <?php foreach ($stageLeads as $lead): ?>
                            <div class="p-3 rounded-xl bg-[#161D2A] border border-gray-800 hover:border-gold/40 transition space-y-2 text-xs">
                                <div class="font-bold text-white"><?= htmlspecialchars($lead['company']) ?></div>
                                <div class="text-gray-400 text-[11px] flex items-center gap-1">
                                    <i class="fas fa-user text-gray-500"></i> <?= htmlspecialchars($lead['contact_name']) ?>
                                </div>
                                <div class="text-gray-400 text-[11px] flex items-center gap-1">
                                    <i class="fas fa-globe text-gray-500"></i> <?= htmlspecialchars($lead['country']) ?>
                                </div>
                                <div class="pt-2 border-t border-gray-800/80 flex justify-between items-center text-[10px]">
                                    <span class="text-gold font-mono font-bold">$<?= number_format($lead['est_monthly_revenue']) ?>/mo</span>
                                    <span class="text-gray-400 font-mono"><?= number_format($lead['est_monthly_photos']) ?> photos</span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</main>

<!-- New Lead Modal -->
<div id="newLeadModal" class="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
    <div class="bg-[#151B28] border border-gray-700 rounded-2xl max-w-md w-full p-6 shadow-2xl">
        <h3 class="text-base font-bold text-white mb-4 flex items-center gap-2">
            <i class="fas fa-briefcase text-gold"></i> Create Sales Lead / Opportunity
        </h3>
        <form method="POST">
            <input type="hidden" name="action_add_lead" value="1">
            <div class="space-y-3 text-xs">
                <div>
                    <label class="block text-gray-300 font-semibold mb-1">Company / Studio Name</label>
                    <input type="text" name="company" required class="w-full bg-[#0B0E14] border border-gray-700 rounded-lg p-2 text-white" placeholder="e.g. Skyline Real Estate Media">
                </div>
                <div>
                    <label class="block text-gray-300 font-semibold mb-1">Contact Name &amp; Email</label>
                    <div class="grid grid-cols-2 gap-2">
                        <input type="text" name="contact_name" required class="bg-[#0B0E14] border border-gray-700 rounded-lg p-2 text-white" placeholder="Contact Name">
                        <input type="email" name="email" required class="bg-[#0B0E14] border border-gray-700 rounded-lg p-2 text-white" placeholder="Email Address">
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-2">
                    <div>
                        <label class="block text-gray-300 font-semibold mb-1">Country</label>
                        <select name="country" class="w-full bg-[#0B0E14] border border-gray-700 rounded-lg p-2 text-white">
                            <option value="United States">United States</option>
                            <option value="United Kingdom">United Kingdom</option>
                            <option value="Australia">Australia</option>
                            <option value="Canada">Canada</option>
                            <option value="UAE">United Arab Emirates</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-gray-300 font-semibold mb-1">Pipeline Stage</label>
                        <select name="stage" class="w-full bg-[#0B0E14] border border-gray-700 rounded-lg p-2 text-white">
                            <option value="Lead">Lead</option>
                            <option value="Qualified">Qualified</option>
                            <option value="Trial">Free Trial</option>
                            <option value="Proposal">Proposal / Contract</option>
                            <option value="Won">Won</option>
                        </select>
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-2">
                    <div>
                        <label class="block text-gray-300 font-semibold mb-1">Est. Photos / Mo</label>
                        <input type="number" name="est_monthly_photos" value="1000" class="w-full bg-[#0B0E14] border border-gray-700 rounded-lg p-2 text-white font-mono">
                    </div>
                    <div>
                        <label class="block text-gray-300 font-semibold mb-1">Est. Revenue / Mo ($)</label>
                        <input type="number" name="est_monthly_revenue" value="1500" class="w-full bg-[#0B0E14] border border-gray-700 rounded-lg p-2 text-white font-mono">
                    </div>
                </div>
            </div>
            <div class="mt-6 flex justify-end gap-3">
                <button type="button" onclick="document.getElementById('newLeadModal').classList.add('hidden')" class="px-4 py-2 text-xs rounded-lg bg-gray-800 text-gray-300">Cancel</button>
                <button type="submit" class="px-4 py-2 text-xs font-bold rounded-lg bg-gold hover:bg-gold-light text-black">Create Opportunity</button>
            </div>
        </form>
    </div>
</div>

</body>
</html>
