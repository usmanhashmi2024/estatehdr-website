<?php
/**
 * Estate HDR — Management Live Client Chat Console
 * Allows Studio Management (Owner, Manager, Supervisor, Team Lead) to communicate
 * directly with authenticated portal clients in real time, view client order breakdown,
 * and share attachments/screenshots.
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/services/ClientChatService.php';

requireAdmin();
$currentAdmin = currentAdminUser();

$allChats = ClientChatService::getAllChats();
// Sort by last_active DESC
uasort($allChats, fn($a, $b) => ($b['last_active_ts'] ?? 0) <=> ($a['last_active_ts'] ?? 0));

$totalUnread = ClientChatService::getTotalAdminUnreadCount();

// Selected client (default to first active chat if available)
$selectedClientId = trim($_GET['client_id'] ?? '');
if (empty($selectedClientId) && !empty($allChats)) {
    $firstChat = reset($allChats);
    $selectedClientId = $firstChat['client_id'];
}

$activeThread = null;
if ($selectedClientId && isset($allChats[$selectedClientId])) {
    $activeThread = $allChats[$selectedClientId];
    ClientChatService::markReadForAdmin($selectedClientId);
    $activeThread['unread_admin'] = 0;
}

// Fetch client order summary
$clientOrderSummary = $selectedClientId ? ClientChatService::getClientOrderSummary($selectedClientId) : null;
$clientOrders = $clientOrderSummary['orders'] ?? [];
$clientProfile = $selectedClientId ? getUserById($selectedClientId) : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Live Chat Management — Estate HDR</title>
    <link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
        tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E',light:'#E5C05D'},dark:{DEFAULT:'#0B0E14',card:'#121721',border:'#1F2937'}}}}};
    </script>
    <link rel="stylesheet" href="/assets/css/app.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-[#0B0E14] text-gray-200 font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-6 space-y-6">

    <!-- ── 1. HEADER ───────────────────────────────────────────────── -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#121721] p-5 sm:p-6 rounded-3xl border border-gray-800 shadow-xl">
        <div>
            <div class="flex items-center gap-2 mb-1">
                <span class="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/40 text-emerald-400 text-xs font-bold">
                    <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                    2-Way Client Live Desk
                </span>
                <?php if ($totalUnread > 0): ?>
                    <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-red-500/20 border border-red-500/40 text-red-400 text-xs font-bold font-mono">
                        <?= $totalUnread ?> Unread Client Messages
                    </span>
                <?php endif; ?>
            </div>
            <h1 class="text-2xl sm:text-3xl font-black text-white flex items-center gap-2.5">
                <span>💬 Client Direct Live Chat Console</span>
            </h1>
            <p class="text-xs sm:text-sm text-gray-400 mt-1 max-w-2xl leading-relaxed">
                Communicate directly with registered clients in real time. Answer order inquiries, resolve revision requests, attach edited samples, and expedite critical production batches.
            </p>
        </div>

        <div class="flex items-center gap-3">
            <a href="/admin/command-center.php" class="px-3.5 py-2 rounded-xl bg-gray-800 hover:bg-gray-700 border border-gray-700 text-xs text-gray-300 font-bold transition flex items-center gap-2">
                <span>🎛️</span> <span>Command Center</span>
            </a>
            <button type="button" onclick="location.reload()" class="btn-gold py-2 px-4 rounded-xl text-xs font-bold shadow-glow flex items-center gap-2">
                <i class="fas fa-rotate"></i> <span>Refresh Inbox</span>
            </button>
        </div>
    </div>

    <!-- ── 2. TWO-COLUMN WORKSPACE: INBOX LIST (LEFT) & CHAT CONSOLE (RIGHT) ── -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

        <!-- ════════════════════════════════════════════════════════════ -->
        <!-- ── LEFT: CLIENT INBOX LIST (4 COLUMNS) ──────────────────── -->
        <!-- ════════════════════════════════════════════════════════════ -->
        <div class="lg:col-span-4 bg-[#121721] rounded-3xl border border-gray-800 shadow-2xl p-5 space-y-4 h-[780px] flex flex-col">
            <div class="flex items-center justify-between border-b border-gray-800 pb-3">
                <h3 class="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                    <span>👥 Active Clients</span>
                </h3>
                <span class="text-xs text-gray-400 font-mono"><?= count($allChats) ?> Threads</span>
            </div>

            <!-- Client Filter -->
            <div>
                <input 
                    type="text" 
                    id="clientFilterInput" 
                    oninput="filterClientList()" 
                    placeholder="Search client name or email..." 
                    class="w-full bg-[#0B0E14] border border-gray-800 rounded-xl px-3 py-2 text-xs text-white focus:border-gold focus:outline-none"
                >
            </div>

            <!-- List -->
            <div id="clientInboxList" class="flex-1 overflow-y-auto space-y-2 pr-1">
                <?php if (empty($allChats)): ?>
                    <div class="py-16 text-center text-gray-500 text-xs">
                        <i class="fas fa-comments text-3xl mb-2 text-gray-600"></i>
                        <p class="text-gray-300 font-bold">No Client Chats Yet</p>
                        <p class="mt-1">When clients send a message from their portal, it will appear here in real time.</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($allChats as $cid => $c): 
                        $isSelected = ($cid === $selectedClientId);
                        $unread = (int)($c['unread_admin'] ?? 0);
                        $cMsgs = (!empty($c['messages']) && is_array($c['messages'])) ? $c['messages'] : [];
                        $lastMsg = !empty($cMsgs) ? end($cMsgs) : null;
                        $lastText = $lastMsg['text'] ?? 'Conversation started';
                    ?>
                        <a 
                            href="?client_id=<?= urlencode($cid) ?>" 
                            class="block p-3.5 rounded-2xl border transition-all client-thread-item <?= $isSelected 
                                ? 'bg-gold/15 border-gold/50 shadow-glow' 
                                : 'bg-[#161D2A] border-gray-800/80 hover:border-gold/30 hover:bg-[#1A2232]' ?>"
                            data-search="<?= htmlspecialchars(strtolower($c['client_name'] . ' ' . $c['client_email'])) ?>"
                        >
                            <div class="flex items-start justify-between gap-2">
                                <div class="font-bold text-xs <?= $isSelected ? 'text-gold' : 'text-white' ?>">
                                    <?= htmlspecialchars($c['client_name']) ?>
                                </div>
                                <span class="text-[10px] text-gray-400 font-mono flex-shrink-0">
                                    <?= date('M j, H:i', strtotime($c['last_active'] ?? 'now')) ?>
                                </span>
                            </div>

                            <div class="text-[11px] text-gray-400 font-mono mt-0.5 truncate">
                                <?= htmlspecialchars($c['client_email']) ?>
                            </div>

                            <p class="text-xs text-gray-300 mt-1.5 line-clamp-1 italic">
                                &ldquo;<?= htmlspecialchars(substr($lastText, 0, 60)) ?>&hellip;&rdquo;
                            </p>

                            <div class="flex items-center justify-between mt-2 pt-2 border-t border-gray-800 text-[10px]">
                                <?php if (!empty($c['selected_order'])): ?>
                                    <span class="px-2 py-0.5 rounded bg-gold/10 text-gold border border-gold/20 font-mono font-bold">
                                        #<?= htmlspecialchars($c['selected_order']) ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-gray-500">General Inquiry</span>
                                <?php endif; ?>

                                <?php if ($unread > 0): ?>
                                    <span class="px-2 py-0.5 rounded-full bg-red-500 text-white font-bold font-mono animate-pulse">
                                        <?= $unread ?> New
                                    </span>
                                <?php else: ?>
                                    <span class="text-emerald-400">✓ Up to date</span>
                                <?php endif; ?>
                            </div>
                        </a>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- ════════════════════════════════════════════════════════════ -->
        <!-- ── RIGHT: ACTIVE CHAT THREAD & REPLY CONSOLE (8 COLUMNS) ── -->
        <!-- ════════════════════════════════════════════════════════════ -->
        <div class="lg:col-span-8 bg-[#121721] rounded-3xl border border-gray-800 shadow-2xl flex flex-col h-[780px] overflow-hidden">
            
            <?php if (!$activeThread): ?>
                <div class="flex-1 flex flex-col items-center justify-center p-8 text-center text-gray-500">
                    <i class="fas fa-comments text-5xl mb-3 text-gray-700"></i>
                    <h3 class="text-base font-bold text-white">Select a Client Conversation</h3>
                    <p class="text-xs text-gray-400 max-w-sm mt-1">
                        Choose a client from the inbox on the left to review their live conversation, see their properties, and reply.
                    </p>
                </div>
            <?php else: ?>

                <!-- Active Chat Header & Client Info Bar -->
                <div class="p-4 sm:p-5 bg-[#161D2A] border-b border-gray-800 flex flex-wrap items-center justify-between gap-4">
                    <div class="flex items-center gap-3.5">
                        <div class="w-11 h-11 rounded-2xl bg-gold/20 text-gold border border-gold/40 flex items-center justify-center font-black text-sm">
                            <?= strtoupper(substr($activeThread['client_name'] ?? 'CL', 0, 2)) ?>
                        </div>
                        <div>
                            <div class="font-bold text-white text-sm flex items-center gap-2">
                                <span><?= htmlspecialchars($activeThread['client_name']) ?></span>
                                <span class="text-[10px] px-2 py-0.5 rounded bg-gold/20 text-gold font-mono font-bold">
                                    Client #<?= htmlspecialchars($selectedClientId) ?>
                                </span>
                            </div>
                            <div class="text-xs text-gray-400 mt-0.5 flex flex-wrap items-center gap-2.5">
                                <span>✉️ <?= htmlspecialchars($activeThread['client_email']) ?></span>
                                <span>&bull;</span>
                                <?php if ($clientOrderSummary): ?>
                                    <span class="text-gray-300 font-mono text-[11px]">
                                        📦 <?= $clientOrderSummary['total'] ?> Total |
                                        <span class="text-amber-400">🎨 <?= $clientOrderSummary['processing'] ?></span> |
                                        <span class="text-purple-400">🛡️ <?= $clientOrderSummary['qa'] ?></span> |
                                        <span class="text-emerald-400">✅ <?= $clientOrderSummary['delivered'] ?></span>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="flex items-center gap-2">
                        <a href="/admin/client-new.php?id=<?= urlencode($selectedClientId) ?>" class="btn-ghost py-1.5 px-3 text-xs font-bold border border-gray-700 text-gray-300 hover:text-white rounded-xl">
                            Client Profile &rarr;
                        </a>
                        <a href="/admin/index.php?client_id=<?= urlencode($selectedClientId) ?>" class="btn-ghost py-1.5 px-3 text-xs font-bold border border-gold/40 text-gold hover:bg-gold/10 rounded-xl">
                            Orders (<?= count($clientOrders) ?>) &rarr;
                        </a>
                    </div>
                </div>

                <!-- Messages Stream -->
                <div id="adminMessagesContainer" class="flex-1 p-5 overflow-y-auto space-y-4 bg-[#0B0E14]/60">
                    <?php foreach (($activeThread['messages'] ?? []) as $msg): 
                        $isClient = ($msg['sender'] ?? '') === 'client';
                        $att = $msg['attachment'] ?? null;
                    ?>
                        <div class="flex flex-col <?= $isClient ? 'items-start' : 'items-end' ?> space-y-1">
                            <div class="flex items-center gap-2 text-[10px] text-gray-400">
                                <strong class="<?= $isClient ? 'text-gold' : 'text-blue-300' ?>">
                                    <?= htmlspecialchars($msg['sender_name'] ?? ($isClient ? $activeThread['client_name'] : 'Management')) ?>
                                </strong>
                                <span>•</span>
                                <span class="font-mono"><?= date('H:i', strtotime($msg['timestamp'] ?? 'now')) ?></span>
                                <?php if (!empty($msg['order_id'])): ?>
                                    <span class="px-2 py-0.5 rounded bg-gold/15 text-gold border border-gold/30 font-mono font-bold">
                                        🏷️ #<?= htmlspecialchars($msg['order_id']) ?>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="max-w-[85%] sm:max-w-[75%] p-3.5 rounded-2xl text-xs leading-relaxed <?= $isClient 
                                ? 'bg-[#161D2A] border border-gray-700/80 text-gray-100 rounded-bl-sm shadow-md' 
                                : 'bg-gradient-to-br from-[#1C180E] to-[#12110B] border border-gold/40 text-gray-100 rounded-br-sm shadow-md' ?>">
                                
                                <?php if (!empty($msg['text'])): ?>
                                    <p><?= nl2br(htmlspecialchars($msg['text'])) ?></p>
                                <?php endif; ?>

                                <!-- Attachment Display -->
                                <?php if (!empty($att)): ?>
                                    <div class="mt-2 pt-2 border-t border-gray-700/50">
                                        <?php if (!empty($att['is_image'])): ?>
                                            <div class="relative group cursor-pointer" onclick="openAdminLightbox('<?= htmlspecialchars($att['file_url'], ENT_QUOTES) ?>', '<?= htmlspecialchars($att['file_name'], ENT_QUOTES) ?>')">
                                                <img src="<?= htmlspecialchars($att['file_url']) ?>" alt="Attached image" class="max-h-48 max-w-full rounded-xl object-cover border border-gray-700 group-hover:border-gold transition">
                                                <div class="absolute inset-0 bg-black/40 rounded-xl opacity-0 group-hover:opacity-100 transition flex items-center justify-center text-white text-xs font-bold gap-1.5">
                                                    <i class="fas fa-search-plus"></i> View Full Image
                                                </div>
                                            </div>
                                            <div class="text-[10px] text-gray-400 mt-1 flex items-center justify-between">
                                                <span class="truncate max-w-[180px]"><?= htmlspecialchars($att['file_name']) ?></span>
                                                <span class="font-mono"><?= round(($att['file_size'] ?? 0) / 1024) ?> KB</span>
                                            </div>
                                        <?php else: ?>
                                            <a href="<?= htmlspecialchars($att['file_url']) ?>" download class="flex items-center gap-2.5 p-2 rounded-xl bg-black/30 border border-gray-700/80 hover:border-gold/40 text-gray-200 transition">
                                                <span class="text-xl text-gold">📄</span>
                                                <div class="flex-1 min-w-0">
                                                    <div class="font-bold text-xs truncate"><?= htmlspecialchars($att['file_name']) ?></div>
                                                    <div class="text-[10px] text-gray-400 font-mono"><?= round(($att['file_size'] ?? 0) / 1024) ?> KB &bull; Click to download</div>
                                                </div>
                                                <i class="fas fa-download text-xs text-gold"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Canned Responses Quick Bar -->
                <div class="px-4 py-2 bg-[#161D2A] border-t border-gray-800 flex items-center gap-2 overflow-x-auto text-[11px] whitespace-nowrap">
                    <span class="text-gray-500 font-bold text-[10px] uppercase tracking-wider">Canned:</span>
                    <button type="button" onclick="setAdminCannedReply('Your order is currently in retouching and on track for delivery within the next 2 hours.')" class="px-2.5 py-1 rounded-lg bg-[#0B0E14] hover:bg-gold/20 text-gray-300 hover:text-gold border border-gray-700 transition">
                        ⚡ In Retouching (2h)
                    </button>
                    <button type="button" onclick="setAdminCannedReply('We have alerted the shift supervisor to prioritize your property as an urgent rush order.')" class="px-2.5 py-1 rounded-lg bg-[#0B0E14] hover:bg-gold/20 text-gray-300 hover:text-gold border border-gray-700 transition">
                        🚀 Rush Prioritized
                    </button>
                    <button type="button" onclick="setAdminCannedReply('Your photos have passed QA inspection and your high-res download link is live in your portal.')" class="px-2.5 py-1 rounded-lg bg-[#0B0E14] hover:bg-gold/20 text-gray-300 hover:text-gold border border-gray-700 transition">
                        ✓ Delivered &amp; Ready
                    </button>
                    <button type="button" onclick="setAdminCannedReply('Revision instructions received! Our lead retoucher is executing the window pull adjustments right now.')" class="px-2.5 py-1 rounded-lg bg-[#0B0E14] hover:bg-gold/20 text-gray-300 hover:text-gold border border-gray-700 transition">
                        🎨 Revisions in Progress
                    </button>
                </div>

                <!-- Management Order Tag & Attachment Preview -->
                <div class="px-4 py-1.5 bg-[#121824] border-t border-gray-800 flex flex-wrap items-center justify-between gap-2 text-xs">
                    <div class="flex items-center gap-2">
                        <span class="text-gray-400 font-bold text-[11px] flex items-center gap-1">
                            <i class="fas fa-tag text-gold"></i> Reference Order:
                        </span>
                        <select id="adminOrderSelect" class="bg-[#0B0E14] border border-gray-700 rounded-lg px-2.5 py-1 text-xs text-white focus:border-gold focus:outline-none max-w-[240px]">
                            <option value="">General Reply (No Order Tag)</option>
                            <?php foreach ($clientOrders as $ord): ?>
                                <option value="<?= htmlspecialchars($ord['id']) ?>">
                                    #<?= htmlspecialchars($ord['id']) ?> — <?= htmlspecialchars(substr($ord['address'], 0, 22)) ?> (<?= htmlspecialchars($ord['status_label']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div id="adminAttPreviewBar" class="hidden items-center gap-2 bg-[#1C2333] px-2.5 py-1 rounded-lg border border-gray-700 text-xs">
                        <span id="adminAttIcon">📎</span>
                        <span id="adminAttName" class="font-bold max-w-[180px] truncate text-white"></span>
                        <button type="button" onclick="removeAdminAttachment()" class="text-gray-400 hover:text-red-400 ml-1">&times;</button>
                    </div>
                </div>

                <!-- Management Reply Form -->
                <div class="p-4 bg-[#161D2A] border-t border-gray-800">
                    <form id="adminReplyForm" onsubmit="handleSendAdminReply(event)" class="flex items-end gap-3">
                        <input type="file" id="adminFileInput" onchange="onAdminFileSelected(this)" accept="image/jpeg,image/png,image/webp,application/pdf,application/zip" class="hidden">
                        
                        <button 
                            type="button" 
                            onclick="document.getElementById('adminFileInput').click()" 
                            class="p-3 rounded-2xl bg-[#0B0E14] hover:bg-gold/10 border border-gray-700 hover:border-gold/50 text-gray-300 hover:text-gold transition shrink-0" 
                            title="Attach Photo or Document"
                        >
                            <i class="fas fa-paperclip text-base"></i>
                        </button>

                        <textarea 
                            id="adminReplyInput" 
                            rows="2" 
                            placeholder="Type official management reply to <?= htmlspecialchars($activeThread['client_name']) ?>... (Enter to Send)" 
                            class="flex-1 bg-[#0B0E14] border border-gray-700 rounded-2xl p-3 text-xs text-white focus:border-gold focus:outline-none resize-none leading-relaxed"
                            onkeydown="if(event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); handleSendAdminReply(event); }"
                        ></textarea>
                        
                        <button type="submit" id="adminSendBtn" class="btn-gold px-6 py-3 rounded-2xl font-black text-xs shadow-glow flex flex-col items-center justify-center gap-1 shrink-0">
                            <i class="fas fa-paper-plane text-sm"></i>
                            <span>Reply</span>
                        </button>
                    </form>
                </div>

            <?php endif; ?>

        </div>

    </div>

</main>

<!-- Lightbox Modal for Admin Images -->
<div id="adminLightboxModal" class="fixed inset-0 bg-black/90 backdrop-blur-md z-50 hidden flex flex-col items-center justify-center p-4">
    <div class="max-w-4xl w-full flex items-center justify-between text-white pb-3">
        <span id="adminLightboxFilename" class="text-xs font-mono text-gray-300"></span>
        <div class="flex items-center gap-3">
            <a id="adminLightboxDownloadBtn" href="#" download class="text-xs text-gold hover:underline flex items-center gap-1.5 font-bold">
                <i class="fas fa-download"></i> Download Full Size
            </a>
            <button type="button" onclick="closeAdminLightbox()" class="text-gray-400 hover:text-white text-2xl font-bold px-2">&times;</button>
        </div>
    </div>
    <div class="max-w-4xl max-h-[80vh] flex items-center justify-center overflow-hidden">
        <img id="adminLightboxImg" src="" alt="Enlarged screenshot" class="max-w-full max-h-[80vh] object-contain rounded-2xl border border-gray-700">
    </div>
</div>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
const SELECTED_CLIENT_ID = '<?= htmlspecialchars($selectedClientId, ENT_QUOTES) ?>';
let adminMsgCount = <?= count($activeThread['messages'] ?? []) ?>;
let adminSelectedFile = null;

function scrollAdminChatToBottom() {
    const box = document.getElementById('adminMessagesContainer');
    if (box) box.scrollTop = box.scrollHeight;
}
window.addEventListener('DOMContentLoaded', scrollAdminChatToBottom);

function setAdminCannedReply(text) {
    const input = document.getElementById('adminReplyInput');
    if (input) {
        input.value = text;
        input.focus();
    }
}

function filterClientList() {
    const query = document.getElementById('clientFilterInput').value.toLowerCase();
    document.querySelectorAll('.client-thread-item').forEach(el => {
        const hay = el.getAttribute('data-search') || '';
        el.style.display = hay.includes(query) ? '' : 'none';
    });
}

function onAdminFileSelected(input) {
    if (input.files && input.files[0]) {
        adminSelectedFile = input.files[0];
        const bar = document.getElementById('adminAttPreviewBar');
        const nameEl = document.getElementById('adminAttName');
        if (bar && nameEl) {
            nameEl.textContent = adminSelectedFile.name;
            bar.classList.remove('hidden');
            bar.classList.add('inline-flex');
        }
    }
}

function removeAdminAttachment() {
    adminSelectedFile = null;
    const input = document.getElementById('adminFileInput');
    if (input) input.value = '';
    const bar = document.getElementById('adminAttPreviewBar');
    if (bar) {
        bar.classList.add('hidden');
        bar.classList.remove('inline-flex');
    }
}

async function handleSendAdminReply(e) {
    if (e) e.preventDefault();
    if (!SELECTED_CLIENT_ID) return;

    const input = document.getElementById('adminReplyInput');
    const orderSelect = document.getElementById('adminOrderSelect');
    const btn = document.getElementById('adminSendBtn');

    const text = input.value.trim();
    if (!text && !adminSelectedFile) return;

    btn.disabled = true;
    btn.classList.add('opacity-50');

    try {
        const formData = new FormData();
        formData.append('action', 'admin_send');
        formData.append('client_id', SELECTED_CLIENT_ID);
        formData.append('text', text);
        if (orderSelect && orderSelect.value) {
            formData.append('order_id', orderSelect.value);
        }
        if (adminSelectedFile) {
            formData.append('attachment', adminSelectedFile);
        }

        const res = await fetch('/api/client-chat.php', {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        if (data.success && data.messages) {
            renderAdminMessages(data.messages);
            input.value = '';
            removeAdminAttachment();
            scrollAdminChatToBottom();
        } else if (data.error) {
            alert('Error sending reply: ' + data.error);
        }
    } catch (err) {
        console.error('Admin send error:', err);
    } finally {
        btn.disabled = false;
        btn.classList.remove('opacity-50');
    }
}

async function pollAdminActiveChat() {
    if (!SELECTED_CLIENT_ID) return;

    try {
        const res = await fetch(`/api/client-chat.php?action=admin_poll&client_id=${encodeURIComponent(SELECTED_CLIENT_ID)}`);
        const data = await res.json();
        if (data.success && data.messages) {
            if (data.messages.length !== adminMsgCount) {
                renderAdminMessages(data.messages);
                scrollAdminChatToBottom();
            }
        }
    } catch (err) {
        console.error('Admin poll error:', err);
    }
}

function renderAdminMessages(messages) {
    adminMsgCount = messages.length;
    const container = document.getElementById('adminMessagesContainer');
    if (!container) return;

    let html = '';
    messages.forEach(msg => {
        const isClient = msg.sender === 'client';
        const senderName = msg.sender_name || (isClient ? 'Client' : 'Management');
        const timeStr = msg.timestamp ? msg.timestamp.substring(11, 16) : 'Now';
        const orderBadge = msg.order_id 
            ? `<span class="px-2 py-0.5 rounded bg-gold/15 text-gold border border-gold/30 font-mono font-bold">🏷️ #${escapeHtml(msg.order_id)}</span>` 
            : '';

        const bubbleCls = isClient
            ? 'bg-[#161D2A] border border-gray-700/80 text-gray-100 rounded-bl-sm shadow-md'
            : 'bg-gradient-to-br from-[#1C180E] to-[#12110B] border border-gold/40 text-gray-100 rounded-br-sm shadow-md';

        let attHtml = '';
        if (msg.attachment) {
            const att = msg.attachment;
            if (att.is_image) {
                attHtml = `
                    <div class="mt-2 pt-2 border-t border-gray-700/50">
                        <div class="relative group cursor-pointer" onclick="openAdminLightbox('${escapeHtml(att.file_url)}', '${escapeHtml(att.file_name)}')">
                            <img src="${escapeHtml(att.file_url)}" alt="Attachment" class="max-h-48 max-w-full rounded-xl object-cover border border-gray-700 group-hover:border-gold transition">
                            <div class="absolute inset-0 bg-black/40 rounded-xl opacity-0 group-hover:opacity-100 transition flex items-center justify-center text-white text-xs font-bold gap-1.5">
                                <i class="fas fa-search-plus"></i> View Full Image
                            </div>
                        </div>
                        <div class="text-[10px] text-gray-400 mt-1 flex items-center justify-between">
                            <span class="truncate max-w-[180px]">${escapeHtml(att.file_name)}</span>
                            <span class="font-mono">${Math.round((att.file_size || 0)/1024)} KB</span>
                        </div>
                    </div>
                `;
            } else {
                attHtml = `
                    <div class="mt-2 pt-2 border-t border-gray-700/50">
                        <a href="${escapeHtml(att.file_url)}" download class="flex items-center gap-2.5 p-2 rounded-xl bg-black/30 border border-gray-700/80 hover:border-gold/40 text-gray-200 transition">
                            <span class="text-xl text-gold">📄</span>
                            <div class="flex-1 min-w-0">
                                <div class="font-bold text-xs truncate">${escapeHtml(att.file_name)}</div>
                                <div class="text-[10px] text-gray-400 font-mono">${Math.round((att.file_size || 0)/1024)} KB &bull; Click to download</div>
                            </div>
                            <i class="fas fa-download text-xs text-gold"></i>
                        </a>
                    </div>
                `;
            }
        }

        html += `
            <div class="flex flex-col ${isClient ? 'items-start' : 'items-end'} space-y-1">
                <div class="flex items-center gap-2 text-[10px] text-gray-400">
                    <strong class="${isClient ? 'text-gold' : 'text-blue-300'}">${escapeHtml(senderName)}</strong>
                    <span>•</span>
                    <span class="font-mono">${escapeHtml(timeStr)}</span>
                    ${orderBadge}
                </div>
                <div class="max-w-[85%] sm:max-w-[75%] p-3.5 rounded-2xl text-xs leading-relaxed ${bubbleCls}">
                    ${msg.text ? `<p>${nl2br(escapeHtml(msg.text))}</p>` : ''}
                    ${attHtml}
                </div>
            </div>
        `;
    });

    container.innerHTML = html;
}

function openAdminLightbox(url, filename) {
    const modal = document.getElementById('adminLightboxModal');
    const img = document.getElementById('adminLightboxImg');
    const nameEl = document.getElementById('adminLightboxFilename');
    const dlBtn = document.getElementById('adminLightboxDownloadBtn');

    if (modal && img) {
        img.src = url;
        if (nameEl) nameEl.textContent = filename;
        if (dlBtn) dlBtn.href = url;
        modal.classList.remove('hidden');
    }
}

function closeAdminLightbox() {
    const modal = document.getElementById('adminLightboxModal');
    if (modal) modal.classList.add('hidden');
}

function escapeHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function nl2br(str) {
    return str.replace(/\n/g, '<br>');
}

// Poll every 3 seconds for client messages
setInterval(pollAdminActiveChat, 3000);
</script>

</body>
</html>
