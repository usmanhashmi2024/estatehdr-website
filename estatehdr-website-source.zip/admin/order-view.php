<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireAdmin();

$orderId = trim($_GET['id'] ?? '');
$order   = getOrder($orderId);
$adminRoles = getAdminRoles();

if (!$order) {
    setFlash('error', 'Order not found.');
    if (in_array('team_lead', $adminRoles)) {
        header('Location: /admin/teamlead-dashboard.php');
    } elseif (in_array('supervisor', $adminRoles)) {
        header('Location: /admin/supervisor-dashboard.php');
    } else {
        header('Location: /admin/orders.php');
    }
    exit;
}

$client = getUserById($order['user_id'] ?? '');
if (!$client && !empty($order['client_name'])) {
    $client = [
        'id'      => $order['user_id'] ?? 'CL-1001',
        'name'    => $order['client_name'],
        'email'   => $order['client_email'] ?? '',
        'phone'   => $order['client_phone'] ?? '',
        'company' => $order['client_company'] ?? ''
    ];
}
$clientPrefs = function_exists('getUserPreferences') ? getUserPreferences($order['user_id'] ?? '') : [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    verifyCsrf();
    $action = $_POST['action'];

    if ($action === 'delete_order') {
        if (deleteOrder($orderId)) {
            setFlash('success', "Order #{$orderId} was permanently deleted.");
            header('Location: /admin/');
            exit;
        } else {
            setFlash('error', "Could not delete order #{$orderId}.");
        }
    } elseif ($action === 'edit_order') {
        $orderType = trim($_POST['order_type'] ?? ($order['order_type'] ?? 'live_order'));
        $isTrial = ($orderType === 'free_trial');
        $billedAmount = $isTrial ? 0.0 : (float)($_POST['billed_amount'] ?? 0.0);

        $updated = updateOrderAdmin($orderId, [
            'property_name'          => $_POST['property_name'] ?? '',
            'service_type'           => $_POST['service_type'] ?? '',
            'status'                 => $_POST['status'] ?? 'pending',
            'order_type'             => $orderType,
            'is_trial'               => $isTrial,
            'raw_images_count'       => (int)($_POST['raw_images_count'] ?? 0),
            'delivered_images_count' => (int)($_POST['delivered_images_count'] ?? 0),
            'billed_amount'          => $billedAmount,
            'cloud_link'             => trim($_POST['cloud_link'] ?? ''),
            'final_cloud_link'       => trim($_POST['final_cloud_link'] ?? ''),
            'instructions'           => trim($_POST['instructions'] ?? ''),
            'turnaround'             => trim($_POST['turnaround'] ?? '24h Standard')
        ]);
        if (function_exists('setOrderType')) {
            setOrderType($orderId, $orderType);
        }
        if ($updated) {
            setFlash('success', "Order details updated successfully.");
        } else {
            setFlash('error', "Failed to update order details.");
        }
    } elseif ($action === 'deliver_with_tracking') {
        $cloudLink       = trim($_POST['cloud_link'] ?? '');
        $deliveredCount  = (int)($_POST['delivered_images_count'] ?? 0);
        $isTrial = !empty($order['is_trial']) || (($order['order_type'] ?? '') === 'free_trial') || stripos($orderId, 'TRIAL-') === 0;

        if ($isTrial) {
            $billedAmount = 0.0;
        } else {
            $billedAmount    = (float)($_POST['billed_amount'] ?? 0.0);
            if ($billedAmount <= 0 && function_exists('calculateServicePrice')) {
                $billedAmount = calculateServicePrice($order['service_type'] ?? 'HDR Photo Editing', $deliveredCount);
            }
        }
        $deliveryMessage = trim($_POST['delivery_message'] ?? '');

        if (empty($cloudLink)) {
            setFlash('error', 'Please provide the high-res delivered files link.');
        } elseif ($deliveredCount < 1) {
            setFlash('error', 'Please input the final delivered images count.');
        } else {
            deliverOrderWithTracking($orderId, $cloudLink, $deliveredCount, $billedAmount, $deliveryMessage);
            
            // Sync to SaaS Orders JSON pipeline
            $saasFile = DATA_PATH . 'saas_orders.json';
            if (file_exists($saasFile)) {
                $saasOrders = json_decode(file_get_contents($saasFile), true) ?: [];
                $sChanged = false;
                foreach ($saasOrders as &$so) {
                    if (($so['id'] ?? '') === $orderId) {
                        $so['delivery_url']       = $cloudLink;
                        $so['status']             = 'sent_client';
                        $so['final_image_count']  = $deliveredCount;
                        $so['price_amount']       = $billedAmount;
                        $so['delivered_at']       = date('c');
                        $so['updated_at']         = date('c');
                        $sChanged = true;
                        break;
                    }
                }
                if ($sChanged) {
                    file_put_contents($saasFile, json_encode($saasOrders, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
                }
            }

            setFlash('success', "Order delivered! Final image count ({$deliveredCount}) and billing (\${$billedAmount}) logged to client's ledger.");
        }
    } elseif ($action === 'reply_message') {
        $reply = trim($_POST['reply_content'] ?? '');
        if (!empty($reply)) {
            appendMessage($orderId, 'admin', 'reply', $reply);
            setFlash('success', 'Message sent to client.');
        }
    } elseif ($action === 'update_status') {
        $newStatus = trim($_POST['new_status'] ?? '');
        if ($newStatus) {
            updateOrderStatus($orderId, $newStatus);
            setFlash('success', 'Order status updated to ' . statusLabel($newStatus));
        }
    } elseif ($action === 'resolve_amendment') {
        $cloudLink       = trim($_POST['cloud_link'] ?? '');
        $resolutionNotes = trim($_POST['resolution_notes'] ?? '');
        $deliveredCount  = (int)($_POST['delivered_images_count'] ?? 0);
        $sendEmail       = !empty($_POST['send_email']);

        if (empty($cloudLink)) {
            setFlash('error', 'Please provide the high-resolution cloud link for the revised files.');
        } else {
            $ok = deliverAmendmentResolution($orderId, $cloudLink, $resolutionNotes, $deliveredCount, $sendEmail);
            if ($ok) {
                setFlash('success', "Amendment resolved and order redelivered! Client has been notified" . ($sendEmail ? ' via email.' : '.'));
            } else {
                setFlash('error', 'Failed to resolve amendment. Please try again.');
            }
        }
    }

    header('Location: /admin/order-view.php?id=' . urlencode($orderId));
    exit;
}

$order = getOrder($orderId); // reload after POST

$hasAmendment = ($order['status'] ?? '') === 'amendment_requested' || !empty($order['annotations']);
$latestAmendNote = '';
if (!empty($order['messages']) && is_array($order['messages'])) {
    foreach (array_reverse($order['messages']) as $m) {
        if (($m['type'] ?? '') === 'amendment') {
            $latestAmendNote = $m['content'] ?? '';
            break;
        }
    }
}
if (empty($latestAmendNote) && !empty($order['instructions'])) {
    $latestAmendNote = $order['instructions'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Job <?= strtoupper($order['id']) ?> — Estate HDR Admin</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-[#0A0A0F] text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8">
  <!-- Back Navigation -->
  <?php
  $backUrl = in_array('team_lead', $adminRoles) ? '/admin/teamlead-dashboard.php' : (in_array('supervisor', $adminRoles) ? '/admin/supervisor-dashboard.php' : '/admin/orders.php');
  $backLabel = in_array('team_lead', $adminRoles) ? 'Back to Team Lead QA Hub' : (in_array('supervisor', $adminRoles) ? 'Back to Supervisor Ops' : 'Back to Orders');
  ?>
  <div class="mb-4">
    <a href="<?= $backUrl ?>" class="btn-ghost py-2 px-4 text-xs font-bold inline-flex items-center gap-2 border border-[#1E1E2E] hover:border-gold rounded-xl">
      <span>←</span> <span><?= $backLabel ?></span>
    </a>
  </div>
  <?= renderFlash() ?>

  <?php if ($hasAmendment): ?>
    <!-- ── URGENT AMENDMENT ALERT BANNER ──────────────────────── -->
    <div class="mb-6 rounded-2xl p-5 border border-amber-500/50 bg-gradient-to-r from-amber-950/60 via-[#18130B] to-[#111118] shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
      <div class="flex items-start gap-4">
        <div class="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-2xl shrink-0">
          ✏️
        </div>
        <div>
          <div class="flex items-center gap-2 flex-wrap">
            <span class="px-2.5 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-amber-500 text-black">Action Required</span>
            <h2 class="text-base sm:text-lg font-bold text-amber-200">Client Revision / Amendment Requested</h2>
          </div>
          <p class="text-xs text-gray-300 mt-1 max-w-2xl leading-relaxed">
            The client has requested modifications on this job. Click <strong class="text-white">View &amp; Submit Amend</strong> to review the client's notes, provide the corrected download link, and dispatch an automated resolution email.
          </p>
        </div>
      </div>
      <div class="shrink-0 flex items-center gap-2">
        <button type="button" onclick="openAmendmentResolutionModal()" class="px-5 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black shadow-lg shadow-amber-500/30 flex items-center gap-2 transition-all">
          <span>✏️</span> <span>View &amp; Submit Amend</span>
        </button>
      </div>
    </div>
  <?php endif; ?>

  <!-- Order Header & Audit Metrics -->
  <div class="glass-card rounded-2xl p-6 mb-6 border border-dark-border shadow-xl">
    <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
      <div>
        <div class="flex flex-wrap items-center gap-3 mb-3">
          <span class="text-sm font-mono font-black px-3.5 py-1.5 rounded-lg bg-gold text-dark shadow-glow flex items-center gap-1.5">
            <span>📦 ORDER ID:</span> <span><?= strtoupper($order['id']) ?></span>
          </span>
          <?php 
          $isOrderTrial = !empty($order['is_trial']) || (($order['order_type'] ?? '') === 'free_trial') || stripos($order['id'], 'TRIAL-') === 0;
          if ($isOrderTrial): ?>
            <span class="text-xs font-black px-3.5 py-1.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm flex items-center gap-1.5">
              <span>🎁 FREE TRIAL</span> <span>($0.00 COMPLIMENTARY)</span>
            </span>
          <?php else: ?>
            <span class="text-xs font-black px-3.5 py-1.5 rounded-lg bg-blue-500/20 text-blue-300 border border-blue-500/40 shadow-sm flex items-center gap-1.5">
              <span>⚡ LIVE ORDER</span> <span>(PAID / BILLABLE)</span>
            </span>
          <?php endif; ?>
          <span class="text-xs text-gray-300 font-mono bg-dark px-3 py-1.5 rounded-lg border border-dark-border">
            👤 CLIENT ID: <strong class="text-white"><?= strtoupper($client['id'] ?? 'CL-1001') ?></strong>
          </span>
          <span class="text-xs font-bold px-3 py-1.5 rounded-lg <?= ($order['created_by'] ?? 'client') === 'admin' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : 'bg-blue-500/20 text-blue-300 border border-blue-500/30' ?>">
            <?= ($order['created_by'] ?? 'client') === 'admin' ? '⚙️ Proxy Order' : '🌐 Client Portal' ?>
          </span>
        </div>
        <h1 class="text-2xl sm:text-3xl font-black text-white"><?= htmlspecialchars($order['property_name']) ?></h1>
        <div class="flex items-center gap-4 mt-2 text-xs text-gray-400 flex-wrap">
          <span class="text-white font-semibold bg-dark-card border border-dark-border px-2.5 py-1 rounded-lg">👤 <?= htmlspecialchars($client['name'] ?? 'Unknown Client') ?> (<?= htmlspecialchars($client['email'] ?? '') ?>)</span>
          <span class="text-gold font-medium"><?= htmlspecialchars($order['service_type']) ?></span>
          <span>Submitted: <?= date('M j, Y g:i A', strtotime($order['created_at'])) ?></span>
        </div>
      </div>

      <!-- Order Actions (Edit, Delete, Status) -->
      <div class="flex flex-wrap items-center gap-2">
        <?php if ($hasAmendment): ?>
          <button type="button" onclick="openAmendmentResolutionModal()" class="py-1.5 px-3 text-xs font-black bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black rounded-xl inline-flex items-center gap-1.5 shadow-md shadow-amber-500/20 animate-pulse">
            <span>✏️</span> <span>View &amp; Submit Amend</span>
          </button>
        <?php endif; ?>
        <button type="button" id="btnOpenEditOrder" class="btn-ghost py-1.5 px-3 text-xs font-bold text-blue-400 border border-blue-500/30 hover:bg-blue-500/10 rounded-xl inline-flex items-center gap-1">
          <span>✏️</span> <span>Edit Details</span>
        </button>
        <button type="button" id="btnOpenDeleteOrder" class="btn-ghost py-1.5 px-3 text-xs font-bold text-red-400 border border-red-500/30 hover:bg-red-500/10 rounded-xl inline-flex items-center gap-1">
          <span>🗑️</span> <span>Delete</span>
        </button>
        <form method="POST" id="updateStatusForm" class="inline-block">
          <?= csrfField() ?>
          <input type="hidden" name="action" value="update_status">
          <div class="flex items-center gap-1.5">
            <select name="new_status" id="viewStatusSelect" data-original="<?= $order['status'] ?>" class="form-select text-xs py-1.5 font-bold bg-[#141624] text-white border-dark-border cursor-pointer">
              <option value="pending" <?= $order['status'] === 'pending' ? 'selected' : '' ?>>⏳ Pending</option>
              <option value="in_progress" <?= $order['status'] === 'in_progress' ? 'selected' : '' ?>>🔄 In Progress</option>
              <option value="assigned_tl" <?= $order['status'] === 'assigned_tl' ? 'selected' : '' ?>>👤 Assigned TL</option>
              <option value="assigned_editor" <?= $order['status'] === 'assigned_editor' ? 'selected' : '' ?>>🎨 Assigned Editor</option>
              <option value="submitted_qa" <?= $order['status'] === 'submitted_qa' ? 'selected' : '' ?>>🔍 QA Review</option>
              <option value="revision_required" <?= $order['status'] === 'revision_required' ? 'selected' : '' ?>>⚠️ Revision Required</option>
              <option value="delivered" <?= in_array($order['status'], ['delivered', 'sent_client']) ? 'selected' : '' ?>>✅ Delivered</option>
              <option value="completed" <?= $order['status'] === 'completed' ? 'selected' : '' ?>>🏆 Completed</option>
              <option value="cancelled" <?= $order['status'] === 'cancelled' ? 'selected' : '' ?>>🚫 Cancelled</option>
            </select>
            <button type="button" id="btnApplyViewStatus" class="btn-gold py-1.5 px-3 text-xs font-black shadow-glow hidden whitespace-nowrap" title="Apply Status Change">
              ✓ Apply
            </button>
          </div>
        </form>
      </div>
    </div>

    <!-- Audited Counts Bar -->
    <div class="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-6 pt-5 border-t border-dark-border">
      <div class="bg-dark/70 rounded-xl p-3 border border-dark-border">
        <div class="text-[11px] text-gray-400 uppercase font-semibold">Raw Images Submitted</div>
        <div class="text-lg font-bold text-white mt-0.5 font-mono"><?= $order['raw_images_count'] ?> photos</div>
      </div>
      <div class="bg-dark/70 rounded-xl p-3 border border-dark-border">
        <div class="text-[11px] text-gold uppercase font-semibold">Final Delivered Images</div>
        <div class="text-lg font-bold text-gold mt-0.5 font-mono">
          <?= $order['delivered_images_count'] > 0 ? $order['delivered_images_count'] . ' photos' : 'Pending' ?>
        </div>
      </div>
      <div class="bg-dark/70 rounded-xl p-3 border border-dark-border">
        <div class="flex items-center justify-between">
          <div class="text-[11px] text-gray-400 uppercase font-semibold">Billed Cost</div>
          <?php if (!$isOrderTrial && (float)($order['billed_amount'] ?? 0) > 0): ?>
            <a href="/admin/ledger.php?client_id=<?= urlencode($order['client_id'] ?? $client['id'] ?? '') ?>&amount=<?= urlencode((string)$order['billed_amount']) ?>&notes=<?= urlencode('Payment for Order #' . strtoupper($order['id'])) ?>&method=PayPal" 
               class="text-[10px] text-emerald-400 hover:text-emerald-300 font-bold hover:underline inline-flex items-center gap-1">
              <span>💵 Record in Ledger ↗</span>
            </a>
          <?php endif; ?>
        </div>
        <div class="text-lg font-bold text-white mt-0.5 font-mono">
          <?php if ($isOrderTrial): ?>
            <span class="text-emerald-400">$0.00 (FREE TRIAL)</span>
          <?php else: ?>
            <?= $order['billed_amount'] > 0 ? '$' . number_format($order['billed_amount'], 2) : 'Unbilled' ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- CLIENT RAW PHOTOS DOWNLOAD LINK CARD -->
  <div class="glass-card rounded-2xl p-5 mb-6 border border-gold/40 shadow-xl bg-dark-card flex flex-col sm:flex-row sm:items-center justify-between gap-4">
    <div class="flex items-center gap-3.5">
      <div class="w-11 h-11 rounded-xl bg-gold/15 text-gold flex items-center justify-center text-xl flex-shrink-0 border border-gold/30">
        📁
      </div>
      <div>
        <div class="text-xs text-gray-400 font-semibold uppercase tracking-wider">Client Raw Photos (<?= $order['raw_images_count'] ?> images submitted)</div>
        <div class="text-white text-sm font-bold mt-0.5"><?= htmlspecialchars($order['property_name']) ?></div>
      </div>
    </div>

    <div class="flex items-center gap-3">
      <a href="<?= htmlspecialchars($order['cloud_link']) ?>" target="_blank" rel="noopener noreferrer"
         class="btn-gold py-2.5 px-6 text-xs font-bold shadow-glow inline-flex items-center gap-2">
        <svg class="w-4 h-4 text-dark" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
        <span>Download Photos ↗</span>
      </a>
    </div>
  </div>

  <!-- Client Style Preferences Card (Quick View) -->
  <div class="rounded-xl border border-gold/30 bg-gold/5 p-4 mb-6 text-xs flex items-start gap-3">
    <div class="text-lg">🎨</div>
    <div class="text-gray-300">
      <strong class="text-white block mb-0.5">Client's Signature Style Preset:</strong>
      Color: <span class="text-gold font-bold"><?= ucfirst(str_replace('_', ' ', $clientPrefs['color_style'])) ?></span> &bull; 
      Sky: <span class="text-gold font-bold"><?= ucfirst(str_replace('_', ' ', $clientPrefs['sky_replacement'])) ?></span> &bull; 
      Window: <span class="text-gold font-bold"><?= ucfirst(str_replace('_', ' ', $clientPrefs['window_treatment'])) ?></span>
      <?php if (!empty($clientPrefs['default_notes'])): ?>
        <div class="text-gray-400 mt-1 italic font-mono">&ldquo;<?= htmlspecialchars($clientPrefs['default_notes']) ?>&rdquo;</div>
      <?php endif; ?>
    </div>
  </div>

  <!-- AutoHDR AI Processing Studio Widget -->
  <div class="glass-card rounded-2xl p-6 mb-6 border border-emerald-500/40 shadow-2xl bg-dark-card/90">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-xl font-bold border border-emerald-500/30">
          🤖
        </div>
        <div>
          <h3 class="text-base font-bold text-white flex items-center gap-2">
            <span>AutoHDR AI Processing Studio</span>
            <span class="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">Local GPU Engine</span>
          </h3>
          <p class="text-gray-400 text-xs mt-0.5">Automated deep learning multi-bracket HDR fusion, window recovery, and real-estate color science.</p>
        </div>
      </div>
      <div id="aiEngineStatusBadge" class="text-xs px-3 py-1.5 rounded-xl bg-dark border border-dark-border text-gray-400 font-mono flex items-center gap-2">
        <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
        <span>AI Engine Ready</span>
      </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 pt-3 border-t border-dark-border">
      <!-- Style Profile Selector -->
      <div>
        <label class="text-xs font-bold text-gray-300 block mb-1.5">AutoHDR Style Profile</label>
        <select id="aiStyleProfile" class="form-select text-xs py-2 w-full font-bold bg-dark border-dark-border">
          <option value="lisa" selected>🌟 Lisa (Vivid Pop &amp; Deep Windows — AutoHDR)</option>
          <option value="classic">🍃 Classic (Natural &amp; Accurate Real-Estate)</option>
          <option value="aura">💎 Aura (Luxury Flambient Architectural)</option>
        </select>
        <p class="text-[11px] text-gray-500 mt-1">Select learned neural style for this listing.</p>
      </div>

      <!-- Secondary AI Enhancements -->
      <div>
        <label class="text-xs font-bold text-gray-300 block mb-1.5">AI Retouching Enhancements</label>
        <div class="space-y-1.5 text-xs text-gray-300">
          <label class="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" id="aiDeepWindow" checked class="rounded bg-dark border-dark-border text-gold focus:ring-0">
            <span>Deep Window Pull &amp; Sky Recovery</span>
          </label>
          <label class="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" id="aiLawnGreener" checked class="rounded bg-dark border-dark-border text-emerald-500 focus:ring-0">
            <span>AI Lawn Greener &amp; Turf Enhancer</span>
          </label>
          <label class="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" id="aiTwilight" class="rounded bg-dark border-dark-border text-blue-400 focus:ring-0">
            <span>Virtual Twilight (Day-to-Dusk)</span>
          </label>
        </div>
      </div>

      <!-- Trigger Action & Progress -->
      <div class="flex flex-col justify-end">
        <button type="button" id="btnStartAiProcess" onclick="dispatchAutoHDRJob('<?= $order['id'] ?>')"
                class="btn-gold py-2.5 px-4 text-xs font-bold shadow-glow flex items-center justify-center gap-2 w-full">
          <span>⚡ Start AutoHDR AI Processing</span>
        </button>
        <p class="text-[11px] text-gray-400 mt-1.5 text-center">Runs offline on your RTX 5060 Ti GPU</p>
      </div>
    </div>

    <!-- Live Progress Bar (Hidden by default) -->
    <div id="aiProgressContainer" class="hidden mt-4 pt-4 border-t border-dark-border">
      <div class="flex items-center justify-between text-xs mb-1.5">
        <span id="aiProgressLabel" class="text-gray-300 font-semibold">Processing shoot brackets...</span>
        <span id="aiProgressPercent" class="text-gold font-mono font-bold">0%</span>
      </div>
      <div class="w-full bg-dark rounded-full h-2.5 overflow-hidden border border-dark-border">
        <div id="aiProgressBar" class="bg-gradient-to-r from-gold to-emerald-400 h-2.5 rounded-full transition-all duration-300" style="width: 0%"></div>
      </div>
      <div id="aiOutputNotification" class="mt-2 text-xs text-emerald-400 hidden flex items-center gap-2">
        <span>✅ Output Ready! Deliverable package prepared in 6K resolution.</span>
      </div>
    </div>
  </div>

  <script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
  function dispatchAutoHDRJob(orderId) {
    const btn = document.getElementById('btnStartAiProcess');
    const progBox = document.getElementById('aiProgressContainer');
    const progBar = document.getElementById('aiProgressBar');
    const progLabel = document.getElementById('aiProgressLabel');
    const progPct = document.getElementById('aiProgressPercent');
    const style = document.getElementById('aiStyleProfile').value;
    const twilight = document.getElementById('aiTwilight').checked;
    const lawn = document.getElementById('aiLawnGreener').checked;

    btn.disabled = true;
    btn.innerHTML = '<span>⏳ Queuing AutoHDR...</span>';
    progBox.classList.remove('hidden');
    progBar.style.width = '10%';
    progPct.textContent = '10%';
    progLabel.textContent = 'Submitting order to local AutoHDR GPU Engine...';

    const formData = new FormData();
    formData.append('csrf_token', '<?= csrfToken() ?>');
    formData.append('action', 'start_processing');
    formData.append('order_id', orderId);
    formData.append('style', style);
    formData.append('enable_twilight', twilight ? '1' : '0');
    formData.append('enable_lawn', lawn ? '1' : '0');

    fetch('/api/ai-processor.php', {
      method: 'POST',
      body: formData
    })
    .then(r => r.json())
    .then(data => {
      if (data.success && data.job) {
        const jobId = data.job.job_id;
        pollAiJob(jobId);
      } else {
        if (window.EstateDialog) EstateDialog.toast(data.error || 'Could not connect to AutoHDR Engine.', 'error');
        else alert(data.error || 'Could not connect to AutoHDR Engine.');
        btn.disabled = false;
        btn.innerHTML = '<span>⚡ Start AutoHDR AI Processing</span>';
      }
    })
    .catch(err => {
      if (window.EstateDialog) EstateDialog.toast('Network error connecting to AI Engine: ' + err, 'error');
      else alert('Network error connecting to local AI Engine: ' + err);
      btn.disabled = false;
      btn.innerHTML = '<span>⚡ Start AutoHDR AI Processing</span>';
    });
  }

  function pollAiJob(jobId) {
    const progBar = document.getElementById('aiProgressBar');
    const progLabel = document.getElementById('aiProgressLabel');
    const progPct = document.getElementById('aiProgressPercent');
    const btn = document.getElementById('btnStartAiProcess');
    const notify = document.getElementById('aiOutputNotification');

    const timer = setInterval(() => {
      fetch('/api/ai-processor.php?action=check_status&job_id=' + jobId)
        .then(r => r.json())
        .then(res => {
          if (res.success && res.data) {
            const p = res.data.progress || 0;
            progBar.style.width = p + '%';
            progPct.textContent = p + '%';
            progLabel.textContent = 'AutoHDR Processing: ' + (res.data.status || 'running') + ' (' + p + '%)';

            if (res.data.status === 'done' || p >= 100) {
              clearInterval(timer);
              progBar.style.width = '100%';
              progPct.textContent = '100%';
              progLabel.textContent = '✅ AutoHDR 6K Rendering Complete!';
              notify.classList.remove('hidden');
              btn.innerHTML = '<span>✓ AI Completed</span>';
            } else if (res.data.status === 'error') {
              clearInterval(timer);
              progLabel.textContent = '❌ Error: ' + (res.data.error || 'Failed');
              btn.disabled = false;
              btn.innerHTML = '<span>⚡ Retry AutoHDR Processing</span>';
            }
          }
        });
    }, 2000);
  }
  </script>

  <!-- Delivery & Financial Tracking Form -->
  <div class="glass-card rounded-2xl p-6 mb-6 border border-gold/30 shadow-2xl">
    <h3 class="text-base font-bold text-white mb-1">Deliver Completed Job &amp; Log Ledger</h3>
    <p class="text-gray-400 text-xs mb-4">Paste the final high-res cloud link, enter the delivered image count, and set the billed amount.</p>

    <form method="POST" class="space-y-4">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="deliver_with_tracking">

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="form-label">Final Delivered Images Count <span class="text-red-400">*</span></label>
          <input type="number" name="delivered_images_count" min="1" max="1000" class="form-input text-sm font-mono"
                 placeholder="e.g. 25" value="<?= $order['delivered_images_count'] ?: $order['raw_images_count'] ?>" required>
          <p class="text-gray-500 text-[11px] mt-1">Exact count of finished edited photos.</p>
        </div>

        <div>
          <label class="form-label <?= $isOrderTrial ? 'text-amber-400 font-bold' : '' ?>">Billed Amount ($ USD)</label>
          <?php if ($isOrderTrial): ?>
            <input type="text" name="billed_amount" class="form-input text-sm font-mono font-bold text-emerald-400 bg-[#161622] cursor-not-allowed"
                   value="0.00" readonly>
            <p class="text-amber-300 text-[11px] mt-1 font-bold">🎁 Free Trial: Strictly $0.00 (No payment demanded, zero ledger debt).</p>
          <?php else: ?>
            <input type="number" step="0.01" name="billed_amount" class="form-input text-sm font-mono"
                   placeholder="e.g. 25.00" value="<?= $order['billed_amount'] ?: '' ?>">
            <p class="text-gray-500 text-[11px] mt-1">Will automatically log a financial ledger record.</p>
          <?php endif; ?>
        </div>
      </div>

      <div>
        <label class="form-label">Delivered Files Cloud Link (Google Drive / Dropbox) <span class="text-red-400">*</span></label>
        <input type="url" name="cloud_link" class="form-input text-sm" placeholder="https://drive.google.com/drive/folders/..." required>
      </div>

      <div>
        <label class="form-label">Delivery Note / Message to Client</label>
        <textarea name="delivery_message" rows="3" class="form-input resize-y text-sm" placeholder="e.g. All photos have been processed with window pulls and twilight exterior..."></textarea>
      </div>

      <button type="submit" class="btn-gold py-3 px-6 font-bold shadow-glow text-xs w-full">
        ✓ Deliver Files, Record Image Count &amp; Update Ledger
      </button>
    </form>
  </div>

  <!-- Messages & Audit Thread -->
  <div class="space-y-4 mb-6">
    <h2 class="text-xs font-bold text-gray-400 uppercase tracking-wider px-1">Job Audit &amp; Message History</h2>
    <?php foreach ($order['messages'] as $msg): ?>
    <?php $isAdmin = ($msg['sender'] === 'admin'); ?>
    <div class="flex <?= $isAdmin ? 'justify-start' : 'justify-end' ?>">
      <div class="message-bubble <?= $isAdmin ? 'admin' : 'client' ?> max-w-[85%]">
        <div class="flex flex-wrap items-center gap-2.5 mb-2.5 pb-2 border-b border-white/5">
          <span class="px-2 py-0.5 rounded text-[11px] font-mono font-black bg-gold/20 text-gold border border-gold/40">
            <?= strtoupper($order['id']) ?>
          </span>
          <span class="text-xs font-bold <?= $isAdmin ? 'text-gold' : 'text-blue-400' ?>">
            <?= $isAdmin ? '✦ Estate HDR Admin' : '👤 ' . htmlspecialchars($client['name'] ?? 'Client') ?>
          </span>
          <span class="message-type-badge type-<?= $msg['type'] ?> text-[10px] uppercase font-bold"><?= ucfirst($msg['type']) ?></span>
          <span class="text-gray-400 text-xs ml-auto font-mono"><?= date('M j, g:i A', strtotime($msg['timestamp'])) ?></span>
        </div>

        <?php if (!empty($msg['content'])): ?>
        <p class="text-gray-200 text-sm leading-relaxed whitespace-pre-wrap"><?= htmlspecialchars($msg['content']) ?></p>
        <?php endif; ?>

        <?php if (!empty($msg['cloud_link'])): ?>
        <div class="mt-3 pt-3 border-t border-white/5">
          <a href="<?= htmlspecialchars($msg['cloud_link']) ?>" target="_blank" rel="noopener noreferrer"
             class="btn-gold py-1.5 px-4 text-xs font-bold inline-flex items-center gap-1.5 shadow-glow">
            <svg class="w-3.5 h-3.5 text-dark" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
            <span>Open Storage Link ↗</span>
          </a>
        </div>
        <?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Admin Reply Form -->
  <div class="glass-card rounded-2xl p-6 border border-dark-border">
    <h3 class="text-base font-bold text-white mb-2">Post Reply to Client</h3>
    <form method="POST" class="space-y-4">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="reply_message">
      <textarea name="reply_content" rows="3" class="form-input resize-y text-sm" placeholder="Type a message or update to the client..." required></textarea>
      <button type="submit" class="btn-ghost py-2 px-6 text-xs font-bold text-gold hover:border-gold">Send Reply</button>
    </form>
  </div>

  <!-- ════════════════════════════════════════════════════════════════ -->
  <!-- ── MODAL 1: EDIT ORDER DETAILS ──────────────────────────────── -->
  <!-- ════════════════════════════════════════════════════════════════ -->
  <div id="editOrderModal" class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
    <div class="glass-card rounded-2xl p-6 max-w-xl w-full border border-dark-border shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
      <div class="flex items-center justify-between border-b border-dark-border pb-3">
        <div>
          <h3 class="text-base font-black text-white flex items-center gap-2">
            <span>✏️</span> <span>Edit Order Details</span>
          </h3>
          <p class="text-xs font-mono text-gold font-bold mt-0.5">ORDER #<?= strtoupper($order['id']) ?></p>
        </div>
        <button type="button" onclick="closeEditModal()" class="text-gray-400 hover:text-white text-xl font-bold">&times;</button>
      </div>

      <form method="POST" action="/admin/order-view.php?id=<?= urlencode($orderId) ?>" class="space-y-4">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="edit_order">

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label class="form-label text-xs">Property Title / Address</label>
            <input type="text" name="property_name" value="<?= htmlspecialchars($order['property_name']) ?>" required class="form-input text-xs">
          </div>
          <div>
            <label class="form-label text-xs">Service Type</label>
            <input type="text" name="service_type" value="<?= htmlspecialchars($order['service_type']) ?>" required class="form-input text-xs">
          </div>
          <div>
            <label class="form-label text-xs font-bold text-amber-300">Order Classification</label>
            <select name="order_type" class="form-select text-xs font-bold bg-[#161622] <?= $isOrderTrial ? 'text-amber-400' : 'text-blue-400' ?>" id="editModalOrderType">
              <option value="live_order" <?= !$isOrderTrial ? 'selected' : '' ?>>⚡ Live Order (Paid)</option>
              <option value="free_trial" <?= $isOrderTrial ? 'selected' : '' ?>>🎁 Free Trial ($0.00)</option>
            </select>
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label class="form-label text-xs">Status</label>
            <select name="status" class="form-select text-xs">
              <option value="pending" <?= $order['status'] === 'pending' ? 'selected' : '' ?>>Pending Intake</option>
              <option value="in_progress" <?= $order['status'] === 'in_progress' ? 'selected' : '' ?>>In Progress (Editing)</option>
              <option value="assigned_editor" <?= $order['status'] === 'assigned_editor' ? 'selected' : '' ?>>Assigned to Editor</option>
              <option value="submitted_qa" <?= $order['status'] === 'submitted_qa' ? 'selected' : '' ?>>Submitted to QA</option>
              <option value="approved" <?= $order['status'] === 'approved' ? 'selected' : '' ?>>QA Approved</option>
              <option value="delivered" <?= $order['status'] === 'delivered' ? 'selected' : '' ?>>Delivered to Client</option>
              <option value="completed" <?= $order['status'] === 'completed' ? 'selected' : '' ?>>Completed</option>
              <option value="amendment_requested" <?= $order['status'] === 'amendment_requested' ? 'selected' : '' ?>>Amendment Requested</option>
              <option value="cancelled" <?= $order['status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
            </select>
          </div>
          <div>
            <label class="form-label text-xs">Raw Photos Count</label>
            <input type="number" name="raw_images_count" value="<?= (int)($order['raw_images_count'] ?? 0) ?>" min="0" class="form-input text-xs">
          </div>
          <div>
            <label class="form-label text-xs">Delivered Photos Count</label>
            <input type="number" name="delivered_images_count" value="<?= (int)($order['delivered_images_count'] ?? 0) ?>" min="0" class="form-input text-xs">
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label class="form-label text-xs">Billed Amount ($ USD)</label>
            <input type="number" step="0.01" name="billed_amount" value="<?= number_format((float)($order['billed_amount'] ?? 0), 2, '.', '') ?>" min="0" class="form-input text-xs font-mono font-bold text-gold">
          </div>
          <div>
            <label class="form-label text-xs">Turnaround SLA</label>
            <select name="turnaround" class="form-select text-xs">
              <option value="24h Standard" <?= ($order['turnaround'] ?? '') === '24h Standard' ? 'selected' : '' ?>>24h Standard</option>
              <option value="12h Rush" <?= ($order['turnaround'] ?? '') === '12h Rush' ? 'selected' : '' ?>>12h Rush</option>
              <option value="6h Urgent" <?= ($order['turnaround'] ?? '') === '6h Urgent' ? 'selected' : '' ?>>6h Urgent</option>
            </select>
          </div>
        </div>

        <div>
          <label class="form-label text-xs">Raw Files Download URL (Client Link)</label>
          <input type="url" name="cloud_link" value="<?= htmlspecialchars($order['cloud_link'] ?? '') ?>" class="form-input text-xs font-mono" placeholder="https://dropbox.com/... or https://wetransfer.com/...">
        </div>

        <div>
          <label class="form-label text-xs">Final Delivered Cloud Link (High-Res Output)</label>
          <input type="url" name="final_cloud_link" value="<?= htmlspecialchars($order['final_cloud_link'] ?? '') ?>" class="form-input text-xs font-mono" placeholder="https://dropbox.com/... or https://wetransfer.com/...">
        </div>

        <div>
          <label class="form-label text-xs">Special Instructions / Notes</label>
          <textarea name="instructions" rows="2" class="form-input text-xs resize-none" placeholder="Client instructions or editor notes..."><?= htmlspecialchars($order['instructions'] ?? '') ?></textarea>
        </div>

        <div class="flex items-center justify-end gap-3 pt-3 border-t border-dark-border">
          <button type="button" onclick="closeEditModal()" class="btn-ghost py-2 px-4 text-xs font-bold">Cancel</button>
          <button type="submit" class="btn-gold py-2 px-6 text-xs font-black shadow-glow">Save Order Changes</button>
        </div>
      </form>
    </div>
  </div>

  <!-- ════════════════════════════════════════════════════════════════ -->
  <!-- ── MODAL 2: DELETE ORDER CONFIRMATION ────────────────────────── -->
  <!-- ════════════════════════════════════════════════════════════════ -->
  <div id="deleteOrderModal" class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
    <div class="glass-card rounded-2xl p-6 max-w-md w-full border border-red-500/40 shadow-2xl space-y-4">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-400 text-xl font-bold">
          ⚠️
        </div>
        <div>
          <h3 class="text-base font-black text-white">Delete Order?</h3>
          <p class="text-xs text-gray-400">This will permanently remove order #<?= strtoupper($order['id']) ?>.</p>
        </div>
      </div>

      <div class="p-3.5 rounded-xl bg-red-950/20 border border-red-800/40 text-xs text-red-300">
        Are you sure you want to permanently delete this order (<strong class="text-white"><?= htmlspecialchars($order['property_name']) ?></strong>)? This action cannot be undone.
      </div>

      <form method="POST" action="/admin/order-view.php?id=<?= urlencode($orderId) ?>" class="flex items-center justify-end gap-3 pt-2">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="delete_order">
        <button type="button" onclick="closeDeleteModal()" class="btn-ghost py-2 px-4 text-xs font-bold">Cancel</button>
        <button type="submit" class="py-2 px-5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs shadow-lg transition-all">
          Yes, Delete Order
        </button>
      </form>
    </div>
  </div>

  <!-- ════════════════════════════════════════════════════════════════ -->
  <!-- ── MODAL 3: VIEW & SUBMIT AMENDMENT RESOLUTION ───────────────── -->
  <!-- ════════════════════════════════════════════════════════════════ -->
  <div id="amendmentResolutionModal" class="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
    <div class="glass-card rounded-2xl p-6 sm:p-7 max-w-2xl w-full border border-amber-500/50 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
      <div class="flex items-center justify-between pb-4 border-b border-dark-border">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 text-xl font-bold">
            ✏️
          </div>
          <div>
            <h3 class="text-base sm:text-lg font-black text-white">View &amp; Submit Amendment</h3>
            <p class="text-xs text-amber-400/90 font-mono">Job #<?= strtoupper($order['id']) ?> — <?= htmlspecialchars($order['property_name']) ?></p>
          </div>
        </div>
        <button type="button" onclick="closeAmendmentResolutionModal()" class="text-gray-400 hover:text-white text-xl p-1 font-bold">&times;</button>
      </div>

      <!-- Client Details & Revision Notes -->
      <div class="p-4 rounded-xl bg-amber-950/20 border border-amber-800/40 space-y-2">
        <div class="flex items-center justify-between text-xs">
          <span class="text-gray-400">Client: <strong class="text-white"><?= htmlspecialchars($client['name'] ?? 'Client') ?></strong></span>
          <span class="text-gray-400">Email: <strong class="text-amber-300 font-mono"><?= htmlspecialchars($client['email'] ?? ($order['client_email'] ?? '')) ?></strong></span>
        </div>
        <div class="text-xs text-gray-300 pt-2 border-t border-amber-900/40">
          <span class="text-[11px] font-bold uppercase tracking-wider text-amber-400 block mb-1">Client Amendment Request / Notes:</span>
          <div class="bg-black/40 p-3 rounded-lg border border-dark-border text-xs text-white whitespace-pre-line font-mono max-h-36 overflow-y-auto">
            <?= htmlspecialchars($latestAmendNote ?: 'Please check annotations and instructions.') ?>
          </div>
        </div>
        <?php if (!empty($order['annotations'])): ?>
          <div class="pt-2 flex items-center justify-between">
            <span class="text-xs text-amber-300">📌 Visual Pin Annotations Present</span>
            <a href="/client/review.php?id=<?= urlencode($order['id']) ?>" target="_blank" class="text-xs font-bold text-gold hover:underline inline-flex items-center gap-1">
              <span>Inspect Visual Annotations ↗</span>
            </a>
          </div>
        <?php endif; ?>
      </div>

      <!-- Resolution Submission Form -->
      <form method="POST" action="/admin/order-view.php?id=<?= urlencode($orderId) ?>" class="space-y-4">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="resolve_amendment">

        <div>
          <label class="form-label text-xs font-bold text-gray-300">
            High-Resolution Cloud Download Link <span class="text-amber-400">*</span>
          </label>
          <input 
            type="url" 
            name="cloud_link" 
            required 
            value="<?= htmlspecialchars($order['final_cloud_link'] ?: ($order['cloud_link'] ?? '')) ?>" 
            placeholder="https://www.dropbox.com/scl/fo/... or Google Drive" 
            class="form-input text-xs font-mono"
          >
          <p class="text-[11px] text-gray-500 mt-1">This link is sent directly to the client in their "Revisions Completed" email button.</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label class="form-label text-xs font-bold text-gray-300">
              Delivered Images Count
            </label>
            <input 
              type="number" 
              name="delivered_images_count" 
              min="1" 
              value="<?= (int)($order['delivered_images_count'] ?: ($order['raw_images_count'] ?: 1)) ?>" 
              class="form-input text-xs font-mono"
            >
          </div>
          <div>
            <label class="form-label text-xs font-bold text-gray-300">
              Order Redelivery Status
            </label>
            <div class="form-input text-xs font-bold text-emerald-400 bg-emerald-500/10 border-emerald-500/30 flex items-center">
              ✅ Automatically transitions to Delivered
            </div>
          </div>
        </div>

        <div>
          <label class="form-label text-xs font-bold text-gray-300">
            Resolution Notes (Visible to Client in Email)
          </label>
          <textarea 
            name="resolution_notes" 
            rows="3" 
            class="form-input text-xs resize-none" 
            placeholder="Explain what was corrected (e.g., Sky replaced with vibrant blue dusk, lawn enhanced, brightness adjusted)..."
          >All requested revisions have been meticulously applied and verified to studio quality standard.</textarea>
        </div>

        <div class="p-3 rounded-xl bg-gold/10 border border-gold/30 flex items-start gap-3">
          <input 
            type="checkbox" 
            name="send_email" 
            id="orderViewSendEmail" 
            value="1" 
            checked 
            class="mt-1 w-4 h-4 rounded border-dark-border text-gold focus:ring-gold bg-[#141624]"
          >
          <label for="orderViewSendEmail" class="text-xs text-gray-300 cursor-pointer">
            <strong class="text-gold font-bold">Send Notification Email to Client (<?= htmlspecialchars($client['email'] ?? ($order['client_email'] ?? 'Client')) ?>)</strong>
            <span class="block text-[11px] text-gray-400 mt-0.5">Dispatches branded "Revisions Completed / Amendment Done" email with download button.</span>
          </label>
        </div>

        <div class="flex items-center justify-end gap-3 pt-3 border-t border-dark-border">
          <button type="button" onclick="closeAmendmentResolutionModal()" class="btn-ghost py-2 px-4 text-xs font-bold">
            Cancel
          </button>
          <button type="submit" class="py-2.5 px-6 rounded-xl font-black text-xs uppercase tracking-wider bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black shadow-lg shadow-amber-500/20 flex items-center gap-2 transition-all">
            <span>🚀</span> <span>Submit &amp; Notify Client</span>
          </button>
        </div>
      </form>
    </div>
  </div>

</main>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
function openAmendmentResolutionModal() {
  const m = document.getElementById('amendmentResolutionModal');
  if (m) m.classList.remove('hidden');
}
function closeAmendmentResolutionModal() {
  const m = document.getElementById('amendmentResolutionModal');
  if (m) m.classList.add('hidden');
}
function openEditModal() {
  const m = document.getElementById('editOrderModal');
  if (m) m.classList.remove('hidden');
}
function closeEditModal() {
  const m = document.getElementById('editOrderModal');
  if (m) m.classList.add('hidden');
}
function confirmDeleteOrder() {
  const m = document.getElementById('deleteOrderModal');
  if (m) m.classList.remove('hidden');
}
function closeDeleteModal() {
  const m = document.getElementById('deleteOrderModal');
  if (m) m.classList.add('hidden');
}

document.addEventListener('DOMContentLoaded', () => {
  const btnEdit = document.getElementById('btnOpenEditOrder');
  if (btnEdit) btnEdit.addEventListener('click', openEditModal);

  const btnDel = document.getElementById('btnOpenDeleteOrder');
  if (btnDel) btnDel.addEventListener('click', confirmDeleteOrder);

  const selStatus = document.getElementById('viewStatusSelect');
  const formStatus = document.getElementById('updateStatusForm');
  const btnApplyStatus = document.getElementById('btnApplyViewStatus');
  if (selStatus && formStatus) {
    const origStatus = selStatus.getAttribute('data-original') || selStatus.value;

    function applyOrderStatus() {
      const selectedName = selStatus.options[selStatus.selectedIndex].text;
      if (window.EstateDialog) {
        EstateDialog.confirm('Update order status to "' + selectedName + '"?', 'Apply Status Change', { danger: false, confirmText: '✓ Apply Changes' }).then(ok => {
          if (ok) {
            formStatus.submit();
          } else {
            selStatus.value = origStatus;
            if (btnApplyStatus) btnApplyStatus.classList.add('hidden');
          }
        });
      } else {
        formStatus.submit();
      }
    }

    selStatus.addEventListener('change', () => {
      if (selStatus.value !== origStatus) {
        if (btnApplyStatus) btnApplyStatus.classList.remove('hidden');
        applyOrderStatus();
      } else {
        if (btnApplyStatus) btnApplyStatus.classList.add('hidden');
      }
    });

    if (btnApplyStatus) {
      btnApplyStatus.addEventListener('click', (e) => {
        e.preventDefault();
        applyOrderStatus();
      });
    }
  }

  const isOrderTrial = <?= json_encode(!empty($order['is_trial']) || (($order['order_type'] ?? '') === 'free_trial')) ?>;
  const serviceType = <?= json_encode($order['service_type'] ?? 'HDR Photo Editing') ?>;
  function autoCalculateBilledAmount(count) {
    if (isOrderTrial) return; // Free Trials are strictly $0.00
    count = parseInt(count) || 0;
    if (count <= 0) return;
    
    const st = serviceType.toLowerCase();
    let unit = 0.80;
    if (st.includes('hdr') || st.includes('photo') || st.includes('flambient')) {
      if (count >= 100) unit = 0.68;
      else if (count >= 50) unit = 0.72;
      else if (count >= 20) unit = 0.76;
      else unit = 0.80;
    } else if (st.includes('staging')) {
      unit = 8.00;
    } else if (st.includes('dusk')) {
      unit = 4.00;
    } else if (st.includes('twilight')) {
      unit = 6.00;
    } else if (st.includes('removal')) {
      unit = 2.00;
    } else if (st.includes('floor') || st.includes('3d')) {
      unit = 15.00;
    }
    
    const total = (count * unit).toFixed(2);
    const billedInput = document.querySelector('input[name="billed_amount"]');
    if (billedInput) {
      billedInput.value = total;
    }
  }

  const delInput = document.querySelector('input[name="delivered_images_count"]');
  if (delInput) {
    delInput.addEventListener('input', (e) => {
      autoCalculateBilledAmount(e.target.value);
    });
  }
});
</script>

</body>
</html>
