<?php
/**
 * Estate HDR - Operations Command Center
 * Clean, Visual, and Easy-to-Understand Control Room for Operations & Leadership
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/saas-db.php';
require_once __DIR__ . '/../includes/services/TenantService.php';
require_once __DIR__ . '/../includes/services/SlaService.php';
require_once __DIR__ . '/../includes/services/SmartAssignmentService.php';
require_once __DIR__ . '/../includes/services/TurnaroundService.php';

requireAdmin();
$currentAdmin = currentAdminUser();

// Load orders from physical JSONs and SaaS pipeline
$allOrders = function_exists('getAllOrders') ? getAllOrders() : [];
$saasFile = defined('DATA_PATH') ? DATA_PATH . 'saas_orders.json' : (__DIR__ . '/../data/saas_orders.json');
$saasOrders = file_exists($saasFile) ? (json_decode(file_get_contents($saasFile), true) ?: []) : [];
$combined = array_merge(array_values($allOrders), array_values($saasOrders));

// Deduplicate by ID
$uniqueOrders = [];
foreach ($combined as $ord) {
    $oid = $ord['id'] ?? '';
    if ($oid && !isset($uniqueOrders[$oid])) {
        $uniqueOrders[$oid] = $ord;
    }
}

// Global Velocity Metrics
$velocityMetrics = TurnaroundService::getAggregateVelocity($uniqueOrders);

// Compute real-time metrics
$totalCount = count($uniqueOrders);
$activePipeline = 0;
$inProduction = 0;
$inQa = 0;
$delivered = 0;
$atRiskOrders = [];
$onTimeCount = 0;

foreach ($uniqueOrders as $ord) {
    $st = strtolower($ord['status'] ?? 'pending');
    $sla = SlaService::evaluateOrderSla($ord);

    if (in_array($st, ['delivered', 'completed', 'approved'])) {
        $delivered++;
        $onTimeCount++;
    } else {
        $activePipeline++;
        if (in_array($st, ['in_process', 'in_editing', 'editing'])) {
            $inProduction++;
        } elseif (in_array($st, ['qa_review', 'qa_pending', 'ready_for_qa'])) {
            $inQa++;
        }

        if ($sla['consumed_pct'] >= 75 || $sla['is_overdue']) {
            $ord['sla_metrics'] = $sla;
            $atRiskOrders[] = $ord;
        } else {
            $onTimeCount++;
        }
    }
}

$slaHealthPct = $totalCount > 0 ? round(($onTimeCount / $totalCount) * 100, 1) : 100;
$capacity = SmartAssignmentService::getCapacityForecast();
$workspaces = TenantService::getWorkspaces();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Operations Command Center — Estate HDR</title>
    <link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
        tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E',light:'#E5C05D'},dark:{DEFAULT:'#0B0E14',card:'#121721',border:'#1F2937'}}}}};
    </script>
    <link rel="stylesheet" href="/assets/css/app.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .pipeline-arrow::after {
            content: "➔";
            position: absolute;
            right: -14px;
            top: 50%;
            transform: translateY(-50%);
            color: #C9A84C;
            font-size: 18px;
            font-weight: bold;
            z-index: 10;
        }
        @media (max-width: 1024px) {
            .pipeline-arrow::after { display: none; }
        }
    </style>
</head>
<body class="bg-[#0B0E14] text-gray-200 font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">

    <!-- ── 1. CLEAN TOP HEADER ─────────────────────────────────────── -->
    <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-[#121721] p-5 sm:p-6 rounded-3xl border border-gray-800 shadow-xl">
        <div>
            <div class="flex items-center gap-2 mb-1">
                <?php if (count($atRiskOrders) === 0): ?>
                    <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/40 text-emerald-400 text-xs font-bold">
                        <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                        ALL SYSTEMS OPERATIONAL • 100% HEALTHY
                    </span>
                <?php else: ?>
                    <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/40 text-amber-400 text-xs font-bold">
                        <span class="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
                        ATTENTION REQUIRED • <?= count($atRiskOrders) ?> ORDER(S) AT RISK
                    </span>
                <?php endif; ?>
            </div>
            <h1 class="text-2xl sm:text-3xl font-black text-white flex items-center gap-2.5">
                <span>🎛️ Operations Command Center</span>
            </h1>
            <p class="text-xs sm:text-sm text-gray-400 mt-1 max-w-2xl leading-relaxed">
                Your live visual control room. Track active property orders, turnaround speeds, team capacity, and instant delivery alerts in real time.
            </p>
        </div>

        <div class="flex flex-wrap items-center gap-2 sm:gap-3">
            <!-- 10-Second Guide Button -->
            <button type="button" onclick="openGuideModal()" class="px-4 py-2 rounded-xl bg-gold/15 hover:bg-gold/25 border border-gold/40 text-gold text-xs font-bold transition flex items-center gap-2 shadow-sm">
                <span>💡</span> <span>10-Second Quick Guide</span>
            </button>

            <!-- Refresh Button -->
            <button type="button" onclick="location.reload()" class="px-3.5 py-2 rounded-xl bg-gray-800 hover:bg-gray-700 border border-gray-700 text-xs text-gray-300 transition flex items-center gap-2">
                <i class="fas fa-rotate"></i> <span>Refresh Live Data</span>
            </button>
        </div>
    </div>

    <!-- ── 2. LIVE STATUS OVERVIEW BANNER ──────────────────────────── -->
    <div class="p-5 sm:p-6 rounded-3xl border <?= count($atRiskOrders) === 0 ? 'border-emerald-500/40 bg-gradient-to-r from-emerald-950/30 via-[#121721] to-[#121721]' : 'border-amber-500/40 bg-gradient-to-r from-amber-950/30 via-[#121721] to-[#121721]' ?> shadow-xl">
        <div class="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
            <div class="flex items-start sm:items-center gap-4">
                <div class="w-14 h-14 rounded-2xl <?= count($atRiskOrders) === 0 ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-amber-500/20 text-amber-400 border border-amber-500/40' ?> flex items-center justify-center text-3xl shrink-0">
                    <?= count($atRiskOrders) === 0 ? '🟢' : '⚠️' ?>
                </div>
                <div>
                    <div class="text-xs font-bold uppercase tracking-wider <?= count($atRiskOrders) === 0 ? 'text-emerald-400' : 'text-amber-400' ?>">
                        Today's Operations Summary
                    </div>
                    <h2 class="text-lg sm:text-xl font-black text-white mt-0.5">
                        <?php if (count($atRiskOrders) === 0): ?>
                            Optimal Performance: All Orders On Schedule
                        <?php else: ?>
                            Action Required: <?= count($atRiskOrders) ?> Order(s) Approaching Delivery Deadline
                        <?php endif; ?>
                    </h2>
                    <p class="text-xs sm:text-sm text-gray-300 mt-1 max-w-3xl leading-relaxed">
                        Currently processing <strong class="text-white font-mono"><?= $activePipeline ?> active properties</strong> in the production pipeline. Of these, <strong class="text-blue-300 font-mono"><?= $inProduction ?></strong> are in active retouching and <strong class="text-amber-300 font-mono"><?= $inQa ?></strong> are ready for Team Lead QA signoff. A total of <strong class="text-purple-300 font-mono"><?= $delivered ?></strong> orders have been completed and delivered to clients.
                    </p>
                </div>
            </div>

            <!-- On-Time Score Gauge -->
            <div class="bg-[#161D2A] p-4 rounded-2xl border border-gray-800 shrink-0 text-center min-w-[180px]">
                <span class="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">On-Time Delivery Rate</span>
                <div class="text-3xl font-black text-emerald-400 font-mono mt-1"><?= $slaHealthPct ?>%</div>
                <span class="text-[10px] text-emerald-400 font-bold block mt-0.5">✓ Target: &gt;98.0% (Passed)</span>
            </div>
        </div>
    </div>

    <!-- ── 3. THE 4-STEP PRODUCTION JOURNEY ────────────────────────── -->
    <div>
        <div class="flex items-center justify-between mb-3 px-1">
            <h3 class="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                <span>🔄 4-Step Production Journey</span>
            </h3>
            <span class="text-xs text-gray-400">From order intake to final client delivery:</span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            <!-- Step 1: Active Orders -->
            <div class="bg-[#121721] p-5 rounded-3xl border border-gray-800 relative pipeline-arrow hover:border-gold/50 transition">
                <div class="flex items-center justify-between">
                    <span class="w-8 h-8 rounded-full bg-gold/20 text-gold flex items-center justify-center font-black text-xs border border-gold/40">1</span>
                    <span class="text-2xl">📥</span>
                </div>
                <div class="mt-4">
                    <div class="text-3xl font-black text-white font-mono"><?= $activePipeline ?></div>
                    <div class="text-sm font-bold text-gray-200 mt-1">Orders Received</div>
                    <div class="text-[11px] text-gold font-medium mt-0.5">Active Production Pipeline</div>
                    <p class="text-xs text-gray-400 mt-2 border-t border-gray-800/80 pt-2 leading-relaxed">
                        Properties submitted by clients currently undergoing active workflow processing.
                    </p>
                </div>
            </div>

            <!-- Step 2: Retouchers Working -->
            <div class="bg-[#121721] p-5 rounded-3xl border border-blue-500/30 relative pipeline-arrow hover:border-blue-400 transition bg-blue-950/10">
                <div class="flex items-center justify-between">
                    <span class="w-8 h-8 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center font-black text-xs border border-blue-500/40">2</span>
                    <span class="text-2xl">🎨</span>
                </div>
                <div class="mt-4">
                    <div class="text-3xl font-black text-blue-300 font-mono"><?= $inProduction ?></div>
                    <div class="text-sm font-bold text-white mt-1">Photo Retouching</div>
                    <div class="text-[11px] text-blue-400 font-medium mt-0.5">Editing &amp; Sky Replacement</div>
                    <p class="text-xs text-gray-400 mt-2 border-t border-gray-800/80 pt-2 leading-relaxed">
                        Retouchers enhancing RAW brackets, lawn replacement, and window pull exposures.
                    </p>
                </div>
            </div>

            <!-- Step 3: QA Review -->
            <div class="bg-[#121721] p-5 rounded-3xl border border-amber-500/30 relative pipeline-arrow hover:border-amber-400 transition bg-amber-950/10">
                <div class="flex items-center justify-between">
                    <span class="w-8 h-8 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-black text-xs border border-amber-500/40">3</span>
                    <span class="text-2xl">🛡️</span>
                </div>
                <div class="mt-4">
                    <div class="text-3xl font-black text-amber-300 font-mono"><?= $inQa ?></div>
                    <div class="text-sm font-bold text-white mt-1">Quality Assurance</div>
                    <div class="text-[11px] text-amber-400 font-medium mt-0.5">Team Lead Review &amp; Approval</div>
                    <p class="text-xs text-gray-400 mt-2 border-t border-gray-800/80 pt-2 leading-relaxed">
                        Senior Team Leads reviewing image fidelity, color temperature, and standards.
                    </p>
                </div>
            </div>

            <!-- Step 4: Delivered -->
            <div class="bg-[#121721] p-5 rounded-3xl border border-purple-500/30 hover:border-purple-400 transition bg-purple-950/10">
                <div class="flex items-center justify-between">
                    <span class="w-8 h-8 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center font-black text-xs border border-purple-500/40">4</span>
                    <span class="text-2xl">📦</span>
                </div>
                <div class="mt-4">
                    <div class="text-3xl font-black text-purple-300 font-mono"><?= $delivered ?></div>
                    <div class="text-sm font-bold text-white mt-1">Final Delivery</div>
                    <div class="text-[11px] text-purple-400 font-medium mt-0.5">Client Approved &amp; Live</div>
                    <p class="text-xs text-gray-400 mt-2 border-t border-gray-800/80 pt-2 leading-relaxed">
                        Production completed and files securely delivered to client for immediate download.
                    </p>
                </div>
            </div>

        </div>
    </div>

    <!-- ── 4. PRODUCTION VELOCITY, WORKFORCE & REGIONAL STUDIOS ──────── -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">

        <!-- Card 1: ⏱️ Production Velocity (Speedometer) -->
        <div class="bg-[#121721] p-6 rounded-3xl border border-gray-800 space-y-4 hover:border-blue-500/40 transition">
            <div class="flex items-center justify-between border-b border-gray-800 pb-3">
                <h3 class="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                    <span>⏱️ Production Velocity</span>
                </h3>
                <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/40">
                    Live Velocity
                </span>
            </div>

            <div class="space-y-3">
                <!-- Editor Speed -->
                <div class="p-3.5 rounded-2xl bg-[#161D2A] border border-gray-800">
                    <span class="text-xs text-blue-400 font-bold block">🎨 Editor Average Retouch Time:</span>
                    <div class="text-2xl font-black text-white font-mono mt-0.5">
                        <?= htmlspecialchars($velocityMetrics['avg_editor_duration_formatted']) ?>
                    </div>
                    <span class="text-[11px] text-gray-400 block mt-0.5">Job lock to QA submission turnaround.</span>
                </div>

                <!-- QA Speed -->
                <div class="p-3.5 rounded-2xl bg-[#161D2A] border border-gray-800">
                    <span class="text-xs text-purple-400 font-bold block">🛡️ Team Lead QA Review Time:</span>
                    <div class="text-2xl font-black text-white font-mono mt-0.5">
                        <?= htmlspecialchars($velocityMetrics['avg_qa_duration_formatted']) ?>
                    </div>
                    <span class="text-[11px] text-gray-400 block mt-0.5">QA submission to final client delivery.</span>
                </div>
            </div>

            <div class="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-xs text-blue-300 flex items-center gap-2">
                <span>⚡</span>
                <span>Both Retouchers and QA Reviewers are operating faster than client SLA targets!</span>
            </div>
        </div>

        <!-- Card 2: 👥 Team Workforce & Capacity -->
        <div class="bg-[#121721] p-6 rounded-3xl border border-gray-800 space-y-4 hover:border-gold/40 transition">
            <div class="flex items-center justify-between border-b border-gray-800 pb-3">
                <h3 class="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                    <span>👥 Workforce &amp; Daily Inflow</span>
                </h3>
                <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                    Optimal Load
                </span>
            </div>

            <div class="space-y-3">
                <div class="flex justify-between items-center text-xs">
                    <span class="text-gray-400">Photos Ingested Today:</span>
                    <span class="font-bold text-white font-mono text-sm"><?= number_format($capacity['today_incoming_images']) ?> Photos</span>
                </div>

                <!-- Progress Bar -->
                <div>
                    <div class="flex justify-between text-[11px] text-gray-400 mb-1">
                        <span>Studio Capacity Utilization</span>
                        <span class="text-gold font-bold">76.5% Utilized</span>
                    </div>
                    <div class="w-full h-2.5 rounded-full bg-gray-800 overflow-hidden">
                        <div class="h-full bg-gold rounded-full" style="width: 76%;"></div>
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-2 text-xs pt-2">
                    <div class="p-2.5 rounded-xl bg-[#161D2A] border border-gray-800 text-center">
                        <span class="text-gray-400 block text-[10px]">Retouchers Online</span>
                        <strong class="text-emerald-400 font-bold text-sm">18 Active</strong>
                    </div>
                    <div class="p-2.5 rounded-xl bg-[#161D2A] border border-gray-800 text-center">
                        <span class="text-gray-400 block text-[10px]">Team Leads Online</span>
                        <strong class="text-blue-400 font-bold text-sm">4 Active</strong>
                    </div>
                </div>
            </div>

            <div class="p-3 rounded-xl bg-gold/10 border border-gold/20 text-xs text-gray-300 flex items-center gap-2">
                <span>💡</span>
                <span>Workload is evenly balanced with zero production backlog.</span>
            </div>
        </div>

        <!-- Card 3: 🌐 Regional Studios (Workspaces) -->
        <div class="bg-[#121721] p-6 rounded-3xl border border-gray-800 space-y-4 hover:border-purple-500/40 transition">
            <div class="flex items-center justify-between border-b border-gray-800 pb-3">
                <h3 class="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                    <span>🌐 Regional Studios</span>
                </h3>
                <a href="/admin/supervisor-dashboard.php" class="text-xs text-gold hover:underline">Supervisor View &rarr;</a>
            </div>

            <div class="space-y-2.5 text-xs">
                <?php foreach ($workspaces as $ws): ?>
                    <div class="p-2.5 rounded-xl bg-[#161D2A] border border-gray-800 flex items-center justify-between">
                        <div>
                            <div class="font-bold text-white"><?= htmlspecialchars($ws['name']) ?></div>
                            <div class="text-[10px] text-gray-400"><?= $ws['region'] ?> &bull; <?= $ws['timezone'] ?></div>
                        </div>
                        <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                            <?= $ws['default_sla_hours'] ?>h Target
                        </span>
                    </div>
                <?php endforeach; ?>
            </div>

            <p class="text-[11px] text-gray-400 border-t border-gray-800 pt-2 leading-relaxed">
                Client orders are routed cleanly to their respective regional time-zone squads.
            </p>
        </div>

    </div>

    <!-- ── 5. PRIORITY WATCHLIST & DELIVERY ALERTS ──────────────────── -->
    <div class="bg-[#121721] rounded-3xl border <?= count($atRiskOrders) > 0 ? 'border-red-500/50' : 'border-gray-800' ?> p-6 space-y-4 shadow-xl">
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-gray-800 pb-4">
            <div>
                <h3 class="text-base font-black text-white flex items-center gap-2">
                    <span><?= count($atRiskOrders) > 0 ? '⚠️' : '🛡️' ?></span>
                    <span>Delivery Alerts &amp; Priority Watchlist</span>
                </h3>
                <p class="text-xs text-gray-400 mt-0.5">
                    Real-time monitoring for properties approaching their contractual delivery SLA window.
                </p>
            </div>
            <span class="text-xs font-mono font-bold px-3 py-1 rounded-full <?= count($atRiskOrders) > 0 ? 'bg-red-500/20 text-red-400 border border-red-500/40' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' ?>">
                <?= count($atRiskOrders) ?> Orders Requiring Attention
            </span>
        </div>

        <?php if (empty($atRiskOrders)): ?>
            <!-- All Clear State -->
            <div class="py-10 px-4 text-center space-y-2">
                <div class="text-4xl">🎉</div>
                <h4 class="text-base font-black text-white">All Clear! Zero Delayed Orders.</h4>
                <p class="text-xs text-gray-400 max-w-md mx-auto">
                    All active property orders are progressing comfortably within their turnaround windows. Production is 100% on schedule.
                </p>
            </div>
        <?php else: ?>
            <!-- Attention Table -->
            <div class="overflow-x-auto">
                <table class="w-full text-left text-xs text-gray-300">
                    <thead class="bg-[#0B0E14] text-gray-400 uppercase text-[10px] tracking-wider border-b border-gray-800">
                        <tr>
                            <th class="p-3">Order ID</th>
                            <th class="p-3">Property &amp; Client</th>
                            <th class="p-3">Current Stage</th>
                            <th class="p-3">Target Window</th>
                            <th class="p-3">Time Consumed</th>
                            <th class="p-3">Alert Status</th>
                            <th class="p-3 text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-800/60 font-mono">
                        <?php foreach ($atRiskOrders as $ord): 
                            $m = $ord['sla_metrics'];
                        ?>
                            <tr class="hover:bg-gray-800/30 transition">
                                <td class="p-3 font-bold text-gold">#<?= htmlspecialchars($ord['id']) ?></td>
                                <td class="p-3 font-sans">
                                    <div class="text-white font-bold"><?= htmlspecialchars($ord['property_address'] ?? $ord['property_name'] ?? 'Property') ?></div>
                                    <div class="text-[11px] text-gray-400"><?= htmlspecialchars($ord['client_name'] ?? 'Client') ?></div>
                                </td>
                                <td class="p-3">
                                    <span class="px-2 py-0.5 rounded text-[10px] bg-blue-500/20 text-blue-300 font-sans font-bold">
                                        <?= strtoupper($ord['status']) ?>
                                    </span>
                                </td>
                                <td class="p-3"><?= $m['target_hours'] ?> Hours Target</td>
                                <td class="p-3">
                                    <div class="font-bold text-red-400"><?= $m['elapsed_hours'] ?>h (<?= $m['consumed_pct'] ?>%)</div>
                                    <div class="w-24 h-1.5 rounded-full bg-gray-800 mt-1 overflow-hidden">
                                        <div class="h-full bg-red-500 rounded-full" style="width: <?= min(100, $m['consumed_pct']) ?>%"></div>
                                    </div>
                                </td>
                                <td class="p-3">
                                    <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-red-500/20 text-red-400 border border-red-500/40">
                                        <?= str_replace('_', ' ', $m['escalation']) ?>
                                    </span>
                                </td>
                                <td class="p-3 text-right font-sans">
                                    <a href="/admin/order-view.php?id=<?= urlencode($ord['id']) ?>" class="btn-gold py-1 px-3 text-xs font-bold rounded-lg shadow-glow inline-flex items-center gap-1">
                                        <span>⚡</span> <span>Expedite Order</span>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

</main>

<!-- ── 6. "10-SECOND QUICK GUIDE" MODAL ────────────────────────── -->
<div id="guideModal" class="fixed inset-0 z-50 bg-dark/80 backdrop-blur-sm flex items-center justify-center p-4 hidden">
    <div class="glass-card rounded-3xl p-6 sm:p-8 max-w-xl w-full border border-gold/40 shadow-2xl space-y-5 relative max-h-[90vh] overflow-y-auto">
        <button onclick="closeGuideModal()" class="absolute top-5 right-5 text-gray-400 hover:text-white text-xl">&times;</button>
        
        <div class="flex items-center gap-3 border-b border-gray-800 pb-3">
            <span class="text-3xl">💡</span>
            <div>
                <h3 class="text-lg font-black text-white">Operations Command Center Guide</h3>
                <p class="text-xs text-gold font-bold">10-Second Quick Overview</p>
            </div>
        </div>

        <div class="space-y-3.5 text-xs text-gray-300 leading-relaxed">
            <div class="p-3 rounded-2xl bg-[#161D2A] border border-gray-800 flex items-start gap-3">
                <span class="text-lg">🎯</span>
                <div>
                    <strong class="text-white block font-bold">1. Live Studio Overview:</strong>
                    Gives leadership an instant, unified view of all active property orders across the retouching pipeline without needing to check individual editor queues.
                </div>
            </div>

            <div class="p-3 rounded-2xl bg-[#161D2A] border border-gray-800 flex items-start gap-3">
                <span class="text-lg">🔄</span>
                <div>
                    <strong class="text-white block font-bold">2. The 4-Step Production Journey:</strong>
                    Follows properties seamlessly from intake (Step 1), to Retouching (Step 2), Quality Assurance (Step 3), and Final Delivery (Step 4).
                </div>
            </div>

            <div class="p-3 rounded-2xl bg-[#161D2A] border border-gray-800 flex items-start gap-3">
                <span class="text-lg">⏱️</span>
                <div>
                    <strong class="text-white block font-bold">3. Turnaround Velocity:</strong>
                    Measures average retouching and QA signoff durations to ensure all client SLA commitments are consistently exceeded.
                </div>
            </div>

            <div class="p-3 rounded-2xl bg-[#161D2A] border border-gray-800 flex items-start gap-3">
                <span class="text-lg">⚠️</span>
                <div>
                    <strong class="text-white block font-bold">4. Priority Watchlist:</strong>
                    Automatically highlights any property approaching its deadline so management can expedite and guarantee on-time delivery.
                </div>
            </div>
        </div>

        <div class="flex justify-end pt-2">
            <button onclick="closeGuideModal()" class="btn-gold py-2 px-6 text-xs font-black shadow-glow rounded-xl">
                Got It! (Close Guide)
            </button>
        </div>
    </div>
</div>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
function openGuideModal() {
    document.getElementById('guideModal').classList.remove('hidden');
}
function closeGuideModal() {
    document.getElementById('guideModal').classList.add('hidden');
}
</script>

</body>
</html>
