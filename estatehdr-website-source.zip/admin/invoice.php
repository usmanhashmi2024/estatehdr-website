<?php
/**
 * Estate HDR — Official Corporate Invoice Studio
 * Generates pixel-perfect printable and downloadable invoices matching the official Estate HDR corporate letterhead.
 */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/mail.php';

requireManagerOrAdmin();

$invoicesFile = DATA_PATH . 'invoices.json';
$invoices = file_exists($invoicesFile) ? (json_decode(file_get_contents($invoicesFile), true) ?: []) : [];

$allClients = getUsers();

// ── Handle Save / Email Invoice POST ─────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['save_invoice']) || isset($_POST['send_invoice_email']))) {
    verifyCsrf();
    $invId = trim($_POST['invoice_number'] ?? ('INV-' . str_pad(count($invoices) + 1, 4, '0', STR_PAD_LEFT)));
    
    // Parse line items
    $items = [];
    $descArr = $_POST['item_desc'] ?? [];
    $qtyArr  = $_POST['item_qty'] ?? [];
    $rateArr = $_POST['item_rate'] ?? [];

    $calculatedSubtotal = 0;
    foreach ($descArr as $idx => $desc) {
        $desc = trim($desc);
        if ($desc === '') continue;
        $qty = floatval($qtyArr[$idx] ?? 1);
        $rate = floatval($rateArr[$idx] ?? 0);
        $lineTotal = round($qty * $rate, 2);
        $calculatedSubtotal += $lineTotal;

        $items[] = [
            'description' => $desc,
            'qty'         => $qty,
            'rate'        => $rate,
            'total'       => $lineTotal
        ];
    }

    if (empty($items)) {
        $items[] = [
            'description' => 'HDR Photo Editing (Professional Blending)',
            'qty'         => 73,
            'rate'        => 0.45,
            'total'       => 32.85
        ];
        $calculatedSubtotal = 32.85;
    }

    $currency     = trim($_POST['currency'] ?? '$');
    $discount     = floatval($_POST['discount'] ?? 0);
    $tax          = floatval($_POST['tax'] ?? 0.0);
    $totalDue     = max(0, round($calculatedSubtotal + $tax - $discount, 2));
    $payoneerLink = trim($_POST['payoneer_link'] ?? '');
    $refNumber    = trim($_POST['ref_number'] ?? ('REF: EH-INV-' . date('Ym') . '-' . strtoupper(substr(md5($invId), 0, 6))));

    $invoiceData = [
        'id'               => $invId,
        'invoice_number'   => $invId,
        'ref_number'       => $refNumber,
        'date'             => trim($_POST['invoice_date'] ?? date('F j, Y')),
        'due_date'         => trim($_POST['due_date'] ?? 'Upon Receipt'),
        'payment_method'   => trim($_POST['payment_method'] ?? 'payoneer'),
        'payoneer_link'    => $payoneerLink,
        'payment_email'    => trim($_POST['payment_email'] ?? 'ashrafnadeem283@gmail.com'),
        'company_name'     => 'Estate HDR',
        'company_address'  => 'Alnoor Town, Lahore, Punjab, 58510',
        'company_phone'    => '+44 (7706) 068-176',
        'company_email'    => 'info@estatehdr.com',
        'company_website'  => 'www.estatehdr.com',
        'client_name'      => trim($_POST['client_name'] ?? ''),
        'client_phone'     => trim($_POST['client_phone'] ?? ''),
        'client_email'     => trim($_POST['client_email'] ?? ''),
        'client_address'   => trim($_POST['client_address'] ?? ''),
        'project_name'     => trim($_POST['project_name'] ?? 'HDR Photo Editing Services'),
        'base_rate'        => floatval($_POST['base_rate'] ?? 0.45),
        'items'            => $items,
        'subtotal'         => $calculatedSubtotal,
        'tax'              => $tax,
        'discount'         => $discount,
        'total'            => $totalDue,
        'currency'         => $currency,
        'status'           => trim($_POST['status'] ?? 'pending'),
        'remarks'          => trim($_POST['remarks'] ?? 'Please process your payment via Payoneer. Send payment to our official account or use the direct link above.'),
        'created_at'       => date('c')
    ];

    // Upsert into invoices list
    $found = false;
    foreach ($invoices as &$inv) {
        if (($inv['id'] ?? '') === $invId || ($inv['invoice_number'] ?? '') === $invId) {
            $inv = array_merge($inv, $invoiceData);
            $found = true;
            break;
        }
    }
    unset($inv);

    if (!$found) {
        array_unshift($invoices, $invoiceData);
    }

    if (function_exists('atomicWriteJson')) {
        atomicWriteJson($invoicesFile, $invoices);
    } else {
        file_put_contents($invoicesFile, json_encode($invoices, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    }

    // Email dispatch to client if requested
    if (isset($_POST['send_invoice_email'])) {
        if (function_exists('sendClientInvoiceEmail')) {
            $sent = sendClientInvoiceEmail($invoiceData);
            if ($sent) {
                setFlash('success', "Invoice {$invId} saved and emailed to " . htmlspecialchars($invoiceData['client_email']) . " successfully!");
            } else {
                setFlash('error', "Invoice {$invId} saved, but email sending to " . htmlspecialchars($invoiceData['client_email']) . " failed. Please check mail logs.");
            }
        } else {
            setFlash('success', "Invoice {$invId} saved.");
        }
    } else {
        setFlash('success', "Invoice {$invId} saved successfully!");
    }

    header('Location: /admin/invoice.php?view=' . urlencode($invId));
    exit;
}

// ── Handle Delete Invoice ───────────────────────────────────────────────────
if (isset($_GET['delete'])) {
    verifyCsrf();
    $delId = trim($_GET['delete']);
    $invoices = array_values(array_filter($invoices, fn($i) => ($i['id'] ?? '') !== $delId && ($i['invoice_number'] ?? '') !== $delId));
    if (function_exists('atomicWriteJson')) {
        atomicWriteJson($invoicesFile, $invoices);
    }
    setFlash('success', "Invoice {$delId} deleted.");
    header('Location: /admin/invoice.php');
    exit;
}

// ── Select Invoice to View/Edit ─────────────────────────────────────────────
$viewId = trim($_GET['view'] ?? '');
$targetClientId = trim($_GET['client_id'] ?? '');
$currentInvoice = null;

// Case 1: Pre-fill from Client CRM (?client_id=CL-XXXX)
if (!empty($targetClientId)) {
    $matchedUser = null;
    foreach ($allClients as $u) {
        if (($u['id'] ?? '') === $targetClientId) {
            $matchedUser = $u;
            break;
        }
    }

    if ($matchedUser) {
        $bal = (float)($matchedUser['balance'] ?? 0.0);
        if ($bal <= 0 && function_exists('getClientLedgerBalance')) {
            $lBal = getClientLedgerBalance($matchedUser['id']);
            $bal = (float)($lBal['outstanding_balance'] ?? 0.0);
        }
        $amountToBill = $bal > 0 ? $bal : 32.85;
        $invNum = 'INV-' . str_pad(count($invoices) + 1, 4, '0', STR_PAD_LEFT);
        $refNum = 'REF: EH-INV-' . date('Ym') . '-' . strtoupper(substr(md5($invNum), 0, 6));

        $currentInvoice = [
            'id'               => $invNum,
            'invoice_number'   => $invNum,
            'ref_number'       => $refNum,
            'date'             => date('F j, Y'),
            'due_date'         => 'Upon Receipt',
            'payment_method'   => 'payoneer',
            'payoneer_link'    => '',
            'payment_email'    => 'ashrafnadeem283@gmail.com',
            'company_name'     => 'Estate HDR',
            'company_address'  => 'Alnoor Town, Lahore, Punjab, 58510',
            'company_phone'    => '+44 (7706) 068-176',
            'company_email'    => 'info@estatehdr.com',
            'company_website'  => 'www.estatehdr.com',
            'client_name'      => $matchedUser['name'] ?? '',
            'client_phone'     => $matchedUser['phone'] ?? '',
            'client_email'     => $matchedUser['email'] ?? '',
            'client_address'   => trim(($matchedUser['company'] ?? '') . (!empty($matchedUser['country']) ? (', ' . $matchedUser['country']) : '')),
            'project_name'     => 'HDR Photo Editing Services',
            'base_rate'        => $amountToBill,
            'items'            => [
                [
                    'description' => 'HDR Photo Editing (Professional Blending)',
                    'qty'         => 1,
                    'rate'        => $amountToBill,
                    'total'       => $amountToBill
                ]
            ],
            'subtotal'         => $amountToBill,
            'tax'              => 0.00,
            'discount'         => 0.00,
            'total'            => $amountToBill,
            'currency'         => '$',
            'status'           => 'pending',
            'remarks'          => 'Please process your payment via Payoneer. Thank you for your business!'
        ];
    }
}

// Case 2: View specific existing invoice
if (!$currentInvoice && !empty($viewId)) {
    foreach ($invoices as $inv) {
        if (($inv['id'] ?? '') === $viewId || ($inv['invoice_number'] ?? '') === $viewId) {
            $currentInvoice = $inv;
            break;
        }
    }
}

// Case 3: Default latest invoice
if (!$currentInvoice && !empty($invoices)) {
    $currentInvoice = $invoices[0];
}

// Case 4: Brand new default template
if (!$currentInvoice) {
    $invNum = 'INV-' . str_pad(count($invoices) + 1, 4, '0', STR_PAD_LEFT);
    $currentInvoice = [
        'id'               => $invNum,
        'invoice_number'   => $invNum,
        'ref_number'       => 'REF: EH-INV-' . date('Ym') . '-C9D2E9',
        'date'             => date('F j, Y'),
        'due_date'         => 'Upon Receipt',
        'payment_method'   => 'payoneer',
        'payoneer_link'    => '',
        'payment_email'    => 'ashrafnadeem283@gmail.com',
        'company_name'     => 'Estate HDR',
        'company_address'  => 'Alnoor Town, Lahore, Punjab, 58510',
        'company_phone'    => '+44 (7706) 068-176',
        'company_email'    => 'info@estatehdr.com',
        'company_website'  => 'www.estatehdr.com',
        'client_name'      => 'Brandon',
        'client_phone'     => '+1 (951) 440-6995',
        'client_email'     => 'brandon@performanceregroup.com',
        'client_address'   => 'Performance Regroup',
        'project_name'     => 'HDR Photo Editing',
        'base_rate'        => 0.45,
        'items'            => [
            ['description' => 'HDR Photo Editing (Professional Blending)', 'qty' => 73, 'rate' => 0.45, 'total' => 32.85]
        ],
        'subtotal'         => 32.85,
        'tax'              => 0.00,
        'discount'         => 0.00,
        'total'            => 32.85,
        'currency'         => '$',
        'status'           => 'pending',
        'remarks'          => 'Please process your payment via Payoneer. Send payment to: ashrafnadeem283@gmail.com or use the online pay link.'
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Official Corporate Invoice Studio — Estate HDR</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
tailwind.config = {
  theme: {
    extend: {
      colors: {
        gold: { DEFAULT: '#C9A84C', light: '#E0C26D', dark: '#9A7A2E' },
        dark: { DEFAULT: '#0A0A0F', card: '#111118', border: '#1E1E2E' }
      }
    }
  }
}
</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">

<style nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
/* Document Sheet & Watermark matching official HR Payslip / Letterhead */
.doc-sheet {
  background: #ffffff;
  color: #111827;
  position: relative;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
  min-height: 1050px;
}

.doc-watermark {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%) rotate(-25deg);
  opacity: 0.07;
  pointer-events: none;
  z-index: 1;
  width: 550px;
  text-align: center;
  user-select: none;
}

.doc-content {
  position: relative;
  z-index: 10;
}

/* Print Styles for Pixel-Perfect A4 Page matching official corporate PDF */
@media print {
  header, nav, footer, .no-print, .no-print * {
    display: none !important;
    visibility: hidden !important;
    height: 0 !important;
    max-height: 0 !important;
    margin: 0 !important;
    padding: 0 !important;
    border: none !important;
  }
  
  html, body {
    background: #ffffff !important;
    color: #111827 !important;
    margin: 0 !important;
    padding: 0 !important;
    width: 100% !important;
    font-size: 11pt !important;
  }
  
  .doc-sheet {
    box-shadow: none !important;
    border: none !important;
    margin: 0 auto !important;
    padding: 8mm 12mm !important;
    width: 100% !important;
    max-width: 100% !important;
    min-height: auto !important;
    page-break-inside: avoid !important;
  }

  .doc-watermark {
    opacity: 0.10 !important;
    display: flex !important;
  }

  @page {
    margin: 8mm 10mm 8mm 10mm;
    size: A4 portrait;
  }
}
</style>
</head>
<body class="bg-[#0A0A0F] text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-6">

  <!-- ── 1. STUDIO HEADER & ACTION TOOLBAR ────────────────────────────── -->
  <div class="no-print mb-6 flex flex-wrap items-center justify-between gap-4 bg-[#111118] p-5 rounded-3xl border border-[#1E1E2E] shadow-2xl">
    <div>
      <div class="flex items-center gap-2 text-xs text-gold font-bold uppercase tracking-wider mb-1">
        <span>📄</span> <span>Official Corporate Invoice Studio</span>
      </div>
      <h1 class="text-xl sm:text-2xl font-black text-white flex items-center gap-3">
        <span>Invoice Generator</span>
        <span class="text-xs px-3 py-1 rounded-full font-mono bg-amber-500/20 text-amber-400 border border-amber-500/40" id="headerInvNumberBadge"><?= htmlspecialchars($currentInvoice['invoice_number'] ?? 'INV-0001') ?></span>
      </h1>
      <p class="text-gray-400 text-xs mt-0.5">Corporate Estate HDR letterhead header, verified seal stamp, and direct Payoneer payment link.</p>
    </div>

    <div class="flex flex-wrap items-center gap-2.5">
      <button type="button" onclick="sendInvoiceEmailDirectly()" class="py-2.5 px-5 text-xs font-black bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl shadow-lg transition-all inline-flex items-center gap-2">
        <span>📧</span> <span>Save &amp; Email to Client</span>
      </button>

      <button type="button" onclick="submitInvoiceForm()" class="py-2.5 px-5 text-xs font-black bg-blue-600 hover:bg-blue-500 text-white rounded-xl shadow-lg transition-all inline-flex items-center gap-2">
        <span>💾</span> <span>Save Invoice Only</span>
      </button>

      <button type="button" onclick="window.print()" class="btn-gold py-2.5 px-5 text-xs font-black shadow-glow inline-flex items-center gap-2 rounded-xl">
        <span>🖨️</span> <span>Print / Save as PDF</span>
      </button>

      <a href="/invoice-view.php?id=<?= urlencode($currentInvoice['invoice_number'] ?? $currentInvoice['id'] ?? 'INV-0001') ?>" target="_blank" class="py-2.5 px-4 text-xs font-bold bg-[#1A1A28] hover:bg-[#24243A] border border-[#2E2E44] text-sky-400 rounded-xl transition-all inline-flex items-center gap-1.5" title="View Public Client Page">
        <span>🌐</span> <span>Public View ↗</span>
      </a>

      <button type="button" onclick="createNewInvoice()" class="py-2.5 px-4 text-xs font-bold bg-[#141420] hover:bg-[#1E1E2E] border border-dark-border text-gray-200 rounded-xl transition-all inline-flex items-center gap-1.5">
        <span>➕</span> <span>New Blank</span>
      </button>

      <button type="button" onclick="toggleSavedDrawer()" class="py-2.5 px-4 text-xs font-bold bg-[#141420] hover:bg-[#1E1E2E] border border-dark-border text-gold rounded-xl transition-all inline-flex items-center gap-1.5">
        <span>📂</span> <span>Saved Invoices (<?= count($invoices) ?>)</span>
      </button>
    </div>
  </div>

  <?= renderFlash() ?>

  <!-- ── 2. TWO-COLUMN LAYOUT: EDITABLE FORM (LEFT) + WYSIWYG SHEET (RIGHT) ── -->
  <div class="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
    
    <!-- LEFT: Form Controls (Hidden on Print) -->
    <div class="no-print xl:col-span-4 glass-card rounded-3xl p-6 border border-dark-border bg-[#111118] space-y-6 shadow-2xl">
      
      <div class="flex items-center justify-between border-b border-dark-border pb-3">
        <h3 class="text-sm font-black text-white flex items-center gap-2">
          <span>⚙️</span> <span>Invoice Customization Controls</span>
        </h3>
        <span class="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 text-[10px] font-mono font-bold uppercase">LIVE EDIT</span>
      </div>

      <form id="masterInvoiceForm" method="POST" class="space-y-4">
        <?= csrfField() ?>
        <input type="hidden" name="save_invoice" value="1">
        <input type="hidden" name="send_invoice_email" id="inputSendEmail" value="0">
        <input type="hidden" name="payment_method" id="inputPaymentMethod" value="<?= htmlspecialchars($currentInvoice['payment_method'] ?? 'payoneer') ?>">

        <!-- Client Auto-Filler Dropdown -->
        <div>
          <label class="block text-xs font-bold text-gray-300 mb-1.5">Quick Auto-Fill from CRM</label>
          <select onchange="autoFillClient(this)" class="w-full bg-[#141422] border border-[#242438] focus:border-gold rounded-xl px-3.5 py-2.5 text-xs text-white">
            <option value="">-- Choose Existing Client --</option>
            <?php foreach ($allClients as $c): 
              $bal = (float)($c['balance'] ?? 0.0);
              $fillVal = ($c['id'] ?? '') . '|' . $c['name'] . '|' . ($c['phone'] ?? '') . '|' . $c['email'] . '|' . ($c['company'] ?? '') . '|' . ($bal > 0 ? $bal : '32.85');
            ?>
            <option value="<?= htmlspecialchars($fillVal) ?>" <?= (($currentInvoice['client_email'] ?? '') === ($c['email'] ?? '')) ? 'selected' : '' ?>>
              <?= htmlspecialchars($c['name']) ?> (<?= htmlspecialchars($c['email']) ?>) <?= $bal > 0 ? ("— Due: $" . number_format($bal, 2)) : '' ?>
            </option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- Invoice Identifiers -->
        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-[11px] font-bold text-gray-400 mb-1">Invoice Number</label>
            <input type="text" name="invoice_number" id="formInvoiceNo" value="<?= htmlspecialchars($currentInvoice['invoice_number'] ?? 'INV-0001') ?>" oninput="syncLiveSheet()" required 
                   class="w-full bg-[#141422] border border-[#242438] focus:border-gold rounded-xl px-3 py-2 text-xs text-white font-mono font-bold">
          </div>
          <div>
            <label class="block text-[11px] font-bold text-gray-400 mb-1">Reference Number</label>
            <input type="text" name="ref_number" id="formRefNumber" value="<?= htmlspecialchars($currentInvoice['ref_number'] ?? ('REF: EH-INV-' . date('Ym') . '-C9D2E9')) ?>" oninput="syncLiveSheet()" required 
                   class="w-full bg-[#141422] border border-[#242438] focus:border-gold rounded-xl px-3 py-2 text-xs text-white font-mono">
          </div>
        </div>

        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-[11px] font-bold text-gray-400 mb-1">Invoice Date</label>
            <input type="text" name="invoice_date" id="formInvoiceDate" value="<?= htmlspecialchars($currentInvoice['date'] ?? date('F j, Y')) ?>" oninput="syncLiveSheet()" required 
                   class="w-full bg-[#141422] border border-[#242438] focus:border-gold rounded-xl px-3 py-2 text-xs text-white font-mono">
          </div>
          <div>
            <label class="block text-[11px] font-bold text-gray-400 mb-1">Due Date</label>
            <input type="text" name="due_date" id="formDueDate" value="<?= htmlspecialchars($currentInvoice['due_date'] ?? 'Upon Receipt') ?>" oninput="syncLiveSheet()" 
                 class="w-full bg-[#141422] border border-[#242438] focus:border-gold rounded-xl px-3 py-2 text-xs text-white">
          </div>
        </div>

        <!-- Client Info -->
        <div class="space-y-2 pt-2 border-t border-dark-border">
          <div class="text-xs font-bold text-gold">Bill To: Client Details</div>
          <div class="grid grid-cols-2 gap-2">
            <input type="text" name="client_id" id="formClientId" placeholder="Client ID (e.g. CL-1012)" value="<?= htmlspecialchars($targetClientId ?: 'CL-1012') ?>" oninput="syncLiveSheet()" 
                   class="w-full bg-[#141422] border border-[#242438] focus:border-gold rounded-xl px-3 py-2 text-xs text-white font-mono">
            <input type="text" name="client_name" id="formClientName" placeholder="Client Name" value="<?= htmlspecialchars($currentInvoice['client_name'] ?? '') ?>" oninput="syncLiveSheet()" 
                   class="w-full bg-[#141422] border border-[#242438] focus:border-gold rounded-xl px-3 py-2 text-xs text-white" required>
          </div>
          <input type="text" name="client_address" id="formClientAddress" placeholder="Company / Agency / Country" value="<?= htmlspecialchars($currentInvoice['client_address'] ?? '') ?>" oninput="syncLiveSheet()" 
                 class="w-full bg-[#141422] border border-[#242438] focus:border-gold rounded-xl px-3 py-2 text-xs text-white">
          <div class="grid grid-cols-2 gap-2">
            <input type="text" name="client_phone" id="formClientPhone" placeholder="Phone Number" value="<?= htmlspecialchars($currentInvoice['client_phone'] ?? '') ?>" oninput="syncLiveSheet()" 
                   class="w-full bg-[#141422] border border-[#242438] focus:border-gold rounded-xl px-3 py-2 text-xs text-white">
            <input type="email" name="client_email" id="formClientEmail" placeholder="Client Email" value="<?= htmlspecialchars($currentInvoice['client_email'] ?? '') ?>" oninput="syncLiveSheet()" 
                   class="w-full bg-[#141422] border border-[#242438] focus:border-gold rounded-xl px-3 py-2 text-xs text-white" required>
          </div>
        </div>

        <!-- Payoneer Link & Payment Routing -->
        <div class="space-y-2 pt-2 border-t border-dark-border">
          <div class="text-xs font-bold text-emerald-400 flex items-center justify-between">
            <span>💳 Payoneer Invoice Payment Link</span>
            <span class="text-[10px] text-gray-400 font-normal">Instant Pay Button</span>
          </div>
          <input type="url" name="payoneer_link" id="formPayoneerLink" placeholder="https://payoneer.com/..." value="<?= htmlspecialchars($currentInvoice['payoneer_link'] ?? '') ?>" oninput="syncLiveSheet()" 
                 class="w-full bg-[#141422] border border-emerald-500/40 focus:border-emerald-400 rounded-xl px-3 py-2 text-xs text-white font-mono placeholder:text-gray-600">
          <div class="text-[10px] text-gray-400 leading-normal">
            Paste your Payoneer payment link here. A clickable button will be automatically generated inside the invoice and client email!
          </div>

          <div class="grid grid-cols-2 gap-2 pt-2">
            <div>
              <label class="block text-[11px] font-bold text-gray-400 mb-1">Currency</label>
              <select name="currency" id="formCurrency" onchange="syncLiveSheet()" class="w-full bg-[#141422] border border-[#242438] focus:border-gold rounded-xl px-3 py-2 text-xs text-white">
                <option value="$" <?= ($currentInvoice['currency'] ?? '$') === '$' ? 'selected' : '' ?>>$ (USD)</option>
                <option value="£" <?= ($currentInvoice['currency'] ?? '') === '£' ? 'selected' : '' ?>>£ (GBP)</option>
                <option value="€" <?= ($currentInvoice['currency'] ?? '') === '€' ? 'selected' : '' ?>>€ (EUR)</option>
                <option value="C$" <?= ($currentInvoice['currency'] ?? '') === 'C$' ? 'selected' : '' ?>>C$ (CAD)</option>
                <option value="A$" <?= ($currentInvoice['currency'] ?? '') === 'A$' ? 'selected' : '' ?>>A$ (AUD)</option>
              </select>
            </div>
            <div>
              <label class="block text-[11px] font-bold text-gray-400 mb-1">Status</label>
              <select name="status" id="formStatus" onchange="syncLiveSheet()" class="w-full bg-[#141422] border border-[#242438] focus:border-gold rounded-xl px-3 py-2 text-xs text-white">
                <option value="pending" <?= ($currentInvoice['status'] ?? '') === 'pending' ? 'selected' : '' ?>>🟡 Pending</option>
                <option value="paid" <?= ($currentInvoice['status'] ?? '') === 'paid' ? 'selected' : '' ?>>🟢 Paid</option>
                <option value="overdue" <?= ($currentInvoice['status'] ?? '') === 'overdue' ? 'selected' : '' ?>>🔴 Overdue</option>
              </select>
            </div>
          </div>
        </div>

        <!-- Remarks Instructions -->
        <div class="pt-2 border-t border-dark-border">
          <label class="block text-xs font-bold text-gold mb-1">Payment Instructions &amp; Routing</label>
          <textarea name="remarks" id="formRemarks" rows="2" oninput="syncLiveSheet()" 
                    class="w-full bg-[#141422] border border-[#242438] focus:border-gold rounded-xl p-3 text-xs text-white leading-relaxed"><?= htmlspecialchars($currentInvoice['remarks'] ?? 'Please process your payment via Payoneer. Send payment to: ashrafnadeem283@gmail.com') ?></textarea>
        </div>

        <!-- Hidden inputs container for dynamically added table line items -->
        <div id="hiddenLineItemsContainer"></div>

      </form>
    </div>

    <!-- RIGHT: Pixel-Perfect Printable Live Invoice Sheet (WYSIWYG matching PDF Letterhead) -->
    <div class="xl:col-span-8 flex justify-center w-full">
      
      <div id="invoicePrintCard" class="doc-sheet rounded-3xl p-8 sm:p-14 overflow-hidden border border-gray-200 w-full max-w-[850px] relative">
        
        <!-- Screen Actions Toolbar on Top of Sheet -->
        <div class="no-print absolute top-6 right-6 flex items-center gap-2 z-20">
          <button type="button" onclick="sendInvoiceEmailDirectly()" class="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow transition-all flex items-center gap-1.5">
            <span>📧</span> <span>Send Email</span>
          </button>
          <button type="button" onclick="window.print()" class="px-3.5 py-1.5 rounded-xl bg-gray-900 hover:bg-gray-800 text-white font-bold text-xs shadow transition-all flex items-center gap-1.5">
            <span>🖨️</span> <span>Print PDF</span>
          </button>
        </div>

        <!-- 15% OPACITY ESTATE HDR CORPORATE WATERMARK -->
        <div class="doc-watermark flex flex-col items-center justify-center">
          <img src="/assets/images/Black.png" alt="Estate HDR" class="w-60 sm:w-64 h-auto object-contain mx-auto mb-2 opacity-90" onerror="this.style.display='none'">
          <div class="text-xs font-mono tracking-widest text-black font-black uppercase">Official Verified Corporate Document</div>
        </div>

        <div class="doc-content space-y-7">
          
          <!-- ── 1. CORPORATE LETTERHEAD HEADER (EXACT MATCH TO INVOICE.PDF) ── -->
          <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b-2 border-[#C9A84C] pb-6">
            <div>
              <div class="flex items-center gap-3">
                <img src="/assets/images/Black.png" alt="Estate HDR" class="h-9 sm:h-10 w-auto max-w-[190px] object-contain" onerror="this.outerHTML='<span class=\'font-black text-xl text-gray-900\'>Estate <span class=\'text-[#C9A84C]\'>HDR</span></span>'">
                <span class="text-[10px] uppercase font-black tracking-widest px-2.5 py-1 rounded bg-amber-100 text-amber-900 border border-amber-300">
                  Commercial Billing Division
                </span>
              </div>
              <p class="text-[11px] text-gray-800 font-mono font-bold mt-1">Premium Real Estate Photo Retouching &amp; Virtual Media SaaS</p>
              <p class="text-[10px] text-gray-500 font-mono">UK Reg: EH-789021 • London &bull; Worldwide Delivery Hubs</p>
            </div>

            <div class="text-right text-[11px] font-mono text-gray-600 space-y-0.5">
              <div class="font-bold text-gray-900" id="sheetRefNumber"><?= htmlspecialchars($currentInvoice['ref_number'] ?? 'REF: EH-INV-202609-C9D2E9') ?></div>
              <div>Date: <strong class="text-gray-900" id="sheetInvoiceDate"><?= htmlspecialchars($currentInvoice['date'] ?? date('F j, Y')) ?></strong></div>
              <div>Contact: <span class="text-gray-900">billing@estatehdr.com</span></div>
              <div>Portal: <span class="text-gray-900">www.estatehdr.com</span></div>
            </div>
          </div>

          <!-- ── 2. DOCUMENT TITLE ────────────────────────────────────── -->
          <div class="text-center space-y-1">
            <h2 class="text-xl font-black tracking-wide text-gray-900 uppercase">OFFICIAL COMMERCIAL INVOICE</h2>
            <p class="text-xs font-mono text-gray-600">
              Invoice #: <strong class="font-bold text-gray-900 font-mono" id="sheetInvoiceNo"><?= htmlspecialchars($currentInvoice['invoice_number'] ?? 'INV-0001') ?></strong>
              &bull; Due Date: <strong class="text-gray-900" id="sheetDueDate"><?= htmlspecialchars($currentInvoice['due_date'] ?? 'Upon Receipt') ?></strong>
              &bull; Currency: <strong>USD ($)</strong>
            </p>
          </div>

          <!-- ── 3. CLIENT INFO GRID (MATCHING HR EMPLOYEE INFO BOX) ── -->
          <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-gray-50 border border-gray-200 text-xs font-mono">
            <div><span class="text-gray-500 block">Client ID:</span><strong class="text-gray-900" id="sheetClientId"><?= htmlspecialchars($targetClientId ?: 'CL-1012') ?></strong></div>
            <div><span class="text-gray-500 block">Client Name:</span><strong class="text-gray-900" id="sheetClientName"><?= htmlspecialchars($currentInvoice['client_name'] ?? 'Brandon') ?></strong></div>
            <div><span class="text-gray-500 block">Company / Agency:</span><strong class="text-gray-900" id="sheetClientAddress"><?= htmlspecialchars($currentInvoice['client_address'] ?? 'Performance Regroup') ?></strong></div>
            <div><span class="text-gray-500 block">Client Contact:</span><strong class="text-gray-900" id="sheetClientEmail"><?= htmlspecialchars($currentInvoice['client_email'] ?? 'brandon@performanceregroup.com') ?></strong></div>
          </div>

          <!-- ── 4. LINE ITEMS TABLE (MATCHING PAYSLIP EARNINGS TABLE) ── -->
          <div class="overflow-hidden rounded-xl border border-gray-200">
            <table class="w-full text-xs text-left">
              <thead class="bg-gray-100 text-gray-700 font-bold border-b border-gray-200">
                <tr>
                  <th class="p-3">SERVICES &amp; DELIVERABLES DESCRIPTION</th>
                  <th class="p-3 text-center w-20">QTY</th>
                  <th class="p-3 text-right w-24">RATE ($)</th>
                  <th class="p-3 text-right w-28">LINE TOTAL ($)</th>
                  <th class="no-print p-3 w-10 text-center"></th>
                </tr>
              </thead>
              <tbody id="invoiceTableBody" class="divide-y divide-gray-100 font-mono">
                <?php foreach (($currentInvoice['items'] ?? []) as $iIdx => $it): ?>
                <tr class="item-row">
                  <td class="p-3">
                    <input type="text" value="<?= htmlspecialchars($it['description'] ?? 'HDR Photo Editing') ?>" class="w-full bg-transparent outline-none font-bold text-gray-900 text-xs border-0 focus:ring-1 focus:ring-blue-400 rounded px-1" oninput="calculateSheetTotals()">
                  </td>
                  <td class="p-3 text-center">
                    <input type="number" step="1" min="1" value="<?= htmlspecialchars($it['qty'] ?? 1) ?>" class="w-16 bg-transparent text-center font-mono outline-none border-0 focus:ring-1 focus:ring-blue-400 rounded px-1 text-gray-800" oninput="calculateSheetTotals()">
                  </td>
                  <td class="p-3 text-right">
                    <input type="number" step="0.01" min="0" value="<?= htmlspecialchars($it['rate'] ?? 0) ?>" class="w-20 bg-transparent text-right font-mono outline-none border-0 focus:ring-1 focus:ring-blue-400 rounded px-1 text-gray-800" oninput="calculateSheetTotals()">
                  </td>
                  <td class="p-3 text-right font-mono font-bold text-gray-900 line-total-cell">
                    <?= htmlspecialchars($currentInvoice['currency'] ?? '$') ?><?= number_format((float)($it['total'] ?? 0), 2) ?>
                  </td>
                  <td class="no-print p-3 text-center">
                    <button type="button" onclick="removeRow(this)" class="text-red-400 hover:text-red-700 font-bold text-sm px-1" title="Remove row">&times;</button>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
              <tfoot class="bg-gray-50 border-t-2 border-gray-300 font-bold font-mono">
                <tr>
                  <td class="p-3 text-gray-800" colspan="3">SUBTOTAL:</td>
                  <td class="p-3 text-right text-gray-900 font-mono" id="sheetSubtotal"><?= htmlspecialchars($currentInvoice['currency'] ?? '$') ?><?= number_format((float)($currentInvoice['subtotal'] ?? 32.85), 2) ?></td>
                  <td class="no-print"></td>
                </tr>
                <tr>
                  <td class="p-3 text-gray-800" colspan="3">TAX / VAT:</td>
                  <td class="p-3 text-right text-gray-900 font-mono" id="sheetTax"><?= htmlspecialchars($currentInvoice['currency'] ?? '$') ?>0.00</td>
                  <td class="no-print"></td>
                </tr>
              </tfoot>
            </table>
          </div>

          <!-- Add Item Row Button (Screen only) -->
          <div class="no-print text-left -mt-3">
            <button type="button" onclick="addInvoiceRow()" class="text-xs font-bold text-[#C9A84C] hover:underline inline-flex items-center gap-1">
              <span>➕</span> <span>Add Another Service Line Item</span>
            </button>
          </div>

          <!-- ── 5. TOTAL NET PAYABLE CARD (MATCHING NET SALARY CARD) ── -->
          <div class="p-5 rounded-2xl bg-amber-50/70 border-2 border-[#C9A84C] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <span class="text-xs text-amber-900 font-bold uppercase tracking-wider">TOTAL NET INVOICE AMOUNT DUE:</span>
              <p class="text-[11px] text-gray-600 font-mono mt-0.5">Please settle upon receipt via verified official payment channels.</p>
              <div id="sheetPayoneerButtonContainer" class="mt-3 <?= !empty($currentInvoice['payoneer_link']) ? '' : 'hidden' ?>">
                <a href="<?= htmlspecialchars($currentInvoice['payoneer_link'] ?? '#') ?>" target="_blank" id="sheetPayoneerLinkBtn" class="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs inline-flex items-center gap-2 shadow-lg transition-all">
                  <span>💳</span> <span>Click Here to Pay Online via Payoneer &rarr;</span>
                </a>
              </div>
            </div>
            <div class="text-right">
              <div class="text-2xl sm:text-3xl font-black text-gray-900 font-mono" id="sheetTotalDue"><?= htmlspecialchars($currentInvoice['currency'] ?? '$') ?><?= number_format((float)($currentInvoice['total'] ?? 32.85), 2) ?> USD</div>
              <span class="text-[10px] font-bold text-emerald-800 uppercase px-2 py-0.5 rounded bg-emerald-100 border border-emerald-300 inline-block mt-1">
                ✓ PAYMENT PENDING / APPROVED
              </span>
            </div>
          </div>

          <!-- ── 6. PAYMENT INSTRUCTIONS BOX ── -->
          <div class="p-4 rounded-xl bg-gray-50 border border-gray-200 text-xs font-mono space-y-1">
            <div class="font-bold text-gray-900 uppercase text-[11px] text-[#C9A84C]">Payment Instructions &amp; Routing</div>
            <p class="text-gray-700 leading-relaxed" id="sheetRemarksText">
              <?= nl2br(htmlspecialchars($currentInvoice['remarks'] ?? 'Please process your payment via Payoneer. Send payment to our official account: ashrafnadeem283@gmail.com')) ?>
            </p>
          </div>

          <!-- ── 7. OFFICIAL SIGNATURES & CORPORATE STAMP (EXACT MATCH TO INVOICE.PDF) ── -->
          <div class="pt-8 border-t-2 border-gray-200 grid grid-cols-3 gap-6 text-center text-xs font-mono">
            
            <!-- Accounts / Billing Signature -->
            <div class="space-y-2">
              <div class="h-14 flex items-end justify-center">
                <span class="font-serif italic text-base text-gray-800 font-bold border-b border-gray-400 pb-1 px-4">
                  Usman Nadeem
                </span>
              </div>
              <div class="font-bold text-gray-900">Head of Client Billing</div>
              <div class="text-[10px] text-gray-500">Estate HDR Finance Division</div>
            </div>

            <!-- Official Seal -->
            <div class="flex flex-col items-center justify-center">
              <div class="w-20 h-20 rounded-full border-2 border-dashed border-[#C9A84C] flex flex-col items-center justify-center p-1 text-center bg-amber-50/50">
                <span class="text-[8px] font-black text-[#C9A84C] uppercase tracking-tighter">ESTATE HDR</span>
                <span class="text-[7px] text-gray-600 font-bold">OFFICIAL SEAL</span>
                <span class="text-[6px] text-gray-400">VERIFIED</span>
              </div>
              <span class="text-[9px] text-gray-400 mt-1">Official Corporate Stamp</span>
            </div>

            <!-- Client Acknowledgment -->
            <div class="space-y-2">
              <div class="h-14 flex items-end justify-center">
                <span class="border-b border-gray-400 w-32 inline-block"></span>
              </div>
              <div class="font-bold text-gray-900" id="sheetClientSignName"><?= htmlspecialchars($currentInvoice['client_name'] ?? 'Brandon') ?></div>
              <div class="text-[10px] text-gray-500">Client Signature &amp; Date</div>
            </div>

          </div>

          <div class="text-right text-[11px] font-mono text-gray-400 pt-2">
            1/1
          </div>

        </div>

      </div>

    </div>

  </div>

  <!-- ── 3. SAVED INVOICES DRAWER (MODAL) ──────────────────────────────── -->
  <div id="savedInvoicesDrawer" class="hidden no-print fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
    <div class="bg-[#111118] border border-dark-border rounded-3xl max-w-2xl w-full max-h-[85vh] flex flex-col overflow-hidden shadow-2xl">
      <div class="p-5 border-b border-dark-border flex items-center justify-between">
        <h3 class="text-base font-black text-white flex items-center gap-2">
          <span>📂</span> <span>Saved Invoices Database (<?= count($invoices) ?>)</span>
        </h3>
        <button type="button" onclick="toggleSavedDrawer()" class="text-gray-400 hover:text-white text-xl font-bold">&times;</button>
      </div>
      <div class="flex-1 overflow-y-auto p-4 space-y-2">
        <?php if (empty($invoices)): ?>
          <div class="p-8 text-center text-gray-500 text-xs">No saved invoices found.</div>
        <?php else: ?>
          <?php foreach ($invoices as $invItem): ?>
          <div class="p-3.5 rounded-2xl bg-[#161622] border border-[#232336] flex items-center justify-between gap-4 hover:border-gold/30 transition-all">
            <div>
              <div class="font-black text-white text-xs flex items-center gap-2">
                <span class="font-mono text-gold"><?= htmlspecialchars($invItem['invoice_number'] ?? $invItem['id']) ?></span>
                <span>•</span>
                <span><?= htmlspecialchars($invItem['client_name'] ?? 'Client') ?></span>
              </div>
              <div class="text-[11px] text-gray-400 mt-0.5">
                <?= htmlspecialchars($invItem['date'] ?? '') ?> &bull; <?= htmlspecialchars($invItem['currency'] ?? '$') ?><?= number_format((float)($invItem['total'] ?? 0), 2) ?> &bull; <span class="capitalize text-emerald-400"><?= htmlspecialchars($invItem['status'] ?? 'pending') ?></span>
              </div>
            </div>
            <div class="flex items-center gap-2">
              <a href="/admin/invoice.php?view=<?= urlencode($invItem['invoice_number'] ?? $invItem['id']) ?>" class="px-3 py-1.5 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/40 text-xs font-bold hover:bg-blue-600 hover:text-white transition-all">
                ✏️ Edit
              </a>
              <a href="/invoice-view.php?id=<?= urlencode($invItem['invoice_number'] ?? $invItem['id']) ?>" target="_blank" class="px-3 py-1.5 rounded-xl bg-[#222232] text-gray-300 border border-[#333346] text-xs font-bold hover:text-white transition-all">
                🌐 View
              </a>
              <a href="/admin/invoice.php?delete=<?= urlencode($invItem['invoice_number'] ?? $invItem['id']) ?>&csrf=<?= csrfToken() ?>" data-confirm="Delete this invoice?" class="px-3 py-1.5 rounded-xl bg-red-600/20 text-red-400 border border-red-500/40 text-xs font-bold hover:bg-red-600 hover:text-white transition-all">
                🗑️
              </a>
            </div>
          </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>

</main>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
function syncLiveSheet() {
  const invNo = document.getElementById('formInvoiceNo').value || 'INV-0001';
  const refNo = document.getElementById('formRefNumber').value || 'REF: EH-INV-202609-C9D2E9';
  const invDate = document.getElementById('formInvoiceDate').value || '';
  const dueDate = document.getElementById('formDueDate').value || 'Upon Receipt';
  const clientId = document.getElementById('formClientId').value || 'CL-1012';
  const clientName = document.getElementById('formClientName').value || 'Client';
  const clientAddress = document.getElementById('formClientAddress').value || '';
  const clientEmail = document.getElementById('formClientEmail').value || '';
  const remarks = document.getElementById('formRemarks').value || '';
  const payoneerLink = document.getElementById('formPayoneerLink').value || '';

  document.getElementById('sheetInvoiceNo').textContent = invNo;
  document.getElementById('headerInvNumberBadge').textContent = invNo;
  document.getElementById('sheetRefNumber').textContent = refNo;
  document.getElementById('sheetInvoiceDate').textContent = invDate;
  document.getElementById('sheetDueDate').textContent = dueDate;
  document.getElementById('sheetClientId').textContent = clientId;
  document.getElementById('sheetClientName').textContent = clientName;
  document.getElementById('sheetClientSignName').textContent = clientName;
  document.getElementById('sheetClientAddress').textContent = clientAddress;
  document.getElementById('sheetClientEmail').textContent = clientEmail;
  document.getElementById('sheetRemarksText').innerHTML = remarks.replace(/\n/g, '<br>');

  const btnContainer = document.getElementById('sheetPayoneerButtonContainer');
  const btn = document.getElementById('sheetPayoneerLinkBtn');
  if (payoneerLink.trim()) {
    btnContainer.classList.remove('hidden');
    btn.href = payoneerLink.trim();
  } else {
    btnContainer.classList.add('hidden');
  }

  calculateSheetTotals();
}

function calculateSheetTotals() {
  const currency = document.getElementById('formCurrency').value || '$';
  const rows = document.querySelectorAll('#invoiceTableBody tr.item-row');
  let subtotal = 0;

  rows.forEach(row => {
    const qtyInput = row.querySelector('input[type="number"]:nth-of-type(1)');
    const rateInput = row.querySelectorAll('input[type="number"]')[1] || row.querySelector('input[step="0.01"]');
    const totalCell = row.querySelector('.line-total-cell');

    const qty = parseFloat(qtyInput?.value) || 0;
    const rate = parseFloat(rateInput?.value) || 0;
    const lineTotal = Math.round(qty * rate * 100) / 100;
    subtotal += lineTotal;

    if (totalCell) {
      totalCell.textContent = currency + lineTotal.toFixed(2);
    }
  });

  document.getElementById('sheetSubtotal').textContent = currency + subtotal.toFixed(2);
  document.getElementById('sheetTax').textContent = currency + '0.00';
  document.getElementById('sheetTotalDue').textContent = currency + subtotal.toFixed(2) + ' USD';
}

function addInvoiceRow() {
  const tbody = document.getElementById('invoiceTableBody');
  const tr = document.createElement('tr');
  tr.className = 'item-row';
  tr.innerHTML = `
    <td class="p-3">
      <input type="text" value="HDR Photo Editing" class="w-full bg-transparent outline-none font-bold text-gray-900 text-xs border-0 focus:ring-1 focus:ring-blue-400 rounded px-1" oninput="calculateSheetTotals()">
    </td>
    <td class="p-3 text-center">
      <input type="number" step="1" min="1" value="1" class="w-16 bg-transparent text-center font-mono outline-none border-0 focus:ring-1 focus:ring-blue-400 rounded px-1 text-gray-800" oninput="calculateSheetTotals()">
    </td>
    <td class="p-3 text-right">
      <input type="number" step="0.01" min="0" value="10.00" class="w-20 bg-transparent text-right font-mono outline-none border-0 focus:ring-1 focus:ring-blue-400 rounded px-1 text-gray-800" oninput="calculateSheetTotals()">
    </td>
    <td class="p-3 text-right font-mono font-bold text-gray-900 line-total-cell">
      $10.00
    </td>
    <td class="no-print p-3 text-center">
      <button type="button" onclick="removeRow(this)" class="text-red-400 hover:text-red-700 font-bold text-sm px-1" title="Remove row">&times;</button>
    </td>
  `;
  tbody.appendChild(tr);
  calculateSheetTotals();
}

function removeRow(btn) {
  const rows = document.querySelectorAll('#invoiceTableBody tr.item-row');
  if (rows.length > 1) {
    btn.closest('tr').remove();
    calculateSheetTotals();
  } else {
    alert('Invoice must contain at least one line item.');
  }
}

function prepareHiddenInputs() {
  const container = document.getElementById('hiddenLineItemsContainer');
  container.innerHTML = '';
  const rows = document.querySelectorAll('#invoiceTableBody tr.item-row');

  rows.forEach(row => {
    const desc = row.querySelector('input[type="text"]').value;
    const nums = row.querySelectorAll('input[type="number"]');
    const qty = nums[0]?.value || 1;
    const rate = nums[1]?.value || 0;

    const iDesc = document.createElement('input');
    iDesc.type = 'hidden';
    iDesc.name = 'item_desc[]';
    iDesc.value = desc;
    container.appendChild(iDesc);

    const iQty = document.createElement('input');
    iQty.type = 'hidden';
    iQty.name = 'item_qty[]';
    iQty.value = qty;
    container.appendChild(iQty);

    const iRate = document.createElement('input');
    iRate.type = 'hidden';
    iRate.name = 'item_rate[]';
    iRate.value = rate;
    container.appendChild(iRate);
  });
}

function submitInvoiceForm() {
  document.getElementById('inputSendEmail').value = '0';
  prepareHiddenInputs();
  document.getElementById('masterInvoiceForm').submit();
}

function sendInvoiceEmailDirectly() {
  const clientEmail = document.getElementById('formClientEmail').value.trim();
  if (!clientEmail) {
    if (window.EstateDialog) EstateDialog.toast('Please enter a valid client email address before sending.', 'error');
    else alert('Please enter a valid client email address before sending.');
    return;
  }
  const doSend = () => {
    document.getElementById('inputSendEmail').value = '1';
    prepareHiddenInputs();
    document.getElementById('masterInvoiceForm').submit();
  };

  if (window.EstateDialog) {
    EstateDialog.confirm('Save and send this official invoice directly to ' + clientEmail + '?', 'Send Official Invoice', { danger: false, confirmText: '✓ Send Invoice Now' }).then(ok => {
      if (ok) doSend();
    });
  } else {
    doSend();
  }
}

function autoFillClient(select) {
  if (!select.value) return;
  const parts = select.value.split('|');
  document.getElementById('formClientId').value = parts[0] || 'CL-1012';
  document.getElementById('formClientName').value = parts[1] || '';
  document.getElementById('formClientPhone').value = parts[2] || '';
  document.getElementById('formClientEmail').value = parts[3] || '';
  document.getElementById('formClientAddress').value = parts[4] || '';

  const rate = parseFloat(parts[5]) || 32.85;
  const firstRateInput = document.querySelector('#invoiceTableBody tr.item-row input[type="number"]:nth-of-type(2)') || document.querySelectorAll('#invoiceTableBody tr.item-row input[type="number"]')[1];
  if (firstRateInput) {
    firstRateInput.value = rate.toFixed(2);
  }

  syncLiveSheet();
}

function toggleSavedDrawer() {
  const d = document.getElementById('savedInvoicesDrawer');
  d.classList.toggle('hidden');
}

function createNewInvoice() {
  window.location.href = '/admin/invoice.php?new=1';
}

document.addEventListener('DOMContentLoaded', () => {
  syncLiveSheet();
});
</script>

</body>
</html>
