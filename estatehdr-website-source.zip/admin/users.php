<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireManagerOrAdmin();

function renderRoleBadges(array $roles): string {
    $html = '';
    $map = [
        'owner'              => ['CEO / Owner', 'bg-gold/15 text-gold border-gold/30'],
        'super_admin'        => ['Super Admin', 'bg-gold/15 text-gold border-gold/30'],
        'manager'            => ['Production Manager', 'bg-blue-500/15 text-blue-400 border-blue-500/30'],
        'production_manager' => ['Production Manager', 'bg-blue-500/15 text-blue-400 border-blue-500/30'],
        'supervisor'         => ['Supervisor', 'bg-purple-500/15 text-purple-400 border-purple-500/30'],
        'team_lead'          => ['Team Lead', 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'],
        'photo_editor'       => ['Photo Editor', 'bg-gray-500/15 text-gray-300 border-gray-500/30'],
        'editor'             => ['Editor', 'bg-gray-500/15 text-gray-300 border-gray-500/30'],
        'hr'                 => ['HR Department', 'bg-pink-500/15 text-pink-400 border-pink-500/30'],
        'seo_manager'        => ['SEO Manager', 'bg-teal-500/15 text-teal-400 border-teal-500/30']
    ];
    foreach ($roles as $r) {
        $cfg = $map[$r] ?? [ucfirst($r), 'bg-gray-500/15 text-gray-300 border-gray-500/30'];
        $html .= '<span class="px-2.5 py-1 rounded-lg text-xs font-bold border ' . $cfg[1] . ' mr-1.5">' . $cfg[0] . '</span>';
    }
    return $html;
}

// Handle Delete User
if (isset($_GET['delete'])) {
    if (!isOwner()) {
        setFlash('error', 'Only the Owner can delete administrative users.');
        header('Location: /admin/users.php');
        exit;
    }
    $delId = trim($_GET['delete']);
    deleteAdminUser($delId);
    setFlash('success', 'User removed successfully.');
    header('Location: /admin/users.php');
    exit;
}

// Handle Add / Edit User POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_user'])) {
    verifyCsrf();
    $name     = trim($_POST['name'] ?? '');
    $email    = strtolower(trim($_POST['email'] ?? ''));
    $phone    = trim($_POST['phone'] ?? '');
    $roles    = $_POST['roles'] ?? ['photo_editor'];
    $password = $_POST['password'] ?? '';
    $isActive = isset($_POST['is_active']);

    if (empty($name) || empty($email)) {
        setFlash('error', 'Please enter both a full name and email address.');
    } else {
        $userData = [
            'id'        => trim($_POST['id'] ?? ''),
            'name'      => $name,
            'email'     => $email,
            'phone'     => $phone,
            'roles'     => $roles,
            'is_active' => $isActive
        ];
        if (!empty($password)) {
            $userData['password'] = $password;
        }
        saveAdminUser($userData);
        setFlash('success', 'Staff account for "' . htmlspecialchars($name) . '" saved successfully!');
        header('Location: /admin/users.php');
        exit;
    }
}

$users = getAdminUsers();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Staff &amp; User Roles — Estate HDR Admin</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8">
  <!-- Back Navigation -->
  <div class="mb-4">
    <a href="/admin/" class="btn-ghost py-2 px-4 text-xs font-bold inline-flex items-center gap-2 border border-[#1E1E2E] hover:border-gold rounded-xl">
      <span>←</span> <span>Back to Dashboard</span>
    </a>
  </div>
  <?= renderFlash() ?>

  <!-- Top Header & Actions -->
  <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
    <div>
      <div class="section-tag mb-1">Team &amp; Access Control</div>
      <h1 class="text-2xl sm:text-3xl font-black text-white">STAFF &amp; USER ROLES</h1>
      <p class="text-gray-400 text-xs mt-1">Manage team permissions, role-based access (Editor, Team Lead, Supervisor, Manager, HR, SEO), and account statuses.</p>
    </div>

    <div class="flex flex-wrap items-center gap-3">
      <a href="/admin/roles-sop.php" class="btn-ghost py-2.5 px-5 text-xs font-bold inline-flex items-center gap-2 border border-gold/40 text-gold hover:bg-gold/10 rounded-xl">
        <span>📖</span> <span>Company Roles &amp; SOP Handbook</span>
      </a>
      <button onclick="openAddUserModal()" class="btn-gold py-2.5 px-6 text-xs font-bold shadow-glow inline-flex items-center gap-2">
        <span>+</span> <span>Add New User</span>
      </button>
    </div>
  </div>

  <!-- Users Data Table -->
  <div class="glass-card rounded-2xl overflow-hidden border border-dark-border shadow-2xl">
    <div class="p-4 border-b border-dark-border flex flex-wrap items-center justify-between gap-4">
      <div class="flex items-center gap-3 text-xs">
        <h3 class="font-bold text-white uppercase tracking-wider">TEAM DIRECTORY</h3>
        <span class="text-gray-400 font-mono"><?= count($users) ?> active staff members</span>
      </div>

      <!-- Quick Role Legend -->
      <div class="flex items-center gap-2 text-xs overflow-x-auto py-1">
        <span class="px-2 py-0.5 rounded-full bg-gold/20 text-gold border border-gold/30 font-bold uppercase text-[11px]">OWNER</span>
        <span class="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/30 font-bold uppercase text-[11px]">MANAGER</span>
        <span class="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/30 font-bold uppercase text-[11px]">SUPERVISOR</span>
        <span class="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold uppercase text-[11px]">TEAM LEAD</span>
        <span class="px-2 py-0.5 rounded-full bg-gray-500/20 text-gray-300 border border-gray-500/30 font-bold uppercase text-[11px]">EDITOR</span>
        <span class="px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-400 border border-pink-500/30 font-bold uppercase text-[11px]">HR</span>
        <span class="px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-400 border border-teal-500/30 font-bold uppercase text-[11px]">SEO</span>
      </div>
    </div>

    <div class="overflow-x-auto">
      <table class="dashboard-table w-full text-left text-xs">
        <thead>
          <tr>
            <th>NAME</th>
            <th>EMAIL</th>
            <th>PHONE</th>
            <th>ROLES</th>
            <th>CREATED DATE</th>
            <th class="text-center">STATUS</th>
            <th class="text-right">ACTIONS</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($users as $u): 
            $roles = $u['roles'] ?? [$u['role'] ?? 'photo_editor'];
          ?>
          <tr class="hover:bg-white/[0.02]">
            <td>
              <div class="font-bold text-white text-sm"><?= htmlspecialchars($u['name']) ?></div>
            </td>
            <td class="font-mono text-gray-300">
              <?= htmlspecialchars($u['email']) ?>
            </td>
            <td class="font-mono text-gray-400">
              <?= htmlspecialchars($u['phone'] ?? '—') ?>
            </td>
            <td>
              <div class="flex flex-wrap gap-1.5">
                <?= renderRoleBadges($roles) ?>
              </div>
            </td>
            <td class="font-mono text-gray-400">
              <?= !empty($u['created_at']) ? date('M j, Y', strtotime($u['created_at'])) : '—' ?>
            </td>
            <td class="text-center">
              <?php if (!empty($u['is_active'])): ?>
                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> Active
                </span>
              <?php else: ?>
                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-red-500/10 text-red-400 border border-red-500/20">
                  <span class="w-1.5 h-1.5 rounded-full bg-red-400"></span> Disabled
                </span>
              <?php endif; ?>
            </td>
            <td class="text-right">
              <div class="flex items-center justify-end gap-2">
                <button onclick='openEditUserModal(<?= json_encode($u) ?>)' class="p-1.5 rounded-lg bg-dark border border-dark-border text-gray-300 hover:text-gold hover:border-gold/40 transition-colors" title="Edit User">
                  ✏️
                </button>
                <?php if (isOwner() && $u['id'] !== 'adm-1'): ?>
                  <button type="button" onclick="openDeleteStaffModal('<?= htmlspecialchars($u['id'], ENT_QUOTES) ?>', '<?= htmlspecialchars($u['name'], ENT_QUOTES) ?>', '<?= htmlspecialchars($u['email'], ENT_QUOTES) ?>')" class="p-1.5 rounded-lg bg-dark border border-dark-border text-gray-400 hover:text-red-400 hover:border-red-500/40 transition-colors" title="Delete User">
                    🗑️
                  </button>
                <?php endif; ?>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</main>

<!-- ADD / EDIT USER MODAL -->
<div id="userModal" class="fixed inset-0 z-50 bg-dark/80 backdrop-blur-sm flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 sm:p-8 max-w-lg w-full border border-dark-border shadow-2xl space-y-6 relative max-h-[90vh] overflow-y-auto">
    <button onclick="closeUserModal()" class="absolute top-5 right-5 text-gray-400 hover:text-white text-lg">&times;</button>
    
    <div>
      <h3 id="modalTitle" class="text-lg font-bold text-white">Add New Staff User</h3>
      <p class="text-xs text-gray-400 mt-0.5">Assign production department roles and login credentials.</p>
    </div>

    <form method="POST" class="space-y-4">
      <?= csrfField() ?>
      <input type="hidden" name="save_user" value="1">
      <input type="hidden" name="id" id="userId" value="">

      <div>
        <label class="form-label">Full Name *</label>
        <input type="text" name="name" id="userName" required class="form-input w-full" placeholder="e.g. John Smith">
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="form-label">Email Address *</label>
          <input type="email" name="email" id="userEmail" required class="form-input w-full" placeholder="user@estatehdr.com">
        </div>
        <div>
          <label class="form-label">Phone Number</label>
          <input type="text" name="phone" id="userPhone" class="form-input w-full" placeholder="+44 770 606 8176">
        </div>
      </div>

      <div>
        <label class="form-label">Password <span id="pwdNotice" class="text-gray-500 text-[11px]">(Leave blank to keep current)</span></label>
        <input type="password" name="password" id="userPassword" class="form-input w-full" placeholder="••••••••">
      </div>

      <!-- Roles Selection -->
      <div>
        <label class="form-label">Assign Production &amp; Operational Roles *</label>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1 text-xs">
          <label class="flex items-center gap-2.5 p-3 rounded-xl bg-dark/60 border border-dark-border cursor-pointer hover:border-gold/50">
            <input type="checkbox" name="roles[]" value="owner" id="role_owner" class="rounded text-gold">
            <div>
              <strong class="text-gold block">CEO / Director (Owner)</strong>
              <span class="text-gray-400 text-[11px]">Full executive &amp; system ownership</span>
            </div>
          </label>

          <label class="flex items-center gap-2.5 p-3 rounded-xl bg-dark/60 border border-dark-border cursor-pointer hover:border-gold/50">
            <input type="checkbox" name="roles[]" value="manager" id="role_manager" class="rounded text-gold">
            <div>
              <strong class="text-blue-400 block">Production / Operations Manager</strong>
              <span class="text-gray-400 text-[11px]">Overall production, capacity &amp; workflow</span>
            </div>
          </label>

          <label class="flex items-center gap-2.5 p-3 rounded-xl bg-dark/60 border border-dark-border cursor-pointer hover:border-gold/50">
            <input type="checkbox" name="roles[]" value="supervisor" id="role_supervisor" class="rounded text-gold">
            <div>
              <strong class="text-purple-400 block">Supervisor</strong>
              <span class="text-gray-400 text-[11px]">Multiple teams monitoring &amp; QA audits</span>
            </div>
          </label>

          <label class="flex items-center gap-2.5 p-3 rounded-xl bg-dark/60 border border-dark-border cursor-pointer hover:border-gold/50">
            <input type="checkbox" name="roles[]" value="team_lead" id="role_team_lead" class="rounded text-gold">
            <div>
              <strong class="text-emerald-400 block">Team Lead</strong>
              <span class="text-gray-400 text-[11px]">Job assignment, technical support &amp; QC</span>
            </div>
          </label>

          <label class="flex items-center gap-2.5 p-3 rounded-xl bg-dark/60 border border-dark-border cursor-pointer hover:border-gold/50">
            <input type="checkbox" name="roles[]" value="photo_editor" id="role_photo_editor" class="rounded text-gold">
            <div>
              <strong class="text-gray-300 block">Photo Editor</strong>
              <span class="text-gray-400 text-[11px]">Core editing execution &amp; self-QC</span>
            </div>
          </label>

          <label class="flex items-center gap-2.5 p-3 rounded-xl bg-dark/60 border border-dark-border cursor-pointer hover:border-gold/50">
            <input type="checkbox" name="roles[]" value="hr" id="role_hr" class="rounded text-gold">
            <div>
              <strong class="text-pink-400 block">HR Department</strong>
              <span class="text-gray-400 text-[11px]">Hiring, onboarding, attendance &amp; policies</span>
            </div>
          </label>

          <label class="flex items-center gap-2.5 p-3 rounded-xl bg-dark/60 border border-dark-border cursor-pointer hover:border-gold/50">
            <input type="checkbox" name="roles[]" value="seo_manager" id="role_seo_manager" class="rounded text-gold">
            <div>
              <strong class="text-teal-400 block">SEO &amp; Content Manager</strong>
              <span class="text-gray-400 text-[11px]">Blog CMS, meta tags &amp; sitemaps</span>
            </div>
          </label>
        </div>
      </div>

      <!-- Account Status -->
      <div class="p-3 rounded-xl bg-dark/60 border border-dark-border flex items-center justify-between">
        <div>
          <span class="text-xs font-bold text-white block">Account Active</span>
          <span class="text-[11px] text-gray-400">Allow user to sign in to their administrative portal</span>
        </div>
        <label class="relative inline-flex items-center cursor-pointer">
          <input type="checkbox" name="is_active" id="userIsActive" class="sr-only peer" checked>
          <div class="w-11 h-6 bg-dark-border peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gold"></div>
        </label>
      </div>

      <div class="flex items-center justify-end gap-3 pt-2">
        <button type="button" onclick="closeUserModal()" class="btn-ghost py-2.5 px-5 text-xs">Cancel</button>
        <button type="submit" class="btn-gold py-2.5 px-6 text-xs font-bold shadow-glow">Save User Account</button>
      </div>
    </form>
  </div>
</div>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
function openAddUserModal() {
  document.getElementById('modalTitle').textContent = 'Add New Staff User';
  document.getElementById('userId').value = '';
  document.getElementById('userName').value = '';
  document.getElementById('userEmail').value = '';
  document.getElementById('userPhone').value = '';
  document.getElementById('userPassword').value = '';
  document.getElementById('userPassword').required = true;
  document.getElementById('pwdNotice').textContent = '(Required for new user)';
  document.getElementById('userIsActive').checked = true;

  // Uncheck all roles and check default Photo Editor
  document.querySelectorAll('#userModal input[name="roles[]"]').forEach(cb => cb.checked = false);
  const def = document.getElementById('role_photo_editor');
  if (def) def.checked = true;

  document.getElementById('userModal').classList.remove('hidden');
}

function openEditUserModal(user) {
  document.getElementById('modalTitle').textContent = 'Edit Staff User: ' + user.name;
  document.getElementById('userId').value = user.id || '';
  document.getElementById('userName').value = user.name || '';
  document.getElementById('userEmail').value = user.email || '';
  document.getElementById('userPhone').value = user.phone || '';
  document.getElementById('userPassword').value = '';
  document.getElementById('userPassword').required = false;
  document.getElementById('pwdNotice').textContent = '(Leave blank to keep current)';
  document.getElementById('userIsActive').checked = !!user.is_active;

  // Set roles
  const roles = user.roles || (user.role ? [user.role] : []);
  document.querySelectorAll('#userModal input[name="roles[]"]').forEach(cb => {
    cb.checked = roles.includes(cb.value);
  });

  document.getElementById('userModal').classList.remove('hidden');
}

function closeUserModal() {
  document.getElementById('userModal').classList.add('hidden');
}
</script>


<!-- CUSTOM DELETE STAFF MODAL (Never blocked by browser) -->
<div id="deleteStaffModal" class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 max-w-md w-full border border-red-500/50 shadow-2xl space-y-4">
    <div class="flex items-center gap-3">
      <div class="w-10 h-10 rounded-2xl bg-red-600/20 border border-red-500 flex items-center justify-center text-red-400 text-xl font-black">
        ⚠️
      </div>
      <div>
        <h3 class="text-base font-black text-white">Delete Staff Account?</h3>
        <p class="text-xs text-gray-400">Permanently revoke credentials and remove from team roster.</p>
      </div>
    </div>

    <div class="p-3.5 rounded-2xl bg-red-950/30 border border-red-800/50 text-xs text-red-200 space-y-1">
      <div>Staff Member: <strong id="deleteStaffName" class="text-white"></strong></div>
      <div class="text-[11px] text-gray-400 font-mono" id="deleteStaffEmail"></div>
    </div>

    <div class="flex items-center justify-end gap-3 pt-2">
      <button type="button" onclick="closeDeleteStaffModal()" class="btn-ghost py-2.5 px-4 text-xs font-bold">Cancel</button>
      <a id="confirmDeleteStaffBtn" href="#" class="py-2.5 px-5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs shadow-lg transition-all inline-flex items-center gap-1.5">
        <span>🗑️ Yes, Delete User</span>
      </a>
    </div>
  </div>
</div>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
function openDeleteStaffModal(userId, name, email) {
  document.getElementById('deleteStaffName').textContent = name;
  document.getElementById('deleteStaffEmail').textContent = email;
  document.getElementById('confirmDeleteStaffBtn').href = '/admin/users.php?delete=' + encodeURIComponent(userId);
  document.getElementById('deleteStaffModal').classList.remove('hidden');
}

function closeDeleteStaffModal() {
  document.getElementById('deleteStaffModal').classList.add('hidden');
}
</script>

</body>
</html>
