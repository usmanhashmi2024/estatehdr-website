<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/mail.php';
require_once __DIR__ . '/../includes/db.php';
requireAdmin();

$testResult = null;
$recipient = trim($_POST['test_email'] ?? (currentUser()['email'] ?? ''));
$testType  = trim($_POST['test_type'] ?? 'all');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['run_mail_test'])) {
    verifyCsrf();
    
    if (empty($recipient) || !filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
        setFlash('error', 'Please enter a valid destination email address for testing.');
    } else {
        $mockOrder = [
            'id'                     => 'ORD-' . rand(5000, 9999),
            'property_name'          => '742 Evergreen Luxury Terrace, Beverly Hills',
            'service_type'           => 'HDR Photo Editing',
            'editing_type'           => 'HDR Photo Editing',
            'cloud_link'             => 'https://dropbox.com/scl/fo/sample-raw-assets',
            'notes'                  => 'Sample order test with window pulls and golden sky replacement.',
            'raw_images_count'       => 24,
            'delivered_images_count' => 24,
            'billed_amount'          => 21.62,
            'client_name'            => 'Test Client (Estate HDR)',
            'client_email'           => $recipient,
            'client_phone'           => '+44 770 606 8176',
            'client_company'         => 'Luxury Real Estate Group',
            'created_at'             => date('c')
        ];

        $results = [];

        if ($testType === 'order' || $testType === 'all') {
            $resOrder = sendNewOrderNotification($mockOrder);
            $results['order_placement'] = [
                'name'    => 'Order Placement Confirmation Email',
                'success' => $resOrder,
                'subject' => "Thank you for placing an order on Estate HDR — #{$mockOrder['id']}"
            ];
        }

        if ($testType === 'delivery' || $testType === 'all') {
            $resDelivery = sendOrderDeliveryInvoiceEmail($mockOrder, 21.62, 'https://dropbox.com/scl/fo/sample-delivered-finals', 24);
            $results['delivery_invoice'] = [
                'name'    => 'Order Delivery & PayPal Invoice Email ($21.62 USD)',
                'success' => $resDelivery,
                'subject' => "Your Photos & Invoice are Ready! — Order #{$mockOrder['id']} — $21.62 USD"
            ];
        }

        $testResult = [
            'recipient' => $recipient,
            'results'   => $results,
            'timestamp' => date('Y-m-d H:i:s T')
        ];
    }
}

// Load recent email logs
$recentLogs = [];
$logFile = DATA_PATH . 'email_logs.json';
if (file_exists($logFile)) {
    $recentLogs = array_slice(json_decode(file_get_contents($logFile), true) ?: [], 0, 15);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Email Diagnostic & Live Test Center — Estate HDR Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css">
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-5xl w-full mx-auto px-6 py-8 space-y-6">
  <?= renderFlash() ?>

  <div>
    <div class="section-tag mb-1">Production Diagnostics</div>
    <h1 class="text-2xl sm:text-3xl font-black text-white">EMAIL DISPATCH &amp; SMTP TEST CENTER</h1>
    <p class="text-gray-400 text-xs mt-1">Verify automated order confirmations and PayPal invoice delivery emails in real-time.</p>
  </div>

  <!-- ── 1. ACTIVE CONFIGURATION STATUS CARD ── -->
  <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
    <div class="p-4 rounded-2xl bg-dark-card border border-dark-border space-y-1">
      <div class="text-[11px] text-gray-400 uppercase font-bold">Mail Delivery Engine</div>
      <div class="text-sm font-bold text-white flex items-center gap-2">
        <?php if (defined('SMTP_PASS') && strlen(SMTP_PASS) > 0): ?>
          <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span class="text-emerald-400">Authenticated Socket SMTP</span>
        <?php else: ?>
          <span class="w-2 h-2 rounded-full bg-amber-400"></span>
          <span class="text-amber-300">PHP mail() with Envelope RFC (-f)</span>
        <?php endif; ?>
      </div>
      <div class="text-[11px] text-gray-500 font-mono">Host: <?= defined('SMTP_HOST') ? SMTP_HOST : 'smtp.hostinger.com' ?>:<?= defined('SMTP_PORT') ? SMTP_PORT : 465 ?></div>
    </div>

    <div class="p-4 rounded-2xl bg-dark-card border border-dark-border space-y-1">
      <div class="text-[11px] text-gray-400 uppercase font-bold">Official PayPal Recipient</div>
      <div class="text-sm font-mono font-bold text-gold"><?= defined('PAYPAL_EMAIL') ? PAYPAL_EMAIL : 'ashrafnadeem283@gmail.com' ?></div>
      <div class="text-[11px] text-gray-500">PayPal.me Link: <?= defined('PAYPAL_ME_LINK') ? PAYPAL_ME_LINK : 'Configured' ?></div>
    </div>

    <div class="p-4 rounded-2xl bg-dark-card border border-dark-border space-y-1">
      <div class="text-[11px] text-gray-400 uppercase font-bold">Primary Dispatch Mailbox</div>
      <div class="text-sm font-mono font-bold text-blue-400"><?= defined('ORDER_EMAIL') ? ORDER_EMAIL : 'order@estatehdr.com' ?></div>
      <div class="text-[11px] text-gray-500">Sender: <?= defined('SMTP_FROM_NAME') ? SMTP_FROM_NAME : 'Estate HDR' ?></div>
    </div>
  </div>

  <!-- ── 2. LIVE TEST DISPATCHER ── -->
  <div class="p-6 rounded-2xl bg-dark-card border border-dark-border space-y-4">
    <h2 class="text-base font-bold text-white flex items-center gap-2">
      <span>✉️</span> Dispatch Live Test Email
    </h2>

    <form method="POST" class="space-y-4">
      <?= csrfField() ?>
      <input type="hidden" name="run_mail_test" value="1">

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="block text-xs font-bold text-gray-300 uppercase mb-1">Destination Test Email Address</label>
          <input type="email" name="test_email" required value="<?= htmlspecialchars($recipient) ?>" placeholder="your.email@gmail.com" class="w-full px-4 py-2.5 rounded-xl bg-[#141422] border border-[#232338] text-sm text-white focus:border-gold outline-none font-mono">
          <p class="text-[11px] text-gray-500 mt-1">Enter your own personal email (Gmail / iCloud / Outlook) to test receiving.</p>
        </div>

        <div>
          <label class="block text-xs font-bold text-gray-300 uppercase mb-1">Select Email Workflow to Test</label>
          <select name="test_type" class="w-full px-4 py-2.5 rounded-xl bg-[#141422] border border-[#232338] text-sm text-white focus:border-gold outline-none">
            <option value="all" <?= $testType === 'all' ? 'selected' : '' ?>>⚡ Send BOTH (Order Confirmation + Delivery Invoice)</option>
            <option value="order" <?= $testType === 'order' ? 'selected' : '' ?>>1️⃣ Order Placement Confirmation Only ("Thank you for placing...")</option>
            <option value="delivery" <?= $testType === 'delivery' ? 'selected' : '' ?>>2️⃣ Order Delivery &amp; PayPal Invoice Only ($21.62 USD)</option>
          </select>
        </div>
      </div>

      <div class="flex items-center justify-end pt-2">
        <button type="submit" class="btn-gold py-2.5 px-6 text-xs font-black shadow-glow inline-flex items-center gap-2">
          🚀 Send Live Test Email Now &rarr;
        </button>
      </div>
    </form>
  </div>

  <?php if (!empty($testResult)): ?>
  <!-- ── 3. TEST EXECUTION SUMMARY ── -->
  <div class="p-6 rounded-2xl bg-emerald-950/20 border border-emerald-500/40 space-y-4">
    <div class="flex items-center gap-3">
      <span class="text-2xl">🎉</span>
      <div>
        <h3 class="text-base font-bold text-emerald-400">Test Execution Finished</h3>
        <p class="text-xs text-gray-300">Target Inbox: <strong class="text-white font-mono"><?= htmlspecialchars($testResult['recipient']) ?></strong> at <?= $testResult['timestamp'] ?></p>
      </div>
    </div>

    <div class="space-y-2">
      <?php foreach ($testResult['results'] as $key => $res): ?>
        <div class="flex items-center justify-between p-3 rounded-xl bg-[#0d141e] border border-[#1e2a3b] text-xs">
          <div>
            <strong class="text-white"><?= htmlspecialchars($res['name']) ?></strong>
            <div class="text-[11px] text-gray-400 font-mono mt-0.5"><?= htmlspecialchars($res['subject']) ?></div>
          </div>
          <span class="px-2.5 py-1 rounded-full font-bold uppercase text-[10px] <?= $res['success'] ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-red-500/20 text-red-400 border border-red-500/30' ?>">
            <?= $res['success'] ? '✓ DISPATCHED' : '⚠️ ATTEMPTED' ?>
          </span>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- ── 4. RECENT AUDIT LOGS ── -->
  <div class="p-6 rounded-2xl bg-dark-card border border-dark-border space-y-4">
    <div class="flex items-center justify-between">
      <h2 class="text-base font-bold text-white flex items-center gap-2">
        <span>📜</span> Recent Email Dispatch Logs
      </h2>
      <span class="text-xs text-gray-500">Live storage in data/email_logs.json</span>
    </div>

    <?php if (empty($recentLogs)): ?>
      <p class="text-xs text-gray-500 italic">No email logs recorded yet.</p>
    <?php else: ?>
      <div class="overflow-x-auto">
        <table class="w-full text-xs text-left">
          <thead>
            <tr class="text-gray-400 border-b border-dark-border">
              <th class="pb-2">Timestamp</th>
              <th class="pb-2">Recipient</th>
              <th class="pb-2">Subject</th>
              <th class="pb-2">Transport</th>
              <th class="pb-2 text-right">Status</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-dark-border/40 font-mono">
            <?php foreach ($recentLogs as $l): ?>
            <tr>
              <td class="py-2.5 text-gray-400"><?= substr($l['timestamp'] ?? '', 0, 19) ?></td>
              <td class="py-2.5 text-blue-400"><?= htmlspecialchars($l['recipient'] ?? '') ?></td>
              <td class="py-2.5 text-white"><?= htmlspecialchars(substr($l['subject'] ?? '', 0, 45)) ?>...</td>
              <td class="py-2.5 text-gray-400"><?= htmlspecialchars($l['meta']['transport'] ?? 'native') ?></td>
              <td class="py-2.5 text-right">
                <span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase <?= !empty($l['success']) ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400' ?>">
                  <?= !empty($l['success']) ? 'OK' : 'FAIL' ?>
                </span>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</main>

</body>
</html>
