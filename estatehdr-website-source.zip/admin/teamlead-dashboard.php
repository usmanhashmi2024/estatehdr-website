<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/saas-db.php';
requireAdmin();

// ── Handle God-Mode Delete Order (Owner / Super Admin) ────────────────────────
if (isset($_GET['delete_order_id'])) {
    if (!isOwner()) {
        setFlash('error', 'Only Owner/CEO has permission to delete production orders.');
        header("Location: /admin/teamlead-dashboard.php");
        exit;
    }
    $delOid = trim($_GET['delete_order_id']);
    deleteOrder($delOid);
    setFlash('success', "Order #{$delOid} permanently removed from all queues.");
    header("Location: /admin/teamlead-dashboard.php");
    exit;
}


$currentAdmin = currentAdminUser();
$adminRoles   = getAdminRoles();
$tlId         = $currentAdmin['id']   ?? 'adm-4';
$tlName       = $currentAdmin['name'] ?? 'Production Team Lead';

// ── 1. POST: Assign Editor ──────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_editor'])) {
    verifyCsrf();
    $orderId  = trim($_POST['order_id'] ?? '');
    $editorId = trim($_POST['editor_id'] ?? '');
    
    $employees = getSaaSEmployees();
    $editorName = 'Assigned Editor';
    foreach ($employees as $emp) {
        if (($emp['user_id'] ?? '') === $editorId || ($emp['id'] ?? '') === $editorId) {
            $editorName = $emp['name'];
            break;
        }
    }
    
    $orders = getSaaSOrders();
    foreach ($orders as &$o) {
        if ($o['id'] === $orderId) {
            $o['assigned_editor_id']   = $editorId;
            $o['assigned_editor_name'] = $editorName;
            $o['status']               = 'assigned_editor';
            $o['updated_at']           = date('c');
            saveSaaSOrders($orders);
            logSaaSEvent($tlId, "Team Lead assigned job to $editorName", $orderId, ['editor_id' => $editorId]);
            break;
        }
    }
    setFlash('success', "Order #$orderId successfully assigned to Editor: $editorName!");
    header("Location: /admin/teamlead-dashboard.php");
    exit;
}

// ── 2. POST: QA Decision (Approve vs Revision) ──────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_qa_decision'])) {
    verifyCsrf();
    $orderId  = trim($_POST['order_id'] ?? '');
    $decision = trim($_POST['decision'] ?? '');
    
    if ($decision === 'approve') {
        updateSaaSOrderStatus($orderId, 'approved', $tlId, $tlName, 'Team Lead approved quality');
        setFlash('success', "Order #$orderId APPROVED! Forwarded to Supervisor for client delivery.");
    } elseif ($decision === 'revision') {
        $instructions = trim($_POST['revision_instructions'] ?? '');
        $category     = trim($_POST['mistake_category'] ?? 'General');
        if (empty($instructions)) {
            setFlash('error', 'Please provide revision instructions for the editor.');
            header("Location: /admin/teamlead-dashboard.php");
            exit;
        }
        addOrderRevision($orderId, $tlName, $instructions, $category);
        setFlash('error', "Revision requested for Order #$orderId. Sent back to Editor with notes.");
    }
    header("Location: /admin/teamlead-dashboard.php");
    exit;
}

$allOrders  = getSaaSOrders();
$employees  = getSaaSEmployees();
$editors    = array_values(array_filter($employees, fn($e) => $e['role'] === 'Photo Editor'));

// Filter orders assigned to this TL or unassigned
$myOrders = array_values(array_filter($allOrders, function($o) use ($tlId, $adminRoles) {
    if (in_array('owner', $adminRoles) || in_array('manager', $adminRoles) || in_array('supervisor', $adminRoles)) return true;
    return ($o['assigned_tl_id'] ?? '') === $tlId || empty($o['assigned_tl_id']);
}));

// Categorized Order Buckets
$unassignedOrders = array_values(array_filter($myOrders, fn($o) => in_array($o['status'] ?? '', ['assigned_tl', 'new', 'received']) || empty($o['assigned_editor_id'])));
$inProcessOrders  = array_values(array_filter($myOrders, fn($o) => in_array($o['status'] ?? '', ['assigned_editor', 'in_process'])));
$awaitingQAOrders = array_values(array_filter($myOrders, fn($o) => in_array($o['status'] ?? '', ['submitted_qa', 'resubmitted'])));
$inRevisionOrders = array_values(array_filter($myOrders, fn($o) => ($o['status'] ?? '') === 'revision_required'));
$approvedOrders   = array_values(array_filter($myOrders, fn($o) => in_array($o['status'] ?? '', ['approved', 'ready_delivery', 'sent_client', 'completed'])));

// Comprehensive Category Counts for Interactive Filter Bar
$tlCategoryCounts = [
    'all'             => count($myOrders),
    'pending'         => 0,
    'editing'         => 0,
    'qa_review'       => 0,
    'revision'        => 0,
    'approved'        => 0,
    'free_trial'      => 0,
    'live_order'      => 0,
    'cleared'         => 0,
    'due'             => 0,
];

$categorizedTlOrders = [];
foreach ($myOrders as $o) {
    $s = strtolower($o['status'] ?? 'pending');
    $fin = function_exists('getOrderFinancialStatus') ? getOrderFinancialStatus($o) : [
        'is_trial' => false,
        'category_badge' => '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/40">⚡ LIVE ORDER</span>',
        'cleared' => false,
        'payment_status' => 'pending',
        'payment_badge' => '<span class="text-gray-400 font-mono">—</span>'
    ];

    if (in_array($s, ['submitted_qa', 'resubmitted'])) {
        $wfCat = 'qa_review';
    } elseif ($s === 'revision_required') {
        $wfCat = 'revision';
    } elseif (in_array($s, ['approved', 'ready_delivery', 'sent_client', 'completed'])) {
        $wfCat = 'approved';
    } elseif (in_array($s, ['assigned_editor', 'in_process'])) {
        $wfCat = 'editing';
    } else {
        $wfCat = 'pending';
    }

    $isTrial = !empty($fin['is_trial']);
    $isCleared = !empty($fin['cleared']);
    $hasDue = (($fin['payment_status'] ?? '') === 'pending');

    $tlCategoryCounts[$wfCat]++;
    if ($isTrial) {
        $tlCategoryCounts['free_trial']++;
    } else {
        $tlCategoryCounts['live_order']++;
    }
    if ($isCleared) {
        $tlCategoryCounts['cleared']++;
    }
    if ($hasDue) {
        $tlCategoryCounts['due']++;
    }

    $categorizedTlOrders[] = [
        'order'     => $o,
        'fin'       => $fin,
        'wf_cat'    => $wfCat,
        'type_cat'  => $isTrial ? 'free_trial' : 'live_order',
        'pay_cat'   => $isCleared ? 'cleared' : ($hasDue ? 'due' : 'in_production'),
    ];
}

$initialTlCat = trim($_GET['cat'] ?? 'all');
if (!array_key_exists($initialTlCat, $tlCategoryCounts)) {
    $initialTlCat = 'all';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Team Lead QA Hub — Estate HDR</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8 space-y-8">
  <?= renderFlash() ?>

  <!-- ── PAGE HEADER ──────────────────────────────────────────────── -->
  <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
    <div>
      <div class="section-tag mb-1">Working Leadership &amp; Quality Hub</div>
      <h1 class="text-2xl sm:text-3xl font-black text-white">TEAM LEAD PRODUCTION &amp; QA HUB</h1>
      <p class="text-gray-400 text-xs mt-1">Smart editor job assignment, quality control inspection, and revision feedback.</p>
    </div>
  </div>

  <!-- ── METRIC COUNTERS ─────────────────────────────────────────── -->
  <div class="grid grid-cols-2 sm:grid-cols-5 gap-4">
    <!-- Unassigned -->
    <div class="glass-card rounded-2xl p-5 border border-amber-500/40 bg-amber-950/15 space-y-1.5 shadow-lg">
      <span class="text-xs text-amber-400 uppercase font-black tracking-wider">Unassigned</span>
      <div class="text-3xl font-black text-white font-mono"><?= count($unassignedOrders) ?></div>
      <span class="text-xs text-amber-300 font-bold">Assign Editor &darr;</span>
    </div>
    <!-- In Production -->
    <div class="glass-card rounded-2xl p-5 border border-blue-500/40 bg-blue-950/15 space-y-1.5 shadow-lg">
      <span class="text-xs text-blue-400 uppercase font-black tracking-wider">In Production</span>
      <div class="text-3xl font-black text-blue-300 font-mono"><?= count($inProcessOrders) ?></div>
      <span class="text-xs text-gray-300 font-medium">Editors working</span>
    </div>
    <!-- Awaiting QA Review -->
    <div class="glass-card rounded-2xl p-5 border border-purple-500/50 bg-purple-950/20 space-y-1.5 shadow-lg">
      <span class="text-xs text-purple-300 uppercase font-black tracking-wider">Awaiting QA</span>
      <div class="text-3xl font-black text-purple-300 font-mono"><?= count($awaitingQAOrders) ?></div>
      <span class="text-xs text-purple-300 font-bold">Action Needed &darr;</span>
    </div>
    <!-- In Revision -->
    <div class="glass-card rounded-2xl p-5 border border-red-500/40 bg-red-950/15 space-y-1.5 shadow-lg">
      <span class="text-xs text-red-400 uppercase font-black tracking-wider">In Revision</span>
      <div class="text-3xl font-black text-red-300 font-mono"><?= count($inRevisionOrders) ?></div>
      <span class="text-xs text-red-400 font-bold">Editor fixing</span>
    </div>
    <!-- QA Approved -->
    <div class="glass-card rounded-2xl p-5 border border-emerald-500/40 bg-emerald-950/15 space-y-1.5 shadow-lg">
      <span class="text-xs text-emerald-400 uppercase font-black tracking-wider">Approved</span>
      <div class="text-3xl font-black text-emerald-300 font-mono"><?= count($approvedOrders) ?></div>
      <span class="text-xs text-gray-300 font-medium">Ready for Supervisor</span>
    </div>
  </div>

  <!-- ── 1. AWAITING QA REVIEW SECTION (TOP PRIORITY) ─────────────── -->
  <?php if (!empty($awaitingQAOrders)): ?>
  <div class="glass-card rounded-3xl border border-purple-500/50 bg-purple-950/15 shadow-2xl p-6 sm:p-8 space-y-6">
    <div class="flex items-center justify-between border-b border-purple-500/30 pb-5">
      <div class="flex items-center gap-3">
        <span class="text-2xl animate-bounce">🔍</span>
        <div>
          <h3 class="text-lg font-black text-white uppercase tracking-tight">SUBMITTED JOBS — AWAITING TEAM LEAD QA REVIEW</h3>
          <p class="text-sm text-purple-200/90 font-medium mt-0.5">Inspect processed files, approve quality, or request revision corrections.</p>
        </div>
      </div>
      <span class="px-4 py-1.5 rounded-full bg-purple-500/25 text-purple-200 font-black text-sm border border-purple-500/50 shadow-sm">
        <?= count($awaitingQAOrders) ?> Jobs Ready for Review
      </span>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
      <?php foreach ($awaitingQAOrders as $o): 
        $isRevSub = ($o['status'] === 'resubmitted') || !empty($o['is_revision_resubmit']);
        $revRound = count($o['revisions'] ?? []);
      ?>
      <div class="p-6 rounded-2xl bg-dark/95 border <?= $isRevSub ? 'border-blue-500/60' : 'border-purple-500/50' ?> space-y-4 shadow-xl">
        <div class="flex items-center justify-between border-b border-dark-border pb-3.5">
          <div>
            <span class="font-mono font-black text-gold text-base"><?= htmlspecialchars($o['id']) ?></span>
            <span class="ml-2.5 font-black text-white text-base"><?= htmlspecialchars($o['property_name']) ?></span>
          </div>
          <?php if ($isRevSub): ?>
            <span class="px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/40 text-xs font-black font-mono animate-pulse">
              🔁 REVISION DONE (Round #<?= $revRound ?>)
            </span>
          <?php else: ?>
            <span class="px-3 py-1 rounded-full bg-purple-500/25 text-purple-200 border border-purple-500/50 text-xs font-black">
              SUBMITTED FOR QA
            </span>
          <?php endif; ?>
        </div>

        <div class="grid grid-cols-2 gap-3 text-sm font-mono">
          <div class="p-3.5 rounded-xl bg-[#111118] border border-dark-border">
            <span class="text-gray-400 block text-xs">Editor:</span>
            <strong class="text-white text-sm"><?= htmlspecialchars($o['assigned_editor_name'] ?? 'Photo Editor') ?></strong>
          </div>
          <div class="p-3.5 rounded-xl bg-[#111118] border border-dark-border">
            <span class="text-gray-400 block text-xs">Final Photos Count:</span>
            <strong class="text-emerald-400 text-sm font-bold"><?= $o['final_image_count'] ?? $o['photo_count'] ?> Images</strong>
          </div>
        </div>

        <div class="p-3.5 rounded-xl bg-[#111118] border border-dark-border text-sm font-mono">
          <span class="text-gray-400 block mb-1 text-xs">Editor Output Storage:</span>
          <strong class="text-gold break-all text-sm"><?= htmlspecialchars($o['output_storage_path'] ?: 'Check storage server') ?></strong>
        </div>

        <!-- QA & View Action Buttons -->
        <div class="pt-2 flex items-center justify-end gap-2.5">
          <a href="/admin/order-view.php?id=<?= urlencode($o['id']) ?>" class="btn-ghost py-2.5 px-4 text-xs font-bold border border-dark-border text-gray-300 hover:text-white rounded-xl inline-flex items-center gap-1.5">
            <span>👁️</span> <span>View Order</span>
          </a>
          <button type="button" class="btn-gold py-2.5 px-5 text-sm font-black shadow-glow inline-flex items-center gap-2 btn-open-qa" data-order-id="<?= htmlspecialchars($o['id'], ENT_QUOTES) ?>">
            <span>🔍</span> <span>Perform QA &rarr;</span>
          </button>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- ── 2. UNASSIGNED JOBS SECTION (ASSIGN TO EDITOR) ────────────── -->
  <?php if (!empty($unassignedOrders)): ?>
  <div class="glass-card rounded-3xl border border-amber-500/40 bg-amber-950/15 shadow-xl p-6 sm:p-8 space-y-6">
    <div class="flex items-center justify-between border-b border-amber-500/30 pb-5">
      <div class="flex items-center gap-3">
        <span class="text-2xl">⚡</span>
        <div>
          <h3 class="text-lg font-black text-white">UNASSIGNED ORDERS — ASSIGN TO PHOTO EDITORS</h3>
          <p class="text-sm text-amber-200/90 font-medium mt-0.5">Distribute jobs evenly based on editor availability.</p>
        </div>
      </div>
      <span class="px-4 py-1.5 rounded-full bg-amber-500/25 text-amber-300 font-black text-sm border border-amber-500/50 shadow-sm">
        <?= count($unassignedOrders) ?> Orders Unassigned
      </span>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
      <?php foreach ($unassignedOrders as $o): ?>
      <div class="p-5 rounded-2xl bg-dark/95 border border-amber-500/30 space-y-3.5 shadow-md">
        <div class="flex items-center justify-between">
          <span class="font-mono font-black text-gold text-base"><?= htmlspecialchars($o['id']) ?></span>
          <span class="text-gray-300 text-xs font-mono font-bold bg-white/5 px-2 py-0.5 rounded-md"><?= $o['photo_count'] ?> Photos</span>
        </div>
        <div>
          <div class="font-bold text-white text-base"><?= htmlspecialchars($o['property_name']) ?></div>
          <div class="text-gray-300 text-sm mt-0.5 font-medium"><?= htmlspecialchars($o['editing_type']) ?></div>
        </div>

        <form method="POST" class="pt-3 border-t border-dark-border space-y-2.5">
          <?= csrfField() ?>
          <input type="hidden" name="assign_editor" value="1">
          <input type="hidden" name="order_id" value="<?= htmlspecialchars($o['id']) ?>">
          
          <label class="form-label text-xs font-bold text-gray-300">Assign Editor:</label>
          <div class="flex gap-2">
            <select name="editor_id" required class="form-select text-sm py-2 px-3 bg-[#161622] border-[#2A2A3A] rounded-xl flex-1 text-white font-medium">
              <?php foreach ($editors as $ed): 
                $edUid = $ed['user_id'] ?? $ed['id'];
                $edPres = getStaffOnlinePresence($ed);
                $edActiveCount = count(array_filter($allOrders, fn($ord) => (($ord['assigned_editor_id'] ?? '') === $edUid || ($ord['assigned_editor_id'] ?? '') === $ed['id']) && !in_array($ord['status'] ?? '', ['completed','sent_client'])));
              ?>
                <option value="<?= htmlspecialchars($edUid) ?>">
                  <?= $edPres['is_online'] ? '🟢' : '⚪' ?> <?= htmlspecialchars($ed['name']) ?> (<?= $edActiveCount ?> active)
                </option>
              <?php endforeach; ?>
            </select>
            <button type="submit" class="btn-gold py-2 px-4 text-sm font-black shadow-glow whitespace-nowrap">
              Assign &rarr;
            </button>
          </div>
        </form>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- ── 3. MASTER TEAM LEAD ORDER PIPELINE & CATEGORIES TABLE ──── -->
  <div class="glass-card rounded-3xl border border-dark-border shadow-2xl overflow-hidden space-y-4 p-6">
    <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-dark-border pb-4">
      <div>
        <h3 class="font-black text-white uppercase text-base tracking-wider flex items-center gap-2">
          <span>📋</span> <span>TEAM LEAD PIPELINE &amp; CATEGORIES</span>
        </h3>
        <p class="text-xs text-gray-400 mt-0.5">Filter by Team Lead stage (Pending Assignment, Editing, QA Review, Revision, Delivered) or commercial category.</p>
      </div>

      <div class="w-full lg:w-72">
        <input type="text" id="teamleadSearchInput" onkeyup="filterTeamleadOrders()" placeholder="Search order ID, property, editor..." class="form-input text-xs py-2 px-3 bg-[#111118] border-dark-border rounded-xl w-full text-white placeholder-gray-500">
      </div>
    </div>

    <!-- Category Tabs Bar -->
    <div class="flex flex-wrap items-center gap-2 pt-1 pb-1">
      <button type="button" onclick="setTeamleadCategory('all')" id="tlCatBtn-all" class="tl-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-gold text-black shadow-lg shadow-gold/20">
        <span>📋 All Orders</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-black/30 text-black tl-count-badge"><?= $tlCategoryCounts['all'] ?></span>
      </button>

      <button type="button" onclick="setTeamleadCategory('pending')" id="tlCatBtn-pending" class="tl-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-transparent text-gray-400 hover:text-white hover:bg-white/5">
        <span>⏳ Unassigned</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 tl-count-badge"><?= $tlCategoryCounts['pending'] ?></span>
      </button>

      <button type="button" onclick="setTeamleadCategory('editing')" id="tlCatBtn-editing" class="tl-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-transparent text-gray-400 hover:text-white hover:bg-white/5">
        <span>🎨 In Editing</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-500/20 text-blue-300 tl-count-badge"><?= $tlCategoryCounts['editing'] ?></span>
      </button>

      <button type="button" onclick="setTeamleadCategory('qa_review')" id="tlCatBtn-qa_review" class="tl-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-transparent text-gray-400 hover:text-white hover:bg-white/5">
        <span>🔍 Awaiting QA</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-purple-500/25 text-purple-300 tl-count-badge"><?= $tlCategoryCounts['qa_review'] ?></span>
      </button>

      <button type="button" onclick="setTeamleadCategory('revision')" id="tlCatBtn-revision" class="tl-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-transparent text-gray-400 hover:text-white hover:bg-white/5">
        <span>⚠️ In Revision</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-red-500/20 text-red-400 tl-count-badge"><?= $tlCategoryCounts['revision'] ?></span>
      </button>

      <button type="button" onclick="setTeamleadCategory('approved')" id="tlCatBtn-approved" class="tl-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-transparent text-gray-400 hover:text-white hover:bg-white/5">
        <span>✅ Approved &amp; Delivered</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/20 text-emerald-300 tl-count-badge"><?= $tlCategoryCounts['approved'] ?></span>
      </button>

      <div class="h-6 w-px bg-dark-border mx-1 hidden sm:block"></div>

      <button type="button" onclick="setTeamleadCategory('free_trial')" id="tlCatBtn-free_trial" class="tl-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-transparent text-gray-400 hover:text-white hover:bg-white/5">
        <span>🎁 Free Trials</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 tl-count-badge"><?= $tlCategoryCounts['free_trial'] ?></span>
      </button>

      <button type="button" onclick="setTeamleadCategory('live_order')" id="tlCatBtn-live_order" class="tl-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-transparent text-gray-400 hover:text-white hover:bg-white/5">
        <span>⚡ Live Orders</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-500/20 text-blue-300 tl-count-badge"><?= $tlCategoryCounts['live_order'] ?></span>
      </button>
    </div>

    <!-- Table -->
    <div class="overflow-x-auto">
      <table class="dashboard-table w-full text-left text-xs" id="teamleadOrdersTable">
        <thead>
          <tr class="border-b border-dark-border bg-[#141420]">
            <th class="py-3 px-3">ORDER ID</th>
            <th class="py-3 px-3">PROPERTY</th>
            <th class="py-3 px-3">CATEGORY</th>
            <th class="py-3 px-3">CLEARANCE</th>
            <th class="py-3 px-3">PHOTOS</th>
            <th class="py-3 px-3">ASSIGNED EDITOR</th>
            <th class="py-3 px-3">STATUS</th>
            <th class="py-3 px-3">DEADLINE</th>
            <th class="py-3 px-3 text-right">QA ACTIONS</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-dark-border">
          <?php foreach ($categorizedTlOrders as $item): 
            $o = $item['order'];
            $fin = $item['fin'];
            $wfCat = $item['wf_cat'];
            $typeCat = $item['type_cat'];
            $payCat = $item['pay_cat'];
            $s = strtolower($o['status'] ?? 'pending');
            $isAwaiting = in_array($s, ['submitted_qa', 'resubmitted']);
          ?>
          <tr class="hover:bg-white/[0.03] transition-colors tl-order-row"
              data-wf-cat="<?= htmlspecialchars($wfCat) ?>"
              data-type-cat="<?= htmlspecialchars($typeCat) ?>"
              data-pay-cat="<?= htmlspecialchars($payCat) ?>">

            <!-- ORDER ID -->
            <td class="py-3 px-3 font-mono font-bold text-gold text-xs">
              <a href="/admin/order-view.php?id=<?= urlencode($o['id']) ?>" class="hover:underline">
                <?= htmlspecialchars($o['id']) ?>
              </a>
            </td>

            <!-- PROPERTY -->
            <td class="py-3 px-3">
              <div class="font-bold text-white text-xs"><?= htmlspecialchars($o['property_name'] ?? '—') ?></div>
              <div class="text-gray-400 text-[11px] mt-0.5"><?= htmlspecialchars($o['editing_type'] ?? 'Standard Editing') ?></div>
            </td>

            <!-- CATEGORY -->
            <td class="py-3 px-3 whitespace-nowrap">
              <?= $fin['category_badge'] ?>
            </td>

            <!-- CLEARANCE -->
            <td class="py-3 px-3 whitespace-nowrap">
              <?= $fin['payment_badge'] ?>
            </td>

            <!-- PHOTOS -->
            <td class="py-3 px-3 font-mono font-bold text-white text-xs"><?= $o['photo_count'] ?? 0 ?></td>

            <!-- ASSIGNED EDITOR -->
            <td class="py-3 px-3 whitespace-nowrap">
              <?php if (!empty($o['assigned_editor_name'])): ?>
                <span class="font-bold text-blue-300 text-xs"><?= htmlspecialchars($o['assigned_editor_name']) ?></span>
                <?php if (!empty($o['locked_by_id'])): ?>
                  <span class="ml-1 text-[10px] text-blue-400 font-bold bg-blue-500/20 px-1.5 py-0.5 rounded">● Editing</span>
                <?php endif; ?>
              <?php else: ?>
                <span class="text-gray-400 italic text-xs">Unassigned</span>
              <?php endif; ?>
            </td>

            <!-- STATUS -->
            <td class="py-3 px-3 whitespace-nowrap">
              <?php if ($s === 'revision_required'): ?>
                <span class="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/40 font-bold text-[10px] animate-pulse">REVISION REQUIRED</span>
              <?php elseif ($s === 'resubmitted'): ?>
                <span class="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/40 font-bold text-[10px]">🔁 REVISION DONE</span>
              <?php elseif ($s === 'submitted_qa'): ?>
                <span class="px-2 py-0.5 rounded-full bg-purple-500/25 text-purple-300 border border-purple-500/40 font-bold text-[10px]">QA REVIEW</span>
              <?php elseif (in_array($s, ['approved', 'ready_delivery'])): ?>
                <span class="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold text-[10px]">✓ APPROVED</span>
              <?php elseif (in_array($s, ['sent_client', 'completed'])): ?>
                <span class="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/40 font-bold text-[10px]">✓ DELIVERED</span>
              <?php elseif ($s === 'in_process'): ?>
                <span class="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/40 font-bold text-[10px]">IN PROCESS</span>
              <?php else: ?>
                <span class="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold text-[10px]"><?= strtoupper(str_replace('_', ' ', $s)) ?></span>
              <?php endif; ?>
            </td>

            <!-- DEADLINE -->
            <td class="py-3 px-3 font-mono text-gray-300 text-xs font-medium whitespace-nowrap"><?= date('M j, H:i', strtotime($o['deadline'] ?? 'now')) ?></td>

            <!-- QA ACTIONS -->
            <td class="py-3 px-3 text-right whitespace-nowrap">
              <div class="flex items-center justify-end gap-1.5">
                <?php if ($isAwaiting): ?>
                  <button type="button" class="btn-gold py-1 px-2.5 text-xs font-black shadow-glow btn-open-qa rounded-lg" data-order-id="<?= htmlspecialchars($o['id'], ENT_QUOTES) ?>">
                    🔍 QA
                  </button>
                <?php endif; ?>
                <a href="/admin/order-view.php?id=<?= urlencode($o['id']) ?>" class="btn-ghost py-1 px-2.5 text-xs font-bold border border-dark-border text-gray-300 hover:text-white rounded-lg">
                  View
                </a>
                <?php if ($isOwner): ?>
                  <button type="button" class="btn-open-tldel py-1 px-2 text-xs font-bold rounded-lg bg-red-600/20 hover:bg-red-600/40 text-red-400 border border-red-500/30 transition-all" data-order-id="<?= htmlspecialchars($o['id'], ENT_QUOTES) ?>" data-order-title="<?= htmlspecialchars($o['property_name'] ?? $o['id'], ENT_QUOTES) ?>">
                    Delete
                  </button>
                <?php endif; ?>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
          <tr id="teamleadEmptyRow" class="hidden">
            <td colspan="9" class="py-12 text-center text-gray-500 text-xs">
              No orders found matching this category filter.
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

</main>

<!-- ── QA INSPECTION & REVISION MODAL ────────────────────────────── -->
<div id="qaModal" class="fixed inset-0 z-50 bg-dark/85 backdrop-blur-md flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 sm:p-8 max-w-2xl w-full border border-dark-border shadow-2xl space-y-6 relative bg-[#0E0E18]">
    <button type="button" class="btn-close-qa absolute top-5 right-5 text-gray-400 hover:text-white text-2xl font-bold">&times;</button>
    
    <div>
      <div class="section-tag mb-1.5">Quality Control Inspection</div>
      <h3 id="qaModalTitle" class="text-xl font-black text-white">Order Quality Inspection</h3>
      <p class="text-sm text-gray-300 font-medium mt-1">Inspect final output files against company quality standards before approving.</p>
    </div>

    <div class="p-4 rounded-2xl bg-dark/95 border border-dark-border space-y-2.5 text-sm font-mono">
      <div class="flex justify-between"><span class="text-gray-400">Editor:</span> <strong id="qaEditorName" class="text-white text-sm"></strong></div>
      <div class="flex justify-between"><span class="text-gray-400">Photos Count:</span> <strong id="qaImageCount" class="text-emerald-400 text-sm font-bold"></strong></div>
      <div class="pt-2 border-t border-dark-border">
        <span class="text-gray-400 block mb-1 text-xs font-mono">Output Path:</span>
        <strong id="qaStoragePath" class="text-gold break-all text-sm font-bold"></strong>
      </div>
    </div>

    <!-- QA Form -->
    <form method="POST" class="space-y-4">
      <?= csrfField() ?>
      <input type="hidden" name="action_qa_decision" value="1">
      <input type="hidden" name="order_id" id="qaOrderId" value="">

      <!-- Revision Form Fields (Toggled when revision clicked) -->
      <div id="revFields" class="space-y-3 hidden p-5 rounded-2xl bg-red-950/40 border border-red-500/50">
        <div>
          <label class="form-label text-sm font-bold text-red-300">Mistake / Error Category <span class="text-red-400">*</span></label>
          <select name="mistake_category" class="form-select w-full text-sm mt-1.5 bg-[#111118] text-white py-2 px-3 rounded-xl border border-red-500/30">
            <option value="Window Pull / Masking">Window Pull / Masking Glare</option>
            <option value="Exposure & White Balance">Exposure &amp; White Balance</option>
            <option value="Sky Replacement">Sky Replacement / Edges</option>
            <option value="Vertical Straightening">Vertical Straightening / Perspective</option>
            <option value="Object Removal Missed">Object Removal Missed</option>
            <option value="Color Cast / Over-saturation">Color Cast / Saturation</option>
            <option value="Client Instructions Missed">Client Custom Instructions Missed</option>
            <option value="Other">Other Adjustments</option>
          </select>
        </div>
        <div>
          <label class="form-label text-sm font-bold text-red-300">Revision Notes for Editor <span class="text-red-400">*</span></label>
          <textarea name="revision_instructions" id="revTextarea" rows="3"
                    placeholder="Specific instructions: e.g. Fix the window reflections in the master bedroom and warm up the living room..."
                    class="form-textarea w-full text-sm mt-1.5 bg-[#111118] text-white font-mono py-2.5 px-3 rounded-xl border border-red-500/30"></textarea>
        </div>
      </div>

      <!-- Action Buttons -->
      <div class="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3">
        <button type="button" id="toggleRevBtn" class="btn-toggle-rev btn-ghost w-full sm:w-auto py-3 px-5 text-sm font-bold border border-red-500/40 text-red-400 hover:bg-red-500/10 inline-flex items-center justify-center gap-2">
          <span>⚠️</span> <span id="revBtnText">Request Revision</span>
        </button>

        <button type="submit" name="decision" value="approve" id="approveBtn" class="btn-gold w-full sm:w-auto py-3 px-6 text-sm font-black shadow-glow inline-flex items-center justify-center gap-2">
          <span>✓</span> <span>Approve &amp; Forward to Supervisor</span>
        </button>

        <button type="submit" name="decision" value="revision" id="submitRevBtn" class="btn-gold w-full sm:w-auto py-3 px-6 text-sm font-black shadow-glow hidden bg-gradient-to-r from-red-600 to-amber-600 inline-flex items-center justify-center gap-2">
          <span>📤</span> <span>Send Revision to Editor</span>
        </button>
      </div>
    </form>
  </div>
</div>

<!-- GOD MODE DELETE MODAL -->
<div id="tlDeleteModal" class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 max-w-md w-full border border-red-500/50 shadow-2xl space-y-4">
    <div class="flex items-center gap-3">
      <div class="w-10 h-10 rounded-2xl bg-red-600/20 border border-red-500 flex items-center justify-center text-xl">🗑️</div>
      <div>
        <h3 class="text-base font-black text-white">Permanently Delete Order?</h3>
        <p class="text-xs text-gray-400">Removed from all queues, CRM, and server storage.</p>
      </div>
    </div>
    <div class="p-3.5 rounded-2xl bg-red-950/30 border border-red-800/50 text-xs text-red-200">
      Order: <strong id="tlDelTitle" class="text-white"></strong> &nbsp;(<span id="tlDelId" class="font-mono text-gold font-bold"></span>)
    </div>
    <div class="flex items-center justify-end gap-3 pt-2">
      <button type="button" class="btn-close-tldel btn-ghost py-2.5 px-4 text-xs font-bold">Cancel</button>
      <a id="tlDelConfirmBtn" href="#" class="py-2.5 px-5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs shadow-lg transition-all inline-flex items-center gap-1.5">
        🗑️ Yes, Delete
      </a>
    </div>
  </div>
</div>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
window.teamLeadOrders = <?= json_encode($myOrders, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?> || [];

document.addEventListener('DOMContentLoaded', function() {
  document.addEventListener('click', function(e) {
    const qaBtn = e.target.closest('.btn-open-qa');
    if (qaBtn) {
      e.preventDefault();
      const oid = qaBtn.getAttribute('data-order-id');
      openQAModalById(oid);
      return;
    }

    const closeBtn = e.target.closest('.btn-close-qa');
    if (closeBtn) {
      e.preventDefault();
      closeQAModal();
      return;
    }

    const revToggle = e.target.closest('.btn-toggle-rev');
    if (revToggle) {
      e.preventDefault();
      toggleRevisionMode();
      return;
    }

    const delBtn = e.target.closest('.btn-open-tldel');
    if (delBtn) {
      e.preventDefault();
      const oid = delBtn.getAttribute('data-order-id');
      const title = delBtn.getAttribute('data-order-title') || oid;
      openTLDeleteModal(oid, title);
      return;
    }

    const closeDel = e.target.closest('.btn-close-tldel');
    if (closeDel) {
      e.preventDefault();
      const m = document.getElementById('tlDeleteModal');
      if (m) m.classList.add('hidden');
      return;
    }
  });
});

function openQAModalById(orderId) {
  const order = window.teamLeadOrders.find(o => String(o.id) === String(orderId)) || { id: orderId };
  openQAModal(order);
}

function openQAModal(order) {
  if (!order) return;
  const m = document.getElementById('qaModal');
  if (!m) return;

  document.getElementById('qaOrderId').value = order.id || '';
  document.getElementById('qaModalTitle').innerText = 'Quality Inspection: ' + (order.id || '') + ' (' + (order.property_name || 'Property') + ')';
  document.getElementById('qaEditorName').innerText = order.assigned_editor_name || 'Photo Editor';
  document.getElementById('qaImageCount').innerText = (order.final_image_count || order.photo_count || 10) + ' Photos';
  document.getElementById('qaStoragePath').innerText = order.output_storage_path || order.delivery_url || order.input_storage_path || 'No output storage specified';
  
  // Reset revision fields
  document.getElementById('revFields').classList.add('hidden');
  document.getElementById('approveBtn').classList.remove('hidden');
  document.getElementById('submitRevBtn').classList.add('hidden');
  document.getElementById('revBtnText').innerText = 'Request Revision';
  document.getElementById('revTextarea').required = false;

  m.classList.remove('hidden');
}

function closeQAModal() {
  const m = document.getElementById('qaModal');
  if (m) m.classList.add('hidden');
}

function toggleRevisionMode() {
  const revFields = document.getElementById('revFields');
  const approveBtn = document.getElementById('approveBtn');
  const submitRevBtn = document.getElementById('submitRevBtn');
  const revTextarea = document.getElementById('revTextarea');
  const revBtnText = document.getElementById('revBtnText');

  if (revFields.classList.contains('hidden')) {
    revFields.classList.remove('hidden');
    approveBtn.classList.add('hidden');
    submitRevBtn.classList.remove('hidden');
    revTextarea.required = true;
    revBtnText.innerText = '← Cancel Revision';
  } else {
    revFields.classList.add('hidden');
    approveBtn.classList.remove('hidden');
    submitRevBtn.classList.add('hidden');
    revTextarea.required = false;
    revBtnText.innerText = 'Request Revision';
  }
}

function openTLDeleteModal(oid, title) {
  const delId = document.getElementById('tlDelId');
  const delTitle = document.getElementById('tlDelTitle');
  const delBtn = document.getElementById('tlDelConfirmBtn');
  const m = document.getElementById('tlDeleteModal');

  if (delId) delId.textContent = '#' + oid;
  if (delTitle) delTitle.textContent = title;
  if (m) m.classList.remove('hidden');
}

let currentTlCategory = '<?= htmlspecialchars($initialTlCat, ENT_QUOTES) ?>';

function setTeamleadCategory(cat) {
  currentTlCategory = cat;

  document.querySelectorAll('.tl-cat-btn').forEach(btn => {
    btn.className = 'tl-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-transparent text-gray-400 hover:text-white hover:bg-white/5';
    const badge = btn.querySelector('.tl-count-badge');
    if (badge) {
      badge.classList.remove('bg-black/30', 'text-black');
    }
  });

  const activeBtn = document.getElementById('tlCatBtn-' + cat);
  if (activeBtn) {
    if (cat === 'pending' || cat === 'free_trial') {
      activeBtn.className = 'tl-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-amber-500 text-black shadow-lg shadow-amber-500/20';
    } else if (cat === 'qa_review') {
      activeBtn.className = 'tl-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-purple-500 text-black shadow-lg shadow-purple-500/20';
    } else if (cat === 'revision') {
      activeBtn.className = 'tl-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-red-500 text-white shadow-lg shadow-red-500/20';
    } else if (cat === 'approved') {
      activeBtn.className = 'tl-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-emerald-500 text-black shadow-lg shadow-emerald-500/20';
    } else if (cat === 'editing' || cat === 'live_order') {
      activeBtn.className = 'tl-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-blue-500 text-white shadow-lg shadow-blue-500/20';
    } else {
      activeBtn.className = 'tl-cat-btn px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 bg-gold text-black shadow-lg shadow-gold/20';
    }
    const badge = activeBtn.querySelector('.tl-count-badge');
    if (badge) {
      badge.classList.add('bg-black/30', 'text-black');
    }
  }

  // Update URL without reload
  const url = new URL(window.location);
  url.searchParams.set('cat', cat);
  window.history.replaceState({}, '', url);

  filterTeamleadOrders();
}

function filterTeamleadOrders() {
  const query = (document.getElementById('teamleadSearchInput')?.value || '').toLowerCase().trim();
  const rows = document.querySelectorAll('#teamleadOrdersTable tbody tr.tl-order-row');
  let visibleCount = 0;

  rows.forEach(row => {
    const wfCat   = row.getAttribute('data-wf-cat') || '';
    const typeCat = row.getAttribute('data-type-cat') || '';
    const payCat  = row.getAttribute('data-pay-cat') || '';
    const text    = row.textContent.toLowerCase();

    let matchesCat = false;
    if (currentTlCategory === 'all') matchesCat = true;
    else if (currentTlCategory === wfCat) matchesCat = true;
    else if (currentTlCategory === typeCat) matchesCat = true;
    else if (currentTlCategory === payCat) matchesCat = true;

    const matchesQuery = !query || text.includes(query);

    if (matchesCat && matchesQuery) {
      row.style.display = '';
      visibleCount++;
    } else {
      row.style.display = 'none';
    }
  });

  const emptyRow = document.getElementById('teamleadEmptyRow');
  if (emptyRow) {
    emptyRow.style.display = (visibleCount === 0) ? '' : 'none';
  }
}

// Initial category filter trigger
if (currentTlCategory !== 'all') {
  setTeamleadCategory(currentTlCategory);
}
</script>

</body>
</html>
