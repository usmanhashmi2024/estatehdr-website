<?php
error_reporting(E_ALL & ~E_NOTICE);
@ini_set('display_errors', '1');

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/mail.php';

requireManagerOrAdmin();

// ── Fallback Helpers (Prevents any missing function errors on live server) ────
if (!function_exists('deleteLedgerEntry')) {
    function deleteLedgerEntry(string $entryId): bool {
        $file = defined('LEDGER_FILE') ? LEDGER_FILE : (DATA_PATH . 'ledger.json');
        if (!file_exists($file)) return false;
        $data = json_decode(@file_get_contents($file), true) ?: [];
        $filtered = array_values(array_filter($data, fn($e) => ($e['id'] ?? '') !== $entryId));
        return (bool)@file_put_contents($file, json_encode($filtered, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX);
    }
}

if (!function_exists('purgeLedger')) {
    function purgeLedger(): bool {
        $file = defined('LEDGER_FILE') ? LEDGER_FILE : (DATA_PATH . 'ledger.json');
        return (bool)@file_put_contents($file, json_encode([], JSON_PRETTY_PRINT), LOCK_EX);
    }
}

// ── Manual Sync / Reconcile Trigger (Fast, on-demand only) ───────────────────
if (isset($_GET['reconcile'])) {
    if (function_exists('reconcileAllOrdersLedger')) {
        $syncedCount = reconcileAllOrdersLedger();
        setFlash('success', "Order reconciliation complete. Synced {$syncedCount} delivered order(s) with financial ledger.");
    }
    header('Location: /admin/ledger.php');
    exit;
}

$allUsers     = getUsers();
$allOrders    = getAllOrders();
$financeStats = getGlobalFinancialStats();

$userMap = [];
foreach ($allUsers as $u) {
    $userMap[$u['id']] = $u;
}

$selectedClient = trim($_GET['client_id'] ?? '');
$prefillAmount  = trim($_GET['amount'] ?? '');
$prefillNotes   = trim($_GET['notes'] ?? $_GET['memo'] ?? '');
$prefillMethod  = trim($_GET['method'] ?? 'PayPal');
$prefillType    = trim($_GET['type'] ?? 'payment');

// ── Handle Action: Send Follow-up Reminder Email ─────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_balance_reminder'])) {
    verifyCsrf();
    $clientId    = trim($_POST['client_id'] ?? '');
    $clientEmail = trim($_POST['client_email'] ?? '');
    $clientName  = trim($_POST['client_name'] ?? '');
    $amountDue   = (float)($_POST['amount_due'] ?? 0.0);
    $customMsg   = trim($_POST['custom_message'] ?? '');
    $subject     = trim($_POST['subject'] ?? '') ?: 'Payment Reminder: Outstanding Balance for Estate HDR Services';

    if (empty($clientEmail) || !filter_var($clientEmail, FILTER_VALIDATE_EMAIL)) {
        setFlash('error', 'Invalid client email address.');
    } elseif ($amountDue <= 0) {
        setFlash('error', 'Outstanding balance must be greater than zero.');
    } else {
        $siteUrl = defined('SITE_URL') ? rtrim(SITE_URL, '/') : 'https://estatehdr.com';
        $invoiceUrl = $siteUrl . '/client/invoices.php';
        $formattedDue = '$' . number_format($amountDue, 2) . ' USD';

        $htmlBody = '<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>' . htmlspecialchars($subject) . '</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #0A0A0F; color: #FFFFFF; margin: 0; padding: 24px; }
    .container { max-width: 600px; margin: 0 auto; background: #111118; border: 1px solid #C9A84C; border-radius: 16px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.6); }
    .header { background: #07070A; padding: 28px 24px; text-align: center; border-bottom: 1px solid #1E1E2E; }
    .content { padding: 32px 28px; line-height: 1.6; }
    .due-card { background: rgba(201, 168, 76, 0.08); border: 1px solid rgba(201, 168, 76, 0.4); border-radius: 12px; padding: 20px; text-align: center; margin: 24px 0; }
    .due-amount { font-size: 32px; font-weight: 800; color: #C9A84C; margin: 6px 0; letter-spacing: -0.5px; }
    .btn { display: inline-block; background: #C9A84C; color: #0A0A0F !important; font-weight: 800; padding: 14px 32px; border-radius: 10px; text-decoration: none; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px; margin: 16px 0 8px 0; }
    .methods-card { background: #161622; border: 1px solid #1E1E2E; border-radius: 12px; padding: 18px 20px; margin: 20px 0; font-size: 13px; color: #D1D5DB; }
    .methods-card p { margin: 6px 0; }
    .footer { padding: 20px 24px; text-align: center; font-size: 12px; color: #6B7280; border-top: 1px solid #1E1E2E; background: #07070A; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1 style="color: #C9A84C; margin: 0; font-size: 22px; letter-spacing: 2px;">ESTATE HDR</h1>
      <p style="color: #9CA3AF; margin: 4px 0 0 0; font-size: 11px; text-transform: uppercase; letter-spacing: 1px;">Luxury Real Estate Photo Editing Studio</p>
    </div>
    <div class="content">
      <p style="font-size: 16px; margin-top: 0;">Dear <strong>' . htmlspecialchars($clientName ?: 'Valued Client') . '</strong>,</p>
      ' . (!empty($customMsg) ? '<div style="color: #E5E7EB; background: #161622; padding: 14px 18px; border-radius: 8px; border-left: 3px solid #C9A84C; margin-bottom: 20px; font-size: 14px;">' . nl2br(htmlspecialchars($customMsg)) . '</div>' : '<p style="color: #D1D5DB; font-size: 14px;">We hope you are delighted with your completed property photos! This is a friendly notification regarding your current outstanding balance with Estate HDR.</p>') . '

      <div class="due-card">
        <div style="font-size: 12px; text-transform: uppercase; color: #9CA3AF; letter-spacing: 1px; font-weight: 600;">Total Outstanding Balance Due</div>
        <div class="due-amount">' . $formattedDue . '</div>
        <div style="font-size: 12px; color: #9CA3AF;">Status: Awaiting Settlement</div>
      </div>

      <div class="methods-card">
        <strong style="color: #FFFFFF; font-size: 13px; display: block; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 0.5px;">Accepted Payment Methods:</strong>
        <p>🅿️ <strong>PayPal:</strong> Please remit to <code style="color: #C9A84C; background: #0A0A0F; padding: 2px 6px; border-radius: 4px;">billing@estatehdr.com</code></p>
        <p>🟠 <strong>Payoneer / 🟢 Wise:</strong> Direct transfer available upon request or client portal invoice</p>
        <p>🏛️ <strong>Bank Wire / Transfer:</strong> Include your Client Reference ID: <strong style="color: #C9A84C;">' . htmlspecialchars($clientId) . '</strong></p>
      </div>

      <div style="text-align: center; margin: 24px 0 12px 0;">
        <a href="' . htmlspecialchars($invoiceUrl) . '" class="btn">View Invoices &amp; Clear Balance</a>
      </div>

      <p style="font-size: 12px; color: #9CA3AF; text-align: center; margin-top: 20px;">
        If you have already settled this payment in the past 24 hours, please disregard this reminder.
      </p>
    </div>
    <div class="footer">
      &copy; ' . date('Y') . ' Estate HDR Studio. All rights reserved.<br>
      Billing &amp; Support: <a href="mailto:support@estatehdr.com" style="color: #C9A84C; text-decoration: none;">support@estatehdr.com</a>
    </div>
  </div>
</body>
</html>';

        $mailSent = sendEstateHdrMail($clientEmail, $subject, $htmlBody);

        if (function_exists('logAuditEvent')) {
            logAuditEvent('ledger.reminder_sent', $clientId, [
                'client_email' => $clientEmail,
                'client_name'  => $clientName,
                'amount_due'   => $amountDue,
                'mail_sent'    => $mailSent,
            ]);
        }

        if ($mailSent) {
            setFlash('success', '📧 Follow-up reminder email sent to ' . htmlspecialchars($clientEmail) . ' for ' . $formattedDue . '.');
        } else {
            setFlash('warning', 'Reminder processed, but mail delivery encountered an issue. Please verify email logs.');
        }
        header('Location: /admin/ledger.php?tab=pending');
        exit;
    }
}

// ── Handle Action: Delete Individual Ledger Entry ────────────────────────────
if (isset($_GET['delete_entry'])) {
    if (!isOwner()) {
        setFlash('error', 'Only the Owner/CEO can delete financial records.');
        header('Location: /admin/ledger.php');
        exit;
    }
    $delId = trim($_GET['delete_entry']);
    if (deleteLedgerEntry($delId)) {
        setFlash('success', 'Ledger transaction was permanently deleted.');
    } else {
        setFlash('error', 'Could not delete ledger transaction.');
    }
    header('Location: /admin/ledger.php' . ($selectedClient ? '?client_id=' . urlencode($selectedClient) : ''));
    exit;
}

// ── Handle Action: Reset All Ledger Invoices (Purge) ─────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['purge_all_ledger'])) {
    verifyCsrf();
    if (!isOwner()) {
        setFlash('error', 'Access Denied: Only Owner can reset financial ledger.');
        header('Location: /admin/ledger.php');
        exit;
    }
    purgeLedger();
    setFlash('success', 'All financial ledger transactions and invoices have been cleared to zero.');
    header('Location: /admin/ledger.php');
    exit;
}

// ── Handle Action: Edit Existing Ledger Entry ────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_ledger_entry'])) {
    verifyCsrf();
    $entryId  = trim($_POST['entry_id'] ?? '');
    $clientId = trim($_POST['user_id'] ?? '');
    $type     = trim($_POST['type'] ?? 'payment');
    $amount   = (float)($_POST['amount'] ?? 0.0);
    $method   = trim($_POST['payment_method'] ?? 'PayPal') ?: 'PayPal';
    $notes    = trim($_POST['notes'] ?? '');

    $ledgerList = getLedger();
    $updated = false;
    foreach ($ledgerList as &$item) {
        if (($item['id'] ?? '') === $entryId) {
            if ($clientId) $item['user_id'] = $clientId;
            $item['type']           = $type;
            $item['amount']         = max(0.0, $amount);
            $item['payment_method'] = $method;
            $item['notes']          = $notes;
            $item['updated_at']     = date('c');
            $updated = true;
            break;
        }
    }
    if ($updated && saveLedger($ledgerList)) {
        setFlash('success', 'Ledger transaction updated successfully.');
    } else {
        setFlash('error', 'Failed to update ledger entry.');
    }
    header('Location: /admin/ledger.php' . ($selectedClient ? '?client_id=' . urlencode($selectedClient) : ''));
    exit;
}

// ── Handle Action: Record New Payment or Charge Entry ────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_ledger_entry'])) {
    verifyCsrf();
    $clientId = trim($_POST['user_id'] ?? '');
    $type     = trim($_POST['type'] ?? 'payment');
    $amount   = (float)($_POST['amount'] ?? 0.0);
    $method   = trim($_POST['payment_method'] ?? 'PayPal') ?: 'PayPal';
    $notes    = trim($_POST['notes'] ?? '');

    if (empty($clientId) || !isset($userMap[$clientId])) {
        setFlash('error', 'Please select a valid client.');
    } elseif ($amount <= 0) {
        setFlash('error', 'Amount must be greater than zero.');
    } else {
        addLedgerEntry($clientId, null, $type, $amount, $method, $notes, 'admin');
        setFlash('success', ucfirst($type) . ' transaction of $' . number_format($amount, 2) . ' logged for ' . htmlspecialchars($userMap[$clientId]['name']));
        $targetTab = ($type === 'payment') ? 'completed' : 'pending';
        header('Location: /admin/ledger.php?tab=' . $targetTab . ($selectedClient ? '&client_id=' . urlencode($selectedClient) : ''));
        exit;
    }
}

// ── Group and Process Ledger Records ─────────────────────────────────────────
$allLedger = getLedger();

$clientLedgerMap   = [];
$completedPayments = [];

foreach ($allLedger as $entry) {
    $uid = $entry['user_id'] ?? '';
    if (!$uid) continue;
    if (!isset($clientLedgerMap[$uid])) {
        $clientLedgerMap[$uid] = [
            'user_id'       => $uid,
            'user'          => $userMap[$uid] ?? ['id' => $uid, 'name' => 'Client ' . substr($uid, 0, 8), 'email' => ''],
            'total_billed'  => 0.0,
            'total_paid'    => 0.0,
            'billed_count'  => 0,
            'paid_count'    => 0,
            'orders'        => [],
            'last_activity' => $entry['created_at'] ?? '',
        ];
    }

    $amt = (float)($entry['amount'] ?? 0.0);
    $type = $entry['type'] ?? 'payment';

    if ($type === 'billed') {
        $clientLedgerMap[$uid]['total_billed'] += $amt;
        $clientLedgerMap[$uid]['billed_count']++;
        if (!empty($entry['order_id'])) {
            $clientLedgerMap[$uid]['orders'][] = [
                'order_id'   => $entry['order_id'],
                'amount'     => $amt,
                'notes'      => $entry['notes'] ?? '',
                'created_at' => $entry['created_at'] ?? ''
            ];
        }
    } elseif ($type === 'payment') {
        $clientLedgerMap[$uid]['total_paid'] += $amt;
        $clientLedgerMap[$uid]['paid_count']++;
        $completedPayments[] = $entry;
    }

    if (strtotime($entry['created_at'] ?? '') > strtotime($clientLedgerMap[$uid]['last_activity'] ?? '')) {
        $clientLedgerMap[$uid]['last_activity'] = $entry['created_at'];
    }
}

// Identify pending balances vs settled clients
$pendingClients = [];
$settledClients = [];

foreach ($clientLedgerMap as $uid => $cData) {
    $due = round(max(0.0, $cData['total_billed'] - $cData['total_paid']), 2);
    $credit = round(max(0.0, $cData['total_paid'] - $cData['total_billed']), 2);
    $cData['due'] = $due;
    $cData['credit'] = $credit;

    if ($due > 0.009) {
        $pendingClients[] = $cData;
    } else {
        $settledClients[] = $cData;
    }
}

// Sort pending clients by highest amount due first
usort($pendingClients, fn($a, $b) => $b['due'] <=> $a['due']);

// Sort completed payments newest first
usort($completedPayments, fn($a, $b) => strtotime($b['created_at'] ?? '1970-01-01') <=> strtotime($a['created_at'] ?? '1970-01-01'));

// Filter raw ledger if client filter is selected
$rawLedger = $allLedger;
if ($selectedClient) {
    $rawLedger = array_values(array_filter($rawLedger, fn($e) => ($e['user_id'] ?? '') === $selectedClient));
}

// Determine active tab
$activeTab = trim($_GET['tab'] ?? '');
if (!in_array($activeTab, ['pending', 'completed', 'audit'])) {
    $activeTab = (!empty($pendingClients)) ? 'pending' : 'completed';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Financial Ledger &amp; Payments — Estate HDR Admin</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-[#0A0A0F] text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8 space-y-6">

  <!-- Breadcrumbs & Quick Top Actions -->
  <div class="flex flex-wrap items-center justify-between gap-3">
    <a href="/admin/" class="btn-ghost py-2 px-4 text-xs font-bold inline-flex items-center gap-2 border border-[#1E1E2E] hover:border-gold rounded-xl transition-all">
      <span>←</span> <span>Back to Dashboard</span>
    </a>

    <div class="flex items-center gap-2.5">
      <a href="/admin/ledger.php?reconcile=1" class="py-2 px-4 rounded-xl bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 border border-blue-500/30 text-xs font-bold shadow-lg transition-all inline-flex items-center gap-1.5" title="Audit and synchronize billed amounts with delivered orders">
        <span>🔄</span> <span>Sync Delivered Orders</span>
      </a>

      <button type="button" onclick="scrollToPaymentForm()" class="btn-gold py-2 px-4 text-xs font-bold inline-flex items-center gap-1.5 rounded-xl shadow-glow">
        <span>💰</span> <span>Record Payment</span>
      </button>

      <?php if (isOwner()): ?>
        <button type="button" onclick="openPurgeLedgerModal()" class="py-2 px-4 rounded-xl bg-red-600/20 hover:bg-red-600/30 text-red-300 border border-red-500/40 text-xs font-bold shadow-lg transition-all inline-flex items-center gap-1.5">
          <span>🧹</span> <span>Reset Ledger</span>
        </button>
      <?php endif; ?>
    </div>
  </div>

  <?= renderFlash() ?>

  <!-- Page Header -->
  <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
    <div>
      <h1 class="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-3">
        <span>FINANCIAL LEDGER &amp; PAYMENTS</span>
      </h1>
      <p class="text-gray-400 text-xs mt-1">Manage pending client dues, track cleared PayPal / Payoneer / Wise payments, and issue follow-up reminder emails.</p>
    </div>
  </div>

  <!-- Key Metrics KPI Cards -->
  <div class="grid grid-cols-1 sm:grid-cols-3 gap-5">
    <div class="glass-card rounded-2xl p-6 border border-dark-border bg-gradient-to-br from-[#111118] to-[#161622]">
      <div class="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 flex items-center justify-between">
        <span>Total Billed Revenue</span>
        <span class="text-gray-500">📈</span>
      </div>
      <div class="text-3xl font-black text-white font-mono">$<?= number_format($financeStats['total_billed'], 2) ?></div>
      <div class="text-xs text-gray-500 mt-1">Across all completed photo editing deliveries</div>
    </div>

    <div class="glass-card rounded-2xl p-6 border border-green-500/30 bg-green-500/5">
      <div class="text-xs font-semibold text-green-400 uppercase tracking-wider mb-2 flex items-center justify-between">
        <span>Total Payments Received</span>
        <span class="text-green-500">✅</span>
      </div>
      <div class="text-3xl font-black text-green-400 font-mono">$<?= number_format($financeStats['total_collected'], 2) ?></div>
      <div class="text-xs text-gray-500 mt-1"><?= count($completedPayments) ?> cleared transaction(s) recorded</div>
    </div>

    <div class="glass-card rounded-2xl p-6 border border-amber-500/40 bg-amber-500/5">
      <div class="text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2 flex items-center justify-between">
        <span>Total Pending Balance (Dues)</span>
        <span class="text-amber-500">⏳</span>
      </div>
      <div class="text-3xl font-black text-amber-400 font-mono">$<?= number_format($financeStats['total_outstanding'], 2) ?></div>
      <div class="text-xs text-amber-300/80 mt-1"><?= count($pendingClients) ?> client(s) with uncollected dues</div>
    </div>
  </div>

  <!-- Interactive Simplified Tabs Bar -->
  <div class="glass-card rounded-2xl border border-dark-border p-2">
    <div class="flex flex-wrap items-center gap-2">
      <button type="button" onclick="switchLedgerTab('pending')" id="tabBtn-pending" class="px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 <?= $activeTab === 'pending' ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/20' : 'bg-transparent text-gray-400 hover:text-white hover:bg-white/5' ?>">
        <span>⏳ Pending Balances (Unpaid Dues)</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black <?= $activeTab === 'pending' ? 'bg-black/30 text-black' : 'bg-amber-500/20 text-amber-300' ?>">
          <?= count($pendingClients) ?>
        </span>
      </button>

      <button type="button" onclick="switchLedgerTab('completed')" id="tabBtn-completed" class="px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 <?= $activeTab === 'completed' ? 'bg-green-500 text-black shadow-lg shadow-green-500/20' : 'bg-transparent text-gray-400 hover:text-white hover:bg-white/5' ?>">
        <span>✅ Received / Completed Payments</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black <?= $activeTab === 'completed' ? 'bg-black/30 text-black' : 'bg-green-500/20 text-green-300' ?>">
          <?= count($completedPayments) ?>
        </span>
      </button>

      <button type="button" onclick="switchLedgerTab('audit')" id="tabBtn-audit" class="px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 <?= $activeTab === 'audit' ? 'bg-gold text-black shadow-lg shadow-gold/20' : 'bg-transparent text-gray-400 hover:text-white hover:bg-white/5' ?>">
        <span>📋 Full Itemized Audit Trail</span>
        <span class="px-2 py-0.5 rounded-full text-[10px] font-black <?= $activeTab === 'audit' ? 'bg-black/30 text-black' : 'bg-white/10 text-gray-300' ?>">
          <?= count($rawLedger) ?>
        </span>
      </button>
    </div>
  </div>

  <!-- ═══════════════════════════════════════════════════════════════════════ -->
  <!-- TAB 1: PENDING BALANCES (UNPAID DUES)                                    -->
  <!-- ═══════════════════════════════════════════════════════════════════════ -->
  <div id="tabContent-pending" class="<?= $activeTab === 'pending' ? '' : 'hidden' ?> space-y-4">
    <div class="glass-card rounded-2xl overflow-hidden border border-amber-500/30 shadow-xl">
      <div class="p-6 border-b border-dark-border flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-amber-500/5">
        <div>
          <h2 class="text-base font-black text-amber-400 flex items-center gap-2">
            <span>⏳</span> <span>Clients With Outstanding Balances &amp; Unpaid Invoices</span>
          </h2>
          <p class="text-xs text-gray-400 mt-0.5">Click <strong>Follow-up Reminder</strong> to email the client with payment instructions, or <strong>Record Payment</strong> once received.</p>
        </div>
        <div class="text-xs font-mono text-amber-300/80 bg-amber-950/40 border border-amber-500/30 px-3 py-1.5 rounded-xl">
          Total Due: <strong class="text-white">$<?= number_format($financeStats['total_outstanding'], 2) ?> USD</strong>
        </div>
      </div>

      <?php if (empty($pendingClients)): ?>
        <div class="p-16 text-center space-y-3">
          <div class="text-4xl">🎉</div>
          <div class="text-base font-bold text-white">All Client Balances Are Fully Settled!</div>
          <p class="text-xs text-gray-400 max-w-md mx-auto">There are currently no outstanding unpaid balances across your clients. All delivered orders have been reconciled and cleared.</p>
        </div>
      <?php else: ?>
        <div class="overflow-x-auto">
          <table class="dashboard-table w-full text-xs text-left">
            <thead>
              <tr class="border-b border-dark-border text-gray-400 uppercase text-[11px] tracking-wider">
                <th class="py-3 px-4">Client Details</th>
                <th class="py-3 px-4">Total Invoiced</th>
                <th class="py-3 px-4">Total Paid</th>
                <th class="py-3 px-4">Current Due ($)</th>
                <th class="py-3 px-4">Recent Delivered Orders</th>
                <th class="py-3 px-4 text-right">Quick Follow-up Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-dark-border">
              <?php foreach ($pendingClients as $item):
                $cli = $item['user'];
                $clientName  = $cli['name'] ?? 'Client ' . $item['user_id'];
                $clientEmail = $cli['email'] ?? '';
              ?>
              <tr class="hover:bg-white/[0.02] transition-colors">
                <!-- Client Details -->
                <td class="py-4 px-4">
                  <div class="text-white font-black text-sm"><?= htmlspecialchars($clientName) ?></div>
                  <div class="text-gray-400 font-mono text-[11px] mt-0.5"><?= htmlspecialchars($clientEmail ?: 'No email listed') ?></div>
                  <div class="inline-block mt-1 text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 border border-white/10 text-gray-400">
                    ID: <?= htmlspecialchars($item['user_id']) ?>
                  </div>
                </td>

                <!-- Invoiced -->
                <td class="py-4 px-4 font-mono font-bold text-gray-200">
                  $<?= number_format($item['total_billed'], 2) ?>
                  <div class="text-[10px] text-gray-500 font-normal"><?= $item['billed_count'] ?> order(s) billed</div>
                </td>

                <!-- Paid -->
                <td class="py-4 px-4 font-mono font-bold text-green-400">
                  $<?= number_format($item['total_paid'], 2) ?>
                  <div class="text-[10px] text-gray-500 font-normal"><?= $item['paid_count'] ?> payment(s) received</div>
                </td>

                <!-- Current Due Highlight -->
                <td class="py-4 px-4">
                  <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-500/15 border border-amber-500/40 text-amber-400 font-mono text-sm font-black shadow-sm">
                    <span>$<?= number_format($item['due'], 2) ?></span>
                    <span class="text-[10px] font-sans font-bold uppercase tracking-wider text-amber-300">DUE</span>
                  </div>
                </td>

                <!-- Orders Reference -->
                <td class="py-4 px-4">
                  <?php if (!empty($item['orders'])): ?>
                    <div class="flex flex-wrap gap-1.5 max-w-xs">
                      <?php foreach (array_slice($item['orders'], 0, 3) as $ord): ?>
                        <a href="/admin/order-view.php?id=<?= urlencode($ord['order_id']) ?>" class="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-mono bg-blue-500/10 text-blue-300 border border-blue-500/20 hover:border-gold hover:text-gold transition-colors" title="<?= htmlspecialchars($ord['notes']) ?>">
                          <span>📦</span> <?= htmlspecialchars($ord['order_id']) ?>
                        </a>
                      <?php endforeach; ?>
                      <?php if (count($item['orders']) > 3): ?>
                        <span class="text-[10px] text-gray-500 self-center">+<?= count($item['orders']) - 3 ?> more</span>
                      <?php endif; ?>
                    </div>
                  <?php else: ?>
                    <span class="text-gray-500 text-xs font-mono">—</span>
                  <?php endif; ?>
                </td>

                <!-- Action Buttons -->
                <td class="py-4 px-4 text-right whitespace-nowrap">
                  <div class="flex items-center justify-end gap-2">
                    <!-- Follow-up Reminder Modal Trigger -->
                    <button type="button" 
                      onclick="openSendReminderModal('<?= htmlspecialchars($item['user_id'], ENT_QUOTES) ?>', '<?= htmlspecialchars($clientName, ENT_QUOTES) ?>', '<?= htmlspecialchars($clientEmail, ENT_QUOTES) ?>', <?= (float)$item['due'] ?>)" 
                      class="py-1.5 px-3 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 font-bold text-xs shadow-md transition-all inline-flex items-center gap-1.5">
                      <span>📧</span> <span>Follow-up Reminder</span>
                    </button>

                    <!-- Prefill Payment Form Button -->
                    <button type="button" 
                      onclick="prefillPaymentForm('<?= htmlspecialchars($item['user_id'], ENT_QUOTES) ?>', <?= (float)$item['due'] ?>, 'Clearance for outstanding balance (<?= htmlspecialchars($clientName, ENT_QUOTES) ?>)')" 
                      class="py-1.5 px-3 rounded-xl bg-green-500/20 hover:bg-green-500/30 text-green-300 border border-green-500/40 font-bold text-xs shadow-md transition-all inline-flex items-center gap-1.5">
                      <span>💰</span> <span>Record Payment</span>
                    </button>

                    <!-- Client Invoices Link -->
                    <a href="/admin/orders.php?client_id=<?= urlencode($item['user_id']) ?>" class="btn-ghost py-1.5 px-2.5 text-xs text-gray-400 hover:text-white border border-[#1E1E2E] rounded-xl" title="View all orders for this client">
                      <span>Orders ↗</span>
                    </a>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- ═══════════════════════════════════════════════════════════════════════ -->
  <!-- TAB 2: COMPLETED / RECEIVED PAYMENTS                                    -->
  <!-- ═══════════════════════════════════════════════════════════════════════ -->
  <div id="tabContent-completed" class="<?= $activeTab === 'completed' ? '' : 'hidden' ?> space-y-4">
    <div class="glass-card rounded-2xl overflow-hidden border border-green-500/30 shadow-xl">
      <div class="p-6 border-b border-dark-border flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-green-500/5">
        <div>
          <h2 class="text-base font-black text-green-400 flex items-center gap-2">
            <span>✅</span> <span>Cleared Payments Received &amp; Client Credits</span>
          </h2>
          <p class="text-xs text-gray-400 mt-0.5">Chronological record of all settled client wires, PayPal transfers, Payoneer invoices, and adjustments.</p>
        </div>
        <div class="text-xs font-mono text-green-300/90 bg-green-950/40 border border-green-500/30 px-3 py-1.5 rounded-xl">
          Total Collected: <strong class="text-white">$<?= number_format($financeStats['total_collected'], 2) ?> USD</strong>
        </div>
      </div>

      <?php if (empty($completedPayments)): ?>
        <div class="p-16 text-center space-y-3">
          <div class="text-4xl">💳</div>
          <div class="text-base font-bold text-white">No Received Payments Recorded Yet</div>
          <p class="text-xs text-gray-400 max-w-md mx-auto">When clients remit payments via PayPal, Payoneer, Wise, or Bank Wire, record them using the form below to clear client dues.</p>
        </div>
      <?php else: ?>
        <div class="overflow-x-auto">
          <table class="dashboard-table w-full text-xs text-left">
            <thead>
              <tr class="border-b border-dark-border text-gray-400 uppercase text-[11px] tracking-wider">
                <th class="py-3 px-4">Date Cleared</th>
                <th class="py-3 px-4">Client Name</th>
                <th class="py-3 px-4">Amount Cleared ($)</th>
                <th class="py-3 px-4">Payment Method</th>
                <th class="py-3 px-4">Reference Memo / Notes</th>
                <th class="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-dark-border">
              <?php foreach ($completedPayments as $item):
                $c = $userMap[$item['user_id'] ?? ''] ?? null;
                $amt = (float)($item['amount'] ?? 0.0);
                $pm  = trim($item['payment_method'] ?? 'PayPal');
              ?>
              <tr class="hover:bg-white/[0.02] transition-colors">
                <td class="py-4 px-4 text-gray-400 font-mono">
                  <?= !empty($item['created_at']) ? date('M j, Y g:i A', strtotime($item['created_at'])) : '—' ?>
                </td>
                <td class="py-4 px-4">
                  <div class="text-white font-bold text-sm"><?= htmlspecialchars($c['name'] ?? ('Client ' . ($item['user_id'] ?? ''))) ?></div>
                  <div class="text-gray-500 font-mono text-[11px]"><?= htmlspecialchars($c['email'] ?? ($item['user_id'] ?? '')) ?></div>
                </td>
                <td class="py-4 px-4 font-mono text-base font-black text-green-400">
                  +$<?= number_format($amt, 2) ?>
                </td>
                <td class="py-4 px-4">
                  <?php if (stripos($pm, 'paypal') !== false): ?>
                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold bg-sky-500/15 text-sky-400 border border-sky-500/30">
                      <span>🅿️</span> <span>PayPal</span>
                    </span>
                  <?php elseif (stripos($pm, 'payoneer') !== false): ?>
                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30">
                      <span>🟠</span> <span>Payoneer</span>
                    </span>
                  <?php elseif (stripos($pm, 'wise') !== false): ?>
                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                      <span>🟢</span> <span>Wise</span>
                    </span>
                  <?php elseif (stripos($pm, 'bank') !== false || stripos($pm, 'wire') !== false || stripos($pm, 'transfer') !== false): ?>
                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold bg-indigo-500/15 text-indigo-400 border border-indigo-500/30">
                      <span>🏛️</span> <span><?= htmlspecialchars($pm ?: 'Bank Transfer') ?></span>
                    </span>
                  <?php elseif (stripos($pm, 'stripe') !== false || stripos($pm, 'card') !== false): ?>
                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold bg-purple-500/15 text-purple-400 border border-purple-500/30">
                      <span>💳</span> <span><?= htmlspecialchars($pm) ?></span>
                    </span>
                  <?php elseif (stripos($pm, 'cash') !== false || stripos($pm, 'cheque') !== false): ?>
                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold bg-teal-500/15 text-teal-400 border border-teal-500/30">
                      <span>💵</span> <span><?= htmlspecialchars($pm) ?></span>
                    </span>
                  <?php else: ?>
                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold bg-white/10 text-gray-300 border border-white/20">
                      <span>⚙️</span> <span><?= htmlspecialchars($pm ?: 'Direct Credit') ?></span>
                    </span>
                  <?php endif; ?>
                </td>
                <td class="py-4 px-4">
                  <div class="text-gray-300 font-medium"><?= htmlspecialchars($item['notes'] ?: 'Payment received') ?></div>
                  <div class="text-[11px] text-gray-500 font-mono mt-0.5">Recorded by: <?= htmlspecialchars($item['created_by'] ?? 'admin') ?></div>
                </td>
                <td class="py-4 px-4 text-right whitespace-nowrap">
                  <div class="flex items-center justify-end gap-1.5">
                    <button type="button" onclick='openEditLedgerModal(<?= json_encode($item, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>)' class="btn-ghost py-1 px-2.5 text-xs font-bold text-blue-400 border border-blue-500/30 hover:bg-blue-500/10 rounded-lg" title="Edit Payment Record">
                      ✏️ Edit
                    </button>
                    <?php if (isOwner()): ?>
                      <button type="button" onclick="openDeleteLedgerModal('<?= htmlspecialchars($item['id'] ?? '', ENT_QUOTES) ?>', '$<?= number_format($amt, 2) ?> (Payment)')" class="btn-ghost py-1 px-2.5 text-xs font-bold text-red-400 border border-red-500/30 hover:bg-red-500/10 rounded-lg" title="Delete Payment Record">
                        🗑️ Delete
                      </button>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- ═══════════════════════════════════════════════════════════════════════ -->
  <!-- TAB 3: FULL ITEMIZED AUDIT TRAIL                                        -->
  <!-- ═══════════════════════════════════════════════════════════════════════ -->
  <div id="tabContent-audit" class="<?= $activeTab === 'audit' ? '' : 'hidden' ?> space-y-4">
    <div class="glass-card rounded-2xl overflow-hidden border border-dark-border shadow-xl">
      <div class="p-6 border-b border-dark-border flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 class="text-base font-black text-white flex items-center gap-2">
            <span>📋</span> <span>Complete Financial Ledger Audit Trail</span>
          </h2>
          <span class="text-xs text-gray-500 font-mono"><?= count($rawLedger) ?> itemized transaction(s) recorded</span>
        </div>

        <!-- Filter by Client -->
        <form method="GET" class="flex items-center gap-2">
          <input type="hidden" name="tab" value="audit">
          <select name="client_id" class="form-select text-xs py-1.5 bg-[#161622]" onchange="this.form.submit()">
            <option value="">All Clients (Full Ledger)</option>
            <?php foreach ($allUsers as $u): $sel = ($selectedClient === $u['id']) ? 'selected' : ''; ?>
            <option value="<?= $u['id'] ?>" <?= $sel ?>><?= htmlspecialchars($u['name']) ?> (<?= $u['id'] ?>)</option>
            <?php endforeach; ?>
          </select>
          <?php if ($selectedClient): ?>
            <a href="/admin/ledger.php?tab=audit" class="btn-ghost py-1.5 px-3 text-xs">&times; Reset Filter</a>
          <?php endif; ?>
        </form>
      </div>

      <?php if (empty($rawLedger)): ?>
        <div class="p-16 text-center text-gray-500 text-sm">
          No ledger transactions match this filter.
        </div>
      <?php else: ?>
        <div class="overflow-x-auto">
          <table class="dashboard-table w-full text-xs text-left">
            <thead>
              <tr class="border-b border-dark-border text-gray-400 uppercase text-[11px] tracking-wider">
                <th class="py-3 px-4">Date</th>
                <th class="py-3 px-4">Client</th>
                <th class="py-3 px-4">Type</th>
                <th class="py-3 px-4">Description &amp; Reference</th>
                <th class="py-3 px-4">Method</th>
                <th class="py-3 px-4">Amount ($)</th>
                <th class="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-dark-border">
              <?php foreach ($rawLedger as $item): 
                $c = $userMap[$item['user_id'] ?? ''] ?? null;
                $amt = (float)($item['amount'] ?? 0.0);
                $type = $item['type'] ?? 'payment';
              ?>
              <tr class="hover:bg-white/[0.02] transition-colors">
                <td class="py-3.5 px-4 text-gray-400 font-mono"><?= !empty($item['created_at']) ? date('M j, Y g:i A', strtotime($item['created_at'])) : '—' ?></td>
                <td class="py-3.5 px-4">
                  <div class="text-white font-bold"><?= htmlspecialchars($c['name'] ?? 'Client') ?></div>
                  <div class="text-gray-500 font-mono text-[11px]"><?= htmlspecialchars($c['email'] ?? ($item['user_id'] ?? '')) ?></div>
                </td>
                <td class="py-3.5 px-4">
                  <?php if ($type === 'billed'): ?>
                    <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-bold bg-red-500/10 text-red-400 border border-red-500/20">
                      CHARGE (Billed)
                    </span>
                  <?php else: ?>
                    <span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-bold bg-green-500/10 text-green-400 border border-green-500/20">
                      PAYMENT (Cleared)
                    </span>
                  <?php endif; ?>
                </td>
                <td class="py-3.5 px-4">
                  <div class="text-gray-200"><?= htmlspecialchars($item['notes'] ?: '—') ?></div>
                  <?php if (!empty($item['order_id'])): ?>
                    <a href="/admin/order-view.php?id=<?= urlencode($item['order_id']) ?>" class="text-[11px] text-gold hover:underline font-mono inline-flex items-center gap-1 mt-0.5">
                      <span>📦</span> <span>Order #<?= strtoupper(substr($item['order_id'], 0, 8)) ?> ↗</span>
                    </a>
                  <?php endif; ?>
                </td>
                <td class="py-3.5 px-4">
                  <span class="text-xs text-gray-300 font-medium">
                    <?= htmlspecialchars($item['payment_method'] ?? 'PayPal') ?>
                  </span>
                </td>
                <td class="py-3.5 px-4 font-mono text-sm font-black <?= $type === 'billed' ? 'text-white' : 'text-green-400' ?>">
                  <?= $type === 'billed' ? '+' : '-' ?>$<?= number_format($amt, 2) ?>
                </td>
                <td class="py-3.5 px-4 text-right whitespace-nowrap">
                  <div class="flex items-center justify-end gap-1.5">
                    <button type="button" onclick='openEditLedgerModal(<?= json_encode($item, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>)' class="btn-ghost py-1 px-2 text-xs font-bold text-blue-400 border border-blue-500/30 hover:bg-blue-500/10 rounded-lg">
                      ✏️ Edit
                    </button>
                    <?php if (isOwner()): ?>
                      <button type="button" onclick="openDeleteLedgerModal('<?= htmlspecialchars($item['id'] ?? '', ENT_QUOTES) ?>', '$<?= number_format($amt, 2) ?> (<?= htmlspecialchars($type, ENT_QUOTES) ?>)')" class="btn-ghost py-1 px-2 text-xs font-bold text-red-400 border border-red-500/30 hover:bg-red-500/10 rounded-lg">
                        🗑️ Delete
                      </button>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- ═══════════════════════════════════════════════════════════════════════ -->
  <!-- FORM: RECORD MANUAL PAYMENT / INVOICE ADJUSTMENT                        -->
  <!-- ═══════════════════════════════════════════════════════════════════════ -->
  <div id="recordPaymentCard" class="glass-card rounded-2xl p-6 border border-gold/30 shadow-2xl transition-all">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4 border-b border-dark-border pb-3">
      <div>
        <h3 class="text-sm font-black text-gold uppercase tracking-wider flex items-center gap-2">
          <span>💰</span> <span>Record Manual Payment / Invoice Adjustment</span>
        </h3>
        <p class="text-gray-400 text-xs mt-0.5">Credit payments received via PayPal, Payoneer, Wise, Bank Wire, or log custom charges.</p>
      </div>
      <span class="text-[11px] font-mono text-gray-400 bg-white/5 border border-white/10 px-2.5 py-1 rounded-lg">
        Admin Ledger Accounting
      </span>
    </div>

    <form method="POST" action="/admin/ledger.php" class="grid grid-cols-1 sm:grid-cols-12 gap-4 items-end">
      <?= csrfField() ?>
      <input type="hidden" name="create_ledger_entry" value="1">

      <!-- Client Selection -->
      <div class="sm:col-span-3">
        <label class="form-label text-xs font-bold text-gray-300">Client <span class="text-red-400">*</span></label>
        <select name="user_id" id="manualPaymentUserId" class="form-select text-xs py-2 bg-[#161622] border-dark-border w-full rounded-xl" required>
          <option value="">— Select client —</option>
          <?php foreach ($allUsers as $u): $sel = ($selectedClient === $u['id']) ? 'selected' : ''; ?>
          <option value="<?= $u['id'] ?>" <?= $sel ?>><?= htmlspecialchars($u['name']) ?> (<?= $u['id'] ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>

      <!-- Type -->
      <div class="sm:col-span-2">
        <label class="form-label text-xs font-bold text-gray-300">Transaction Type</label>
        <select name="type" id="manualPaymentType" class="form-select text-xs py-2 bg-[#161622] border-dark-border w-full rounded-xl font-bold">
          <option value="payment" <?= $prefillType === 'payment' ? 'selected' : '' ?>>PAYMENT (Credit Balance)</option>
          <option value="billed" <?= $prefillType === 'billed' ? 'selected' : '' ?>>CHARGE (Debit / Billed)</option>
        </select>
      </div>

      <!-- Amount -->
      <div class="sm:col-span-2">
        <label class="form-label text-xs font-bold text-gray-300">Amount ($ USD) <span class="text-red-400">*</span></label>
        <input type="number" step="0.01" min="0.01" name="amount" id="manualPaymentAmount" value="<?= htmlspecialchars($prefillAmount) ?>" class="form-input text-xs py-2 font-mono bg-[#161622] border-dark-border w-full rounded-xl" placeholder="50.00" required>
      </div>

      <!-- Payment Method -->
      <div class="sm:col-span-2">
        <label class="form-label text-xs font-bold text-gray-300">Payment Method</label>
        <select name="payment_method" id="manualPaymentMethod" class="form-select text-xs py-2 bg-[#161622] border-dark-border w-full rounded-xl font-semibold text-white">
          <option value="PayPal" <?= $prefillMethod === 'PayPal' ? 'selected' : '' ?>>🅿️ PayPal (Default)</option>
          <option value="Payoneer" <?= $prefillMethod === 'Payoneer' ? 'selected' : '' ?>>🟠 Payoneer</option>
          <option value="Wise" <?= $prefillMethod === 'Wise' ? 'selected' : '' ?>>🟢 Wise (TransferWise)</option>
          <option value="Bank Transfer" <?= in_array($prefillMethod, ['Bank Transfer', 'Bank Wire']) ? 'selected' : '' ?>>🏛️ Bank Transfer / Wire</option>
          <option value="Stripe / Card" <?= in_array($prefillMethod, ['Stripe / Card', 'Stripe Invoice', 'Credit Card']) ? 'selected' : '' ?>>💳 Stripe / Card</option>
          <option value="Direct Cash" <?= in_array($prefillMethod, ['Direct Cash', 'Cash / Cheque']) ? 'selected' : '' ?>>💵 Direct Cash / Cheque</option>
          <option value="Manual Adjustment" <?= $prefillMethod === 'Manual Adjustment' ? 'selected' : '' ?>>⚙️ Manual Adjustment</option>
        </select>
      </div>

      <!-- Reference / Notes -->
      <div class="sm:col-span-3">
        <label class="form-label text-xs font-bold text-gray-300">Reference / Memo</label>
        <input type="text" name="notes" id="manualPaymentNotes" value="<?= htmlspecialchars($prefillNotes) ?>" class="form-input text-xs py-2 bg-[#161622] border-dark-border w-full rounded-xl" placeholder="e.g. PayPal Transaction #94821">
      </div>

      <div class="sm:col-span-12 pt-2">
        <button type="submit" class="btn-gold py-2.5 px-6 text-xs font-black shadow-glow w-full sm:w-auto rounded-xl flex items-center justify-center gap-2">
          <span>✓</span> <span>Record &amp; Clear Ledger Transaction</span>
        </button>
      </div>
    </form>
  </div>

</main>

<!-- ── MODAL 1: FOLLOW-UP REMINDER EMAIL ──────────────────────────────── -->
<div id="sendReminderModal" class="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 sm:p-8 max-w-lg w-full border border-amber-500/50 shadow-2xl space-y-5 animate-in fade-in duration-200">
    <div class="flex items-center justify-between border-b border-dark-border pb-4">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 text-lg">
          📧
        </div>
        <div>
          <h3 class="text-base font-black text-white">Send Payment Follow-up Reminder</h3>
          <p class="text-xs text-gray-400">Direct luxury branded email dispatch to client.</p>
        </div>
      </div>
      <button type="button" onclick="closeSendReminderModal()" class="text-gray-400 hover:text-white text-2xl font-light leading-none">&times;</button>
    </div>

    <form method="POST" action="/admin/ledger.php" class="space-y-4">
      <?= csrfField() ?>
      <input type="hidden" name="send_balance_reminder" value="1">
      <input type="hidden" name="client_id" id="reminderClientId">

      <!-- Client Target Box -->
      <div class="p-3.5 rounded-2xl bg-[#161622] border border-[#1E1E2E] flex items-center justify-between">
        <div>
          <div class="text-xs font-bold text-white" id="reminderClientNameDisplay">Client Name</div>
          <div class="text-[11px] text-gray-400 font-mono" id="reminderClientEmailDisplay">client@email.com</div>
        </div>
        <div class="text-right">
          <div class="text-[10px] text-gray-400 uppercase tracking-wider">Amount Due</div>
          <div class="text-base font-black text-amber-400 font-mono" id="reminderAmountDisplay">$0.00 USD</div>
        </div>
      </div>

      <div>
        <label class="form-label text-xs font-bold text-gray-300">Recipient Email Address</label>
        <input type="email" name="client_email" id="reminderClientEmail" class="form-input text-xs py-2 bg-[#161622] border-dark-border w-full rounded-xl font-mono" required>
      </div>

      <input type="hidden" name="client_name" id="reminderClientName">
      <input type="hidden" name="amount_due" id="reminderAmountDue">

      <div>
        <label class="form-label text-xs font-bold text-gray-300">Email Subject Line</label>
        <input type="text" name="subject" id="reminderSubject" class="form-input text-xs py-2 bg-[#161622] border-dark-border w-full rounded-xl font-medium" value="Payment Reminder: Outstanding Balance for Estate HDR Services" required>
      </div>

      <div>
        <label class="form-label text-xs font-bold text-gray-300">Personal Note / Message to Client</label>
        <textarea name="custom_message" id="reminderMessage" rows="4" class="form-textarea text-xs py-2 bg-[#161622] border-dark-border w-full rounded-xl leading-relaxed" placeholder="Type personal note or leave blank for official standard template..."></textarea>
      </div>

      <div class="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-300 flex items-start gap-2">
        <span class="text-sm">💡</span>
        <span>The email will automatically feature the official Estate HDR gold letterhead, clear payment buttons, and direct instructions for PayPal (<code>billing@estatehdr.com</code>), Payoneer, Wise, and Bank Wire.</span>
      </div>

      <div class="flex items-center justify-end gap-3 pt-3 border-t border-dark-border">
        <button type="button" onclick="closeSendReminderModal()" class="btn-ghost py-2.5 px-4 text-xs font-bold rounded-xl">Cancel</button>
        <button type="submit" class="py-2.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-black text-xs shadow-lg shadow-amber-500/20 transition-all inline-flex items-center gap-2">
          <span>📤</span> <span>Send Email Reminder Now</span>
        </button>
      </div>
    </form>
  </div>
</div>

<!-- ── MODAL 2: EDIT LEDGER ENTRY ────────────────────────────────────── -->
<div id="editLedgerModal" class="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 sm:p-8 max-w-lg w-full border border-blue-500/40 shadow-2xl space-y-5 animate-in fade-in duration-200">
    <div class="flex items-center justify-between border-b border-dark-border pb-3">
      <h3 class="text-base font-black text-white flex items-center gap-2">
        <span>✏️</span> <span>Edit Invoice / Ledger Entry</span>
      </h3>
      <button type="button" onclick="closeEditLedgerModal()" class="text-gray-400 hover:text-white text-2xl leading-none">&times;</button>
    </div>

    <form method="POST" action="/admin/ledger.php<?= $selectedClient ? '?client_id=' . urlencode($selectedClient) : '' ?>" class="space-y-4">
      <?= csrfField() ?>
      <input type="hidden" name="edit_ledger_entry" value="1">
      <input type="hidden" name="entry_id" id="editEntryId">

      <div>
        <label class="form-label text-xs font-bold text-gray-300">Client</label>
        <select name="user_id" id="editUserId" class="form-select text-xs py-2 bg-[#161622] border-dark-border w-full rounded-xl" required>
          <?php foreach ($allUsers as $u): ?>
          <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['name']) ?> (<?= $u['id'] ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="form-label text-xs font-bold text-gray-300">Type</label>
          <select name="type" id="editType" class="form-select text-xs py-2 bg-[#161622] border-dark-border w-full rounded-xl font-bold">
            <option value="payment">PAYMENT (Credit)</option>
            <option value="billed">CHARGE (Debit)</option>
          </select>
        </div>
        <div>
          <label class="form-label text-xs font-bold text-gray-300">Amount ($ USD)</label>
          <input type="number" step="0.01" min="0.01" name="amount" id="editAmount" class="form-input text-xs py-2 bg-[#161622] border-dark-border w-full rounded-xl font-mono" required>
        </div>
      </div>

      <div>
        <label class="form-label text-xs font-bold text-gray-300">Payment Method</label>
        <select name="payment_method" id="editMethod" class="form-select text-xs py-2 bg-[#161622] border-dark-border w-full rounded-xl font-semibold text-white">
          <option value="PayPal">🅿️ PayPal</option>
          <option value="Payoneer">🟠 Payoneer</option>
          <option value="Wise">🟢 Wise (TransferWise)</option>
          <option value="Bank Transfer">🏛️ Bank Transfer / Wire</option>
          <option value="Stripe / Card">💳 Stripe / Card</option>
          <option value="Direct Cash">💵 Direct Cash / Cheque</option>
          <option value="Manual Adjustment">⚙️ Manual Adjustment</option>
        </select>
      </div>

      <div>
        <label class="form-label text-xs font-bold text-gray-300">Description / Reference Note</label>
        <input type="text" name="notes" id="editNotes" class="form-input text-xs py-2 bg-[#161622] border-dark-border w-full rounded-xl">
      </div>

      <div class="flex items-center justify-end gap-3 pt-3 border-t border-dark-border">
        <button type="button" onclick="closeEditLedgerModal()" class="btn-ghost py-2.5 px-4 text-xs font-bold rounded-xl">Cancel</button>
        <button type="submit" class="btn-gold py-2.5 px-6 text-xs font-black shadow-glow rounded-xl">Save Changes</button>
      </div>
    </form>
  </div>
</div>

<!-- ── MODAL 3: DELETE LEDGER ENTRY ──────────────────────────────────── -->
<div id="deleteLedgerModal" class="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 sm:p-8 max-w-md w-full border border-red-500/50 shadow-2xl space-y-4 animate-in fade-in duration-200">
    <div class="flex items-center gap-3">
      <div class="w-12 h-12 rounded-2xl bg-red-600/20 border border-red-500 flex items-center justify-center text-red-400 text-xl font-black">
        ⚠️
      </div>
      <div>
        <h3 class="text-base font-black text-white">Delete Invoice Record?</h3>
        <p class="text-xs text-gray-400">Permanently remove this transaction from the ledger.</p>
      </div>
    </div>

    <div class="p-3.5 rounded-2xl bg-red-950/30 border border-red-800/50 text-xs text-red-200">
      Invoice Item: <strong id="deleteLedgerInfo" class="text-white font-mono"></strong>
    </div>

    <div class="flex items-center justify-end gap-3 pt-2">
      <button type="button" onclick="closeDeleteLedgerModal()" class="btn-ghost py-2.5 px-4 text-xs font-bold rounded-xl">Cancel</button>
      <a id="confirmDeleteLedgerBtn" href="#" class="py-2.5 px-5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs shadow-lg transition-all inline-flex items-center gap-1.5">
        <span>🗑️ Yes, Delete Entry</span>
      </a>
    </div>
  </div>
</div>

<!-- ── MODAL 4: PURGE ALL LEDGER (RESET TO ZERO) ──────────────────────── -->
<div id="purgeLedgerModal" class="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 sm:p-8 max-w-md w-full border border-red-500/50 shadow-2xl space-y-5 animate-in fade-in duration-200">
    <div class="flex items-center gap-3.5 border-b border-dark-border pb-4">
      <div class="w-12 h-12 rounded-2xl bg-red-600/20 border border-red-500 flex items-center justify-center text-red-400 text-2xl font-black">
        🧹
      </div>
      <div>
        <h3 class="text-lg font-black text-red-400">Reset All Ledger Invoices</h3>
        <p class="text-xs text-gray-400">Clear all past financial transaction records.</p>
      </div>
    </div>

    <div class="p-4 rounded-2xl bg-red-950/40 border border-red-800/60 text-xs text-red-200 space-y-2">
      <p><strong>Warning:</strong> This will permanently delete <strong>all <?= count($allLedger) ?> invoice transactions</strong> and reset the revenue audit trail.</p>
      <p class="text-gray-400">Client profiles and order records will remain completely safe.</p>
    </div>

    <form method="POST" action="/admin/ledger.php" class="flex items-center justify-end gap-3 pt-2">
      <?= csrfField() ?>
      <input type="hidden" name="purge_all_ledger" value="1">
      <button type="button" onclick="closePurgeLedgerModal()" class="btn-ghost py-2.5 px-4 text-xs font-bold rounded-xl">Cancel</button>
      <button type="submit" class="py-2.5 px-6 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs shadow-lg transition-all flex items-center gap-1.5">
        <span>🧹 Yes, Reset All Invoices</span>
      </button>
    </form>
  </div>
</div>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
// ── Interactive Tabs Controller ──────────────────────────────────────────────
function switchLedgerTab(tabId) {
  const tabs = ['pending', 'completed', 'audit'];
  tabs.forEach(t => {
    const content = document.getElementById('tabContent-' + t);
    const btn = document.getElementById('tabBtn-' + t);
    if (!content || !btn) return;

    if (t === tabId) {
      content.classList.remove('hidden');
      if (t === 'pending') {
        btn.className = 'px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 bg-amber-500 text-black shadow-lg shadow-amber-500/20';
      } else if (t === 'completed') {
        btn.className = 'px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 bg-green-500 text-black shadow-lg shadow-green-500/20';
      } else {
        btn.className = 'px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 bg-gold text-black shadow-lg shadow-gold/20';
      }
    } else {
      content.classList.add('hidden');
      btn.className = 'px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 bg-transparent text-gray-400 hover:text-white hover:bg-white/5';
    }
  });

  // Update URL history without page reload
  const url = new URL(window.location);
  url.searchParams.set('tab', tabId);
  window.history.replaceState({}, '', url);
}

// ── Follow-up Reminder Modal ────────────────────────────────────────────────
function openSendReminderModal(clientId, clientName, clientEmail, amountDue) {
  document.getElementById('reminderClientId').value = clientId;
  document.getElementById('reminderClientName').value = clientName;
  document.getElementById('reminderClientEmail').value = clientEmail;
  document.getElementById('reminderAmountDue').value = parseFloat(amountDue).toFixed(2);

  document.getElementById('reminderClientNameDisplay').textContent = clientName || 'Client ' + clientId;
  document.getElementById('reminderClientEmailDisplay').textContent = clientEmail || 'No email registered';
  document.getElementById('reminderAmountDisplay').textContent = '$' + parseFloat(amountDue).toFixed(2) + ' USD';

  const defaultMsg = 'Dear ' + (clientName || 'Valued Client') + ',\n\nWe hope you are satisfied with your delivered property photos! This is a friendly reminder that your account has an outstanding balance of $' + parseFloat(amountDue).toFixed(2) + ' USD for recent photo editing services.\n\nKindly clear this invoice via PayPal (billing@estatehdr.com) or contact us if you need any assistance.\n\nThank you for choosing Estate HDR!\nEstate HDR Accounts Team';
  document.getElementById('reminderMessage').value = defaultMsg;

  document.getElementById('sendReminderModal').classList.remove('hidden');
}

function closeSendReminderModal() {
  document.getElementById('sendReminderModal').classList.add('hidden');
}

// ── Prefill Payment Form ─────────────────────────────────────────────────────
function prefillPaymentForm(clientId, amount, memo) {
  document.getElementById('manualPaymentUserId').value = clientId;
  document.getElementById('manualPaymentType').value = 'payment';
  document.getElementById('manualPaymentAmount').value = parseFloat(amount).toFixed(2);
  document.getElementById('manualPaymentNotes').value = memo || '';

  scrollToPaymentForm();
}

function scrollToPaymentForm() {
  const card = document.getElementById('recordPaymentCard');
  if (card) {
    card.scrollIntoView({ behavior: 'smooth', block: 'center' });
    card.classList.add('ring-2', 'ring-gold', 'shadow-gold/30');
    setTimeout(() => {
      card.classList.remove('ring-2', 'ring-gold', 'shadow-gold/30');
    }, 2500);
  }
}

// ── Edit Ledger Entry Modal ──────────────────────────────────────────────────
function openEditLedgerModal(item) {
  if (!item) return;
  document.getElementById('editEntryId').value = item.id || '';
  document.getElementById('editUserId').value = item.user_id || '';
  document.getElementById('editType').value = item.type || 'payment';
  document.getElementById('editAmount').value = parseFloat(item.amount || 0).toFixed(2);
  let meth = item.payment_method || 'PayPal';
  if (meth === 'Bank Wire') meth = 'Bank Transfer';
  if (meth === 'Stripe Invoice' || meth === 'Credit Card') meth = 'Stripe / Card';
  if (meth === 'Cash / Cheque') meth = 'Direct Cash';
  document.getElementById('editMethod').value = meth;
  document.getElementById('editNotes').value = item.notes || '';
  document.getElementById('editLedgerModal').classList.remove('hidden');
}

function closeEditLedgerModal() {
  document.getElementById('editLedgerModal').classList.add('hidden');
}

// ── Delete Ledger Entry Modal ────────────────────────────────────────────────
function openDeleteLedgerModal(id, info) {
  document.getElementById('deleteLedgerInfo').textContent = info;
  document.getElementById('confirmDeleteLedgerBtn').href = '/admin/ledger.php?delete_entry=' + encodeURIComponent(id);
  document.getElementById('deleteLedgerModal').classList.remove('hidden');
}

function closeDeleteLedgerModal() {
  document.getElementById('deleteLedgerModal').classList.add('hidden');
}

// ── Purge All Invoices Modal ─────────────────────────────────────────────────
function openPurgeLedgerModal() {
  document.getElementById('purgeLedgerModal').classList.remove('hidden');
}

function closePurgeLedgerModal() {
  document.getElementById('purgeLedgerModal').classList.add('hidden');
}

// Close modals when clicking outside backdrop
window.addEventListener('click', function(e) {
  const modals = ['sendReminderModal', 'editLedgerModal', 'deleteLedgerModal', 'purgeLedgerModal'];
  modals.forEach(mId => {
    const el = document.getElementById(mId);
    if (el && e.target === el) {
      el.classList.add('hidden');
    }
  });
});
</script>

</body>
</html>
