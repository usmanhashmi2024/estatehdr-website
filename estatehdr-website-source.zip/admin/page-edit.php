<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireSeoManagerOrAdmin();

$slug = trim($_GET['slug'] ?? '');
$isEditing = !empty($slug);
$page = $isEditing ? getPageSeo($slug) : null;
$allPages = getPagesSeo();
$pageCategories = getPageCategories();
$currentAdmin = currentAdminUser();

// Handle Save POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $isAjax = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
           || (!empty($_SERVER['CONTENT_TYPE']) && str_contains($_SERVER['CONTENT_TYPE'], 'application/json'))
           || isset($_POST['ajax_save']);

    $rawInput = file_get_contents('php://input');
    if (!empty($rawInput)) {
        $jsonInput = json_decode($rawInput, true);
        if (is_array($jsonInput)) {
            $_POST = array_merge($_POST, $jsonInput);
        }
    }

    $token = $_POST['csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (empty($token) || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        $freshToken = csrfToken();
        if ($isAjax) {
            header('Content-Type: application/json; charset=utf-8');
            http_response_code(200);
            echo json_encode([
                'success'        => false,
                'code'           => 'CSRF_EXPIRED',
                'error'          => 'Your editing session or security token refreshed. Auto-renewing session...',
                'new_csrf_token' => $freshToken
            ]);
            exit;
        } else {
            setFlash('error', 'Session refreshed. Please click Publish / Save again.');
            header('Location: ' . ($_SERVER['REQUEST_URI'] ?: '/admin/pages.php'));
            exit;
        }
    }

    $pageContent = '';
    if (!empty($_POST['content_b64'])) {
        $pageContent = base64_decode($_POST['content_b64']);
    } elseif (isset($_POST['content'])) {
        $pageContent = $_POST['content'];
    }

    $schemaJson = '';
    if (!empty($_POST['schema_json_b64'])) {
        $schemaJson = base64_decode($_POST['schema_json_b64']);
    } elseif (isset($_POST['schema_json'])) {
        $schemaJson = $_POST['schema_json'];
    }

    $pageData = [
        'id'               => $isEditing ? ($page['id'] ?? ('page-' . $slug)) : ('page-' . time()),
        'title'            => trim($_POST['title'] ?? ''),
        'page_name'        => trim($_POST['page_name'] ?? $_POST['title'] ?? ''),
        'slug'             => trim($_POST['slug'] ?? ''),
        'parent_id'        => trim($_POST['parent_id'] ?? ''),
        'category'         => trim($_POST['category'] ?? 'Services & Solutions'),
        'template'         => trim($_POST['template'] ?? 'default'),
        'order'            => (int)($_POST['order'] ?? 0),
        'author'           => $currentAdmin['name'] ?? 'SEO Manager',
        'status'           => $_POST['status'] ?? 'published',
        'content'          => $pageContent,
        'featured_image'   => trim($_POST['featured_image'] ?? ''),
        'focus_keyword'    => trim($_POST['focus_keyword'] ?? ''),
        'meta_title'       => trim($_POST['meta_title'] ?? ''),
        'meta_description' => trim($_POST['meta_description'] ?? ''),
        'og_image'         => trim($_POST['og_image'] ?? $_POST['featured_image'] ?? ''),
        'canonical_url'    => trim($_POST['canonical_url'] ?? ''),
        'robots'           => $_POST['robots'] ?? 'index, follow',
        'allow_comments'   => isset($_POST['allow_comments']),
        'exclude_sitemap'  => isset($_POST['exclude_sitemap']),
        'schema_json'      => trim($schemaJson)
    ];

    if (empty($pageData['meta_title'])) $pageData['meta_title'] = $pageData['title'];

    $saved = savePage($pageData);
    $statusText = $saved['status'] === 'draft' ? 'saved as Draft' : 'published live';
    $msg = 'Page "' . htmlspecialchars($saved['page_name']) . '" ' . $statusText . ' successfully!';
    setFlash('success', $msg);

    if ($isAjax) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'success'     => true,
            'id'          => $saved['id'],
            'status'      => $saved['status'],
            'redirect'    => '/admin/pages.php',
            'message'     => $msg,
            'csrf_token'  => csrfToken()
        ]);
        exit;
    }

    header('Location: /admin/pages.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $isEditing ? 'Edit Page: ' . htmlspecialchars($page['page_name'] ?? $page['title']) : 'Add New Page' ?> — Estate HDR</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
<style nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
/* Visual WYSIWYG Editor Styles */
#editorVisual, #editorVisualFullscreen {
  min-height: 420px;
  max-height: 850px;
  overflow-y: auto;
  outline: none;
  font-family: 'Inter', system-ui, -apple-system, sans-serif;
  color: #E2E8F0;
  line-height: 1.75;
}
#editorVisual:focus, #editorVisualFullscreen:focus { border-color: #C9A84C; }

/* ── Clear Visual Headings with Badges ── */
#editorVisual h1, #editorVisualFullscreen h1 {
  font-size: 2rem !important;
  font-weight: 800 !important;
  margin: 1.5rem 0 0.6rem !important;
  color: #FFFFFF !important;
  border-bottom: 2px solid rgba(201, 168, 76, 0.4) !important;
  padding-bottom: 0.35rem !important;
}
#editorVisual h1::before, #editorVisualFullscreen h1::before {
  content: "H1 Main Heading";
  display: inline-block;
  font-size: 11px;
  font-family: ui-monospace, SFMono-Regular, monospace;
  font-weight: 800;
  text-transform: uppercase;
  background: rgba(201, 168, 76, 0.25);
  color: #C9A84C;
  border: 1px solid rgba(201, 168, 76, 0.5);
  padding: 2px 8px;
  border-radius: 6px;
  margin-right: 10px;
  vertical-align: middle;
  user-select: none;
}

#editorVisual h2, #editorVisualFullscreen h2 {
  font-size: 1.6rem !important;
  font-weight: 800 !important;
  margin: 1.35rem 0 0.5rem !important;
  color: #F5D77F !important;
  border-left: 4px solid #F5D77F !important;
  padding-left: 10px !important;
}
#editorVisual h2::before, #editorVisualFullscreen h2::before {
  content: "H2 Section";
  display: inline-block;
  font-size: 10px;
  font-family: ui-monospace, SFMono-Regular, monospace;
  font-weight: 800;
  text-transform: uppercase;
  background: rgba(245, 215, 127, 0.2);
  color: #F5D77F;
  border: 1px solid rgba(245, 215, 127, 0.4);
  padding: 1px 7px;
  border-radius: 6px;
  margin-right: 8px;
  vertical-align: middle;
  user-select: none;
}

#editorVisual h3, #editorVisualFullscreen h3 {
  font-size: 1.3rem !important;
  font-weight: 700 !important;
  margin: 1.15rem 0 0.4rem !important;
  color: #C9A84C !important;
  border-left: 3px solid #C9A84C !important;
  padding-left: 8px !important;
}
#editorVisual h3::before, #editorVisualFullscreen h3::before {
  content: "H3 Sub-heading";
  display: inline-block;
  font-size: 9px;
  font-family: ui-monospace, SFMono-Regular, monospace;
  font-weight: 800;
  text-transform: uppercase;
  background: rgba(201, 168, 76, 0.15);
  color: #C9A84C;
  border: 1px solid rgba(201, 168, 76, 0.3);
  padding: 1px 6px;
  border-radius: 5px;
  margin-right: 8px;
  vertical-align: middle;
  user-select: none;
}

#editorVisual h4, #editorVisualFullscreen h4 {
  font-size: 1.1rem !important;
  font-weight: 700 !important;
  margin: 0.85rem 0 0.3rem !important;
  color: #E2E8F0 !important;
}
#editorVisual h4::before, #editorVisualFullscreen h4::before {
  content: "H4";
  display: inline-block;
  font-size: 9px;
  font-family: ui-monospace, SFMono-Regular, monospace;
  font-weight: 800;
  background: rgba(255, 255, 255, 0.15);
  color: #E2E8F0;
  border: 1px solid rgba(255, 255, 255, 0.3);
  padding: 1px 5px;
  border-radius: 4px;
  margin-right: 6px;
  vertical-align: middle;
  user-select: none;
}

#editorVisual p, #editorVisualFullscreen p, #editorVisual div:not(.grid):not(.glass-card):not(.schema-embed-badge), #editorVisualFullscreen div:not(.grid):not(.glass-card):not(.schema-embed-badge) { margin-top: 0 !important; margin-bottom: 0.65rem !important; line-height: 1.65 !important; color: #E2E8F0; }
#editorVisual blockquote, #editorVisualFullscreen blockquote { border-left: 4px solid #C9A84C; background: rgba(22, 22, 34, 0.4); padding: 1rem 1.25rem; margin: 1.25rem 0; font-style: italic; color: #CBD5E1; border-radius: 0 0.75rem 0.75rem 0; }
#editorVisual ul, #editorVisualFullscreen ul { list-style-type: disc; margin-left: 1.5rem; margin-bottom: 0.85rem; }
#editorVisual ol, #editorVisualFullscreen ol { list-style-type: decimal; margin-left: 1.5rem; margin-bottom: 0.85rem; }
#editorVisual table, #editorVisualFullscreen table { width: 100% !important; border-collapse: collapse !important; margin: 1.25rem 0 !important; border: 1px solid #2D2D3F !important; border-radius: 0.75rem !important; overflow: hidden !important; background: #0E0E16 !important; color: #F1F5F9 !important; }
#editorVisual th, #editorVisual td, #editorVisualFullscreen th, #editorVisualFullscreen td { border: 1px solid #2D2D3F !important; padding: 0.75rem 0.9rem !important; text-align: left !important; }
#editorVisual th, #editorVisualFullscreen th { background: #161622 !important; color: #C9A84C !important; font-weight: bold !important; text-transform: uppercase !important; font-size: 0.75rem !important; letter-spacing: 0.05em !important; }
#editorVisual td, #editorVisualFullscreen td { background: #0E0E16 !important; color: #F1F5F9 !important; font-size: 0.875rem !important; line-height: 1.5 !important; }
#editorVisual tr:nth-child(even) td, #editorVisualFullscreen tr:nth-child(even) td { background: #14141F !important; }
#editorVisual img, #editorVisualFullscreen img { max-width: 100%; border-radius: 0.75rem; margin: 1rem 0; box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.5); }
#editorVisual a, #editorVisualFullscreen a { color: #C9A84C; text-decoration: underline; font-weight: bold; }
#editorVisual hr, #editorVisualFullscreen hr { border: 0; border-top: 1px solid #2A2A3A; margin: 2rem 0; }
html.light #editorVisual, html.light #editorVisualFullscreen { color: #0F172A; background-color: #FFFFFF; }
html.light #editorVisual h1, html.light #editorVisual h2, html.light #editorVisualFullscreen h1, html.light #editorVisualFullscreen h2 { color: #0F172A; }
html.light #editorVisual p, html.light #editorVisualFullscreen p, html.light #editorVisual div, html.light #editorVisualFullscreen div { color: #334155; }
html.light #editorVisual table, html.light #editorVisualFullscreen table { background: #FFFFFF !important; border-color: #CBD5E1 !important; color: #0F172A !important; }
html.light #editorVisual th, html.light #editorVisualFullscreen th { background: #F1F5F9 !important; color: #9A7A2E !important; border-color: #CBD5E1 !important; }
html.light #editorVisual td, html.light #editorVisualFullscreen td { background: #FFFFFF !important; color: #0F172A !important; border-color: #CBD5E1 !important; }
html.light #editorVisual tr:nth-child(even) td, html.light #editorVisualFullscreen tr:nth-child(even) td { background: #F8FAFC !important; }
</style>
</head>
<body class="bg-[#0A0A0F] text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8">
  <?= renderFlash() ?>

  <!-- Top Action Bar with Back Button & Quick Actions -->
  <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-[#1E1E2E]">
    <div class="flex items-center gap-4">
      <a href="/admin/pages.php" class="btn-ghost py-2.5 px-4 text-xs font-bold inline-flex items-center gap-2 border border-[#1E1E2E] hover:border-gold">
        <span>←</span> <span>Back to Pages</span>
      </a>
      <div>
        <h1 class="text-xl sm:text-2xl font-black text-white"><?= $isEditing ? 'Edit Page: ' . htmlspecialchars($page['page_name'] ?? $page['title']) : 'Add New Static Page' ?></h1>
        <p class="text-xs text-gray-400">Manage page hierarchy, rich block content, draft status, and SSR SEO parameters.</p>
      </div>
    </div>

    <!-- Quick Action Buttons -->
    <div class="flex items-center gap-3">
      <button type="button" onclick="EstateEditor.openLivePreview('page')" class="btn-ghost py-2.5 px-4 text-xs font-bold text-gold border-gold/40 hover:bg-gold/10 inline-flex items-center gap-1.5 shadow-sm">
        <span>👁️</span> <span>Live Preview</span>
      </button>
      <button type="button" onclick="submitAs('draft')" class="btn-ghost py-2.5 px-5 text-xs font-bold text-gray-300 border-[#2A2A3A] hover:border-gold inline-flex items-center gap-1.5">
        <span>💾</span> <span>Save as Draft</span>
      </button>
      <button type="button" id="topSubmitBtn" onclick="submitAs('published')" class="btn-gold py-2.5 px-6 text-xs font-black shadow-glow inline-flex items-center gap-1.5">
        <span>🚀</span> <span id="topSubmitBtnText"><?= $isEditing ? 'Update & Publish' : 'Publish Page' ?></span>
      </button>
    </div>
  </div>

  <form id="pageForm" method="POST" class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
    <?= csrfField() ?>
    <input type="hidden" id="formStatus" name="status" value="<?= htmlspecialchars($page['status'] ?? 'published') ?>">

    <!-- LEFT COLUMN: MAIN CONTENT & RICH EDITOR (8 Cols) -->
    <div class="lg:col-span-8 space-y-6">
      
      <!-- Page Title & Permalink -->
      <div class="glass-card rounded-2xl p-6 border border-dark-border shadow-xl space-y-4 bg-[#111118]">
        <div>
          <label class="form-label text-xs">Page Title (Main H1 Heading) <span class="text-red-400">*</span></label>
          <input type="text" id="pageTitleInput" name="title" value="<?= htmlspecialchars($page['title'] ?? $page['page_name'] ?? '') ?>" 
                 class="form-input text-base font-bold" placeholder="e.g. Luxury Real Estate Virtual Staging" required oninput="syncPageSlug()">
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label class="form-label text-xs">Internal Reference Name</label>
            <input type="text" name="page_name" value="<?= htmlspecialchars($page['page_name'] ?? '') ?>" class="form-input text-xs" placeholder="e.g. Services Overview">
          </div>

          <div>
            <label class="form-label text-xs">URL Slug / Permalink</label>
            <div class="flex items-center">
              <span class="bg-dark px-3 py-2 text-xs font-mono text-gray-500 border border-r-0 border-dark-border rounded-l-xl">/</span>
              <input type="text" id="pageSlugInput" name="slug" value="<?= htmlspecialchars($page['slug'] ?? '') ?>" 
                     class="form-input text-xs font-mono rounded-l-none" placeholder="about-us" <?= ($page['slug'] ?? '') === 'home' ? 'readonly' : '' ?>>
            </div>
          </div>
        </div>
      </div>

      <!-- Rich Block Content Editor -->
      <div class="glass-card rounded-2xl p-6 border border-dark-border shadow-xl space-y-3 bg-[#111118]">
        <div class="flex items-center justify-between border-b border-[#1E1E2E] pb-3">
          <div class="flex items-center gap-2">
            <label class="form-label text-xs font-bold text-white mb-0">Page Body Content</label>
            <span class="px-2 py-0.5 rounded bg-gold/10 text-gold text-[10px] font-bold uppercase">WYSIWYG Pro • Type / for commands</span>
          </div>
          <div class="flex items-center gap-2">
            <button type="button" onclick="EstateEditor.openFullscreenModal()" class="btn-ghost py-1 px-3 text-xs font-bold text-amber-300 border border-amber-500/40 hover:bg-gold hover:text-dark inline-flex items-center gap-1.5 transition-all shadow-sm" title="Expand to Fullscreen Focus Editor">
              <span>⛶</span> <span>Expand Editor</span>
            </button>
            <button type="button" onclick="toggleCodeView()" id="codeViewBtn" class="btn-ghost py-1 px-3 text-xs font-mono text-gold border border-gold/40 hover:bg-gold/10 inline-flex items-center gap-1">
              <span>&lt;/&gt;</span> <span id="codeViewBtnText">HTML View</span>
            </button>
          </div>
        </div>

        <!-- Full Rich Formatting Toolbar -->
        <div id="editorToolbar" class="flex flex-wrap items-center gap-1.5 p-2.5 bg-[#07070B] rounded-xl border border-[#1E1E2E] text-xs">
          <div class="flex items-center gap-1 bg-[#161622] p-1 rounded-lg border border-[#2A2A3A]">
            <select id="editorHeadingSelect" onchange="EstateEditor.applyHeading(this.value)" class="form-select text-xs py-1 px-2.5 font-bold bg-[#0D0D14] text-gold border-[#3A3A4E] rounded-md">
              <option value="p">Paragraph (Normal Text)</option>
              <option value="h1">Heading 1 (H1 - Main Title)</option>
              <option value="h2">Heading 2 (H2 - Main Section)</option>
              <option value="h3">Heading 3 (H3 - Sub-Section)</option>
              <option value="h4">Heading 4 (H4 - Minor Topic)</option>
              <option value="h5">Heading 5 (H5)</option>
              <option value="h6">Heading 6 (H6)</option>
            </select>
            <span id="editorActiveBlockBadge" class="px-2 py-0.5 rounded bg-gold/20 text-gold border border-gold/40 font-mono font-black text-[11px]">P</span>
            <span class="w-[1px] h-4 bg-[#2A2A3A] mx-0.5"></span>
            <button type="button" onclick="EstateEditor.applyHeading('h1')" class="px-2 py-1 rounded bg-[#0D0D14] hover:bg-gold hover:text-dark font-black text-xs text-white border border-[#2A2A3A]" title="Quick Apply Heading 1">H1</button>
            <button type="button" onclick="EstateEditor.applyHeading('h2')" class="px-2 py-1 rounded bg-[#0D0D14] hover:bg-gold hover:text-dark font-black text-xs text-gold border border-gold/40" title="Quick Apply Heading 2">H2</button>
            <button type="button" onclick="EstateEditor.applyHeading('h3')" class="px-2 py-1 rounded bg-[#0D0D14] hover:bg-gold hover:text-dark font-black text-xs text-amber-300 border border-amber-500/30" title="Quick Apply Heading 3">H3</button>
            <button type="button" onclick="EstateEditor.applyHeading('p')" class="px-2 py-1 rounded bg-[#0D0D14] hover:bg-gold hover:text-dark font-bold text-xs text-gray-300 border border-[#2A2A3A]" title="Quick Apply Normal Paragraph">P</button>
          </div>

          <span class="w-[1px] h-5 bg-[#2A2A3A] mx-1"></span>

          <button type="button" onclick="EstateEditor.execCmd('bold')" class="p-1.5 px-2.5 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg font-bold" title="Bold (Ctrl+B)"><strong>B</strong></button>
          <button type="button" onclick="EstateEditor.execCmd('italic')" class="p-1.5 px-2.5 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg italic" title="Italic (Ctrl+I)"><em>I</em></button>
          <button type="button" onclick="EstateEditor.execCmd('underline')" class="p-1.5 px-2.5 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg underline" title="Underline (Ctrl+U)"><u>U</u></button>
          <button type="button" onclick="EstateEditor.execCmd('strikeThrough')" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg line-through" title="Strikethrough"><s>S</s></button>
          <button type="button" onclick="EstateEditor.execCmd('removeFormat')" class="p-1.5 px-2 bg-[#161622] hover:bg-red-500 hover:text-white rounded-lg" title="Clear Formatting">🧹</button>

          <span class="w-[1px] h-5 bg-[#2A2A3A] mx-1"></span>

          <button type="button" onclick="EstateEditor.execCmd('justifyLeft')" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Align Left">⬅️</button>
          <button type="button" onclick="EstateEditor.execCmd('justifyCenter')" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Align Center">↔️</button>
          <button type="button" onclick="EstateEditor.execCmd('justifyRight')" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Align Right">➡️</button>

          <span class="w-[1px] h-5 bg-[#2A2A3A] mx-1"></span>

          <button type="button" onclick="EstateEditor.execCmd('insertUnorderedList')" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Bullet List">• List</button>
          <button type="button" onclick="EstateEditor.execCmd('insertOrderedList')" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Numbered List">1. List</button>

          <span class="w-[1px] h-5 bg-[#2A2A3A] mx-1"></span>

          <button type="button" onclick="EstateEditor.openLinkModal()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg text-blue-400 font-bold" title="Insert Link">🔗 Link</button>
          <button type="button" onclick="EstateEditor.openImageModal()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Insert Image with Alt Text">🖼️ Image</button>
          <button type="button" onclick="EstateEditor.openVideoModal()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Embed YouTube/Video">🎥 Video</button>
          <button type="button" onclick="EstateEditor.openRawHtmlModal()" class="p-1.5 px-2.5 bg-[#161622] hover:bg-emerald-500 hover:text-dark rounded-lg text-emerald-400 font-mono font-black border border-emerald-500/40 shadow-sm" title="Insert Custom HTML Embed or Schema Markup">&lt;/&gt; Code / Schema</button>
          <button type="button" onclick="EstateEditor.openTableModal()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg font-bold" title="Insert Table">📊 Table</button>
          <button type="button" onclick="EstateEditor.insertBlockquote()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Insert Blockquote">❝ Quote</button>
          <button type="button" onclick="EstateEditor.insertCalloutBox()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg text-amber-400 font-bold" title="Callout Tip Box">💡 Callout</button>
          <button type="button" onclick="EstateEditor.insertHorizontalRule()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg" title="Horizontal Divider">➖ Divider</button>
          <button type="button" onclick="EstateEditor.openCtaModal()" class="p-1.5 px-2 bg-[#161622] hover:bg-gold hover:text-dark rounded-lg text-gold font-bold" title="Insert Gold CTA Button">🔘 Button</button>
        </div>

        <!-- Live Visual Contenteditable Surface (Populated via JS to isolate internal DOM) -->
        <div id="editorVisual" contenteditable="true" class="form-input text-sm p-4 rounded-xl border border-[#1E1E2E] bg-[#07070B] min-h-[380px] focus:ring-1 focus:ring-gold" oninput="EstateEditor.syncVisualToTextarea()"></div>

        <!-- Raw HTML Textarea (Synced & Toggleable) -->
        <textarea id="pageContent" name="content" rows="18" class="hidden form-input text-xs font-mono resize-y leading-relaxed bg-[#07070B]" 
                  placeholder="Raw HTML code..." oninput="EstateEditor.syncTextareaToVisual()"><?= htmlspecialchars($page['content'] ?? '') ?></textarea>
      </div>

      
      <!-- Live Readability & SEO Score Card -->
      <div class="glass-card rounded-2xl p-6 border border-emerald-500/30 shadow-xl space-y-4 bg-gradient-to-br from-[#111118] to-[#0A0A0F]">
        <div class="flex items-center justify-between border-b border-[#1E1E2E] pb-3">
          <div class="flex items-center gap-2">
            <span class="text-xl">📊</span>
            <div>
              <h3 class="text-sm font-black text-white">Content Readability &amp; SEO Health</h3>
              <p class="text-gray-400 text-xs">Real-time Flesch Reading Ease &amp; Google scanability auditor.</p>
            </div>
          </div>
          <span id="readabilityScoreDisplay" class="text-base font-mono font-black text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-xl border border-emerald-500/30">85 / 100</span>
        </div>

        <div>
          <div id="readabilityLabelDisplay" class="text-xs font-bold text-emerald-400">🟢 Good — Very Easy to Read &amp; Fast to Scan</div>
          <div id="readabilityStatsDisplay" class="text-xs font-mono text-gray-400 mt-1">Total Words: 0 | Sentences: 0 | Avg Words/Sentence: 0.0</div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
          <div class="p-3 rounded-xl bg-dark/60 border border-[#1E1E2E] flex items-center gap-2">
            <span>✅</span> <span>High Typography Contrast (95%+)</span>
          </div>
          <div class="p-3 rounded-xl bg-dark/60 border border-[#1E1E2E] flex items-center gap-2">
            <span>✅</span> <span>H1-H6 Subheading Hierarchy</span>
          </div>
          <div class="p-3 rounded-xl bg-dark/60 border border-[#1E1E2E] flex items-center gap-2">
            <span>✅</span> <span>Scannable Bullet &amp; Table Formatting</span>
          </div>
          <div class="p-3 rounded-xl bg-dark/60 border border-[#1E1E2E] flex items-center gap-2">
            <span>✅</span> <span>Mobile-Optimized Line Heights</span>
          </div>
        </div>
      </div>

      <!-- Advanced On-Page SEO Card -->
      <div class="glass-card rounded-2xl p-6 border border-gold/30 shadow-xl space-y-5 bg-gradient-to-br from-dark-card to-dark">
        <div class="border-b border-dark-border pb-3 flex items-center justify-between">
          <div>
            <h3 class="text-sm font-bold text-white flex items-center gap-2">
              <span>🚀</span> <span>Search Engine Optimization (Google / SSR Pure Indexable)</span>
            </h3>
            <p class="text-gray-400 text-xs mt-0.5">SSR pure HTML meta tags, OpenGraph social cards &amp; Structured JSON-LD schema.</p>
          </div>
          <span class="section-tag">SSR 100% Indexable</span>
        </div>

        <div>
          <label class="form-label text-xs">Focus Keyword</label>
          <input type="text" id="focusKeyword" name="focus_keyword" value="<?= htmlspecialchars($page['focus_keyword'] ?? '') ?>" class="form-input text-xs" placeholder="e.g. real estate photo editing" oninput="calculateSeoScore()">
        </div>

        <div>
          <div class="flex items-center justify-between mb-1">
            <label class="form-label text-xs">SEO Meta Title (Title Tag)</label>
            <span id="titleCount" class="text-xs font-mono font-bold text-gray-400">0 / 60 chars</span>
          </div>
          <input type="text" id="metaTitle" name="meta_title" value="<?= htmlspecialchars($page['meta_title'] ?? '') ?>" class="form-input text-sm" placeholder="e.g. Real Estate Photo Editing Services | Estate HDR" oninput="updateCounters()">
        </div>

        <div>
          <div class="flex items-center justify-between mb-1">
            <label class="form-label text-xs">SEO Meta Description</label>
            <span id="descCount" class="text-xs font-mono font-bold text-gray-400">0 / 160 chars</span>
          </div>
          <textarea id="metaDesc" name="meta_description" rows="2" class="form-input text-sm resize-y" placeholder="Short description shown in Google search result snippet..." oninput="updateCounters()"><?= htmlspecialchars($page['meta_description'] ?? '') ?></textarea>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label class="form-label text-xs">Robots Meta Directive</label>
            <select name="robots" class="form-select text-xs">
              <option value="index, follow" <?= ($page['robots'] ?? '') === 'index, follow' ? 'selected' : '' ?>>index, follow (Allow Google Indexing)</option>
              <option value="noindex, follow" <?= ($page['robots'] ?? '') === 'noindex, follow' ? 'selected' : '' ?>>noindex, follow (Hide From Google)</option>
            </select>
          </div>

          <div>
            <label class="form-label text-xs">Canonical URL Override</label>
            <input type="url" name="canonical_url" value="<?= htmlspecialchars($page['canonical_url'] ?? '') ?>" class="form-input text-xs font-mono" placeholder="https://estatehdr.com/...">
          </div>
        </div>

        <div class="pt-3 border-t border-dark-border flex items-center justify-between">
          <div>
            <div class="text-xs font-bold text-white">Exclude from XML Sitemap</div>
            <div class="text-xs text-gray-400">Hide this page from auto-generated sitemap.xml</div>
          </div>
          <input type="checkbox" name="exclude_sitemap" value="1" <?= !empty($page['exclude_sitemap']) ? 'checked' : '' ?> class="w-4 h-4 text-gold rounded border-dark-border bg-dark">
        </div>

        <div>
          <div class="flex flex-wrap items-center justify-between gap-2 mb-1.5">
            <label class="form-label text-xs">Custom JSON-LD Structured Data Schema</label>
            <div class="flex flex-wrap gap-1.5">
              <button type="button" onclick="insertCardSchemaTemplate('faq')" class="btn-ghost py-0.5 px-2 text-[10px] font-bold border-gold/40 text-gold hover:bg-gold/10">+ FAQ</button>
              <button type="button" onclick="insertCardSchemaTemplate('webpage')" class="btn-ghost py-0.5 px-2 text-[10px] font-bold border-blue-500/40 text-blue-400 hover:bg-blue-500/10">+ WebPage</button>
              <button type="button" onclick="insertCardSchemaTemplate('business')" class="btn-ghost py-0.5 px-2 text-[10px] font-bold border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/10">+ Agency</button>
              <button type="button" onclick="insertCardSchemaTemplate('howto')" class="btn-ghost py-0.5 px-2 text-[10px] font-bold border-purple-500/40 text-purple-400 hover:bg-purple-500/10">+ How-To</button>
            </div>
          </div>
          <textarea id="pageSchemaJson" name="schema_json" rows="4" class="form-input text-xs font-mono text-amber-300 resize-y" placeholder='{
  "@context": "https://schema.org",
  "@type": "WebPage",
  "name": "Page Title"
}'><?= htmlspecialchars($page['schema_json'] ?? '') ?></textarea>
          <p class="text-[11px] text-gray-500 mt-1">💡 Click any template above to auto-generate valid JSON-LD schema with page title &amp; URL.</p>
        </div>
      </div>

    </div>

    <!-- RIGHT COLUMN: SIDEBAR & PUBLISHING (4 Cols) -->
    <div class="lg:col-span-4 space-y-6">
      
      <!-- Publishing Controls Card -->
      <div class="glass-card rounded-2xl p-6 border border-dark-border shadow-xl space-y-4 bg-[#111118]">
        <div class="flex items-center justify-between border-b border-dark-border pb-2">
          <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider">Publishing Status</h3>
          <span id="sidebarStatusBadge" class="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider <?= ($page['status'] ?? '') === 'draft' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' ?>">
            <?= ($page['status'] ?? '') === 'draft' ? 'Draft' : 'Live' ?>
          </span>
        </div>

        <div>
          <label class="form-label text-xs">Status</label>
          <select name="status_select" id="pageStatusSelect" class="form-select text-sm" onchange="updatePublishingState(this.value)">
            <option value="published" <?= ($page['status'] ?? '') === 'published' ? 'selected' : '' ?>>Published (Live Immediately)</option>
            <option value="draft" <?= ($page['status'] ?? '') === 'draft' ? 'selected' : '' ?>>Draft (Saved Privately)</option>
          </select>
        </div>
      </div>

      <!-- Categories & Taxonomy -->
      <div class="glass-card rounded-2xl p-6 border border-dark-border shadow-xl space-y-4 bg-[#111118]">
        <div class="flex items-center justify-between border-b border-dark-border pb-2">
          <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider">Category &amp; Taxonomy</h3>
          <a href="/admin/categories.php?tab=page" target="_blank" class="text-[11px] text-gold hover:underline font-bold">Manage ↗</a>
        </div>

        <div>
          <label class="form-label text-xs">Page Category</label>
          <select name="category" id="pageCategorySelect" class="form-select text-sm">
            <?php foreach ($pageCategories as $pCat): ?>
              <option value="<?= htmlspecialchars($pCat['name']) ?>" <?= ($page['category'] ?? '') === $pCat['name'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($pCat['name']) ?>
              </option>
            <?php endforeach; ?>
            <?php if (empty($pageCategories)): ?>
              <option value="Services &amp; Solutions">Services &amp; Solutions</option>
              <option value="Company &amp; About">Company &amp; About</option>
            <?php endif; ?>
          </select>
        </div>

        <!-- Quick Add Custom Category -->
        <div class="pt-2 border-t border-[#1E1E2E]">
          <div id="quickAddCatBox" class="hidden space-y-2">
            <input type="text" id="quickCatName" class="form-input text-xs" placeholder="New category name...">
            <div class="flex gap-2">
              <button type="button" onclick="quickAddPageCategory()" class="btn-gold py-1.5 px-3 text-xs font-bold flex-1">Add Category</button>
              <button type="button" onclick="document.getElementById('quickAddCatBox').classList.add('hidden')" class="btn-ghost py-1.5 px-2 text-xs">Cancel</button>
            </div>
          </div>
          <button type="button" onclick="document.getElementById('quickAddCatBox').classList.toggle('hidden')" class="text-xs font-bold text-gold hover:underline inline-flex items-center gap-1 mt-1">
            <span>+</span> <span>Add Custom Category</span>
          </button>
        </div>
      </div>

      <!-- Page Attributes & Hierarchy -->
      <div class="glass-card rounded-2xl p-6 border border-dark-border shadow-xl space-y-4 bg-[#111118]">
        <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider border-b border-dark-border pb-2">Page Attributes</h3>
        <div>
          <label class="form-label text-xs">Parent Page</label>
          <select name="parent_id" class="form-select text-xs">
            <option value="">(None / Top Level)</option>
            <?php foreach ($allPages as $p): ?>
              <?php if (($p['slug'] ?? '') !== $slug): ?>
                <option value="<?= htmlspecialchars($p['id']) ?>" <?= ($page['parent_id'] ?? '') === $p['id'] ? 'selected' : '' ?>>
                  <?= htmlspecialchars($p['page_name'] ?? $p['title']) ?> (/<?= htmlspecialchars($p['slug']) ?>)
                </option>
              <?php endif; ?>
            <?php endforeach; ?>
          </select>
        </div>

        <div>
          <label class="form-label text-xs">Page Template</label>
          <select name="template" class="form-select text-xs">
            <option value="default" <?= ($page['template'] ?? '') === 'default' ? 'selected' : '' ?>>Default Clean Template</option>
            <option value="full_width" <?= ($page['template'] ?? '') === 'full_width' ? 'selected' : '' ?>>Full Width Landing Page</option>
            <option value="sidebar" <?= ($page['template'] ?? '') === 'sidebar' ? 'selected' : '' ?>>With Sidebar</option>
            <option value="contact" <?= ($page['template'] ?? '') === 'contact' ? 'selected' : '' ?>>Contact &amp; Inquiry</option>
          </select>
        </div>

        <div>
          <label class="form-label text-xs">Menu Order</label>
          <input type="number" name="order" value="<?= (int)($page['order'] ?? 0) ?>" class="form-input text-xs font-mono" placeholder="0">
        </div>
      </div>

      <!-- Featured Image & Social OG Card with Drag & Drop Uploader -->
      <div class="glass-card rounded-2xl p-6 border border-dark-border shadow-xl space-y-4 bg-[#111118]">
        <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider border-b border-dark-border pb-2">Featured Image / OG Card</h3>
        
        <!-- Drag & Drop Zone -->
        <div id="featuredImgDropzone" class="border-2 border-dashed border-[#2A2A3A] hover:border-gold rounded-2xl p-4 text-center cursor-pointer transition-colors bg-dark/60">
          <div class="text-2xl mb-1">📸</div>
          <div class="font-bold text-white text-xs mb-0.5">Drag &amp; drop image or <span class="text-gold underline">browse</span></div>
          <div class="text-[10px] text-gray-400">Auto-saved to uploads directory</div>
          <input type="file" id="featuredImgFileInput" accept="image/*" style="position: absolute; left: -9999px; top: -9999px; width: 1px; height: 1px; opacity: 0; pointer-events: none;" tabindex="-1" aria-hidden="true">
        </div>

        <div>
          <label class="form-label text-xs">Custom File Name Prefix (Optional)</label>
          <input type="text" id="featuredImgCustomName" class="form-input text-xs font-mono" placeholder="e.g. luxury-penthouse">
        </div>

        <div id="featuredImgUploadProgress" class="hidden text-center py-1">
          <div class="inline-flex items-center gap-2 text-gold font-mono text-xs">
            <span class="animate-spin text-sm">⏳</span> Uploading image...
          </div>
        </div>

        <div>
          <label class="form-label text-xs">Image Path / URL</label>
          <input type="text" id="featuredImgInput" name="featured_image" value="<?= htmlspecialchars($page['featured_image'] ?? '') ?>" class="form-input text-xs font-mono" placeholder="/assets/images/portfolio/hdr/1-after.jpg" oninput="updateCoverPreview()">
        </div>
        
        <div class="rounded-xl overflow-hidden border border-dark-border bg-dark h-36 flex items-center justify-center shadow-inner">
          <img id="coverPreview" src="<?= htmlspecialchars($page['featured_image'] ?: '/assets/images/portfolio/hdr/1-after.jpg') ?>" alt="Cover Preview" class="w-full h-full object-cover">
        </div>
      </div>

    </div>
  </form>
</main>

<script src="/assets/js/editor-pro.js?v=<?= file_exists(ROOT_PATH . '/assets/js/editor-pro.js') ? filemtime(ROOT_PATH . '/assets/js/editor-pro.js') : time() ?>"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
const CURRENT_PAGE_SLUG = '<?= htmlspecialchars($slug ?: 'new', ENT_QUOTES, 'UTF-8') ?>';
const DRAFT_PAGE_STORAGE_KEY = 'estatehdr_draft_page_' + CURRENT_PAGE_SLUG;
let isFormSubmitting = false;

function savePageDraftToLocalStorage() {
  if (isFormSubmitting) return;
  const title = (document.getElementById('pageTitleInput')?.value || '').trim();
  let content = '';
  const code = document.getElementById('pageContent');
  const visual = document.getElementById('editorVisual');
  if (code && !code.classList.contains('hidden')) {
    content = code.value || '';
  } else if (visual) {
    content = visual.innerHTML || '';
  }
  if (!title && !content) return;
  try {
    localStorage.setItem(DRAFT_PAGE_STORAGE_KEY, JSON.stringify({
      title, content, slug: document.getElementById('pageSlugInput')?.value || '', savedAt: Date.now()
    }));
  } catch (e) {}
}

async function submitAs(status) {
  if (isFormSubmitting) return;

  const topBtn = document.getElementById('topSubmitBtn');
  const topBtnText = document.getElementById('topSubmitBtnText');
  const originalText = topBtnText ? topBtnText.innerHTML : 'Publish';

  document.getElementById('formStatus').value = status;
  if (document.getElementById('pageStatusSelect')) {
    document.getElementById('pageStatusSelect').value = status;
  }
  updatePublishingState(status);

  const code = document.getElementById('pageContent');
  if (code && !code.classList.contains('hidden')) {
    EstateEditor.syncTextareaToVisual();
  } else {
    EstateEditor.syncVisualToTextarea();
  }

  const titleVal = (document.getElementById('pageTitleInput')?.value || '').trim();
  if (!titleVal) {
    alert('Please enter a Page Title before saving.');
    document.getElementById('pageTitleInput')?.focus();
    return;
  }

  savePageDraftToLocalStorage();
  isFormSubmitting = true;
  if (topBtn) {
    topBtn.disabled = true;
    topBtn.classList.add('opacity-75', 'cursor-not-allowed');
  }
  if (topBtnText) {
    topBtnText.innerHTML = `<span class="inline-block animate-spin mr-1">⏳</span> Saving...`;
  }

  const form = document.getElementById('pageForm');
  const formData = new FormData(form);
  formData.append('ajax_save', '1');

  // WAF & ModSecurity Safe Encoding
  const rawContent = formData.get('content') || '';
  const rawSchema = formData.get('schema_json') || '';
  try {
    formData.set('content_b64', btoa(unescape(encodeURIComponent(rawContent))));
    formData.delete('content');
  } catch (e) {}
  try {
    if (rawSchema) {
      formData.set('schema_json_b64', btoa(unescape(encodeURIComponent(rawSchema))));
      formData.delete('schema_json');
    }
  } catch (e) {}

  try {
    const postUrl = window.location.href;
    let resp = await fetch(postUrl, {
      method: 'POST',
      headers: {
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRF-TOKEN': window.CSRF_TOKEN || ''
      },
      body: formData
    });

    if (!resp.ok) {
      throw new Error(`Server returned HTTP ${resp.status}. Content is preserved locally.`);
    }

    const data = await resp.json();
    if (data.success) {
      try { localStorage.removeItem(DRAFT_PAGE_STORAGE_KEY); } catch (e) {}
      if (window.EstateDialog) {
        EstateDialog.toast(data.message || 'Page saved successfully!', 'success');
      }
      setTimeout(() => {
        window.location.href = data.redirect || '/admin/pages.php';
      }, 700);
    } else {
      throw new Error(data.error || 'Failed to save page.');
    }
  } catch (err) {
    console.error('Save failed:', err);
    isFormSubmitting = false;
    if (topBtn) {
      topBtn.disabled = false;
      topBtn.classList.remove('opacity-75', 'cursor-not-allowed');
    }
    if (topBtnText) topBtnText.innerHTML = originalText;
    alert('Save Notice: ' + err.message + '\n\nDon\'t worry: Your page content is preserved in the editor!');
  }
}

function submitCurrentForm() {
  submitAs(document.getElementById('formStatus')?.value || 'published');
}

function updatePublishingState(status) {
  document.getElementById('formStatus').value = status;
  const isDraft = (status === 'draft');
  const badge = document.getElementById('sidebarStatusBadge');
  const topBtnText = document.getElementById('topSubmitBtnText');
  
  if (isDraft) {
    if (badge) {
      badge.className = 'px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30';
      badge.textContent = 'Draft';
    }
    if (topBtnText) topBtnText.textContent = 'Save as Draft';
  } else {
    if (badge) {
      badge.className = 'px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/30';
      badge.textContent = 'Live';
    }
    if (topBtnText) topBtnText.textContent = '<?= $isEditing ? 'Update & Publish' : 'Publish Page' ?>';
  }
}

function toggleCodeView() {
  const visual = document.getElementById('editorVisual');
  const code = document.getElementById('pageContent');
  const btnText = document.getElementById('codeViewBtnText');
  const toolbar = document.getElementById('editorToolbar');

  if (code.classList.contains('hidden')) {
    EstateEditor.syncVisualToTextarea();
    visual.classList.add('hidden');
    toolbar.classList.add('opacity-40', 'pointer-events-none');
    code.classList.remove('hidden');
    btnText.textContent = 'Visual View';
  } else {
    EstateEditor.syncTextareaToVisual();
    code.classList.add('hidden');
    visual.classList.remove('hidden');
    toolbar.classList.remove('opacity-40', 'pointer-events-none');
    btnText.textContent = 'HTML View';
  }
}

function syncPageSlug() {
  const title = document.getElementById('pageTitleInput').value;
  const slugInput = document.getElementById('pageSlugInput');
  if (!slugInput.readOnly && !slugInput.dataset.manual) {
    slugInput.value = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
  }
  const metaTitle = document.getElementById('metaTitle');
  if (!metaTitle.value || metaTitle.value.startsWith(title.substring(0, 10))) {
    metaTitle.value = title ? `${title} | Estate HDR` : '';
    updateCounters();
  }
}

document.getElementById('pageSlugInput').addEventListener('input', function() {
  this.dataset.manual = 'true';
});

function updateCounters() {
  const titleVal = document.getElementById('metaTitle').value;
  const descVal = document.getElementById('metaDesc').value;
  document.getElementById('titleCount').textContent = `${titleVal.length} / 60 chars`;
  document.getElementById('descCount').textContent = `${descVal.length} / 160 chars`;
}

function updateCoverPreview() {
  document.getElementById('coverPreview').src = document.getElementById('featuredImgInput').value || '/assets/images/portfolio/hdr/1-after.jpg';
}

function quickAddPageCategory() {
  const name = document.getElementById('quickCatName').value.trim();
  if (!name) return;

  const select = document.getElementById('pageCategorySelect');
  const opt = document.createElement('option');
  opt.value = name;
  opt.textContent = name;
  opt.selected = true;
  select.appendChild(opt);

  // Send AJAX to create in background
  const formData = new FormData();
  formData.append('name', name);
  formData.append('type', 'page');
  formData.append('csrf_token', '<?= csrfToken() ?>');

  fetch('/admin/categories.php', { method: 'POST', body: formData });

  document.getElementById('quickCatName').value = '';
  document.getElementById('quickAddCatBox').classList.add('hidden');
}

function runReadabilityAudit() {
  const content = document.getElementById('editorVisual') ? document.getElementById('editorVisual').innerText : '';
  const words = content.trim().split(/\s+/).filter(w => w.length > 0);
  const wordCount = words.length;
  const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 0);
  const sentenceCount = sentences.length || 1;
  const avgWordsPerSentence = (wordCount / sentenceCount).toFixed(1);

  let readabilityScore = Math.max(0, Math.min(100, Math.round(206.835 - (1.015 * avgWordsPerSentence) - 30)));
  if (wordCount < 30) readabilityScore = 85;

  let readabilityLabel = '🟢 Good — Very Easy to Read & Fast to Scan';
  let scoreColor = 'text-emerald-400';
  if (readabilityScore < 50) {
    readabilityLabel = '🔴 Complex — Consider shorter sentences';
    scoreColor = 'text-red-400';
  } else if (readabilityScore < 70) {
    readabilityLabel = '🟡 Fairly Readable — Standard Web Reading';
    scoreColor = 'text-amber-400';
  }

  const scoreElem = document.getElementById('readabilityScoreDisplay');
  const labelElem = document.getElementById('readabilityLabelDisplay');
  const statsElem = document.getElementById('readabilityStatsDisplay');

  if (scoreElem) scoreElem.textContent = `${readabilityScore} / 100`;
  if (labelElem) {
    labelElem.textContent = readabilityLabel;
    labelElem.className = `text-xs font-bold ${scoreColor} mt-1`;
  }
  if (statsElem) {
    statsElem.textContent = `Total Words: ${wordCount} | Sentences: ${sentenceCount} | Avg Words/Sentence: ${avgWordsPerSentence}`;
  }
}

function insertCardSchemaTemplate(type) {
  const title = document.getElementById('pageTitleInput').value || 'Estate HDR Professional Real Estate Photo Editing';
  const slug = document.getElementById('pageSlugInput').value || 'page';
  const author = document.querySelector('input[name="author"]').value || 'Estate HDR Editorial Team';
  const dateStr = new Date().toISOString().split('T')[0];
  let schemaObj = {};

  if (type === 'faq') {
    schemaObj = {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": `What services are detailed on ${title}?`,
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Professional HDR image processing, twilight conversion, virtual staging, and floor planning."
          }
        },
        {
          "@type": "Question",
          "name": "How do I place an order for this service?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Simply sign up for a free client account and submit your raw images with custom instructions."
          }
        }
      ]
    };
  } else if (type === 'webpage') {
    schemaObj = {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": title,
      "url": `https://estatehdr.com/page.php?slug=${encodeURIComponent(slug)}`,
      "description": document.getElementById('pageMetaDesc').value || "Estate HDR dynamic page content.",
      "publisher": {
        "@type": "Organization",
        "name": "Estate HDR",
        "logo": {
          "@type": "ImageObject",
          "url": "https://estatehdr.com/assets/images/logo.png"
        }
      },
      "datePublished": dateStr,
      "dateModified": dateStr
    };
  } else if (type === 'business') {
    schemaObj = {
      "@context": "https://schema.org",
      "@type": "ProfessionalService",
      "name": "Estate HDR",
      "image": "https://estatehdr.com/assets/images/portfolio/hdr/1-after.jpg",
      "url": "https://estatehdr.com",
      "telephone": "+44 770 606 8176",
      "priceRange": "$0.68 - $15.00",
      "address": {
        "@type": "PostalAddress",
        "addressCountry": "US"
      }
    };
  } else if (type === 'howto') {
    schemaObj = {
      "@context": "https://schema.org",
      "@type": "HowTo",
      "name": `Step-by-step guide: ${title}`,
      "step": [
        {
          "@type": "HowToStep",
          "name": "Step 1: Capture Multiple Exposures",
          "text": "Set exposure bracketing on camera tripod at -2, 0, +2 EV."
        },
        {
          "@type": "HowToStep",
          "name": "Step 2: Submit to Estate HDR Portal",
          "text": "Submit RAW photos and receive guaranteed edited photos in 12 hours."
        }
      ]
    };
  }

  const area = document.getElementById('pageSchemaJson');
  if (area) {
    area.value = JSON.stringify(schemaObj, null, 2);
    if (window.EstateDialog) {
      EstateDialog.toast(`✨ ${type.toUpperCase()} Schema template generated!`, 'success');
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  window.EstateEditorMode = 'page';
  EstateEditor.init({
    editorId: 'editorVisual',
    textareaId: 'pageContent'
  });

  // Safely populate editorVisual from textarea to protect outer DOM
  const pageContentEl = document.getElementById('pageContent');
  const editorVisualEl = document.getElementById('editorVisual');
  if (pageContentEl && editorVisualEl && pageContentEl.value) {
    editorVisualEl.innerHTML = pageContentEl.value;
  }

  updateCounters();
  runReadabilityAudit();
});
</script>

</body>
</html>