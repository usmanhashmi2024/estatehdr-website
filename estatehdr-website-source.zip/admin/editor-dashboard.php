<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/saas-db.php';
requireAdmin();

// ── Handle God-Mode Delete Order (Owner / Super Admin) ────────────────────────
if (isset($_GET['delete_order_id'])) {
    if (!isOwner()) {
        setFlash('error', 'Only Owner/CEO has permission to delete production orders.');
        header("Location: /admin/editor-dashboard.php");
        exit;
    }
    $delOid = trim($_GET['delete_order_id']);
    deleteOrder($delOid);
    setFlash('success', "Order #{$delOid} permanently removed from all queues.");
    header("Location: /admin/editor-dashboard.php");
    exit;
}


$currentAdmin = currentAdminUser();
$adminRoles   = getAdminRoles();
$editorId     = $currentAdmin['id'] ?? 'adm-5';
$editorName   = $currentAdmin['name'] ?? 'Photo Editor';

$allOrders = getSaaSOrders();

// For owners/managers show all; for editors show only assigned to them
$isPrivileged = in_array('owner', $adminRoles) || in_array('super_admin', $adminRoles)
             || in_array('manager', $adminRoles) || in_array('production_manager', $adminRoles);
$myOrders = $isPrivileged
    ? $allOrders
    : array_values(array_filter($allOrders, fn($o) => ($o['assigned_editor_id'] ?? '') === $editorId));

// ── Date filter ─────────────────────────────────────────────────────────────
$dateFilter = trim($_GET['date'] ?? 'today');
if ($dateFilter === 'today') {
    $dateStr = date('Y-m-d');
} elseif ($dateFilter === 'week') {
    $dateStr = '';  // show all week
} else {
    $dateStr = $dateFilter; // specific Y-m-d
}

// Build unique dates from orders (created_at date)
$uniqueDates = [];
foreach ($myOrders as $o) {
    $d = substr($o['created_at'] ?? '', 0, 10);
    if ($d) $uniqueDates[$d] = true;
}
krsort($uniqueDates);

// Filter orders by date unless "all"
$filteredOrders = $myOrders;
if ($dateFilter === 'today') {
    $filteredOrders = array_values(array_filter($myOrders, fn($o) => substr($o['created_at'] ?? '', 0, 10) === date('Y-m-d')));
    // If today has no orders, show all (so editor is not confused)
    if (empty($filteredOrders)) $filteredOrders = $myOrders;
}

// ── Status sections ─────────────────────────────────────────────────────────
$sections = [
    'new_assigned'  => ['label' => 'New / Assigned',        'color' => 'text-amber-400',   'border' => 'border-amber-500/30',   'bg' => 'bg-amber-950/10',   'statuses' => ['assigned_editor', 'new']],
    'in_process'    => ['label' => 'In Process',            'color' => 'text-blue-400',    'border' => 'border-blue-500/30',    'bg' => 'bg-blue-950/10',    'statuses' => ['in_process']],
    'revision'      => ['label' => 'Revision Required',     'color' => 'text-red-400',     'border' => 'border-red-500/30',     'bg' => 'bg-red-950/10',     'statuses' => ['revision_required']],
    'submitted_qa'  => ['label' => 'Submitted for QA',      'color' => 'text-purple-400',  'border' => 'border-purple-500/30',  'bg' => 'bg-purple-950/10',  'statuses' => ['submitted_qa', 'resubmitted']],
    'approved'      => ['label' => 'Approved / Completed',  'color' => 'text-emerald-400', 'border' => 'border-emerald-500/30', 'bg' => 'bg-emerald-950/10', 'statuses' => ['approved', 'ready_delivery', 'sent_client', 'completed']],
];

function ordersInSection(array $orders, array $statuses): array {
    return array_values(array_filter($orders, fn($o) => in_array($o['status'] ?? '', $statuses)));
}

// ── KPIs ────────────────────────────────────────────────────────────────────
$todayOrders   = array_values(array_filter($myOrders, fn($o) => substr($o['created_at'] ?? '', 0, 10) === date('Y-m-d')));
$completedToday= count(array_filter($todayOrders, fn($o) => in_array($o['status'] ?? '', ['approved','sent_client','completed'])));
$totalActive   = count(ordersInSection($filteredOrders, ['assigned_editor','new','in_process','revision_required']));
$inProcessCount= count(ordersInSection($filteredOrders, ['in_process']));
$revisionCount = count(ordersInSection($filteredOrders, ['revision_required']));
$submittedCount= count(ordersInSection($filteredOrders, ['submitted_qa','resubmitted']));
$approvedCount = count(ordersInSection($filteredOrders, ['approved','ready_delivery','sent_client','completed']));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Editor Workspace — Estate HDR Production SaaS</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8 space-y-6">
  <?= renderFlash() ?>

  <!-- ── HEADER ──────────────────────────────────────────────────── -->
  <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
    <div>
      <div class="section-tag mb-1">Production Execution Center</div>
      <h1 class="text-2xl sm:text-3xl font-black text-white">EDITOR WORKSPACE</h1>
      <p class="text-gray-400 text-xs mt-1">
        Logged in as: <strong class="text-gold"><?= htmlspecialchars($editorName) ?></strong>
        &bull; <span class="text-emerald-400 font-bold">🔒 Strict Privacy Mode Active</span>
      </p>
    </div>
    <div class="flex items-center gap-4 p-3 rounded-2xl bg-dark-card border border-dark-border">
      <div class="text-center">
        <span class="text-[11px] text-gray-400 block uppercase font-bold">Quality Score</span>
        <span class="text-lg font-mono font-black text-emerald-400">96.5%</span>
      </div>
      <div class="h-8 w-px bg-dark-border"></div>
      <div class="text-center">
        <span class="text-[11px] text-gray-400 block uppercase font-bold">Completed Today</span>
        <span class="text-lg font-mono font-black text-gold"><?= $completedToday ?></span>
      </div>
      <div class="h-8 w-px bg-dark-border"></div>
      <div class="text-center">
        <span class="text-[11px] text-gray-400 block uppercase font-bold">Avg TAT</span>
        <span class="text-lg font-mono font-black text-blue-300">2.4h</span>
      </div>
    </div>
  </div>

  <!-- ── KPI COUNTERS ───────────────────────────────────────────── -->
  <div class="grid grid-cols-2 sm:grid-cols-5 gap-3">
    <?php foreach ($sections as $key => $sec): 
      $cnt = count(ordersInSection($filteredOrders, $sec['statuses']));
    ?>
    <div class="glass-card rounded-2xl p-4 border <?= $sec['border'] ?> <?= $sec['bg'] ?> space-y-1">
      <span class="text-[11px] <?= $sec['color'] ?> uppercase font-bold"><?= $sec['label'] ?></span>
      <div class="text-2xl font-black text-white"><?= $cnt ?></div>
      <?php if ($key === 'revision'): ?>
        <span class="text-[11px] text-red-400 font-bold">⚠ Action Needed</span>
      <?php elseif ($key === 'in_process'): ?>
        <span class="text-[11px] text-blue-400 font-bold">Currently Editing</span>
      <?php else: ?>
        <span class="text-[11px] text-gray-400">Jobs</span>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- ── DATE FILTER TABS ──────────────────────────────────────── -->
  <div class="glass-card rounded-2xl p-4 border border-dark-border">
    <div class="flex flex-wrap items-center gap-2 text-xs font-bold">
      <span class="text-gray-400 mr-1 uppercase tracking-wider">Filter by Date:</span>

      <a href="?date=today" class="px-3 py-1.5 rounded-xl <?= $dateFilter === 'today' ? 'bg-gold text-dark font-black shadow-glow' : 'bg-dark border border-dark-border text-gray-300 hover:text-white' ?>">
        Today (<?= date('M j') ?>)
      </a>

      <?php foreach (array_keys($uniqueDates) as $d): ?>
        <?php if ($d === date('Y-m-d')) continue; ?>
        <a href="?date=<?= urlencode($d) ?>" class="px-3 py-1.5 rounded-xl <?= $dateFilter === $d ? 'bg-gold text-dark font-black shadow-glow' : 'bg-dark border border-dark-border text-gray-300 hover:text-white' ?>">
          <?= date('M j, Y', strtotime($d)) ?>
        </a>
      <?php endforeach; ?>

      <a href="?date=all" class="px-3 py-1.5 rounded-xl <?= $dateFilter === 'all' ? 'bg-gold text-dark font-black shadow-glow' : 'bg-dark border border-dark-border text-gray-300 hover:text-white' ?>">
        All Orders
      </a>

      <span class="ml-auto text-gray-400 font-mono"><?= count($filteredOrders) ?> orders</span>
    </div>
  </div>

  <!-- ── STATUS SECTIONS ────────────────────────────────────────── -->
  <?php foreach ($sections as $key => $sec):
    $sectionOrders = ordersInSection($filteredOrders, $sec['statuses']);
    if (empty($sectionOrders) && $key !== 'new_assigned') continue;
  ?>
  <div class="glass-card rounded-3xl border <?= $sec['border'] ?> <?= $sec['bg'] ?> shadow-xl overflow-hidden">
    <!-- Section Header -->
    <div class="flex items-center justify-between px-6 py-4 border-b border-dark-border">
      <div class="flex items-center gap-3">
        <div class="w-2.5 h-2.5 rounded-full <?= str_replace('text-','bg-', $sec['color']) ?>
          <?= $key === 'revision' ? 'animate-ping' : '' ?>"></div>
        <h3 class="font-bold <?= $sec['color'] ?> uppercase text-xs tracking-wider"><?= $sec['label'] ?></h3>
        <span class="px-2 py-0.5 rounded-full bg-dark border border-dark-border text-white text-[11px] font-mono font-bold"><?= count($sectionOrders) ?></span>
      </div>
    </div>

    <?php if (empty($sectionOrders)): ?>
      <div class="px-6 py-8 text-center text-gray-500 text-xs">
        <?= $key === 'new_assigned' ? 'No new jobs assigned — all caught up! 🎉' : '' ?>
      </div>
    <?php else: ?>
    <div class="overflow-x-auto">
      <table class="dashboard-table w-full text-left text-xs">
        <thead>
          <tr>
            <th>ORDER ID</th>
            <th>PROPERTY</th>
            <th>TYPE</th>
            <th>PHOTOS</th>
            <th>PRIORITY</th>
            <th>DEADLINE</th>
            <th>LOCK STATUS</th>
            <th class="text-right">ACTION</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($sectionOrders as $o):
            $masked    = maskOrderForRole($o, $adminRoles);
            $isLocked  = !empty($o['locked_by_id']);
            $lockedByMe= $isLocked && ($o['locked_by_id'] === $editorId);
            $isRevSub  = !empty($o['is_revision_resubmit']);
          ?>
          <tr class="hover:bg-white/[0.02] <?= $isLocked && !$lockedByMe ? 'opacity-60' : '' ?>">
            <td>
              <span class="font-mono font-bold text-gold"><?= htmlspecialchars($masked['id']) ?></span>
              <?php if ($isRevSub && $masked['status'] === 'resubmitted'): ?>
                <span class="ml-1 px-1.5 py-0.5 rounded text-[9px] bg-blue-500/20 text-blue-300 border border-blue-500/30 font-bold">REVISION DONE</span>
              <?php endif; ?>
            </td>
            <td>
              <div class="font-bold text-white"><?= htmlspecialchars($masked['property_ref']) ?></div>
              <div class="text-gray-400 text-[11px]"><?= htmlspecialchars($masked['property_name']) ?></div>
            </td>
            <td><span class="px-2 py-0.5 rounded bg-dark border border-dark-border text-gray-300"><?= htmlspecialchars($masked['editing_type']) ?></span></td>
            <td class="font-mono font-bold text-white"><?= $masked['photo_count'] ?></td>
            <td>
              <?php if ($masked['priority'] === 'urgent'): ?>
                <span class="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/40 font-bold uppercase text-[11px]">URGENT</span>
              <?php elseif ($masked['priority'] === 'high'): ?>
                <span class="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/40 font-bold uppercase text-[11px]">HIGH</span>
              <?php else: ?>
                <span class="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 border border-blue-500/30 font-bold uppercase text-[11px]"><?= strtoupper($masked['priority']) ?></span>
              <?php endif; ?>
            </td>
            <td class="font-mono text-gray-400"><?= date('M j, H:i', strtotime($masked['deadline'])) ?></td>
            <td>
              <?php if ($lockedByMe): ?>
                <span class="inline-flex items-center gap-1 text-[11px] font-bold text-blue-400">
                  <span class="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse"></span> You are editing
                </span>
              <?php elseif ($isLocked): ?>
                <span class="inline-flex items-center gap-1 text-[11px] font-bold text-red-400">
                  <span class="w-1.5 h-1.5 rounded-full bg-red-400"></span> In use: <?= htmlspecialchars($o['locked_by_name']) ?>
                </span>
              <?php else: ?>
                <span class="text-[11px] text-gray-500">Available</span>
              <?php endif; ?>
            </td>
            <td class="text-right">
              <?php if (in_array($masked['status'] ?? '', ['approved','sent_client','completed'])): ?>
                <span class="px-2.5 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[11px] font-bold">✓ Approved</span>
              <?php elseif (in_array($masked['status'] ?? '', ['submitted_qa','resubmitted'])): ?>
                <span class="px-2.5 py-1.5 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30 text-[11px] font-bold">⏳ TL Reviewing</span>
              <?php else: ?>
                <a href="/admin/editor-order.php?id=<?= urlencode($masked['id']) ?>"
                   class="btn-gold py-1.5 px-4 text-xs font-black shadow-glow inline-flex items-center gap-1.5 <?= ($isLocked && !$lockedByMe) ? 'opacity-40 pointer-events-none' : '' ?>">
                  <?= $masked['status'] === 'revision_required' ? '🔁 Fix Revision' : '▶ Open Job' ?> <span>&rarr;</span>
                </a>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>

</main>

<!-- GOD MODE DELETE MODAL -->
<div id="edDeleteModal" class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 max-w-md w-full border border-red-500/50 shadow-2xl space-y-4">
    <div class="flex items-center gap-3">
      <div class="w-10 h-10 rounded-2xl bg-red-600/20 border border-red-500 flex items-center justify-center text-xl">🗑️</div>
      <div>
        <h3 class="text-base font-black text-white">Permanently Delete Order?</h3>
        <p class="text-xs text-gray-400">Removed from all queues, CRM, and server storage.</p>
      </div>
    </div>
    <div class="p-3.5 rounded-2xl bg-red-950/30 border border-red-800/50 text-xs text-red-200">
      Order: <strong id="edDelTitle" class="text-white"></strong> &nbsp;(<span id="edDelId" class="font-mono text-gold font-bold"></span>)
    </div>
    <div class="flex items-center justify-end gap-3 pt-2">
      <button type="button" onclick="document.getElementById('edDeleteModal').classList.add('hidden')" class="btn-ghost py-2.5 px-4 text-xs font-bold">Cancel</button>
      <a id="edDelConfirmBtn" href="#" class="py-2.5 px-5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs shadow-lg transition-all inline-flex items-center gap-1.5">
        🗑️ Yes, Delete
      </a>
    </div>
  </div>
</div>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
function openEDDeleteModal(oid, title) {
  document.getElementById('edDelId').textContent = '#' + oid;
  document.getElementById('edDelTitle').textContent = title;
  document.getElementById('edDelConfirmBtn').href = '/admin/editor-dashboard.php?delete_order_id=' + encodeURIComponent(oid);
  document.getElementById('edDeleteModal').classList.remove('hidden');
}
</script>

</body>
</html>
