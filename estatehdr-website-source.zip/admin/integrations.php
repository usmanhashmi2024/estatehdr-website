<?php
/**
 * Estate HDR - Integration Marketplace & Webhook Hub
 * Enterprise Layer: Integrations Marketplace (Zapier, Dropbox, Drive, Slack)
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireAdmin();

$intFile = __DIR__ . '/../data/integrations_settings.json';
if (!file_exists($intFile)) {
    $defaults = [
        'dropbox' => ['enabled' => true, 'connected_account' => 'production@estatehdr.com', 'auto_sync' => true],
        'google_drive' => ['enabled' => true, 'connected_account' => 'storage@estatehdr.com', 'auto_sync' => true],
        'zapier' => ['enabled' => true, 'active_zaps' => 4],
        'slack' => ['enabled' => true, 'channel' => '#ops-alerts-live'],
        'frame_io' => ['enabled' => false, 'status' => 'available'],
        'real_estate_api' => ['enabled' => true, 'base_url' => 'https://estatehdr.com/api/v1/']
    ];
    @file_put_contents($intFile, json_encode($defaults, JSON_PRETTY_PRINT));
}

$integrations = json_decode(@file_get_contents($intFile), true) ?: [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Integration Hub &amp; Marketplace — Estate HDR</title>
    <link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
        tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E',light:'#E5C05D'},dark:{DEFAULT:'#0B0E14',card:'#121721',border:'#1F2937'}}}}};
    </script>
    <link rel="stylesheet" href="/assets/css/app.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-[#0B0E14] text-gray-200 font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-6 py-8 space-y-6">
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-gray-800 pb-6">
        <div>
            <div class="text-xs uppercase font-extrabold tracking-widest text-gold mb-1">
                <span>CONNECTORS &amp; ECOSYSTEM</span>
            </div>
            <h1 class="text-2xl sm:text-3xl font-black text-white">Integration Hub &amp; Marketplace</h1>
            <p class="text-xs text-gray-400 mt-1">Connect Estate HDR directly to client CRMs, cloud storage, automation tools, and messaging channels.</p>
        </div>
    </div>

    <!-- Integrations Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <!-- Dropbox -->
        <div class="bg-[#121721] p-6 rounded-2xl border border-gray-800 space-y-4">
            <div class="flex justify-between items-start">
                <div class="w-12 h-12 rounded-xl bg-blue-600/10 text-blue-400 flex items-center justify-center text-2xl font-bold">
                    <i class="fab fa-dropbox"></i>
                </div>
                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    Active Sync
                </span>
            </div>
            <div>
                <h3 class="text-sm font-bold text-white">Dropbox Business</h3>
                <p class="text-xs text-gray-400 mt-1">Automatically mirrors all high-resolution bracket uploads and finished retouched exports.</p>
            </div>
            <div class="text-[11px] text-gray-500 border-t border-gray-800 pt-2 font-mono">
                Connected: <?= htmlspecialchars($integrations['dropbox']['connected_account'] ?? 'Active') ?>
            </div>
        </div>

        <!-- Google Drive -->
        <div class="bg-[#121721] p-6 rounded-2xl border border-gray-800 space-y-4">
            <div class="flex justify-between items-start">
                <div class="w-12 h-12 rounded-xl bg-emerald-600/10 text-emerald-400 flex items-center justify-center text-2xl font-bold">
                    <i class="fab fa-google-drive"></i>
                </div>
                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    Connected
                </span>
            </div>
            <div>
                <h3 class="text-sm font-bold text-white">Google Workspace Drive</h3>
                <p class="text-xs text-gray-400 mt-1">Instant delivery folder generation with client shareable links.</p>
            </div>
            <div class="text-[11px] text-gray-500 border-t border-gray-800 pt-2 font-mono">
                Connected: <?= htmlspecialchars($integrations['google_drive']['connected_account'] ?? 'Active') ?>
            </div>
        </div>

        <!-- Zapier / Make -->
        <div class="bg-[#121721] p-6 rounded-2xl border border-gray-800 space-y-4">
            <div class="flex justify-between items-start">
                <div class="w-12 h-12 rounded-xl bg-amber-600/10 text-amber-400 flex items-center justify-center text-2xl font-bold">
                    <i class="fas fa-bolt"></i>
                </div>
                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    4 Active Zaps
                </span>
            </div>
            <div>
                <h3 class="text-sm font-bold text-white">Zapier &amp; Make.com</h3>
                <p class="text-xs text-gray-400 mt-1">Automate CRM sync (HubSpot, Salesforce, GoHighLevel) on order completion.</p>
            </div>
            <div class="text-[11px] text-gray-500 border-t border-gray-800 pt-2 font-mono">
                Webhook trigger: order.delivered
            </div>
        </div>

        <!-- Slack -->
        <div class="bg-[#121721] p-6 rounded-2xl border border-gray-800 space-y-4">
            <div class="flex justify-between items-start">
                <div class="w-12 h-12 rounded-xl bg-purple-600/10 text-purple-400 flex items-center justify-center text-2xl font-bold">
                    <i class="fab fa-slack"></i>
                </div>
                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    Live Channel
                </span>
            </div>
            <div>
                <h3 class="text-sm font-bold text-white">Slack Ops Alerts</h3>
                <p class="text-xs text-gray-400 mt-1">Real-time alerts for 90% SLA escalation and QA revision notices.</p>
            </div>
            <div class="text-[11px] text-gray-500 border-t border-gray-800 pt-2 font-mono">
                Channel: <?= htmlspecialchars($integrations['slack']['channel'] ?? '#ops') ?>
            </div>
        </div>

        <!-- Real Estate Media API -->
        <div class="bg-[#121721] p-6 rounded-2xl border border-gray-800 space-y-4">
            <div class="flex justify-between items-start">
                <div class="w-12 h-12 rounded-xl bg-gold/10 text-gold flex items-center justify-center text-2xl font-bold">
                    <i class="fas fa-terminal"></i>
                </div>
                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-gold/10 text-gold border border-gold/30">
                    REST API v1
                </span>
            </div>
            <div>
                <h3 class="text-sm font-bold text-white">Direct REST API</h3>
                <p class="text-xs text-gray-400 mt-1">Programmatic order intake, webhook events, and idempotent duplicate protection.</p>
            </div>
            <div class="text-[11px] text-gray-500 border-t border-gray-800 pt-2 font-mono">
                Base: <?= htmlspecialchars($integrations['real_estate_api']['base_url'] ?? '/api/v1/') ?>
            </div>
        </div>
        <!-- Discord & AI RAG Brain -->
        <div class="bg-[#121721] p-6 rounded-2xl border-2 border-purple-500/40 space-y-4 relative overflow-hidden">
            <div class="absolute -top-10 -right-10 w-24 h-24 bg-purple-500/10 rounded-full blur-2xl pointer-events-none"></div>
            <div class="flex justify-between items-start">
                <div class="w-12 h-12 rounded-xl bg-purple-600/20 text-purple-400 flex items-center justify-center text-2xl font-bold">
                    <i class="fab fa-discord"></i>
                </div>
                <span class="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40">
                    Live RAG Brain
                </span>
            </div>
            <div>
                <h3 class="text-sm font-bold text-white">Discord &amp; AI RAG Concierge</h3>
                <p class="text-xs text-gray-400 mt-1">Live chat pre-gate leads, 22+ RAG knowledge articles, and automated conversation dossiers sent directly to your Discord channel.</p>
            </div>
            <div class="pt-2 border-t border-gray-800 flex items-center justify-between text-[11px]">
                <span class="text-emerald-400 font-mono font-bold">● Active 24/7</span>
                <a href="/admin/ai-brain.php" class="text-gold font-bold hover:underline flex items-center gap-1">
                    <span>Configure AI Brain</span> &rarr;
                </a>
            </div>
        </div>
    </div>
</main>

</body>
</html>
