<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/saas-db.php';
requireAdmin();

$currentAdmin = currentAdminUser();
$adminRoles   = getAdminRoles();
$isOwner      = in_array('owner', $adminRoles) || in_array('super_admin', $adminRoles);
$isHR         = in_array('hr', $adminRoles) || $isOwner;

// ── Complete Data Purging for Employee (Owner / God Rights) ──────────────────
if (isset($_GET['delete_emp'])) {
    if (!$isOwner) {
        setFlash('error', 'Access Denied: Only the CEO/Owner can permanently remove staff employees.');
        header("Location: /admin/hr-dashboard.php");
        exit;
    }
    $delEmpId = trim($_GET['delete_emp']);
    
    // 1. Find employee info
    $employees = getSaaSEmployees();
    $targetEmail = '';
    $targetUserId = '';
    foreach ($employees as $e) {
        if ($e['id'] === $delEmpId || ($e['user_id'] ?? '') === $delEmpId) {
            $targetEmail  = strtolower($e['email'] ?? '');
            $targetUserId = $e['user_id'] ?? $e['id'];
            break;
        }
    }
    
    // 2. Remove from saas_employees.json
    $filteredEmps = array_values(array_filter($employees, fn($e) => $e['id'] !== $delEmpId && ($e['user_id'] ?? '') !== $delEmpId && ($targetEmail === '' || strtolower($e['email'] ?? '') !== $targetEmail)));
    saveSaaSEmployees($filteredEmps);
    
    // 3. Remove login credentials from admin_users.json
    if (!empty($targetUserId)) {
        deleteAdminUser($targetUserId);
    } elseif ($targetEmail !== '') {
        $admUsers = getAdminUsers();
        $filteredAdm = array_values(array_filter($admUsers, fn($u) => strtolower($u['email'] ?? '') !== $targetEmail && ($u['id'] ?? '') !== $delEmpId));
        saveAdminUsers($filteredAdm);
    }
    
    // 4. Remove attendance logs
    $attFile = DATA_PATH . 'saas_attendance.json';
    if (file_exists($attFile)) {
        $attLogs = readJson($attFile);
        if (is_array($attLogs)) {
            $filteredAtt = array_values(array_filter($attLogs, fn($a) => ($a['employee_id'] ?? '') !== $delEmpId));
            writeJson($attFile, $filteredAtt);
        }
    }
    
    setFlash('success', "Employee record \"{$delEmpId}\" and corresponding credentials permanently deleted.");
    header("Location: /admin/hr-dashboard.php");
    exit;
}

if (!$isHR) {
    setFlash('error', 'Access Denied: Restricted to Human Resources Department.');
    header("Location: /admin/");
    exit;
}

$viewMode     = trim($_GET['view'] ?? 'staff'); // 'staff' | 'attendance'
$selectedDate = trim($_GET['date'] ?? date('Y-m-d'));

// ── 1. POST: Save / Enroll Employee Profile (New Hire or Edit) ───────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_save_employee'])) {
    verifyCsrf();
    
    $empId   = trim($_POST['emp_id'] ?? '');
    $name    = trim($_POST['name'] ?? '');
    $email   = strtolower(trim($_POST['email'] ?? ''));
    $phone   = trim($_POST['phone'] ?? '');
    $role    = trim($_POST['role'] ?? 'Photo Editor');
    $shift   = trim($_POST['shift'] ?? 'Morning (09:00 AM - 06:00 PM)');
    
    if (empty($name) || empty($email)) {
        setFlash('error', 'Employee Full Name and Email are mandatory.');
        header("Location: /admin/hr-dashboard.php");
        exit;
    }
    
    $employees = getSaaSEmployees();
    $isNew = empty($empId);
    if ($isNew) {
        $prefix = match($role) {
            'Team Lead'          => 'EMP-TL-',
            'Supervisor'         => 'EMP-SUP-',
            'Production Manager' => 'EMP-MGR-',
            'SEO Manager'        => 'EMP-SEO-',
            'HR Officer'         => 'EMP-HR-',
            default              => 'EMP-ED-'
        };
        $empId = $prefix . sprintf('%02d', count($employees) + 1);
    }
    
    // Parse Skills array from comma-separated string
    $skillsRaw = trim($_POST['skills'] ?? '');
    $skills = array_filter(array_map('trim', explode(',', $skillsRaw)));
    if (empty($skills)) $skills = ['HDR Photo Editing', 'Color Correction'];
    
    $basicSalary     = (float)($_POST['basic_salary'] ?? 650.0);
    $rentAllowance   = (float)($_POST['rent_allowance'] ?? 80.0);
    $otherAllowances = (float)($_POST['other_allowances'] ?? 40.0);
    $bonus           = (float)($_POST['bonus'] ?? 0.0);
    $deductions      = (float)($_POST['deductions'] ?? 0.0);
    $expectedSalary  = (float)($_POST['expected_salary'] ?? 800.0);
    $currency        = trim($_POST['currency'] ?? 'PKR');
    $netSalary       = ($basicSalary + $rentAllowance + $otherAllowances + $bonus) - $deductions;
    
    $profileData = [
        'id'                  => $empId,
        'user_id'             => trim($_POST['user_id'] ?? ('adm-' . uniqid())),
        'name'                => $name,
        'email'               => $email,
        'phone'               => $phone,
        'role'                => $role,
        'department'          => trim($_POST['department'] ?? 'Production'),
        'shift'               => $shift,
        'shift_hours'         => 9,
        
        // 📌 1. Personal Info
        'age'                 => (int)($_POST['age'] ?? 26),
        'blood_group'         => trim($_POST['blood_group'] ?? 'O+'),
        'location_timezone'   => trim($_POST['location_timezone'] ?? 'Lahore, PK (GMT+5)'),
        'portfolio_links'     => trim($_POST['portfolio_links'] ?? ''),
        'source'              => trim($_POST['source'] ?? 'Direct Application'),
        
        // 💼 2. Work & Status
        'status'              => trim($_POST['status'] ?? 'Active'),
        'experience_timeline' => trim($_POST['experience_timeline'] ?? ''),
        'skills'              => array_values($skills),
        'work_samples_url'    => trim($_POST['work_samples_url'] ?? ''),
        
        // 💰 3. Salary & Payroll
        'basic_salary'        => $basicSalary,
        'rent_allowance'      => $rentAllowance,
        'other_allowances'    => $otherAllowances,
        'bonus'               => $bonus,
        'deductions'          => $deductions,
        'expected_salary'     => $expectedSalary,
        'currency'            => $currency,
        'net_salary'          => $netSalary,
        
        // 📊 4. HR & Admin
        'interview_notes'     => trim($_POST['interview_notes'] ?? ''),
        'hiring_stage'        => trim($_POST['hiring_stage'] ?? 'Hired / Onboarded'),
        'communication_log'   => trim($_POST['communication_log'] ?? ''),
        'background_check'    => trim($_POST['background_check'] ?? 'Verified'),
        'official_docs'       => trim($_POST['official_docs'] ?? 'NDA Signed'),
        
        'quality_score'       => (float)($_POST['quality_score'] ?? 96.5),
        'productivity_score'  => (float)($_POST['productivity_score'] ?? 95.0),
        'updated_at'          => date('c')
    ];
    
    // Save to employees json
    $found = false;
    foreach ($employees as &$emp) {
        if ($emp['id'] === $empId || ($emp['email'] ?? '') === $email) {
            $emp = array_merge($emp, $profileData);
            $found = true;
            break;
        }
    }
    if (!$found) {
        $employees[] = $profileData;
    }
    saveSaaSEmployees($employees);
    
    // Sync into admin_users.json so credentials work
    $roleMap = [
        'Photo Editor'       => 'photo_editor',
        'Team Lead'          => 'team_lead',
        'Supervisor'         => 'supervisor',
        'Production Manager' => 'manager',
        'SEO Manager'        => 'seo_manager',
        'HR Officer'         => 'hr'
    ];
    $adminRole = $roleMap[$role] ?? 'photo_editor';
    $newPass = trim($_POST['password'] ?? '');
    
    $adminUserData = [
        'id'        => $profileData['user_id'],
        'name'      => $name,
        'email'     => $email,
        'phone'     => $phone,
        'roles'     => [$adminRole],
        'is_active' => ($profileData['status'] === 'Active' || $profileData['status'] === 'On Probation')
    ];
    if (!empty($newPass)) {
        $adminUserData['password'] = $newPass;
    }
    saveAdminUser($adminUserData);
    
    logSaaSEvent($currentAdmin['id'] ?? 'adm-6', ($isNew ? 'New employee hired' : 'Employee profile updated') . ": $name ($empId)", $empId, $profileData);
    setFlash('success', "Employee profile for \"$name\" ($empId) saved successfully!");
    header("Location: /admin/hr-dashboard.php");
    exit;
}

// ── 2. POST: Mark Single Attendance ──────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_mark_attendance'])) {
    verifyCsrf();
    $empId       = trim($_POST['employee_id'] ?? '');
    $attDate     = trim($_POST['date'] ?? date('Y-m-d'));
    $status      = trim($_POST['status'] ?? 'Present');
    $checkIn     = trim($_POST['check_in'] ?? '09:00 AM');
    $checkOut    = trim($_POST['check_out'] ?? '');
    $lateMinutes = (int)($_POST['late_minutes'] ?? 0);
    $notes       = trim($_POST['notes'] ?? '');

    $recId = 'ATT-' . str_replace('-', '', $attDate) . '-' . $empId;
    $record = [
        'id'             => $recId,
        'employee_id'    => $empId,
        'date'           => $attDate,
        'shift'          => trim($_POST['shift'] ?? '09:00 AM - 06:00 PM'),
        'check_in'       => ($status === 'Absent' || $status === 'On Leave') ? '—' : $checkIn,
        'check_out'      => $checkOut,
        'total_hours'    => ($status === 'Absent' || $status === 'On Leave') ? 0.0 : 9.0,
        'late_minutes'   => ($status === 'Late') ? max(1, $lateMinutes) : 0,
        'overtime_hours' => 0.0,
        'status'         => $status,
        'notes'          => $notes ?: ($status === 'Present' ? 'On time' : ucfirst($status)),
        'recorded_by'    => $currentAdmin['name'] ?? 'HR Officer',
        'updated_at'     => date('c')
    ];
    saveSaaSAttendanceRecord($record);
    logSaaSEvent($currentAdmin['id'] ?? 'adm-6', "Attendance marked for $empId on $attDate ($status)", $recId);

    setFlash('success', "Attendance updated for employee #$empId ($status)!");
    header("Location: /admin/hr-dashboard.php?view=attendance&date=" . urlencode($attDate));
    exit;
}

// ── 3. POST: Bulk Mark Active Staff as Present ──────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_bulk_mark_present'])) {
    verifyCsrf();
    $attDate    = trim($_POST['date'] ?? date('Y-m-d'));
    $employees  = getSaaSEmployees();
    $existing   = getSaaSAttendance($attDate);
    $existingMap= [];
    foreach ($existing as $ex) {
        $existingMap[$ex['employee_id']] = $ex;
    }

    $marked = 0;
    foreach ($employees as $e) {
        $empId = $e['id'] ?? $e['user_id'];
        if (!isset($existingMap[$empId])) {
            $recId = 'ATT-' . str_replace('-', '', $attDate) . '-' . $empId;
            $record = [
                'id'             => $recId,
                'employee_id'    => $empId,
                'date'           => $attDate,
                'shift'          => $e['shift'] ?? '09:00 AM - 06:00 PM',
                'check_in'       => '08:55 AM',
                'check_out'      => '',
                'total_hours'    => 9.0,
                'late_minutes'   => 0,
                'overtime_hours' => 0.0,
                'status'         => 'Present',
                'notes'          => 'Bulk marked on-time by HR',
                'recorded_by'    => $currentAdmin['name'] ?? 'HR Officer',
                'updated_at'     => date('c')
            ];
            saveSaaSAttendanceRecord($record);
            $marked++;
        }
    }
    setFlash('success', "Marked all $marked active staff as Present on $attDate!");
    header("Location: /admin/hr-dashboard.php?view=attendance&date=" . urlencode($attDate));
    exit;
}

$employees  = getSaaSEmployees();
$hrContracts = function_exists('getHRContracts') ? getHRContracts() : [];
$signedHrContracts = count(array_filter($hrContracts, fn($c) => ($c['status'] ?? '') === 'signed'));
$attendance = getSaaSAttendance($selectedDate);
$attMap     = [];
foreach ($attendance as $a) {
    $attMap[$a['employee_id']] = $a;
}

// Attendance KPIs
$totalEmployees = count($employees);
$presentCount   = count(array_filter($attendance, fn($a) => ($a['status'] ?? '') === 'Present'));
$lateCount      = count(array_filter($attendance, fn($a) => ($a['status'] ?? '') === 'Late' || ($a['late_minutes'] ?? 0) > 0));
$leaveCount     = count(array_filter($attendance, fn($a) => in_array($a['status'] ?? '', ['On Leave', 'Half Day', 'Leave'])));
$absentCount    = count(array_filter($attendance, fn($a) => ($a['status'] ?? '') === 'Absent'));
$unmarkedCount  = max(0, $totalEmployees - count($attendance));
$attendanceRate = $totalEmployees > 0 ? round((($presentCount + $lateCount) / $totalEmployees) * 100, 1) : 100;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HR &amp; People Operations — Estate HDR</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com">
function setShiftPreset(type, start, end, label) {
  if (document.getElementById('fShiftType')) document.getElementById('fShiftType').value = type;
  if (document.getElementById('fShiftStart')) document.getElementById('fShiftStart').value = start;
  if (document.getElementById('fShiftEnd')) document.getElementById('fShiftEnd').value = end;
  buildCustomShiftString(label);
}

function buildCustomShiftString(customLabel) {
  const type = document.getElementById('fShiftType')?.value || 'Day';
  const start = document.getElementById('fShiftStart')?.value || '09:00 AM';
  const end = document.getElementById('fShiftEnd')?.value || '06:00 PM';
  
  let label = customLabel;
  if (!label) {
    if (type === 'Night') label = 'Night Shift';
    else if (type === 'Evening') label = 'Evening Shift';
    else if (type === 'Rotational') label = 'Rotational Shift';
    else label = 'Day Shift';
  }
  
  const fullShift = `${type} Shift (${start} - ${end})`;
  if (document.getElementById('fShift')) {
    document.getElementById('fShift').value = fullShift;
  }
}

</script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}
function setShiftPreset(type, start, end, label) {
  if (document.getElementById('fShiftType')) document.getElementById('fShiftType').value = type;
  if (document.getElementById('fShiftStart')) document.getElementById('fShiftStart').value = start;
  if (document.getElementById('fShiftEnd')) document.getElementById('fShiftEnd').value = end;
  buildCustomShiftString(label);
}

function buildCustomShiftString(customLabel) {
  const type = document.getElementById('fShiftType')?.value || 'Day';
  const start = document.getElementById('fShiftStart')?.value || '09:00 AM';
  const end = document.getElementById('fShiftEnd')?.value || '06:00 PM';
  
  let label = customLabel;
  if (!label) {
    if (type === 'Night') label = 'Night Shift';
    else if (type === 'Evening') label = 'Evening Shift';
    else if (type === 'Rotational') label = 'Rotational Shift';
    else label = 'Day Shift';
  }
  
  const fullShift = `${type} Shift (${start} - ${end})`;
  if (document.getElementById('fShift')) {
    document.getElementById('fShift').value = fullShift;
  }
}

</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js">
function setShiftPreset(type, start, end, label) {
  if (document.getElementById('fShiftType')) document.getElementById('fShiftType').value = type;
  if (document.getElementById('fShiftStart')) document.getElementById('fShiftStart').value = start;
  if (document.getElementById('fShiftEnd')) document.getElementById('fShiftEnd').value = end;
  buildCustomShiftString(label);
}

function buildCustomShiftString(customLabel) {
  const type = document.getElementById('fShiftType')?.value || 'Day';
  const start = document.getElementById('fShiftStart')?.value || '09:00 AM';
  const end = document.getElementById('fShiftEnd')?.value || '06:00 PM';
  
  let label = customLabel;
  if (!label) {
    if (type === 'Night') label = 'Night Shift';
    else if (type === 'Evening') label = 'Evening Shift';
    else if (type === 'Rotational') label = 'Rotational Shift';
    else label = 'Day Shift';
  }
  
  const fullShift = `${type} Shift (${start} - ${end})`;
  if (document.getElementById('fShift')) {
    document.getElementById('fShift').value = fullShift;
  }
}

</script>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8 space-y-8">
  <?= renderFlash() ?>

  <!-- ── PAGE HEADER ──────────────────────────────────────────────── -->
  <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
    <div>
      <div class="section-tag mb-1">Confidential People &amp; Human Resources Management</div>
      <h1 class="text-2xl sm:text-3xl font-black text-white">HR PORTAL &amp; PEOPLE OPERATIONS</h1>
      <p class="text-gray-400 text-xs mt-1">Manage confidential staff profiles, new employee enrollment, hiring data, payroll, and daily shift attendance.</p>
    </div>

    <div class="flex flex-wrap items-center gap-3">
      <a href="/admin/hr-documents.php?doc=offer&mode=outsider" class="btn-gold py-2.5 px-4 text-xs font-black shadow-glow inline-flex items-center gap-1.5">
        <span>✉️</span> <span>Send Offer &amp; NDA to Outsider</span>
      </a>
      <a href="/admin/hr-documents.php?doc=contracts" class="btn-ghost py-2.5 px-4 text-xs font-bold border border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/10 rounded-xl inline-flex items-center gap-1.5">
        <span>📂</span> <span>Signed NDAs (<?= $signedHrContracts ?>)</span>
      </a>
      <a href="/admin/hr-documents.php" class="btn-ghost py-2.5 px-4 text-xs font-bold border border-dark-border text-gray-300 hover:text-white rounded-xl inline-flex items-center gap-1.5">
        <span>💰</span> <span>Payslips &amp; Letters</span>
      </a>
      <button onclick="openEnrollModal()" class="btn-ghost py-2.5 px-3 text-xs font-bold border border-gold/40 text-gold hover:bg-gold/10 rounded-xl inline-flex items-center gap-1">
        <span>+</span> <span>Enroll Staff</span>
      </button>
      <a href="/admin/roles-sop.php?tab=hr" class="btn-ghost py-2.5 px-3 text-xs font-bold border border-pink-500/40 text-pink-300 hover:bg-pink-500/10 rounded-xl inline-flex items-center gap-1">
        <span>📖</span> <span>SOP</span>
      </a>
    </div>
  </div>

  <!-- ── KPI SUMMARY CARDS ───────────────────────────────────────── -->
  <div class="grid grid-cols-2 sm:grid-cols-6 gap-4">
    <div class="glass-card rounded-2xl p-4 border border-dark-border space-y-1">
      <span class="text-[11px] text-gray-400 uppercase font-bold">Total Staff</span>
      <div class="text-2xl font-black text-white"><?= $totalEmployees ?></div>
      <span class="text-[10px] text-gray-400">All Departments</span>
    </div>
    <div class="glass-card rounded-2xl p-4 border border-emerald-500/30 bg-emerald-950/10 space-y-1">
      <span class="text-[11px] text-emerald-400 uppercase font-bold">Present Today</span>
      <div class="text-2xl font-black text-emerald-300"><?= $presentCount ?></div>
      <span class="text-[10px] text-emerald-400 font-bold">Checked In</span>
    </div>
    <div class="glass-card rounded-2xl p-4 border border-amber-500/30 bg-amber-950/10 space-y-1">
      <span class="text-[11px] text-amber-400 uppercase font-bold">Late Arrivals</span>
      <div class="text-2xl font-black text-amber-300"><?= $lateCount ?></div>
      <span class="text-[10px] text-gray-400">Grace Exceeded</span>
    </div>
    <div class="glass-card rounded-2xl p-4 border border-blue-500/30 bg-blue-950/10 space-y-1">
      <span class="text-[11px] text-blue-400 uppercase font-bold">On Leave</span>
      <div class="text-2xl font-black text-blue-300"><?= $leaveCount ?></div>
      <span class="text-[10px] text-blue-400">Approved Leaves</span>
    </div>
    <div class="glass-card rounded-2xl p-4 border border-red-500/30 bg-red-950/10 space-y-1">
      <span class="text-[11px] text-red-400 uppercase font-bold">Absent</span>
      <div class="text-2xl font-black text-red-300"><?= $absentCount ?></div>
      <span class="text-[10px] text-red-400 font-mono"><?= $unmarkedCount ?> unmarked</span>
    </div>
    <div class="glass-card rounded-2xl p-4 border border-pink-500/30 bg-pink-950/10 space-y-1">
      <span class="text-[11px] text-pink-400 uppercase font-bold">Attendance Rate</span>
      <div class="text-2xl font-black text-pink-300"><?= $attendanceRate ?>%</div>
      <span class="text-[10px] text-gray-400 font-mono"><?= date('M Y') ?> Target: 95%</span>
    </div>
  </div>

  <?php if ($viewMode === 'attendance'): ?>
  <!-- ══════════════════════════════════════════════════════════════ -->
  <!-- ── ATTENDANCE MANAGEMENT VIEW ─────────────────────────────── -->
  <!-- ══════════════════════════════════════════════════════════════ -->
  <div class="glass-card rounded-3xl border border-dark-border shadow-2xl p-6 space-y-6">
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-dark-border pb-4">
      <div>
        <h3 class="text-base font-black text-white uppercase tracking-wider">📅 SHIFT ATTENDANCE TRACKER</h3>
        <p class="text-xs text-gray-400">Mark or update employee daily check-in times, late minutes, leaves, and shift hours.</p>
      </div>

      <div class="flex flex-wrap items-center gap-3">
        <form method="GET" class="flex items-center gap-2">
          <input type="hidden" name="view" value="attendance">
          <label class="text-xs text-gray-400 font-bold">Date:</label>
          <input type="date" name="date" value="<?= htmlspecialchars($selectedDate) ?>" onchange="this.form.submit()"
                 class="form-input text-xs py-1.5 px-3 bg-[#161622] border-[#2A2A3A] rounded-xl text-white">
        </form>

        <?php if ($unmarkedCount > 0): ?>
        <form method="POST" class="inline-block">
          <?= csrfField() ?>
          <input type="hidden" name="action_bulk_mark_present" value="1">
          <input type="hidden" name="date" value="<?= htmlspecialchars($selectedDate) ?>">
          <button type="submit" class="btn-gold py-1.5 px-4 text-xs font-black shadow-glow whitespace-nowrap">
            ⚡ Mark All Active Staff Present
          </button>
        </form>
        <?php endif; ?>
      </div>
    </div>

    <!-- Attendance Table -->
    <div class="overflow-x-auto">
      <table class="dashboard-table w-full text-xs text-left">
        <thead>
          <tr>
            <th>EMPLOYEE</th>
            <th>ROLE &amp; SHIFT</th>
            <th>STATUS</th>
            <th>CHECK-IN</th>
            <th>CHECK-OUT</th>
            <th>LATE DURATION</th>
            <th>SHIFT NOTES</th>
            <th class="text-right">ACTION</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($employees as $e): 
            $empId = $e['id'] ?? $e['user_id'];
            $att = $attMap[$empId] ?? null;
            $status = $att['status'] ?? 'Not Marked';
          ?>
          <tr class="hover:bg-white/[0.02]">
            <td>
              <div class="flex items-center gap-3">
                <div class="w-8 h-8 rounded-full bg-gold/20 text-gold flex items-center justify-center font-black text-xs border border-gold/40">
                  <?= strtoupper(substr($e['name'], 0, 2)) ?>
                </div>
                <div>
                  <div class="font-bold text-white"><?= htmlspecialchars($e['name']) ?></div>
                  <div class="text-gray-400 text-[11px] font-mono"><?= htmlspecialchars($e['email']) ?></div>
                </div>
              </div>
            </td>
            <td>
              <div class="font-bold text-gray-200"><?= htmlspecialchars($e['role']) ?></div>
              <div class="text-gray-400 text-[11px] font-mono"><?= htmlspecialchars($e['shift'] ?? 'Day Shift') ?></div>
            </td>
            <td>
              <?php if ($status === 'Present'): ?>
                <span class="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[11px] font-bold inline-flex items-center gap-1.5">
                  <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> Present
                </span>
              <?php elseif ($status === 'Late'): ?>
                <span class="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[11px] font-bold inline-flex items-center gap-1.5">
                  <span class="w-1.5 h-1.5 rounded-full bg-amber-400"></span> Late
                </span>
              <?php elseif ($status === 'On Leave' || $status === 'Leave'): ?>
                <span class="px-2.5 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/40 text-[11px] font-bold">
                  🌴 On Leave
                </span>
              <?php elseif ($status === 'Absent'): ?>
                <span class="px-2.5 py-1 rounded-full bg-red-500/20 text-red-400 border border-red-500/40 text-[11px] font-bold">
                  🔴 Absent
                </span>
              <?php else: ?>
                <span class="px-2.5 py-1 rounded-full bg-gray-500/20 text-gray-400 border border-gray-500/30 text-[11px] italic">
                  ⏳ Unmarked
                </span>
              <?php endif; ?>
            </td>
            <td class="font-mono text-gray-200"><?= htmlspecialchars($att['check_in'] ?? '—') ?></td>
            <td class="font-mono text-gray-400"><?= htmlspecialchars($att['check_out'] ?: '—') ?></td>
            <td class="font-mono">
              <?php if (!empty($att['late_minutes']) && $att['late_minutes'] > 0): ?>
                <span class="text-amber-400 font-bold"><?= $att['late_minutes'] ?> mins late</span>
              <?php else: ?>
                <span class="text-gray-500">0m</span>
              <?php endif; ?>
            </td>
            <td class="text-gray-300 text-[11px] font-mono"><?= htmlspecialchars($att['notes'] ?? '—') ?></td>
            <td class="text-right">
              <button onclick='openAttendanceModal(<?= json_encode($e) ?>, <?= json_encode($att) ?>)'
                      class="btn-ghost py-1 px-3 text-[11px] font-bold border border-gold/40 text-gold hover:bg-gold/10 rounded-lg">
                ✏️ Mark
              </button>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <?php else: ?>
  <!-- ══════════════════════════════════════════════════════════════ -->
  <!-- ── MAIN VIEW: CONFIDENTIAL STAFF PROFILES DIRECTORY ──────── -->
  <!-- ══════════════════════════════════════════════════════════════ -->
  <div class="glass-card rounded-3xl overflow-hidden border border-dark-border shadow-2xl p-6 space-y-4">
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-dark-border pb-4">
      <div>
        <h3 class="text-base font-black text-white uppercase tracking-wider">👔 CONFIDENTIAL STAFF PROFILES &amp; HIRING RECORDS</h3>
        <p class="text-xs text-gray-400">Complete employee dossier: personal info, contact, skills, confidential payroll, interview notes, and NDA status.</p>
      </div>
      <span class="text-xs font-mono text-gold font-bold"><?= count($employees) ?> Employees Enrolled</span>
    </div>

    <div class="overflow-x-auto">
      <table class="dashboard-table w-full text-left text-xs">
        <thead>
          <tr>
            <th>EMP ID</th>
            <th>EMPLOYEE DOSSIER</th>
            <th>ROLE &amp; SHIFT</th>
            <th>SKILLS &amp; SAMPLES</th>
            <th>STATUS</th>
            <th class="text-center">QUALITY</th>
            <th class="text-right">TOTAL COMPENSATION</th>
            <th class="text-right">ACTIONS</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($employees as $e): 
            $empId = $e['id'] ?? $e['user_id'];
            $basic = (float)($e['basic_salary'] ?? 650.0);
            $net   = (float)($e['net_salary'] ?? ($basic + (float)($e['rent_allowance'] ?? 80.0) + (float)($e['other_allowances'] ?? 40.0)));
            $status = $e['status'] ?? 'Active';
          ?>
          <tr class="hover:bg-white/[0.02]">
            <td class="font-mono font-bold text-gold"><?= htmlspecialchars($empId) ?></td>
            <td>
              <div class="font-bold text-white text-sm"><?= htmlspecialchars($e['name']) ?></div>
              <div class="text-gray-400 text-[11px] font-mono"><?= htmlspecialchars($e['email']) ?> &bull; <?= htmlspecialchars($e['phone'] ?? '') ?></div>
              <div class="text-[10px] text-gray-500 font-mono mt-0.5">
                Age: <strong class="text-gray-300"><?= $e['age'] ?? 26 ?></strong> &bull;
                Blood: <strong class="text-red-400"><?= $e['blood_group'] ?? 'O+' ?></strong> &bull;
                Location: <?= htmlspecialchars($e['location_timezone'] ?? 'PK') ?>
              </div>
            </td>
            <td>
              <span class="px-2 py-0.5 rounded text-[11px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                <?= htmlspecialchars($e['role']) ?>
              </span>
              <div class="text-gray-400 text-[10px] font-mono mt-0.5"><?= htmlspecialchars($e['shift'] ?? 'Day Shift') ?></div>
            </td>
            <td>
              <div class="flex flex-wrap gap-1 max-w-xs">
                <?php foreach (($e['skills'] ?? ['HDR Editing', 'Color Balance']) as $sk): ?>
                  <span class="px-1.5 py-0.5 rounded bg-dark border border-dark-border text-[10px] text-gray-300"><?= htmlspecialchars($sk) ?></span>
                <?php endforeach; ?>
              </div>
              <?php if (!empty($e['work_samples_url'])): ?>
                <a href="<?= htmlspecialchars($e['work_samples_url']) ?>" target="_blank" class="text-[10px] text-blue-400 hover:underline inline-block mt-1">
                  📁 Samples / Portfolio ↗
                </a>
              <?php endif; ?>
            </td>
            <td>
              <?php if ($status === 'Active'): ?>
                <span class="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold text-[11px]">Active</span>
              <?php elseif ($status === 'On Probation'): ?>
                <span class="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold text-[11px]">Probation</span>
              <?php else: ?>
                <span class="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 border border-red-500/30 font-bold text-[11px]"><?= htmlspecialchars($status) ?></span>
              <?php endif; ?>
            </td>
            <td class="text-center font-mono font-bold text-emerald-400 text-sm"><?= $e['quality_score'] ?? 96.5 ?>%</td>
            <td class="text-right font-mono">
              <div class="font-black text-gold text-sm"><?= htmlspecialchars($e['currency'] ?? 'PKR') ?> <?= number_format($net, 0) ?></div>
              <div class="text-[10px] text-gray-400">Basic $<?= number_format($basic, 0) ?> + Allow</div>
            </td>
            <td class="text-right">
              <div class="flex items-center justify-end gap-1.5">
                <button onclick='viewEmployeeModal(<?= json_encode($e) ?>)' class="btn-ghost py-1 px-2 text-[11px] font-bold border border-dark-border text-gray-300 hover:text-white rounded-lg">
                  👁️ View
                </button>
                <button onclick='editEmployeeModal(<?= json_encode($e) ?>)' class="btn-ghost py-1 px-2 text-[11px] font-bold border border-gold/40 text-gold hover:bg-gold/10 rounded-lg">
                  ✏️ Edit
                </button>
                <?php if ($isOwner): ?>
                  <button type="button" onclick="openDeleteEmpModal('<?= htmlspecialchars($empId, ENT_QUOTES) ?>', '<?= htmlspecialchars($e['name'], ENT_QUOTES) ?>', '<?= htmlspecialchars($e['email'], ENT_QUOTES) ?>')" class="btn-ghost py-1 px-2 text-[11px] font-bold border border-red-500/40 text-red-400 hover:bg-red-500/10 rounded-lg" title="Delete Employee Record">
                    🗑️ Delete
                  </button>
                <?php endif; ?>
                
                <!-- 📄 Official Docs & Letters Dropdown -->
                <div class="relative inline-block text-left group">
                  <button type="button" class="btn-ghost py-1 px-2 text-[11px] font-bold border border-blue-500/40 text-blue-300 hover:bg-blue-500/10 rounded-lg inline-flex items-center gap-1">
                    <span>📄 Docs</span> <span class="text-[8px]">▾</span>
                  </button>
                  <div class="absolute right-0 top-full mt-1 w-52 rounded-xl bg-[#111118] border border-[#1E1E2E] shadow-2xl p-1.5 hidden group-hover:block z-50 space-y-1 font-mono text-[11px] text-left">
                    <a href="/admin/hr-document.php?id=<?= urlencode($empId) ?>&type=salary_slip" target="_blank" class="flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-gray-300 hover:text-white hover:bg-[#1A1A26]">
                      <span>💰</span> <span>Print Salary Slip</span>
                    </a>
                    <a href="/admin/hr-document.php?id=<?= urlencode($empId) ?>&type=bank_letter" target="_blank" class="flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-gray-300 hover:text-white hover:bg-[#1A1A26]">
                      <span>🏦</span> <span>Bank Account Letter</span>
                    </a>
                    <a href="/admin/hr-document.php?id=<?= urlencode($empId) ?>&type=offer_letter" target="_blank" class="flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-gray-300 hover:text-white hover:bg-[#1A1A26]">
                      <span>✉️</span> <span>Offer Letter</span>
                    </a>
                    <a href="/admin/hr-document.php?id=<?= urlencode($empId) ?>&type=nda" target="_blank" class="flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-gray-300 hover:text-white hover:bg-[#1A1A26]">
                      <span>📜</span> <span>Confidentiality NDA</span>
                    </a>
                    <a href="/admin/hr-document.php?id=<?= urlencode($empId) ?>&type=termination" target="_blank" class="flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-red-400 hover:text-red-300 hover:bg-red-950/40">
                      <span>⚠️</span> <span>Termination Notice</span>
                    </a>
                  </div>
                </div>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endif; ?>

</main>

<!-- ═══════════════════════════════════════════════════════════════════ -->
<!-- ── MODAL 1: VIEW COMPLETE EMPLOYEE DOSSIER ─────────────────────── -->
<!-- ═══════════════════════════════════════════════════════════════════ -->
<div id="viewModal" class="fixed inset-0 z-50 bg-dark/85 backdrop-blur-sm flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 sm:p-8 max-w-2xl w-full border border-dark-border shadow-2xl space-y-5 relative max-h-[90vh] overflow-y-auto">
    <button onclick="closeViewModal()" class="absolute top-5 right-5 text-gray-400 hover:text-white text-xl">&times;</button>
    
    <div class="border-b border-dark-border pb-4">
      <div class="section-tag mb-1">Confidential Employee Dossier</div>
      <h3 id="vName" class="text-xl font-black text-white">Employee Name</h3>
      <p id="vSub" class="text-xs text-gold font-mono mt-0.5"></p>
    </div>

    <!-- 4 Structured Categories -->
    <div class="space-y-4 text-xs font-mono">
      
      <!-- 📌 1. Personal Info -->
      <div class="p-4 rounded-2xl bg-dark/90 border border-dark-border space-y-2">
        <h4 class="text-xs font-bold text-gold uppercase tracking-wider">📌 1. Personal Info</h4>
        <div class="grid grid-cols-2 sm:grid-cols-3 gap-2">
          <div><span class="text-gray-400 block">Age:</span> <strong id="vAge" class="text-white"></strong></div>
          <div><span class="text-gray-400 block">Blood Group:</span> <strong id="vBlood" class="text-red-400"></strong></div>
          <div><span class="text-gray-400 block">Location / Timezone:</span> <strong id="vLocation" class="text-white"></strong></div>
          <div><span class="text-gray-400 block">Email:</span> <strong id="vEmail" class="text-white"></strong></div>
          <div><span class="text-gray-400 block">Phone:</span> <strong id="vPhone" class="text-white"></strong></div>
          <div><span class="text-gray-400 block">Applied Source:</span> <strong id="vSource" class="text-blue-300"></strong></div>
        </div>
        <div class="pt-1"><span class="text-gray-400 block">Portfolio / Links:</span> <a id="vPortfolio" href="#" target="_blank" class="text-blue-400 hover:underline break-all"></a></div>
      </div>

      <!-- 💼 2. Work & Status -->
      <div class="p-4 rounded-2xl bg-dark/90 border border-dark-border space-y-2">
        <h4 class="text-xs font-bold text-gold uppercase tracking-wider">💼 2. Work &amp; Status</h4>
        <div class="grid grid-cols-2 gap-2">
          <div><span class="text-gray-400 block">Designation:</span> <strong id="vRole" class="text-white"></strong></div>
          <div><span class="text-gray-400 block">Shift Schedule:</span> <strong id="vShift" class="text-white"></strong></div>
          <div><span class="text-gray-400 block">Employment Status:</span> <strong id="vStatus" class="text-emerald-400"></strong></div>
          <div><span class="text-gray-400 block">Work Samples Link:</span> <a id="vSamples" href="#" target="_blank" class="text-blue-400 hover:underline break-all"></a></div>
        </div>
        <div><span class="text-gray-400 block mb-1">Technical Skills:</span> <div id="vSkills" class="flex flex-wrap gap-1"></div></div>
        <div><span class="text-gray-400 block">Experience Timeline:</span> <p id="vExp" class="text-gray-300 font-sans text-xs mt-0.5"></p></div>
      </div>

      <!-- 💰 3. Salary & Payroll -->
      <div class="p-4 rounded-2xl bg-dark/90 border border-dark-border space-y-2">
        <h4 class="text-xs font-bold text-gold uppercase tracking-wider">💰 3. Salary &amp; Payroll Breakdown</h4>
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <div><span class="text-gray-400 block">Basic Salary:</span> <strong id="vBasic" class="text-white"></strong></div>
          <div><span class="text-gray-400 block">Rent Allowance:</span> <strong id="vRent" class="text-white"></strong></div>
          <div><span class="text-gray-400 block">Other Allowance:</span> <strong id="vOtherAllow" class="text-white"></strong></div>
          <div><span class="text-gray-400 block">Bonus / Extra:</span> <strong id="vBonus" class="text-emerald-400"></strong></div>
          <div><span class="text-gray-400 block">Fine / Deductions:</span> <strong id="vDeduct" class="text-red-400"></strong></div>
          <div><span class="text-gray-400 block">Expected Salary:</span> <strong id="vExpected" class="text-gray-400"></strong></div>
          <div class="sm:col-span-2"><span class="text-gray-400 block">Total Monthly Net:</span> <strong id="vNet" class="text-gold text-sm font-black"></strong></div>
        </div>
      </div>

      <!-- 📊 4. HR & Admin -->
      <div class="p-4 rounded-2xl bg-dark/90 border border-dark-border space-y-2">
        <h4 class="text-xs font-bold text-gold uppercase tracking-wider">📊 4. HR &amp; Admin Records</h4>
        <div class="grid grid-cols-2 gap-2">
          <div><span class="text-gray-400 block">Hiring Stage:</span> <strong id="vStage" class="text-white"></strong></div>
          <div><span class="text-gray-400 block">Background Check:</span> <strong id="vBgCheck" class="text-emerald-400"></strong></div>
          <div class="col-span-2"><span class="text-gray-400 block">Official Docs:</span> <strong id="vDocs" class="text-white"></strong></div>
        </div>
        <div><span class="text-gray-400 block">Interview Notes &amp; Test Scores:</span> <p id="vNotes" class="text-gray-300 font-sans text-xs mt-0.5"></p></div>
        <div><span class="text-gray-400 block">Communication Log:</span> <p id="vComm" class="text-gray-300 font-sans text-xs mt-0.5"></p></div>
      </div>

    </div>

    <div class="flex justify-end pt-2">
      <button onclick="closeViewModal()" class="btn-gold py-2 px-6 text-xs font-black shadow-glow">Close Dossier</button>
    </div>
  </div>
</div>

<!-- ═══════════════════════════════════════════════════════════════════ -->
<!-- ── MODAL 2: ENROLL NEW HIRE / EDIT COMPLETE EMPLOYEE PROFILE ───── -->
<!-- ═══════════════════════════════════════════════════════════════════ -->
<div id="enrollModal" class="fixed inset-0 z-50 bg-dark/85 backdrop-blur-sm flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 sm:p-8 max-w-3xl w-full border border-dark-border shadow-2xl space-y-6 relative max-h-[92vh] overflow-y-auto">
    <button onclick="closeEnrollModal()" class="absolute top-5 right-5 text-gray-400 hover:text-white text-xl">&times;</button>
    
    <div>
      <div class="section-tag mb-1">Human Resources &amp; Talent Acquisition</div>
      <h3 id="formModalTitle" class="text-xl font-black text-white">Enroll New Employee / Hiring</h3>
      <p class="text-xs text-gray-400 mt-0.5">Fill in all 4 sections completely for accurate payroll, contract, and role assignments.</p>
    </div>

    <form method="POST" class="space-y-6">
      <?= csrfField() ?>
      <input type="hidden" name="action_save_employee" value="1">
      <input type="hidden" name="emp_id" id="fEmpId" value="">
      <input type="hidden" name="user_id" id="fUserId" value="">

      <!-- 📌 1. PERSONAL INFO SECTION -->
      <div class="p-4 sm:p-5 rounded-2xl bg-dark/90 border border-dark-border space-y-3">
        <h4 class="text-xs font-bold text-gold uppercase tracking-wider border-b border-dark-border pb-2">📌 1. Personal Info</h4>
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Full Name <span class="text-red-400">*</span></label>
            <input type="text" name="name" id="fName" required placeholder="e.g. Johnathan Smith" class="form-input text-xs w-full mt-1 bg-[#111118] text-white">
          </div>
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Email Address <span class="text-red-400">*</span></label>
            <input type="email" name="email" id="fEmail" required placeholder="e.g. john@estatehdr.com" class="form-input text-xs w-full mt-1 bg-[#111118] text-white font-mono">
          </div>
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Phone Number</label>
            <input type="text" name="phone" id="fPhone" placeholder="+44 770 000 0000" class="form-input text-xs w-full mt-1 bg-[#111118] text-white font-mono">
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Age</label>
            <input type="number" name="age" id="fAge" value="26" min="18" max="70" class="form-input text-xs w-full mt-1 bg-[#111118] text-white font-mono">
          </div>
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Blood Group</label>
            <select name="blood_group" id="fBlood" class="form-select text-xs w-full mt-1 bg-[#111118] text-white">
              <option value="O+">O+</option>
              <option value="A+">A+</option>
              <option value="B+">B+</option>
              <option value="AB+">AB+</option>
              <option value="O-">O-</option>
              <option value="A-">A-</option>
              <option value="B-">B-</option>
              <option value="AB-">AB-</option>
            </select>
          </div>
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Location / Timezone</label>
            <input type="text" name="location_timezone" id="fLocation" placeholder="e.g. Lahore, PK (GMT+5)" class="form-input text-xs w-full mt-1 bg-[#111118] text-white">
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Portfolio / Social Links</label>
            <input type="text" name="portfolio_links" id="fPortfolio" placeholder="https://behance.net/... or LinkedIn" class="form-input text-xs w-full mt-1 bg-[#111118] text-white font-mono">
          </div>
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Applied From (Source)</label>
            <input type="text" name="source" id="fSource" placeholder="e.g. LinkedIn, Referral, Rozee.pk" class="form-input text-xs w-full mt-1 bg-[#111118] text-white">
          </div>
        </div>
      </div>

      <!-- 💼 2. WORK & STATUS SECTION -->
      <div class="p-4 sm:p-5 rounded-2xl bg-dark/90 border border-dark-border space-y-3">
        <h4 class="text-xs font-bold text-gold uppercase tracking-wider border-b border-dark-border pb-2">💼 2. Work &amp; Status</h4>
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Role / Designation <span class="text-red-400">*</span></label>
            <select name="role" id="fRole" required class="form-select text-xs w-full mt-1 bg-[#111118] text-white">
              <option value="Photo Editor">Photo Editor</option>
              <option value="Team Lead">Team Lead</option>
              <option value="Supervisor">Supervisor</option>
              <option value="Production Manager">Production Manager</option>
              <option value="SEO Manager">SEO Manager</option>
              <option value="HR Officer">HR Officer</option>
            </select>
          </div>
          <!-- 🕒 HR SHIFT DECISION & CLIENT TIMING SUITE -->
          <div class="sm:col-span-2 p-3.5 rounded-xl bg-[#14141E] border border-gold/30 space-y-2.5">
            <div class="flex items-center justify-between">
              <label class="form-label text-xs font-bold text-gold">🕒 HR Shift Decision &amp; Exact Working Hours <span class="text-red-400">*</span></label>
              <span class="text-[10px] text-emerald-400 font-mono font-bold">HR Decides at Hiring</span>
            </div>

            <!-- Quick Preset Buttons -->
            <div class="flex flex-wrap gap-1.5 text-[10px] font-bold font-mono">
              <button type="button" onclick="setShiftPreset('Day', '09:00 AM', '06:00 PM', 'Standard Morning')" class="px-2 py-1 rounded bg-[#1C1C2B] text-gray-300 hover:text-white hover:bg-gold/20 border border-[#2A2A3E]">
                ☀️ Day (09:00 AM - 06:00 PM)
              </button>
              <button type="button" onclick="setShiftPreset('Night', '08:00 PM', '05:00 AM', 'US Client Dedicated')" class="px-2 py-1 rounded bg-[#1C1C2B] text-purple-300 hover:text-white hover:bg-purple-500/20 border border-purple-500/30">
                🌙 US Night (08:00 PM - 05:00 AM)
              </button>
              <button type="button" onclick="setShiftPreset('Evening', '01:00 PM', '10:00 PM', 'UK Client Shift')" class="px-2 py-1 rounded bg-[#1C1C2B] text-blue-300 hover:text-white hover:bg-blue-500/20 border border-blue-500/30">
                🇬🇧 UK (01:00 PM - 10:00 PM)
              </button>
              <button type="button" onclick="setShiftPreset('Day', '05:00 AM', '02:00 PM', 'Australia Early Shift')" class="px-2 py-1 rounded bg-[#1C1C2B] text-amber-300 hover:text-white hover:bg-amber-500/20 border border-amber-500/30">
                🇦🇺 Australia (05:00 AM - 02:00 PM)
              </button>
            </div>

            <!-- Manual Custom Time Inputs -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
              <div>
                <label class="text-[11px] text-gray-400 font-bold block mb-1">Shift Type</label>
                <select id="fShiftType" onchange="buildCustomShiftString()" class="form-select text-xs w-full bg-[#111118] text-white font-bold py-1.5 px-2.5 rounded-lg border-[#2A2A3E]">
                  <option value="Day">☀️ Day / Morning Shift</option>
                  <option value="Night">🌙 Night Shift</option>
                  <option value="Evening">🌅 Evening Shift</option>
                  <option value="Rotational">🔄 Flexible / Rotational</option>
                </select>
              </div>
              <div>
                <label class="text-[11px] text-gray-400 font-bold block mb-1">Check-in (Start Time)</label>
                <input type="text" id="fShiftStart" value="09:00 AM" placeholder="09:00 AM" oninput="buildCustomShiftString()" class="form-input text-xs w-full bg-[#111118] text-white font-mono py-1.5 px-2.5 rounded-lg border-[#2A2A3E]">
              </div>
              <div>
                <label class="text-[11px] text-gray-400 font-bold block mb-1">Check-out (End Time)</label>
                <input type="text" id="fShiftEnd" value="06:00 PM" placeholder="06:00 PM" oninput="buildCustomShiftString()" class="form-input text-xs w-full bg-[#111118] text-white font-mono py-1.5 px-2.5 rounded-lg border-[#2A2A3E]">
              </div>
            </div>

            <!-- Final Saved Shift Output -->
            <div>
              <label class="text-[10px] text-gray-400 font-bold block mb-0.5">Assigned Official Shift Schedule (Saved to Profile &amp; Offer Letter):</label>
              <input type="text" name="shift" id="fShift" required value="Morning (09:00 AM - 06:00 PM)" class="form-input text-xs w-full bg-[#111118] text-gold font-mono font-bold py-1.5 px-2.5 rounded-lg border-gold/40">
            </div>
          </div>
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Status</label>
            <select name="status" id="fStatus" class="form-select text-xs w-full mt-1 bg-[#111118] text-white">
              <option value="Active">Active</option>
              <option value="On Probation">On Probation</option>
              <option value="On Leave">On Leave</option>
              <option value="Terminated">Terminated</option>
              <option value="Resigned">Resigned</option>
            </select>
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Skill Tags (Comma-separated)</label>
            <input type="text" name="skills" id="fSkills" placeholder="e.g. HDR Photo Editing, Flambient, Virtual Staging" class="form-input text-xs w-full mt-1 bg-[#111118] text-white">
          </div>
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Work Samples / Test Attachments Link</label>
            <input type="text" name="work_samples_url" id="fSamples" placeholder="https://drive.google.com/drive/..." class="form-input text-xs w-full mt-1 bg-[#111118] text-white font-mono">
          </div>
        </div>

        <div>
          <label class="form-label text-xs font-bold text-gray-300">Resume / Experience Timeline</label>
          <textarea name="experience_timeline" id="fExp" rows="2" placeholder="e.g. 4 years senior retoucher at XYZ; specialized in luxury villas..." class="form-textarea text-xs w-full mt-1 bg-[#111118] text-white"></textarea>
        </div>
      </div>

      <!-- 💰 3. SALARY & PAYROLL SECTION -->
      <div class="p-4 sm:p-5 rounded-2xl bg-dark/90 border border-dark-border space-y-3">
        <h4 class="text-xs font-bold text-gold uppercase tracking-wider border-b border-dark-border pb-2">💰 3. Salary &amp; Payroll</h4>
        <div class="grid grid-cols-2 sm:grid-cols-5 gap-3">
          <div>
            <label class="form-label text-xs font-bold text-gold">Currency <span class="text-red-400">*</span></label>
            <select name="currency" id="fCurrency" class="form-select text-xs w-full mt-1 bg-[#111118] text-white font-bold">
              <option value="PKR">PKR (Rs. Pakistan)</option>
              <option value="USD">USD ($ United States)</option>
              <option value="GBP">GBP (£ United Kingdom)</option>
              <option value="EUR">EUR (€ Europe)</option>
              <option value="AED">AED (UAE Dirham)</option>
            </select>
          </div>
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Basic Salary <span class="text-red-400">*</span></label>
            <input type="number" name="basic_salary" id="fBasic" required step="0.01" value="85000.00" class="form-input text-xs w-full mt-1 bg-[#111118] text-white font-mono">
          </div>
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Rent Allowance</label>
            <input type="number" name="rent_allowance" id="fRent" step="0.01" value="10000.00" class="form-input text-xs w-full mt-1 bg-[#111118] text-white font-mono">
          </div>
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Other Allowances</label>
            <input type="number" name="other_allowances" id="fOtherAllow" step="0.01" value="5000.00" class="form-input text-xs w-full mt-1 bg-[#111118] text-white font-mono">
          </div>
          <div>
            <label class="form-label text-xs font-bold text-emerald-400">Bonus</label>
            <input type="number" name="bonus" id="fBonus" step="0.01" value="5000.00" class="form-input text-xs w-full mt-1 bg-[#111118] text-white font-mono">
          </div>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
          <div>
            <label class="form-label text-xs font-bold text-red-400">Fine / Deductions ($)</label>
            <input type="number" name="deductions" id="fDeduct" step="0.01" value="0.00" class="form-input text-xs w-full mt-1 bg-[#111118] text-white font-mono">
          </div>
          <div>
            <label class="form-label text-xs font-bold text-gray-400">Expected Salary ($)</label>
            <input type="number" name="expected_salary" id="fExpected" step="0.01" value="800.00" class="form-input text-xs w-full mt-1 bg-[#111118] text-white font-mono">
          </div>
          <div>
            <label class="form-label text-xs font-bold text-gold">Portal Password</label>
            <input type="text" name="password" id="fPass" placeholder="Leave blank to keep current password" class="form-input text-xs w-full mt-1 bg-[#111118] text-white font-mono">
          </div>
        </div>
      </div>

      <!-- 📊 4. HR & ADMIN SECTION -->
      <div class="p-4 sm:p-5 rounded-2xl bg-dark/90 border border-dark-border space-y-3">
        <h4 class="text-xs font-bold text-gold uppercase tracking-wider border-b border-dark-border pb-2">📊 4. HR &amp; Admin Records</h4>
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Hiring Stage</label>
            <select name="hiring_stage" id="fStage" class="form-select text-xs w-full mt-1 bg-[#111118] text-white">
              <option value="Hired / Onboarded">Hired / Onboarded</option>
              <option value="Technical Test Passed">Technical Test Passed</option>
              <option value="Interview Scheduled">Interview Scheduled</option>
              <option value="Offer Sent">Offer Sent</option>
              <option value="Screening">Screening</option>
            </select>
          </div>
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Background Checks</label>
            <select name="background_check" id="fBgCheck" class="form-select text-xs w-full mt-1 bg-[#111118] text-white">
              <option value="Verified">Verified</option>
              <option value="Pending Verification">Pending Verification</option>
              <option value="Not Required">Not Required</option>
            </select>
          </div>
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Official Docs (NDA &amp; Contract)</label>
            <input type="text" name="official_docs" id="fDocs" placeholder="e.g. NDA Signed, Employment Contract #2026" class="form-input text-xs w-full mt-1 bg-[#111118] text-white">
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Interview Notes &amp; Test Scores</label>
            <textarea name="interview_notes" id="fNotes" rows="2" placeholder="e.g. Technical test 98%, excellent speed..." class="form-textarea text-xs w-full mt-1 bg-[#111118] text-white"></textarea>
          </div>
          <div>
            <label class="form-label text-xs font-bold text-gray-300">Communication Log</label>
            <textarea name="communication_log" id="fComm" rows="2" placeholder="e.g. Onboarding call scheduled for Monday..." class="form-textarea text-xs w-full mt-1 bg-[#111118] text-white"></textarea>
          </div>
        </div>
      </div>

      <div class="flex items-center justify-end gap-3 pt-2">
        <button type="button" onclick="closeEnrollModal()" class="btn-ghost py-2 px-5 text-xs font-bold text-gray-400">Cancel</button>
        <button type="submit" class="btn-gold py-2.5 px-8 text-xs font-black shadow-glow">
          💾 Save Employee Profile &amp; Account
        </button>
      </div>
    </form>
  </div>
</div>

<!-- ═══════════════════════════════════════════════════════════════════ -->
<!-- ── MODAL 3: ATTENDANCE RECORD UPDATE ───────────────────────────── -->
<!-- ═══════════════════════════════════════════════════════════════════ -->
<div id="attModal" class="fixed inset-0 z-50 bg-dark/80 backdrop-blur-sm flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 sm:p-8 max-w-md w-full border border-dark-border shadow-2xl space-y-5 relative">
    <button onclick="closeAttendanceModal()" class="absolute top-5 right-5 text-gray-400 hover:text-white text-xl">&times;</button>
    
    <div>
      <div class="section-tag mb-1">Daily Shift Attendance Record</div>
      <h3 id="attModalEmpName" class="text-lg font-black text-white">Update Attendance</h3>
      <p id="attModalDate" class="text-xs text-gray-400 font-mono mt-0.5"></p>
    </div>

    <form method="POST" class="space-y-4">
      <?= csrfField() ?>
      <input type="hidden" name="action_mark_attendance" value="1">
      <input type="hidden" name="employee_id" id="attEmpId" value="">
      <input type="hidden" name="date" id="attDateInput" value="<?= htmlspecialchars($selectedDate) ?>">
      <input type="hidden" name="shift" id="attShiftInput" value="">

      <div>
        <label class="form-label text-xs font-bold text-gray-300">Attendance Status</label>
        <select name="status" id="attStatus" class="form-select w-full text-xs mt-1 bg-[#111118] text-white" onchange="toggleLateInput()">
          <option value="Present">🟢 Present (On Time)</option>
          <option value="Late">🟡 Late Arrival</option>
          <option value="On Leave">🌴 On Leave / Half Day</option>
          <option value="Absent">🔴 Absent (Unexcused)</option>
        </select>
      </div>

      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="form-label text-xs font-bold text-gray-300">Check-in Time</label>
          <input type="text" name="check_in" id="attCheckIn" value="08:55 AM" class="form-input text-xs w-full mt-1 bg-[#111118] text-white font-mono">
        </div>
        <div>
          <label class="form-label text-xs font-bold text-gray-300">Check-out Time</label>
          <input type="text" name="check_out" id="attCheckOut" placeholder="06:00 PM" class="form-input text-xs w-full mt-1 bg-[#111118] text-white font-mono">
        </div>
      </div>

      <div id="lateDurationBox" class="hidden">
        <label class="form-label text-xs font-bold text-amber-400">Late Duration (Minutes)</label>
        <input type="number" name="late_minutes" id="attLateMinutes" value="15" min="0" class="form-input text-xs w-full mt-1 bg-[#111118] text-white font-mono">
      </div>

      <div>
        <label class="form-label text-xs font-bold text-gray-300">HR Shift Notes / Reason</label>
        <input type="text" name="notes" id="attNotes" placeholder="e.g. On time, approved leave, traffic delay" class="form-input text-xs w-full mt-1 bg-[#111118] text-white">
      </div>

      <div class="flex items-center justify-end gap-3 pt-2">
        <button type="button" onclick="closeAttendanceModal()" class="btn-ghost py-2 px-4 text-xs font-bold text-gray-400">Cancel</button>
        <button type="submit" class="btn-gold py-2.5 px-6 text-xs font-black shadow-glow">Save Attendance</button>
      </div>
    </form>
  </div>
</div>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
function viewEmployeeModal(e) {
  document.getElementById('vName').innerText = e.name || 'Employee';
  document.getElementById('vSub').innerText = (e.id || '') + ' • ' + (e.role || '') + ' (' + (e.shift || 'Day Shift') + ')';
  
  // 1. Personal
  document.getElementById('vAge').innerText = e.age || '26';
  document.getElementById('vBlood').innerText = e.blood_group || 'O+';
  document.getElementById('vLocation').innerText = e.location_timezone || 'Lahore, PK (GMT+5)';
  document.getElementById('vEmail').innerText = e.email || '—';
  document.getElementById('vPhone').innerText = e.phone || '—';
  document.getElementById('vSource').innerText = e.source || 'Direct';
  const port = document.getElementById('vPortfolio');
  port.innerText = e.portfolio_links || 'Not provided';
  port.href = e.portfolio_links || '#';

  // 2. Work
  document.getElementById('vRole').innerText = e.role || 'Photo Editor';
  document.getElementById('vShift').innerText = e.shift || 'Day Shift';
  document.getElementById('vStatus').innerText = e.status || 'Active';
  const samp = document.getElementById('vSamples');
  samp.innerText = e.work_samples_url || 'No samples attached';
  samp.href = e.work_samples_url || '#';
  
  const skBox = document.getElementById('vSkills');
  skBox.innerHTML = '';
  (e.skills || ['HDR Blending']).forEach(sk => {
    skBox.innerHTML += '<span class="px-2 py-0.5 rounded bg-dark border border-dark-border text-[11px] text-gray-300 font-bold">' + sk + '</span>';
  });
  document.getElementById('vExp').innerText = e.experience_timeline || 'Standard real estate editing experience.';

  // 3. Salary
  document.getElementById('vBasic').innerText = '$' + (e.basic_salary || 650).toFixed(2);
  document.getElementById('vRent').innerText = '$' + (e.rent_allowance || 80).toFixed(2);
  document.getElementById('vOtherAllow').innerText = '$' + (e.other_allowances || 40).toFixed(2);
  document.getElementById('vBonus').innerText = '$' + (e.bonus || 0).toFixed(2);
  document.getElementById('vDeduct').innerText = '$' + (e.deductions || 0).toFixed(2);
  document.getElementById('vExpected').innerText = '$' + (e.expected_salary || 800).toFixed(2);
  document.getElementById('vNet').innerText = '$' + (e.net_salary || 770).toFixed(2);

  // 4. HR Admin
  document.getElementById('vStage').innerText = e.hiring_stage || 'Hired / Onboarded';
  document.getElementById('vBgCheck').innerText = e.background_check || 'Verified';
  document.getElementById('vDocs').innerText = e.official_docs || 'NDA Signed';
  document.getElementById('vNotes').innerText = e.interview_notes || 'Passed technical evaluation.';
  document.getElementById('vComm').innerText = e.communication_log || 'Onboarded.';

  document.getElementById('viewModal').classList.remove('hidden');
}

function closeViewModal() {
  document.getElementById('viewModal').classList.add('hidden');
}

function openEnrollModal() {
  document.getElementById('formModalTitle').innerText = 'Enroll New Employee / Hiring';
  document.getElementById('fEmpId').value = '';
  document.getElementById('fUserId').value = '';
  document.getElementById('fName').value = '';
  document.getElementById('fEmail').value = '';
  document.getElementById('fPhone').value = '';
  document.getElementById('fAge').value = '26';
  document.getElementById('fBlood').value = 'O+';
  document.getElementById('fLocation').value = 'Lahore, PK (GMT+5)';
  document.getElementById('fPortfolio').value = '';
  document.getElementById('fSource').value = 'LinkedIn';
  document.getElementById('fRole').value = 'Photo Editor';
  document.getElementById('fShift').value = 'Morning (09:00 AM - 06:00 PM)';
  document.getElementById('fStatus').value = 'Active';
  document.getElementById('fSkills').value = 'HDR Photo Editing, Flambient, Window Pull';
  document.getElementById('fSamples').value = '';
  document.getElementById('fExp').value = '';
  document.getElementById('fCurrency').value = 'PKR';
  document.getElementById('fBasic').value = '85000.00';
  document.getElementById('fRent').value = '10000.00';
  document.getElementById('fOtherAllow').value = '5000.00';
  document.getElementById('fBonus').value = '5000.00';
  document.getElementById('fDeduct').value = '0.00';
  document.getElementById('fExpected').value = '100000.00';
  document.getElementById('fPass').value = '';
  document.getElementById('fStage').value = 'Hired / Onboarded';
  document.getElementById('fBgCheck').value = 'Verified';
  document.getElementById('fDocs').value = 'NDA Signed';
  document.getElementById('fNotes').value = '';
  document.getElementById('fComm').value = '';
  document.getElementById('enrollModal').classList.remove('hidden');
}

function editEmployeeModal(e) {
  document.getElementById('formModalTitle').innerText = 'Edit Employee Profile: ' + (e.name || '');
  document.getElementById('fEmpId').value = e.id || '';
  document.getElementById('fUserId').value = e.user_id || '';
  document.getElementById('fName').value = e.name || '';
  document.getElementById('fEmail').value = e.email || '';
  document.getElementById('fPhone').value = e.phone || '';
  document.getElementById('fAge').value = e.age || '26';
  document.getElementById('fBlood').value = e.blood_group || 'O+';
  document.getElementById('fLocation').value = e.location_timezone || 'Lahore, PK (GMT+5)';
  document.getElementById('fPortfolio').value = e.portfolio_links || '';
  document.getElementById('fSource').value = e.source || 'Direct';
  document.getElementById('fRole').value = e.role || 'Photo Editor';
  document.getElementById('fShift').value = e.shift || 'Morning (09:00 AM - 06:00 PM)';
  document.getElementById('fStatus').value = e.status || 'Active';
  document.getElementById('fSkills').value = (e.skills || []).join(', ');
  document.getElementById('fSamples').value = e.work_samples_url || '';
  document.getElementById('fExp').value = e.experience_timeline || '';
  document.getElementById('fCurrency').value = e.currency || 'PKR';
  document.getElementById('fBasic').value = e.basic_salary || '85000.00';
  document.getElementById('fRent').value = e.rent_allowance || '10000.00';
  document.getElementById('fOtherAllow').value = e.other_allowances || '40.00';
  document.getElementById('fBonus').value = e.bonus || '50.00';
  document.getElementById('fDeduct').value = e.deductions || '0.00';
  document.getElementById('fExpected').value = e.expected_salary || '800.00';
  document.getElementById('fPass').value = '';
  document.getElementById('fStage').value = e.hiring_stage || 'Hired / Onboarded';
  document.getElementById('fBgCheck').value = e.background_check || 'Verified';
  document.getElementById('fDocs').value = e.official_docs || 'NDA Signed';
  document.getElementById('fNotes').value = e.interview_notes || '';
  document.getElementById('fComm').value = e.communication_log || '';
  document.getElementById('enrollModal').classList.remove('hidden');
}

function closeEnrollModal() {
  document.getElementById('enrollModal').classList.add('hidden');
}

function openAttendanceModal(emp, att) {
  document.getElementById('attEmpId').value = emp.id || emp.user_id;
  document.getElementById('attShiftInput').value = emp.shift || '09:00 AM - 06:00 PM';
  document.getElementById('attModalEmpName').innerText = emp.name + ' (' + emp.role + ')';
  document.getElementById('attModalDate').innerText = 'Date: ' + document.getElementById('attDateInput').value;
  
  if (att) {
    document.getElementById('attStatus').value = att.status || 'Present';
    document.getElementById('attCheckIn').value = att.check_in || '08:55 AM';
    document.getElementById('attCheckOut').value = att.check_out || '';
    document.getElementById('attLateMinutes').value = att.late_minutes || 0;
    document.getElementById('attNotes').value = att.notes || '';
  } else {
    document.getElementById('attStatus').value = 'Present';
    document.getElementById('attCheckIn').value = '08:55 AM';
    document.getElementById('attCheckOut').value = '';
    document.getElementById('attLateMinutes').value = 0;
    document.getElementById('attNotes').value = 'On time';
  }
  toggleLateInput();
  document.getElementById('attModal').classList.remove('hidden');
}

function closeAttendanceModal() {
  document.getElementById('attModal').classList.add('hidden');
}

function toggleLateInput() {
  const status = document.getElementById('attStatus').value;
  const lateBox = document.getElementById('lateDurationBox');
  if (status === 'Late') {
    lateBox.classList.remove('hidden');
  } else {
    lateBox.classList.add('hidden');
  }
}

function setShiftPreset(type, start, end, label) {
  if (document.getElementById('fShiftType')) document.getElementById('fShiftType').value = type;
  if (document.getElementById('fShiftStart')) document.getElementById('fShiftStart').value = start;
  if (document.getElementById('fShiftEnd')) document.getElementById('fShiftEnd').value = end;
  buildCustomShiftString(label);
}

function buildCustomShiftString(customLabel) {
  const type = document.getElementById('fShiftType')?.value || 'Day';
  const start = document.getElementById('fShiftStart')?.value || '09:00 AM';
  const end = document.getElementById('fShiftEnd')?.value || '06:00 PM';
  
  let label = customLabel;
  if (!label) {
    if (type === 'Night') label = 'Night Shift';
    else if (type === 'Evening') label = 'Evening Shift';
    else if (type === 'Rotational') label = 'Rotational Shift';
    else label = 'Day Shift';
  }
  
  const fullShift = `${type} Shift (${start} - ${end})`;
  if (document.getElementById('fShift')) {
    document.getElementById('fShift').value = fullShift;
  }
}

</script>


<!-- CUSTOM DELETE EMPLOYEE MODAL (HR & Admin Synced) -->
<div id="deleteEmpModal" class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 max-w-md w-full border border-red-500/50 shadow-2xl space-y-4">
    <div class="flex items-center gap-3">
      <div class="w-10 h-10 rounded-2xl bg-red-600/20 border border-red-500 flex items-center justify-center text-red-400 text-xl font-black">
        ⚠️
      </div>
      <div>
        <h3 class="text-base font-black text-white">Remove Employee?</h3>
        <p class="text-xs text-gray-400">Permanently remove from HR roster and revoke system login.</p>
      </div>
    </div>

    <div class="p-3.5 rounded-2xl bg-red-950/30 border border-red-800/50 text-xs text-red-200 space-y-1">
      <div>Employee: <strong id="deleteEmpName" class="text-white"></strong> (<span id="deleteEmpId" class="font-mono text-gold font-bold"></span>)</div>
      <div class="text-[11px] text-gray-400 font-mono" id="deleteEmpEmail"></div>
    </div>

    <div class="flex items-center justify-end gap-3 pt-2">
      <button type="button" onclick="closeDeleteEmpModal()" class="btn-ghost py-2.5 px-4 text-xs font-bold">Cancel</button>
      <a id="confirmDeleteEmpBtn" href="#" class="py-2.5 px-5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs shadow-lg transition-all inline-flex items-center gap-1.5">
        <span>🗑️ Yes, Remove Employee</span>
      </a>
    </div>
  </div>
</div>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
function openDeleteEmpModal(empId, name, email) {
  document.getElementById('deleteEmpId').textContent = empId;
  document.getElementById('deleteEmpName').textContent = name;
  document.getElementById('deleteEmpEmail').textContent = email;
  document.getElementById('confirmDeleteEmpBtn').href = '/admin/hr-dashboard.php?delete_emp=' + encodeURIComponent(empId);
  document.getElementById('deleteEmpModal').classList.remove('hidden');
}

function closeDeleteEmpModal() {
  document.getElementById('deleteEmpModal').classList.add('hidden');
}
</script>

</body>
</html>
