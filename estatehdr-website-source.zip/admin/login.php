<?php
// Route any direct hits on /admin/login.php to /admin/index.php
require_once __DIR__ . '/index.php';
