<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/services/TurnaroundService.php';

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: Sat, 26 Jul 1997 05:00:00 GMT');


// ── Admin Authentication Handler ──────────────────────────────────────────────
if (isset($_GET['logout'])) {
    logoutAdmin();
    header('Location: /admin/');
    exit;
}

$loginError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_login'])) {
    verifyCsrf();
    $clientIp = \EstateHDR\Security\SecurityLogger::getClientIp();

    if (isIpLockedOut($clientIp)) {
        $loginError = 'Security Alert: Too many failed attempts. Login locked for 15 minutes.';
    } else {
        ehdr_rate_limit('login_attempt');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $pass  = $_POST['password'] ?? '';

        $adminUsers = getAdminUsers();
        $authenticatedUser = null;

        foreach ($adminUsers as $u) {
            if (!empty($u['is_active']) && strtolower($u['email']) === $email) {
                if (!empty($u['password_hash']) && password_verify($pass, $u['password_hash'])) {
                    $authenticatedUser = $u;
                    break;
                }
            }
        }

        // Master Admin fallback
        if (!$authenticatedUser && $email === 'admin@estatehdr.com' && verifyAdminPassword($pass)) {
            $authenticatedUser = [
                'id'    => 'adm-1',
                'email' => 'admin@estatehdr.com',
                'name'  => 'Master Admin',
                'roles' => ['owner', 'super_admin']
            ];
        }

        if ($authenticatedUser) {
            clearFailedLoginAttempts($clientIp);
            session_regenerate_id(true);
            $_SESSION['admin_user'] = $authenticatedUser;
            $_SESSION['is_admin']   = true;
            $_SESSION['_ehdr_admin_fingerprint'] = md5($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown');
            $isHttps = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
            @setcookie('ehdr_admin_logged_in', '1', time() + 86400 * 30, '/', '', $isHttps, true);
            @setcookie('ehdr_admin_email', $authenticatedUser['email'], time() + 86400 * 30, '/', '', $isHttps, true);
            
            \EstateHDR\Security\SecurityLogger::log('admin_auth_success', 'INFO', 'Admin logged in successfully', [
                'email'     => $authenticatedUser['email'],
                'client_ip' => $clientIp
            ]);

            $roles = $authenticatedUser['roles'] ?? [$authenticatedUser['role'] ?? 'photo_editor'];

            // Role-based smart redirect
            if (in_array('owner', $roles) || in_array('super_admin', $roles)) {
                header('Location: /admin/');
                exit;
            } elseif (in_array('manager', $roles)) {
                header('Location: /admin/manager-dashboard.php');
                exit;
            } elseif (in_array('team_lead', $roles)) {
                header('Location: /admin/teamlead-dashboard.php');
                exit;
            } elseif (in_array('supervisor', $roles)) {
                header('Location: /admin/supervisor-dashboard.php');
                exit;
            } elseif (in_array('hr', $roles)) {
                header('Location: /admin/hr-dashboard.php');
                exit;
            } elseif (in_array('seo_manager', $roles)) {
                header('Location: /admin/pages.php');
                exit;
            } else {
                header('Location: /admin/editor-dashboard.php');
                exit;
            }
        } else {
            recordFailedLoginAttempt($clientIp);
            \EstateHDR\Security\SecurityLogger::log('admin_auth_failed', 'WARNING', 'Failed admin login attempt', [
                'email'     => $email,
                'client_ip' => $clientIp
            ]);
            $loginError = 'Invalid email or password.';
        }
    }
}

// Check if SEO Manager is logged in and visiting admin root -> redirect to pages
if (isAdminLoggedIn() && isSeoManager()) {
    header('Location: /admin/pages.php');
    exit;
}

// ── Render Login Screen if not authenticated ──────────────────────────────────
if (!isAdminLoggedIn()):
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Sign In — Estate HDR</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-dark min-h-screen flex items-center justify-center p-6">
<div class="glass-card rounded-2xl p-8 max-w-sm w-full border border-dark-border shadow-2xl">
  <div class="flex items-center gap-3 mb-6 justify-center">
    <div class="w-8 h-8 rounded-lg bg-gold flex items-center justify-center font-bold text-dark text-base">E</div>
    <span class="font-bold text-lg text-white">Estate <span class="text-gold">HDR</span></span>
  </div>
  <h1 class="text-xl font-bold text-white mb-2">Staff Portal Login</h1>
  <p class="text-xs text-gray-500 mb-6">Enter your authorized email and password.</p>

  <?php if ($loginError): ?>
    <div class="p-3 mb-4 rounded-xl bg-red-900/30 border border-red-800 text-red-400 text-xs flex items-center gap-2">
      <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
      <span><?= htmlspecialchars($loginError) ?></span>
    </div>
  <?php endif; ?>

  <form method="POST" action="/admin/">
    <?= csrfField() ?>
    <?= ehdr_render_honeypot() ?>
    <input type="hidden" name="admin_login" value="1">
    <div class="space-y-4">
      <div>
        <label class="form-label text-xs">Email Address</label>
        <input type="email" name="email" required autocomplete="email" class="form-input text-xs py-2" placeholder="name@company.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
      </div>
      <div>
        <label class="form-label text-xs">Password</label>
        <input type="password" name="password" required autocomplete="current-password" class="form-input text-xs py-2" placeholder="••••••••">
      </div>
      <button type="submit" class="btn-gold w-full py-2.5 text-xs font-bold shadow-glow mt-2">Sign In to Workspace &rarr;</button>
    </div>
  </form>
  <div class="mt-6 pt-4 border-t border-dark-border text-center">
    <a href="<?= FACEBOOK_LINK ?>" target="_blank" rel="noopener noreferrer" class="text-xs text-gray-400 hover:text-blue-400 inline-flex items-center gap-1.5 font-bold transition-colors" title="Open Estate HDR Facebook in New Tab">
      <svg class="w-3.5 h-3.5 fill-current text-blue-400 shrink-0" width="14" height="14" style="width:14px;height:14px;max-width:14px;max-height:14px;" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
      <span>Official Facebook Page ↗</span>
    </a>
  </div>
</div>
</body>
</html>
<?php
exit;
endif;

// ── Admin Master Dashboard & CRM ──────────────────────────────────────────────
$currentAdmin  = currentAdminUser();
$adminRoles    = getAdminRoles();
$isOwner       = in_array('owner', $adminRoles) || in_array('super_admin', $adminRoles);
$isManagerOnly = (in_array('manager', $adminRoles) || in_array('production_manager', $adminRoles)) && !$isOwner;

$allOrders    = getAllOrders();
$allUsers     = getUsers();
$allLeads     = getLeads();
$financeStats = getGlobalFinancialStats();

$userMap = [];
foreach ($allUsers as $u) $userMap[$u['id']] = $u;

// KPI Calculations
$totalOrders       = count($allOrders);
$clientSubmitted   = 0;
$adminSubmitted    = 0;
$pendingDelivery   = 0;
$pendingRevision   = 0;
$deliveredJobs     = 0;

foreach ($allOrders as $o) {
    if ($o['created_by'] === 'admin') $adminSubmitted++;
    else $clientSubmitted++;

    $st = $o['status'] ?? 'pending';
    if (in_array($st, ['pending', 'in_progress', 'assigned_editor', 'submitted_qa', 'resubmitted'])) $pendingDelivery++;
    if (in_array($st, ['amendment_requested', 'revision_required'])) $pendingRevision++;
    if (in_array($st, ['delivered', 'sent_client', 'completed'])) $deliveredJobs++;
}

// Handle Order Actions (Delete, Edit, Purge All)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_order_action'])) {
    verifyCsrf();
    $act = $_POST['admin_order_action'];

    if ($act === 'delete_order') {
        $oid = trim($_POST['order_id'] ?? '');
        if ($oid && deleteOrder($oid)) {
            setFlash('success', "Order #{$oid} was successfully deleted.");
        } else {
            setFlash('error', "Could not delete order #{$oid}.");
        }
    } elseif ($act === 'purge_all_orders' && $isOwner) {
        $keepOrderId = trim($_POST['keep_order_id'] ?? '');
        $clearLeads  = !empty($_POST['clear_leads']);
        
        $allOrdersList = getAllOrders();
        $count = 0;
        
        foreach ($allOrdersList as $o) {
            $oid = $o['id'] ?? '';
            if ($keepOrderId !== '' && $oid === $keepOrderId) {
                continue; // Keep this order!
            }
            if (!empty($oid)) {
                deleteOrder($oid);
                $count++;
            }
        }
        
        if ($clearLeads) {
            $leadsFile = DATA_PATH . 'leads.json';
            if (file_exists($leadsFile)) {
                @file_put_contents($leadsFile, json_encode([], JSON_PRETTY_PRINT));
            }
        }
        
        if ($keepOrderId !== '') {
            setFlash('success', "Clean Slate Activated: {$count} orders deleted. Kept Order #{$keepOrderId} active in your pipeline!");
        } else {
            setFlash('success', "Fresh Start Activated: {$count} orders cleared from the database.");
        }
    } elseif ($act === 'edit_order') {
        $oid = trim($_POST['order_id'] ?? '');
        if ($oid) {
            $updated = updateOrderAdmin($oid, [
                'property_name'          => $_POST['property_name'] ?? '',
                'service_type'           => $_POST['service_type'] ?? '',
                'status'                 => $_POST['status'] ?? 'pending',
                'raw_images_count'       => (int)($_POST['raw_images_count'] ?? 0),
                'delivered_images_count' => (int)($_POST['delivered_images_count'] ?? 0),
                'billed_amount'          => (float)($_POST['billed_amount'] ?? 0.0),
                'cloud_link'             => trim($_POST['cloud_link'] ?? ''),
                'final_cloud_link'       => trim($_POST['final_cloud_link'] ?? ''),
                'instructions'           => trim($_POST['instructions'] ?? ''),
                'turnaround'             => trim($_POST['turnaround'] ?? '24h Standard')
            ]);
            if ($updated) {
                setFlash('success', "Order #{$oid} was updated successfully.");
            } else {
                setFlash('error', "Failed to update order #{$oid}.");
            }
        }
    }
    header('Location: /admin/' . (!empty($_GET['tab']) ? '?tab=' . urlencode($_GET['tab']) : ''));
    exit;
}

// Active Tab Mode: 'active' (default) vs 'delivered' (historical archive & records by date)
$activeTab = trim($_GET['tab'] ?? 'active');

// Search & Date Filters
$searchKeyword = trim($_GET['q'] ?? '');
$filterStatus  = trim($_GET['status'] ?? '');
$filterClient  = trim($_GET['client_id'] ?? '');
$dateFrom      = trim($_GET['from'] ?? '');
$dateTo        = trim($_GET['to'] ?? '');

$filteredOrders = array_filter($allOrders, function($o) use ($searchKeyword, $filterStatus, $filterClient, $dateFrom, $dateTo, $userMap) {
    if ($searchKeyword !== '') {
        $kw = strtolower($searchKeyword);
        $clientName = strtolower($userMap[$o['user_id']]['name'] ?? '');
        $clientEmail = strtolower($userMap[$o['user_id']]['email'] ?? '');
        $match = str_contains(strtolower($o['property_name']), $kw) ||
                 str_contains(strtolower($o['id']), $kw) ||
                 str_contains(strtolower($o['service_type']), $kw) ||
                 str_contains($clientName, $kw) ||
                 str_contains($clientEmail, $kw);
        if (!$match) return false;
    }
    if ($filterStatus !== '' && $o['status'] !== $filterStatus) return false;
    if ($filterClient !== '' && $o['user_id'] !== $filterClient) return false;
    if ($dateFrom !== '') {
        $orderDate = substr($o['created_at'], 0, 10);
        if ($orderDate < $dateFrom) return false;
    }
    if ($dateTo !== '') {
        $orderDate = substr($o['created_at'], 0, 10);
        if ($orderDate > $dateTo) return false;
    }
    return true;
});
$filteredOrders = array_values($filteredOrders);

// Separate Active Queue from Delivered Records
$activePipelineOrders = array_values(array_filter($filteredOrders, function($o) {
    return !in_array($o['status'] ?? '', ['delivered', 'sent_client', 'completed']);
}));

$deliveredRecordOrders = array_values(array_filter($filteredOrders, function($o) {
    return in_array($o['status'] ?? '', ['delivered', 'sent_client', 'completed']);
}));

// Group Delivered Orders By Date (Date-wise Production Log)
$deliveredByDate = [];
foreach ($deliveredRecordOrders as $do) {
    $dKey = substr($do['updated_at'] ?? $do['created_at'], 0, 10);
    if (!isset($deliveredByDate[$dKey])) {
        $deliveredByDate[$dKey] = [
            'date'         => $dKey,
            'orders'       => [],
            'total_photos' => 0,
            'total_amount' => 0.0
        ];
    }
    $deliveredByDate[$dKey]['orders'][] = $do;
    $deliveredByDate[$dKey]['total_photos'] += (int)($do['delivered_images_count'] ?: $do['raw_images_count'] ?: 0);
    $deliveredByDate[$dKey]['total_amount'] += (float)($do['billed_amount'] ?? 0.0);
}
krsort($deliveredByDate); // Sort newest date first
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $isManagerOnly ? "Production Manager Operations &amp; Reports" : "Admin Master Dashboard &amp; CRM" ?> — Estate HDR</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-[#0A0A0F] text-white font-sans antialiased min-h-screen flex flex-col">

<!-- Master Admin Header -->
<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8 space-y-8">
  <?= renderFlash() ?>

  <!-- ── 1. MASTER KPI SUMMARY GRID ───────────────────────────────── -->
  <div class="grid grid-cols-2 sm:grid-cols-5 gap-4">
    <!-- Active In Pipeline -->
    <div class="glass-card rounded-2xl p-4 border border-blue-500/40 bg-blue-950/10 space-y-1">
      <div class="text-[11px] font-bold text-blue-400 uppercase tracking-wider">Active Pipeline</div>
      <div class="text-3xl font-black text-blue-300"><?= count($activePipelineOrders) ?></div>
      <div class="text-[10px] text-gray-400">Due for processing</div>
    </div>

    <!-- Pending Intake -->
    <div class="glass-card rounded-2xl p-4 border border-amber-500/40 bg-amber-950/10 space-y-1">
      <div class="text-[11px] font-bold text-amber-400 uppercase tracking-wider">Pending Intake</div>
      <div class="text-3xl font-black text-amber-400"><?= $pendingDelivery ?></div>
      <div class="text-[10px] text-gray-400">Awaiting supervisor dispatch</div>
    </div>

    <!-- Needs Revisions -->
    <div class="glass-card rounded-2xl p-4 border border-red-500/40 bg-red-950/10 space-y-1">
      <div class="text-[11px] font-bold text-red-400 uppercase tracking-wider">Needs Revisions</div>
      <div class="text-3xl font-black text-red-400"><?= $pendingRevision ?></div>
      <div class="text-[10px] text-gray-400">Active revision rounds</div>
    </div>

    <!-- Delivered Orders Record -->
    <div class="glass-card rounded-2xl p-4 border border-emerald-500/40 bg-emerald-950/10 space-y-1">
      <div class="text-[11px] font-bold text-emerald-400 uppercase tracking-wider">Delivered Orders</div>
      <div class="text-3xl font-black text-emerald-300"><?= $deliveredJobs ?></div>
      <div class="text-[10px] text-emerald-400 font-bold">In completed record &darr;</div>
    </div>

    <!-- Total Ingested Orders -->
    <div class="glass-card rounded-2xl p-4 border border-dark-border space-y-1">
      <div class="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Total Orders Log</div>
      <div class="text-3xl font-black text-white"><?= $totalOrders ?></div>
      <div class="text-[10px] text-gray-500">Client: <?= $clientSubmitted ?> &bull; Proxy: <?= $adminSubmitted ?></div>
    </div>
  </div>

  <!-- ── 2. SEARCH & DATE FILTER BAR ─────────────────────────────── -->
  <div class="glass-card rounded-2xl p-4 border border-dark-border">
    <form method="GET" action="/admin/" class="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
      <input type="hidden" name="tab" value="<?= htmlspecialchars($activeTab) ?>">
      
      <!-- Search Keyword -->
      <div class="sm:col-span-4">
        <label class="form-label text-xs">Search Order / Client / Property</label>
        <input type="text" name="q" value="<?= htmlspecialchars($searchKeyword) ?>" class="form-input text-xs py-2 bg-[#161622]" placeholder="Search ID, name, email...">
      </div>

      <!-- Filter Client -->
      <div class="sm:col-span-3">
        <label class="form-label text-xs">Filter by Client</label>
        <select name="client_id" class="form-select text-xs py-2 bg-[#161622]">
          <option value="">All Clients (<?= count($allUsers) ?>)</option>
          <?php foreach ($allUsers as $u): ?>
            <option value="<?= htmlspecialchars($u['id']) ?>" <?= $filterClient === $u['id'] ? 'selected' : '' ?>>
              <?= htmlspecialchars($u['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <!-- Date Filter -->
      <div class="sm:col-span-3">
        <label class="form-label text-xs">Filter by Date</label>
        <input type="date" name="from" value="<?= htmlspecialchars($dateFrom) ?>" class="form-input text-xs py-2 text-gray-300 bg-[#161622]">
      </div>

      <div class="sm:col-span-2 flex gap-2">
        <button type="submit" class="btn-gold py-2 px-4 text-xs font-bold flex-1">Filter</button>
        <?php if ($searchKeyword || $filterStatus || $filterClient || $dateFrom || $dateTo): ?>
          <a href="/admin/?tab=<?= urlencode($activeTab) ?>" class="btn-ghost py-2 px-3 text-xs" title="Reset Filters">&times;</a>
        <?php endif; ?>
      </div>
    </form>
  </div>

  <!-- ── 3. WORKSPACE TAB SWITCHER (ACTIVE PIPELINE vs DELIVERED RECORD) -->
  <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-dark-border pb-4">
    <div class="flex items-center gap-3">
      <a href="/admin/?tab=active<?= $dateFrom ? '&from='.urlencode($dateFrom) : '' ?>" class="px-5 py-2.5 rounded-2xl text-xs font-black transition-all <?= $activeTab === 'active' ? 'bg-blue-600 text-white shadow-lg' : 'text-gray-400 hover:text-white bg-[#111118] border border-dark-border' ?>">
        ⚡ Active Production Pipeline (<?= count($activePipelineOrders) ?>)
      </a>
      <a href="/admin/?tab=delivered<?= $dateFrom ? '&from='.urlencode($dateFrom) : '' ?>" class="px-5 py-2.5 rounded-2xl text-xs font-black transition-all <?= $activeTab === 'delivered' ? 'bg-emerald-600 text-white shadow-lg' : 'text-gray-400 hover:text-white bg-[#111118] border border-dark-border' ?>">
        📦 Completed &amp; Delivered Orders Record (<?= count($deliveredRecordOrders) ?>)
      </a>
    </div>

    <div class="flex flex-wrap items-center gap-3">
      <?php if ($isOwner): ?>
        <button type="button" onclick="openPurgeOrdersModal()" class="btn-ghost text-xs py-2 px-3.5 font-bold text-red-400 border border-red-500/40 hover:bg-red-500/10 rounded-xl inline-flex items-center gap-1.5" title="Clear all orders database for a fresh start">
          <span>🧹</span> <span>Fresh Start: Clear All</span>
        </button>
      <?php endif; ?>
      <a href="/admin/order-new.php" class="btn-gold text-xs py-2 px-4 font-black shadow-glow inline-flex items-center gap-2">
        <span>+</span> <span>Proxy Order (On Behalf)</span>
      </a>
    </div>
  </div>

  <!-- ════════════════════════════════════════════════════════════════ -->
  <!-- ── VIEW 1: ACTIVE PRODUCTION PIPELINE (ONLY IN-PROGRESS ORDERS) ── -->
  <!-- ════════════════════════════════════════════════════════════════ -->
  <?php if ($activeTab === 'active'): ?>
    
    <?php if (empty($activePipelineOrders)): ?>
      <div class="glass-card rounded-3xl p-12 text-center space-y-3 border border-dark-border">
        <span class="text-4xl">🎉</span>
        <h3 class="text-lg font-bold text-white">All Active Jobs Completed &amp; Delivered!</h3>
        <p class="text-xs text-gray-400">There are no pending jobs in the active pipeline. All orders have been delivered to clients.</p>
        <a href="/admin/?tab=delivered" class="btn-ghost py-2 px-4 text-xs font-bold text-emerald-400 border border-emerald-500/40 inline-block mt-2">
          View Delivered Orders Record &rarr;
        </a>
      </div>
    <?php else: ?>
      <div class="glass-card rounded-3xl overflow-hidden border border-dark-border shadow-xl">
        <div class="overflow-x-auto">
          <table class="dashboard-table w-full text-xs">
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Client Name &amp; Contact</th>
                <th>Property Name</th>
                <th>Category</th>
                <th>Clearance</th>
                <th>Service</th>
                <th>Raw Photos</th>
                <th>Active Status</th>
                <th class="whitespace-nowrap">⏱️ Editor</th>
                <th class="whitespace-nowrap">🛡️ QA</th>
                <th>Date</th>
                <th class="text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($activePipelineOrders as $order): 
                $client = $userMap[$order['user_id']] ?? null;
                $fin = function_exists('getOrderFinancialStatus') ? getOrderFinancialStatus($order) : null;
                $dur = TurnaroundService::calculateOrderDurations($order);
              ?>
              <tr>
                <td class="font-mono text-gold font-bold">
                  #<?= strtoupper(substr($order['id'], 0, 8)) ?>
                </td>
                <td>
                  <div class="text-white font-bold"><?= htmlspecialchars($client['name'] ?? 'Unknown') ?></div>
                  <div class="text-gray-500 text-[11px] font-mono"><?= htmlspecialchars($client['email'] ?? '') ?></div>
                </td>
                <td>
                  <div class="text-white font-bold"><?= htmlspecialchars($order['property_name']) ?></div>
                  <?php if (!empty($order['cloud_link'])): ?>
                    <a href="<?= htmlspecialchars($order['cloud_link']) ?>" target="_blank" class="text-[11px] text-blue-400 hover:underline inline-flex items-center gap-1 font-mono mt-0.5">
                      <span>📁</span> <span>Download Raw Files ↗</span>
                    </a>
                  <?php endif; ?>
                </td>
                <td class="whitespace-nowrap">
                  <?= $fin['category_badge'] ?? '—' ?>
                </td>
                <td class="whitespace-nowrap">
                  <?= $fin['payment_badge'] ?? '—' ?>
                </td>
                <td class="text-gray-300"><?= htmlspecialchars($order['service_type']) ?></td>
                <td class="font-mono font-bold text-amber-300"><?= (int)($order['raw_images_count'] ?? 0) ?> raw</td>
                <td>
                  <span class="px-2.5 py-1 rounded-full text-xs font-bold inline-flex items-center gap-1.5 <?= statusBadgeClass($order['status']) ?>">
                    <span class="w-1.5 h-1.5 rounded-full bg-current animate-pulse"></span>
                    <?= statusLabel($order['status']) ?>
                  </span>
                </td>
                <td class="whitespace-nowrap font-mono text-[11px] <?= $dur['editor_badge_class'] ?>">
                  <?= htmlspecialchars($dur['editor_duration_formatted']) ?>
                </td>
                <td class="whitespace-nowrap font-mono text-[11px] <?= $dur['qa_badge_class'] ?>">
                  <?= htmlspecialchars($dur['qa_duration_formatted']) ?>
                </td>
                <td class="text-gray-400 font-mono"><?= date('M j, Y', strtotime($order['created_at'])) ?></td>
                <td class="text-right whitespace-nowrap">
                  <div class="flex items-center justify-end gap-1.5">
                    <a href="/admin/order-view.php?id=<?= urlencode($order['id']) ?>" class="btn-gold py-1 px-2.5 text-xs font-bold shadow-glow" title="Manage Order">
                      Manage &rarr;
                    </a>
                    <button type="button" onclick='openEditOrderModal(<?= json_encode($order, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>)' class="btn-ghost py-1 px-2 text-xs font-bold text-blue-400 border border-blue-500/30 hover:bg-blue-500/10 rounded-lg" title="Edit Order Details">
                      ✏️
                    </button>
                    <button type="button" onclick="confirmDeleteOrder('<?= htmlspecialchars($order['id'], ENT_QUOTES) ?>', '<?= htmlspecialchars($order['property_name'], ENT_QUOTES) ?>')" class="btn-ghost py-1 px-2 text-xs font-bold text-red-400 border border-red-500/30 hover:bg-red-500/10 rounded-lg" title="Delete Order">
                      🗑️
                    </button>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    <?php endif; ?>

  <!-- ════════════════════════════════════════════════════════════════ -->
  <!-- ── VIEW 2: DELIVERED ORDERS RECORD (DATE-WISE PRODUCTION LOG) ── -->
  <!-- ════════════════════════════════════════════════════════════════ -->
  <?php else: ?>

    <div class="space-y-6">
      <div class="flex items-center justify-between">
        <div>
          <div class="section-tag mb-1">Delivered Production Archive &amp; Audit Log</div>
          <h2 class="text-xl font-black text-white">Date-wise Delivered Orders Record</h2>
          <p class="text-xs text-gray-400">Chronological history of completed properties delivered to clients with photos count and billing records.</p>
        </div>
      </div>

      <?php if (empty($deliveredByDate)): ?>
        <div class="glass-card rounded-3xl p-12 text-center text-gray-500 text-sm">
          No delivered orders found for the selected filter criteria.
        </div>
      <?php else: ?>
        <?php foreach ($deliveredByDate as $dateKey => $dayGroup): ?>
          <div class="glass-card rounded-3xl p-6 border border-emerald-500/30 shadow-xl space-y-4">
            
            <!-- Date Group Header Summary -->
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-dark-border pb-3">
              <div class="flex items-center gap-3">
                <span class="text-xl">📅</span>
                <div>
                  <h3 class="text-base font-black text-white"><?= date('F j, Y (l)', strtotime($dateKey)) ?></h3>
                  <p class="text-xs text-gray-400 font-mono">Date Key: <?= $dateKey ?></p>
                </div>
              </div>

              <div class="flex items-center gap-4 text-xs font-mono">
                <span class="px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/40">
                  ✓ <?= count($dayGroup['orders']) ?> Orders Delivered
                </span>
                <span class="px-3 py-1 rounded-xl bg-blue-500/20 text-blue-300 font-bold border border-blue-500/40">
                  📸 <?= $dayGroup['total_photos'] ?> Photos Processed
                </span>
                <span class="px-3 py-1 rounded-xl bg-gold/20 text-gold font-black border border-gold/40">
                  💰 $<?= number_format($dayGroup['total_amount'], 2) ?> Billed
                </span>
              </div>
            </div>

            <!-- Orders Table for this Date -->
            <div class="overflow-x-auto">
              <table class="dashboard-table w-full text-xs">
                <thead>
                  <tr>
                    <th>Order ID</th>
                    <th>Client Name</th>
                    <th>Property Name</th>
                    <th>Category</th>
                    <th>Clearance</th>
                    <th>Service</th>
                    <th>Photos Delivered</th>
                    <th>Status</th>
                    <th class="whitespace-nowrap">⏱️ Retouch</th>
                    <th class="whitespace-nowrap">🛡️ QA</th>
                    <th>Cost Billed</th>
                    <th class="text-right">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($dayGroup['orders'] as $dOrd): 
                    $cl = $userMap[$dOrd['user_id']] ?? null;
                    $finD = function_exists('getOrderFinancialStatus') ? getOrderFinancialStatus($dOrd) : null;
                    $durD = TurnaroundService::calculateOrderDurations($dOrd);
                  ?>
                  <tr>
                    <td class="font-mono text-gray-400">#<?= strtoupper(substr($dOrd['id'], 0, 8)) ?></td>
                    <td>
                      <div class="font-bold text-white"><?= htmlspecialchars($cl['name'] ?? 'Client') ?></div>
                      <div class="text-[11px] text-gray-500 font-mono"><?= htmlspecialchars($cl['email'] ?? '') ?></div>
                    </td>
                    <td>
                      <div class="font-bold text-white"><?= htmlspecialchars($dOrd['property_name']) ?></div>
                    </td>
                    <td class="whitespace-nowrap">
                      <?= $finD['category_badge'] ?? '—' ?>
                    </td>
                    <td class="whitespace-nowrap">
                      <?= $finD['payment_badge'] ?? '—' ?>
                    </td>
                    <td class="text-gray-300"><?= htmlspecialchars($dOrd['service_type']) ?></td>
                    <td class="font-mono font-black text-emerald-400">
                      <?= (int)($dOrd['delivered_images_count'] ?: $dOrd['raw_images_count'] ?: 0) ?> Final Photos
                    </td>
                    <td>
                      <span class="px-2.5 py-1 rounded-full text-xs font-bold inline-flex items-center gap-1.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                        Delivered
                      </span>
                    </td>
                    <td class="whitespace-nowrap font-mono text-[11px] <?= $durD['editor_badge_class'] ?>">
                      <?= htmlspecialchars($durD['editor_duration_formatted']) ?>
                    </td>
                    <td class="whitespace-nowrap font-mono text-[11px] <?= $durD['qa_badge_class'] ?>">
                      <?= htmlspecialchars($durD['qa_duration_formatted']) ?>
                    </td>
                    <td class="font-mono font-bold text-gold">
                      $<?= number_format($dOrd['billed_amount'] ?? 0.0, 2) ?>
                    </td>
                    <td class="text-right whitespace-nowrap">
                      <div class="flex items-center justify-end gap-1.5">
                        <a href="/admin/order-view.php?id=<?= urlencode($dOrd['id']) ?>" class="btn-ghost py-1 px-2.5 text-xs font-bold border border-dark-border text-gray-300 hover:text-white rounded-lg" title="View Order Dossier">
                          View Dossier &rarr;
                        </a>
                        <button type="button" onclick='openEditOrderModal(<?= json_encode($dOrd, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>)' class="btn-ghost py-1 px-2 text-xs font-bold text-blue-400 border border-blue-500/30 hover:bg-blue-500/10 rounded-lg" title="Edit Order Details">
                          ✏️
                        </button>
                        <button type="button" onclick="confirmDeleteOrder('<?= htmlspecialchars($dOrd['id'], ENT_QUOTES) ?>', '<?= htmlspecialchars($dOrd['property_name'], ENT_QUOTES) ?>')" class="btn-ghost py-1 px-2 text-xs font-bold text-red-400 border border-red-500/30 hover:bg-red-500/10 rounded-lg" title="Delete Order">
                          🗑️
                        </button>
                      </div>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>

          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

  <?php endif; ?>

  <!-- ── 4. FREE TRIAL LEADS SECTION (NO SIGNUP) ──────────────────── -->
  <div class="glass-card rounded-3xl p-6 border border-dark-border shadow-xl space-y-4">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-dark-border pb-4">
      <div>
        <h2 class="text-base font-black text-white uppercase tracking-wider flex items-center gap-2">
          <span>🎁 Free Trial Leads (No Signup)</span>
          <span class="text-xs bg-gold/20 text-gold px-2.5 py-0.5 rounded-full font-mono font-bold"><?= count($allLeads) ?> Total Leads</span>
        </h2>
        <p class="text-gray-400 text-xs mt-0.5">Leads submitted via landing page trial form. All leads auto-bridge directly into Supervisor Daily Properties Hub as Free Trial Proxy Orders.</p>
      </div>
      <a href="/admin/supervisor-dashboard.php" class="btn-gold py-2 px-4 text-xs font-black shadow-glow inline-flex items-center gap-1.5 self-start sm:self-auto">
        <span>⚡ Open Supervisor Production Hub</span> &rarr;
      </a>
    </div>

    <?php if (empty($allLeads)): ?>
      <div class="text-center py-8 text-gray-500 text-xs">
        No pending trial requests.
      </div>
    <?php else: 
      $saasOrdersAll = function_exists('getSaaSOrders') ? getSaaSOrders() : [];
      $saasTrialMap = [];
      foreach ($saasOrdersAll as $so) {
        if (!empty($so['lead_id'])) $saasTrialMap[$so['lead_id']] = $so;
        elseif (str_starts_with($so['id'], 'TRIAL-')) $saasTrialMap[str_replace('TRIAL-', '', $so['id'])] = $so;
      }
    ?>
      <div class="overflow-x-auto">
        <table class="dashboard-table w-full text-xs">
          <thead>
            <tr>
              <th>Lead / Client</th>
              <th>WhatsApp / Phone</th>
              <th>Service</th>
              <th>Raw Photos Link</th>
              <th>Production Status</th>
              <th>Date</th>
              <th class="text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach (array_slice($allLeads, 0, 10) as $lead): 
              $tOrder = $saasTrialMap[$lead['id']] ?? $saasTrialMap[strtoupper($lead['id'])] ?? null;
              $liveStatus = $tOrder['status'] ?? ($lead['status'] ?? 'new');
            ?>
            <tr class="hover:bg-white/[0.02] transition-colors">
              <td>
                <div class="font-bold text-white"><?= htmlspecialchars($lead['name']) ?></div>
                <div class="text-[11px] text-gray-400 font-mono"><?= htmlspecialchars($lead['email']) ?></div>
              </td>
              <td class="font-mono text-emerald-400 font-bold"><?= htmlspecialchars($lead['phone'] ?? $lead['whatsapp'] ?? 'N/A') ?></td>
              <td>
                <span class="px-2 py-0.5 rounded-lg bg-white/5 border border-dark-border text-gray-300 font-medium">
                  <?= htmlspecialchars($lead['service'] ?? 'HDR Photo Editing') ?>
                </span>
              </td>
              <td>
                <?php if (!empty($lead['cloud_link'])): ?>
                  <a href="<?= htmlspecialchars($lead['cloud_link']) ?>" target="_blank" class="text-blue-400 hover:text-blue-300 hover:underline font-mono inline-flex items-center gap-1">
                    <span>📁</span> <span>Open Raw Photos ↗</span>
                  </a>
                <?php else: ?>
                  <span class="text-gray-600 font-mono">No link</span>
                <?php endif; ?>
              </td>
              <td>
                <?php if ($liveStatus === 'sent_client' || ($lead['status'] ?? '') === 'delivered'): ?>
                  <span class="px-2.5 py-1 rounded-full text-xs font-black inline-flex items-center gap-1.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    ✓ Delivered to Client
                  </span>
                <?php elseif ($liveStatus === 'approved' || $liveStatus === 'ready_delivery'): ?>
                  <span class="px-2.5 py-1 rounded-full text-xs font-black inline-flex items-center gap-1.5 bg-purple-500/20 text-purple-300 border border-purple-500/40">
                    <span class="w-1.5 h-1.5 rounded-full bg-purple-400 animate-pulse"></span>
                    🚀 QA Approved (Ready to Deliver)
                  </span>
                <?php elseif ($liveStatus === 'submitted_qa'): ?>
                  <span class="px-2.5 py-1 rounded-full text-xs font-bold inline-flex items-center gap-1.5 bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    <span class="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                    🔍 In QA Review (TL)
                  </span>
                <?php elseif ($liveStatus === 'assigned_editor' || !empty($tOrder['assigned_editor_name'])): ?>
                  <span class="px-2.5 py-1 rounded-full text-xs font-bold inline-flex items-center gap-1.5 bg-blue-500/20 text-blue-300 border border-blue-500/30">
                    <span class="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse"></span>
                    🎨 Editing (<?= htmlspecialchars($tOrder['assigned_editor_name'] ?? 'Editor') ?>)
                  </span>
                <?php else: ?>
                  <span class="px-2.5 py-1 rounded-full text-xs font-bold inline-flex items-center gap-1.5 bg-gold/20 text-gold border border-gold/40">
                    <span class="w-1.5 h-1.5 rounded-full bg-gold"></span>
                    🎁 In Supervisor Hub (New)
                  </span>
                <?php endif; ?>
              </td>
              <td class="text-gray-400 font-mono text-[11px]"><?= date('M j, Y', strtotime($lead['created_at'] ?? 'now')) ?></td>
              <td class="text-right">
                <a href="/admin/supervisor-dashboard.php" class="btn-ghost py-1 px-3 text-xs font-bold border border-gold/40 text-gold hover:bg-gold hover:text-dark transition-all rounded-lg inline-flex items-center gap-1">
                  <span>⚡ Manage in Supervisor Hub</span> &rarr;
                </a>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <!-- ════════════════════════════════════════════════════════════════ -->
  <!-- ── MODAL 1: EDIT ORDER DETAILS ──────────────────────────────── -->
  <!-- ════════════════════════════════════════════════════════════════ -->
  <div id="editOrderModal" class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
    <div class="glass-card rounded-2xl p-6 max-w-xl w-full border border-dark-border shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
      <div class="flex items-center justify-between border-b border-dark-border pb-3">
        <div>
          <h3 class="text-base font-black text-white flex items-center gap-2">
            <span>✏️</span> <span>Edit Order Details</span>
          </h3>
          <p id="editOrderModalSubtitle" class="text-xs font-mono text-gold font-bold mt-0.5">ORDER #</p>
        </div>
        <button type="button" onclick="closeEditOrderModal()" class="text-gray-400 hover:text-white text-xl font-bold">&times;</button>
      </div>

      <form method="POST" action="/admin/<?= $activeTab ? '?tab=' . urlencode($activeTab) : '' ?>" class="space-y-4">
        <?= csrfField() ?>
        <input type="hidden" name="admin_order_action" value="edit_order">
        <input type="hidden" name="order_id" id="editOrderId">

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label class="form-label text-xs">Property Title / Address</label>
            <input type="text" name="property_name" id="editPropertyName" required class="form-input text-xs">
          </div>
          <div>
            <label class="form-label text-xs">Service Type</label>
            <input type="text" name="service_type" id="editServiceType" required class="form-input text-xs">
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label class="form-label text-xs">Status</label>
            <select name="status" id="editStatus" class="form-select text-xs">
              <option value="pending">Pending Intake</option>
              <option value="in_progress">In Progress (Editing)</option>
              <option value="assigned_editor">Assigned to Editor</option>
              <option value="submitted_qa">Submitted to QA</option>
              <option value="approved">QA Approved</option>
              <option value="delivered">Delivered to Client</option>
              <option value="completed">Completed</option>
              <option value="amendment_requested">Amendment Requested</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>
          <div>
            <label class="form-label text-xs">Raw Photos Count</label>
            <input type="number" name="raw_images_count" id="editRawCount" min="0" class="form-input text-xs">
          </div>
          <div>
            <label class="form-label text-xs">Delivered Photos Count</label>
            <input type="number" name="delivered_images_count" id="editDeliveredCount" min="0" class="form-input text-xs">
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label class="form-label text-xs">Billed Amount ($ USD)</label>
            <input type="number" step="0.01" name="billed_amount" id="editBilledAmount" min="0" class="form-input text-xs font-mono font-bold text-gold">
          </div>
          <div>
            <label class="form-label text-xs">Turnaround SLA</label>
            <select name="turnaround" id="editTurnaround" class="form-select text-xs">
              <option value="24h Standard">24h Standard</option>
              <option value="12h Rush">12h Rush</option>
              <option value="6h Urgent">6h Urgent</option>
            </select>
          </div>
        </div>

        <div>
          <label class="form-label text-xs">Raw Files Download URL (Client Link)</label>
          <input type="url" name="cloud_link" id="editCloudLink" class="form-input text-xs font-mono" placeholder="https://dropbox.com/... or https://wetransfer.com/...">
        </div>

        <div>
          <label class="form-label text-xs">Final Delivered Cloud Link (High-Res Output)</label>
          <input type="url" name="final_cloud_link" id="editFinalCloudLink" class="form-input text-xs font-mono" placeholder="https://dropbox.com/... or https://wetransfer.com/...">
        </div>

        <div>
          <label class="form-label text-xs">Special Instructions / Notes</label>
          <textarea name="instructions" id="editInstructions" rows="2" class="form-input text-xs resize-none" placeholder="Client instructions or editor notes..."></textarea>
        </div>

        <div class="flex items-center justify-end gap-3 pt-3 border-t border-dark-border">
          <button type="button" onclick="closeEditOrderModal()" class="btn-ghost py-2 px-4 text-xs font-bold">Cancel</button>
          <button type="submit" class="btn-gold py-2 px-6 text-xs font-black shadow-glow">Save Order Changes</button>
        </div>
      </form>
    </div>
  </div>

  <!-- ════════════════════════════════════════════════════════════════ -->
  <!-- ── MODAL 2: DELETE ORDER CONFIRMATION ────────────────────────── -->
  <!-- ════════════════════════════════════════════════════════════════ -->
  <div id="deleteOrderModal" class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 hidden flex items-center justify-center p-4">
    <div class="glass-card rounded-2xl p-6 max-w-md w-full border border-red-500/40 shadow-2xl space-y-4">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-400 text-xl font-bold">
          ⚠️
        </div>
        <div>
          <h3 class="text-base font-black text-white">Delete Order?</h3>
          <p class="text-xs text-gray-400">This will permanently remove the order record.</p>
        </div>
      </div>

      <div class="p-3.5 rounded-xl bg-red-950/20 border border-red-800/40 text-xs text-red-300">
        Are you sure you want to delete order <strong id="deleteOrderDisplayId" class="text-white font-mono"></strong> (<span id="deleteOrderDisplayTitle" class="text-gray-200"></span>)?
      </div>

      <form method="POST" action="/admin/<?= $activeTab ? '?tab=' . urlencode($activeTab) : '' ?>" class="flex items-center justify-end gap-3 pt-2">
        <?= csrfField() ?>
        <input type="hidden" name="admin_order_action" value="delete_order">
        <input type="hidden" name="order_id" id="deleteOrderIdInput">
        <button type="button" onclick="closeDeleteOrderModal()" class="btn-ghost py-2 px-4 text-xs font-bold">Cancel</button>
        <button type="submit" class="py-2 px-5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs shadow-lg transition-all">
          Yes, Delete Order
        </button>
      </form>
    </div>
  </div>

  <!-- ════════════════════════════════════════════════════════════════ -->
  <!-- ── MODAL 3: SMART PURGE & SELECTIVE CLEAN SLATE ──────────────── -->
  <!-- ════════════════════════════════════════════════════════════════ -->
  <div id="purgeOrdersModal" class="fixed inset-0 bg-black/85 backdrop-blur-md z-50 hidden flex items-center justify-center p-4">
    <div class="glass-card rounded-3xl p-6 sm:p-8 max-w-lg w-full border border-red-500/50 shadow-2xl space-y-5">
      
      <div class="flex items-center gap-3.5 border-b border-dark-border pb-4">
        <div class="w-12 h-12 rounded-2xl bg-red-600/20 border border-red-500 flex items-center justify-center text-red-400 text-2xl font-bold">
          🧹
        </div>
        <div>
          <h3 class="text-lg font-black text-white">Smart Clean Slate &amp; Order Purge</h3>
          <p class="text-xs text-gray-400">Delete all demo/test orders or keep only 1 selected client order.</p>
        </div>
      </div>

      <form method="POST" action="/admin/" class="space-y-4">
        <?= csrfField() ?>
        <input type="hidden" name="admin_order_action" value="purge_all_orders">

        <div class="space-y-2">
          <label class="form-label text-xs font-bold text-gray-300">Clean Slate Options:</label>
          
          <div class="p-3.5 rounded-2xl bg-dark/90 border border-dark-border space-y-2.5 text-xs">
            <label class="flex items-center gap-2.5 cursor-pointer text-gray-200">
              <input type="radio" name="purge_mode" value="all" checked onchange="toggleKeepOrderDropdown(false)" class="text-red-600 focus:ring-red-500">
              <span><strong>Wipe All Orders (<?= $totalOrders ?> Total):</strong> Completely clear all old &amp; test orders.</span>
            </label>

            <label class="flex items-center gap-2.5 cursor-pointer text-gray-200">
              <input type="radio" name="purge_mode" value="keep_one" onchange="toggleKeepOrderDropdown(true)" class="text-gold focus:ring-gold">
              <span><strong>Keep Only One Order:</strong> Delete all old orders EXCEPT 1 real order below.</span>
            </label>
          </div>
        </div>

        <!-- Keep Single Order Dropdown (Conditional) -->
        <div id="keepOrderSelectContainer" class="hidden space-y-1.5 p-3 rounded-2xl bg-[#141422] border border-gold/40">
          <label class="form-label text-xs font-black text-gold">Select the 1 Order you want to KEEP:</label>
          <select name="keep_order_id" id="keepOrderIdSelect" class="form-select text-xs py-2.5 bg-[#0B0B12] text-white w-full border border-gold/40 rounded-xl">
            <option value="">-- Choose Order to Keep --</option>
            <?php foreach ($allOrders as $o): 
              $cName = $userMap[$o['user_id']]['name'] ?? ($o['client_name'] ?? 'Client');
            ?>
              <option value="<?= htmlspecialchars($o['id']) ?>">
                #<?= htmlspecialchars($o['id']) ?> — <?= htmlspecialchars($o['property_name']) ?> (<?= htmlspecialchars($cName) ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- Optional: Clear Trial Leads -->
        <div class="flex items-center gap-2.5 px-1">
          <input type="checkbox" name="clear_leads" id="clearLeadsCheckbox" value="1" class="rounded text-red-600 focus:ring-red-500">
          <label for="clearLeadsCheckbox" class="text-xs text-gray-400 cursor-pointer">Also clear all demo free trial leads from the leads table.</label>
        </div>

        <div class="flex items-center justify-end gap-3 pt-3 border-t border-dark-border">
          <button type="button" onclick="closePurgeOrdersModal()" class="btn-ghost py-2.5 px-5 text-xs font-bold">Cancel</button>
          <button type="submit" class="py-2.5 px-6 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs shadow-lg transition-all flex items-center gap-1.5">
            <span>🧹 Execute Clean Slate</span>
          </button>
        </div>
      </form>
    </div>
  </div>

</main>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
function openEditOrderModal(order) {
  if (!order) return;
  document.getElementById('editOrderId').value = order.id || '';
  document.getElementById('editOrderModalSubtitle').textContent = `ORDER #${(order.id || '').toUpperCase()}`;
  document.getElementById('editPropertyName').value = order.property_name || '';
  document.getElementById('editServiceType').value = order.service_type || 'HDR Photo Editing';
  document.getElementById('editStatus').value = order.status || 'pending';
  document.getElementById('editRawCount').value = order.raw_images_count || 0;
  document.getElementById('editDeliveredCount').value = order.delivered_images_count || 0;
  document.getElementById('editBilledAmount').value = parseFloat(order.billed_amount || 0).toFixed(2);
  document.getElementById('editTurnaround').value = order.turnaround || '24h Standard';
  document.getElementById('editCloudLink').value = order.cloud_link || '';
  document.getElementById('editFinalCloudLink').value = order.final_cloud_link || '';
  document.getElementById('editInstructions').value = order.instructions || '';
  document.getElementById('editOrderModal').classList.remove('hidden');
}

function closeEditOrderModal() {
  document.getElementById('editOrderModal').classList.add('hidden');
}

function confirmDeleteOrder(orderId, propName) {
  document.getElementById('deleteOrderIdInput').value = orderId;
  document.getElementById('deleteOrderDisplayId').textContent = `#${orderId.toUpperCase()}`;
  document.getElementById('deleteOrderDisplayTitle').textContent = propName;
  document.getElementById('deleteOrderModal').classList.remove('hidden');
}

function closeDeleteOrderModal() {
  document.getElementById('deleteOrderModal').classList.add('hidden');
}

function toggleKeepOrderDropdown(show) {
  const container = document.getElementById('keepOrderSelectContainer');
  if (show) {
    container.classList.remove('hidden');
  } else {
    container.classList.add('hidden');
    document.getElementById('keepOrderIdSelect').value = '';
  }
}

function openPurgeOrdersModal() {
  document.getElementById('purgeOrdersModal').classList.remove('hidden');
}

function closePurgeOrdersModal() {
  document.getElementById('purgeOrdersModal').classList.add('hidden');
}
</script>
</body>
</html>
