<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/audit.php';

requireAdmin();
enforceRoleAccess();

$currentAdmin = currentAdminUser();
$adminRoles   = getAdminRoles();
$isOwner      = in_array('owner', $adminRoles) || in_array('super_admin', $adminRoles);
$canDelete    = $isOwner || in_array('manager', $adminRoles);
$canEditOrder = $isOwner || in_array('manager', $adminRoles) || in_array('supervisor', $adminRoles);

$allOrders = getAllOrders();
$allUsers  = getUsers();

$userMap = [];
foreach ($allUsers as $u) $userMap[$u['id']] = $u;

// ── Handle GET delete ──────────────────────────────────────────────────────
if (isset($_GET['delete_order_id']) && $canDelete) {
    $oid = trim($_GET['delete_order_id']);
    deleteOrder($oid);
    logAuditEvent('order.delete', $oid, ['method' => 'GET']);
    setFlash('success', "Order #{$oid} permanently deleted from all queues.");
    header('Location: /admin/orders.php');
    exit;
}

// ── Handle POST Actions (Full Admin Authority) ─────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_order_action'])) {
    verifyCsrf();
    $act = $_POST['admin_order_action'];

    // 1. DELETE ORDER
    if ($act === 'delete_order' && $canDelete) {
        $oid = trim($_POST['order_id'] ?? '');
        deleteOrder($oid);
        logAuditEvent('order.delete', $oid, ['method' => 'POST']);
        setFlash('success', "Order #{$oid} permanently deleted.");
    }

    // 2. SWITCH ORDER TYPE (FREE TRIAL VS LIVE ORDER)
    elseif ($act === 'switch_order_type' && $canEditOrder) {
        $oid = trim($_POST['order_id'] ?? '');
        $newType = trim($_POST['order_type'] ?? 'live_order');
        setOrderType($oid, $newType);
        $typeLabel = ($newType === 'free_trial') ? '🎁 Free Trial ($0.00)' : '⚡ Live Order (Paid)';
        logAuditEvent('order.type_change', $oid, ['new_type' => $newType]);
        setFlash('success', "Order #{$oid} classification updated to: {$typeLabel}");
    }

    // 3. DIRECT STATUS UPDATE (1-CLICK DROPDOWN)
    elseif ($act === 'update_order_status' && $canEditOrder) {
        $oid = trim($_POST['order_id'] ?? '');
        $newStatus = trim($_POST['new_status'] ?? '');
        if (!empty($oid) && !empty($newStatus)) {
            updateOrderStatus($oid, $newStatus);
            logAuditEvent('order.status_change', $oid, ['new_status' => $newStatus]);
            setFlash('success', "Order #{$oid} status updated to " . strtoupper(str_replace('_', ' ', $newStatus)) . ".");
        }
    }

    // 4. QUICK COMPLETE / DELIVER ORDER
    elseif ($act === 'quick_complete_order' && $canEditOrder) {
        $oid = trim($_POST['order_id'] ?? '');
        $cloudLink = trim($_POST['final_cloud_link'] ?? '');
        $delCount  = (int)($_POST['delivered_images_count'] ?? 0);
        $order = getOrder($oid);

        if ($order) {
            $isTrial = !empty($order['is_trial']) || (($order['order_type'] ?? '') === 'free_trial') || str_starts_with(strtoupper($oid), 'TRIAL-');
            $billed = $isTrial ? 0.0 : (float)($order['billed_amount'] ?? 0.0);
            if ($delCount <= 0) {
                $delCount = (int)($order['delivered_images_count'] ?: $order['raw_images_count'] ?: 1);
            }
            if (empty($cloudLink)) {
                $cloudLink = $order['final_cloud_link'] ?? ($order['cloud_link'] ?? 'https://estatehdr.com/portal');
            }

            deliverOrderWithTracking($oid, $cloudLink, $delCount, $billed, 'Your order has been completed and delivered by management.');
            updateOrderStatus($oid, 'delivered');
            logAuditEvent('order.quick_complete', $oid, ['delivered_count' => $delCount, 'is_trial' => $isTrial]);
            setFlash('success', "Order #{$oid} marked as Completed / Delivered! Moved to Delivered Records.");
        }
        header('Location: /admin/orders.php?tab=delivered');
        exit;
    }

    // 5. QUICK EDIT ORDER DETAILS (MODAL)
    elseif ($act === 'quick_edit_order' && $canEditOrder) {
        $oid = trim($_POST['order_id'] ?? '');
        $orderType = trim($_POST['order_type'] ?? 'live_order');
        $isTrial = ($orderType === 'free_trial');
        $billed = $isTrial ? 0.0 : (float)($_POST['billed_amount'] ?? 0.0);

        updateOrderAdmin($oid, [
            'property_name'          => trim($_POST['property_name'] ?? ''),
            'service_type'           => trim($_POST['service_type'] ?? ''),
            'status'                 => trim($_POST['status'] ?? 'pending'),
            'order_type'             => $orderType,
            'is_trial'               => $isTrial,
            'raw_images_count'       => max(0, (int)($_POST['raw_images_count'] ?? 0)),
            'delivered_images_count' => max(0, (int)($_POST['delivered_images_count'] ?? 0)),
            'billed_amount'          => $billed,
            'cloud_link'             => trim($_POST['cloud_link'] ?? ''),
            'final_cloud_link'       => trim($_POST['final_cloud_link'] ?? ''),
            'instructions'           => trim($_POST['instructions'] ?? '')
        ]);
        setOrderType($oid, $orderType);
        logAuditEvent('order.admin_edit', $oid, ['property' => $_POST['property_name'] ?? '', 'status' => $_POST['status'] ?? '']);
        setFlash('success', "Order #{$oid} details successfully updated.");
    }

    // 6. PURGE ALL ORDERS (OWNER ONLY)
    elseif ($act === 'purge_all_orders' && $isOwner) {
        $all = getAllOrders();
        $cnt = 0;
        foreach ($all as $o) { if (!empty($o['id'])) { deleteOrder($o['id']); $cnt++; } }
        $saasFile = DATA_PATH . 'saas_orders.json';
        if (file_exists($saasFile)) file_put_contents($saasFile, json_encode([], JSON_PRETTY_PRINT), LOCK_EX);
        logAuditEvent('order.purge_all', 'all_orders', ['count' => $cnt]);
        setFlash('success', "All {$cnt} orders purged from the system.");
    }

    header('Location: /admin/orders.php');
    exit;
}

// ── Filters ───────────────────────────────────────────────────────────────
$searchQ         = trim($_GET['q'] ?? '');
$filterStatus    = trim($_GET['status'] ?? '');
$filterClient    = trim($_GET['client_id'] ?? '');
$filterOrderType = trim($_GET['order_type'] ?? '');
$dateFrom        = trim($_GET['from'] ?? '');
$dateTo          = trim($_GET['to'] ?? '');
$activeTab       = trim($_GET['tab'] ?? 'active');

$filteredOrders = array_values(array_filter($allOrders, function($o) use ($searchQ, $filterStatus, $filterClient, $filterOrderType, $dateFrom, $dateTo, $userMap) {
    if ($searchQ !== '') {
        $kw = strtolower($searchQ);
        $cn = strtolower($userMap[$o['user_id'] ?? '']['name'] ?? ($o['client_name'] ?? ''));
        $ce = strtolower($userMap[$o['user_id'] ?? '']['email'] ?? ($o['client_email'] ?? ''));
        if (!str_contains(strtolower($o['id'] ?? ''), $kw) &&
            !str_contains(strtolower($o['property_name'] ?? ''), $kw) &&
            !str_contains(strtolower($o['service_type'] ?? ''), $kw) &&
            !str_contains($cn, $kw) && !str_contains($ce, $kw)) return false;
    }
    if ($filterStatus !== '' && ($o['status'] ?? '') !== $filterStatus) return false;
    if ($filterClient !== '' && ($o['user_id'] ?? '') !== $filterClient) return false;
    
    $isTrial = !empty($o['is_trial']) || (($o['order_type'] ?? '') === 'free_trial') || (($o['service_type'] ?? '') === 'free_trial') || stripos($o['id'] ?? '', 'TRIAL-') === 0;
    if ($filterOrderType === 'free_trial' && !$isTrial) return false;
    if ($filterOrderType === 'live_order' && $isTrial) return false;

    if ($dateFrom !== '' && substr($o['created_at'] ?? '', 0, 10) < $dateFrom) return false;
    if ($dateTo   !== '' && substr($o['created_at'] ?? '', 0, 10) > $dateTo)   return false;
    return true;
}));

$deliveredSt = ['delivered','sent_client','completed'];
$pendingSt   = ['pending', 'new', 'received'];
$inProdSt    = ['in_progress', 'assigned_editor', 'assigned_tl', 'submitted_qa', 'resubmitted', 'revision_required', 'amendment_requested', 'ready_delivery', 'approved'];

$activeOrders    = array_values(array_filter($filteredOrders, fn($o) => !in_array($o['status'] ?? '', $deliveredSt)));
$deliveredOrders = array_values(array_filter($filteredOrders, fn($o) =>  in_array($o['status'] ?? '', $deliveredSt)));
$pendingOrders   = array_values(array_filter($filteredOrders, fn($o) =>  in_array($o['status'] ?? '', $pendingSt)));
$inProdOrders    = array_values(array_filter($filteredOrders, fn($o) =>  in_array($o['status'] ?? '', $inProdSt)));
$amendOrders     = array_values(array_filter($filteredOrders, fn($o) => in_array($o['status'] ?? '', ['revision_required', 'amendment_requested']) || !empty($o['annotations'])));
$trialOrders     = array_values(array_filter($filteredOrders, fn($o) => !empty($o['is_trial']) || (($o['order_type'] ?? '') === 'free_trial') || (($o['service_type'] ?? '') === 'free_trial') || stripos($o['id'] ?? '', 'TRIAL-') === 0));
$liveOrders      = array_values(array_filter($filteredOrders, fn($o) => empty($o['is_trial']) && (($o['order_type'] ?? '') !== 'free_trial') && (($o['service_type'] ?? '') !== 'free_trial') && stripos($o['id'] ?? '', 'TRIAL-') !== 0));

if ($activeTab === 'delivered') {
    $showOrders = $deliveredOrders;
} elseif ($activeTab === 'pending') {
    $showOrders = $pendingOrders;
} elseif ($activeTab === 'in_production') {
    $showOrders = $inProdOrders;
} elseif ($activeTab === 'amendments') {
    $showOrders = $amendOrders;
} elseif ($activeTab === 'free_trial') {
    $showOrders = $trialOrders;
} elseif ($activeTab === 'live_order') {
    $showOrders = $liveOrders;
} elseif ($activeTab === 'all') {
    $showOrders = $filteredOrders;
} else {
    $showOrders = $activeOrders;
}

$totalOrders     = count($allOrders);
$freeTrialCount  = count(array_filter($allOrders, fn($o) => !empty($o['is_trial']) || (($o['order_type'] ?? '') === 'free_trial') || (($o['service_type'] ?? '') === 'free_trial') || stripos($o['id'] ?? '', 'TRIAL-') === 0));
$liveOrderCount  = max(0, $totalOrders - $freeTrialCount);
$activeCount     = count(array_filter($allOrders, fn($o) => !in_array($o['status'] ?? '', $deliveredSt)));
$deliveredCount  = count(array_filter($allOrders, fn($o) =>  in_array($o['status'] ?? '', $deliveredSt)));
$pendingCount    = count(array_filter($allOrders, fn($o) => in_array($o['status'] ?? '', $pendingSt)));
$inProdCount     = count(array_filter($allOrders, fn($o) => in_array($o['status'] ?? '', $inProdSt)));
$revisionCount   = count(array_filter($allOrders, fn($o) => in_array($o['status'] ?? '', ['revision_required','amendment_requested'])));

$statusLabels = [
    'pending'           => ['label' => 'Pending',         'cls' => 'bg-amber-500/20 text-amber-300 border-amber-500/40'],
    'in_progress'       => ['label' => 'In Progress',     'cls' => 'bg-blue-500/20 text-blue-400 border-blue-500/40'],
    'assigned_editor'   => ['label' => 'Assigned Editor', 'cls' => 'bg-blue-500/20 text-blue-400 border-blue-500/40'],
    'assigned_tl'       => ['label' => 'Assigned TL',     'cls' => 'bg-purple-500/20 text-purple-300 border-purple-500/40'],
    'submitted_qa'      => ['label' => 'QA Review',       'cls' => 'bg-purple-500/20 text-purple-300 border-purple-500/40'],
    'resubmitted'       => ['label' => 'Resubmitted',     'cls' => 'bg-purple-500/20 text-purple-300 border-purple-500/40'],
    'revision_required' => ['label' => 'Revision Req.',   'cls' => 'bg-red-500/20 text-red-400 border-red-500/40'],
    'amendment_requested'=> ['label'=> 'Amendment',       'cls' => 'bg-red-500/20 text-red-400 border-red-500/40'],
    'approved'          => ['label' => 'Approved',        'cls' => 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'],
    'ready_delivery'    => ['label' => 'Ready Delivery',  'cls' => 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'],
    'delivered'         => ['label' => 'Delivered',       'cls' => 'bg-emerald-600/20 text-emerald-300 border-emerald-600/40'],
    'sent_client'       => ['label' => 'Sent to Client',  'cls' => 'bg-emerald-600/20 text-emerald-300 border-emerald-600/40'],
    'completed'         => ['label' => 'Completed',       'cls' => 'bg-emerald-800/20 text-emerald-200 border-emerald-800/40'],
    'cancelled'         => ['label' => 'Cancelled',       'cls' => 'bg-gray-500/20 text-gray-400 border-gray-500/40'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Orders Management &mdash; Estate HDR Admin</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
tailwind.config = {
  theme: {
    extend: {
      colors: {
        gold: { DEFAULT: '#C9A84C', dark: '#9A7A2E' },
        dark: { DEFAULT: '#0A0A0F', card: '#111118', border: '#1E1E2E' }
      }
    }
  }
};
</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-[#0A0A0F] text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8 space-y-6">
  <?= renderFlash() ?>

  <!-- PAGE HEADER -->
  <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
    <div>
      <h1 class="text-2xl font-black text-white">&#128203; Orders Management</h1>
      <p class="text-xs text-gray-400 mt-1">Full control panel: Change status, mark complete, edit details, or delete any order.</p>
    </div>
    <div class="flex items-center gap-3 flex-wrap">
      <a href="/admin/order-new.php" class="btn-gold py-2 px-4 text-xs font-black shadow-glow inline-flex items-center gap-1.5">
        &#43; New Order
      </a>
      <?php if ($isOwner && $totalOrders > 0): ?>
      <button type="button" id="btnOpenPurgeAll"
        class="py-2 px-4 rounded-xl bg-red-600/20 hover:bg-red-600/30 text-red-300 border border-red-500/40 text-xs font-black transition-all inline-flex items-center gap-1.5">
        &#x1F9F9; Purge All Orders
      </button>
      <?php endif; ?>
    </div>
  </div>

  <!-- KPI CARDS -->
  <div class="grid grid-cols-2 sm:grid-cols-5 gap-4">
    <div class="glass-card rounded-2xl p-4 border border-dark-border space-y-1">
      <div class="text-[11px] font-bold text-gray-400 uppercase tracking-wider">Total Orders</div>
      <div class="text-3xl font-black text-white"><?= $totalOrders ?></div>
    </div>
    <div class="glass-card rounded-2xl p-4 border border-blue-500/40 bg-blue-950/10 space-y-1">
      <div class="text-[11px] font-bold text-blue-400 uppercase tracking-wider">⚡ Live Orders</div>
      <div class="text-3xl font-black text-blue-300"><?= $liveOrderCount ?></div>
    </div>
    <div class="glass-card rounded-2xl p-4 border border-amber-500/40 bg-amber-950/10 space-y-1">
      <div class="text-[11px] font-bold text-amber-400 uppercase tracking-wider">🎁 Free Trials</div>
      <div class="text-3xl font-black text-amber-300"><?= $freeTrialCount ?></div>
    </div>
    <div class="glass-card rounded-2xl p-4 border border-purple-500/40 bg-purple-950/10 space-y-1">
      <div class="text-[11px] font-bold text-purple-400 uppercase tracking-wider">Active Pipeline</div>
      <div class="text-3xl font-black text-purple-300"><?= $activeCount ?></div>
    </div>
    <div class="glass-card rounded-2xl p-4 border border-emerald-500/40 bg-emerald-950/10 space-y-1">
      <div class="text-[11px] font-bold text-emerald-400 uppercase tracking-wider">Delivered Records</div>
      <div class="text-3xl font-black text-emerald-300"><?= $deliveredCount ?></div>
    </div>
  </div>

  <!-- FILTER BAR -->
  <div class="glass-card rounded-2xl p-4 border border-dark-border">
    <form method="GET" action="/admin/orders.php" class="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
      <input type="hidden" name="tab" value="<?= htmlspecialchars($activeTab) ?>">
      <div class="sm:col-span-3">
        <label class="form-label text-xs">Search Order / Client / Property</label>
        <input type="text" name="q" value="<?= htmlspecialchars($searchQ) ?>" class="form-input text-xs py-2 bg-[#161622]" placeholder="Order ID, property name, service...">
      </div>
      <div class="sm:col-span-2">
        <label class="form-label text-xs">Order Type</label>
        <select name="order_type" class="form-select text-xs py-2 bg-[#161622]">
          <option value="">All Types</option>
          <option value="live_order" <?= $filterOrderType === 'live_order' ? 'selected' : '' ?>>⚡ Live Orders (Paid)</option>
          <option value="free_trial" <?= $filterOrderType === 'free_trial' ? 'selected' : '' ?>>🎁 Free Trials ($0.00)</option>
        </select>
      </div>
      <div class="sm:col-span-2">
        <label class="form-label text-xs">Status</label>
        <select name="status" class="form-select text-xs py-2 bg-[#161622]">
          <option value="">All Statuses</option>
          <?php foreach ($statusLabels as $sv => $sd): ?>
            <option value="<?= $sv ?>" <?= $filterStatus === $sv ? 'selected' : '' ?>><?= $sd['label'] ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="sm:col-span-2">
        <label class="form-label text-xs">Client</label>
        <select name="client_id" class="form-select text-xs py-2 bg-[#161622]">
          <option value="">All Clients</option>
          <?php foreach ($allUsers as $u): ?>
            <option value="<?= htmlspecialchars($u['id']) ?>" <?= $filterClient === $u['id'] ? 'selected' : '' ?>><?= htmlspecialchars($u['name'] ?? $u['email']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="sm:col-span-3 flex gap-2">
        <button type="submit" class="btn-gold py-2 px-4 text-xs font-bold flex-1">Apply Filter</button>
        <a href="/admin/orders.php" class="btn-ghost py-2 px-4 text-xs font-bold flex-1 text-center">Reset</a>
      </div>
    </form>
  </div>

  <!-- TABS -->
  <div class="flex flex-wrap gap-1 border-b border-dark-border">
    <?php
    $tabs = [
        'active'        => ['label' => '⚡ Active Pipeline',    'count' => $activeCount,     'color' => 'blue'],
        'pending'       => ['label' => '⏳ Pending Intake',     'count' => $pendingCount,    'color' => 'amber'],
        'in_production' => ['label' => '⚙️ In Production',      'count' => $inProdCount,     'color' => 'indigo'],
        'amendments'    => ['label' => '✏️ Amendments',         'count' => $revisionCount,   'color' => 'amber'],
        'delivered'     => ['label' => '✅ Delivered Records',  'count' => $deliveredCount,  'color' => 'emerald'],
        'free_trial'    => ['label' => '🎁 Free Trials',        'count' => $freeTrialCount,  'color' => 'amber'],
        'live_order'    => ['label' => '💎 Live Orders',        'count' => $liveOrderCount,  'color' => 'blue'],
        'all'           => ['label' => '📋 All Orders',         'count' => $totalOrders,     'color' => 'gray'],
    ];
    foreach ($tabs as $tabKey => $tabData):
        $isAct = $activeTab === $tabKey;
        $qp = http_build_query(array_merge($_GET, ['tab' => $tabKey]));
    ?>
    <a href="/admin/orders.php?<?= $qp ?>"
       class="px-3.5 py-2 text-xs font-bold rounded-t-lg transition-all <?= $isAct ? 'bg-[#111118] border border-b-[#111118] border-dark-border text-white -mb-px z-10 relative' : 'text-gray-500 hover:text-gray-300' ?>">
      <?= $tabData['label'] ?>
      <span class="ml-1.5 px-1.5 py-0.5 rounded-full text-[10px] font-black <?= $isAct ? 'bg-gold/20 text-gold' : 'bg-dark-border/60 text-gray-500' ?>"><?= $tabData['count'] ?></span>
    </a>
    <?php endforeach; ?>
  </div>

  <!-- ORDERS TABLE -->
  <div class="glass-card rounded-3xl border border-dark-border shadow-xl overflow-hidden">
    <?php if (empty($showOrders)): ?>
    <div class="py-20 text-center text-gray-500">
      <div class="text-5xl mb-4">&#128269;</div>
      <div class="font-bold text-lg text-white">No orders found in <?= htmlspecialchars($tabs[$activeTab]['label'] ?? 'this view') ?></div>
      <div class="text-xs mt-2">Adjust your filters or switch tabs to view other records.</div>
    </div>
    <?php else: ?>
    <div class="overflow-x-auto">
      <table class="dashboard-table w-full text-left text-xs">
        <thead>
          <tr>
            <th>ORDER ID</th>
            <th>PROPERTY</th>
            <th>SERVICE</th>
            <th>CLIENT</th>
            <th>ORDER TYPE</th>
            <th>CLEARANCE</th>
            <th class="text-center">PHOTOS</th>
            <th>STATUS (DIRECT CONTROL)</th>
            <th>CREATED</th>
            <th class="text-right">AMOUNT</th>
            <th class="text-right">ACTIONS</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($showOrders as $o):
            $client = $userMap[$o['user_id'] ?? ''] ?? null;
            $status = strtolower($o['status'] ?? 'pending');
            $sInfo = $statusLabels[$status] ?? ['label' => strtoupper(str_replace('_',' ',$status)), 'cls' => 'bg-gray-500/20 text-gray-300 border-gray-500/40'];
            $isTrialOrder = !empty($o['is_trial']) || (($o['order_type'] ?? '') === 'free_trial') || (($o['service_type'] ?? '') === 'free_trial') || stripos($o['id'] ?? '', 'TRIAL-') === 0;
            $isDelivered = in_array($status, ['delivered', 'completed', 'sent_client']);
          ?>
          <tr class="hover:bg-white/[0.02]">
            <td class="font-mono font-bold text-gold whitespace-nowrap">
              <a href="/admin/order-view.php?id=<?= urlencode($o['id']) ?>" class="hover:underline">
                <?= htmlspecialchars($o['id']) ?>
              </a>
            </td>
            <td>
              <div class="font-bold text-white max-w-[160px] truncate" title="<?= htmlspecialchars($o['property_name'] ?? '') ?>">
                <?= htmlspecialchars($o['property_name'] ?? '&mdash;') ?>
              </div>
              <?php if (!empty($o['cloud_link'])): ?>
                <a href="<?= htmlspecialchars($o['cloud_link']) ?>" target="_blank" class="text-blue-400 text-[10px] hover:underline">&#128193; Raw Files</a>
              <?php endif; ?>
              <?php if (!empty($o['final_cloud_link'])): ?>
                <span class="text-gray-500 text-[10px]">•</span>
                <a href="<?= htmlspecialchars($o['final_cloud_link']) ?>" target="_blank" class="text-emerald-400 text-[10px] hover:underline">📦 Delivered Files</a>
              <?php endif; ?>
            </td>
            <td class="text-gray-300 max-w-[110px] truncate"><?= htmlspecialchars($o['service_type'] ?? $o['editing_type'] ?? '&mdash;') ?></td>
            <td>
              <?php if ($client): ?>
                <div class="font-bold text-white"><?= htmlspecialchars($client['name'] ?? '') ?></div>
                <div class="text-gray-500 text-[10px] font-mono"><?= htmlspecialchars($client['email'] ?? '') ?></div>
              <?php elseif (!empty($o['client_name'])): ?>
                <div class="font-bold text-white"><?= htmlspecialchars($o['client_name']) ?></div>
                <div class="text-gray-500 text-[10px] font-mono"><?= htmlspecialchars($o['client_email'] ?? '') ?></div>
              <?php else: ?>
                <span class="text-gray-500 italic">&mdash;</span>
              <?php endif; ?>
            </td>
            <td class="whitespace-nowrap">
              <div class="space-y-1.5">
                <?php if ($isTrialOrder): ?>
                  <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-500/15 text-amber-300 border border-amber-500/40 shadow-sm">
                    🎁 FREE TRIAL
                  </span>
                <?php else: ?>
                  <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-500/15 text-blue-300 border border-blue-500/40 shadow-sm">
                    ⚡ LIVE ORDER
                  </span>
                <?php endif; ?>

                <?php if ($canEditOrder): ?>
                <form method="POST" action="/admin/orders.php" class="order-type-form block">
                  <?= csrfField() ?>
                  <input type="hidden" name="admin_order_action" value="switch_order_type">
                  <input type="hidden" name="order_id" value="<?= htmlspecialchars($o['id']) ?>">
                  <div class="flex items-center gap-1.5">
                    <select name="order_type" 
                            data-original="<?= $isTrialOrder ? 'free_trial' : 'live_order' ?>"
                            data-order-id="<?= htmlspecialchars($o['id'], ENT_QUOTES) ?>"
                            data-order-title="<?= htmlspecialchars($o['property_name'] ?? $o['id'], ENT_QUOTES) ?>"
                            class="order-type-select bg-[#141622] text-[10px] font-bold py-1 px-2 rounded-lg border border-dark-border focus:border-gold outline-none cursor-pointer transition-all <?= $isTrialOrder ? 'text-amber-400' : 'text-blue-400' ?>">
                      <option value="free_trial" <?= $isTrialOrder ? 'selected' : '' ?>>🎁 Free Trial ($0.00)</option>
                      <option value="live_order" <?= !$isTrialOrder ? 'selected' : '' ?>>⚡ Live Order (Paid)</option>
                    </select>
                    <button type="button" 
                            class="btn-apply-type py-1 px-2 text-[10px] font-black rounded-lg bg-gold text-dark hover:bg-gold/90 transition-all shadow-glow hidden whitespace-nowrap flex-shrink-0"
                            title="Apply Classification Change">
                      ✓ Apply
                    </button>
                  </div>
                </form>
                <?php endif; ?>
              </div>
            </td>
            <td class="whitespace-nowrap">
              <?php 
                $finStatus = function_exists('getOrderFinancialStatus') ? getOrderFinancialStatus($o) : null; 
                echo $finStatus['payment_badge'] ?? '<span class="text-gray-500 text-[11px]">—</span>';
              ?>
            </td>
            <td class="text-center font-mono font-bold text-white">
              <?= (int)($o['raw_images_count'] ?? $o['photo_count'] ?? 0) ?>
              <?php if (!empty($o['delivered_images_count']) && $o['delivered_images_count'] > 0): ?>
                <span class="text-emerald-400"> &rarr; <?= (int)$o['delivered_images_count'] ?></span>
              <?php endif; ?>
            </td>
            <td>
              <div class="space-y-1.5 min-w-[155px]">
                <span class="inline-block px-2 py-0.5 rounded-full text-[10px] font-bold border <?= $sInfo['cls'] ?>">
                  <?= $sInfo['label'] ?>
                </span>

                <!-- Full Admin Status Authority Dropdown with Apply Button -->
                <?php if ($canEditOrder): ?>
                <form method="POST" action="/admin/orders.php" class="order-status-form block">
                  <?= csrfField() ?>
                  <input type="hidden" name="admin_order_action" value="update_order_status">
                  <input type="hidden" name="order_id" value="<?= htmlspecialchars($o['id']) ?>">
                  <div class="flex items-center gap-1.5">
                    <select name="new_status" 
                            data-original="<?= $status ?>"
                            data-order-id="<?= htmlspecialchars($o['id'], ENT_QUOTES) ?>"
                            data-order-title="<?= htmlspecialchars($o['property_name'] ?? $o['id'], ENT_QUOTES) ?>"
                            class="order-status-select w-full bg-[#12131F] text-[10px] font-bold py-1 px-1.5 rounded-lg border border-dark-border hover:border-gold text-gray-300 hover:text-white outline-none cursor-pointer transition-all">
                      <option value="pending" <?= ($status === 'pending') ? 'selected' : '' ?>>⏳ Pending</option>
                      <option value="in_progress" <?= ($status === 'in_progress') ? 'selected' : '' ?>>🔄 In Progress</option>
                      <option value="assigned_editor" <?= ($status === 'assigned_editor') ? 'selected' : '' ?>>👤 Assigned Editor</option>
                      <option value="submitted_qa" <?= ($status === 'submitted_qa') ? 'selected' : '' ?>>🔍 QA Review</option>
                      <option value="revision_required" <?= ($status === 'revision_required') ? 'selected' : '' ?>>⚠️ Revision Req.</option>
                      <option value="ready_delivery" <?= ($status === 'ready_delivery') ? 'selected' : '' ?>>📦 Ready Delivery</option>
                      <option value="delivered" <?= in_array($status, ['delivered', 'sent_client']) ? 'selected' : '' ?>>✅ Delivered</option>
                      <option value="completed" <?= ($status === 'completed') ? 'selected' : '' ?>>🏆 Completed</option>
                      <option value="cancelled" <?= ($status === 'cancelled') ? 'selected' : '' ?>>🚫 Cancelled</option>
                    </select>
                    <button type="button" 
                            class="btn-apply-status py-1 px-2 text-[10px] font-black rounded-lg bg-gold text-dark hover:bg-gold/90 transition-all shadow-glow hidden whitespace-nowrap flex-shrink-0"
                            title="Apply Status Change">
                      ✓ Apply
                    </button>
                  </div>
                </form>
                <?php endif; ?>
              </div>
            </td>
            <td class="font-mono text-gray-400 whitespace-nowrap"><?= date('M j, Y', strtotime($o['created_at'] ?? 'now')) ?></td>
            <td class="text-right font-mono font-bold">
              <?php if ($isTrialOrder): ?>
                <span class="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">$0.00 FREE</span>
              <?php else: ?>
                <?php $amt = (float)($o['billed_amount'] ?? 0); ?>
                <?= $amt > 0 ? '<span class="text-gold">$'.number_format($amt, 2).'</span>' : '<span class="text-gray-600">&mdash;</span>' ?>
              <?php endif; ?>
            </td>
            <td class="text-right whitespace-nowrap">
              <div class="flex items-center justify-end gap-1.5">
                
                <!-- Quick Amend Submit Button (If amendment requested) -->
                <?php if ($status === 'amendment_requested' || !empty($o['annotations'])): ?>
                <a href="/admin/order-view.php?id=<?= urlencode($o['id']) ?>"
                  class="py-1 px-2.5 text-[11px] font-black rounded-lg bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black shadow-sm shadow-amber-500/30 transition-all inline-flex items-center gap-1 animate-pulse"
                  title="View &amp; Submit Amendment Resolution">
                  <span>✏️</span> <span>Submit Amend</span>
                </a>
                <?php endif; ?>

                <!-- 1-Click Complete Button (If not delivered yet) -->
                <?php if ($canEditOrder && !$isDelivered): ?>
                <button type="button"
                  data-order-id="<?= htmlspecialchars($o['id'], ENT_QUOTES) ?>"
                  data-order-title="<?= htmlspecialchars($o['property_name'] ?? $o['id'], ENT_QUOTES) ?>"
                  data-raw-count="<?= (int)($o['raw_images_count'] ?? $o['photo_count'] ?? 1) ?>"
                  data-final-link="<?= htmlspecialchars($o['final_cloud_link'] ?? ($o['cloud_link'] ?? ''), ENT_QUOTES) ?>"
                  class="btn-open-complete py-1 px-2.5 text-[11px] font-bold rounded-lg bg-emerald-600/25 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/40 transition-all inline-flex items-center gap-1 shadow-sm"
                  title="Mark as Completed &amp; Delivered">
                  <span>✓</span> <span>Complete</span>
                </button>
                <?php endif; ?>

                <!-- Quick Edit Button -->
                <?php if ($canEditOrder): ?>
                <button type="button"
                  data-order='<?= htmlspecialchars(json_encode([
                    'id'                     => $o['id'],
                    'property_name'          => $o['property_name'] ?? '',
                    'service_type'           => $o['service_type'] ?? $o['editing_type'] ?? '',
                    'status'                 => $status,
                    'order_type'             => $isTrialOrder ? 'free_trial' : 'live_order',
                    'raw_images_count'       => (int)($o['raw_images_count'] ?? $o['photo_count'] ?? 0),
                    'delivered_images_count' => (int)($o['delivered_images_count'] ?? $o['raw_images_count'] ?? 0),
                    'billed_amount'          => (float)($o['billed_amount'] ?? 0),
                    'cloud_link'             => $o['cloud_link'] ?? '',
                    'final_cloud_link'       => $o['final_cloud_link'] ?? '',
                    'instructions'           => $o['instructions'] ?? $o['notes'] ?? ''
                  ]), ENT_QUOTES) ?>'
                  class="btn-open-quick-edit py-1 px-2 text-[11px] font-bold rounded-lg bg-white/5 hover:bg-white/10 text-gold border border-gold/30 hover:border-gold transition-all"
                  title="Edit Order Details">
                  ✏️ Edit
                </button>
                <?php endif; ?>

                <a href="/admin/order-view.php?id=<?= urlencode($o['id']) ?>" class="btn-ghost py-1 px-2.5 text-[11px] font-bold border border-dark-border text-gray-300 hover:text-white rounded-lg">
                  View
                </a>

                <?php if ($canDelete): ?>
                <button type="button"
                  data-order-id="<?= htmlspecialchars($o['id'], ENT_QUOTES) ?>"
                  data-order-title="<?= htmlspecialchars($o['property_name'] ?? $o['id'], ENT_QUOTES) ?>"
                  class="btn-open-delete py-1 px-2.5 text-[11px] font-bold rounded-lg bg-red-600/20 hover:bg-red-600/40 text-red-400 border border-red-500/30 transition-all"
                  title="Permanently Delete Order">
                  Delete
                </button>
                <?php endif; ?>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="px-6 py-3 border-t border-dark-border text-xs text-gray-500 flex items-center justify-between">
      <span>Showing <strong class="text-white"><?= count($showOrders) ?></strong> of <strong class="text-white"><?= $totalOrders ?></strong> orders</span>
      <?php $totalBilled = array_sum(array_column($showOrders,'billed_amount')); ?>
      <span class="font-mono">Total Billed: <strong class="text-gold">$<?= number_format($totalBilled, 2) ?></strong></span>
    </div>
    <?php endif; ?>
  </div>

</main>

<!-- ── MODAL 1: QUICK COMPLETE CONFIRMATION ──────────────────────────── -->
<div id="quickCompleteModal" class="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 sm:p-8 max-w-md w-full border border-emerald-500/50 shadow-2xl space-y-4">
    <div class="flex items-center gap-3.5 border-b border-dark-border pb-4">
      <div class="w-12 h-12 rounded-2xl bg-emerald-600/20 border border-emerald-500 flex items-center justify-center text-2xl">✓</div>
      <div>
        <h3 class="text-lg font-black text-white">Complete &amp; Deliver Order</h3>
        <p class="text-xs text-gray-400">Moves this order to Delivered Records and updates client status.</p>
      </div>
    </div>

    <form method="POST" action="/admin/orders.php" class="space-y-4">
      <?= csrfField() ?>
      <input type="hidden" name="admin_order_action" value="quick_complete_order">
      <input type="hidden" name="order_id" id="completeOrderId">

      <div class="p-3.5 rounded-2xl bg-emerald-950/30 border border-emerald-800/40 text-xs text-emerald-200">
        Order: <strong id="completeOrderTitle" class="text-white"></strong> &nbsp;(<span id="completeOrderIdLabel" class="font-mono text-gold font-bold"></span>)
      </div>

      <div>
        <label class="form-label text-xs">Delivered Images Count <span class="text-red-400">*</span></label>
        <input type="number" name="delivered_images_count" id="completeDeliveredCount" min="1" required class="form-input text-sm w-full mt-1">
      </div>

      <div>
        <label class="form-label text-xs">Final Download / Delivery Link (Optional)</label>
        <input type="url" name="final_cloud_link" id="completeFinalLink" class="form-input text-sm w-full mt-1" placeholder="https://dropbox.com/... or Google Drive link">
      </div>

      <div class="flex items-center justify-end gap-3 pt-2">
        <button type="button" id="completeCancelBtn" class="btn-ghost py-2.5 px-4 text-xs font-bold">Cancel</button>
        <button type="submit" class="py-2.5 px-6 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-glow transition-all inline-flex items-center gap-1.5">
          <span>✓</span> <span>Apply &amp; Mark Delivered</span>
        </button>
      </div>
    </form>
  </div>
</div>

<!-- ── MODAL 2: FULL QUICK EDIT ORDER DETAILS ────────────────────────── -->
<div id="quickEditModal" class="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 hidden overflow-y-auto">
  <div class="glass-card rounded-3xl p-6 sm:p-8 max-w-xl w-full border border-gold/40 shadow-2xl space-y-4 my-8">
    <div class="flex items-center justify-between border-b border-dark-border pb-4">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-2xl bg-gold/10 border border-gold/40 text-gold flex items-center justify-center text-xl font-bold">✏️</div>
        <div>
          <h3 class="text-lg font-black text-white">Edit Order Details</h3>
          <p class="text-xs text-gray-400">Admin override for order <span id="editOrderIdBadge" class="font-mono text-gold font-bold"></span></p>
        </div>
      </div>
      <button type="button" id="editModalCloseBtn" class="text-gray-400 hover:text-white text-lg font-bold">✕</button>
    </div>

    <form method="POST" action="/admin/orders.php" class="space-y-4">
      <?= csrfField() ?>
      <input type="hidden" name="admin_order_action" value="quick_edit_order">
      <input type="hidden" name="order_id" id="editOrderId">

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label class="form-label text-xs">Property Title / Address <span class="text-red-400">*</span></label>
          <input type="text" name="property_name" id="editPropertyName" required class="form-input text-xs w-full mt-1">
        </div>

        <div>
          <label class="form-label text-xs">Service Type <span class="text-red-400">*</span></label>
          <input type="text" name="service_type" id="editServiceType" required class="form-input text-xs w-full mt-1">
        </div>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label class="form-label text-xs">Order Status <span class="text-red-400">*</span></label>
          <select name="status" id="editStatus" class="form-select text-xs w-full mt-1 bg-dark">
            <option value="pending">Pending</option>
            <option value="in_progress">In Progress</option>
            <option value="assigned_editor">Assigned Editor</option>
            <option value="submitted_qa">QA Review</option>
            <option value="revision_required">Revision Required</option>
            <option value="ready_delivery">Ready Delivery</option>
            <option value="delivered">Delivered</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>

        <div>
          <label class="form-label text-xs">Order Classification <span class="text-red-400">*</span></label>
          <select name="order_type" id="editOrderType" class="form-select text-xs w-full mt-1 bg-dark">
            <option value="free_trial">🎁 Free Trial ($0.00)</option>
            <option value="live_order">⚡ Live Order (Paid)</option>
          </select>
        </div>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
          <label class="form-label text-xs">Raw Images Count</label>
          <input type="number" name="raw_images_count" id="editRawCount" min="0" class="form-input text-xs w-full mt-1">
        </div>

        <div>
          <label class="form-label text-xs">Delivered Images Count</label>
          <input type="number" name="delivered_images_count" id="editDeliveredCount" min="0" class="form-input text-xs w-full mt-1">
        </div>

        <div>
          <label class="form-label text-xs">Billed Amount ($ USD)</label>
          <input type="number" step="0.01" name="billed_amount" id="editBilledAmount" min="0" class="form-input text-xs w-full mt-1 font-mono text-gold">
        </div>
      </div>

      <div>
        <label class="form-label text-xs">Client Raw Images Link (Dropbox / Drive)</label>
        <input type="url" name="cloud_link" id="editCloudLink" class="form-input text-xs w-full mt-1" placeholder="https://...">
      </div>

      <div>
        <label class="form-label text-xs">Final Delivered Files Link</label>
        <input type="url" name="final_cloud_link" id="editFinalLink" class="form-input text-xs w-full mt-1" placeholder="https://...">
      </div>

      <div>
        <label class="form-label text-xs">Client Instructions &amp; Admin Notes</label>
        <textarea name="instructions" id="editInstructions" rows="2" class="form-textarea text-xs w-full mt-1"></textarea>
      </div>

      <div class="flex items-center justify-end gap-3 pt-3 border-t border-dark-border">
        <button type="button" id="editCancelBtn" class="btn-ghost py-2.5 px-4 text-xs font-bold">Cancel</button>
        <button type="submit" class="btn-gold py-2.5 px-6 text-xs font-black shadow-glow inline-flex items-center gap-1.5">
          <span>✓</span> <span>Apply &amp; Save Changes</span>
        </button>
      </div>
    </form>
  </div>
</div>

<!-- ── MODAL 2B: CUSTOM WEBSITE POPUP - APPLY ORDER CHANGES ────────── -->
<div id="applyOrderChangeModal" class="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 sm:p-7 max-w-md w-full border border-gold/50 shadow-2xl space-y-5 animate-in fade-in duration-150">
    <div class="flex items-center gap-3.5 border-b border-dark-border pb-3.5">
      <div id="applyModalIconBox" class="w-12 h-12 rounded-2xl bg-gold/15 border border-gold/40 flex items-center justify-center text-2xl font-black flex-shrink-0 text-gold shadow-glow">
        ⚙️
      </div>
      <div class="flex-1 min-w-0">
        <h3 id="applyModalHeading" class="text-base font-black text-white">
          Apply Order Changes
        </h3>
        <p class="text-xs text-gray-400 font-mono truncate" id="applyModalSubheading">Order #ORD-5006</p>
      </div>
      <button type="button" id="applyModalCloseBtn" class="text-gray-400 hover:text-white text-xl font-bold p-1">&times;</button>
    </div>

    <!-- Details Box -->
    <div class="p-4 rounded-2xl bg-[#141422] border border-[#232338] space-y-3">
      <div class="text-xs text-gray-300">
        Order: <strong id="applyModalOrderTitle" class="text-white"></strong>
      </div>
      
      <div class="grid grid-cols-2 gap-2 pt-2 border-t border-dark-border text-xs">
        <div>
          <span class="text-gray-500 block text-[10px] uppercase font-bold">Current Setting</span>
          <span id="applyModalOldVal" class="font-bold text-gray-300"></span>
        </div>
        <div>
          <span class="text-gold block text-[10px] uppercase font-bold">New Selection</span>
          <span id="applyModalNewVal" class="font-bold text-gold"></span>
        </div>
      </div>
    </div>

    <div class="text-xs text-gray-400 leading-relaxed" id="applyModalExplanation">
      Click <strong>Apply Changes</strong> to update this order in production queues and databases.
    </div>

    <!-- Action Buttons -->
    <div class="flex items-center justify-end gap-3 pt-3 border-t border-dark-border">
      <button type="button" id="applyModalCancelBtn" class="btn-ghost py-2.5 px-4 text-xs font-bold text-gray-400 hover:text-white">
        Cancel
      </button>
      <button type="button" id="applyModalConfirmBtn" class="btn-gold py-2.5 px-6 text-xs font-black shadow-glow inline-flex items-center gap-2">
        <span>✓</span> <span>Apply Changes</span>
      </button>
    </div>
  </div>
</div>

<!-- ── MODAL 3: DELETE CONFIRMATION ──────────────────────────────────── -->
<div id="deleteOrderModal" class="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 max-w-md w-full border border-red-500/50 shadow-2xl space-y-4">
    <div class="flex items-center gap-3">
      <div class="w-10 h-10 rounded-2xl bg-red-600/20 border border-red-500 flex items-center justify-center text-xl">&#128465;</div>
      <div>
        <h3 class="text-base font-black text-white">Delete Order?</h3>
        <p class="text-xs text-gray-400">Permanently removed from all production queues and databases. Cannot be undone.</p>
      </div>
    </div>
    <div class="p-3.5 rounded-2xl bg-red-950/30 border border-red-800/50 text-xs text-red-200">
      Order: <strong id="delOrderTitle" class="text-white"></strong> &nbsp;(<span id="delOrderId" class="font-mono text-gold font-bold"></span>)
    </div>
    <div class="flex items-center justify-end gap-3 pt-2">
      <button type="button" id="delOrderCancelBtn" class="btn-ghost py-2.5 px-4 text-xs font-bold">Cancel</button>
      <a id="delOrderConfirmBtn" href="#" class="py-2.5 px-5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs shadow-lg transition-all inline-flex items-center gap-1.5">
        &#128465; Yes, Delete
      </a>
    </div>
  </div>
</div>

<!-- ── MODAL 4: PURGE ALL MODAL ──────────────────────────────────────── -->
<?php if ($isOwner): ?>
<div id="purgeAllModal" class="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 hidden">
  <div class="glass-card rounded-3xl p-6 sm:p-8 max-w-md w-full border border-red-500/50 shadow-2xl space-y-5">
    <div class="flex items-center gap-3.5 border-b border-dark-border pb-4">
      <div class="w-12 h-12 rounded-2xl bg-red-600/20 border border-red-500 flex items-center justify-center text-2xl">&#x1F9F9;</div>
      <div>
        <h3 class="text-lg font-black text-red-400">Purge ALL Orders</h3>
        <p class="text-xs text-gray-400">Deletes every order from the system &mdash; cannot be undone.</p>
      </div>
    </div>
    <div class="p-4 rounded-2xl bg-red-950/40 border border-red-800/60 text-xs text-red-200 space-y-1.5">
      <p><strong class="text-white"><?= $totalOrders ?></strong> orders will be permanently deleted.</p>
      <p class="text-gray-400">Supervisor SaaS pipeline will also be fully cleared.</p>
    </div>
    <form method="POST" action="/admin/orders.php" class="flex items-center justify-end gap-3 pt-2">
      <?= csrfField() ?>
      <input type="hidden" name="admin_order_action" value="purge_all_orders">
      <button type="button" id="purgeAllCancelBtn" class="btn-ghost py-2.5 px-4 text-xs font-bold">Cancel</button>
      <button type="submit" class="py-2.5 px-6 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs shadow-lg transition-all">
        &#x1F9F9; Yes, Purge All
      </button>
    </form>
  </div>
</div>
<?php endif; ?>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
document.addEventListener('DOMContentLoaded', function() {
  
  // Custom Apply Changes Modal State
  let pendingSubmitForm = null;
  let pendingRevertSelect = null;
  let pendingOriginalValue = '';

  const applyModal = document.getElementById('applyOrderChangeModal');
  const applyClose = document.getElementById('applyModalCloseBtn');
  const applyCancel = document.getElementById('applyModalCancelBtn');
  const applyConfirm = document.getElementById('applyModalConfirmBtn');

  function openApplyModal(opts) {
    if (!applyModal) return;
    pendingSubmitForm = opts.form;
    pendingRevertSelect = opts.select;
    pendingOriginalValue = opts.originalValue;

    document.getElementById('applyModalHeading').textContent = opts.heading || 'Apply Order Changes';
    document.getElementById('applyModalSubheading').textContent = 'Order #' + (opts.orderId || '');
    document.getElementById('applyModalOrderTitle').textContent = opts.orderTitle || ('Order #' + (opts.orderId || ''));
    document.getElementById('applyModalOldVal').textContent = opts.oldLabel || '';
    document.getElementById('applyModalNewVal').textContent = opts.newLabel || '';
    document.getElementById('applyModalExplanation').innerHTML = opts.explanation || 'Click <strong>Apply Changes</strong> to update this order.';
    
    applyModal.classList.remove('hidden');
  }

  function closeApplyModal(revert = false) {
    if (!applyModal) return;
    applyModal.classList.add('hidden');
    if (revert && pendingRevertSelect) {
      pendingRevertSelect.value = pendingOriginalValue;
      const form = pendingRevertSelect.closest('form');
      if (form) {
        const applyBtn = form.querySelector('.btn-apply-status, .btn-apply-type');
        if (applyBtn) applyBtn.classList.add('hidden');
      }
    }
    pendingSubmitForm = null;
    pendingRevertSelect = null;
  }

  if (applyClose) applyClose.addEventListener('click', () => closeApplyModal(true));
  if (applyCancel) applyCancel.addEventListener('click', () => closeApplyModal(true));
  if (applyConfirm) {
    applyConfirm.addEventListener('click', () => {
      if (pendingSubmitForm) {
        applyConfirm.disabled = true;
        applyConfirm.innerHTML = '<span>⏳</span> <span>Applying...</span>';
        pendingSubmitForm.submit();
      }
    });
  }

  // 1. Status Dropdown & Inline Apply Button
  document.querySelectorAll('.order-status-select').forEach(function(sel) {
    const form = sel.closest('form');
    const applyBtn = form ? form.querySelector('.btn-apply-status') : null;
    const originalVal = sel.getAttribute('data-original');
    const oid = sel.getAttribute('data-order-id');
    const title = sel.getAttribute('data-order-title');

    function triggerStatusApply() {
      const oldOption = sel.querySelector('option[value="' + originalVal + '"]');
      const oldText = oldOption ? oldOption.text : originalVal;
      const newText = sel.options[sel.selectedIndex].text;

      openApplyModal({
        form: form,
        select: sel,
        originalValue: originalVal,
        heading: 'Apply Status Update',
        orderId: oid,
        orderTitle: title,
        oldLabel: oldText,
        newLabel: newText,
        explanation: 'Update status of order <strong>#' + oid + '</strong> to <strong>' + newText + '</strong>. This will instantly synchronize production queues.'
      });
    }

    sel.addEventListener('change', function() {
      if (this.value !== originalVal) {
        if (applyBtn) applyBtn.classList.remove('hidden');
        triggerStatusApply();
      } else {
        if (applyBtn) applyBtn.classList.add('hidden');
      }
    });

    if (applyBtn) {
      applyBtn.addEventListener('click', function(e) {
        e.preventDefault();
        triggerStatusApply();
      });
    }
  });

  // 2. Order Type Quick-Switch & Inline Apply Button
  document.querySelectorAll('.order-type-select').forEach(function(sel) {
    const form = sel.closest('form');
    const applyBtn = form ? form.querySelector('.btn-apply-type') : null;
    const originalVal = sel.getAttribute('data-original');
    const oid = sel.getAttribute('data-order-id');
    const title = sel.getAttribute('data-order-title');

    function triggerTypeApply() {
      const isTrial = (sel.value === 'free_trial');
      const oldText = (originalVal === 'free_trial') ? '🎁 Free Trial ($0.00)' : '⚡ Live Order (Paid)';
      const newText = isTrial ? '🎁 Free Trial ($0.00)' : '⚡ Live Order (Paid)';

      openApplyModal({
        form: form,
        select: sel,
        originalValue: originalVal,
        heading: 'Apply Classification Change',
        orderId: oid,
        orderTitle: title,
        oldLabel: oldText,
        newLabel: newText,
        explanation: isTrial 
          ? 'Switch order <strong>#' + oid + '</strong> to <strong>Free Trial ($0.00)</strong>. All billing charges will be set to zero.' 
          : 'Switch order <strong>#' + oid + '</strong> to <strong>Live Order (Paid)</strong>.'
      });
    }

    sel.addEventListener('change', function() {
      if (this.value !== originalVal) {
        if (applyBtn) applyBtn.classList.remove('hidden');
        triggerTypeApply();
      } else {
        if (applyBtn) applyBtn.classList.add('hidden');
      }
    });

    if (applyBtn) {
      applyBtn.addEventListener('click', function(e) {
        e.preventDefault();
        triggerTypeApply();
      });
    }
  });

  // 3. Quick Complete Modal
  document.querySelectorAll('.btn-open-complete').forEach(function(btn) {
    btn.addEventListener('click', function() {
      const oid = this.getAttribute('data-order-id');
      const title = this.getAttribute('data-order-title');
      const rawCount = this.getAttribute('data-raw-count') || 1;
      const finalLink = this.getAttribute('data-final-link') || '';

      document.getElementById('completeOrderId').value = oid;
      document.getElementById('completeOrderIdLabel').textContent = '#' + oid;
      document.getElementById('completeOrderTitle').textContent = title;
      document.getElementById('completeDeliveredCount').value = rawCount;
      document.getElementById('completeFinalLink').value = finalLink;

      document.getElementById('quickCompleteModal').classList.remove('hidden');
    });
  });

  const completeCancel = document.getElementById('completeCancelBtn');
  if (completeCancel) {
    completeCancel.addEventListener('click', () => {
      document.getElementById('quickCompleteModal').classList.add('hidden');
    });
  }

  // 4. Quick Edit Modal
  document.querySelectorAll('.btn-open-quick-edit').forEach(function(btn) {
    btn.addEventListener('click', function() {
      const raw = this.getAttribute('data-order');
      if (!raw) return;
      try {
        const o = JSON.parse(raw);
        document.getElementById('editOrderId').value = o.id;
        document.getElementById('editOrderIdBadge').textContent = '#' + o.id;
        document.getElementById('editPropertyName').value = o.property_name || '';
        document.getElementById('editServiceType').value = o.service_type || '';
        document.getElementById('editStatus').value = o.status || 'pending';
        document.getElementById('editOrderType').value = o.order_type || 'live_order';
        document.getElementById('editRawCount').value = o.raw_images_count || 0;
        document.getElementById('editDeliveredCount').value = o.delivered_images_count || 0;
        document.getElementById('editBilledAmount').value = o.billed_amount || 0;
        document.getElementById('editCloudLink').value = o.cloud_link || '';
        document.getElementById('editFinalLink').value = o.final_cloud_link || '';
        document.getElementById('editInstructions').value = o.instructions || '';

        document.getElementById('quickEditModal').classList.remove('hidden');
      } catch(err) {
        console.error('Error parsing order data', err);
      }
    });
  });

  const editCancel = document.getElementById('editCancelBtn');
  if (editCancel) editCancel.addEventListener('click', () => document.getElementById('quickEditModal').classList.add('hidden'));
  const editClose = document.getElementById('editModalCloseBtn');
  if (editClose) editClose.addEventListener('click', () => document.getElementById('quickEditModal').classList.add('hidden'));

  // 5. Delete Order Modal
  document.querySelectorAll('.btn-open-delete').forEach(function(btn) {
    btn.addEventListener('click', function() {
      const oid = this.getAttribute('data-order-id');
      const title = this.getAttribute('data-order-title');
      document.getElementById('delOrderId').textContent = '#' + oid;
      document.getElementById('delOrderTitle').textContent = title;
      document.getElementById('delOrderConfirmBtn').href = '/admin/orders.php?delete_order_id=' + encodeURIComponent(oid);
      document.getElementById('deleteOrderModal').classList.remove('hidden');
    });
  });

  const delCancel = document.getElementById('delOrderCancelBtn');
  if (delCancel) delCancel.addEventListener('click', () => document.getElementById('deleteOrderModal').classList.add('hidden'));

  // 6. Purge All Modal
  const openPurgeBtn = document.getElementById('btnOpenPurgeAll');
  if (openPurgeBtn) {
    openPurgeBtn.addEventListener('click', () => {
      const pam = document.getElementById('purgeAllModal');
      if (pam) pam.classList.remove('hidden');
    });
  }

  const purgeCancel = document.getElementById('purgeAllCancelBtn');
  if (purgeCancel) {
    purgeCancel.addEventListener('click', () => {
      const pam = document.getElementById('purgeAllModal');
      if (pam) pam.classList.add('hidden');
    });
  }
});
</script>
</body>
</html>
