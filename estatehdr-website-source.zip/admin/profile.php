<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/saas-db.php';
require_once __DIR__ . '/../includes/countries.php';
require_once __DIR__ . '/../includes/audit.php';
requireAdmin();

$currentAdmin = currentAdminUser();
$adminRoles   = getAdminRoles();
$userId       = $currentAdmin['id'] ?? '';
$employees    = getSaaSEmployees();
$allCountries = getCountries();

// Find employee profile
$myProfile = null;
foreach ($employees as $e) {
    if ($e['user_id'] === $userId) { $myProfile = $e; break; }
}

// Check admin_users.json for custom photo and extra fields
$adminUsersFile = DATA_PATH . '/admin_users.json';
$currentPhoto = $currentAdmin['photo'] ?? '';
$currentCountry = $currentAdmin['country'] ?? 'United Kingdom';
$currentDialCode = $currentAdmin['dial_code'] ?? '+44';

if (file_exists($adminUsersFile)) {
    $admins = json_decode(file_get_contents($adminUsersFile), true) ?: [];
    foreach ($admins as $a) {
        if (($a['id'] ?? '') === $userId || strtolower($a['email'] ?? '') === strtolower($currentAdmin['email'] ?? '')) {
            if (!empty($a['photo'])) {
                $currentPhoto = $a['photo'];
                $_SESSION['admin_user']['photo'] = $a['photo'];
            }
            if (!empty($a['country'])) $currentCountry = $a['country'];
            if (!empty($a['dial_code'])) $currentDialCode = $a['dial_code'];
            break;
        }
    }
}

// Fallback to team images if match found
if (empty($currentPhoto)) {
    if (strtolower($currentAdmin['email'] ?? '') === 'admin@estatehdr.com') {
        $currentPhoto = '/assets/images/team/co-founder-1.jpg';
    } elseif (strtolower($currentAdmin['email'] ?? '') === 'manager@estatehdr.com') {
        $currentPhoto = '/assets/images/team/project-manager.jpg';
    } elseif (strtolower($currentAdmin['email'] ?? '') === 'supervisor@estatehdr.com') {
        $currentPhoto = '/assets/images/team/supervisor.jpg';
    }
}

// Determine back URL based on role
$isOwner      = in_array('owner', $adminRoles) || in_array('super_admin', $adminRoles);
$isManager    = in_array('manager', $adminRoles) || in_array('production_manager', $adminRoles) || $isOwner;
$isSupervisor = in_array('supervisor', $adminRoles) && !$isManager;
$isTeamLead   = in_array('team_lead', $adminRoles) && !$isSupervisor && !$isManager;
$isPhotoEditor= (in_array('photo_editor', $adminRoles) || in_array('editor', $adminRoles)) && !$isManager && !$isOwner;
$isHR         = in_array('hr', $adminRoles) && !$isManager && !$isOwner;

if ($isPhotoEditor) $backUrl = '/admin/editor-dashboard.php';
elseif ($isTeamLead) $backUrl = '/admin/teamlead-dashboard.php';
elseif ($isSupervisor) $backUrl = '/admin/supervisor-dashboard.php';
elseif ($isHR) $backUrl = '/admin/hr-dashboard.php';
elseif ($isManager) $backUrl = '/admin/manager-dashboard.php';
else $backUrl = '/admin/';

// Handle profile update POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_profile'])) {
    verifyCsrf();
    $firstName   = trim($_POST['first_name'] ?? '');
    $lastName    = trim($_POST['last_name'] ?? '');
    $phone       = trim($_POST['phone'] ?? '');
    $country     = trim($_POST['country'] ?? 'United Kingdom');
    $dialCode    = trim($_POST['dial_code'] ?? '+44');
    $currentPass = trim($_POST['current_password'] ?? '');
    $newPass     = trim($_POST['new_password'] ?? '');
    $confPass    = trim($_POST['confirm_password'] ?? '');

    $adminUsers = json_decode(file_get_contents($adminUsersFile), true) ?? [];
    $updated = false;

    foreach ($adminUsers as &$u) {
        if ($u['id'] === $userId || strtolower($u['email'] ?? '') === strtolower($currentAdmin['email'] ?? '')) {
            $u['name'] = trim("$firstName $lastName");
            if (!empty($phone)) $u['phone'] = $phone;
            $u['country'] = $country;
            $u['dial_code'] = $dialCode;

            // Password update validation
            if (!empty($newPass)) {
                $storedHash = $u['password_hash'] ?? '';
                if (!empty($storedHash) && !empty($currentPass) && !password_verify($currentPass, $storedHash)) {
                    setFlash('error', 'Current password entered is incorrect. Profile details saved, but password was not changed.');
                    header("Location: /admin/profile.php");
                    exit;
                }
                if (strlen($newPass) < 8) {
                    setFlash('error', 'New password must be at least 8 characters long.');
                    header("Location: /admin/profile.php");
                    exit;
                }
                if ($newPass !== $confPass) {
                    setFlash('error', 'New passwords do not match. Profile details saved, password unchanged.');
                    header("Location: /admin/profile.php");
                    exit;
                }
                $u['password_hash'] = password_hash($newPass, PASSWORD_BCRYPT);
                logAuditEvent('profile.password_change', $userId, ['actor' => $u['email']]);
            }

            $updated = true;
            $_SESSION['admin_user']['name'] = $u['name'];
            $_SESSION['admin_user']['country'] = $country;
            break;
        }
    }

    if ($updated) {
        file_put_contents($adminUsersFile, json_encode($adminUsers, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES), LOCK_EX);
        logAuditEvent('profile.update', $userId, ['name' => "$firstName $lastName", 'country' => $country]);
        setFlash('success', 'Staff profile updated successfully!');
    }
    header("Location: /admin/profile.php");
    exit;
}

// Parse name into parts
$fullName  = $currentAdmin['name'] ?? '';
$nameParts = explode(' ', $fullName, 2);
$firstName = $nameParts[0] ?? '';
$lastName  = $nameParts[1] ?? '';
$roleLabel = $currentAdmin['role'] ?? implode(', ', $adminRoles);
$initials  = strtoupper(mb_substr($firstName, 0, 1) . mb_substr($lastName, 0, 1)) ?: strtoupper(mb_substr($fullName, 0, 2));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Profile — Estate HDR</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
tailwind.config = {
  theme: {
    extend: {
      colors: {
        gold: { DEFAULT: '#C9A84C', dark: '#9A7A2E' },
        dark: { DEFAULT: '#0A0A0F', card: '#111118', border: '#1E1E2E' }
      }
    }
  }
};
</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>

<style nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
.avatar-container { position: relative; cursor: pointer; }
.avatar-overlay { opacity: 0; transition: all 0.2s ease-in-out; }
.avatar-container:hover .avatar-overlay { opacity: 1; }
#avatarCanvas { touch-action: none; user-select: none; }
</style>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[950px] w-full mx-auto px-6 sm:px-10 py-8 space-y-6">
  <?= renderFlash() ?>

  <!-- Top Breadcrumb / Action Bar -->
  <div class="flex items-center justify-between">
    <a href="<?= htmlspecialchars($backUrl) ?>" class="btn-ghost py-2 px-4 text-xs font-bold inline-flex items-center gap-2 border border-dark-border hover:border-gold rounded-xl">
      <span>←</span> <span>Back to Dashboard</span>
    </a>

    <div class="flex items-center gap-2">
      <button type="button" id="topBtnViewPhoto" class="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 hover:text-white border border-dark-border text-xs font-bold inline-flex items-center gap-1.5 transition-all">
        <span>👁️</span> <span>View Photo</span>
      </button>
      <button type="button" id="topBtnUploadPhoto" class="px-3.5 py-1.5 rounded-xl bg-gold hover:bg-amber-400 text-dark font-black text-xs inline-flex items-center gap-1.5 shadow-glow transition-all">
        <span>📷</span> <span>Upload Photo</span>
      </button>
    </div>
  </div>

  <!-- Profile Card -->
  <div class="glass-card rounded-3xl p-8 border border-dark-border shadow-2xl">
    <div class="flex flex-col sm:flex-row items-center sm:items-start gap-6 border-b border-dark-border pb-8">
      
      <!-- Interactive Avatar Container -->
      <div id="avatarContainerClick" class="avatar-container relative group" title="Click to View or Crop Photo">
        <div id="avatarDisplayWrapper" class="w-24 h-24 sm:w-28 sm:h-28 rounded-full overflow-hidden border-2 border-gold shadow-glow bg-[#141422] flex items-center justify-center">
          <?php if (!empty($currentPhoto)): ?>
            <img id="mainProfileAvatar" src="<?= htmlspecialchars($currentPhoto) ?>" alt="<?= htmlspecialchars($fullName) ?>" class="w-full h-full object-cover">
          <?php else: ?>
            <div id="initialsAvatar" class="w-full h-full bg-gradient-to-br from-gold to-amber-700 flex items-center justify-center text-dark text-3xl font-black select-none">
              <?= $initials ?>
            </div>
          <?php endif; ?>
        </div>

        <div class="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-emerald-500 border-2 border-dark flex items-center justify-center" title="Active Staff">
          <span class="w-2 h-2 rounded-full bg-white block"></span>
        </div>

        <div class="avatar-overlay absolute inset-0 rounded-full bg-dark/75 backdrop-blur-[2px] flex flex-col items-center justify-center text-white border-2 border-gold">
          <span class="text-lg">📷</span>
          <span class="text-[10px] font-black uppercase tracking-wider text-gold mt-0.5">Edit Photo</span>
        </div>
      </div>

      <!-- User Details & Quick Buttons -->
      <div class="text-center sm:text-left flex-1 space-y-2">
        <h1 class="text-2xl sm:text-3xl font-black text-white"><?= htmlspecialchars($fullName) ?></h1>
        
        <div class="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-0.5">
          <span class="px-3 py-1 rounded-xl bg-gold/20 text-gold border border-gold/40 text-xs font-black uppercase">
            <?= htmlspecialchars($roleLabel) ?>
          </span>
          <span class="px-3 py-1 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-xs font-bold flex items-center gap-1.5">
            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span> Active Staff
          </span>
          <span class="px-2.5 py-1 rounded-xl bg-white/5 text-gray-400 text-xs font-mono border border-white/10">
            ID: <?= htmlspecialchars($userId) ?>
          </span>
        </div>

        <p class="text-gray-400 text-xs font-mono"><?= htmlspecialchars($currentAdmin['email'] ?? '') ?></p>

        <!-- Quick Photo Action Links -->
        <div class="pt-2 flex flex-wrap items-center justify-center sm:justify-start gap-3">
          <button type="button" id="linkViewPhoto" class="text-xs text-gold hover:underline font-bold inline-flex items-center gap-1">
            <span>👁️</span> <span>View Full Photo</span>
          </button>
          <span class="text-gray-600">•</span>
          <button type="button" id="linkUploadPhoto" class="text-xs text-emerald-400 hover:underline font-bold inline-flex items-center gap-1">
            <span>✂️</span> <span>Crop &amp; Upload New Photo</span>
          </button>
        </div>
      </div>

    </div>

    <!-- Hidden File Input for Avatar Selection -->
    <input type="file" id="profilePhotoInput" accept="image/jpeg,image/png,image/webp,image/jpg" class="hidden">

    <!-- Profile Edit Form -->
    <form method="POST" class="mt-8 space-y-6">
      <?= csrfField() ?>
      <input type="hidden" name="save_profile" value="1">

      <div>
        <div class="text-xs font-black text-gold uppercase tracking-wider mb-3 flex items-center gap-2">
          <span>✦</span> <span>Personal &amp; Contact Information</span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label class="form-label text-xs">First Name <span class="text-red-400">*</span></label>
            <input type="text" name="first_name" value="<?= htmlspecialchars($firstName) ?>" required class="form-input w-full mt-1 text-sm py-2.5" placeholder="Enter first name">
          </div>
          <div>
            <label class="form-label text-xs">Last Name</label>
            <input type="text" name="last_name" value="<?= htmlspecialchars($lastName) ?>" class="form-input w-full mt-1 text-sm py-2.5" placeholder="Enter last name">
          </div>
        </div>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="form-label text-xs">Official Email Address (Locked)</label>
          <input type="email" value="<?= htmlspecialchars($currentAdmin['email'] ?? '') ?>" disabled class="form-input w-full mt-1 text-sm py-2.5 opacity-60 cursor-not-allowed bg-black/20" title="Contact System Admin to change corporate email">
          <p class="text-[11px] text-gray-500 mt-1">Authorized corporate login identity.</p>
        </div>

        <div>
          <label class="form-label text-xs">Country / Region <span class="text-red-400">*</span></label>
          <select name="country" id="countrySelector" class="form-input w-full mt-1 text-sm py-2.5 bg-dark">
            <?php foreach ($allCountries as $c): ?>
              <option value="<?= htmlspecialchars($c['name']) ?>" data-dial="<?= htmlspecialchars($c['dial_code']) ?>" data-code="<?= htmlspecialchars($c['code']) ?>" <?= (strcasecmp($currentCountry, $c['name']) === 0 || strcasecmp($currentCountry, $c['code']) === 0) ? 'selected' : '' ?>>
                <?= $c['emoji'] ?> <?= htmlspecialchars($c['name']) ?> (<?= htmlspecialchars($c['dial_code']) ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="form-label text-xs">Direct Phone / WhatsApp</label>
          <div class="flex items-center gap-2 mt-1">
            <input type="text" name="dial_code" id="dialCodeInput" value="<?= htmlspecialchars($currentDialCode) ?>" readonly class="w-20 text-center form-input text-sm py-2.5 bg-black/40 font-mono text-gold cursor-default" title="Country Dial Code">
            <input type="tel" name="phone" id="phoneInput" value="<?= htmlspecialchars($myProfile['phone'] ?? ($currentAdmin['phone'] ?? '')) ?>" class="form-input flex-1 text-sm py-2.5" placeholder="770 606 8176">
          </div>
          <p class="text-[11px] text-gray-500 mt-1">Used for internal urgent dispatch notices.</p>
        </div>

        <div>
          <label class="form-label text-xs">Assigned System Role (Immutable)</label>
          <input type="text" value="<?= htmlspecialchars($roleLabel) ?>" disabled class="form-input w-full mt-1 text-sm py-2.5 opacity-60 cursor-not-allowed bg-black/20 font-bold text-gold" title="Roles are managed by Owner/HR">
          <p class="text-[11px] text-gray-500 mt-1">Role elevation requires CEO/Owner authorization.</p>
        </div>
      </div>

      <!-- Password Security Section -->
      <div class="border-t border-dark-border pt-6">
        <div class="text-xs font-black text-gold uppercase tracking-wider mb-3 flex items-center justify-between">
          <div class="flex items-center gap-2">
            <span>✦</span> <span>Security &amp; Password</span>
          </div>
          <span class="text-[11px] text-gray-400 font-normal lowercase">leave blank to keep current</span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label class="form-label text-xs">Current Password</label>
            <input type="password" name="current_password" class="form-input w-full mt-1 text-sm py-2.5" placeholder="Current password" autocomplete="current-password">
          </div>
          <div>
            <label class="form-label text-xs">New Password (min 8 chars)</label>
            <input type="password" name="new_password" id="newPasswordInput" class="form-input w-full mt-1 text-sm py-2.5" placeholder="Enter new password" autocomplete="new-password">
            <!-- Strength meter -->
            <div class="w-full bg-white/10 h-1 rounded-full mt-2 overflow-hidden">
              <div id="passwordStrengthBar" class="h-full w-0 transition-all duration-300 bg-red-500"></div>
            </div>
            <div id="passwordStrengthLabel" class="text-[10px] text-gray-400 mt-1">Min 8 characters</div>
          </div>
          <div>
            <label class="form-label text-xs">Confirm New Password</label>
            <input type="password" name="confirm_password" id="confirmPasswordInput" class="form-input w-full mt-1 text-sm py-2.5" placeholder="Repeat new password">
            <div id="passwordMatchLabel" class="text-[10px] text-transparent mt-2">Passwords match</div>
          </div>
        </div>
      </div>

      <?php if ($myProfile): ?>
      <div class="border-t border-dark-border pt-6">
        <div class="text-xs font-black text-gold uppercase tracking-wider mb-3 flex items-center gap-2">
          <span>✦</span> <span>Production &amp; QA Stats (Read-Only)</span>
        </div>
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div class="p-4 rounded-2xl bg-dark/90 border border-dark-border text-center">
            <div class="text-xl font-black text-emerald-400 font-mono"><?= $myProfile['quality_score'] ?? '100' ?>%</div>
            <div class="text-[11px] text-gray-400 mt-1 font-bold">Quality Score</div>
          </div>
          <div class="p-4 rounded-2xl bg-dark/90 border border-dark-border text-center">
            <div class="text-xl font-black text-blue-400 font-mono"><?= $myProfile['productivity_score'] ?? '98' ?>%</div>
            <div class="text-[11px] text-gray-400 mt-1 font-bold">Productivity</div>
          </div>
          <div class="p-4 rounded-2xl bg-dark/90 border border-dark-border text-center">
            <div class="text-xl font-black text-gold"><?= htmlspecialchars($myProfile['shift'] ?? 'Day Shift') ?></div>
            <div class="text-[11px] text-gray-400 mt-1 font-bold">Shift Schedule</div>
          </div>
          <div class="p-4 rounded-2xl bg-dark/90 border border-dark-border text-center">
            <div class="text-xl font-black text-white"><?= htmlspecialchars($myProfile['department'] ?? 'Executive') ?></div>
            <div class="text-[11px] text-gray-400 mt-1 font-bold">Department</div>
          </div>
        </div>
      </div>
      <?php endif; ?>

      <div class="flex justify-end pt-4 border-t border-dark-border">
        <button type="submit" class="btn-gold py-3 px-8 text-sm font-black shadow-glow inline-flex items-center gap-2">
          <span>💾</span> <span>Save Profile Changes</span>
        </button>
      </div>
    </form>
  </div>
</main>

<!-- ── MODAL 1: AVATAR OPTIONS ──────────────────────────────────────── -->
<div id="avatarOptionsModal" class="hidden fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
  <div class="glass-card rounded-3xl p-6 max-w-sm w-full border border-gold/30 shadow-2xl space-y-5 text-center">
    <div class="w-12 h-12 rounded-2xl bg-gold/10 border border-gold/30 text-gold flex items-center justify-center text-2xl mx-auto">
      👤
    </div>
    <div>
      <h3 class="text-lg font-black text-white">Profile Photo Options</h3>
      <p class="text-xs text-gray-400 mt-1">View your current high-res photo or upload and crop a new one.</p>
    </div>

    <div class="space-y-3 pt-2">
      <button type="button" id="modalOptViewPhoto" class="w-full py-3 px-4 rounded-xl bg-white/5 hover:bg-white/10 text-white font-bold text-xs border border-dark-border hover:border-gold transition-all flex items-center justify-center gap-2">
        <span>👁️</span> <span>View Current Photo</span>
      </button>

      <button type="button" id="modalOptUploadPhoto" class="w-full py-3 px-4 rounded-xl bg-gold hover:bg-amber-400 text-dark font-black text-xs shadow-glow transition-all flex items-center justify-center gap-2">
        <span>📷</span> <span>Upload &amp; Crop New Photo</span>
      </button>

      <button type="button" id="modalOptCancel" class="w-full py-2.5 text-xs text-gray-500 hover:text-gray-300 font-bold transition-all">
        Cancel
      </button>
    </div>
  </div>
</div>

<!-- ── MODAL 2: HIGH-RES PHOTO LIGHTBOX ─────────────────────────────── -->
<div id="photoViewerModal" class="hidden fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
  <div id="photoViewerCard" class="relative max-w-lg w-full p-4 flex flex-col items-center space-y-4">
    <button type="button" id="closePhotoViewerBtn" class="absolute -top-3 -right-3 w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 text-white font-bold text-lg flex items-center justify-center transition-all border border-white/20">
      ✕
    </button>

    <div class="w-64 h-64 sm:w-80 sm:h-80 rounded-3xl overflow-hidden border-4 border-gold shadow-2xl bg-[#111118]">
      <img id="viewerImage" src="<?= htmlspecialchars(!empty($currentPhoto) ? $currentPhoto : '/assets/images/logo.png') ?>" alt="Profile Photo" class="w-full h-full object-cover">
    </div>

    <div class="text-center">
      <div class="text-base font-black text-white"><?= htmlspecialchars($fullName) ?></div>
      <div class="text-xs text-gold font-bold uppercase mt-0.5"><?= htmlspecialchars($roleLabel) ?></div>
    </div>

    <div class="flex items-center gap-3 pt-2">
      <button type="button" id="viewerChangePhotoBtn" class="px-5 py-2.5 rounded-xl bg-gold hover:bg-amber-400 text-dark font-black text-xs shadow-glow inline-flex items-center gap-2">
        <span>📷</span> <span>Change Photo</span>
      </button>
      <button type="button" id="viewerCloseBtn" class="px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs">
        Close
      </button>
    </div>
  </div>
</div>

<!-- ── MODAL 3: VANILLA JS CROPPER STUDIO (ZERO EXTERNAL CDN) ────────── -->
<div id="cropperModal" class="hidden fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
  <div class="glass-card rounded-3xl p-6 sm:p-8 max-w-xl w-full border border-gold/40 shadow-[0_25px_70px_rgba(0,0,0,0.9)] space-y-6">
    
    <!-- Modal Header -->
    <div class="flex items-center justify-between border-b border-dark-border pb-4">
      <div class="flex items-center gap-2.5">
        <div class="w-8 h-8 rounded-xl bg-gold/10 border border-gold/30 text-gold flex items-center justify-center text-base font-black">
          ✂️
        </div>
        <div>
          <h3 class="text-lg font-black text-white">Crop &amp; Align Profile Avatar</h3>
          <p class="text-[11px] text-gray-400">Drag to reposition, use controls to Zoom and Rotate (1:1 standard).</p>
        </div>
      </div>
      <button type="button" id="btnCropperCloseX" class="w-8 h-8 rounded-full bg-white/5 hover:bg-white/15 text-gray-400 hover:text-white flex items-center justify-center text-sm font-bold">
        ✕
      </button>
    </div>

    <!-- Canvas Preview Box with Circular Overlay Guide -->
    <div class="relative w-full h-80 bg-[#09090F] rounded-2xl overflow-hidden border border-[#232338] flex items-center justify-center select-none">
      <canvas id="avatarCanvas" width="320" height="320" class="rounded-full shadow-[0_0_40px_rgba(201,168,76,0.3)] border-2 border-gold cursor-grab"></canvas>
      <div class="absolute inset-0 pointer-events-none rounded-2xl border border-white/5"></div>
    </div>

    <!-- Cropper Controls: Zoom In, Zoom Out, Rotate 90, Reset -->
    <div class="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-[#0D0D16] border border-dark-border">
      <div class="flex items-center gap-2">
        <button type="button" id="btnZoomIn" class="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-white text-xs font-bold border border-white/10 active:scale-95 transition-all" title="Zoom In">
          🔍 +
        </button>
        <button type="button" id="btnZoomOut" class="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-white text-xs font-bold border border-white/10 active:scale-95 transition-all" title="Zoom Out">
          🔍 -
        </button>
        <button type="button" id="btnRotate" class="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-white text-xs font-bold border border-white/10 active:scale-95 transition-all" title="Rotate 90 degrees">
          🔄 Rotate 90°
        </button>
        <button type="button" id="btnReset" class="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/15 text-white text-xs font-bold border border-white/10 active:scale-95 transition-all" title="Reset View">
          Reset
        </button>
      </div>

      <div class="text-[11px] text-gray-400 font-mono">Drag to Pan • Mousewheel to Zoom</div>
    </div>

    <!-- Footer Action Buttons -->
    <div class="flex items-center justify-end gap-3 pt-2">
      <button type="button" id="btnCropperCancel" class="px-5 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-gray-300 font-bold text-xs">
        Cancel
      </button>
      <button type="button" id="btnSaveAvatar" class="px-6 py-2.5 rounded-xl bg-gold hover:bg-amber-400 text-dark font-black text-xs shadow-glow inline-flex items-center gap-2 active:scale-95 transition-all">
        <span>💾</span> <span id="saveBtnText">Save Cropped Photo</span>
      </button>
    </div>

  </div>
</div>

<!-- ── JAVASCRIPT LOGIC (CSP NONCED, NO INLINE HANDLERS) ─────────────── -->
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
document.addEventListener('DOMContentLoaded', function() {
  const csrfTokenVal = '<?= csrfToken() ?>';

  // Elements
  const avatarInput = document.getElementById('profilePhotoInput');
  const avatarCanvas = document.getElementById('avatarCanvas');
  const ctx = avatarCanvas.getContext('2d');
  
  const cropperModal = document.getElementById('cropperModal');
  const avatarOptionsModal = document.getElementById('avatarOptionsModal');
  const photoViewerModal = document.getElementById('photoViewerModal');
  
  const countrySelector = document.getElementById('countrySelector');
  const dialCodeInput = document.getElementById('dialCodeInput');
  
  const newPassInput = document.getElementById('newPasswordInput');
  const confPassInput = document.getElementById('confirmPasswordInput');
  const strengthBar = document.getElementById('passwordStrengthBar');
  const strengthLabel = document.getElementById('passwordStrengthLabel');
  const matchLabel = document.getElementById('passwordMatchLabel');

  // Cropper State Machine
  let img = new Image();
  let state = { scale: 1, rotate: 0, offsetX: 0, offsetY: 0 };
  let dragging = false;
  let lastX = 0, lastY = 0;

  function draw() {
    ctx.clearRect(0, 0, avatarCanvas.width, avatarCanvas.height);
    ctx.save();
    ctx.translate(avatarCanvas.width / 2 + state.offsetX, avatarCanvas.height / 2 + state.offsetY);
    ctx.rotate((state.rotate * Math.PI) / 180);
    ctx.scale(state.scale, state.scale);
    if (img.src) {
      ctx.drawImage(img, -img.width / 2, -img.height / 2);
    }
    ctx.restore();
  }

  function resetState() {
    if (!img.src || !img.width) return;
    const scaleToFit = Math.max(avatarCanvas.width / img.width, avatarCanvas.height / img.height);
    state = { scale: scaleToFit, rotate: 0, offsetX: 0, offsetY: 0 };
    draw();
  }

  // Country & Dial Code Sync
  if (countrySelector && dialCodeInput) {
    countrySelector.addEventListener('change', function() {
      const opt = countrySelector.options[countrySelector.selectedIndex];
      if (opt && opt.dataset.dial) {
        dialCodeInput.value = opt.dataset.dial;
      }
    });
  }

  // Password Strength Checker
  if (newPassInput) {
    newPassInput.addEventListener('input', function() {
      const val = newPassInput.value;
      let score = 0;
      if (val.length >= 8) score++;
      if (/[A-Z]/.test(val)) score++;
      if (/[0-9]/.test(val)) score++;
      if (/[^A-Za-z0-9]/.test(val)) score++;

      if (val.length === 0) {
        strengthBar.style.width = '0%';
        strengthBar.className = 'h-full transition-all duration-300 bg-red-500';
        strengthLabel.innerText = 'Min 8 characters';
      } else if (score <= 1) {
        strengthBar.style.width = '25%';
        strengthBar.className = 'h-full transition-all duration-300 bg-red-500';
        strengthLabel.innerText = 'Weak password';
      } else if (score === 2) {
        strengthBar.style.width = '50%';
        strengthBar.className = 'h-full transition-all duration-300 bg-amber-500';
        strengthLabel.innerText = 'Fair password';
      } else if (score === 3) {
        strengthBar.style.width = '75%';
        strengthBar.className = 'h-full transition-all duration-300 bg-blue-500';
        strengthLabel.innerText = 'Good password';
      } else {
        strengthBar.style.width = '100%';
        strengthBar.className = 'h-full transition-all duration-300 bg-emerald-500';
        strengthLabel.innerText = 'Strong password ✓';
      }
      checkMatch();
    });
  }

  if (confPassInput) {
    confPassInput.addEventListener('input', checkMatch);
  }

  function checkMatch() {
    if (!confPassInput || !newPassInput) return;
    if (!confPassInput.value) {
      matchLabel.className = 'text-[10px] text-transparent mt-2';
      return;
    }
    if (confPassInput.value === newPassInput.value) {
      matchLabel.innerText = 'Passwords match ✓';
      matchLabel.className = 'text-[10px] text-emerald-400 mt-2 font-bold';
    } else {
      matchLabel.innerText = 'Passwords do not match ✗';
      matchLabel.className = 'text-[10px] text-red-400 mt-2 font-bold';
    }
  }

  // Avatar file input handler
  avatarInput.addEventListener('change', function(e) {
    const file = e.target.files && e.target.files[0];
    if (!file) return;

    if (!file.type.match(/^image\/(jpeg|png|webp|jpg)$/i)) {
      alert('Please select a valid image file (JPG, PNG, or WebP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = function(ev) {
      img = new Image();
      img.onload = function() {
        resetState();
        cropperModal.classList.remove('hidden');
      };
      img.src = ev.target.result;
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  });

  // Modal Triggers
  const avatarClickTrigger = document.getElementById('avatarContainerClick');
  if (avatarClickTrigger) {
    avatarClickTrigger.addEventListener('click', () => avatarOptionsModal.classList.remove('hidden'));
  }
  
  const modalOptViewPhoto = document.getElementById('modalOptViewPhoto');
  if (modalOptViewPhoto) {
    modalOptViewPhoto.addEventListener('click', () => {
      avatarOptionsModal.classList.add('hidden');
      photoViewerModal.classList.remove('hidden');
    });
  }

  const modalOptUploadPhoto = document.getElementById('modalOptUploadPhoto');
  if (modalOptUploadPhoto) {
    modalOptUploadPhoto.addEventListener('click', () => {
      avatarOptionsModal.classList.add('hidden');
      avatarInput.click();
    });
  }

  const modalOptCancel = document.getElementById('modalOptCancel');
  if (modalOptCancel) {
    modalOptCancel.addEventListener('click', () => avatarOptionsModal.classList.add('hidden'));
  }

  const topBtnView = document.getElementById('topBtnViewPhoto');
  if (topBtnView) {
    topBtnView.addEventListener('click', () => photoViewerModal.classList.remove('hidden'));
  }

  const linkView = document.getElementById('linkViewPhoto');
  if (linkView) {
    linkView.addEventListener('click', () => photoViewerModal.classList.remove('hidden'));
  }

  const topBtnUpload = document.getElementById('topBtnUploadPhoto');
  if (topBtnUpload) {
    topBtnUpload.addEventListener('click', () => avatarInput.click());
  }

  const linkUpload = document.getElementById('linkUploadPhoto');
  if (linkUpload) {
    linkUpload.addEventListener('click', () => avatarInput.click());
  }

  const viewerChange = document.getElementById('viewerChangePhotoBtn');
  if (viewerChange) {
    viewerChange.addEventListener('click', () => {
      photoViewerModal.classList.add('hidden');
      avatarInput.click();
    });
  }

  const closeViewerBtn = document.getElementById('closePhotoViewerBtn');
  if (closeViewerBtn) {
    closeViewerBtn.addEventListener('click', () => photoViewerModal.classList.add('hidden'));
  }

  const viewerCloseBtn = document.getElementById('viewerCloseBtn');
  if (viewerCloseBtn) {
    viewerCloseBtn.addEventListener('click', () => photoViewerModal.classList.add('hidden'));
  }

  if (photoViewerModal) {
    photoViewerModal.addEventListener('click', (e) => {
      if (e.target === photoViewerModal) photoViewerModal.classList.add('hidden');
    });
  }

  // Cropper Controls
  document.getElementById('btnZoomIn').addEventListener('click', () => {
    state.scale *= 1.15;
    draw();
  });

  document.getElementById('btnZoomOut').addEventListener('click', () => {
    state.scale = Math.max(0.1, state.scale / 1.15);
    draw();
  });

  document.getElementById('btnRotate').addEventListener('click', () => {
    state.rotate = (state.rotate + 90) % 360;
    draw();
  });

  document.getElementById('btnReset').addEventListener('click', resetState);

  function closeCropper() {
    cropperModal.classList.add('hidden');
  }

  document.getElementById('btnCropperCloseX').addEventListener('click', closeCropper);
  document.getElementById('btnCropperCancel').addEventListener('click', closeCropper);

  // Mouse drag & Wheel zoom
  avatarCanvas.addEventListener('mousedown', (e) => {
    dragging = true;
    avatarCanvas.classList.remove('cursor-grab');
    avatarCanvas.classList.add('cursor-grabbing');
    lastX = e.clientX;
    lastY = e.clientY;
  });

  window.addEventListener('mouseup', () => {
    dragging = false;
    avatarCanvas.classList.remove('cursor-grabbing');
    avatarCanvas.classList.add('cursor-grab');
  });

  window.addEventListener('mousemove', (e) => {
    if (!dragging) return;
    state.offsetX += e.clientX - lastX;
    state.offsetY += e.clientY - lastY;
    lastX = e.clientX;
    lastY = e.clientY;
    draw();
  });

  avatarCanvas.addEventListener('wheel', (e) => {
    e.preventDefault();
    if (e.deltaY < 0) state.scale *= 1.08;
    else state.scale = Math.max(0.1, state.scale / 1.08);
    draw();
  }, { passive: false });

  // Touch Support for Mobile / Tablets
  avatarCanvas.addEventListener('touchstart', (e) => {
    if (e.touches.length === 1) {
      dragging = true;
      lastX = e.touches[0].clientX;
      lastY = e.touches[0].clientY;
    }
  }, { passive: true });

  window.addEventListener('touchend', () => { dragging = false; });

  window.addEventListener('touchmove', (e) => {
    if (!dragging || e.touches.length !== 1) return;
    state.offsetX += e.touches[0].clientX - lastX;
    state.offsetY += e.touches[0].clientY - lastY;
    lastX = e.touches[0].clientX;
    lastY = e.touches[0].clientY;
    draw();
  }, { passive: true });

  // Save Cropped Avatar
  document.getElementById('btnSaveAvatar').addEventListener('click', function() {
    if (!img.src) {
      alert('Please choose a photo first.');
      return;
    }

    const btn = document.getElementById('btnSaveAvatar');
    const btnText = document.getElementById('saveBtnText');
    btn.disabled = true;
    btnText.innerText = 'Uploading & Saving...';

    // High quality PNG from canvas
    const dataUrl = avatarCanvas.toDataURL('image/png');

    fetch('/admin/profile-save-avatar.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        avatar_data: dataUrl,
        csrf_token: csrfTokenVal
      })
    })
    .then(r => r.json())
    .then(res => {
      btn.disabled = false;
      btnText.innerText = 'Save Cropped Photo';
      if (res.success && res.photo_url) {
        // Update main page avatar
        const avatarWrapper = document.getElementById('avatarDisplayWrapper');
        avatarWrapper.innerHTML = `<img id="mainProfileAvatar" src="${res.photo_url}?t=${Date.now()}" alt="Profile Photo" class="w-full h-full object-cover">`;

        // Update viewer image
        const viewerImg = document.getElementById('viewerImage');
        if (viewerImg) viewerImg.src = res.photo_url;

        closeCropper();
        alert('✓ Profile picture successfully updated and saved!');
      } else {
        alert('Error: ' + (res.error || 'Failed to save avatar photo.'));
      }
    })
    .catch(err => {
      btn.disabled = false;
      btnText.innerText = 'Save Cropped Photo';
      alert('Network error while saving avatar. Please try again.');
    });
  });

});
</script>

</body>
</html>
