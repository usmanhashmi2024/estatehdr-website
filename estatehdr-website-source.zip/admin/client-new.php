<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireSuperAdmin();

$name     = trim($_GET['name'] ?? '');
$email    = trim($_GET['email'] ?? '');
$phone    = trim($_GET['phone'] ?? '');
$createdClient = null;
$tempPass = '';
$errors   = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $name     = trim($_POST['name'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $phone    = trim($_POST['phone'] ?? '');
    $tempPass = trim($_POST['password'] ?? '');
    $notes    = trim($_POST['notes'] ?? '');

    if (strlen($name) < 2)                 $errors[] = 'Name is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    if (strlen($tempPass) < 6)             $errors[] = 'Temporary password must be at least 6 characters.';

    if (getUserByEmail($email)) {
        $errors[] = 'A client with this email already exists.';
    }

    if (empty($errors)) {
        $createdClient = createUser($name, $email, $tempPass, $phone, $notes, 'admin');
        setFlash('success', 'Client account created successfully! You can share their login credentials below.');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manual Client Onboarding — Estate HDR Admin</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-[#0A0A0F] text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="portal-main max-w-2xl">
  <?= renderFlash() ?>

  <div class="mb-8">
    <div class="section-tag mb-2">Admin Onboarding Flow</div>
    <h1 class="text-2xl sm:text-3xl font-bold text-white">Manual Client Onboarding</h1>
    <p class="text-gray-400 text-sm mt-1">Create user accounts for VIP clients, agencies, or photographer referrals who prefer not to sign up themselves.</p>
  </div>

  <?php if ($createdClient): ?>
  <!-- Shareable Credentials Card -->
  <div class="glass-card rounded-2xl p-8 border border-green-500/40 shadow-2xl mb-8">
    <div class="text-4xl mb-3">🎉</div>
    <h3 class="text-xl font-bold text-green-400 mb-2">Account Created for <?= htmlspecialchars($createdClient['name']) ?>!</h3>
    <p class="text-gray-300 text-xs mb-6">Copy and send this ready-made welcome message to the client via Email or WhatsApp:</p>

    <div class="bg-dark p-4 rounded-xl border border-dark-border text-xs font-mono text-gray-300 space-y-1 select-all mb-6">
      <div>Hi <?= htmlspecialchars($createdClient['name']) ?>,</div>
      <br>
      <div>Your Estate HDR Client Portal account is ready:</div>
      <div>Portal URL: <?= BASE_URL ?>/login.php</div>
      <div>Email: <?= htmlspecialchars($createdClient['email']) ?></div>
      <div>Password: <?= htmlspecialchars($tempPass) ?></div>
      <br>
      <div>You can view live order progress, QA before/after files, and submit new jobs directly through your dashboard.</div>
    </div>

    <div class="flex gap-4">
      <a href="/admin/order-new.php?client_id=<?= urlencode($createdClient['id']) ?>" class="btn-gold flex-1 py-3 text-xs font-bold text-center shadow-glow">
        + Create First Proxy Order for this Client &rarr;
      </a>
      <a href="/admin/clients.php" class="btn-ghost py-3 px-6 text-xs text-center">View Clients Directory</a>
    </div>
  </div>
  <?php else: ?>

  <?php if (!empty($errors)): ?>
  <div class="flash-msg flash-error mb-6">
    <?php foreach ($errors as $e): ?><div>&bull; <?= htmlspecialchars($e) ?></div><?php endforeach; ?>
  </div>
  <?php endif; ?>

  <div class="glass-card rounded-2xl p-8 border border-dark-border shadow-2xl">
    <form method="POST" class="space-y-6">
      <?= csrfField() ?>

      <div>
        <label class="form-label">Client Full Name / Agency <span class="text-red-400">*</span></label>
        <input type="text" name="name" class="form-input text-sm" placeholder="e.g. John Doe (Premier Realty)" value="<?= htmlspecialchars($name) ?>" required>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="form-label">Email Address <span class="text-red-400">*</span></label>
          <input type="email" name="email" class="form-input text-sm" placeholder="john@realty.com" value="<?= htmlspecialchars($email) ?>" required>
        </div>

        <div>
          <label class="form-label">WhatsApp / Phone Number</label>
          <input type="text" name="phone" class="form-input text-sm" placeholder="+44 770 606 8176" value="<?= htmlspecialchars($phone) ?>">
        </div>
      </div>

      <div>
        <label class="form-label">Temporary Password <span class="text-red-400">*</span></label>
        <input type="text" name="password" class="form-input text-sm font-mono" value="Welcome@2025!" required>
        <p class="text-gray-500 text-[11px] mt-1">Client can change this anytime after logging in.</p>
      </div>

      <div>
        <label class="form-label">Internal CRM Notes</label>
        <textarea name="notes" rows="3" class="form-input resize-y text-sm" placeholder="e.g. VIP Realtor with 50+ listings per month, prefers flambient tone..."></textarea>
      </div>

      <div class="flex gap-4 pt-2">
        <button type="submit" class="btn-gold flex-1 py-3 text-sm font-bold shadow-glow">
          Onboard Client &amp; Generate Credentials
        </button>
        <a href="/admin/clients.php" class="btn-ghost flex-none py-3 px-6 text-sm">Cancel</a>
      </div>
    </form>
  </div>
  <?php endif; ?>
</main>
</body>
</html>
