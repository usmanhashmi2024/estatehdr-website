<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/saas-db.php';
require_once __DIR__ . '/../includes/mail.php';
requireAdmin();

$currentAdmin = currentAdminUser();
$adminRoles   = getAdminRoles();
$isOwner      = in_array('owner', $adminRoles) || in_array('super_admin', $adminRoles);
$isHR         = in_array('hr', $adminRoles) || $isOwner;

if (!$isHR) {
    setFlash('error', 'Access Denied: Restricted to Human Resources Department.');
    header("Location: /admin/");
    exit;
}

$employees = getSaaSEmployees();
$contracts = getHRContracts();

// ── 1. POST ACTIONS: CREATE & SEND CONTRACT / ENROLL CANDIDATE / DELETE ───────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $action = trim($_POST['action'] ?? '');

    // Action: Create and optionally Email Offer / NDA to Outsider Candidate
    if ($action === 'create_and_send_contract') {
        $candidateName  = trim($_POST['candidate_name'] ?? '');
        $candidateEmail = strtolower(trim($_POST['candidate_email'] ?? ''));
        $candidatePhone = trim($_POST['candidate_phone'] ?? '');
        $candidateCnic  = trim($_POST['candidate_id_number'] ?? '');
        $role           = trim($_POST['role'] ?? 'Photo Editor');
        $dept           = trim($_POST['department'] ?? 'Production');
        $shift          = trim($_POST['shift'] ?? 'US Client Shift (08:00 PM - 05:00 AM PKT)');
        $joiningDate    = trim($_POST['joining_date'] ?? date('F j, Y', strtotime('+7 days')));
        $probation      = trim($_POST['probation_period'] ?? '3 Months');
        $compType       = trim($_POST['compensation_type'] ?? 'Monthly Salary');
        $currency       = trim($_POST['currency'] ?? 'USD ($)');
        $totalSalary    = (float)($_POST['total_salary'] ?? 750.0);
        $salaryNotes    = trim($_POST['salary_notes'] ?? 'Disbursed via automated monthly direct transfer upon SLA performance completion.');
        $docType        = trim($_POST['doc_type'] ?? 'offer_and_nda'); // 'offer_letter' | 'nda' | 'offer_and_nda'
        $sendEmailNow   = isset($_POST['send_email_now']);

        if (empty($candidateName) || empty($candidateEmail)) {
            setFlash('error', 'Candidate Full Name and Email Address are mandatory.');
            header("Location: /admin/hr-documents.php?doc=" . urlencode($docType) . "&mode=outsider");
            exit;
        }

        $contractId = 'EH-HR-' . date('Ym') . '-' . strtoupper(substr(md5(uniqid('', true)), 0, 6));
        $token      = bin2hex(random_bytes(24));

        // Get role duties & clauses
        $ndaData = function_exists('getRoleSpecificNDAClauses') ? getRoleSpecificNDAClauses($role) : [];
        $roleDuties = $ndaData['duties'] ?? 'Carry out professional duties in line with Estate HDR SOPs.';
        $roleClauses = $ndaData['clauses'] ?? [];

        $contractData = [
            'id'                  => $contractId,
            'token'               => $token,
            'doc_type'            => $docType,
            'candidate_name'      => $candidateName,
            'candidate_email'     => $candidateEmail,
            'candidate_phone'     => $candidatePhone,
            'candidate_id_number' => $candidateCnic,
            'role'                => $role,
            'department'          => $dept,
            'shift'               => $shift,
            'joining_date'        => $joiningDate,
            'probation_period'    => $probation,
            'compensation_type'   => $compType,
            'currency'            => $currency,
            'total_salary'        => $totalSalary,
            'salary_notes'        => $salaryNotes,
            'role_duties'         => $roleDuties,
            'custom_clauses'      => $roleClauses,
            'status'              => 'pending',
            'created_at'          => date('c'),
            'created_by'          => $currentAdmin['name'] ?? 'HR Officer',
            'signed_at'           => null,
            'signer_name'         => '',
            'signer_cnic'         => '',
            'signature_data'      => '',
            'signer_ip'           => '',
            'signed_file'         => ''
        ];

        // Save into contracts index and create standalone record file
        saveHRSignedDocument($contractData);

        $signUrl = BASE_URL . '/hr-sign.php?token=' . urlencode($token);

        if ($sendEmailNow) {
            $sent = sendHROfferNdaEmail($contractData);
            if ($sent) {
                setFlash('success', "Offer Letter & NDA successfully generated and emailed to {$candidateEmail}! Signing link: {$signUrl}");
            } else {
                setFlash('warning', "Contract generated! Email delivery failed (check SMTP), but candidate can sign at: {$signUrl}");
            }
        } else {
            setFlash('success', "Contract {$contractId} created! Copy signing link to send to candidate: {$signUrl}");
        }

        header("Location: /admin/hr-documents.php?doc=contracts&view_id=" . urlencode($contractId));
        exit;
    }

    // Action: 1-Click Enroll Signed Candidate into Staff Database
    if ($action === 'enroll_candidate_as_staff') {
        $contractId = trim($_POST['contract_id'] ?? '');
        $contract = getHRContractById($contractId);

        if (!$contract) {
            setFlash('error', 'Contract record not found.');
            header("Location: /admin/hr-documents.php?doc=contracts");
            exit;
        }

        $allEmps = getSaaSEmployees();
        $prefix = match($contract['role']) {
            'Team Lead'          => 'EMP-TL-',
            'Supervisor'         => 'EMP-SUP-',
            'Production Manager' => 'EMP-MGR-',
            'SEO Manager'        => 'EMP-SEO-',
            'HR Officer'         => 'EMP-HR-',
            default              => 'EMP-ED-'
        };
        $newEmpId = $prefix . sprintf('%02d', count($allEmps) + 1);

        $newEmployee = [
            'id'                => $newEmpId,
            'user_id'           => 'user_' . strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $contract['candidate_name'])) . '_' . rand(100, 999),
            'name'              => $contract['candidate_name'],
            'email'             => $contract['candidate_email'],
            'phone'             => $contract['candidate_phone'] ?: '+44 770 606 8176',
            'role'              => $contract['role'],
            'department'        => $contract['department'],
            'shift'             => $contract['shift'],
            'location_timezone' => 'Lahore, PK (GMT+5)',
            'status'            => 'Active',
            'joining_date'      => $contract['joining_date'],
            'basic_salary'      => (float)($contract['total_salary'] * 0.85),
            'rent_allowance'    => (float)($contract['total_salary'] * 0.10),
            'other_allowances'  => (float)($contract['total_salary'] * 0.05),
            'bonus'             => 0.0,
            'deductions'        => 0.0,
            'net_salary'        => (float)$contract['total_salary'],
            'currency'          => str_contains($contract['currency'], 'PKR') ? 'PKR' : (str_contains($contract['currency'], 'GBP') ? 'GBP' : 'USD'),
            'notes'             => 'Hired via Signed Contract ' . $contract['id'] . ' on ' . date('Y-m-d')
        ];

        $allEmps[] = $newEmployee;
        saveSaaSEmployees($allEmps);

        setFlash('success', "Candidate '{$contract['candidate_name']}' successfully enrolled as Staff Member [{$newEmpId}] in SaaS HR Database!");
        header("Location: /admin/hr-dashboard.php");
        exit;
    }

    // Action: Delete contract
    if ($action === 'delete_contract') {
        $delId = trim($_POST['contract_id'] ?? '');
        $allContracts = getHRContracts();
        $target = null;
        foreach ($allContracts as $c) {
            if ($c['id'] === $delId) { $target = $c; break; }
        }
        $filtered = array_values(array_filter($allContracts, fn($c) => $c['id'] !== $delId));
        saveHRContracts($filtered);

        if ($target && !empty($target['signed_file'])) {
            $filePath = DATA_PATH . $target['signed_file'];
            if (file_exists($filePath)) @unlink($filePath);
        }

        setFlash('success', "Contract record '{$delId}' permanently deleted.");
        header("Location: /admin/hr-documents.php?doc=contracts");
        exit;
    }
}

// ── 2. VIEW PARAMETERS ────────────────────────────────────────────────────────
$selectedDoc   = trim($_GET['doc'] ?? 'salary'); // 'salary' | 'bank' | 'offer' | 'nda' | 'termination' | 'contracts'
$mode          = trim($_GET['mode'] ?? 'staff');  // 'staff' | 'outsider'
$selectedEmpId = trim($_GET['emp_id'] ?? ($employees[0]['id'] ?? 'EMP-TL-01'));
$viewContractId= trim($_GET['view_id'] ?? '');

// Active contract for viewing if requested
$activeContract = null;
if (!empty($viewContractId)) {
    $activeContract = getHRContractById($viewContractId);
} elseif ($selectedDoc === 'contracts' && !empty($contracts)) {
    $activeContract = $contracts[0];
}

// Find selected employee data
$empData = null;
foreach ($employees as $e) {
    if (($e['id'] ?? '') === $selectedEmpId || ($e['user_id'] ?? '') === $selectedEmpId) {
        $empData = $e;
        break;
    }
}
if (!$empData && !empty($employees)) {
    $empData = $employees[0];
    $selectedEmpId = $empData['id'] ?? 'EMP-TL-01';
}

// Default values populated from employee record
$empName       = $empData['name'] ?? 'Johnathan Retoucher';
$empEmail      = $empData['email'] ?? 'editor@estatehdr.com';
$empPhone      = $empData['phone'] ?? '+44 770 606 8176';
$empRole       = $empData['role'] ?? 'Photo Editor';
$empShift      = $empData['shift'] ?? 'Morning (09:00 AM - 06:00 PM)';
$empDept       = $empData['department'] ?? 'Production';
$empLocation   = $empData['location_timezone'] ?? 'Lahore, PK (GMT+5)';
$empCurrency   = trim($_GET['currency'] ?? ($empData['currency'] ?? 'PKR'));

$basicSalary     = (float)($empData['basic_salary'] ?? 650.0);
$rentAllowance   = (float)($empData['rent_allowance'] ?? 80.0);
$otherAllowances = (float)($empData['other_allowances'] ?? 40.0);
$bonus           = (float)($empData['bonus'] ?? 50.0);
$deductions      = (float)($empData['deductions'] ?? 0.0);
$netSalary       = (float)($empData['net_salary'] ?? ($basicSalary + $rentAllowance + $otherAllowances + $bonus - $deductions));

// Dates & References
$docDate   = date('F j, Y');
$payPeriod = date('F Y');
$refNumber = 'REF: EH-HR-' . date('Ym') . '-' . strtoupper(substr(md5($selectedEmpId), 0, 6));

$ndaInfo = function_exists('getRoleSpecificNDAClauses') ? getRoleSpecificNDAClauses($empRole) : [
    'title' => 'General Employee Non-Disclosure & Privacy Shield',
    'duties' => 'Standard real estate retouching duties.',
    'clauses' => ['Data Protection: All client property photos are strictly confidential.']
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>HR Documents, Offer Letters &amp; Signed NDAs Hub — Estate HDR</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<style nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
.doc-sheet {
  position: relative;
  background: #ffffff;
  color: #111827;
  font-family: 'Inter', sans-serif;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
  min-height: 1000px;
}
.doc-watermark {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%) rotate(-25deg);
  opacity: 0.10;
  pointer-events: none;
  z-index: 1;
  width: 550px;
  text-align: center;
  user-select: none;
}
.doc-content { position: relative; z-index: 10; }
.script-font { font-family: 'Dancing Script', cursive; }

@media print {
  header, nav, footer, .no-print, .no-print * {
    display: none !important;
    visibility: hidden !important;
    height: 0 !important;
    padding: 0 !important;
    margin: 0 !important;
  }
  body { background: #ffffff !important; color: #111827 !important; margin: 0 !important; padding: 0 !important; font-size: 11pt !important; }
  main { display: block !important; padding: 0 !important; margin: 0 !important; width: 100% !important; }
  .grid { display: block !important; }
  .lg\:col-span-4 { display: none !important; }
  .lg\:col-span-8 { display: block !important; width: 100% !important; margin: 0 !important; padding: 0 !important; }
  .doc-sheet {
    box-shadow: none !important;
    border: none !important;
    margin: 0 auto !important;
    padding: 6mm 10mm !important;
    width: 100% !important;
    max-width: 100% !important;
  }
  .doc-watermark { opacity: 0.10 !important; display: flex !important; }
  @page { size: A4 portrait; margin: 6mm 10mm; }
}
</style>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8 space-y-8">
  <?= renderFlash() ?>

  <!-- ── 1. HEADER & TOP CONTROLS (NO PRINT) ──────────────────────── -->
  <div class="no-print space-y-6">
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
      <div>
        <div class="section-tag mb-1">Corporate HR Operations, Hiring &amp; Legal Agreements</div>
        <h1 class="text-2xl sm:text-3xl font-black text-white uppercase">HR DOCUMENTS, OFFER LETTERS &amp; NDAS</h1>
        <p class="text-gray-400 text-xs mt-1">Generate official offer letters, role-tailored NDAs with salary details for outsiders, and maintain dedicated signed contract files per employee.</p>
      </div>

      <div class="flex items-center gap-3">
        <?php if ($selectedDoc !== 'contracts'): ?>
        <button onclick="window.print()" class="btn-gold py-2.5 px-6 text-xs font-black shadow-glow inline-flex items-center gap-2">
          <span>🖨️</span> <span>Print / Save as PDF Document</span>
        </button>
        <?php endif; ?>
      </div>
    </div>

    <!-- Document Switcher Tabs -->
    <div class="flex flex-wrap gap-2 p-2 bg-[#111118] rounded-2xl border border-[#1E1E2E] text-xs font-bold">
      <a href="?doc=salary&emp_id=<?= urlencode($selectedEmpId) ?>" class="px-4 py-2.5 rounded-xl transition-all <?= $selectedDoc === 'salary' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white' ?>">
        💰 1. Pay Salary &amp; Payslip
      </a>
      <a href="?doc=bank&emp_id=<?= urlencode($selectedEmpId) ?>" class="px-4 py-2.5 rounded-xl transition-all <?= $selectedDoc === 'bank' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white' ?>">
        🏦 2. Bank Opening Letter
      </a>
      <a href="?doc=offer&mode=outsider" class="px-4 py-2.5 rounded-xl transition-all <?= $selectedDoc === 'offer' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white' ?>">
        ✉️ 3. Employment Offer Letter
      </a>
      <a href="?doc=nda&mode=outsider" class="px-4 py-2.5 rounded-xl transition-all <?= $selectedDoc === 'nda' ? 'bg-gold text-dark font-black shadow-glow' : 'text-gray-300 hover:text-white' ?>">
        📜 4. Role-Specific NDA Agreement
      </a>
      <a href="?doc=termination&emp_id=<?= urlencode($selectedEmpId) ?>" class="px-4 py-2.5 rounded-xl transition-all <?= $selectedDoc === 'termination' ? 'bg-red-600 text-white font-black shadow-glow' : 'text-gray-300 hover:text-white' ?>">
        ⚠️ 5. Termination / Notice
      </a>
      <a href="?doc=contracts" class="px-4 py-2.5 rounded-xl transition-all inline-flex items-center gap-2 <?= $selectedDoc === 'contracts' ? 'bg-emerald-600 text-white font-black shadow-glow' : 'text-emerald-400 hover:text-white bg-emerald-950/20 border border-emerald-500/30' ?>">
        <span>📂</span> <span>6. Candidate Contracts &amp; Signed NDAs Archive (<?= count($contracts) ?>)</span>
      </a>
    </div>
  </div>

  <!-- ════════════════════════════════════════════════════════════════ -->
  <!-- ── 2. VIEW: CONTRACTS & SIGNED NDAS ARCHIVE ──────────────────── -->
  <!-- ════════════════════════════════════════════════════════════════ -->
  <?php if ($selectedDoc === 'contracts'): ?>
  <div class="space-y-6">
    
    <!-- KPI Counters -->
    <?php
    $signedCount  = count(array_filter($contracts, fn($c) => ($c['status'] ?? '') === 'signed'));
    $pendingCount = count(array_filter($contracts, fn($c) => ($c['status'] ?? '') !== 'signed'));
    ?>
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
      <div class="glass-card rounded-2xl p-5 border border-dark-border space-y-1">
        <span class="text-xs text-gray-400 font-bold uppercase">Total Agreements Dispatched</span>
        <div class="text-2xl font-black text-white"><?= count($contracts) ?></div>
        <span class="text-[11px] text-gray-400">Offer Letters &amp; NDAs</span>
      </div>
      <div class="glass-card rounded-2xl p-5 border border-amber-500/40 bg-amber-950/10 space-y-1">
        <span class="text-xs text-amber-400 font-bold uppercase">⏳ Awaiting Candidate Signature</span>
        <div class="text-2xl font-black text-amber-300"><?= $pendingCount ?></div>
        <span class="text-[11px] text-gray-400">Link sent to outsider</span>
      </div>
      <div class="glass-card rounded-2xl p-5 border border-emerald-500/40 bg-emerald-950/10 space-y-1">
        <span class="text-xs text-emerald-400 font-bold uppercase">✅ Digitally Signed &amp; Stored</span>
        <div class="text-2xl font-black text-emerald-300"><?= $signedCount ?></div>
        <span class="text-[11px] text-emerald-400">Individual signed files saved in data/hr_signed_docs/</span>
      </div>
    </div>

    <!-- Active Contract Viewer (If selected) -->
    <?php if ($activeContract): ?>
    <div class="glass-card rounded-3xl p-6 border border-gold/40 shadow-2xl space-y-4">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-dark-border pb-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs uppercase font-mono font-bold text-gold"><?= htmlspecialchars($activeContract['id']) ?></span>
            <span class="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase <?= ($activeContract['status'] ?? '') === 'signed' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-amber-500/20 text-amber-300 border border-amber-500/40' ?>">
              <?= ($activeContract['status'] ?? '') === 'signed' ? '✓ Signed & Verified' : '⏳ Pending Signature' ?>
            </span>
          </div>
          <h2 class="text-xl font-black text-white mt-1">
            <?= htmlspecialchars($activeContract['candidate_name']) ?> &mdash; <span class="text-gold"><?= htmlspecialchars($activeContract['role']) ?></span>
          </h2>
          <p class="text-xs text-gray-400 font-mono">Email: <?= htmlspecialchars($activeContract['candidate_email']) ?> &bull; Phone: <?= htmlspecialchars($activeContract['candidate_phone'] ?: 'N/A') ?></p>
        </div>

        <div class="flex flex-wrap items-center gap-2">
          <a href="/hr-sign.php?token=<?= urlencode($activeContract['token']) ?>" target="_blank" class="btn-gold py-2 px-4 text-xs font-black inline-flex items-center gap-1.5 shadow-sm">
            <span>👁️</span> <span>Open Candidate Signing Portal ↗</span>
          </a>
          <button onclick="navigator.clipboard.writeText('<?= BASE_URL ?>/hr-sign.php?token=<?= urlencode($activeContract['token']) ?>'); alert('Signing Link Copied to Clipboard!');" class="btn-ghost py-2 px-3 text-xs font-bold border border-gold/40 text-gold hover:bg-gold/10 rounded-xl inline-flex items-center gap-1">
            <span>🔗</span> <span>Copy Link</span>
          </button>
          <?php if (($activeContract['status'] ?? '') === 'signed'): ?>
          <form method="POST" data-confirm="Enroll this signed candidate directly into active staff database?" class="inline">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="enroll_candidate_as_staff">
            <input type="hidden" name="contract_id" value="<?= htmlspecialchars($activeContract['id']) ?>">
            <button type="submit" class="py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs inline-flex items-center gap-1.5 shadow-md">
              <span>👤</span> <span>Enroll into Staff Database</span>
            </button>
          </form>
          <?php endif; ?>
        </div>
      </div>

      <!-- Contract Info Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
        <div class="p-3 rounded-xl bg-dark/60 border border-dark-border"><span class="text-gray-500 block">Department:</span><strong class="text-white"><?= htmlspecialchars($activeContract['department']) ?></strong></div>
        <div class="p-3 rounded-xl bg-dark/60 border border-dark-border"><span class="text-gray-500 block">Shift / Timings:</span><strong class="text-white"><?= htmlspecialchars($activeContract['shift']) ?></strong></div>
        <div class="p-3 rounded-xl bg-dark/60 border border-dark-border"><span class="text-gray-500 block">Compensation:</span><strong class="text-gold"><?= htmlspecialchars($activeContract['currency']) ?> <?= number_format((float)($activeContract['total_salary'] ?? 0), 2) ?></strong></div>
        <div class="p-3 rounded-xl bg-dark/60 border border-dark-border"><span class="text-gray-500 block">Joining Date:</span><strong class="text-white"><?= htmlspecialchars($activeContract['joining_date']) ?></strong></div>
      </div>

      <?php if (($activeContract['status'] ?? '') === 'signed'): ?>
      <div class="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/40 text-xs font-mono space-y-1.5">
        <div class="text-emerald-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
          <span>✓</span> <span>Certified Legally Binding Digital Execution Audit</span>
        </div>
        <div class="text-gray-300">Signed By: <strong class="text-white"><?= htmlspecialchars($activeContract['signer_name']) ?></strong> (CNIC: <?= htmlspecialchars($activeContract['signer_cnic'] ?: 'Verified') ?>)</div>
        <div class="text-gray-300">Signed At: <strong class="text-white"><?= htmlspecialchars($activeContract['signed_at_formatted'] ?? $activeContract['signed_at']) ?></strong> &bull; IP: <span class="text-gold"><?= htmlspecialchars($activeContract['signer_ip']) ?></span></div>
        <div class="text-gray-400 text-[11px]">Dedicated Storage File: <code class="text-emerald-300"><?= htmlspecialchars($activeContract['signed_file'] ?? 'data/hr_signed_docs/' . $activeContract['id'] . '.json') ?></code></div>
      </div>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Contracts Table -->
    <div class="glass-card rounded-3xl border border-dark-border overflow-hidden">
      <div class="p-5 border-b border-dark-border flex items-center justify-between">
        <div>
          <h3 class="text-base font-black text-white uppercase">All Outgoing Candidate Contracts &amp; NDAs</h3>
          <p class="text-gray-400 text-xs mt-0.5">Every signed agreement is stored in its own dedicated file with digital signature and audit trail.</p>
        </div>
        <a href="?doc=offer&mode=outsider" class="btn-gold py-2 px-4 text-xs font-black inline-flex items-center gap-1.5">
          <span>+</span> <span>New Outsider Offer / NDA</span>
        </a>
      </div>

      <div class="overflow-x-auto">
        <table class="w-full text-xs text-left">
          <thead class="bg-[#161622] text-gray-400 font-bold uppercase border-b border-dark-border">
            <tr>
              <th class="p-4">Ref &amp; Date</th>
              <th class="p-4">Candidate</th>
              <th class="p-4">Designation &amp; Dept</th>
              <th class="p-4">Agreed Salary</th>
              <th class="p-4">Status &amp; Signature</th>
              <th class="p-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-dark-border font-mono">
            <?php if (empty($contracts)): ?>
            <tr>
              <td colspan="6" class="p-8 text-center text-gray-500 text-xs">
                No candidate contracts dispatched yet. Click "+ New Outsider Offer / NDA" above to send your first official agreement.
              </td>
            </tr>
            <?php else: ?>
              <?php foreach ($contracts as $c): 
                $signed = ($c['status'] ?? '') === 'signed';
              ?>
              <tr class="hover:bg-white/[0.02] transition-colors">
                <td class="p-4">
                  <span class="font-bold text-white"><?= htmlspecialchars($c['id']) ?></span>
                  <div class="text-[10px] text-gray-400"><?= htmlspecialchars($c['joining_date'] ?? date('d M Y', strtotime($c['created_at'] ?? 'now'))) ?></div>
                </td>
                <td class="p-4">
                  <div class="font-bold text-white font-sans text-sm"><?= htmlspecialchars($c['candidate_name']) ?></div>
                  <div class="text-[11px] text-gray-400"><?= htmlspecialchars($c['candidate_email']) ?></div>
                </td>
                <td class="p-4">
                  <span class="text-gold font-bold"><?= htmlspecialchars($c['role']) ?></span>
                  <div class="text-[10px] text-gray-400"><?= htmlspecialchars($c['department']) ?> &bull; <?= htmlspecialchars($c['shift']) ?></div>
                </td>
                <td class="p-4">
                  <strong class="text-white"><?= htmlspecialchars($c['currency']) ?> <?= number_format((float)($c['total_salary'] ?? 0), 2) ?></strong>
                  <div class="text-[10px] text-gray-400"><?= htmlspecialchars($c['compensation_type']) ?></div>
                </td>
                <td class="p-4">
                  <?php if ($signed): ?>
                    <span class="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-black uppercase flex items-center gap-1 w-fit">
                      <span>✓</span> <span>Signed</span>
                    </span>
                    <div class="text-[10px] text-gray-400 mt-1"><?= htmlspecialchars(date('d M Y', strtotime($c['signed_at']))) ?></div>
                  <?php else: ?>
                    <span class="px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-black uppercase flex items-center gap-1 w-fit">
                      <span>⏳</span> <span>Pending Sign</span>
                    </span>
                  <?php endif; ?>
                </td>
                <td class="p-4 text-right space-x-2">
                  <a href="?doc=contracts&view_id=<?= urlencode($c['id']) ?>" class="px-3 py-1.5 rounded-lg bg-gray-800 hover:bg-gray-700 text-white font-bold text-xs inline-block">
                    View
                  </a>
                  <a href="/hr-sign.php?token=<?= urlencode($c['token']) ?>" target="_blank" class="px-3 py-1.5 rounded-lg bg-gold/20 hover:bg-gold hover:text-dark text-gold font-bold text-xs inline-block">
                    Sign Portal
                  </a>
                  <form method="POST" data-confirm="Delete this contract record?" class="inline">
                    <?= csrfField() ?>
                    <input type="hidden" name="action" value="delete_contract">
                    <input type="hidden" name="contract_id" value="<?= htmlspecialchars($c['id']) ?>">
                    <button type="submit" class="px-2.5 py-1.5 rounded-lg bg-red-950/40 hover:bg-red-800 text-red-300 text-xs">
                      ✕
                    </button>
                  </form>
                </td>
              </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>

  <!-- ════════════════════════════════════════════════════════════════ -->
  <!-- ── 3. VIEW: STANDARD HR GENERATOR & OUTSIDER OFFER / NDA HUB ── -->
  <!-- ════════════════════════════════════════════════════════════════ -->
  <?php else: ?>

  <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
    
    <!-- ── LEFT: CONFIGURATION & CANDIDATE HIRING FORM (NO PRINT) ── -->
    <div class="lg:col-span-4 glass-card rounded-3xl p-6 border border-dark-border shadow-2xl space-y-6 no-print">
      <div class="border-b border-dark-border pb-3 flex items-center justify-between">
        <div>
          <div class="section-tag mb-1">HR Generator Suite</div>
          <h3 class="text-base font-black text-white uppercase">Customize Document</h3>
        </div>
      </div>

      <!-- Mode Toggle: Existing Staff vs Outsider Candidate -->
      <div class="flex items-center gap-2 p-1.5 rounded-2xl bg-[#161622] border border-dark-border text-xs font-bold">
        <a href="?doc=<?= urlencode($selectedDoc) ?>&mode=staff&emp_id=<?= urlencode($selectedEmpId) ?>" class="flex-1 text-center py-2 rounded-xl transition-all <?= $mode === 'staff' ? 'bg-gold text-dark font-black shadow-sm' : 'text-gray-400 hover:text-white' ?>">
          👤 Existing Staff
        </a>
        <a href="?doc=<?= urlencode($selectedDoc) ?>&mode=outsider" class="flex-1 text-center py-2 rounded-xl transition-all <?= $mode === 'outsider' ? 'bg-amber-500 text-dark font-black shadow-sm' : 'text-gray-400 hover:text-white' ?>">
          🌟 New Outsider Hire
        </a>
      </div>

      <!-- ── MODE A: SELECT EXISTING STAFF ───────────────────────── -->
      <?php if ($mode === 'staff'): ?>
      <div>
        <label class="form-label text-xs font-bold text-gold">👤 Select Active Staff Member</label>
        <select onchange="window.location.href='?doc=<?= urlencode($selectedDoc) ?>&mode=staff&emp_id=' + this.value"
                class="form-select text-xs w-full mt-1 bg-[#161622] border-[#2A2A3A] text-white rounded-xl py-2 px-3 font-bold">
          <?php foreach ($employees as $emp): 
            $eId = $emp['id'] ?? $emp['user_id'];
          ?>
            <option value="<?= htmlspecialchars($eId) ?>" <?= $eId === $selectedEmpId ? 'selected' : '' ?>>
              <?= htmlspecialchars($emp['name']) ?> (<?= htmlspecialchars($emp['role']) ?>)
            </option>
          <?php endforeach; ?>
        </select>
        <p class="text-[11px] text-gray-400 mt-1">Auto-populates salary, duties, and contact details from employee profile.</p>
      </div>

      <!-- Salary Form Controls -->
      <?php if ($selectedDoc === 'salary'): ?>
      <div class="space-y-4 pt-2 border-t border-dark-border text-xs">
        <div>
          <label class="form-label font-bold text-gold">💵 Currency</label>
          <select id="inCurrency" onchange="updateSalaryPreview()" class="form-select text-xs w-full mt-1 bg-[#161622] border-[#2A2A3A] text-white font-bold">
            <option value="PKR" <?= $empCurrency === 'PKR' ? 'selected' : '' ?>>PKR (Rs. Pakistani Rupee)</option>
            <option value="USD" <?= $empCurrency === 'USD' ? 'selected' : '' ?>>USD ($ US Dollar)</option>
            <option value="GBP" <?= $empCurrency === 'GBP' ? 'selected' : '' ?>>GBP (£ British Pound)</option>
            <option value="EUR" <?= $empCurrency === 'EUR' ? 'selected' : '' ?>>EUR (€ Euro)</option>
            <option value="AED" <?= $empCurrency === 'AED' ? 'selected' : '' ?>>AED (UAE Dirham)</option>
          </select>
        </div>
        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="form-label font-bold text-gray-300">Basic Salary</label>
            <input type="number" id="inBasic" value="<?= $basicSalary ?>" step="1" oninput="updateSalaryPreview()" class="form-input text-xs w-full mt-1 bg-[#161622] text-white font-mono">
          </div>
          <div>
            <label class="form-label font-bold text-gray-300">Rent Allowance</label>
            <input type="number" id="inRent" value="<?= $rentAllowance ?>" step="1" oninput="updateSalaryPreview()" class="form-input text-xs w-full mt-1 bg-[#161622] text-white font-mono">
          </div>
        </div>

        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="form-label font-bold text-gray-300">Other Allow ($)</label>
            <input type="number" id="inOther" value="<?= $otherAllowances ?>" step="1" oninput="updateSalaryPreview()" class="form-input text-xs w-full mt-1 bg-[#161622] text-white font-mono">
          </div>
          <div>
            <label class="form-label font-bold text-emerald-400">Bonus ($)</label>
            <input type="number" id="inBonus" value="<?= $bonus ?>" step="1" oninput="updateSalaryPreview()" class="form-input text-xs w-full mt-1 bg-[#161622] text-white font-mono">
          </div>
        </div>

        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="form-label font-bold text-red-400">Deductions ($)</label>
            <input type="number" id="inDeduct" value="<?= $deductions ?>" step="1" oninput="updateSalaryPreview()" class="form-input text-xs w-full mt-1 bg-[#161622] text-white font-mono">
          </div>
          <div>
            <label class="form-label font-bold text-gray-300">Pay Period Month</label>
            <input type="text" id="inMonth" value="<?= $payPeriod ?>" oninput="updateSalaryPreview()" class="form-input text-xs w-full mt-1 bg-[#161622] text-white font-mono">
          </div>
        </div>

        <div class="p-3 rounded-xl bg-gold/10 border border-gold/30 flex items-center justify-between">
          <span class="text-xs font-bold text-gold">Calculated Net Pay:</span>
          <span id="calcNetText" class="text-base font-black text-gold font-mono">$<?= number_format($netSalary, 2) ?></span>
        </div>
      </div>
      <?php endif; ?>

      <?php if ($selectedDoc === 'bank'): ?>
      <div class="space-y-4 pt-2 border-t border-dark-border text-xs">
        <div>
          <label class="form-label font-bold text-gray-300">Bank Name &amp; Branch</label>
          <input type="text" id="inBankName" value="Standard Chartered Bank / Authorized Branch" oninput="updateBankPreview()" class="form-input text-xs w-full mt-1 bg-[#161622] text-white">
        </div>
        <div>
          <label class="form-label font-bold text-gray-300">Employee CNIC / Passport ID</label>
          <input type="text" id="inBankId" value="CNIC: 35201-9876543-1 / Official ID: <?= htmlspecialchars($empData['id']) ?>" oninput="updateBankPreview()" class="form-input text-xs w-full mt-1 bg-[#161622] text-white font-mono">
        </div>
      </div>
      <?php endif; ?>

      <?php if ($selectedDoc === 'termination'): ?>
      <div class="space-y-4 pt-2 border-t border-dark-border text-xs">
        <div>
          <label class="form-label font-bold text-red-400">Effective Termination Date</label>
          <input type="text" id="inTermDate" value="<?= $docDate ?>" oninput="updateTermPreview()" class="form-input text-xs w-full mt-1 bg-[#161622] text-white font-mono">
        </div>
        <div>
          <label class="form-label font-bold text-gray-300">Reason for Separation</label>
          <select id="inTermReason" onchange="updateTermPreview()" class="form-select text-xs w-full mt-1 bg-[#161622] text-white">
            <option value="Operational Realignment & Shift Restructuring">Operational Realignment</option>
            <option value="Performance Below Quality SLA Standards">Performance Below SLA Standards</option>
            <option value="Voluntary Resignation Acceptance">Voluntary Resignation</option>
            <option value="End of Fixed Contract Term">End of Contract</option>
          </select>
        </div>
        <div>
          <label class="form-label font-bold text-gray-300">Full &amp; Final Settlement Days</label>
          <input type="text" id="inTermSettlement" value="14 Business Days" oninput="updateTermPreview()" class="form-input text-xs w-full mt-1 bg-[#161622] text-white font-mono">
        </div>
      </div>
      <?php endif; ?>

      <div class="pt-4 border-t border-dark-border">
        <button onclick="window.print()" class="btn-gold w-full py-3 font-black text-xs shadow-glow inline-flex items-center justify-center gap-2">
          <span>🖨️</span> <span>Print Official Letterhead</span>
        </button>
      </div>

      <!-- ── MODE B: NEW OUTSIDER HIRE / CANDIDATE HIRING FORM ─────── -->
      <?php else: ?>
      <form method="POST" class="space-y-4 pt-2 text-xs">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="create_and_send_contract">
        <input type="hidden" name="doc_type" value="<?= ($selectedDoc === 'nda' ? 'nda' : ($selectedDoc === 'offer' ? 'offer_letter' : 'offer_and_nda')) ?>">

        <div class="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300">
          <strong class="block text-xs uppercase font-black">🌟 Hiring Outside Contractor / Candidate</strong>
          <span class="text-[11px] text-gray-300">Enter candidate details and salary. The system generates an official Offer &amp; NDA with a digital signing link.</span>
        </div>

        <div>
          <label class="form-label font-bold text-white">Candidate Full Name *</label>
          <input type="text" name="candidate_name" id="inCandName" required placeholder="e.g. Farhan Ali" oninput="updateCandidatePreview()" class="form-input text-xs w-full mt-1 bg-[#161622] text-white font-bold">
        </div>

        <div>
          <label class="form-label font-bold text-white">Candidate Email Address *</label>
          <input type="email" name="candidate_email" id="inCandEmail" required placeholder="candidate@example.com" oninput="updateCandidatePreview()" class="form-input text-xs w-full mt-1 bg-[#161622] text-white">
        </div>

        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="form-label font-bold text-gray-300">Phone / WhatsApp</label>
            <input type="text" name="candidate_phone" id="inCandPhone" placeholder="+44 ... / +92 ..." oninput="updateCandidatePreview()" class="form-input text-xs w-full mt-1 bg-[#161622] text-white font-mono">
          </div>
          <div>
            <label class="form-label font-bold text-gray-300">CNIC / National ID</label>
            <input type="text" name="candidate_id_number" id="inCandCnic" placeholder="35201-XXXXXXX-X" oninput="updateCandidatePreview()" class="form-input text-xs w-full mt-1 bg-[#161622] text-white font-mono">
          </div>
        </div>

        <!-- Role Selector (Auto-updates NDA clauses & duties) -->
        <div>
          <label class="form-label font-bold text-gold">Assigned Designation / Role *</label>
          <select name="role" id="inCandRole" onchange="updateRolePreset(this.value)" class="form-select text-xs w-full mt-1 bg-[#161622] border-[#2A2A3A] text-white font-bold">
            <option value="Photo Editor">Photo Editor (HDR &amp; Flambient)</option>
            <option value="Senior Photo Editor">Senior Photo Editor (Master Blending)</option>
            <option value="Team Lead">Team Lead (QA &amp; Editor Allocation)</option>
            <option value="Supervisor">Supervisor (Operations &amp; Shift Management)</option>
            <option value="Production Manager">Production Manager (Global Operations)</option>
            <option value="SEO Manager">SEO Manager (CMS &amp; Growth Strategy)</option>
            <option value="QA Specialist">Quality Assurance Specialist (Final Inspection)</option>
            <option value="Virtual Staging Artist">Virtual Staging Artist (3D Architectural)</option>
            <option value="Freelance Editor">Freelance Editor (Remote Contractor)</option>
          </select>
        </div>

        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="form-label font-bold text-gray-300">Department</label>
            <input type="text" name="department" id="inCandDept" value="Production" oninput="updateCandidatePreview()" class="form-input text-xs w-full mt-1 bg-[#161622] text-white font-bold">
          </div>
          <div>
            <label class="form-label font-bold text-gray-300">Joining Date</label>
            <input type="text" name="joining_date" id="inCandJoin" value="<?= date('F j, Y', strtotime('+7 days')) ?>" oninput="updateCandidatePreview()" class="form-input text-xs w-full mt-1 bg-[#161622] text-white font-mono">
          </div>
        </div>

        <div>
          <label class="form-label font-bold text-gold">Shift Schedule &amp; Client Timing</label>
          <input type="text" name="shift" id="inCandShift" value="US Client Shift (08:00 PM - 05:00 AM PKT)" oninput="updateCandidatePreview()" list="outsiderShiftPresets" class="form-input text-xs w-full mt-1 bg-[#161622] text-white font-bold">
          <datalist id="outsiderShiftPresets">
            <option value="US Client Shift (08:00 PM - 05:00 AM PKT)">US Dedicated Shift</option>
            <option value="UK Client Shift (01:00 PM - 10:00 PM PKT)">UK Dedicated Shift</option>
            <option value="Australia Shift (05:00 AM - 02:00 PM PKT)">Australia Early Shift</option>
            <option value="Morning Shift (09:00 AM - 06:00 PM)">Standard Morning Shift</option>
            <option value="Night Shift (06:00 PM - 03:00 AM)">Standard Night Shift</option>
            <option value="Flexible Remote / Freelance Output">Flexible Remote Output</option>
          </datalist>
        </div>

        <!-- Compensation Controls -->
        <div class="p-4 rounded-2xl bg-[#141622] border border-dark-border space-y-3">
          <span class="text-xs uppercase font-black text-amber-400">💵 Compensation &amp; Salary Structure</span>
          
          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="form-label font-bold text-gray-300">Payment Currency</label>
              <select name="currency" id="inCandCurrency" onchange="updateCandidatePreview()" class="form-select text-xs w-full mt-1 bg-[#161622] text-white font-bold">
                <option value="USD ($)">USD ($)</option>
                <option value="PKR (Rs.)">PKR (Rs.)</option>
                <option value="GBP (£)">GBP (£)</option>
                <option value="EUR (€)">EUR (€)</option>
              </select>
            </div>
            <div>
              <label class="form-label font-bold text-gray-300">Compensation Model</label>
              <select name="compensation_type" id="inCandCompType" onchange="updateCandidatePreview()" class="form-select text-xs w-full mt-1 bg-[#161622] text-white font-bold">
                <option value="Monthly Salary">Monthly Salary</option>
                <option value="Per Bracket / Photo Rate">Per Bracket Rate</option>
                <option value="Bi-Weekly Retainer">Bi-Weekly Retainer</option>
                <option value="Contract Fee">Fixed Contract Fee</option>
              </select>
            </div>
          </div>

          <div>
            <label class="form-label font-bold text-white">Agreed Total Compensation Amount</label>
            <input type="number" step="0.01" name="total_salary" id="inCandSalary" value="750.00" oninput="updateCandidatePreview()" class="form-input text-sm w-full mt-1 bg-[#161622] text-gold font-black font-mono">
          </div>

          <div>
            <label class="form-label font-bold text-gray-300">Payment Routing / Terms Note</label>
            <input type="text" name="salary_notes" id="inCandNotes" value="Disbursed via automated monthly direct transfer upon SLA performance completion." oninput="updateCandidatePreview()" class="form-input text-xs w-full mt-1 bg-[#161622] text-white">
          </div>
        </div>

        <div class="space-y-2 pt-3 border-t border-dark-border">
          <button type="submit" name="send_email_now" value="1" class="btn-gold w-full py-3.5 font-black text-xs shadow-glow flex items-center justify-center gap-2">
            <span>🚀</span> <span>Save &amp; Email Offer / NDA to Candidate</span>
          </button>
          <button type="submit" class="w-full py-2.5 rounded-xl bg-gray-800 hover:bg-gray-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all">
            <span>💾</span> <span>Generate Link Only (No Email)</span>
          </button>
        </div>
      </form>
      <?php endif; ?>

    </div>

    <!-- ── RIGHT: LIVE DOCUMENT PREVIEW (PRINTABLE A4 SHEET) ──────── -->
    <div class="lg:col-span-8">
      <div class="doc-sheet rounded-3xl p-8 sm:p-12 border border-dark-border">
        
        <!-- 15% Watermark -->
        <div class="doc-watermark flex flex-col items-center justify-center">
          <img src="/assets/images/Black.png" alt="Estate HDR" class="w-64 h-auto object-contain mx-auto mb-2 opacity-90" onerror="this.style.display='none'">
          <div class="text-xs font-mono tracking-widest text-black font-black uppercase">Official Verified Corporate Document</div>
        </div>

        <div class="doc-content space-y-7">
          
          <!-- ── CORPORATE LETTERHEAD HEADER ──────────────────────────── -->
          <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b-2 border-[#C9A84C] pb-6">
            <div>
              <div class="flex items-center gap-3">
                <img src="/assets/images/Black.png" alt="Estate HDR" class="h-9 sm:h-10 w-auto max-w-[190px] object-contain" onerror="this.outerHTML='<span class=\'font-black text-xl text-gray-900\'>Estate <span class=\'text-[#C9A84C]\'>HDR</span></span>'">
                <span class="text-[10px] uppercase font-black tracking-widest px-2.5 py-1 rounded bg-amber-100 text-amber-900 border border-amber-300">
                  Human Resources &amp; Legal Operations
                </span>
              </div>
              <p class="text-[11px] text-gray-800 font-mono font-bold mt-1">Premium Real Estate Photo Retouching &amp; Virtual Media SaaS</p>
              <p class="text-[10px] text-gray-500 font-mono">UK Reg: EH-789021 • London &bull; Worldwide Delivery Hubs</p>
            </div>

            <div class="text-right text-[11px] font-mono text-gray-600 space-y-0.5">
              <div class="font-bold text-gray-900"><?= htmlspecialchars($refNumber) ?></div>
              <div>Date: <strong class="text-gray-900"><?= htmlspecialchars($docDate) ?></strong></div>
              <div>HR Desk: <span class="text-gray-900">hr@estatehdr.com</span></div>
              <div>Portal: <span class="text-gray-900">www.estatehdr.com</span></div>
            </div>
          </div>

          <!-- ── LIVE DOCUMENT SWITCHER (PREVIEWS) ────────────────────── -->
          
          <?php if ($selectedDoc === 'salary'): ?>
          <!-- 💰 1. SALARY SLIP PREVIEW -->
          <div class="space-y-4 text-xs leading-relaxed text-gray-800">
            <div class="text-center space-y-1">
              <h2 class="text-xl font-black tracking-wide text-gray-900 uppercase">OFFICIAL MONTHLY SALARY DISBURSEMENT SLIP</h2>
              <p class="text-xs font-mono text-gray-600">Pay Period: <strong class="text-gray-900" id="outPayMonth"><?= $payPeriod ?></strong> &bull; Currency: <strong>USD ($)</strong></p>
            </div>

            <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-gray-50 border border-gray-200 font-mono text-xs">
              <div><span class="text-gray-500 block">Employee ID:</span><strong class="text-gray-900"><?= htmlspecialchars($selectedEmpId) ?></strong></div>
              <div><span class="text-gray-500 block">Staff Name:</span><strong class="text-gray-900"><?= htmlspecialchars($empName) ?></strong></div>
              <div><span class="text-gray-500 block">Designation:</span><strong class="text-gray-900"><?= htmlspecialchars($empRole) ?></strong></div>
              <div><span class="text-gray-500 block">Department:</span><strong class="text-gray-900"><?= htmlspecialchars($empDept) ?></strong></div>
            </div>

            <table class="w-full text-xs text-left border border-gray-200 rounded-xl overflow-hidden">
              <thead class="bg-gray-100 text-gray-700 font-bold border-b border-gray-200">
                <tr><th class="p-3">EARNINGS &amp; ALLOWANCES</th><th class="p-3 text-right">AMOUNT</th><th class="p-3">DEDUCTIONS &amp; TAX</th><th class="p-3 text-right">AMOUNT</th></tr>
              </thead>
              <tbody class="divide-y divide-gray-100 font-mono">
                <tr><td class="p-3">Basic Salary</td><td class="p-3 text-right" id="outBasic">$<?= number_format($basicSalary, 2) ?></td><td class="p-3">Statutory Deductions / Leaves</td><td class="p-3 text-right" id="outDeduct">$<?= number_format($deductions, 2) ?></td></tr>
                <tr><td class="p-3">House Rent Allowance</td><td class="p-3 text-right" id="outRent">$<?= number_format($rentAllowance, 2) ?></td><td class="p-3">Other Withholdings</td><td class="p-3 text-right">$0.00</td></tr>
                <tr><td class="p-3">Utility &amp; Other Allowances</td><td class="p-3 text-right" id="outOther">$<?= number_format($otherAllowances, 2) ?></td><td class="p-3">-</td><td class="p-3 text-right">-</td></tr>
                <tr><td class="p-3 text-emerald-800 font-bold">Shift &amp; Quality Bonus</td><td class="p-3 text-right text-emerald-800 font-bold" id="outBonus">$<?= number_format($bonus, 2) ?></td><td class="p-3">-</td><td class="p-3 text-right">-</td></tr>
              </tbody>
            </table>

            <div class="p-5 rounded-2xl bg-amber-50/70 border-2 border-[#C9A84C] flex items-center justify-between">
              <div><span class="text-xs text-amber-900 font-bold uppercase tracking-wider">TOTAL NET PAYABLE SALARY:</span><p class="text-[11px] text-gray-600 font-mono mt-0.5">Dispatched directly to verified corporate salary account.</p></div>
              <div class="text-right"><div class="text-2xl font-black text-gray-900 font-mono" id="outNet">$<?= number_format($netSalary, 2) ?> USD</div><span class="text-[10px] font-bold text-emerald-800 uppercase px-2 py-0.5 rounded bg-emerald-100 border border-emerald-300">✓ Disbursed &amp; Approved</span></div>
            </div>
          </div>

          <?php elseif ($selectedDoc === 'bank'): ?>
          <!-- 🏦 2. BANK OPENING LETTER PREVIEW -->
          <div class="space-y-4 text-xs leading-relaxed text-gray-800">
            <div class="space-y-1"><p class="font-bold text-gray-900">To,</p><p class="font-bold text-gray-900">The Branch Manager,</p><p class="text-gray-700" id="outBankName">Standard Chartered Bank / Authorized Branch,</p></div>
            <div class="pt-2 border-b border-gray-300 pb-2"><h3 class="text-sm font-black text-gray-900 uppercase">SUBJECT: REQUEST FOR OPENING CORPORATE SALARY ACCOUNT</h3></div>
            <p>Dear Sir / Madam,</p>
            <p>This is to officially confirm and certify that <strong>Mr./Ms. <?= htmlspecialchars($empName) ?></strong> (Employee ID: <strong><?= htmlspecialchars($selectedEmpId) ?></strong>) is a bona fide, full-time permanent employee of <strong>Estate HDR</strong>, serving in the capacity of <strong><?= htmlspecialchars($empRole) ?></strong> in our <strong><?= htmlspecialchars($empDept) ?> Department</strong>.</p>
            <div class="p-4 rounded-xl bg-gray-50 border border-gray-200 space-y-1 font-mono text-[11px]">
              <div>• <strong>Employee Full Name:</strong> <?= htmlspecialchars($empName) ?></div>
              <div>• <strong>Designation:</strong> <?= htmlspecialchars($empRole) ?></div>
              <div>• <strong>Official Email:</strong> <?= htmlspecialchars($empEmail) ?></div>
              <div>• <strong>Monthly Net Compensation:</strong> $<?= number_format($netSalary, 2) ?> USD</div>
              <div>• <strong>Employment Status:</strong> Active / Full-Time</div>
            </div>
            <p>We request your esteemed financial institution to facilitate the opening of an individual <strong>Corporate Salary Account</strong> for automated monthly salary disbursements.</p>
          </div>

          <?php elseif ($selectedDoc === 'offer' || $selectedDoc === 'nda'): ?>
          <!-- ✉️ & 📜 3 & 4. OFFER LETTER / NDA (CANDIDATE OR STAFF) -->
          <div class="space-y-4 text-xs leading-relaxed text-gray-800">
            <div>
              <p class="font-bold text-gray-900">To: <strong id="pvName" class="text-base"><?= ($mode === 'outsider' ? 'Candidate Name' : htmlspecialchars($empName)) ?></strong></p>
              <p class="text-gray-600 font-mono" id="pvContact"><?= ($mode === 'outsider' ? 'candidate@example.com' : htmlspecialchars($empEmail)) ?></p>
            </div>

            <div class="border-b border-gray-300 pb-2">
              <h3 class="text-sm font-black text-gray-900 uppercase">
                <?= $selectedDoc === 'offer' ? 'OFFICIAL APPOINTMENT &amp; EMPLOYMENT OFFER LETTER' : 'ROLE-SPECIFIC CONFIDENTIALITY &amp; NON-DISCLOSURE AGREEMENT' ?>
              </h3>
              <p class="text-[11px] text-[#9A7A2E] font-bold font-mono mt-0.5">Specialized Protocol: <span id="pvRoleTitle"><?= htmlspecialchars($empRole) ?></span></p>
            </div>

            <p>
              On behalf of <strong>Estate HDR</strong>, we are pleased to extend this formal 
              <?= $selectedDoc === 'offer' ? 'offer of engagement' : 'confidentiality agreement' ?> for the position of 
              <strong id="pvRole"><?= htmlspecialchars($empRole) ?></strong>.
            </p>

            <div class="p-4 rounded-xl bg-gray-50 border border-gray-200 space-y-2 font-mono text-[11px]">
              <div>• <strong>Designation:</strong> <span id="pvRoleRow"><?= htmlspecialchars($empRole) ?></span></div>
              <div>• <strong>Department:</strong> <span id="pvDeptRow"><?= htmlspecialchars($empDept) ?></span></div>
              <div>• <strong>Expected Joining Date:</strong> <span id="pvJoinRow"><?= date('F j, Y', strtotime('+7 days')) ?></span></div>
              <div>• <strong>Assigned Shift:</strong> <span id="pvShiftRow"><?= htmlspecialchars($empShift) ?></span></div>
              <div>• <strong>Agreed Total Compensation:</strong> <strong id="pvSalaryRow" class="text-gray-900">$750.00 USD (Monthly Salary)</strong></div>
            </div>

            <?php if ($selectedDoc === 'offer'): ?>
            <p>
              In this role, you will be expected to adhere to the company's Standard Operating Procedures (SOP), maintain strict client privacy, 
              and deliver high-caliber real estate visual content. Please review and sign using the digital signature link provided.
            </p>
            <?php else: ?>
            <div class="space-y-2">
              <h4 class="font-bold text-gray-900 uppercase text-xs">Role-Specific Confidentiality Terms:</h4>
              <div class="p-3 rounded-lg bg-gray-50 border border-gray-200 text-gray-700 leading-relaxed" id="pvNdaClauses">
                • <strong>Raw Media Exclusivity:</strong> All client HDR brackets and exposures are strictly proprietary.<br>
                • <strong>Client Shield:</strong> Direct contact or solicitation of clients is strictly prohibited.<br>
                • <strong>Perpetual Binding:</strong> Obligations remain binding post-employment under applicable law.
              </div>
            </div>
            <?php endif; ?>

          </div>

          <?php elseif ($selectedDoc === 'termination'): ?>
          <!-- ⚠️ 5. TERMINATION PREVIEW -->
          <div class="space-y-4 text-xs leading-relaxed text-gray-800">
            <div><p class="font-bold text-gray-900">To: <strong><?= htmlspecialchars($empName) ?></strong></p></div>
            <div class="border-b border-red-300 pb-2"><h3 class="text-sm font-black text-red-700 uppercase">OFFICIAL EMPLOYMENT TERMINATION / RELIEVING NOTICE</h3></div>
            <p>Dear <strong><?= htmlspecialchars($empName) ?></strong>,</p>
            <p>This letter serves as formal notification that your employment with <strong>Estate HDR</strong> as <strong><?= htmlspecialchars($empRole) ?></strong> is being officially concluded effective <strong id="outTermDate"><?= $docDate ?></strong>.</p>
          </div>
          <?php endif; ?>

          <!-- ── OFFICIAL SIGNATURES & CORPORATE STAMP ───────────────── -->
          <div class="pt-10 border-t-2 border-gray-200 grid grid-cols-3 gap-6 text-center text-xs font-mono">
            
            <div class="space-y-2">
              <div class="h-14 flex items-end justify-center">
                <span class="font-serif italic text-base text-gray-800 font-bold border-b border-gray-400 pb-1 px-4">
                  Sarah Jenkins
                </span>
              </div>
              <div class="font-bold text-gray-900">Sarah Jenkins</div>
              <div class="text-[10px] text-gray-500">Head of Human Resources &bull; Estate HDR</div>
            </div>

            <div class="flex flex-col items-center justify-center">
              <div class="w-20 h-20 rounded-full border-2 border-dashed border-[#C9A84C] flex flex-col items-center justify-center p-1 text-center bg-amber-50/50">
                <span class="text-[8px] font-black text-[#C9A84C] uppercase tracking-tighter">ESTATE HDR</span>
                <span class="text-[7px] text-gray-600 font-bold">OFFICIAL SEAL</span>
                <span class="text-[6px] text-gray-400">VERIFIED</span>
              </div>
              <span class="text-[9px] text-gray-400 mt-1">Official Corporate Stamp</span>
            </div>

            <div class="space-y-2">
              <div class="h-14 flex items-end justify-center">
                <span class="border-b border-gray-400 w-32 inline-block"></span>
              </div>
              <div class="font-bold text-gray-900" id="pvSignerName"><?= ($mode === 'outsider' ? 'Candidate Signature' : htmlspecialchars($empName)) ?></div>
              <div class="text-[10px] text-gray-500">Appointee / Employee Signature</div>
            </div>

          </div>

          <div class="text-right text-[11px] font-mono text-gray-400 pt-2">
            1/1
          </div>

        </div>

      </div>
    </div>

  </div>

  <?php endif; ?>

</main>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
function updateSalaryPreview() {
  const b = parseFloat(document.getElementById('inBasic')?.value || 0);
  const r = parseFloat(document.getElementById('inRent')?.value || 0);
  const o = parseFloat(document.getElementById('inOther')?.value || 0);
  const bo = parseFloat(document.getElementById('inBonus')?.value || 0);
  const d = parseFloat(document.getElementById('inDeduct')?.value || 0);
  const net = (b + r + o + bo) - d;

  if (document.getElementById('calcNetText')) document.getElementById('calcNetText').textContent = '$' + net.toFixed(2);
  if (document.getElementById('outNet')) document.getElementById('outNet').textContent = '$' + net.toFixed(2) + ' USD';
  if (document.getElementById('outBasic')) document.getElementById('outBasic').textContent = '$' + b.toFixed(2);
  if (document.getElementById('outRent')) document.getElementById('outRent').textContent = '$' + r.toFixed(2);
  if (document.getElementById('outOther')) document.getElementById('outOther').textContent = '$' + o.toFixed(2);
  if (document.getElementById('outBonus')) document.getElementById('outBonus').textContent = '$' + bo.toFixed(2);
  if (document.getElementById('outDeduct')) document.getElementById('outDeduct').textContent = '$' + d.toFixed(2);
}

function updateCandidatePreview() {
  const name = document.getElementById('inCandName')?.value || 'Candidate Name';
  const email = document.getElementById('inCandEmail')?.value || 'candidate@example.com';
  const phone = document.getElementById('inCandPhone')?.value || '';
  const role = document.getElementById('inCandRole')?.value || 'Photo Editor';
  const dept = document.getElementById('inCandDept')?.value || 'Production';
  const shift = document.getElementById('inCandShift')?.value || '';
  const join = document.getElementById('inCandJoin')?.value || '';
  const sal = parseFloat(document.getElementById('inCandSalary')?.value || 0).toFixed(2);
  const curr = document.getElementById('inCandCurrency')?.value || 'USD ($)';
  const comp = document.getElementById('inCandCompType')?.value || 'Monthly Salary';

  if (document.getElementById('pvName')) document.getElementById('pvName').textContent = name;
  if (document.getElementById('pvContact')) document.getElementById('pvContact').textContent = email + (phone ? ' • ' + phone : '');
  if (document.getElementById('pvRole')) document.getElementById('pvRole').textContent = role;
  if (document.getElementById('pvRoleTitle')) document.getElementById('pvRoleTitle').textContent = role + ' Protocol';
  if (document.getElementById('pvRoleRow')) document.getElementById('pvRoleRow').textContent = role;
  if (document.getElementById('pvDeptRow')) document.getElementById('pvDeptRow').textContent = dept;
  if (document.getElementById('pvShiftRow')) document.getElementById('pvShiftRow').textContent = shift;
  if (document.getElementById('pvJoinRow')) document.getElementById('pvJoinRow').textContent = join;
  if (document.getElementById('pvSalaryRow')) document.getElementById('pvSalaryRow').textContent = `${curr} ${sal} (${comp})`;
  if (document.getElementById('pvSignerName')) document.getElementById('pvSignerName').textContent = name;
}

function updateRolePreset(role) {
  updateCandidatePreview();
}
</script>

</body>
</html>
