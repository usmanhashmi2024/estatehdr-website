<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireManagerOrAdmin();

$allUsers = getUsers();
$errors   = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrf();
    $userId          = trim($_POST['user_id'] ?? '');
    $propertyName    = trim($_POST['property_name'] ?? '');
    $cloudLink       = trim($_POST['cloud_link'] ?? '');
    $serviceType     = trim($_POST['service_type'] ?? '');
    $rawImagesCount  = (int)($_POST['raw_images_count'] ?? 0);
    $notes           = trim($_POST['notes'] ?? '');
    $orderType       = trim($_POST['order_type'] ?? 'live_order');
    $isTrial         = ($orderType === 'free_trial');

    $client = getUserById($userId);
    if (!$client)                          $errors[] = 'Please select a valid registered client.';
    if (strlen($propertyName) < 3)         $errors[] = 'Property name is required (min 3 characters).';
    if (empty($cloudLink))                 $errors[] = 'Please provide the client raw files link.';
    if (empty($serviceType))              $errors[] = 'Please select service type.';
    if ($rawImagesCount < 1)               $errors[] = 'Please specify number of raw images submitted.';

    if (empty($errors)) {
        $order = createOrder($userId, $propertyName, $cloudLink, $notes, $serviceType, $rawImagesCount, 'admin', $isTrial);
        $typeMsg = $isTrial ? ' [🎁 Free Trial]' : ' [⚡ Live Order]';
        setFlash('success', 'Proxy order #' . strtoupper(substr($order['id'], 0, 8)) . $typeMsg . ' created on behalf of ' . htmlspecialchars($client['name']) . '! Dispatched directly to Supervisor Daily Properties Queue for assignment.');
        header('Location: /admin/supervisor-dashboard.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Proxy Order Creation (On Behalf) — Estate HDR Admin</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-[#0A0A0F] text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="portal-main max-w-2xl">
  <?= renderFlash() ?>

  <div class="mb-8">
    <div class="section-tag mb-2">Order on Behalf of Client</div>
    <h1 class="text-2xl sm:text-3xl font-bold text-white">Proxy Job Creation</h1>
    <p class="text-gray-400 text-sm mt-1">If a client emailed or sent Dropbox links via WhatsApp, place the order here to maintain a 100% auditable historical ledger.</p>
  </div>

  <?php if (!empty($errors)): ?>
  <div class="flash-msg flash-error mb-6">
    <?php foreach ($errors as $e): ?><div>&bull; <?= htmlspecialchars($e) ?></div><?php endforeach; ?>
  </div>
  <?php endif; ?>

  <div class="glass-card rounded-2xl p-8 border border-dark-border shadow-2xl">
    <form method="POST" class="space-y-6">
      <?= csrfField() ?>

      <!-- Client Selection -->
      <div>
        <div class="flex items-center justify-between mb-1.5">
          <label class="form-label mb-0">Select Client Account <span class="text-red-400">*</span></label>
          <a href="/admin/client-new.php" class="text-gold text-xs hover:underline font-semibold">+ Onboard New Client</a>
        </div>
        <select name="user_id" class="form-select text-sm" required>
          <option value="">— Select registered client —</option>
          <?php foreach ($allUsers as $u): $sel = (($_POST['user_id'] ?? ($_GET['client_id'] ?? '')) === $u['id']) ? 'selected' : ''; ?>
          <option value="<?= $u['id'] ?>" <?= $sel ?>><?= htmlspecialchars($u['name']) ?> (<?= htmlspecialchars($u['email']) ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>

      <!-- Order Classification: Live Order vs Free Trial -->
      <div class="p-4 rounded-xl bg-[#141622] border border-amber-500/30 space-y-2">
        <label class="form-label font-bold text-amber-300 mb-0">Order Classification / Billing Tier <span class="text-red-400">*</span></label>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <label class="flex items-center gap-3 p-3 rounded-lg bg-[#0e1017] border border-dark-border cursor-pointer hover:border-gold transition-all">
            <input type="radio" name="order_type" value="live_order" <?= (($_POST['order_type'] ?? 'live_order') === 'live_order') ? 'checked' : '' ?> class="text-gold focus:ring-0">
            <div>
              <div class="font-bold text-white text-xs">⚡ Live Order (Paid)</div>
              <div class="text-[11px] text-gray-400">Normal billable production order.</div>
            </div>
          </label>
          <label class="flex items-center gap-3 p-3 rounded-lg bg-[#0e1017] border border-amber-500/40 cursor-pointer hover:border-gold transition-all">
            <input type="radio" name="order_type" value="free_trial" <?= (($_POST['order_type'] ?? '') === 'free_trial') ? 'checked' : '' ?> class="text-gold focus:ring-0">
            <div>
              <div class="font-bold text-amber-300 text-xs">🎁 Free Trial ($0.00)</div>
              <div class="text-[11px] text-gray-400">100% complimentary &bull; Zero charge.</div>
            </div>
          </label>
        </div>
      </div>

      <!-- Property Name -->
      <div>
        <label class="form-label">Property Name / Address <span class="text-red-400">*</span></label>
        <input type="text" name="property_name" class="form-input text-sm" placeholder="e.g. 104 Ocean View Drive, Malibu" value="<?= htmlspecialchars($_POST['property_name'] ?? '') ?>" required>
      </div>

      <!-- Service Type & Raw Count -->
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label class="form-label">Service Type <span class="text-red-400">*</span></label>
          <select name="service_type" class="form-select text-sm" required>
            <option value="">— Select service —</option>
            <?php
            $services = [
              'Virtual Staging',
              'HDR Photo Editing',
              'Floor Plans & 3D Tours',
              'Item Removal',
              'Virtual Twilight',
              'Day to Dusk',
              'Full Custom Package (Multiple Services)'
            ];
            foreach ($services as $svc): $sel = (($_POST['service_type'] ?? '') === $svc) ? 'selected' : ''; ?>
            <option value="<?= $svc ?>" <?= $sel ?>><?= $svc ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div>
          <label class="form-label">Number of Raw Images <span class="text-red-400">*</span></label>
          <input type="number" name="raw_images_count" min="1" max="1000" class="form-input text-sm" placeholder="e.g. 30" value="<?= htmlspecialchars($_POST['raw_images_count'] ?? '') ?>" required>
        </div>
      </div>

      <!-- Cloud Link -->
      <div>
        <label class="form-label">Client's Cloud Storage Link (Drive/Dropbox) <span class="text-red-400">*</span></label>
        <input type="url" name="cloud_link" class="form-input text-sm" placeholder="https://dropbox.com/... or Google Drive folder" value="<?= htmlspecialchars($_POST['cloud_link'] ?? '') ?>" required>
      </div>

      <!-- Notes -->
      <div>
        <label class="form-label">Instructions / Communication Notes</label>
        <textarea name="notes" rows="4" class="form-input resize-y text-sm" placeholder="e.g. Client requested flambient interior + twilight exterior. Received via email."><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
      </div>

      <div class="flex gap-4 pt-2">
        <button type="submit" class="btn-gold flex-1 py-3 text-sm font-bold shadow-glow">
          Create Audited Proxy Order
        </button>
        <a href="/admin/" class="btn-ghost flex-none py-3 px-6 text-sm">Cancel</a>
      </div>
    </form>
  </div>
</main>
</body>
</html>
