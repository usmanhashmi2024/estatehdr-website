<?php
/**
 * Estate HDR — AI Brain & Cognitive RAG Agent Control Center
 * 
 * Features:
 * - Real-Time RAG Knowledge Base Management (22+ Core Articles)
 * - Discord Live Webhook Integration & Instant Test Ping
 * - Multi-Provider AI Engine (Autonomous Neural Synthesizer, OpenAI, Groq, Anthropic)
 * - Self-Learning Memory Inbox (Real Visitor Questions Flagged for Learning)
 * - Live Interactive AI Playground / Test Sandbox
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/services/AiChatAgent.php';

use EstateHDR\Services\AiChatAgent;

requireAdmin();

$adminCurrentPage = 'ai-brain';
$pageTitle = 'AI Brain & RAG Chat Agent — Estate HDR';

$dataPath = defined('DATA_PATH') ? DATA_PATH : (dirname(__DIR__) . '/data/');
$brainDir = $dataPath . 'chat_brain/';
if (!is_dir($brainDir)) @mkdir($brainDir, 0755, true);

$feedbackMessage = '';
$feedbackType = 'success';

// ─── ACTION 1: SAVE AGENT & DISCORD SETTINGS ──────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_save_settings'])) {
    $currentSettings = AiChatAgent::getSettings();
    $newSettings = [
        'agent_name'            => trim($_POST['agent_name'] ?? 'Alice | Senior Retouching Director'),
        'provider'              => trim($_POST['provider'] ?? 'builtin'),
        'api_key'               => trim($_POST['api_key'] ?? ''),
        'model'                 => trim($_POST['model'] ?? 'gpt-4o-mini'),
        'enable_discord_alerts' => !empty($_POST['enable_discord_alerts']),
        'discord_webhook_url'   => trim($_POST['discord_webhook_url'] ?? ''),
        'auto_learn_enabled'    => !empty($_POST['auto_learn_enabled'])
    ];

    AiChatAgent::saveSettings($newSettings);

    // Also update discord_settings.json for global consistency
    $dFile = $dataPath . 'discord_settings.json';
    $dData = file_exists($dFile) ? (@json_decode(@file_get_contents($dFile), true) ?: []) : [];
    if (!empty($newSettings['discord_webhook_url'])) {
        $dData['webhook_url'] = $newSettings['discord_webhook_url'];
        $dData['enabled'] = true;
        $dData['notify_live_chat'] = true;
        $dData['notify_new_lead'] = true;
        @file_put_contents($dFile, json_encode($dData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    }

    $feedbackMessage = 'AI Agent and Discord Webhook settings saved successfully!';
    $feedbackType = 'success';
}

// ─── ACTION 2: TEST DISCORD WEBHOOK PING ───────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_test_discord'])) {
    $settings = AiChatAgent::getSettings();
    $webhook = trim($settings['discord_webhook_url'] ?? '');

    if (empty($webhook) || !filter_var($webhook, FILTER_VALIDATE_URL)) {
        $feedbackMessage = 'Discord Webhook URL is invalid or empty. Please enter a valid Discord webhook URL.';
        $feedbackType = 'error';
    } else {
        $testEmbed = [
            'title'       => "🧪 Estate HDR — Live Discord Webhook Test",
            'description' => "Your Discord notifications channel is **100% active and connected** to Estate HDR AI Concierge!",
            'color'       => 13215820, // Gold #C9A84C
            'fields'      => [
                ['name' => '🤖 AI Agent', 'value' => $settings['agent_name'] ?? 'Alice', 'inline' => true],
                ['name' => '🧠 Engine Provider', 'value' => strtoupper($settings['provider'] ?? 'Built-in Neural RAG'), 'inline' => true],
                ['name' => '🕒 Test Timestamp', 'value' => date('Y-m-d H:i:s T'), 'inline' => true],
                ['name' => '🛡️ Status', 'value' => "🟢 Ready to receive Live Chat Leads & Dossiers", 'inline' => false]
            ],
            'footer'      => ['text' => 'Estate HDR Brain Intelligence • Test Ping']
        ];

        $ch = curl_init($webhook);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode([
                'username'   => 'Estate HDR AI Concierge',
                'avatar_url' => 'https://estatehdr.com/assets/images/favicon.png',
                'embeds'     => [$testEmbed]
            ]),
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'User-Agent: EstateHDR-AiBrain/1.0'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 4,
            CURLOPT_SSL_VERIFYPEER => true
        ]);
        $res = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($code >= 200 && $code < 300) {
            $feedbackMessage = 'Discord test message dispatched successfully! Check your Discord channel.';
            $feedbackType = 'success';
        } else {
            $feedbackMessage = "Discord responded with HTTP code {$code}. Please verify the webhook URL.";
            $feedbackType = 'error';
        }
    }
}

// ─── ACTION 3: ADD / EDIT KNOWLEDGE ARTICLE ────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_save_article'])) {
    $id = trim($_POST['article_id'] ?? '');
    $category = trim($_POST['category'] ?? 'General Information');
    $title = trim($_POST['title'] ?? '');
    $keywordsRaw = trim($_POST['keywords'] ?? '');
    $content = trim($_POST['content'] ?? '');

    $keywords = array_values(array_filter(array_map('trim', explode(',', $keywordsRaw))));

    if (!empty($title) && !empty($content)) {
        AiChatAgent::saveKnowledgeArticle([
            'id'       => $id ?: ('kb_' . time() . '_' . substr(bin2hex(random_bytes(2)), 0, 4)),
            'category' => $category,
            'title'    => $title,
            'keywords' => $keywords,
            'content'  => $content
        ]);
        $feedbackMessage = "Knowledge article '{$title}' saved and synchronized to AI Brain!";
        $feedbackType = 'success';
    } else {
        $feedbackMessage = 'Title and Content are required fields.';
        $feedbackType = 'error';
    }
}

// ─── ACTION 4: DELETE KNOWLEDGE ARTICLE ────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_delete_article'])) {
    $delId = trim($_POST['delete_id'] ?? '');
    if (!empty($delId)) {
        AiChatAgent::deleteKnowledgeArticle($delId);
        $feedbackMessage = "Knowledge article deleted successfully.";
        $feedbackType = 'success';
    }
}

// ─── ACTION 5: DISMISS UNANSWERED QUERY ────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_dismiss_query'])) {
    $unansId = trim($_POST['unanswered_id'] ?? '');
    $unansFile = $brainDir . 'unanswered_queries.json';
    if (file_exists($unansFile)) {
        $items = @json_decode(@file_get_contents($unansFile), true) ?: [];
        $items = array_values(array_filter($items, fn($x) => ($x['id'] ?? '') !== $unansId));
        @file_put_contents($unansFile, json_encode($items, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        $feedbackMessage = 'Question dismissed from Learning Inbox.';
        $feedbackType = 'success';
    }
}

// ─── ACTION 6: SANDBOX QUERY TEST ──────────────────────────────────────
$sandboxQuery = '';
$sandboxResult = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_test_sandbox'])) {
    $sandboxQuery = trim($_POST['sandbox_query'] ?? '');
    if (!empty($sandboxQuery)) {
        $retrieval = AiChatAgent::retrieveKnowledge($sandboxQuery);
        $response = AiChatAgent::processMessage('V-ADMIN-SANDBOX', $sandboxQuery, [
            'name'  => 'Test Photographer',
            'email' => 'photographer@agency.com'
        ]);

        $sandboxResult = [
            'retrieval' => $retrieval,
            'response'  => $response
        ];
    }
}

// Load Current Data
$agentSettings = AiChatAgent::getSettings();
$articles = AiChatAgent::getKnowledgeBase();

// Load Unanswered Queries
$unansweredFile = $brainDir . 'unanswered_queries.json';
$unansweredQueries = file_exists($unansweredFile) ? (@json_decode(@file_get_contents($unansweredFile), true) ?: []) : [];

// Load Live Chat Stats
$chatsFile = $dataPath . 'live_chats.json';
$allChats = file_exists($chatsFile) ? (@json_decode(@file_get_contents($chatsFile), true) ?: []) : [];
$totalChatTurns = 0;
$totalLeadsCaptured = 0;
foreach ($allChats as $c) {
    $totalChatTurns += count($c['messages'] ?? []);
    if (!empty($c['visitor_email'])) {
        $totalLeadsCaptured++;
    }
}

// Group articles by category
$categorizedArticles = [];
foreach ($articles as $a) {
    $cat = $a['category'] ?? 'General Information';
    $categorizedArticles[$cat][] = $a;
}
ksort($categorizedArticles);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($pageTitle) ?></title>
  <link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;600;800&display=swap" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
    tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E',light:'#E5C05D'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#222230'}},fontFamily:{sans:['Inter','sans-serif'],mono:['JetBrains Mono','monospace']}}}};
  </script>
  <link rel="stylesheet" href="/assets/css/app.css">
</head>
<body class="bg-[#07070B] text-gray-200 font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-6 py-8 space-y-8">

  <!-- Header Banner -->
  <div class="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 pb-6 border-b border-gray-800">
    <div>
      <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/15 text-purple-300 border border-purple-500/30 text-xs font-black uppercase tracking-wider mb-2">
        <span class="w-2 h-2 rounded-full bg-purple-400 animate-ping"></span>
        <span>Cognitive RAG Intelligence Engine</span>
      </div>
      <h1 class="text-3xl font-black text-white flex items-center gap-3">
        <span>🧠 AI Brain &amp; Live Chat Concierge</span>
        <span class="px-2.5 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-400 text-xs font-mono font-bold uppercase">Active • 24/7</span>
      </h1>
      <p class="text-xs sm:text-sm text-gray-400 mt-1 max-w-3xl">
        Manage company knowledge retrieval (RAG), pre-chat lead gates, Discord transcript alerts, and review self-learning visitor queries.
      </p>
    </div>

    <!-- Quick Stats -->
    <div class="flex flex-wrap items-center gap-3">
      <div class="px-4 py-2.5 rounded-2xl bg-[#111118] border border-gray-800 flex items-center gap-3">
        <span class="text-2xl">📚</span>
        <div>
          <div class="text-[10px] text-gray-400 uppercase font-bold">Knowledge Chunks</div>
          <div class="text-lg font-black text-gold"><?= count($articles) ?> Articles</div>
        </div>
      </div>
      <div class="px-4 py-2.5 rounded-2xl bg-[#111118] border border-gray-800 flex items-center gap-3">
        <span class="text-2xl">👥</span>
        <div>
          <div class="text-[10px] text-gray-400 uppercase font-bold">Leads Captured</div>
          <div class="text-lg font-black text-emerald-400"><?= $totalLeadsCaptured ?> Leads</div>
        </div>
      </div>
      <div class="px-4 py-2.5 rounded-2xl bg-[#111118] border border-gray-800 flex items-center gap-3">
        <span class="text-2xl">💬</span>
        <div>
          <div class="text-[10px] text-gray-400 uppercase font-bold">Chat Exchanges</div>
          <div class="text-lg font-black text-white"><?= $totalChatTurns ?> Messages</div>
        </div>
      </div>
    </div>
  </div>

  <!-- Feedback Alert -->
  <?php if (!empty($feedbackMessage)): ?>
  <div class="p-4 rounded-2xl border <?= $feedbackType === 'success' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300' : 'bg-red-500/10 border-red-500/30 text-red-300' ?> flex items-center justify-between">
    <div class="flex items-center gap-2.5 text-xs font-bold">
      <span><?= $feedbackType === 'success' ? '✅' : '⚠️' ?></span>
      <span><?= htmlspecialchars($feedbackMessage) ?></span>
    </div>
    <button onclick="this.parentElement.remove()" class="text-gray-400 hover:text-white text-sm font-bold">&times;</button>
  </div>
  <?php endif; ?>

  <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
    
    <!-- ── LEFT COLUMN (1/3): AI CONFIGURATION & DISCORD SETTINGS ── -->
    <div class="space-y-6">
      
      <!-- Card: Engine Settings -->
      <div class="p-6 rounded-3xl bg-[#111118] border border-gray-800 shadow-xl space-y-5">
        <div class="flex items-center justify-between pb-3 border-b border-gray-800">
          <h3 class="text-base font-bold text-white flex items-center gap-2">
            <span>⚙️ AI Engine &amp; Discord Alerts</span>
          </h3>
          <span class="px-2 py-0.5 rounded bg-gold/15 text-gold text-[10px] font-black uppercase">Live Config</span>
        </div>

        <form method="POST" class="space-y-4">
          <input type="hidden" name="action_save_settings" value="1">

          <div>
            <label class="block text-xs font-bold text-gray-300 mb-1">Agent Persona Name</label>
            <input type="text" name="agent_name" value="<?= htmlspecialchars($agentSettings['agent_name'] ?? 'Alice | Senior Retouching Director') ?>" 
                   class="w-full bg-[#181824] border border-gray-700 rounded-xl px-3.5 py-2 text-xs text-white focus:border-gold focus:outline-none">
          </div>

          <div>
            <label class="block text-xs font-bold text-gray-300 mb-1">AI Intelligence Provider</label>
            <select name="provider" class="w-full bg-[#181824] border border-gray-700 rounded-xl px-3 py-2 text-xs text-white focus:border-gold focus:outline-none">
              <option value="builtin" <?= ($agentSettings['provider'] ?? '') === 'builtin' ? 'selected' : '' ?>>
                ⚡ Built-in Autonomous Neural Synthesizer (100% Uptime &bull; $0 API Costs)
              </option>
              <option value="openai" <?= ($agentSettings['provider'] ?? '') === 'openai' ? 'selected' : '' ?>>
                🤖 OpenAI (GPT-4o / GPT-4o-mini)
              </option>
              <option value="groq" <?= ($agentSettings['provider'] ?? '') === 'groq' ? 'selected' : '' ?>>
                ⚡ Groq Llama 3.3 70B (Ultra Fast)
              </option>
              <option value="anthropic" <?= ($agentSettings['provider'] ?? '') === 'anthropic' ? 'selected' : '' ?>>
                🧠 Anthropic Claude 3.5 Sonnet
              </option>
            </select>
          </div>

          <div>
            <label class="block text-xs font-bold text-gray-300 mb-1">External API Key (Optional)</label>
            <input type="password" name="api_key" value="<?= htmlspecialchars($agentSettings['api_key'] ?? '') ?>" placeholder="sk-... (Leave blank for built-in neural RAG)" 
                   class="w-full bg-[#181824] border border-gray-700 rounded-xl px-3.5 py-2 text-xs text-white font-mono placeholder-gray-500 focus:border-gold focus:outline-none">
          </div>

          <div>
            <label class="block text-xs font-bold text-gray-300 mb-1">Model Name</label>
            <input type="text" name="model" value="<?= htmlspecialchars($agentSettings['model'] ?? 'gpt-4o-mini') ?>" 
                   class="w-full bg-[#181824] border border-gray-700 rounded-xl px-3.5 py-2 text-xs text-white font-mono focus:border-gold focus:outline-none">
          </div>

          <div class="pt-2 border-t border-gray-800 space-y-3">
            <div class="flex items-center justify-between">
              <div>
                <div class="text-xs font-bold text-white">Discord Live Alerts</div>
                <div class="text-[10px] text-gray-400">Post new leads &amp; chat dossiers instantly</div>
              </div>
              <input type="checkbox" name="enable_discord_alerts" value="1" <?= !empty($agentSettings['enable_discord_alerts']) ? 'checked' : '' ?> 
                     class="w-4 h-4 accent-gold rounded">
            </div>

            <div>
              <label class="block text-xs font-bold text-gray-300 mb-1">Discord Webhook URL</label>
              <input type="url" name="discord_webhook_url" value="<?= htmlspecialchars($agentSettings['discord_webhook_url'] ?? '') ?>" placeholder="https://discord.com/api/webhooks/..." 
                     class="w-full bg-[#181824] border border-gray-700 rounded-xl px-3.5 py-2 text-xs text-white font-mono placeholder-gray-500 focus:border-gold focus:outline-none">
            </div>

            <div class="flex items-center justify-between">
              <div>
                <div class="text-xs font-bold text-white">Self-Learning Memory</div>
                <div class="text-[10px] text-gray-400">Capture novel questions to Learning Inbox</div>
              </div>
              <input type="checkbox" name="auto_learn_enabled" value="1" <?= !empty($agentSettings['auto_learn_enabled']) ? 'checked' : '' ?> 
                     class="w-4 h-4 accent-gold rounded">
            </div>
          </div>

          <div class="pt-3 flex gap-2">
            <button type="submit" class="flex-1 py-2.5 px-4 rounded-xl bg-gold hover:bg-amber-400 text-dark font-black text-xs uppercase tracking-wider shadow-glow transition-all">
              Save AI Settings
            </button>
          </div>
        </form>

        <!-- Discord Test Button -->
        <form method="POST" class="pt-2 border-t border-gray-800">
          <input type="hidden" name="action_test_discord" value="1">
          <button type="submit" class="w-full py-2 px-3 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/40 text-xs font-bold transition-all flex items-center justify-center gap-2">
            <span>🔔 Send Live Test Ping to Discord</span>
          </button>
        </form>
      </div>

      <!-- Card: Self-Learning Memory Inbox -->
      <div class="p-6 rounded-3xl bg-[#111118] border border-gray-800 shadow-xl space-y-4">
        <div class="flex items-center justify-between pb-3 border-b border-gray-800">
          <h3 class="text-base font-bold text-white flex items-center gap-2">
            <span>🧠 Learning Inbox</span>
          </h3>
          <span class="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 text-[10px] font-mono font-black"><?= count($unansweredQueries) ?> Pending</span>
        </div>

        <p class="text-xs text-gray-400 leading-relaxed">
          Questions asked by real visitors that had low RAG confidence or unique terminology. Turn them into permanent knowledge with one click!
        </p>

        <?php if (empty($unansweredQueries)): ?>
        <div class="p-6 rounded-2xl bg-dark/60 border border-dark-border text-center">
          <span class="text-2xl block mb-1">🎉</span>
          <div class="text-xs font-bold text-gray-300">All Visitor Queries Understood</div>
          <div class="text-[11px] text-gray-500 mt-0.5">The AI Brain successfully mapped all recent visitor inquiries.</div>
        </div>
        <?php else: ?>
        <div class="space-y-3 max-h-[360px] overflow-y-auto pr-1">
          <?php foreach ($unansweredQueries as $uq): ?>
          <div class="p-3.5 rounded-2xl bg-[#161622] border border-gray-800 space-y-2">
            <div class="text-xs text-white font-medium">"<?= htmlspecialchars($uq['query'] ?? '') ?>"</div>
            <div class="flex items-center justify-between text-[10px] text-gray-400 font-mono">
              <span>Asked: <?= htmlspecialchars($uq['hits'] ?? 1) ?>x &middot; <?= substr($uq['last_asked'] ?? '', 0, 10) ?></span>
              <div class="flex items-center gap-1.5">
                <button type="button" onclick="prefillArticleForm(<?= htmlspecialchars(json_encode($uq['query'] ?? '')) ?>)" class="text-gold font-bold hover:underline">
                  + Add to Brain
                </button>
                <form method="POST" class="inline" onsubmit="return confirm('Dismiss this question?')">
                  <input type="hidden" name="action_dismiss_query" value="1">
                  <input type="hidden" name="unanswered_id" value="<?= htmlspecialchars($uq['id'] ?? '') ?>">
                  <button type="submit" class="text-gray-500 hover:text-red-400 font-bold ml-1">&times;</button>
                </form>
              </div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>

    </div>

    <!-- ── RIGHT COLUMN (2/3): KNOWLEDGE BASE MANAGER & PLAYGROUND ── -->
    <div class="lg:col-span-2 space-y-8">
      
      <!-- Interactive AI Test Sandbox -->
      <div class="p-6 rounded-3xl bg-gradient-to-r from-[#141422] via-[#111118] to-[#141422] border-2 border-gold/30 shadow-2xl space-y-4">
        <div class="flex items-center justify-between pb-3 border-b border-gray-800">
          <div>
            <h3 class="text-lg font-black text-white flex items-center gap-2">
              <span>🎯 Live AI Playground &amp; Knowledge Tester</span>
            </h3>
            <p class="text-xs text-gray-400 mt-0.5">Test any question to see how the RAG Brain retrieves documents and synthesizes human responses.</p>
          </div>
          <span class="px-3 py-1 rounded-xl bg-gold/20 text-gold border border-gold/40 text-xs font-mono font-black">Interactive Sandbox</span>
        </div>

        <form method="POST" class="space-y-3">
          <input type="hidden" name="action_test_sandbox" value="1">
          <div class="flex gap-2">
            <input type="text" name="sandbox_query" value="<?= htmlspecialchars($sandboxQuery ?: 'How much for 35 photos with Sony brackets by tomorrow morning?') ?>" 
                   placeholder="e.g. Can you do virtual staging and flambient blending?" 
                   class="flex-1 bg-[#181824] border border-gray-700 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-500 focus:border-gold focus:outline-none">
            <button type="submit" class="py-2.5 px-6 rounded-xl bg-gold hover:bg-amber-400 text-dark font-black text-xs uppercase tracking-wider shadow-glow transition-all flex items-center gap-2 flex-shrink-0">
              <span>Test AI Brain</span>
              <span>&rarr;</span>
            </button>
          </div>
        </form>

        <?php if ($sandboxResult !== null): ?>
        <div class="mt-4 p-4 rounded-2xl bg-[#0B0B12] border border-gray-800 space-y-3">
          <div class="flex items-center justify-between text-xs">
            <div class="font-bold text-white flex items-center gap-2">
              <span>Retrieved Article:</span>
              <span class="text-gold font-mono"><?= htmlspecialchars($sandboxResult['retrieval']['best_match']['title'] ?? 'No direct match') ?></span>
            </div>
            <div class="font-mono text-[11px] text-emerald-400">
              Confidence Score: <?= $sandboxResult['retrieval']['confidence'] ?>
            </div>
          </div>

          <div class="p-4 rounded-xl bg-[#141422] border border-gray-700 text-xs text-gray-200 leading-relaxed">
            <div class="text-[10px] font-bold text-gold uppercase tracking-wider mb-2">● Alice's Live Response:</div>
            <?= $sandboxResult['response']['reply'] ?? '' ?>
          </div>
        </div>
        <?php endif; ?>
      </div>

      <!-- Knowledge Base Articles Accordion / Manager -->
      <div class="p-6 rounded-3xl bg-[#111118] border border-gray-800 shadow-xl space-y-6">
        <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-gray-800">
          <div>
            <h3 class="text-xl font-black text-white flex items-center gap-2">
              <span>📚 Active Company Knowledge Chunks (<?= count($articles) ?>)</span>
            </h3>
            <p class="text-xs text-gray-400 mt-0.5">The exact verified facts, pricing tables, technical specifications, and policies indexed by the RAG Engine.</p>
          </div>
          <button type="button" onclick="openAddArticleModal()" class="py-2 px-4 rounded-xl bg-gold hover:bg-amber-400 text-dark font-bold text-xs shadow-glow transition-all flex items-center gap-1.5 flex-shrink-0">
            <span>+ Add New Article</span>
          </button>
        </div>

        <div class="space-y-6">
          <?php foreach ($categorizedArticles as $category => $catArticles): ?>
          <div class="space-y-3">
            <div class="flex items-center gap-2 text-xs font-black text-gold uppercase tracking-wider">
              <span>📁 <?= htmlspecialchars($category) ?></span>
              <span class="text-gray-500 font-normal font-mono">(<?= count($catArticles) ?>)</span>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
              <?php foreach ($catArticles as $art): ?>
              <div class="p-4 rounded-2xl bg-[#161622] border border-gray-800 hover:border-gold/50 transition-colors flex flex-col justify-between space-y-3">
                <div>
                  <div class="flex items-start justify-between gap-2 mb-1">
                    <h4 class="text-xs font-bold text-white leading-snug"><?= htmlspecialchars($art['title'] ?? '') ?></h4>
                    <span class="font-mono text-[9px] px-1.5 py-0.5 rounded bg-dark/60 text-gray-400 flex-shrink-0"><?= htmlspecialchars($art['id'] ?? '') ?></span>
                  </div>
                  <p class="text-[11px] text-gray-400 line-clamp-3 leading-relaxed"><?= htmlspecialchars($art['content'] ?? '') ?></p>
                </div>

                <div class="pt-2 border-t border-gray-800/80 flex items-center justify-between text-[10px]">
                  <span class="text-gray-500"><?= count($art['keywords'] ?? []) ?> trigger keywords</span>
                  <div class="flex items-center gap-2">
                    <button type="button" onclick='editArticle(<?= htmlspecialchars(json_encode($art)) ?>)' class="text-gold font-bold hover:underline">
                      Edit
                    </button>
                    <form method="POST" class="inline" onsubmit="return confirm('Are you sure you want to delete this article?')">
                      <input type="hidden" name="action_delete_article" value="1">
                      <input type="hidden" name="delete_id" value="<?= htmlspecialchars($art['id'] ?? '') ?>">
                      <button type="submit" class="text-red-400 hover:underline">Delete</button>
                    </form>
                  </div>
                </div>
              </div>
              <?php endforeach; ?>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

    </div>

  </div>

</main>

<!-- ── MODAL: ADD / EDIT ARTICLE ──────────────────────────────────── -->
<div id="articleModal" class="hidden fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
  <div class="w-full max-w-2xl rounded-3xl bg-[#12121C] border-2 border-gold/40 shadow-2xl p-6 space-y-4 max-h-[90vh] overflow-y-auto">
    <div class="flex items-center justify-between pb-3 border-b border-gray-800">
      <h3 id="modalTitle" class="text-lg font-black text-white">Add Knowledge Article</h3>
      <button onclick="closeArticleModal()" class="w-8 h-8 rounded-full bg-white/5 hover:bg-white/15 text-gray-300 hover:text-white flex items-center justify-center text-sm font-bold">&times;</button>
    </div>

    <form method="POST" class="space-y-4">
      <input type="hidden" name="action_save_article" value="1">
      <input type="hidden" id="formArticleId" name="article_id" value="">

      <div>
        <label class="block text-xs font-bold text-gray-300 mb-1">Category</label>
        <input type="text" id="formCategory" name="category" required placeholder="e.g. Services & Technique, Pricing, Turnaround" 
               class="w-full bg-[#181824] border border-gray-700 rounded-xl px-3.5 py-2 text-xs text-white focus:border-gold focus:outline-none">
      </div>

      <div>
        <label class="block text-xs font-bold text-gray-300 mb-1">Article Title</label>
        <input type="text" id="formTitle" name="title" required placeholder="e.g. Drone Video Editing & Social Reels" 
               class="w-full bg-[#181824] border border-gray-700 rounded-xl px-3.5 py-2 text-xs text-white focus:border-gold focus:outline-none">
      </div>

      <div>
        <label class="block text-xs font-bold text-gray-300 mb-1">Trigger Keywords (Comma separated)</label>
        <input type="text" id="formKeywords" name="keywords" required placeholder="e.g. drone video, aerial, walkthrough, reels, tiktok" 
               class="w-full bg-[#181824] border border-gray-700 rounded-xl px-3.5 py-2 text-xs text-white focus:border-gold focus:outline-none">
      </div>

      <div>
        <label class="block text-xs font-bold text-gray-300 mb-1">Detailed Content (Facts &amp; Knowledge)</label>
        <textarea id="formContent" name="content" rows="6" required placeholder="Enter full accurate facts and explanations that the AI should use to answer client queries..." 
                  class="w-full bg-[#181824] border border-gray-700 rounded-xl p-3.5 text-xs text-white focus:border-gold focus:outline-none leading-relaxed"></textarea>
      </div>

      <div class="pt-3 flex gap-3 justify-end">
        <button type="button" onclick="closeArticleModal()" class="py-2.5 px-5 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-300 font-bold text-xs transition-all">Cancel</button>
        <button type="submit" class="py-2.5 px-6 rounded-xl bg-gold hover:bg-amber-400 text-dark font-black text-xs uppercase tracking-wider shadow-glow transition-all">Save to Brain</button>
      </div>
    </form>
  </div>
</div>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
function openAddArticleModal() {
  document.getElementById('modalTitle').innerText = 'Add Knowledge Article';
  document.getElementById('formArticleId').value = '';
  document.getElementById('formCategory').value = 'Services & Photography';
  document.getElementById('formTitle').value = '';
  document.getElementById('formKeywords').value = '';
  document.getElementById('formContent').value = '';
  document.getElementById('articleModal').classList.remove('hidden');
}

function closeArticleModal() {
  document.getElementById('articleModal').classList.add('hidden');
}

function editArticle(art) {
  document.getElementById('modalTitle').innerText = 'Edit Knowledge Article';
  document.getElementById('formArticleId').value = art.id || '';
  document.getElementById('formCategory').value = art.category || '';
  document.getElementById('formTitle').value = art.title || '';
  document.getElementById('formKeywords').value = (art.keywords || []).join(', ');
  document.getElementById('formContent').value = art.content || '';
  document.getElementById('articleModal').classList.remove('hidden');
}

function prefillArticleForm(query) {
  openAddArticleModal();
  document.getElementById('formTitle').value = 'Answer: ' + query;
  document.getElementById('formKeywords').value = query.toLowerCase() + ', ' + query.split(' ').slice(0, 3).join(' ');
  document.getElementById('formContent').focus();
}
</script>

</body>
</html>
