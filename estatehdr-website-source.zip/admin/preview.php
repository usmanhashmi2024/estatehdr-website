<?php
/**
 * Estate HDR — Live Frontend Preview Engine (Opens in Dedicated New Browser Tab)
 * URL: /admin/preview.php?type=post&slug=...
 * Supports unsaved real-time localStorage hydration, desktop/mobile frames, and 1:1 public theme replication.
 */
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
requireSeoManagerOrAdmin();

$type = trim($_GET['type'] ?? 'post');
$slug = trim($_GET['slug'] ?? '');

// Fallback to database post if accessible
$fallbackPost = null;
if (!empty($slug)) {
    $all = getAllBlogsAdmin();
    foreach ($all as $b) {
        if ($b['slug'] === $slug || $b['id'] === $slug) {
            $fallbackPost = $b;
            break;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title id="previewPageTitle">Live Preview — Estate HDR</title>
<meta name="robots" content="noindex,nofollow">

<!-- Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">

<!-- Fonts & Tailwind -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
tailwind.config = {
  theme: {
    extend: {
      colors: {
        gold: { DEFAULT: '#C9A84C', light: '#E8C97B', dark: '#9A7A2E' },
        dark: { DEFAULT: '#0A0A0F', card: '#111118', border: '#1E1E2E' },
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        display: ['Playfair Display', 'serif'],
      },
    }
  }
};
</script>
<link rel="stylesheet" href="/assets/css/bundle.css?v=<?= file_exists(ROOT_PATH . '/assets/css/bundle.css') ? filemtime(ROOT_PATH . '/assets/css/bundle.css') : time() ?>">
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<style nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
/* ── Estate HDR Preview Typography & Layout Engine ─────────────────── */
#articleBodyContent {
  font-family: 'Inter', system-ui, -apple-system, sans-serif;
  color: #E2E8F0;
  line-height: 1.65;
}

/* Tight, clean paragraph and typography styling matching editorial standard */
#articleBodyContent p, #articleBodyContent div:not(.grid):not(.glass-card):not(.schema-embed-badge) {
  margin-top: 0 !important;
  margin-bottom: 0.65rem !important;
  line-height: 1.65 !important;
  color: #E2E8F0 !important;
}

#articleBodyContent h1 {
  font-size: 2.25rem !important;
  font-weight: 900 !important;
  color: #FFFFFF !important;
  line-height: 1.25 !important;
  margin-top: 2rem !important;
  margin-bottom: 0.75rem !important;
}

#articleBodyContent h2:not([style*="color"]) {
  font-size: 1.75rem !important;
  font-weight: 800 !important;
  color: #F5D77F !important; /* Signature Gold */
  line-height: 1.3 !important;
  margin-top: 2rem !important;
  margin-bottom: 0.65rem !important;
  border-bottom: 1px solid rgba(245, 215, 127, 0.2) !important;
  padding-bottom: 0.35rem !important;
}

#articleBodyContent h3:not([style*="color"]) {
  font-size: 1.35rem !important;
  font-weight: 700 !important;
  color: #C9A84C !important; /* Amber / Gold */
  line-height: 1.35 !important;
  margin-top: 1.5rem !important;
  margin-bottom: 0.5rem !important;
}

#articleBodyContent h4:not([style*="color"]) {
  font-size: 1.15rem !important;
  font-weight: 700 !important;
  color: #E2E8F0 !important;
  margin-top: 1.25rem !important;
  margin-bottom: 0.4rem !important;
}

/* Respect explicit user-selected inline heading / text colors */
#articleBodyContent :is(h1, h2, h3, h4, h5, h6, span, p)[style*="color"] {
  color: inherit !important;
}

/* Complete Responsive Table Styling */
#articleBodyContent table {
  width: 100% !important;
  border-collapse: collapse !important;
  margin: 1.5rem 0 !important;
  border: 1px solid #2D2D3F !important;
  border-radius: 0.75rem !important;
  overflow: hidden !important;
  background: #0E0E16 !important;
  color: #F1F5F9 !important;
  display: table !important;
}

#articleBodyContent th {
  background: #161622 !important;
  color: #C9A84C !important;
  font-weight: 700 !important;
  text-transform: uppercase !important;
  font-size: 0.75rem !important;
  letter-spacing: 0.05em !important;
  border: 1px solid #2D2D3F !important;
  padding: 0.75rem 1rem !important;
  text-align: left !important;
}

#articleBodyContent td {
  border: 1px solid #2D2D3F !important;
  padding: 0.75rem 1rem !important;
  font-size: 0.875rem !important;
  color: #F1F5F9 !important;
  background: #0E0E16 !important;
  line-height: 1.5 !important;
  vertical-align: top !important;
}

#articleBodyContent tr:nth-child(even) td {
  background: #14141F !important;
}

#articleBodyContent tr:hover td {
  background: rgba(201, 168, 76, 0.05) !important;
}

#articleBodyContent ul {
  list-style-type: disc !important;
  margin-left: 1.5rem !important;
  margin-bottom: 0.85rem !important;
  color: #CBD5E1 !important;
}

#articleBodyContent ol {
  list-style-type: decimal !important;
  margin-left: 1.5rem !important;
  margin-bottom: 0.85rem !important;
  color: #CBD5E1 !important;
}

#articleBodyContent li {
  margin-bottom: 0.35rem !important;
}

#articleBodyContent blockquote {
  border-left: 4px solid #C9A84C !important;
  background: rgba(22, 22, 34, 0.4) !important;
  padding: 1rem 1.25rem !important;
  margin: 1.25rem 0 !important;
  font-style: italic !important;
  color: #CBD5E1 !important;
  border-radius: 0 0.75rem 0.75rem 0 !important;
}

#articleBodyContent img {
  max-width: 100% !important;
  height: auto !important;
  border-radius: 1rem !important;
  margin: 1.25rem auto !important;
  display: block !important;
}
</style>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col pt-32">

<!-- ── STICKY TOP LIVE PREVIEW CONTROL BAR ───────────────────────── -->
<div class="fixed top-0 left-0 right-0 z-[9999] bg-[#111118]/95 backdrop-blur-md border-b border-amber-500/40 shadow-2xl px-6 py-3">
  <div class="max-w-[1850px] mx-auto flex flex-wrap items-center justify-between gap-4">
    
    <!-- Left: Status Indicator -->
    <div class="flex items-center gap-3">
      <span class="flex h-3 w-3 relative">
        <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
        <span class="relative inline-flex rounded-full h-3 w-3 bg-amber-500"></span>
      </span>
      <div>
        <div class="text-xs font-black uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
          <span>👁️ Live Preview Mode</span>
          <span class="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-mono font-bold">New Tab Active</span>
        </div>
        <div class="text-[11px] text-gray-400">Unsaved editor changes reflected live. Not visible to the public.</div>
      </div>
    </div>

    <!-- Center: Device Switcher -->
    <div class="flex items-center gap-1.5 bg-dark p-1 rounded-xl border border-[#1E1E2E] text-xs">
      <button type="button" onclick="switchDevice('desktop')" id="devBtnDesk" class="px-3 py-1.5 rounded-lg font-bold bg-gold text-dark transition-all flex items-center gap-1.5">
        <span>🖥️</span> <span>Desktop</span>
      </button>
      <button type="button" onclick="switchDevice('tablet')" id="devBtnTab" class="px-3 py-1.5 rounded-lg font-bold text-gray-400 hover:text-white transition-all flex items-center gap-1.5">
        <span>📱</span> <span>Tablet</span>
      </button>
      <button type="button" onclick="switchDevice('mobile')" id="devBtnMob" class="px-3 py-1.5 rounded-lg font-bold text-gray-400 hover:text-white transition-all flex items-center gap-1.5">
        <span>📲</span> <span>Mobile</span>
      </button>
    </div>

    <!-- Right: Actions -->
    <div class="flex items-center gap-3">
      <button type="button" onclick="reloadFromStorage()" class="px-3 py-1.5 rounded-xl bg-dark-card border border-[#2A2A3A] hover:border-gold text-xs font-bold text-gray-300 hover:text-white inline-flex items-center gap-1.5 transition-all">
        <span>🔄</span> <span>Sync with Editor</span>
      </button>
      <button type="button" onclick="window.close()" class="px-3 py-1.5 rounded-xl bg-red-500/20 hover:bg-red-500 text-red-300 hover:text-white text-xs font-bold transition-all inline-flex items-center gap-1">
        <span>✕</span> <span>Close Tab</span>
      </button>
    </div>

  </div>
</div>

<!-- ── SIMULATED PUBLIC HEADER ──────────────────────────────────── -->
<div class="fixed top-[61px] left-0 right-0 z-40 bg-dark/90 backdrop-blur-md border-b border-dark-border/60">
  <div class="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
    <a href="/" target="_blank" class="flex items-center gap-2">
      <img src="/assets/images/logo.png" alt="Estate HDR" class="h-10 w-auto object-contain">
    </a>
    <div class="flex items-center gap-4 text-xs text-gray-300 font-bold">
      <span>Services</span>
      <span>Pricing</span>
      <span>Portfolio</span>
      <span class="text-gold">Blog</span>
      <span>Contact</span>
    </div>
  </div>
</div>

<!-- ── PREVIEW WRAPPER CONTAINER (Allows Desktop/Tablet/Mobile Resizing) ── -->
<div class="flex-1 flex justify-center w-full px-4 pb-16">
  <div id="previewFrame" class="w-full max-w-7xl transition-all duration-300">

    <!-- Hero Article Header -->
    <article class="max-w-4xl mx-auto py-8 space-y-6">
      <!-- Breadcrumb & Category -->
      <div class="flex items-center gap-3 text-xs">
        <span class="text-gray-400">Blog</span>
        <span class="text-gray-600">/</span>
        <span id="articleCategoryBadge" class="px-3 py-1 rounded-full bg-gold/10 border border-gold/30 text-gold font-bold uppercase tracking-wider text-[10px]">
          <?= htmlspecialchars($fallbackPost['category'] ?? 'HDR Photo Editing') ?>
        </span>
      </div>

      <!-- Main H1 Title -->
      <h1 id="articleMainTitle" class="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight">
        <?= htmlspecialchars($fallbackPost['title'] ?? 'Live Article Preview Title') ?>
      </h1>

      <!-- Author Bar -->
      <div class="flex items-center justify-between border-y border-dark-border py-4 text-xs text-gray-400">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-full bg-gradient-to-br from-gold to-amber-600 text-dark font-black flex items-center justify-center text-sm shadow-md">
            E
          </div>
          <div>
            <div id="articleAuthorName" class="font-bold text-white"><?= htmlspecialchars($fallbackPost['author'] ?? 'Estate HDR Team') ?></div>
            <div class="text-gray-500">Real Estate Photography Post-Production Specialist</div>
          </div>
        </div>
        <div class="font-mono text-gray-400">
          <?= date('M j, Y') ?> • 5 min read
        </div>
      </div>

      <!-- Natural Auto-Sizing Featured Image (Never crops 1200x628 or any aspect ratio sides) -->
      <div id="articleCoverContainer" class="<?= empty($fallbackPost['featured_image']) ? 'hidden' : '' ?> rounded-2xl sm:rounded-3xl overflow-hidden border border-dark-border shadow-2xl bg-dark-card/40 flex items-center justify-center p-1 sm:p-2">
        <img id="articleCoverImg" src="<?= htmlspecialchars($fallbackPost['featured_image'] ?? '') ?>" 
             alt="Featured Cover Preview" class="w-full h-auto max-h-[650px] object-contain rounded-xl sm:rounded-2xl block mx-auto">
      </div>

      <!-- Article Excerpt Box -->
      <div id="articleExcerptBox" class="p-4 rounded-2xl bg-dark-card border border-dark-border text-sm text-gray-300 italic">
        <span class="text-gold font-bold mr-1">Summary:</span>
        <span id="articleExcerptText"><?= htmlspecialchars($fallbackPost['excerpt'] ?? 'Article excerpt and preview summary...') ?></span>
      </div>

      <!-- Article Body HTML -->
      <div id="articleBodyContent" class="pt-4 text-gray-200">
        <?= $fallbackPost['content'] ?? '<p>Write your article in the admin editor and click Live Preview to view it here live in a new tab.</p>' ?>
      </div>

      <!-- Tags Bar -->
      <div id="articleTagsContainer" class="pt-8 border-t border-dark-border flex flex-wrap items-center gap-2">
        <span class="text-xs text-gray-400 font-bold uppercase tracking-wider mr-2">Tags:</span>
        <!-- Dynamic Tag Pills injected via JS -->
      </div>
    </article>

  </div>
</div>

<!-- ── PREVIEW DATA HYDRATION ENGINE ────────────────────────────── -->
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
function applyPreviewData(data) {
  if (!data) return;
  if (data.title) {
    document.getElementById('articleMainTitle').textContent = data.title;
    document.getElementById('previewPageTitle').textContent = `Preview: ${data.title} — Estate HDR`;
  }
  if (data.category) {
    document.getElementById('articleCategoryBadge').textContent = data.category;
  }
  if (data.author) {
    document.getElementById('articleAuthorName').textContent = data.author;
  }
  
  // Auto-sizing Featured Cover Image — hide if none specified, never inject demo images
  const coverContainer = document.getElementById('articleCoverContainer');
  const coverImg = document.getElementById('articleCoverImg');
  if (data.coverUrl && data.coverUrl.trim() !== '') {
    coverImg.src = data.coverUrl;
    coverContainer.classList.remove('hidden');
  } else {
    coverImg.src = '';
    coverContainer.classList.add('hidden');
  }

  if (data.excerpt) {
    document.getElementById('articleExcerptText').textContent = data.excerpt;
    document.getElementById('articleExcerptBox').classList.remove('hidden');
  } else {
    document.getElementById('articleExcerptBox').classList.add('hidden');
  }
  if (data.content !== undefined) {
    // Clean excessive empty paragraphs to keep tight editorial spacing
    const cleaned = data.content.replace(/<p>\s*(<br\s*\/?>|&nbsp;|\s)*<\/p>/gi, '');
    document.getElementById('articleBodyContent').innerHTML = cleaned || '<p>No content written yet.</p>';
  }
  if (data.tags) {
    const container = document.getElementById('articleTagsContainer');
    const tagList = data.tags.split(',').map(t => t.trim()).filter(Boolean);
    container.innerHTML = '<span class="text-xs text-gray-400 font-bold uppercase tracking-wider mr-2">Tags:</span>';
    tagList.forEach(t => {
      const badge = document.createElement('span');
      badge.className = 'px-3 py-1 rounded-lg bg-[#161622] text-gold border border-gold/30 text-xs font-semibold';
      badge.textContent = '#' + t;
      container.appendChild(badge);
    });
  }
}

function reloadFromStorage() {
  try {
    const raw = localStorage.getItem('estatehdr_preview_data') || sessionStorage.getItem('estatehdr_preview_data');
    if (!raw) return;
    const data = JSON.parse(raw);
    applyPreviewData(data);
  } catch(e) {
    console.error('Error hydrating preview data from storage:', e);
  }
}

function switchDevice(dev) {
  const frame = document.getElementById('previewFrame');
  const btnD = document.getElementById('devBtnDesk');
  const btnT = document.getElementById('devBtnTab');
  const btnM = document.getElementById('devBtnMob');

  btnD.className = `px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${dev === 'desktop' ? 'bg-gold text-dark shadow-sm' : 'text-gray-400 hover:text-white'}`;
  btnT.className = `px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${dev === 'tablet' ? 'bg-gold text-dark shadow-sm' : 'text-gray-400 hover:text-white'}`;
  btnM.className = `px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${dev === 'mobile' ? 'bg-gold text-dark shadow-sm' : 'text-gray-400 hover:text-white'}`;

  if (dev === 'mobile') {
    frame.className = 'w-[390px] max-w-full bg-[#0E0E16] border-4 border-[#2A2A3A] rounded-[2.5rem] p-6 shadow-2xl transition-all duration-300';
  } else if (dev === 'tablet') {
    frame.className = 'w-[768px] max-w-full bg-[#0E0E16] border-2 border-[#2A2A3A] rounded-3xl p-8 shadow-2xl transition-all duration-300';
  } else {
    frame.className = 'w-full max-w-7xl transition-all duration-300';
  }
}

// Automatically hydrate preview on initial load and listen for updates
window.addEventListener('DOMContentLoaded', reloadFromStorage);
window.addEventListener('storage', (e) => {
  if (e.key === 'estatehdr_preview_data') {
    reloadFromStorage();
  }
});
window.addEventListener('message', (e) => {
  if (e.data && e.data.type === 'ESTATE_HDR_PREVIEW' && e.data.data) {
    applyPreviewData(e.data.data);
  }
});
</script>

</body>
</html>
