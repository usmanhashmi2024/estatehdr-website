<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/saas-db.php';
require_once __DIR__ . '/../includes/services/AiQualityService.php';
require_once __DIR__ . '/../includes/services/StyleConsistencyService.php';
requireAdmin();

$currentAdmin = currentAdminUser();
$adminRoles   = getAdminRoles();
$editorId     = $currentAdmin['id']   ?? 'adm-5';
$editorName   = $currentAdmin['name'] ?? 'Photo Editor';
$orderId      = trim($_GET['id'] ?? '');

$order = getSaaSOrderById($orderId);
if (!$order) {
    http_response_code(404);
    die('<h2 style="color:white;font-family:sans-serif;padding:40px">Order not found.</h2>');
}

// ── 1. POST: Start / Lock Job (transitions status to in_process) ─────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_start_job'])) {
    verifyCsrf();
    $result = lockJobForEditor($orderId, $editorId, $editorName);
    if ($result['success']) {
        setFlash('success', "Job #$orderId started! Status is now IN PROCESS. You can submit your finished files below.");
    } else {
        setFlash('error', "Cannot start job: already locked by " . ($result['locked_by_name'] ?? 'another editor') . ".");
    }
    header("Location: /admin/editor-order.php?id=" . urlencode($orderId));
    exit;
}

// ── 2. POST: Submit for QA (first-time OR after revision) ───────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_submit_qa'])) {
    verifyCsrf();
    $outputPath        = trim($_POST['output_path'] ?? '');
    $isRevisionResubmit= ($_POST['is_revision'] ?? '0') === '1';
    $finalImageCount   = (int)($_POST['final_image_count'] ?? 0);

    if (empty($outputPath)) {
        setFlash('error', 'Please provide the final output storage path before submitting.');
        header("Location: /admin/editor-order.php?id=" . urlencode($orderId));
        exit;
    }
    if ($finalImageCount < 1) {
        $finalImageCount = (int)($order['photo_count'] ?? 10);
    }

    $ok = submitJobForQA($orderId, $editorId, $editorName, $outputPath, $isRevisionResubmit, $finalImageCount);
    if ($ok) {
        $msg = $isRevisionResubmit
            ? 'Revision corrections submitted successfully! Team Lead will review your fix.'
            : 'Job submitted to Team Lead for QA Review!';
        setFlash('success', $msg);
    } else {
        setFlash('error', 'Submission failed. Please try again.');
    }
    header("Location: /admin/editor-dashboard.php");
    exit;
}

// Reload fresh order after any POST
$order       = getSaaSOrderById($orderId);
$maskedOrder = maskOrderForRole($order, $adminRoles);

$isLocked   = !empty($order['locked_by_id']);
$lockedByMe = $isLocked && ($order['locked_by_id'] === $editorId);
$lockedBySomeoneElse = $isLocked && !$lockedByMe;

$isRevisionRequired = ($order['status'] === 'revision_required');
$revisionsList      = $order['revisions'] ?? [];
$lastRevision       = !empty($revisionsList) ? end($revisionsList) : null;

$isAssignedEditor   = ($order['assigned_editor_id'] ?? '') === $editorId || ($order['assigned_editor_id'] ?? '') === ($currentAdmin['id'] ?? '');
$isPrivilegedUser   = in_array('owner', $adminRoles) || in_array('manager', $adminRoles) || in_array('super_admin', $adminRoles);

// Editing permissions
$isInProcess        = ($order['status'] === 'in_process');
$canStartJob        = in_array($order['status'], ['assigned_editor', 'new', 'received', 'assigned_tl']) && !$lockedBySomeoneElse;
$canSubmitFirst     = $isInProcess && ($lockedByMe || $isAssignedEditor || $isPrivilegedUser);
$canSubmitRevision  = $isRevisionRequired && ($isAssignedEditor || $isPrivilegedUser || $lockedByMe) && !$lockedBySomeoneElse;

// AI Copilot & Style DNA Analysis
$aiAudit = AiQualityService::auditImageQuality($order['id'] ?? 'preview');
$clientDna = StyleConsistencyService::evaluateConsistency($order['client_id'] ?? 'default');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Job <?= htmlspecialchars($maskedOrder['id']) ?> — Editor Workspace</title>
<meta name="robots" content="noindex,nofollow">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">tailwind.config={theme:{extend:{colors:{gold:{DEFAULT:'#C9A84C',dark:'#9A7A2E'},dark:{DEFAULT:'#0A0A0F',card:'#111118',border:'#1E1E2E'}}}}}</script>
<link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
<script src="/assets/js/theme.js"></script>
</head>
<body class="bg-dark text-white font-sans antialiased min-h-screen flex flex-col">

<?php require_once __DIR__ . '/../includes/admin-header.php'; ?>

<main class="flex-1 max-w-[1850px] w-full mx-auto px-4 sm:px-8 py-8 space-y-6">
  <?= renderFlash() ?>

  <!-- ── TOP BAR: BACK & STATUS ────────────────────────────────────── -->
  <div class="flex items-center justify-between gap-4">
    <a href="/admin/editor-dashboard.php" class="btn-ghost py-2 px-4 text-xs font-bold inline-flex items-center gap-2 border border-dark-border hover:border-gold rounded-xl">
      <span>←</span> <span>Back to My Workspace</span>
    </a>
    <div class="flex items-center gap-3">
      <?php if ($isInProcess && ($lockedByMe || $isAssignedEditor)): ?>
        <span class="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-blue-500/20 border border-blue-500/50 text-blue-400 text-xs font-black shadow-glow">
          <span class="w-2.5 h-2.5 rounded-full bg-blue-400 animate-ping"></span> IN PROCESS — YOU ARE EDITING
        </span>
      <?php elseif ($lockedBySomeoneElse): ?>
        <span class="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-red-500/20 border border-red-500/50 text-red-400 text-xs font-black">
          🔒 Locked by <?= htmlspecialchars($order['locked_by_name']) ?>
        </span>
      <?php elseif ($isRevisionRequired): ?>
        <span class="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-red-500/20 border border-red-500/50 text-red-400 text-xs font-black animate-pulse">
          ⚠️ REVISION REQUIRED (Round #<?= count($revisionsList) ?>)
        </span>
      <?php else: ?>
        <span class="px-3 py-1.5 rounded-xl bg-dark-card border border-dark-border text-gold font-bold font-mono text-xs uppercase">
          <?= strtoupper(str_replace('_', ' ', $maskedOrder['status'])) ?>
        </span>
      <?php endif; ?>
    </div>
  </div>

  <!-- ── 1. LOCKED BY SOMEONE ELSE WARNING ────────────────────────── -->
  <?php if ($lockedBySomeoneElse): ?>
  <div class="p-6 rounded-3xl bg-red-950/40 border-2 border-red-500/60 flex items-center gap-4 shadow-xl">
    <span class="text-3xl">🔒</span>
    <div>
      <h4 class="font-black text-red-300 text-base">Job Currently Locked by Another Editor</h4>
      <p class="text-xs text-gray-300 mt-1">
        <strong class="text-white"><?= htmlspecialchars($order['locked_by_name']) ?></strong>
        started editing this job at <strong class="text-gold"><?= !empty($order['locked_at']) ? date('M j, H:i', strtotime($order['locked_at'])) : '—' ?></strong>.
        Please select a different order.
      </p>
    </div>
  </div>
  <?php endif; ?>

  <!-- ── 2. REVISION REQUIRED BANNER (FULL HISTORY + RESUBMIT) ──────── -->
  <?php if ($isRevisionRequired && $lastRevision): ?>
  <div class="p-6 sm:p-8 rounded-3xl bg-red-950/30 border-2 border-red-500/60 space-y-5 shadow-2xl">
    <div class="flex items-start justify-between gap-4 border-b border-red-500/30 pb-4">
      <div class="flex items-center gap-3">
        <span class="text-3xl animate-bounce">⚠️</span>
        <div>
          <h3 class="text-lg font-black text-red-400 uppercase tracking-wide">
            REVISION REQUIRED — ROUND #<?= count($revisionsList) ?>
          </h3>
          <p class="text-xs text-gray-300 mt-0.5">
            Requested by Team Lead: <strong class="text-white"><?= htmlspecialchars($lastRevision['requested_by']) ?></strong>
            &bull; <span class="text-gray-400 font-mono"><?= date('M j, Y — H:i', strtotime($lastRevision['requested_at'])) ?></span>
          </p>
        </div>
      </div>
      <span class="px-3 py-1 rounded-full bg-red-500/20 text-red-300 border border-red-500/40 text-xs font-bold font-mono">
        Category: <?= htmlspecialchars($lastRevision['category']) ?>
      </span>
    </div>

    <!-- Latest Revision Notes -->
    <div class="p-5 rounded-2xl bg-dark/90 border border-red-500/40 text-sm text-gray-200 font-mono whitespace-pre-wrap leading-relaxed shadow-inner">
      <?= htmlspecialchars($lastRevision['instructions']) ?>
    </div>

    <!-- Source Raw Files Link -->
    <?php if (!empty($order['input_storage_path'])): ?>
    <div class="flex items-center gap-3 text-xs">
      <a href="<?= htmlspecialchars($order['input_storage_path']) ?>" target="_blank" class="btn-ghost py-2 px-4 text-xs font-bold border border-blue-500/40 text-blue-400 rounded-xl inline-flex items-center gap-2 hover:bg-blue-500/10">
        <span>📁</span> <span>Open Original Raw Photos ↗</span>
      </a>
      <?php if (!empty($order['output_storage_path'])): ?>
      <span class="text-gray-400 font-mono">Previous Output: <strong class="text-gold"><?= htmlspecialchars($order['output_storage_path']) ?></strong></span>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Revision Resubmission Form -->
    <?php if ($canSubmitRevision): ?>
    <form method="POST" class="pt-4 border-t border-red-500/30 space-y-4">
      <?= csrfField() ?>
      <input type="hidden" name="action_submit_qa" value="1">
      <input type="hidden" name="is_revision" value="1">

      <div class="section-tag text-red-300">✏️ Submit Corrected Revision to Team Lead</div>
      
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
          <label class="form-label text-xs font-bold text-gray-200">📊 Revised Image Count <span class="text-red-400">*</span></label>
          <input type="number" name="final_image_count" required min="1"
                 value="<?= htmlspecialchars((string)($order['final_image_count'] ?? $order['photo_count'] ?? 10)) ?>"
                 placeholder="e.g. 20"
                 class="form-input w-full text-xs mt-1 bg-[#111118] text-white">
        </div>
        <div class="sm:col-span-2">
          <label class="form-label text-xs font-bold text-gray-200">📁 Updated Output Storage Path (Dropbox / Drive / Server) <span class="text-red-400">*</span></label>
          <input type="text" name="output_path" required
                 value="<?= htmlspecialchars($order['output_storage_path'] ?? '') ?>"
                 placeholder="e.g. /storage/outputs/2026/08/<?= htmlspecialchars($order['id']) ?>_rev<?= count($revisionsList) ?>_final/"
                 class="form-input w-full text-xs mt-1 bg-[#111118] text-white">
        </div>
      </div>

      <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-2">
        <p class="text-xs text-amber-300/90 font-medium">
          🔁 After submitting, Team Lead will inspect your corrected images and approve or request further adjustments.
        </p>
        <button type="submit" class="btn-gold py-3 px-8 font-black shadow-glow whitespace-nowrap text-sm inline-flex items-center gap-2 bg-gradient-to-r from-red-600 via-amber-600 to-gold">
          <span>🔁</span> <span>Submit Revision for QA</span>
        </button>
      </div>
    </form>
    <?php endif; ?>

    <!-- Revision History List (if multiple rounds) -->
    <?php if (count($revisionsList) > 1): ?>
    <details class="pt-3 border-t border-red-500/20 text-xs">
      <summary class="cursor-pointer text-gray-400 hover:text-white font-bold py-1">
        📜 View Past Revision History (<?= count($revisionsList) ?> total rounds)
      </summary>
      <div class="space-y-3 mt-3">
        <?php foreach (array_reverse($revisionsList) as $idx => $rev): ?>
        <div class="p-3 rounded-xl bg-dark/60 border border-dark-border text-xs space-y-1">
          <div class="flex justify-between font-bold text-gray-300">
            <span>Round #<?= $rev['revision_number'] ?? ($idx + 1) ?> &bull; <?= htmlspecialchars($rev['category'] ?? 'General') ?></span>
            <span class="font-mono text-gray-400"><?= date('M j, H:i', strtotime($rev['requested_at'] ?? 'now')) ?></span>
          </div>
          <p class="text-gray-300 font-mono"><?= htmlspecialchars($rev['instructions']) ?></p>
        </div>
        <?php endforeach; ?>
      </div>
    </details>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <!-- ── 3. JOB SPECIFICATION CARD ────────────────────────────────── -->
  <div class="glass-card rounded-3xl p-6 sm:p-8 border border-dark-border shadow-2xl space-y-6">
    <div class="flex flex-col sm:flex-row justify-between sm:items-start gap-4 border-b border-dark-border pb-6">
      <div>
        <div class="section-tag mb-1">Job Specification (Privacy Shield Active)</div>
        <h1 class="text-2xl sm:text-3xl font-black text-white">
          <?= htmlspecialchars($maskedOrder['id']) ?>
          <span class="text-gold text-xl">&bull; <?= htmlspecialchars($maskedOrder['property_ref']) ?></span>
        </h1>
        <p class="text-gray-400 text-xs mt-1">Property: <strong class="text-white"><?= htmlspecialchars($maskedOrder['property_name']) ?></strong></p>
      </div>

      <!-- Action / Download Buttons in Header -->
      <div class="flex items-center gap-3">
        <?php if ($canStartJob): ?>
          <form method="POST" class="inline-block">
            <?= csrfField() ?>
            <input type="hidden" name="action_start_job" value="1">
            <button type="submit" class="btn-gold py-3 px-6 text-xs font-black shadow-glow inline-flex items-center gap-2 bg-gradient-to-r from-emerald-600 via-teal-500 to-gold">
              <span>▶</span> <span>Start Job &amp; Download Photos (<?= $maskedOrder['photo_count'] ?> files)</span>
            </button>
          </form>
        <?php elseif (!empty($order['input_storage_path'])): ?>
          <a href="<?= htmlspecialchars($order['input_storage_path']) ?>" target="_blank" class="btn-gold py-2.5 px-5 text-xs font-black shadow-glow inline-flex items-center gap-2">
            <span>📥</span> <span>Download Raw Photos (<?= $maskedOrder['photo_count'] ?> files) ↗</span>
          </a>
        <?php endif; ?>
      </div>
    </div>

    <!-- Job Details Grid -->
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
      <div class="p-4 rounded-2xl bg-dark/80 border border-dark-border space-y-1">
        <span class="text-gray-400 block">Editing Scope</span>
        <strong class="text-gold text-sm"><?= htmlspecialchars($maskedOrder['editing_type']) ?></strong>
      </div>
      <div class="p-4 rounded-2xl bg-dark/80 border border-dark-border space-y-1">
        <span class="text-gray-400 block">Team Lead</span>
        <strong class="text-white text-sm"><?= htmlspecialchars($maskedOrder['assigned_tl_name'] ?? 'Production Team Lead') ?></strong>
      </div>
      <div class="p-4 rounded-2xl bg-dark/80 border border-dark-border space-y-1">
        <span class="text-gray-400 block">Deadline</span>
        <strong class="text-emerald-400 text-sm"><?= date('F j, Y — H:i', strtotime($maskedOrder['deadline'])) ?></strong>
      </div>
    </div>

    <!-- Instructions -->
    <div class="p-5 rounded-2xl bg-dark/80 border border-dark-border space-y-2">
      <h4 class="text-xs font-bold text-gold uppercase tracking-wider">Editing Instructions</h4>
      <p class="text-sm text-gray-200 leading-relaxed"><?= nl2br(htmlspecialchars($maskedOrder['instructions'] ?: 'Standard high-quality real estate photo editing. Ensure natural colors, straight verticals, and clear window pulls.')) ?></p>
    </div>

    <!-- ─── 4. SUBMIT FOR QA REVIEW FORM (when in process) ───────── -->
    <?php if ($canSubmitFirst): ?>
    <div class="p-6 rounded-3xl bg-blue-950/20 border-2 border-blue-500/40 space-y-4">
      <div class="flex items-center justify-between border-b border-blue-500/30 pb-3">
        <div class="flex items-center gap-2">
          <span class="text-xl animate-pulse">📤</span>
          <h3 class="font-black text-white text-sm uppercase tracking-wide">COMPLETED EDITING? SUBMIT FOR QA REVIEW</h3>
        </div>
        <span class="text-xs text-blue-400 font-mono font-bold">Status: In Process</span>
      </div>

      <form method="POST" class="space-y-4">
        <?= csrfField() ?>
        <input type="hidden" name="action_submit_qa" value="1">
        <input type="hidden" name="is_revision" value="0">

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label class="form-label text-xs font-bold text-gray-200">📊 Final Images Done Count <span class="text-red-400">*</span></label>
            <input type="number" name="final_image_count" required min="1"
                   value="<?= htmlspecialchars((string)($order['final_image_count'] ?? $order['photo_count'] ?? 10)) ?>"
                   placeholder="e.g. 20"
                   class="form-input w-full text-xs mt-1 bg-[#111118] text-white">
            <p class="text-[10px] text-gray-400 mt-1">Logged for monthly performance and image totals.</p>
          </div>
          <div class="sm:col-span-2">
            <label class="form-label text-xs font-bold text-gray-200">📁 Final Output Storage Path (Dropbox / Drive / Server) <span class="text-red-400">*</span></label>
            <input type="text" name="output_path" required
                   value="<?= htmlspecialchars($order['output_storage_path'] ?? '') ?>"
                   placeholder="e.g. /storage/outputs/2026/08/<?= htmlspecialchars($order['id']) ?>_final/ or Drive Link"
                   class="form-input w-full text-xs mt-1 bg-[#111118] text-white">
          </div>
        </div>

        <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-2">
          <p class="text-xs text-gray-400">
            Once submitted, your job lock will release and the order will move to Team Lead QA inspection.
          </p>
          <button type="submit" class="btn-gold py-3 px-8 font-black shadow-glow whitespace-nowrap text-sm inline-flex items-center gap-2">
            <span>🚀</span> <span>Submit for QA Review &rarr;</span>
          </button>
        </div>
      </form>
    </div>
    <?php elseif ($canStartJob): ?>
    <!-- Prompt to Start Job -->
    <div class="p-6 rounded-3xl bg-amber-950/20 border border-amber-500/40 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
      <div>
        <h4 class="font-bold text-white text-sm">Job Assigned to You</h4>
        <p class="text-xs text-amber-200/80 mt-0.5">Click "Start Job" to mark this order in process and download raw source photos.</p>
      </div>
      <form method="POST">
        <?= csrfField() ?>
        <input type="hidden" name="action_start_job" value="1">
        <button type="submit" class="btn-gold py-2.5 px-6 text-xs font-black shadow-glow inline-flex items-center gap-2">
          <span>▶</span> <span>Start Job &amp; Begin Editing</span>
        </button>
      </form>
    </div>
    <?php endif; ?>

    <!-- ── AI EDITOR COPILOT & STYLE DNA ASSISTANT ────────────────────── -->
    <div class="rounded-3xl bg-gradient-to-br from-[#121722] to-[#171E2D] border border-gold/40 p-6 sm:p-8 shadow-2xl space-y-5">
      <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-gray-800 pb-4">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-2xl bg-gold/20 text-gold flex items-center justify-center font-black text-lg border border-gold/40">
            🤖
          </div>
          <div>
            <h3 class="text-base font-black text-white flex items-center gap-2">
              <span>AI Editor Copilot</span>
              <span class="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">Active Assistant</span>
            </h3>
            <p class="text-xs text-gray-400 mt-0.5">Automated Bracket Pre-Check &amp; Client Style DNA Consistency</p>
          </div>
        </div>
        <div class="flex items-center gap-3">
          <div class="text-right">
            <div class="text-xs text-gray-400">Style Match</div>
            <div class="text-sm font-black text-gold font-mono"><?= $clientDna['similarity_score'] ?>% Benchmark</div>
          </div>
          <div class="w-10 h-10 rounded-xl bg-dark/80 border border-gold/40 flex items-center justify-center font-bold text-xs text-gold">
            <?= $aiAudit['confidence_score'] ?>%
          </div>
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <!-- Technical Findings -->
        <div class="p-4 rounded-2xl bg-dark/60 border border-gray-800 space-y-3">
          <div class="text-xs font-bold text-gray-300 flex items-center gap-2">
            <span class="text-amber-400">🔍</span> Detected Exposure &amp; Geometric Flags
          </div>
          <?php if (empty($aiAudit['issues'])): ?>
            <p class="text-xs text-emerald-400">✅ All brackets aligned. Clean exposure dynamic range.</p>
          <?php else: ?>
            <ul class="space-y-2">
              <?php foreach ($aiAudit['issues'] as $issue): ?>
                <li class="text-xs text-gray-300 flex items-start gap-2 bg-dark-card p-2 rounded-lg border border-gray-800/80">
                  <span class="text-amber-400 mt-0.5">&bull;</span>
                  <span><?= htmlspecialchars($issue['details']) ?></span>
                </li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>

        <!-- Copilot Suggested Actions -->
        <div class="p-4 rounded-2xl bg-dark/60 border border-gray-800 space-y-3">
          <div class="text-xs font-bold text-gray-300 flex items-center gap-2">
            <span class="text-gold">⚡</span> Suggested 1-Click Retouch Actions
          </div>
          <div class="space-y-2">
            <?php foreach ($aiAudit['suggested_actions'] as $action): ?>
              <div class="flex items-center justify-between gap-2 p-2 rounded-lg bg-dark-card border border-gold/20 text-xs">
                <span class="text-gray-200">✓ <?= htmlspecialchars($action) ?></span>
                <button type="button" onclick="this.classList.add('bg-emerald-600','text-white'); this.innerText='Applied';" class="px-2 py-1 rounded bg-gold/10 hover:bg-gold/20 text-gold font-bold text-[11px] transition">
                  Apply Fix
                </button>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>

      <!-- Client Style Guidance -->
      <div class="p-3 rounded-xl bg-gold/5 border border-gold/20 text-xs text-gray-300 flex items-center gap-3">
        <span class="text-gold text-lg">💡</span>
        <div>
          <strong class="text-white">Client Style Rule:</strong>
          <?= htmlspecialchars($clientDna['intelligent_feedback'][0] ?? 'Deliver balanced natural lighting with clean vertical lines.') ?>
        </div>
      </div>
    </div>

  </div>

</main>
</body>
</html>
