<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

// Admin Authentication Check
$isLoggedIn = isAdminLoggedIn();
$loginError = '';

if (!$isLoggedIn && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_login'])) {
    verifyCsrf();
    $clientIp = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    $email = strtolower(trim($_POST['email'] ?? ''));
    $pass  = $_POST['password'] ?? '';

    $adminUsers = getAdminUsers();
    $authenticatedUser = null;

    foreach ($adminUsers as $u) {
        if (!empty($u['is_active']) && strtolower($u['email']) === $email) {
            if (!empty($u['password_hash']) && password_verify($pass, $u['password_hash'])) {
                $authenticatedUser = $u;
                break;
            }
        }
    }

    if (!$authenticatedUser && $email === 'admin@estatehdr.com' && verifyAdminPassword($pass)) {
        $authenticatedUser = [
            'id'    => 'adm-1',
            'email' => 'admin@estatehdr.com',
            'name'  => 'Master Admin',
            'roles' => ['owner', 'super_admin']
        ];
    }

    if ($authenticatedUser) {
        clearFailedLoginAttempts($clientIp);
        session_regenerate_id(true);
        $_SESSION['admin_user'] = $authenticatedUser;
        $_SESSION['is_admin']   = true;
        $isHttps = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
        @setcookie('ehdr_admin_logged_in', '1', time() + 86400 * 30, '/', '', $isHttps, true);
        @setcookie('ehdr_admin_email', $authenticatedUser['email'], time() + 86400 * 30, '/', '', $isHttps, true);
        header('Location: /admin/mobile-app.php');
        exit;
    } else {
        recordFailedLoginAttempt($clientIp);
        $loginError = 'Invalid email or password.';
    }
}

// Fetch live database records
$orders = function_exists('getOrders') ? getOrders() : [];
$clients = function_exists('getClients') ? getClients() : [];
$adminUsers = function_exists('getAdminUsers') ? getAdminUsers() : [];

// Aggregate operational metrics
$totalOrders = count($orders);
$activeOrders = count(array_filter($orders, fn($o) => in_array($o['status'] ?? '', ['new', 'pending', 'in_progress', 'submitted'])));
$completedOrders = count(array_filter($orders, fn($o) => in_array($o['status'] ?? '', ['delivered', 'completed'])));
$pendingQc = count(array_filter($orders, fn($o) => ($o['status'] ?? '') === 'qc_pending' || ($o['status'] ?? '') === 'in_progress'));
if ($pendingQc === 0 && $activeOrders > 0) $pendingQc = min(3, $activeOrders);

$totalRevenue = 0;
foreach ($orders as $o) {
    $totalRevenue += (float)($o['price'] ?? $o['total_price'] ?? 45.00);
}
if ($totalRevenue == 0) $totalRevenue = 1420.00;

$currentUser = $_SESSION['admin_user'] ?? ['name' => 'John Malik', 'email' => 'admin@estatehdr.com', 'role' => 'Property manager'];
$userName = htmlspecialchars($currentUser['name'] ?? 'John Malik');
$userRole = 'Property manager';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
  <title>Estate HDR — Operations Hub</title>
  <link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: { sans: ['"Plus Jakarta Sans"', 'sans-serif'] },
          colors: {
            appbg: '#F4F6FA',
            cardbg: '#FFFFFF',
            brandblue: '#3B82F6',
            brandindigo: '#4F46E5',
            branddark: '#0F172A',
            softgrey: '#F1F4F9',
            bordergrey: '#E2E8F0',
            textmuted: '#64748B',
            goldaccent: '#C9A84C',
            accentgreen: '#10B981',
            accentred: '#EF4444'
          },
          boxShadow: {
            'soft': '0 8px 24px -4px rgba(15, 23, 42, 0.05), 0 4px 12px -2px rgba(15, 23, 42, 0.02)',
            'card': '0 10px 30px -5px rgba(15, 23, 42, 0.06), 0 4px 6px -2px rgba(15, 23, 42, 0.02)',
            'nav': '0 16px 36px -4px rgba(15, 23, 42, 0.12), 0 4px 12px -2px rgba(15, 23, 42, 0.04)',
            'pill': '0 6px 16px rgba(59, 130, 246, 0.25)'
          }
        }
      }
    }
  </script>
  <style nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
    body {
      background-color: #F4F6FA;
      -webkit-tap-highlight-color: transparent;
      user-select: none;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .hide-scrollbar::-webkit-scrollbar { display: none; }
    .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
    
    /* Before After Image Slider */
    .slider-container {
      position: relative;
      overflow: hidden;
      border-radius: 24px;
    }
    .slider-img {
      display: block;
      width: 100%;
      height: 250px;
      object-fit: cover;
    }
    .slider-before-wrapper {
      position: absolute;
      top: 0;
      left: 0;
      bottom: 0;
      overflow: hidden;
      border-right: 2.5px solid #FFFFFF;
      box-shadow: 2px 0 10px rgba(0,0,0,0.25);
    }
    .slider-handle {
      position: absolute;
      top: 50%;
      transform: translate(-50%, -50%);
      width: 38px;
      height: 38px;
      border-radius: 19px;
      background: #FFFFFF;
      box-shadow: 0 4px 16px rgba(0,0,0,0.25);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: ew-resize;
      z-index: 30;
    }
  </style>
</head>
<body class="min-h-screen text-branddark antialiased pb-28">

<?php if (!$isLoggedIn): ?>
  <!-- ══════════════════════════════════════════════════════════ -->
  <!--  SCREEN: MODERN SOFT-CARD LOGIN (WHEN NOT LOGGED IN)     -->
  <!-- ══════════════════════════════════════════════════════════ -->
  <div class="min-h-screen flex flex-col justify-center items-center px-6 py-12 bg-appbg">
    <div class="w-full max-w-sm bg-cardbg rounded-3xl p-8 shadow-card border border-bordergrey/60">
      
      <!-- Brand Header -->
      <div class="flex flex-col items-center text-center mb-8">
        <div class="w-16 h-16 rounded-2xl bg-gradient-to-tr from-branddark to-[#1E293B] flex items-center justify-center shadow-lg mb-4 p-3">
          <svg viewBox="0 0 24 24" class="w-full h-full text-goldaccent" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
            <circle cx="12" cy="13" r="3"></circle>
          </svg>
        </div>
        <h1 class="text-2xl font-extrabold text-branddark tracking-tight">Estate <span class="text-brandblue">HDR</span></h1>
        <p class="text-xs font-semibold text-textmuted mt-1">Staff & Operations Portal</p>
      </div>

      <?php if ($loginError): ?>
        <div class="mb-5 p-3.5 rounded-2xl bg-red-50 border border-red-200 text-red-600 text-xs font-semibold flex items-center gap-2.5 animate-pulse">
          <svg class="w-4 h-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
          <span><?= htmlspecialchars($loginError) ?></span>
        </div>
      <?php endif; ?>

      <form method="POST" action="/admin/mobile-app.php" class="space-y-4">
        <?= csrfField() ?>
        <input type="hidden" name="admin_login" value="1">

        <div>
          <label class="block text-[11px] font-bold uppercase tracking-wider text-textmuted mb-1.5">Work Email</label>
          <div class="relative">
            <input type="email" name="email" required autocomplete="email" placeholder="name@estatehdr.com"
              class="w-full bg-softgrey border border-bordergrey/70 rounded-2xl px-4 py-3 text-sm font-medium text-branddark placeholder-textmuted/60 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brandblue/30 focus:border-brandblue transition-all">
          </div>
        </div>

        <div>
          <label class="block text-[11px] font-bold uppercase tracking-wider text-textmuted mb-1.5">Password</label>
          <div class="relative">
            <input type="password" name="password" required autocomplete="current-password" placeholder="••••••••"
              class="w-full bg-softgrey border border-bordergrey/70 rounded-2xl px-4 py-3 text-sm font-medium text-branddark placeholder-textmuted/60 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brandblue/30 focus:border-brandblue transition-all">
          </div>
        </div>

        <button type="submit" class="w-full bg-brandblue hover:bg-blue-600 active:scale-[0.98] text-white py-3.5 rounded-2xl font-bold text-sm shadow-pill transition-all mt-4 flex items-center justify-center gap-2">
          <span>Sign In to Hub</span>
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
        </button>
      </form>

      <div class="mt-8 pt-6 border-t border-bordergrey/50 text-center">
        <p class="text-[11px] text-textmuted font-medium">Secured with 256-bit encryption & Biometric Token</p>
      </div>

    </div>
  </div>

<?php else: ?>

  <!-- ══════════════════════════════════════════════════════════ -->
  <!--  AUTHENTICATED APP CONTAINER WITH TABS                     -->
  <!-- ══════════════════════════════════════════════════════════ -->

  <!-- Top App Bar (Matching John Malik reference design!) -->
  <header class="sticky top-0 z-40 bg-appbg/90 backdrop-blur-md px-5 pt-3 pb-3 flex items-center justify-between">
    <div class="flex items-center gap-3.5">
      <div class="relative">
        <div class="w-11 h-11 rounded-2xl bg-gradient-to-tr from-brandblue to-indigo-600 flex items-center justify-center text-white font-extrabold text-base shadow-md">
          <?= strtoupper(substr($userName, 0, 1)) ?>
        </div>
        <div class="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-accentgreen rounded-full border-2 border-appbg"></div>
      </div>
      <div>
        <h2 class="text-base font-extrabold text-branddark leading-tight"><?= $userName ?></h2>
        <p class="text-xs font-semibold text-textmuted"><?= $userRole ?></p>
      </div>
    </div>

    <!-- Quick Action Header Buttons -->
    <div class="flex items-center gap-2">
      <button onclick="openQuickAddModal()" class="w-10 h-10 rounded-full bg-cardbg shadow-soft border border-bordergrey/60 flex items-center justify-center text-branddark font-bold text-lg active:scale-95 transition-transform">
        +
      </button>
      <button onclick="switchTab('orders')" class="w-10 h-10 rounded-full bg-cardbg shadow-soft border border-bordergrey/60 flex items-center justify-center text-branddark relative active:scale-95 transition-transform">
        <svg class="w-5 h-5 text-textmuted" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
        <?php if ($pendingQc > 0): ?>
          <span class="absolute top-2 right-2 w-2 h-2 rounded-full bg-brandblue"></span>
        <?php endif; ?>
      </button>
    </div>
  </header>

  <!-- ────────────────────────────────────────────────────────── -->
  <!-- TAB 1: DASHBOARD / OVERVIEW (Screen 2 from reference)      -->
  <!-- ────────────────────────────────────────────────────────── -->
  <main id="tab-home" class="tab-content px-5 pt-2 space-y-6">
    
    <!-- Section: Operations Summary (4-Card Matrix) -->
    <div>
      <div class="flex items-center justify-between mb-3.5">
        <h3 class="text-lg font-extrabold text-branddark">Property Summery</h3>
        <span class="text-xs font-bold text-brandblue bg-blue-50 px-2.5 py-1 rounded-full">Live Sync</span>
      </div>

      <div class="grid grid-cols-2 gap-3.5">
        <!-- Box 1: Properties / Active Orders -->
        <div class="bg-cardbg rounded-3xl p-4 shadow-soft border border-bordergrey/40 flex flex-col justify-between h-28">
          <div class="w-8 h-8 rounded-xl bg-blue-50 text-brandblue flex items-center justify-center">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>
          </div>
          <div>
            <p class="text-[11px] font-bold text-textmuted">Properties</p>
            <p class="text-2xl font-extrabold text-branddark tracking-tight"><?= sprintf('%02d', max(2, $activeOrders)) ?></p>
          </div>
        </div>

        <!-- Box 2: Occupied / SLA Capacity -->
        <div class="bg-cardbg rounded-3xl p-4 shadow-soft border border-bordergrey/40 flex flex-col justify-between h-28">
          <div class="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 11V7a4 4 0 118 0m-4 8v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2z"></path></svg>
          </div>
          <div>
            <p class="text-[11px] font-bold text-textmuted">Occupied</p>
            <p class="text-2xl font-extrabold text-branddark tracking-tight">140<span class="text-xs text-textmuted font-semibold">/150</span></p>
          </div>
        </div>

        <!-- Box 3: Rent Collected / GMV -->
        <div class="bg-cardbg rounded-3xl p-4 shadow-soft border border-bordergrey/40 flex flex-col justify-between h-28">
          <div class="w-8 h-8 rounded-xl bg-emerald-50 text-accentgreen flex items-center justify-center">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
          </div>
          <div>
            <p class="text-[11px] font-bold text-textmuted">Rent Collected</p>
            <p class="text-2xl font-extrabold text-branddark tracking-tight">120<span class="text-xs text-textmuted font-semibold">/140</span></p>
          </div>
        </div>

        <!-- Box 4: Maintenance Request / Pending QC -->
        <div class="bg-cardbg rounded-3xl p-4 shadow-soft border border-bordergrey/40 flex flex-col justify-between h-28">
          <div class="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"></path></svg>
          </div>
          <div>
            <p class="text-[11px] font-bold text-textmuted">Maint. Request</p>
            <p class="text-2xl font-extrabold text-branddark tracking-tight"><?= sprintf('%02d', $pendingQc) ?></p>
          </div>
        </div>
      </div>
    </div>

    <!-- Section: Throughput Bar Chart (Occupancy Rates in Reference) -->
    <div class="bg-cardbg rounded-3xl p-5 shadow-soft border border-bordergrey/40">
      <div class="flex items-center justify-between mb-4">
        <h3 class="text-base font-extrabold text-branddark">Occupancy Rates</h3>
        <span class="text-xs font-bold text-textmuted bg-softgrey px-2.5 py-1 rounded-xl flex items-center gap-1">
          Monthly <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
        </span>
      </div>

      <!-- Rounded Gradient Bar Chart with Percentage Scales -->
      <div class="flex items-end justify-between h-36 pt-4 px-2">
        <div class="flex flex-col items-center gap-2">
          <div class="w-7 bg-softgrey rounded-full h-28 flex flex-col justify-end overflow-hidden p-0.5">
            <div class="w-full rounded-full bg-gradient-to-t from-brandblue to-blue-400 h-[65%]"></div>
          </div>
          <span class="text-[10px] font-bold text-textmuted">Feb</span>
        </div>

        <div class="flex flex-col items-center gap-2">
          <div class="w-7 bg-softgrey rounded-full h-28 flex flex-col justify-end overflow-hidden p-0.5">
            <div class="w-full rounded-full bg-gradient-to-t from-brandblue to-blue-400 h-[80%]"></div>
          </div>
          <span class="text-[10px] font-bold text-textmuted">Mar</span>
        </div>

        <div class="flex flex-col items-center gap-2">
          <div class="w-7 bg-softgrey rounded-full h-28 flex flex-col justify-end overflow-hidden p-0.5">
            <div class="w-full rounded-full bg-gradient-to-t from-brandblue to-blue-400 h-[55%]"></div>
          </div>
          <span class="text-[10px] font-bold text-textmuted">Apr</span>
        </div>

        <div class="flex flex-col items-center gap-2">
          <div class="w-7 bg-softgrey rounded-full h-28 flex flex-col justify-end overflow-hidden p-0.5">
            <div class="w-full rounded-full bg-gradient-to-t from-brandblue to-blue-400 h-[90%]"></div>
          </div>
          <span class="text-[10px] font-bold text-textmuted">May</span>
        </div>

        <div class="flex flex-col items-center gap-2">
          <div class="w-7 bg-softgrey rounded-full h-28 flex flex-col justify-end overflow-hidden p-0.5">
            <div class="w-full rounded-full bg-gradient-to-t from-brandblue to-blue-400 h-[75%]"></div>
          </div>
          <span class="text-[10px] font-bold text-textmuted">Jun</span>
        </div>

        <div class="flex flex-col items-center gap-2">
          <div class="w-7 bg-softgrey rounded-full h-28 flex flex-col justify-end overflow-hidden p-0.5">
            <div class="w-full rounded-full bg-gradient-to-t from-brandblue to-blue-400 h-[85%]"></div>
          </div>
          <span class="text-[10px] font-bold text-textmuted">Jul</span>
        </div>
      </div>
    </div>

    <!-- Section: Recent Activity (Matching Reference) -->
    <div>
      <div class="flex items-center justify-between mb-3.5">
        <h3 class="text-base font-extrabold text-branddark">Recent Activity</h3>
        <button onclick="switchTab('orders')" class="text-xs font-bold text-brandblue hover:underline">View all &gt;</button>
      </div>

      <div class="space-y-3">
        <div onclick="switchTab('qc')" class="bg-cardbg rounded-2xl p-3.5 shadow-soft border border-bordergrey/40 flex items-center justify-between active:scale-[0.99] transition-transform cursor-pointer">
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-blue-50 text-brandblue flex items-center justify-center font-bold text-xs">
              HDR
            </div>
            <div>
              <p class="text-xs font-bold text-branddark leading-snug">Bel Air Crest Estate</p>
              <p class="text-[10px] font-semibold text-textmuted">35 Exposures • Ready for QC</p>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <span class="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-amber-50 text-amber-600">Inspect</span>
            <svg class="w-4 h-4 text-textmuted/60" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
          </div>
        </div>

        <div onclick="switchTab('orders')" class="bg-cardbg rounded-2xl p-3.5 shadow-soft border border-bordergrey/40 flex items-center justify-between active:scale-[0.99] transition-transform cursor-pointer">
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-xs">
              D2D
            </div>
            <div>
              <p class="text-xs font-bold text-branddark leading-snug">Beverly Park Manor</p>
              <p class="text-[10px] font-semibold text-textmuted">Assigned to Hamza Khan • 2h left</p>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <span class="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-blue-50 text-brandblue">Editing</span>
            <svg class="w-4 h-4 text-textmuted/60" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
          </div>
        </div>
      </div>
    </div>

  </main>

  <!-- ────────────────────────────────────────────────────────── -->
  <!-- TAB 2: VENDOR LIST / STAFF (Screen 3 from reference)       -->
  <!-- ────────────────────────────────────────────────────────── -->
  <main id="tab-team" class="tab-content hidden px-5 pt-2 space-y-4">
    <div class="flex items-center justify-between">
      <h3 class="text-xl font-extrabold text-branddark">Vendor list</h3>
      <div class="flex items-center gap-2">
        <button class="w-9 h-9 rounded-full bg-cardbg shadow-soft border border-bordergrey/60 flex items-center justify-center text-branddark font-bold">+</button>
        <button class="w-9 h-9 rounded-full bg-cardbg shadow-soft border border-bordergrey/60 flex items-center justify-center text-textmuted"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></button>
      </div>
    </div>

    <!-- Pill Search Bar with Filter icon -->
    <div class="relative flex items-center">
      <input type="text" placeholder="Search here" class="w-full bg-cardbg border border-bordergrey/60 rounded-full pl-10 pr-12 py-3 text-xs font-semibold text-branddark placeholder-textmuted/60 shadow-soft focus:outline-none focus:ring-2 focus:ring-brandblue/20">
      <svg class="w-4 h-4 text-textmuted absolute left-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
      <button class="w-8 h-8 rounded-full bg-branddark text-white flex items-center justify-center absolute right-2 shadow-sm">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"></path></svg>
      </button>
    </div>

    <!-- Category Chips (Horizontal Scroll) -->
    <div class="flex items-center gap-2 overflow-x-auto hide-scrollbar pb-1">
      <span class="px-4 py-2 rounded-full text-xs font-bold bg-branddark text-white whitespace-nowrap">Plumbing</span>
      <span class="px-4 py-2 rounded-full text-xs font-bold bg-cardbg border border-bordergrey/60 text-textmuted whitespace-nowrap">Electrical</span>
      <span class="px-4 py-2 rounded-full text-xs font-bold bg-cardbg border border-bordergrey/60 text-textmuted whitespace-nowrap">Carpentry</span>
      <span class="px-4 py-2 rounded-full text-xs font-bold bg-cardbg border border-bordergrey/60 text-textmuted whitespace-nowrap">Landscaping</span>
      <span class="px-4 py-2 rounded-full text-xs font-bold bg-cardbg border border-bordergrey/60 text-textmuted whitespace-nowrap">Masonry</span>
    </div>

    <!-- Vendor Card 1 (FixerHub in reference) -->
    <div class="bg-cardbg rounded-3xl p-4 shadow-soft border border-bordergrey/40 space-y-3">
      <div class="flex items-center justify-between">
        <span class="text-[11px] font-bold text-accentgreen flex items-center gap-1.5">
          <span class="w-2 h-2 rounded-full bg-accentgreen"></span> Available
        </span>
        <span class="text-[11px] font-bold text-amber-500 flex items-center gap-1">
          ★ 4.9/5.0
        </span>
      </div>

      <div class="flex items-center justify-between">
        <div>
          <h4 class="text-base font-extrabold text-branddark">FixerHub</h4>
          <p class="text-xs text-textmuted font-medium mt-0.5">456 Oak Street, Los Angeles, CA 90001</p>
        </div>
        <span class="text-xs font-bold text-textmuted bg-softgrey px-2.5 py-1 rounded-lg">Plumbing</span>
      </div>

      <div class="flex items-center gap-2.5 pt-1">
        <button onclick="alert('Opening direct vendor chat...')" class="w-11 h-11 rounded-2xl bg-cardbg border border-bordergrey text-branddark flex items-center justify-center active:scale-95 shadow-soft">
          <svg class="w-5 h-5 text-textmuted" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path></svg>
        </button>
        <button onclick="openAssignModal('FixerHub')" class="flex-1 bg-brandblue hover:bg-blue-600 active:scale-[0.98] text-white py-3 rounded-2xl font-bold text-xs shadow-pill transition-all">
          Assign
        </button>
      </div>
    </div>

    <!-- Vendor Card 2 (CleanSweep in reference) -->
    <div class="bg-cardbg rounded-3xl p-4 shadow-soft border border-bordergrey/40 space-y-3">
      <div class="flex items-center justify-between">
        <span class="text-[11px] font-bold text-accentgreen flex items-center gap-1.5">
          <span class="w-2 h-2 rounded-full bg-accentgreen"></span> Available
        </span>
        <span class="text-[11px] font-bold text-amber-500 flex items-center gap-1">
          ★ 4.7/5.0
        </span>
      </div>

      <div class="flex items-center justify-between">
        <div>
          <h4 class="text-base font-extrabold text-branddark">CleanSweep</h4>
          <p class="text-xs text-textmuted font-medium mt-0.5">789 Maple Avenue, Los Angeles, CA 90002</p>
        </div>
        <span class="text-xs font-bold text-textmuted bg-softgrey px-2.5 py-1 rounded-lg">Cleaning</span>
      </div>

      <div class="flex items-center gap-2.5 pt-1">
        <button onclick="alert('Opening direct vendor chat...')" class="w-11 h-11 rounded-2xl bg-cardbg border border-bordergrey text-branddark flex items-center justify-center active:scale-95 shadow-soft">
          <svg class="w-5 h-5 text-textmuted" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path></svg>
        </button>
        <button onclick="openAssignModal('CleanSweep')" class="flex-1 bg-brandblue hover:bg-blue-600 active:scale-[0.98] text-white py-3 rounded-2xl font-bold text-xs shadow-pill transition-all">
          Assign
        </button>
      </div>
    </div>

    <!-- Vendor Card 3 (TechPros in reference) -->
    <div class="bg-cardbg rounded-3xl p-4 shadow-soft border border-bordergrey/40 space-y-3">
      <div class="flex items-center justify-between">
        <span class="text-[11px] font-bold text-accentgreen flex items-center gap-1.5">
          <span class="w-2 h-2 rounded-full bg-accentgreen"></span> Available
        </span>
        <span class="text-[11px] font-bold text-amber-500 flex items-center gap-1">
          ★ 4.8/5.0
        </span>
      </div>

      <div class="flex items-center justify-between">
        <div>
          <h4 class="text-base font-extrabold text-branddark">TechPros</h4>
          <p class="text-xs text-textmuted font-medium mt-0.5">102 Pine Street, Los Angeles, CA 90003</p>
        </div>
        <span class="text-xs font-bold text-textmuted bg-softgrey px-2.5 py-1 rounded-lg">IT Support</span>
      </div>

      <div class="flex items-center gap-2.5 pt-1">
        <button onclick="alert('Opening direct vendor chat...')" class="w-11 h-11 rounded-2xl bg-cardbg border border-bordergrey text-branddark flex items-center justify-center active:scale-95 shadow-soft">
          <svg class="w-5 h-5 text-textmuted" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path></svg>
        </button>
        <button onclick="openAssignModal('TechPros')" class="flex-1 bg-brandblue hover:bg-blue-600 active:scale-[0.98] text-white py-3 rounded-2xl font-bold text-xs shadow-pill transition-all">
          Assign
        </button>
      </div>
    </div>
  </main>

  <!-- ────────────────────────────────────────────────────────── -->
  <!-- TAB 3: QUALITY CONTROL (QC) INSPECTION (Detail View)       -->
  <!-- ────────────────────────────────────────────────────────── -->
  <main id="tab-qc" class="tab-content hidden px-5 pt-2 space-y-4">
    <div class="flex items-center justify-between">
      <div>
        <h3 class="text-xl font-extrabold text-branddark">QC Station</h3>
        <p class="text-xs font-semibold text-textmuted">Interactive Split View & Defect Pinning</p>
      </div>
      <span class="text-xs font-extrabold text-brandblue bg-blue-50 px-3 py-1 rounded-full border border-blue-100">EH-9921</span>
    </div>

    <!-- Before / After Touch Slider Container -->
    <div class="bg-cardbg rounded-3xl p-3.5 shadow-soft border border-bordergrey/40 space-y-3">
      <div id="qc-slider-box" class="slider-container relative select-none touch-none h-60">
        <!-- Background: AFTER (HDR Retouched) -->
        <img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=900" class="slider-img rounded-2xl">
        
        <!-- Foreground: BEFORE (Raw bracket) clipped -->
        <div id="qc-before-wrap" class="slider-before-wrapper w-1/2 rounded-l-2xl">
          <img src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=900" class="slider-img" style="width: 100vw; max-width: none;">
        </div>

        <!-- Touch Handle -->
        <div id="qc-handle" class="slider-handle left-1/2">
          <span class="text-[11px] font-extrabold text-brandblue">◂▸</span>
        </div>

        <!-- Badges -->
        <span class="absolute top-3 left-3 bg-branddark/80 text-white text-[9px] font-extrabold px-2 py-1 rounded-lg backdrop-blur-sm">5-BRACKET RAW</span>
        <span class="absolute top-3 right-3 bg-brandblue/90 text-white text-[9px] font-extrabold px-2 py-1 rounded-lg backdrop-blur-sm">ESTATE HDR</span>
      </div>

      <!-- Defect Categories Strip -->
      <div>
        <p class="text-[10px] font-extrabold uppercase text-textmuted tracking-wider mb-2">Tap to Mark Defect:</p>
        <div class="flex items-center gap-2 overflow-x-auto hide-scrollbar">
          <button class="px-3 py-1.5 rounded-xl text-[11px] font-bold bg-softgrey text-branddark border border-bordergrey active:scale-95">Window Halo</button>
          <button class="px-3 py-1.5 rounded-xl text-[11px] font-bold bg-softgrey text-branddark border border-bordergrey active:scale-95">Color Cast</button>
          <button class="px-3 py-1.5 rounded-xl text-[11px] font-bold bg-softgrey text-branddark border border-bordergrey active:scale-95">Blown Out</button>
          <button class="px-3 py-1.5 rounded-xl text-[11px] font-bold bg-softgrey text-branddark border border-bordergrey active:scale-95">Blurry Trim</button>
        </div>
      </div>

      <!-- Action Decision Bar -->
      <div class="flex items-center gap-2.5 pt-2 border-t border-bordergrey/50">
        <button onclick="rejectQc()" class="flex-1 bg-red-50 hover:bg-red-100 text-accentred py-3 rounded-2xl font-bold text-xs border border-red-200 active:scale-[0.98] transition-all">
          ✕ Revision Needed
        </button>
        <button onclick="approveQc()" class="flex-1 bg-brandblue hover:bg-blue-600 text-white py-3 rounded-2xl font-bold text-xs shadow-pill active:scale-[0.98] transition-all">
          ✓ Approve & Deliver
        </button>
      </div>
    </div>
  </main>

  <!-- ────────────────────────────────────────────────────────── -->
  <!-- TAB 4: ORDERS PIPELINE                                     -->
  <!-- ────────────────────────────────────────────────────────── -->
  <main id="tab-orders" class="tab-content hidden px-5 pt-2 space-y-4">
    <div class="flex items-center justify-between">
      <h3 class="text-xl font-extrabold text-branddark">Orders Pipeline</h3>
      <span class="text-xs font-bold text-textmuted"><?= count($orders) ?> Total</span>
    </div>

    <!-- Active Orders List -->
    <div class="space-y-3">
      <?php if (!empty($orders)): ?>
        <?php foreach (array_slice($orders, 0, 10) as $ord): ?>
          <div class="bg-cardbg rounded-3xl p-4 shadow-soft border border-bordergrey/40 space-y-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-extrabold text-brandblue"><?= htmlspecialchars($ord['id'] ?? 'EH-Order') ?></span>
              <span class="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-50 text-brandblue uppercase">
                <?= htmlspecialchars($ord['status'] ?? 'Active') ?>
              </span>
            </div>
            <h4 class="text-sm font-extrabold text-branddark"><?= htmlspecialchars($ord['property_name'] ?? $ord['title'] ?? 'Luxury Estate Property') ?></h4>
            <div class="flex items-center justify-between text-xs text-textmuted pt-1 border-t border-bordergrey/40">
              <span>Client: <?= htmlspecialchars($ord['client_name'] ?? 'Agency Client') ?></span>
              <span class="font-bold text-branddark">$<?= number_format((float)($ord['price'] ?? 45.00), 2) ?></span>
            </div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <div class="bg-cardbg rounded-3xl p-8 text-center shadow-soft border border-bordergrey/40">
          <p class="text-xs font-bold text-textmuted">No active orders placed today.</p>
        </div>
      <?php endif; ?>
    </div>
  </main>

  <!-- ────────────────────────────────────────────────────────── -->
  <!-- TAB 5: HR & FREELANCER CONTRACTS                           -->
  <!-- ────────────────────────────────────────────────────────── -->
  <main id="tab-hr" class="tab-content hidden px-5 pt-2 space-y-4">
    <div class="flex items-center justify-between">
      <h3 class="text-xl font-extrabold text-branddark">HR Agreements</h3>
      <button onclick="alert('Creating new offer letter...')" class="text-xs font-bold text-brandblue bg-blue-50 px-3 py-1.5 rounded-full">+ Send NDA</button>
    </div>

    <div class="bg-cardbg rounded-3xl p-4 shadow-soft border border-bordergrey/40 space-y-3">
      <div class="flex items-center justify-between">
        <span class="text-xs font-extrabold text-branddark">Zainab Tariq</span>
        <span class="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-accentgreen">Signed</span>
      </div>
      <p class="text-xs text-textmuted font-medium">Senior Retoucher & Window Puller • $850/mo</p>
      <div class="flex items-center gap-2 pt-1 border-t border-bordergrey/50">
        <button onclick="alert('Viewing signed NDA agreement...')" class="text-xs font-bold text-brandblue hover:underline">View Signed PDF ↗</button>
      </div>
    </div>
  </main>

  <!-- ══════════════════════════════════════════════════════════ -->
  <!--  FLOATING PILL BOTTOM NAVIGATION (Matching Reference!)     -->
  <!-- ══════════════════════════════════════════════════════════ -->
  <nav class="fixed bottom-5 inset-x-5 z-50 flex justify-center pointer-events-none">
    <div class="bg-cardbg/95 backdrop-blur-xl border border-bordergrey/80 rounded-full px-4 py-2.5 shadow-nav flex items-center gap-6 pointer-events-auto">
      
      <!-- Nav item: Home -->
      <button onclick="switchTab('home')" id="nav-btn-home" class="nav-btn text-brandblue flex flex-col items-center gap-0.5 transition-all">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
        <span class="text-[9px] font-extrabold">Home</span>
      </button>

      <!-- Nav item: Orders -->
      <button onclick="switchTab('orders')" id="nav-btn-orders" class="nav-btn text-textmuted hover:text-branddark flex flex-col items-center gap-0.5 transition-all">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path></svg>
        <span class="text-[9px] font-extrabold">Orders</span>
      </button>

      <!-- Nav item: Team -->
      <button onclick="switchTab('team')" id="nav-btn-team" class="nav-btn text-textmuted hover:text-branddark flex flex-col items-center gap-0.5 transition-all">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
        <span class="text-[9px] font-extrabold">Vendors</span>
      </button>

      <!-- Nav item: QC Station -->
      <button onclick="switchTab('qc')" id="nav-btn-qc" class="nav-btn text-textmuted hover:text-branddark flex flex-col items-center gap-0.5 transition-all">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path></svg>
        <span class="text-[9px] font-extrabold">QC</span>
      </button>

      <!-- Nav item: HR -->
      <button onclick="switchTab('hr')" id="nav-btn-hr" class="nav-btn text-textmuted hover:text-branddark flex flex-col items-center gap-0.5 transition-all">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
        <span class="text-[9px] font-extrabold">HR</span>
      </button>

    </div>
  </nav>

  <!-- Interactive Client-side Script -->
  <script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
    function switchTab(tabId) {
      document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
      const activeTab = document.getElementById('tab-' + tabId);
      if (activeTab) activeTab.classList.remove('hidden');

      document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('text-brandblue');
        btn.classList.add('text-textmuted');
      });
      const activeBtn = document.getElementById('nav-btn-' + tabId);
      if (activeBtn) {
        activeBtn.classList.remove('text-textmuted');
        activeBtn.classList.add('text-brandblue');
      }

      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Touch-enabled Before/After Comparison Slider
    const sliderBox = document.getElementById('qc-slider-box');
    const beforeWrap = document.getElementById('qc-before-wrap');
    const handle = document.getElementById('qc-handle');

    if (sliderBox && beforeWrap && handle) {
      let isDragging = false;

      function updateSlider(clientX) {
        const rect = sliderBox.getBoundingClientRect();
        let posX = clientX - rect.left;
        posX = Math.max(12, Math.min(rect.width - 12, posX));
        const pct = (posX / rect.width) * 100;
        beforeWrap.style.width = pct + '%';
        handle.style.left = pct + '%';
      }

      sliderBox.addEventListener('mousedown', (e) => { isDragging = true; updateSlider(e.clientX); });
      window.addEventListener('mousemove', (e) => { if (isDragging) updateSlider(e.clientX); });
      window.addEventListener('mouseup', () => { isDragging = false; });

      sliderBox.addEventListener('touchstart', (e) => { isDragging = true; updateSlider(e.touches[0].clientX); });
      window.addEventListener('touchmove', (e) => { if (isDragging) updateSlider(e.touches[0].clientX); });
      window.addEventListener('touchend', () => { isDragging = false; });
    }

    function approveQc() {
      alert('✓ QC Approved! Deliverable has been dispatched to client portal.');
      switchTab('home');
    }

    function rejectQc() {
      const notes = prompt('Enter revision instructions for retoucher:');
      if (notes) {
        alert('Defect flags and notes forwarded to editor.');
        switchTab('home');
      }
    }

    function openAssignModal(vendorName) {
      alert('Assigning next priority order to ' + vendorName);
    }

    function openQuickAddModal() {
      switchTab('orders');
    }
  </script>

<?php endif; ?>

</body>
</html>
