<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/seo-helper.php';

// Clean 301 redirect for direct /index.php requests to root home (Resolves audit check)
if (!empty($_SERVER['REQUEST_URI'])) {
    $reqPath = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    if ($reqPath === '/index.php' || str_ends_with($reqPath, '/index.php')) {
        header('Location: /', true, 301);
        exit;
    }
}

$trialSuccess = false;
$trialError   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'trial_request') {
    verifyCsrf();
    
    $guardResult = ehdr_process_and_guard_lead($_POST, 'trial_request', true);
    if (!$guardResult['success']) {
        $trialError = $guardResult['error'];
    } else {
        $data = $guardResult['sanitized'];
        saveLead($data['name'], $data['email'], $data['phone'], $data['service'], $data['cloud_link'], $data['notes']);
        $trialSuccess = true;
    }
}

$seo = getPageSeo('home') ?: [
    'meta_title'       => 'Estate HDR — Premium Real Estate Photo Editing Services',
    'meta_description' => 'Professional HDR blending, flambient image processing, virtual twilight, virtual staging & window pulls. Delivered within 24 hours. Trusted by top real estate agencies worldwide.',
    'canonical_url'    => BASE_URL . '/',
    'og_image'         => BASE_URL . '/assets/images/portfolio/hdr/1-after.jpg',
    'robots'           => 'index, follow',
    'schema_json'      => ''
];

$pageTitle = htmlspecialchars($seo['meta_title'] ?? 'Estate HDR — Premium Real Estate Photo Editing');
$pageDesc  = htmlspecialchars($seo['meta_description'] ?? '');
$canonUrl  = htmlspecialchars(!empty($seo['canonical_url']) ? $seo['canonical_url'] : (BASE_URL . '/'));
$ogImage   = htmlspecialchars(!empty($seo['og_image']) ? $seo['og_image'] : (BASE_URL . '/assets/images/portfolio/hdr/1-after.jpg'));
$robots    = htmlspecialchars($seo['robots'] ?? 'index, follow');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?></title>
<meta name="description" content="<?= $pageDesc ?>">
<meta name="robots" content="<?= $robots ?>">
<link rel="canonical" href="<?= $canonUrl ?>">
<!-- Open Graph / Facebook / WhatsApp -->
<meta property="og:type"         content="website">
<meta property="og:url"          content="<?= $canonUrl ?>">
<meta property="og:title"        content="<?= $pageTitle ?>">
<meta property="og:description"  content="<?= $pageDesc ?>">
<meta property="og:image"        content="<?= $ogImage ?>">
<!-- Twitter Card -->
<meta name="twitter:card"        content="summary_large_image">
<meta name="twitter:title"       content="<?= $pageTitle ?>">
<meta name="twitter:description" content="<?= $pageDesc ?>">
<meta name="twitter:image"       content="<?= $ogImage ?>">
<?= renderSeoHeadTags() ?>
<link rel="alternate" type="application/rss+xml" title="Estate HDR RSS Feed" href="/rss.xml">
<link rel="alternate" type="application/atom+xml" title="Estate HDR Atom Feed" href="/rss.xml">
<!-- Master Enterprise Knowledge Graph & Rich Snippets (Schema.org JSON-LD) -->
<script type="application/ld+json" nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
{
  "@context": "https://schema.org",
  "@graph": [
    <?= json_encode(getGlobalOrganizationSchema(), JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) ?>,
    <?= json_encode(getWebsiteSearchSchema(), JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) ?>,
    <?= json_encode(getFaqPageSchema([
      ['q' => 'What is the turnaround time for real estate photo editing?', 'a' => 'Standard turnaround is 24 hours guaranteed. We also offer 12-hour Express and 6-hour Rush delivery for urgent property listings.'],
      ['q' => 'What camera RAW formats do you support?', 'a' => 'We accept all professional RAW files including Canon (.CR2, .CR3), Nikon (.NEF), Sony (.ARW), Fuji (.RAF), DNG, and uncompressed TIFF / JPEG.'],
      ['q' => 'Do you provide free revisions?', 'a' => 'Yes, Estate HDR provides 100% free unlimited revisions on all orders until complete client satisfaction.'],
      ['q' => 'How does your 1-3 photo free trial work?', 'a' => 'Submit up to 3 RAW photos through our Free Trial form. We edit them to luxury architectural standards within 24 hours with no credit card required.'],
      ['q' => 'What is the difference between HDR blending and Flambient editing?', 'a' => 'HDR merges bracketed ambient exposures for maximum dynamic range. Flambient combines ambient daylight with strobe/flash exposures for exact color fidelity, zero window glare, and rich architectural depth.'],
      ['q' => 'How are high-resolution deliverables supplied?', 'a' => 'You receive web-optimized 2048px MLS images under 2MB for instant MLS portal upload and 300 DPI uncompressed print-ready files.']
    ]), JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) ?>
  ]
}
</script>
<!-- Favicon -->
<!-- Official Gold & White Favicons -->
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/images/favicon.png">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/images/apple-touch-icon.png">
<link rel="shortcut icon" href="/favicon.ico">
<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap" onload="this.onload=null;this.rel='stylesheet'">
<noscript>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:ital,wght@0,700;1,700&display=swap">
</noscript>
  <link rel="stylesheet" href="/assets/css/bundle.css?v=<?= file_exists(ROOT_PATH . '/assets/css/bundle.css') ? filemtime(ROOT_PATH . '/assets/css/bundle.css') : time() ?>">
  <link rel="stylesheet" href="/assets/css/app.css?v=<?= file_exists(ROOT_PATH . '/assets/css/app.css') ? filemtime(ROOT_PATH . '/assets/css/app.css') : time() ?>">
</head>
<body class="bg-dark text-white overflow-x-hidden">

<a href="#main-content" class="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[100] focus:px-4 focus:py-2.5 focus:bg-gold focus:text-dark focus:font-black focus:rounded-xl focus:shadow-2xl focus:outline-none">Skip to main content</a>

<?php require_once __DIR__ . '/includes/public-header.php'; ?>

<!-- MAIN LANDMARK -->
<main id="main-content" role="main">

<!-- HERO -->
<section id="hero" class="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
  <!-- Cinematic Real Estate Single Background Video (Desktop) & Lightweight Poster (Mobile) -->
  <div class="absolute inset-0 overflow-hidden pointer-events-none z-0 bg-dark" aria-hidden="true">
    <!-- Mobile Fast Poster Fallback -->
    <div class="md:hidden absolute inset-0 bg-cover bg-center opacity-50 filter brightness-90 contrast-105" style="background-image:url('/assets/images/portfolio/hdr/1-after.webp');"></div>
    <!-- Desktop High-Performance Video -->
    <video id="heroBgVideo" autoplay muted loop playsinline preload="none" poster="/assets/images/portfolio/hdr/1-after.jpg" aria-hidden="true" tabindex="-1" class="hidden md:block w-full h-full object-cover opacity-50 filter brightness-90 contrast-105">
      <source src="/assets/videos/hero.mp4" type="video/mp4">
      <track kind="captions" src="data:text/vtt;charset=utf-8,WEBVTT" srclang="en" label="English" default>
    </video>
  </div>

  <!-- Clean Dark Luxury Overlay -->
  <div class="absolute inset-0 bg-black/60 pointer-events-none z-1"></div>
  <div class="absolute inset-0 bg-gradient-to-b from-black/80 via-transparent to-dark pointer-events-none z-1"></div>

  <div class="relative z-10 max-w-7xl mx-auto px-6 text-center hero-content-scale">
    <div class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-gold/30 bg-gold/10 text-gold text-xs font-semibold tracking-wide mb-8 hero-tag">
      <span class="w-1.5 h-1.5 rounded-full bg-gold animate-pulse"></span>
      World's #1 Real Estate Retouching &amp; 3D Staging Studio
    </div>
    <h1 class="hero-h1 font-display text-4xl sm:text-5xl lg:text-5xl font-black leading-[1.12] tracking-tight mb-8">
      <span class="block text-white drop-shadow-md">World's #1 Luxury</span>
      <span class="block text-gradient drop-shadow-lg font-black py-1">Real Estate Photo Editing</span>
      <span class="block text-white drop-shadow-md">&amp; 3D Staging Studio</span>
    </h1>
    <p class="hero-desc text-xl sm:text-2xl text-gray-300 font-medium max-w-3xl mx-auto mb-12 leading-relaxed drop-shadow">
      Transforming ordinary property photos into high-converting architectural masterpieces. Expert <strong class="text-gold font-bold">HDR blending</strong>, <strong class="text-gold font-bold">flambient processing</strong>, <strong class="text-gold font-bold">virtual twilight</strong> &amp; <strong class="text-gold font-bold">3D staging</strong> — delivered in 24 hours.
    </p>
    <div class="hero-cta flex flex-col sm:flex-row gap-4 justify-center">
      <a href="/register.php" class="btn-gold text-base px-8 py-4 shadow-glow inline-flex items-center justify-center gap-2">
        Start Your First Order — Free
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
      </a>
      <a href="#portfolio" class="btn-ghost text-base px-8 py-4 inline-flex items-center justify-center gap-2">
        View Our Work
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
      </a>
    </div>
    <div class="hero-trust mt-16 flex flex-wrap justify-center gap-8 text-center">
      <div><div class="text-3xl font-bold text-gold">1M+</div><div class="text-xs text-gray-300 mt-1 font-medium">Photos Edited</div></div>
      <div class="hidden sm:block w-px h-12 bg-dark-border self-center"></div>
      <div><div class="text-3xl font-bold text-gold">500+</div><div class="text-xs text-gray-300 mt-1 font-medium">Happy Agencies</div></div>
      <div class="hidden sm:block w-px h-12 bg-dark-border self-center"></div>
      <div><div class="text-3xl font-bold text-gold">24h</div><div class="text-xs text-gray-300 mt-1 font-medium">Turnaround</div></div>
      <div class="hidden sm:block w-px h-12 bg-dark-border self-center"></div>
      <div><div class="text-3xl font-bold text-gold">99.8%</div><div class="text-xs text-gray-300 mt-1 font-medium">Satisfaction</div></div>
    </div>
  </div>
  <div class="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
    <span class="text-xs text-gray-400 uppercase tracking-widest font-semibold">Scroll</span>
    <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
  </div>
</section>

<!-- SERVICES -->
<section id="services" class="py-28 px-6 relative">
  <div class="max-w-7xl mx-auto">
    <div class="text-center mb-20 reveal">
      <div class="section-tag">Our Expertise</div>
      <h2 class="text-4xl lg:text-5xl font-bold mt-4 mb-6">Every Service Your Listings <span class="text-gradient">Deserve</span></h2>
      <p class="text-gray-400 text-lg max-w-2xl mx-auto">From raw bracketed exposures to award-winning final images — pixel-perfect precision on every edit.</p>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <?php
      $services = [
        [
          'svg' => '<svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"/></svg>',
          'title' => 'HDR Photo Editing',
          'desc' => 'Multi-exposure HDR blending and flambient techniques that perfectly balance vibrant interior lighting with crystal-clear window pulls, true-to-life colors, and zero glare.',
          'slug' => 'hdr-photo-editing'
        ],
        [
          'svg' => '<svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M3 14h18m-9-4v8m-7 4h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>',
          'title' => 'Virtual Staging',
          'desc' => 'Place photorealistic furniture and designer decor into empty or dated rooms, helping prospective buyers instantly envision the home\'s true potential and driving faster offers.',
          'slug' => 'virtual-staging'
        ],
        [
          'svg' => '<svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>',
          'title' => 'Day to Dusk',
          'desc' => 'Convert flat, overcast daytime exteriors into warm golden-hour and dusk atmospheres that create instant emotional appeal and command premium listing prices.',
          'slug' => 'day-to-dusk'
        ],
        [
          'svg' => '<svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"/></svg>',
          'title' => 'Virtual Twilight',
          'desc' => 'Transform ordinary daytime exterior photos into breathtaking twilight imagery with glowing interior lights, warm ambient fixtures, and rich, dramatic sunset skies without reshooting.',
          'slug' => 'virtual-twilight'
        ],
        [
          'svg' => '<svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>',
          'title' => 'Item Removal',
          'desc' => 'Seamless decluttering and object removal. We erase unwanted vehicles, power cords, trash bins, for-sale signs, and personal clutter while restoring clean underlying surfaces.',
          'slug' => 'item-removal'
        ],
        [
          'svg' => '<svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/></svg>',
          'title' => 'Floor Plans & 3D Tours',
          'desc' => 'High-precision 2D & 3D schematics with accurate room dimensions, square footage calculations, and Zillow/Matterport 3D walkthrough layouts that boost listing engagement.',
          'slug' => 'floor-plans'
        ],
      ];
      foreach ($services as $i => $svc): 
        $srvUrl = '/services/' . $svc['slug'];
      ?>
      <article onclick="window.location.href='<?= $srvUrl ?>'" class="service-card glass-card p-8 rounded-2xl group reveal flex flex-col justify-between cursor-pointer hover:border-gold/60 transition-all hover:scale-[1.02]" style="transition-delay: <?= $i * 80 ?>ms" itemscope itemtype="https://schema.org/Service">
        <div>
          <div class="w-14 h-14 rounded-2xl bg-gold/10 border border-gold/30 text-gold flex items-center justify-center mb-6 group-hover:scale-110 group-hover:border-gold group-hover:bg-gold/20 transition-all shadow-sm">
            <?= $svc['svg'] ?>
          </div>
          <h3 class="text-xl font-bold mb-3 text-white group-hover:text-gold transition-colors" itemprop="name">
            <a href="<?= $srvUrl ?>"><?= $svc['title'] ?></a>
          </h3>
          <p class="text-gray-300 text-sm leading-relaxed" itemprop="description"><?= $svc['desc'] ?></p>
        </div>
        <div class="mt-6 pt-4 border-t border-dark-border/40 flex items-center gap-3" onclick="event.stopPropagation();">
          <a href="/#trial" class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gold text-dark font-black text-xs hover:bg-gold-light transition-all shadow-sm">
            <span>Free Trial</span>
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
          </a>
          <a href="<?= $srvUrl ?>" class="inline-flex items-center gap-1.5 text-gray-300 hover:text-gold text-xs font-bold transition-colors">
            <span>Explore Samples</span>
            <svg class="w-3 h-3 text-gold" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
          </a>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- HOW IT WORKS -->
<section id="how-it-works" class="py-28 px-6 bg-dark-card/50">
  <div class="max-w-7xl mx-auto">
    <div class="text-center mb-20 reveal">
      <div class="section-tag">Simple Process</div>
      <h2 class="text-4xl lg:text-5xl font-bold mt-4">From Upload to <span class="text-gradient">Masterpiece</span></h2>
      <p class="text-gray-400 text-lg mt-4">Three simple steps. Zero hassle.</p>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
      <?php
      $steps = [
        ['n'=>'01','title'=>'Upload Your Files','desc'=>'Create a free account, open a new order ticket, and paste your Google Drive, Dropbox, or WeTransfer link. Add your specific editing notes.'],
        ['n'=>'02','title'=>'We Edit & Deliver','desc'=>'Our professional editors process your real estate photos using HDR blending, flambient techniques, and your specific requirements. Delivered within 24 hours.'],
        ['n'=>'03','title'=>'Review & Revise','desc'=>'Download your finished images. If anything needs tweaking, click "Request Amendment" directly on the ticket — free revisions until you\'re 100% satisfied.'],
      ];
      foreach ($steps as $i => $step): ?>
      <div class="text-center reveal" style="transition-delay: <?= $i * 120 ?>ms">
        <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-gold/20 to-gold/5 border border-gold/30 flex items-center justify-center mx-auto mb-6">
          <span class="text-gold font-bold text-xl"><?= $step['n'] ?></span>
        </div>
        <h3 class="text-xl font-bold mb-3"><?= $step['title'] ?></h3>
        <p class="text-gray-400 text-sm leading-relaxed"><?= $step['desc'] ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- PORTFOLIO / BEFORE-AFTER -->
<section id="portfolio" class="py-28 px-6">
  <div class="max-w-7xl mx-auto">
    <div class="text-center mb-12 reveal">
      <div class="section-tag">Interactive Portfolio</div>
      <h2 class="text-4xl lg:text-5xl font-bold mt-4">See the <span class="text-gradient">Transformation</span></h2>
      <p class="text-gray-400 text-lg mt-4 max-w-2xl mx-auto">Click any service category below and drag the interactive slider to see our real before &amp; after results.</p>
    </div>

    <!-- Portfolio Filter Buttons -->
    <div class="flex flex-wrap justify-center gap-2.5 mb-14 reveal" role="tablist" aria-label="Portfolio Transformation Categories">
      <button type="button" role="tab" id="tab-port-hdr" aria-selected="true" aria-controls="port-hdr" onclick="switchPortfolioTab('port-hdr')" class="portfolio-tab-btn active px-5 py-2.5 rounded-xl text-sm font-bold transition-all border border-gold bg-gold text-dark shadow-sm" data-portfolio="port-hdr">
        HDR &amp; Flambient
      </button>
      <button type="button" role="tab" id="tab-port-item-removal" aria-selected="false" aria-controls="port-item-removal" onclick="switchPortfolioTab('port-item-removal')" class="portfolio-tab-btn px-5 py-2.5 rounded-xl text-sm font-bold transition-all border border-dark-border bg-dark-card text-gray-300 hover:text-white hover:border-gold/40" data-portfolio="port-item-removal">
        Item Removal
      </button>
      <button type="button" role="tab" id="tab-port-virtual-staging" aria-selected="false" aria-controls="port-virtual-staging" onclick="switchPortfolioTab('port-virtual-staging')" class="portfolio-tab-btn px-5 py-2.5 rounded-xl text-sm font-bold transition-all border border-dark-border bg-dark-card text-gray-300 hover:text-white hover:border-gold/40" data-portfolio="port-virtual-staging">
        Virtual Staging
      </button>
      <button type="button" role="tab" id="tab-port-renovation" aria-selected="false" aria-controls="port-renovation" onclick="switchPortfolioTab('port-renovation')" class="portfolio-tab-btn px-5 py-2.5 rounded-xl text-sm font-bold transition-all border border-dark-border bg-dark-card text-gray-300 hover:text-white hover:border-gold/40" data-portfolio="port-renovation">
        Virtual Renovation
      </button>
      <button type="button" role="tab" id="tab-port-day-to-dusk" aria-selected="false" aria-controls="port-day-to-dusk" onclick="switchPortfolioTab('port-day-to-dusk')" class="portfolio-tab-btn px-5 py-2.5 rounded-xl text-sm font-bold transition-all border border-dark-border bg-dark-card text-gray-300 hover:text-white hover:border-gold/40" data-portfolio="port-day-to-dusk">
        Day to Dusk
      </button>
      <button type="button" role="tab" id="tab-port-twilight" aria-selected="false" aria-controls="port-twilight" onclick="switchPortfolioTab('port-twilight')" class="portfolio-tab-btn px-5 py-2.5 rounded-xl text-sm font-bold transition-all border border-dark-border bg-dark-card text-gray-300 hover:text-white hover:border-gold/40" data-portfolio="port-twilight">
        Virtual Twilight
      </button>
    </div>

    <?php
    $portfolioCategories = [
      'port-hdr' => [
        'title' => 'HDR & Flambient Photo Editing',
        'desc' => 'Multi-exposure blending balancing ultra-bright interiors with clear window views.',
        'folder' => 'hdr',
        'items' => [
          ['sample' => 1, 'title' => 'Living Room Interior HDR'],
          ['sample' => 2, 'title' => 'Kitchen & Dining Window Pull'],
          ['sample' => 3, 'title' => 'Master Bedroom Ambient Light'],
          ['sample' => 4, 'title' => 'Open Concept Luxury Hall'],
          ['sample' => 5, 'title' => 'Bathroom & Mirror Exposure'],
          ['sample' => 6, 'title' => 'Covered Patio & Outdoor View']
        ]
      ],
      'port-item-removal' => [
        'title' => 'Item Removal & Decluttering',
        'desc' => 'Erase unwanted items, cords, cars, bins, and clutter seamlessly.',
        'folder' => 'item-removal',
        'items' => [
          ['sample' => 1, 'title' => 'Driveway Vehicle & Bin Removal'],
          ['sample' => 2, 'title' => 'Interior Furniture & Cord Cleanup'],
          ['sample' => 3, 'title' => 'Kitchen Counter Decluttering'],
          ['sample' => 4, 'title' => 'Yard Hose & Toy Removal'],
          ['sample' => 5, 'title' => 'Wall Art & Personal Photo Erasure'],
          ['sample' => 6, 'title' => 'Poolside Clutter Clean']
        ]
      ],
      'port-virtual-staging' => [
        'title' => 'Virtual Staging',
        'desc' => 'Photorealistic 3D furniture staging that brings vacant rooms to life.',
        'folder' => 'virtual-staging',
        'items' => [
          ['sample' => 1, 'title' => 'Modern Living Room Staging'],
          ['sample' => 2, 'title' => 'Master Bedroom Staging'],
          ['sample' => 3, 'title' => 'Dining Room Furniture Placement'],
          ['sample' => 4, 'title' => 'Home Office Setup'],
          ['sample' => 5, 'title' => 'Outdoor Patio Staging'],
          ['sample' => 6, 'title' => 'Basement Lounge Area']
        ]
      ],
      'port-renovation' => [
        'title' => 'Virtual Renovation & Remodeling',
        'desc' => 'Replace outdated flooring, repaint walls, and modernize dated kitchens.',
        'folder' => 'renovation',
        'items' => [
          ['sample' => 1, 'title' => 'Kitchen Countertop & Cabinet Update'],
          ['sample' => 2, 'title' => 'Hardwood Flooring & Wall Color Change'],
          ['sample' => 3, 'title' => 'Bathroom Tile & Vanity Modernization'],
          ['sample' => 4, 'title' => 'Fireplace & Feature Wall Makeover'],
          ['sample' => 5, 'title' => 'Exterior Siding & Door Repaint'],
          ['sample' => 6, 'title' => 'Ceiling & Lighting Renovation']
        ]
      ],
      'port-day-to-dusk' => [
        'title' => 'Day to Dusk Conversion',
        'desc' => 'Turn flat daytime exteriors into warm, high-converting dusk images.',
        'folder' => 'day-to-dusk',
        'items' => [
          ['sample' => 1, 'title' => 'Luxury Villa Day to Dusk'],
          ['sample' => 2, 'title' => 'Suburban Home Sunset Transformation'],
          ['sample' => 3, 'title' => 'Modern Condo Golden Hour'],
          ['sample' => 4, 'title' => 'Backyard Pool Dusk Ambiance'],
          ['sample' => 5, 'title' => 'Front Elevation Dusk Glow'],
          ['sample' => 6, 'title' => 'Townhouse Evening Lighting']
        ]
      ],
      'port-twilight' => [
        'title' => 'Virtual Twilight Photography',
        'desc' => 'Deep blue night skies, illuminated windows, and landscape lighting.',
        'folder' => 'twilight',
        'items' => [
          ['sample' => 1, 'title' => 'Estate Exterior Twilight'],
          ['sample' => 2, 'title' => 'Pool & Patio Evening Ambiance'],
          ['sample' => 3, 'title' => 'Architectural Modern Home Night'],
          ['sample' => 4, 'title' => 'Waterfront Property Twilight'],
          ['sample' => 5, 'title' => 'Garden Landscape Night Glow'],
          ['sample' => 6, 'title' => 'Driveway & Entryway Twilight']
        ]
      ],
    ];

    function findPortfolioImage(string $folder, string $prefix): ?string {
      $extensions = ['webp', 'WEBP', 'jpg', 'jpeg', 'png', 'JPG', 'JPEG', 'PNG'];
      foreach ($extensions as $ext) {
        $relPath = "assets/images/portfolio/{$folder}/{$prefix}.{$ext}";
        if (file_exists(ROOT_PATH . '/' . $relPath)) {
          return '/' . $relPath;
        }
      }
      return null;
    }
    ?>

    <!-- Category Sliders (3 Per Row, 6 Total Per Category) -->
    <?php foreach ($portfolioCategories as $catKey => $catData): ?>
    <div id="<?= $catKey ?>" role="tabpanel" aria-labelledby="tab-<?= $catKey ?>" class="portfolio-category-panel <?= $catKey === 'port-hdr' ? '' : 'hidden' ?>">
      <div class="text-center mb-8">
        <h3 class="text-2xl font-bold text-white"><?= $catData['title'] ?></h3>
        <p class="text-gray-400 text-sm mt-1"><?= $catData['desc'] ?></p>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <?php foreach ($catData['items'] as $idx => $item): 
          $itemNum = $item['sample'];
          $beforeImg = findPortfolioImage($catData['folder'], "{$itemNum}-before") ?? ($itemNum === 1 ? findPortfolioImage($catData['folder'], "before") : null);
          $afterImg  = findPortfolioImage($catData['folder'], "{$itemNum}-after") ?? ($itemNum === 1 ? findPortfolioImage($catData['folder'], "after") : null);
        ?>
        <div class="flex flex-col">
          <div class="ba-container relative rounded-2xl overflow-hidden aspect-[4/3] glass-card cursor-ew-resize select-none border border-dark-border hover:border-gold/30 transition-colors shadow-lg" data-ba>
            <!-- Before Layer -->
            <div class="ba-before absolute inset-0 flex items-center justify-center bg-dark">
              <?php if ($beforeImg): ?>
                <img loading="lazy" decoding="async" width="600" height="450" src="<?= $beforeImg ?>" alt="Before: <?= htmlspecialchars($catData['title']) ?> Sample <?= $itemNum ?>" class="w-full h-full object-cover pointer-events-none">
              <?php else: ?>
                <div class="text-center p-6 bg-gradient-to-br from-gray-900 to-gray-800 w-full h-full flex flex-col items-center justify-center">
                  <div class="text-4xl mb-2 opacity-40">📷</div>
                  <div class="text-gray-400 font-medium text-xs tracking-wide">Sample <?= $itemNum ?> (Before)</div>
                </div>
              <?php endif; ?>
            </div>

            <!-- After Layer -->
            <div class="ba-after absolute inset-0 flex items-center justify-center bg-dark" style="clip-path: inset(0 50% 0 0)">
              <?php if ($afterImg): ?>
                <img loading="lazy" decoding="async" width="600" height="450" src="<?= $afterImg ?>" alt="After: <?= htmlspecialchars($catData['title']) ?> Sample <?= $itemNum ?>" class="w-full h-full object-cover pointer-events-none">
              <?php else: ?>
                <div class="text-center p-6 bg-gradient-to-br from-amber-950/70 to-dark w-full h-full flex flex-col items-center justify-center">
                  <div class="text-4xl mb-2">✨</div>
                  <div class="text-gold font-bold text-xs tracking-wide">Sample <?= $itemNum ?> (After)</div>
                </div>
              <?php endif; ?>
            </div>

            <!-- Divider Line & Handle -->
            <div class="ba-divider absolute inset-y-0 flex items-center" style="left:50%">
              <div class="w-0.5 h-full bg-white/95 shadow-xl"></div>
              <div class="absolute w-10 h-10 rounded-full bg-white shadow-[0_4px_16px_rgba(0,0,0,0.7),0_0_12px_rgba(201,168,76,0.35)] flex items-center justify-center -translate-x-1/2 border-2 border-dark/90 text-dark transition-transform hover:scale-110">
                <svg class="w-4 h-4 text-dark font-black" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M8 9l-4 3 4 3M16 9l4 3-4 3"/>
                </svg>
              </div>
            </div>

            <!-- Badges -->
            <div class="absolute top-3.5 left-3.5 px-3 py-1 bg-black/85 backdrop-blur-md border border-white/20 rounded-lg text-xs font-black text-white shadow-xl pointer-events-none uppercase tracking-wider">
              BEFORE
            </div>
            <div class="absolute top-3.5 right-3.5 px-3 py-1 bg-gold backdrop-blur-md border border-gold/40 rounded-lg text-xs font-black text-dark shadow-xl pointer-events-none uppercase tracking-wider">
              AFTER
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- View More Category Button -->
      <div class="text-center mt-12">
        <a href="/portfolio?service=<?= str_replace('port-', '', $catKey) ?>" class="inline-flex items-center gap-3 px-8 py-4 rounded-xl bg-dark-card border-2 border-gold/60 hover:border-gold hover:bg-gold hover:text-dark text-white font-bold text-sm transition-all duration-300 shadow-md group">
          <span>Explore Full <?= htmlspecialchars($catData['title']) ?> Gallery</span>
          <svg class="w-4 h-4 text-gold group-hover:text-dark transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
        </a>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- PRICING -->
<section id="pricing" class="py-28 px-6 bg-dark-card/50 relative">
  <div class="max-w-7xl mx-auto">
    <div class="text-center mb-10 reveal">
      <div class="section-tag">Instant Quote &amp; Transparent Rates</div>
      <h2 class="text-4xl lg:text-5xl font-bold mt-4">Simple, <span class="text-gradient">Honest Rates</span></h2>
      <p class="text-gray-300 text-base sm:text-lg mt-3 max-w-2xl mx-auto">
        No hidden fees. Zero subscription locks. Use our live interactive calculator below or view fixed category packages.
      </p>
    </div>

    <!-- Master Mode Switcher: Calculator vs Package Tiers -->
    <div class="flex justify-center mb-12 reveal">
      <div class="inline-flex p-1.5 rounded-2xl bg-[#111118] border border-gold/40 shadow-xl gap-2">
        <button type="button" 
                id="btn-mode-calc" 
                onclick="window.switchPricingMode('calc')"
                class="px-6 py-2.5 rounded-xl text-xs sm:text-sm font-black transition-all bg-gold text-dark shadow-glow flex items-center gap-2">
          <span>⚡ Live Pricing Calculator</span>
        </button>
        <button type="button" 
                id="btn-mode-tiers" 
                onclick="window.switchPricingMode('tiers')"
                class="px-6 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-gray-400 hover:text-white transition-all flex items-center gap-2">
          <span>📦 Fixed Service Packages</span>
        </button>
      </div>
    </div>

    <!-- ── 1. INTERACTIVE PRICING CALCULATOR VIEW (DEFAULT) ── -->
    <div id="pricing-view-calc" class="transition-all duration-500">
      <?php require __DIR__ . '/includes/pricing-calculator.php'; ?>
    </div>

    <!-- ── 2. FIXED PACKAGE TIERS VIEW ── -->
    <div id="pricing-view-tiers" class="hidden transition-all duration-500 space-y-12">
      <!-- Category Tabs -->
      <div class="flex flex-wrap justify-center gap-3" role="tablist" aria-label="Pricing Categories">
        <button type="button" role="tab" id="tab-cat-hdr" aria-selected="true" aria-controls="cat-hdr" class="pricing-tab-btn active px-6 py-3 rounded-xl text-sm font-bold transition-all border border-gold bg-gold text-dark shadow-sm" data-target="cat-hdr">
          HDR &amp; Item Removal
        </button>
        <button type="button" role="tab" id="tab-cat-staging" aria-selected="false" aria-controls="cat-staging" class="pricing-tab-btn px-6 py-3 rounded-xl text-sm font-bold transition-all border border-dark-border bg-dark-card text-gray-300 hover:text-white hover:border-gold/40" data-target="cat-staging">
          Virtual Staging &amp; Renovation
        </button>
        <button type="button" role="tab" id="tab-cat-floorplans" aria-selected="false" aria-controls="cat-floorplans" class="pricing-tab-btn px-6 py-3 rounded-xl text-sm font-bold transition-all border border-dark-border bg-dark-card text-gray-300 hover:text-white hover:border-gold/40" data-target="cat-floorplans">
          Floor Plans &amp; 3D Tours
        </button>
        <button type="button" role="tab" id="tab-cat-video" aria-selected="false" aria-controls="cat-video" class="pricing-tab-btn px-6 py-3 rounded-xl text-sm font-bold transition-all border border-dark-border bg-dark-card text-gray-300 hover:text-white hover:border-gold/40" data-target="cat-video">
          Video Editing
        </button>
      </div>

    <?php
    $pricingCategories = [
      'cat-hdr' => [
        'title' => 'Hand-Blended HDR Enhancement & Retouching',
        'subtitle' => 'Pixel-perfect exposures, window pulls, and blue sky guarantee. Limited-time promotional rates!',
        'plans' => [
          [
            'name' => 'Single Property',
            'tier_scope' => '1 – 24 Photos Batch',
            'was_price' => '$0.80',
            'price' => '$0.60',
            'unit' => '/ image',
            'savings_badge' => '25% OFF LIMITED TIME',
            'bonus' => '1 FREE Day-to-Dusk Hero Photo ($10 Value)',
            'desc' => 'Perfect for condos, apartments & standard residential shoots.',
            'features' => [
              'Manual HDR 3-5 Bracket Blending',
              'Window Pull & Flambient Balancing',
              'Sky Replacement & Lawn Green-Up',
              '1 FREE Day-to-Dusk Hero ($0.00)',
              'Guaranteed 24h Turnaround',
              '100% Free Unlimited Amendments'
            ],
            'popular' => false,
            'cta' => 'Get Started ($0.60/ea)',
            'link' => '/register.php'
          ],
          [
            'name' => 'Pro Volume Batch',
            'tier_scope' => '25 – 49 Photos Batch',
            'was_price' => '$0.75',
            'price' => '$0.55',
            'unit' => '/ image',
            'savings_badge' => '🔥 31% OFF — MOST POPULAR',
            'bonus' => '1 FREE Day-to-Dusk Hero Photo ($10 Value)',
            'desc' => 'Best value for residential listings & active real estate photographers.',
            'features' => [
              'Everything in Single Property',
              'Volume Rate: $0.55 / photo',
              'Flash Reflection & Mirror Glare Removal',
              'Fireplace Fire & TV Screen Additions',
              '1 FREE Day-to-Dusk Hero ($0.00)',
              'Priority 18h Delivery',
              'Dedicated Senior Retoucher Bay'
            ],
            'popular' => true,
            'cta' => 'Start Pro Shoot ($0.55/ea)',
            'link' => '/register.php'
          ],
          [
            'name' => 'Agency & Bulk Volume',
            'tier_scope' => '50+ Photos Batch',
            'was_price' => '$0.70',
            'price' => '$0.45 – $0.50',
            'unit' => '/ image',
            'savings_badge' => 'UP TO 44% OFF VIP TIER',
            'bonus' => 'FREE Day-to-Dusk on EVERY Property',
            'desc' => 'Engineered for high-volume real estate media teams & studios.',
            'features' => [
              '50–99 Photos: $0.50 / photo (37% Off)',
              '100+ Photos: $0.45 / photo (VIP 44% Off)',
              'Advanced Item & Vehicle Removal',
              'FREE Day-to-Dusk on EVERY Property',
              'Rush 12h Overnight SLA Guarantee',
              'Dedicated Lead Retoucher + Account Manager',
              'Custom White-Label Delivery Links'
            ],
            'popular' => false,
            'cta' => 'Claim Agency Pricing',
            'link' => '/register.php'
          ]
        ]
      ],
            'cat-video' => [
        'title' => 'Real Estate Video Editing & Drone Reels',
        'subtitle' => 'Cinematic 4K property walkthroughs, vertical social reels, and aerial drone tours with licensed music.',
        'plans' => [
          [
            'name' => 'Social Reel (9:16)',
            'price' => '$15.00',
            'unit' => '/ video',
            'desc' => 'Perfect for Instagram Reels & TikTok',
            'features' => ['30-60s Vertical Reel', 'Trending Audio Hooks', 'Speed Ramps & Transitions', 'Title & Logo Overlay', '24h Delivery'],
            'popular' => false,
            'cta' => 'Order Reel',
            'link' => '/login.php'
          ],
          [
            'name' => 'Full 4K Walkthrough',
            'price' => '$30.00',
            'unit' => '/ video',
            'desc' => 'Complete property interior & exterior tour',
            'features' => ['Up to 3-Min 4K Tour', 'Cinematic Color Grading', 'Stabilizer Warp Fixes', 'Licensed Music Track', '24h Turnaround'],
            'popular' => true,
            'cta' => 'Order Walkthrough',
            'link' => '/login.php'
          ],
          [
            'name' => 'Drone + Cinematic',
            'price' => '$45.00',
            'unit' => '/ video',
            'desc' => 'Full aerial & interior luxury package',
            'features' => ['4K Aerial & Interior Blend', '3D Motion Tracking Titles', 'Property Boundary Graphics', 'Agent Branding & Outro', 'Free Amendments'],
            'popular' => false,
            'cta' => 'Order Drone Package',
            'link' => '/login.php'
          ]
        ]
      ],
      'cat-staging' => [
        'title' => 'Virtual Staging & Renovation',
        'subtitle' => 'Photorealistic 3D furniture placement and interior renovation that sells homes faster.',
        'plans' => [
          [
            'name' => 'Starter',
            'price' => '$10',
            'unit' => '/ image',
            'desc' => 'Perfect for basic staging',
            'features' => ['Standard Furniture', 'Basic Lighting & Shadows', '1 Revision', '48h Delivery'],
            'popular' => false,
            'cta' => 'Get Started',
            'link' => '/register.php'
          ],
          [
            'name' => 'Professional',
            'price' => '$8',
            'unit' => '/ image',
            'desc' => 'Best for modern listings',
            'features' => ['Everything in Starter', 'Scandinavian Style (Popular)', 'Photorealistic Lighting', '24h Priority Delivery', '2 Amendments'],
            'popular' => true,
            'cta' => 'Start Now — Best Value',
            'link' => '/register.php'
          ],
          [
            'name' => 'Agency',
            'price' => 'Custom',
            'unit' => '',
            'desc' => 'For luxury real estate',
            'features' => ['Everything in Professional', 'Luxury Custom Decor', 'Virtual Renovation (Wall/Floor)', '12h Rush Delivery', 'Unlimited Amendments'],
            'popular' => false,
            'cta' => 'Contact Us',
            'link' => 'mailto:hello@estatehdr.com'
          ]
        ]
      ],
      'cat-floorplans' => [
        'title' => 'Floor Plans & 3D Tours',
        'subtitle' => 'Accurate, high-conversion 2D/3D schematics and immersive walkthrough layouts.',
        'plans' => [
          [
            'name' => 'Starter',
            'price' => '$10',
            'unit' => '/ plan',
            'desc' => 'Basic property layouts',
            'features' => ['2D Floor Plan (B&W)', 'Room Labels & Dimensions', 'Total Sq. Ft. Calculation', '48h Delivery'],
            'popular' => false,
            'cta' => 'Get Started',
            'link' => '/register.php'
          ],
          [
            'name' => 'Professional',
            'price' => '$25',
            'unit' => '/ plan',
            'desc' => 'Engaging 3D visual layouts',
            'features' => ['Everything in Starter', '3D Floorplan', '3D Zillow Plan Processing', 'Standard Furniture Added', '24h Priority Delivery'],
            'popular' => true,
            'cta' => 'Start Now — Best Value',
            'link' => '/register.php'
          ],
          [
            'name' => 'Agency',
            'price' => 'Custom',
            'unit' => '',
            'desc' => 'Premium interactive tours',
            'features' => ['Everything in Professional', '3D Matterport Plan', 'Premium Textures (Wood/Tile)', '12h Rush Delivery', 'Unlimited Amendments'],
            'popular' => false,
            'cta' => 'Contact Us',
            'link' => 'mailto:hello@estatehdr.com'
          ]
        ]
      ]
    ];
    ?>

    <!-- Category Grids -->
    <?php foreach ($pricingCategories as $catId => $cat): ?>
    <div id="<?= $catId ?>" role="tabpanel" aria-labelledby="tab-<?= $catId ?>" class="pricing-category-grid <?= $catId === 'cat-hdr' ? '' : 'hidden' ?>">
      <div class="text-center mb-8">
        <h3 class="text-2xl font-bold text-white"><?= $cat['title'] ?></h3>
        <p class="text-gray-300 text-sm mt-1"><?= $cat['subtitle'] ?></p>
      </div>

      <?php if ($catId === 'cat-hdr'): ?>
      <!-- Limited-Time Promotional Banner & Volume Tier Scale -->
      <div class="mb-10 p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-gold/15 via-[#13131d] to-gold/15 border-2 border-gold/40 shadow-2xl relative overflow-hidden reveal">
        <div class="absolute -top-16 -right-16 w-52 h-52 bg-gold/10 rounded-full blur-3xl pointer-events-none"></div>

        <div class="flex flex-col lg:flex-row items-center justify-between gap-5 mb-6 pb-6 border-b border-dark-border/80">
          <div class="space-y-1.5 text-center lg:text-left">
            <div class="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-gold/20 text-gold border border-gold/40 text-xs font-black uppercase tracking-wider">
              <span class="w-2 h-2 rounded-full bg-gold animate-ping"></span>
              <span>Limited-Time Exclusive Promotion</span>
            </div>
            <h4 class="text-2xl sm:text-3xl font-black text-white">
              HDR Photo Retouching: <span class="line-through text-gray-500 font-bold text-xl sm:text-2xl">$0.80</span> <span class="text-gradient font-black text-3xl sm:text-4xl">$0.60</span> <span class="text-base text-gray-400 font-semibold">/ photo</span>
            </h4>
            <p class="text-xs sm:text-sm text-gray-300 max-w-2xl">
              Same museum-grade hand-blended exposure fusion, window pulls, and sky replacements. Slashed pricing plus tiered volume rates down to $0.45/photo!
            </p>
          </div>

          <!-- 1 FREE Day-to-Dusk Hero Box -->
          <div class="flex items-center gap-3.5 px-5 py-3.5 rounded-2xl bg-emerald-500/10 border-2 border-emerald-500/40 text-left flex-shrink-0 shadow-lg">
            <div class="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-2xl flex-shrink-0">
              🎁
            </div>
            <div>
              <div class="text-[11px] font-black text-emerald-400 uppercase tracking-wider">Included Free On Every Listing</div>
              <div class="text-sm sm:text-base font-bold text-white">1 FREE Day-to-Dusk Hero Photo</div>
              <div class="text-xs text-gray-400"><span class="line-through text-gray-500 font-semibold">$10.00 Value</span> &rarr; <strong class="text-emerald-400">$0.00 Complimentary</strong></div>
            </div>
          </div>
        </div>

        <!-- 4-Tier Volume Scale Grid matching Calculator -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          <!-- Tier 1 -->
          <div class="p-4 rounded-2xl bg-dark/95 border border-dark-border flex flex-col justify-between hover:border-gold/40 transition-colors">
            <div>
              <div class="flex items-center justify-between mb-1.5">
                <span class="text-white font-bold text-xs">1 – 24 Photos</span>
                <span class="px-2 py-0.5 rounded-md bg-gold/15 text-gold font-bold text-[10px]">Save 25%</span>
              </div>
              <div class="text-gray-400 text-[11px]">Single property standard</div>
            </div>
            <div class="mt-3 pt-2.5 border-t border-dark-border/60">
              <span class="text-xs text-gray-500 line-through font-bold">$0.80</span>
              <span class="text-2xl font-black text-white ml-1.5">$0.60</span>
              <span class="text-gray-400 text-[11px]">/ photo</span>
            </div>
          </div>

          <!-- Tier 2 -->
          <div class="p-4 rounded-2xl bg-dark/95 border border-gold/40 flex flex-col justify-between hover:border-gold transition-colors">
            <div>
              <div class="flex items-center justify-between mb-1.5">
                <span class="text-white font-bold text-xs">25 – 49 Photos</span>
                <span class="px-2 py-0.5 rounded-md bg-gold/20 text-gold font-bold text-[10px]">Save 31%</span>
              </div>
              <div class="text-gray-400 text-[11px]">Standard residential home</div>
            </div>
            <div class="mt-3 pt-2.5 border-t border-dark-border/60">
              <span class="text-xs text-gray-500 line-through font-bold">$0.75</span>
              <span class="text-2xl font-black text-gold ml-1.5">$0.55</span>
              <span class="text-gray-400 text-[11px]">/ photo</span>
            </div>
          </div>

          <!-- Tier 3 -->
          <div class="p-4 rounded-2xl bg-dark/95 border-2 border-gold/70 shadow-lg relative flex flex-col justify-between">
            <div class="absolute -top-2.5 right-3 px-2 py-0.5 rounded-full bg-gold text-dark text-[10px] font-black uppercase tracking-wider shadow-sm">Most Popular</div>
            <div>
              <div class="flex items-center justify-between mb-1.5">
                <span class="text-white font-bold text-xs">50 – 99 Photos</span>
                <span class="px-2 py-0.5 rounded-md bg-gold text-dark font-black text-[10px]">Save 37%</span>
              </div>
              <div class="text-gray-400 text-[11px]">Multi-shoot / large luxury</div>
            </div>
            <div class="mt-3 pt-2.5 border-t border-dark-border/60">
              <span class="text-xs text-gray-500 line-through font-bold">$0.70</span>
              <span class="text-2xl font-black text-white ml-1.5">$0.50</span>
              <span class="text-gray-400 text-[11px]">/ photo</span>
            </div>
          </div>

          <!-- VIP Tier -->
          <div class="p-4 rounded-2xl bg-dark/95 border border-emerald-500/50 shadow-md flex flex-col justify-between hover:border-emerald-400 transition-colors">
            <div>
              <div class="flex items-center justify-between mb-1.5">
                <span class="text-emerald-400 font-bold text-xs">100+ Photos</span>
                <span class="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-400 font-black text-[10px]">Save 44% VIP</span>
              </div>
              <div class="text-gray-400 text-[11px]">High-volume studio & agency</div>
            </div>
            <div class="mt-3 pt-2.5 border-t border-dark-border/60">
              <span class="text-xs text-gray-500 line-through font-bold">$0.65</span>
              <span class="text-2xl font-black text-emerald-400 ml-1.5">$0.45</span>
              <span class="text-gray-400 text-[11px]">/ photo</span>
            </div>
          </div>
        </div>
      </div>
      <?php endif; ?>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
        <?php foreach ($cat['plans'] as $i => $plan): ?>
        <div class="<?= $plan['popular'] ? 'pricing-popular rounded-2xl p-8 relative ring-2 ring-gold/50 shadow-glow bg-gradient-to-b from-[#181824] to-[#0e0e16]' : 'glass-card rounded-2xl p-8 relative bg-dark-card/90' ?> flex flex-col justify-between" style="min-height: 520px;">
          <div>
            <?php if ($plan['popular']): ?>
            <div class="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-gold rounded-full text-dark text-xs font-black uppercase tracking-wider whitespace-nowrap shadow-lg">Most Popular</div>
            <?php endif; ?>
            
            <div class="mb-5">
              <?php if (!empty($plan['savings_badge'])): ?>
              <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gold/15 text-gold border border-gold/30 text-[10px] font-black uppercase tracking-wider mb-2">
                <span><?= $plan['savings_badge'] ?></span>
              </div>
              <?php endif; ?>
              <h4 class="text-xl font-bold mb-1 text-white"><?= $plan['name'] ?></h4>
              <?php if (!empty($plan['tier_scope'])): ?>
              <span class="text-xs font-mono font-bold text-gold block mb-1"><?= $plan['tier_scope'] ?></span>
              <?php endif; ?>
              <p class="text-gray-400 text-xs leading-relaxed"><?= $plan['desc'] ?></p>
            </div>

            <div class="mb-5 pb-5 border-b border-dark-border/60">
              <div class="flex items-baseline gap-2">
                <?php if (!empty($plan['was_price'])): ?>
                <span class="text-lg line-through text-gray-500 font-bold"><?= $plan['was_price'] ?></span>
                <?php endif; ?>
                <span class="text-4xl lg:text-5xl font-black <?= $plan['popular'] ? 'text-gold' : 'text-white' ?>"><?= $plan['price'] ?></span>
                <span class="text-gray-400 text-sm ml-1 font-medium"><?= $plan['unit'] ?></span>
              </div>
              <?php if (!empty($plan['was_price'])): ?>
              <span class="text-[11px] font-bold text-emerald-400 block mt-1">Limited-Time Promotional Rate</span>
              <?php endif; ?>
            </div>

            <?php if (!empty($plan['bonus'])): ?>
            <div class="mb-5 p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center gap-2">
              <span class="text-base flex-shrink-0">🎁</span>
              <span class="text-xs font-bold text-emerald-400 leading-tight"><?= $plan['bonus'] ?></span>
            </div>
            <?php endif; ?>

            <ul class="space-y-3 mb-8">
              <?php foreach ($plan['features'] as $f): ?>
              <li class="flex items-center gap-3 text-sm text-gray-300">
                <svg class="w-4 h-4 text-gold flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"/></svg>
                <span><?= $f ?></span>
              </li>
              <?php endforeach; ?>
            </ul>
          </div>

          <div>
            <a href="<?= $plan['link'] ?>" class="block text-center <?= $plan['popular'] ? 'btn-gold py-3.5 text-sm font-black' : 'btn-secondary py-3.5 text-sm font-bold' ?> w-full rounded-xl transition-all shadow-md">
              <?= $plan['cta'] ?>
            </a>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section id="testimonials" class="py-28 px-6">
  <div class="max-w-7xl mx-auto">
    <div class="text-center mb-16 reveal">
      <div class="section-tag">Client Voices</div>
      <h2 class="text-4xl lg:text-5xl font-bold mt-4">Trusted by <span class="text-gradient">Top Agencies</span></h2>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <?php
      $testimonials = [
        ['name'=>'Sarah Mitchell','role'=>'Lead Photographer, Prestige Realty','quote'=>'Estate HDR transformed our workflow. Their flambient processing is the best I have seen — cleaner, faster, and more natural than any competitor.','stars'=>5],
        ['name'=>'James Carter','role'=>'Real Estate Media Director','quote'=>'The virtual twilight service is astonishing. Clients think I shoot at golden hour for every listing. The quality-to-price ratio is unbeatable.','stars'=>5],
        ['name'=>'Emma Rodriguez','role'=>'Independent Real Estate Photographer','quote'=>'Window pulls and HDR blending in 24 hours. The amendment process is seamless — I just click and request changes directly on the ticket.','stars'=>5],
      ];
      foreach ($testimonials as $i => $t): ?>
      <div class="glass-card p-8 rounded-2xl reveal" style="transition-delay: <?= $i * 100 ?>ms">
        <div class="flex gap-1 mb-4"><?php for ($s=0;$s<$t['stars'];$s++): ?><span class="text-gold">&#9733;</span><?php endfor; ?></div>
        <p class="text-gray-300 text-sm leading-relaxed mb-6 italic">"<?= $t['quote'] ?>"</p>
        <div>
          <div class="font-semibold text-white"><?= $t['name'] ?></div>
          <div class="text-gray-400 text-xs mt-0.5 font-medium"><?= $t['role'] ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- FAQ -->
<section id="faq" class="py-28 px-6 bg-dark-card/50">
  <div class="max-w-3xl mx-auto">
    <div class="text-center mb-16 reveal">
      <div class="section-tag">FAQ</div>
      <h2 class="text-4xl font-bold mt-4">Frequently Asked <span class="text-gradient">Questions</span></h2>
    </div>
    <div class="space-y-4" itemscope itemtype="https://schema.org/FAQPage">
      <?php
      $faqs = [
        ['q'=>'What is HDR blending for real estate photography?','a'=>'HDR blending for real estate combines multiple bracketed exposures into a single perfectly lit image. This ensures interiors appear bright and natural while windows and exteriors remain correctly exposed — something a single exposure cannot achieve.'],
        ['q'=>'What is flambient photography and why is it better?','a'=>'Flambient image processing combines flash photography with ambient light exposures. The result is a natural-looking image with soft, even lighting that avoids harsh shadows of pure flash or orange color casts of ambient-only shooting. It is the gold standard for high-end real estate photo editing.'],
        ['q'=>'How long does editing take?','a'=>'Our standard turnaround is 24 hours from the time you submit your order ticket and cloud link. Rush 12-hour delivery is available on Agency plans.'],
        ['q'=>'How do I send my photos?','a'=>'Simply paste a Google Drive, Dropbox, or WeTransfer link into your order ticket. We download your files, edit them, and deliver finished images via a cloud link on the same ticket thread.'],
        ['q'=>'What if I need revisions?','a'=>'Request amendments directly on your ticket thread. Click "Request Amendment," describe what needs changing, and we will revise and re-deliver on the same ticket. Amendments are free until you are 100% satisfied.'],
        ['q'=>'Do you offer virtual staging services?','a'=>'Yes! Our virtual staging services add photorealistic furniture, decor, and finishing touches to empty rooms. Prices start from the Professional plan and are quoted per room for Agency clients.'],
      ];
      foreach ($faqs as $i => $faq): ?>
      <div class="glass-card rounded-xl reveal" style="transition-delay: <?= $i * 60 ?>ms" itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
        <button id="faq-btn-<?= $i ?>" class="faq-btn w-full flex items-center justify-between p-6 text-left" onclick="toggleFaq(this)" aria-expanded="false" aria-controls="faq-ans-<?= $i ?>">
          <span class="font-semibold text-white pr-4" itemprop="name"><?= $faq['q'] ?></span>
          <svg class="faq-icon w-5 h-5 text-gold flex-shrink-0 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
        </button>
        <div id="faq-ans-<?= $i ?>" class="faq-answer hidden px-6 pb-6" role="region" aria-labelledby="faq-btn-<?= $i ?>" itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
          <p class="text-gray-300 text-sm leading-relaxed" itemprop="text"><?= $faq['a'] ?></p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- FREE TRIAL REQUEST FORM (NO SIGNUP REQUIRED) -->
<section id="trial" class="py-24 px-6 bg-dark-card/40 relative">
  <div class="max-w-4xl mx-auto">
    <div class="text-center mb-12 reveal">
      <div class="section-tag">Instant Free Trial</div>
      <h2 class="text-4xl lg:text-5xl font-bold mt-4">Test Our Quality <span class="text-gradient">100% Free</span></h2>
      <p class="text-gray-400 text-base sm:text-lg mt-3 max-w-xl mx-auto">
        No account required. Send your raw files and we'll deliver your edited sample within 24 hours.
      </p>
    </div>

    <div class="glass-card rounded-2xl p-8 sm:p-12 border border-gold/30 shadow-2xl relative reveal">
      <?php if ($trialSuccess): ?>
      <div class="p-8 rounded-2xl bg-green-500/10 border border-green-500/30 text-center">
        <div class="text-5xl mb-3">🎉</div>
        <h3 class="text-2xl font-bold text-emerald-400 mb-2">Free Trial Request Received!</h3>
        <p class="text-gray-300 text-sm leading-relaxed max-w-md mx-auto mb-6">
          Thank you! Our editing team has received your files. We will review and email your finished high-res sample within 24 hours to <strong class="text-white"><?= htmlspecialchars($_POST['email'] ?? '') ?></strong>.
        </p>
        <a href="<?= WHATSAPP_LINK ?>" target="_blank" class="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold transition-all shadow-lg" rel="noopener noreferrer">
          <span>Chat with Team on WhatsApp</span>
          <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.182-.573c.978.58 1.911.928 3.145.929 3.178 0 5.767-2.587 5.768-5.766.001-3.187-2.575-5.771-5.764-5.771zm3.392 8.244c-.144.405-.837.774-1.17.824-.299.045-.677.063-1.092-.069-.252-.08-.575-.187-.988-.365-1.739-.751-2.874-2.502-2.961-2.617-.087-.116-.708-.94-.708-1.793s.448-1.273.607-1.446c.159-.173.346-.217.462-.217l.332.006c.106.005.249-.04.39.298.144.347.491 1.2.534 1.287.043.087.072.188.014.304-.058.116-.087.188-.173.289l-.26.304c-.087.086-.177.18-.076.354.101.174.449.741.964 1.201.662.591 1.221.774 1.394.86s.275.072.376-.043c.101-.116.433-.506.549-.68.116-.173.231-.145.39-.087s1.011.477 1.184.564.289.13.332.202c.043.072.043.419-.101.824z"/></svg>
        </a>
      </div>
      <?php else: ?>

      <?php if ($trialError): ?>
      <div class="flash-msg flash-error mb-6"><?= htmlspecialchars($trialError) ?></div>
      <?php endif; ?>

      <form method="POST" action="#trial" class="space-y-6" onsubmit="if(this.dataset.submitted){return false;} this.dataset.submitted='true'; const btn=this.querySelector('button[type=submit]'); if(btn){ btn.style.pointerEvents='none'; btn.style.opacity='0.7'; btn.innerHTML='<span class=\'inline-block animate-spin mr-2\'>⏳</span> Submitting Free Trial Request...'; } return true;">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="trial_request">

        <!-- Fast-Track WhatsApp Alternative Banner (Fixes "false floor" issue) -->
        <div class="p-4 sm:p-5 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div class="flex items-center gap-3 text-left">
            <div class="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center flex-shrink-0">
              <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.182-.573c.978.58 1.911.928 3.145.929 3.178 0 5.767-2.587 5.768-5.766.001-3.187-2.575-5.771-5.764-5.771zm3.392 8.244c-.144.405-.837.774-1.17.824-.299.045-.677.063-1.092-.069-.252-.08-.575-.187-.988-.365-1.739-.751-2.874-2.502-2.961-2.617-.087-.116-.708-.94-.708-1.793s.448-1.273.607-1.446c.159-.173.346-.217.462-.217l.332.006c.106.005.249-.04.39.298.144.347.491 1.2.534 1.287.043.087.072.188.014.304-.058.116-.087.188-.173.289l-.26.304c-.087.086-.177.18-.076.354.101.174.449.741.964 1.201.662.591 1.221.774 1.394.86s.275.072.376-.043c.101-.116.433-.506.549-.68.116-.173.231-.145.39-.087s1.011.477 1.184.564.289.13.332.202c.043.072.043.419-.101.824z"/></svg>
            </div>
            <div>
              <div class="text-sm font-bold text-white">Prefer to skip the form?</div>
              <div class="text-xs text-gray-300">Send your raw bracketed photos directly to our 24/7 WhatsApp production desk.</div>
            </div>
          </div>
          <a href="<?= WHATSAPP_LINK ?>" target="_blank" rel="noopener noreferrer" class="btn-whatsapp whitespace-nowrap flex-shrink-0 text-xs uppercase tracking-wider font-black">
            <span>Fast WhatsApp Response</span>
          </a>
        </div>

        <!-- Step 1: Contact Details -->
        <div class="space-y-4 pt-2">
          <div class="flex items-center gap-2 pb-2 border-b border-dark-border text-gold font-bold text-xs tracking-wide">
            <span class="w-5 h-5 rounded-full bg-gold text-dark flex items-center justify-center font-mono font-black text-xs">1</span>
            <span>Your Contact Details</span>
          </div>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label for="trial-name" class="form-label">Full Name <span class="text-red-400">*</span></label>
              <input type="text" id="trial-name" name="name" class="form-input" placeholder="Alex Morgan" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>
            </div>
            <div>
              <label for="trial-email" class="form-label">Work Email <span class="text-red-400">*</span></label>
              <input type="email" id="trial-email" name="email" class="form-input" placeholder="alex@realty.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
            </div>
          </div>
          <div>
            <label for="trial-phone" class="form-label">WhatsApp / Phone Number <span class="text-xs text-gray-400 font-normal">(Optional — for instant delivery alerts)</span></label>
            <input type="text" id="trial-phone" name="phone" class="form-input" placeholder="+44 770 606 8176" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>">
          </div>
        </div>

        <!-- Step 2: Sample Media & Instructions -->
        <div class="space-y-4 pt-4">
          <div class="flex items-center gap-2 pb-2 border-b border-dark-border text-gold font-bold text-xs tracking-wide">
            <span class="w-5 h-5 rounded-full bg-gold text-dark flex items-center justify-center font-mono font-black text-xs">2</span>
            <span>Sample Photos &amp; Editing Instructions</span>
          </div>
          <div>
            <label for="trial-service" class="form-label">Service Required <span class="text-red-400">*</span></label>
            <div class="relative">
              <select id="trial-service" name="service" class="form-select appearance-none pr-10 w-full cursor-pointer" required>
                <option value="HDR Photo Editing">HDR Photo Editing &amp; Flambient Exposure Blending</option>
                <option value="Virtual Staging">Virtual Staging (3D Furniture &amp; Interior Decor)</option>
                <option value="Item Removal">Item Removal &amp; Decluttering</option>
                <option value="Virtual Twilight">Virtual Twilight (Golden Evening &amp; Sky Replacement)</option>
                <option value="Day to Dusk">Day to Dusk Conversion</option>
                <option value="Floor Plans & 3D Tours">Floor Plans &amp; 3D Schematics</option>
                <option value="Virtual Renovation">Virtual Renovation &amp; Remodeling</option>
              </select>
              <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-gold">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M19 9l-7 7-7-7"/></svg>
              </div>
            </div>
          </div>

          <div>
            <label for="trial-cloud-link" class="form-label">Cloud Link to Raw Photos (Google Drive / Dropbox / WeTransfer) <span class="text-red-400">*</span></label>
            <input type="url" id="trial-cloud-link" name="cloud_link" class="form-input" placeholder="https://drive.google.com/... or Dropbox / WeTransfer link" value="<?= htmlspecialchars($_POST['cloud_link'] ?? '') ?>" required>
            <p class="text-gray-300 text-xs mt-1.5">Paste link to 1-3 raw bracketed photos. Ensure link sharing is set to &ldquo;Anyone with link can view/download&rdquo;.</p>
          </div>

          <div>
            <label for="trial-notes" class="form-label">Specific Instructions / Notes <span class="text-xs text-gray-400 font-normal">(Optional)</span></label>
            <textarea id="trial-notes" name="notes" rows="3" class="form-input resize-y" placeholder="e.g. Please brighten window views, remove the driveway trash bin, keep warm wood tones..."><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
          </div>
        </div>

        <?= ehdr_render_honeypot() ?>
        <?= ehdr_render_turnstile('trial_request') ?>

        <div class="pt-4">
          <button type="submit" class="btn-gold w-full py-4 text-base font-black shadow-[0_4px_16px_rgba(201,168,76,0.35)] hover:shadow-[0_6px_22px_rgba(201,168,76,0.5)] border border-gold-light/40 inline-flex items-center justify-center gap-3 transition-all">
            <svg class="w-5 h-5 text-dark" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
            <span>Submit Free Trial Request (Guaranteed 24h Delivery)</span>
          </button>
        </div>
      </form>
      <?php endif; ?>
    </div>
  </div>
</section>

  <!-- ABOUT US TEASER SECTION (Topical Authority & EEAT) -->
  <section id="about" class="py-24 px-6 relative border-t border-dark-border bg-gradient-to-b from-dark to-dark-card/50">
    <div class="max-w-7xl mx-auto">
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div>
          <div class="section-tag mb-3">About Estate HDR</div>
          <h2 class="text-3xl sm:text-4xl font-bold text-white mb-6">
            Architectural Precision. <span class="text-gradient">24-Hour Delivery.</span>
          </h2>
          <div class="space-y-4 text-gray-300 text-sm sm:text-base leading-relaxed">
            <p>
              <strong>Who We Are:</strong> Estate HDR is an international architectural post-production lab operated by our parent company, <strong class="text-white">Estate HDR Studio Group Ltd</strong>. We partner directly with professional real estate photographers, premier brokerages, and MLS media agencies across North America, the UK, Europe, and Australasia.
            </p>
            <p>
              <strong>Our Story:</strong> Founded by real estate imaging veterans, we solved the photo editing bottleneck: delivering pristine window pulls, authentic color balance, and 100% human-verified quality within 24 hours guaranteed.
            </p>
            <p>
              <strong>What We Do:</strong> From multi-bracket flambient blending to 3D photorealistic virtual staging and sunset twilight conversions, every image is retouched on color-calibrated monitors under strict ISO 12646 soft-proofing standards.
            </p>
          </div>
          <div class="mt-8 flex flex-wrap items-center gap-4">
            <a href="/about" class="btn-gold py-3 px-6 text-sm font-bold shadow-glow inline-flex items-center gap-2">
              <span>Read Our Full Story &amp; Standards</span>
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
            </a>
            <a href="/team" class="btn-ghost py-3 px-6 text-sm font-semibold text-gray-300 hover:text-white">
              Meet Our Team &rarr;
            </a>
          </div>
        </div>
        <div class="grid grid-cols-2 gap-4">
          <div class="space-y-4">
            <div class="p-6 rounded-2xl bg-dark/70 border border-dark-border shadow-lg">
              <div class="text-3xl font-black text-gold">50,000+</div>
              <div class="text-xs text-gray-400 mt-1 font-semibold">Properties Processed</div>
              <p class="text-xs text-gray-400 mt-2">Delivered to MLS &amp; portals worldwide</p>
            </div>
            <div class="p-6 rounded-2xl bg-dark/70 border border-dark-border shadow-lg">
              <div class="text-3xl font-black text-gold">24 Hours</div>
              <div class="text-xs text-gray-400 mt-1 font-semibold">Turnaround Guarantee</div>
              <p class="text-xs text-gray-400 mt-2">Overnight shifts for next-day delivery</p>
            </div>
          </div>
          <div class="space-y-4 pt-6">
            <div class="p-6 rounded-2xl bg-dark/70 border border-dark-border shadow-lg">
              <div class="text-3xl font-black text-gold">4.9 / 5.0</div>
              <div class="text-xs text-gray-400 mt-1 font-semibold">Client Satisfaction</div>
              <p class="text-xs text-gray-400 mt-2">Verified rating across 500+ agencies</p>
            </div>
            <div class="p-6 rounded-2xl bg-dark/70 border border-dark-border shadow-lg">
              <div class="text-3xl font-black text-gold">100%</div>
              <div class="text-xs text-gray-400 mt-1 font-semibold">Human QA Inspected</div>
              <p class="text-xs text-gray-400 mt-2">2-tier quality control on every photo</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

</main>

<!-- FOOTER & REAL-TIME CHAT WIDGETS -->
<?php require_once __DIR__ . '/includes/public-footer.php'; ?>

<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
// Navbar scroll
window.addEventListener('scroll', () => {
  const nb = document.getElementById('navbar');
  if (nb) nb.classList.toggle('nav-scrolled', window.scrollY > 50);
});

// FAQ accordion
function toggleFaq(btn) {
  const answer = btn.nextElementSibling;
  const icon   = btn.querySelector('.faq-icon');
  const isOpen = !answer.classList.contains('hidden');
  document.querySelectorAll('.faq-answer').forEach(a => a.classList.add('hidden'));
  document.querySelectorAll('.faq-btn').forEach(b => b.setAttribute('aria-expanded', 'false'));
  document.querySelectorAll('.faq-icon').forEach(i => i.style.transform = '');
  if (!isOpen) {
    answer.classList.remove('hidden');
    btn.setAttribute('aria-expanded', 'true');
    if (icon) icon.style.transform = 'rotate(180deg)';
  }
}

// Universal Before/After slider initializer
function initSliders(scope) {
  const root = scope || document;
  root.querySelectorAll('[data-ba]').forEach(container => {
    if (container.hasAttribute('data-slider-ready')) {
      const after   = container.querySelector('.ba-after');
      const divider = container.querySelector('.ba-divider');
      if (divider && after) {
        divider.style.left = '50%';
        after.style.clipPath = 'inset(0 50% 0 0)';
      }
      return;
    }
    container.setAttribute('data-slider-ready', 'true');

    const after   = container.querySelector('.ba-after');
    const divider = container.querySelector('.ba-divider');
    if (!after || !divider) return;

    const move = (x) => {
      const rect = container.getBoundingClientRect();
      if (rect.width === 0) return;
      const pct  = Math.min(Math.max(((x - rect.left) / rect.width) * 100, 0), 100);
      divider.style.left = pct + '%';
      after.style.clipPath = `inset(0 ${100 - pct}% 0 0)`;
    };

    const onStart = (e) => {
      const isTouch = e.type === 'touchstart';
      const onMove = (ev) => {
        const cx = isTouch && ev.touches ? ev.touches[0].clientX : ev.clientX;
        move(cx);
      };
      const onEnd = () => {
        window.removeEventListener(isTouch ? 'touchmove' : 'mousemove', onMove);
        window.removeEventListener(isTouch ? 'touchend' : 'mouseup', onEnd);
      };
      window.addEventListener(isTouch ? 'touchmove' : 'mousemove', onMove, { passive: true });
      window.addEventListener(isTouch ? 'touchend' : 'mouseup', onEnd, { once: true });
    };

    divider.addEventListener('mousedown', onStart);
    divider.addEventListener('touchstart', onStart, { passive: true });
    
    // Initial 50% placement
    divider.style.left = '50%';
    after.style.clipPath = 'inset(0 50% 0 0)';
  });
}

// Portfolio Tab Switcher (Global Function)
function switchPortfolioTab(targetId) {
  // Toggle button styles and ARIA attributes
  document.querySelectorAll('.portfolio-tab-btn').forEach(b => {
    const isTarget = b.getAttribute('data-portfolio') === targetId;
    b.setAttribute('aria-selected', isTarget ? 'true' : 'false');
    if (isTarget) {
      b.classList.add('active', 'border-gold', 'bg-gold', 'text-dark', 'shadow-glow');
      b.classList.remove('border-dark-border', 'bg-dark-card', 'text-gray-300');
    } else {
      b.classList.remove('active', 'border-gold', 'bg-gold', 'text-dark', 'shadow-glow');
      b.classList.add('border-dark-border', 'bg-dark-card', 'text-gray-300');
    }
  });

  // Toggle panels
  document.querySelectorAll('.portfolio-category-panel').forEach(panel => {
    if (panel.id === targetId) {
      panel.classList.remove('hidden');
      panel.style.animation = 'ehdrPageEnter 0.26s cubic-bezier(0.16, 1, 0.3, 1) forwards';
      if (window.initEstateHDRSliders) {
        window.initEstateHDRSliders(panel);
      } else {
        initSliders(panel);
      }
    } else {
      panel.classList.add('hidden');
      panel.style.animation = '';
    }
  });
}

// Master Pricing Mode Switcher (Calculator vs Packages)
function switchPricingMode(mode) {
  const calcView  = document.getElementById('pricing-view-calc');
  const tiersView = document.getElementById('pricing-view-tiers');
  const btnCalc   = document.getElementById('btn-mode-calc');
  const btnTiers  = document.getElementById('btn-mode-tiers');

  if (mode === 'calc') {
    if (calcView)  {
      calcView.classList.remove('hidden');
      calcView.style.animation = 'ehdrPageEnter 0.26s cubic-bezier(0.16, 1, 0.3, 1) forwards';
    }
    if (tiersView) tiersView.classList.add('hidden');
    if (btnCalc) {
      btnCalc.className = 'px-6 py-2.5 rounded-xl text-xs sm:text-sm font-black transition-all bg-gold text-dark shadow-glow flex items-center gap-2';
    }
    if (btnTiers) {
      btnTiers.className = 'px-6 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-gray-400 hover:text-white transition-all flex items-center gap-2';
    }
  } else {
    if (calcView)  calcView.classList.add('hidden');
    if (tiersView) {
      tiersView.classList.remove('hidden');
      tiersView.style.animation = 'ehdrPageEnter 0.26s cubic-bezier(0.16, 1, 0.3, 1) forwards';
    }
    if (btnCalc) {
      btnCalc.className = 'px-6 py-2.5 rounded-xl text-xs sm:text-sm font-bold text-gray-400 hover:text-white transition-all flex items-center gap-2';
    }
    if (btnTiers) {
      btnTiers.className = 'px-6 py-2.5 rounded-xl text-xs sm:text-sm font-black transition-all bg-gold text-dark shadow-glow flex items-center gap-2';
    }
  }
}
window.switchPricingMode = switchPricingMode;

// Pricing Tab Switcher (Global Function)
function switchPricingTab(targetId) {
  document.querySelectorAll('.pricing-tab-btn').forEach(b => {
    const isTarget = b.getAttribute('data-target') === targetId;
    b.setAttribute('aria-selected', isTarget ? 'true' : 'false');
    if (isTarget) {
      b.classList.add('active', 'border-gold', 'bg-gold', 'text-dark', 'shadow-glow');
      b.classList.remove('border-dark-border', 'bg-dark-card', 'text-gray-300');
    } else {
      b.classList.remove('active', 'border-gold', 'bg-gold', 'text-dark', 'shadow-glow');
      b.classList.add('border-dark-border', 'bg-dark-card', 'text-gray-300');
    }
  });

  document.querySelectorAll('.pricing-category-grid').forEach(grid => {
    if (grid.id === targetId) {
      grid.classList.remove('hidden');
    } else {
      grid.classList.add('hidden');
    }
  });
}

// Bind click listeners when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  const activePanel = document.querySelector('.portfolio-category-panel:not(.hidden)') || document.getElementById('port-hdr');
  if (activePanel) initSliders(activePanel);

  document.querySelectorAll('.portfolio-tab-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const tid = btn.getAttribute('data-portfolio');
      if (tid) switchPortfolioTab(tid);
    });
  });

  document.querySelectorAll('.pricing-tab-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const tid = btn.getAttribute('data-target');
      if (tid) switchPricingTab(tid);
    });
  });
});

// Ensure Hero Video Autoplays Smoothly without blocking initial paint
const heroVideo = document.getElementById('heroBgVideo');
if (heroVideo && window.innerWidth >= 768) {
  const startVideo = () => {
    if (heroVideo.dataset.loaded) return;
    heroVideo.dataset.loaded = 'true';
    heroVideo.preload = 'auto';
    heroVideo.play().catch(() => {
      ['click', 'touchstart', 'scroll'].forEach(evt => {
        window.addEventListener(evt, () => {
          if (heroVideo.paused) heroVideo.play().catch(() => {});
        }, { once: true, passive: true });
      });
    });
  };
  if (document.readyState === 'complete') {
    setTimeout(startVideo, 300);
  } else {
    window.addEventListener('load', () => setTimeout(startVideo, 300), { once: true });
  }
}
</script>

<!-- Deferred Background Video Ingestion -->
<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">
window.addEventListener('load', function() {
  setTimeout(function() {
    var v = document.getElementById('heroBgVideo');
    if (v) {
      var s = v.querySelector('source[data-src]');
      if (s) {
        s.src = s.dataset.src;
        v.load();
        var p = v.play();
        if (p !== undefined) { p.catch(function(){}); }
      }
    }
  }, 1200);
});
</script>

</body>
</html>
