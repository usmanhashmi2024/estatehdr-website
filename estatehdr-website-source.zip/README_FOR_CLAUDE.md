# README FOR CLAUDE - ESTATE HDR WEBSITE SOURCE REPOSITORY

> **NOTICE FOR CLAUDE AI:**
> This repository contains the complete, sanitized production source code of the live website **https://estatehdr.com**.
> **CRITICAL DIRECTIVE:** DO NOT invent final pricing or commercial terms. Always reference [`data/services.json`](file:///data/services.json) and [`pricing.php`](file:///pricing.php) for baseline rates, and request explicit site owner approval before proposing or deploying any production modifications.

---

## 1. Verified Project Identity & Source Path

- **Brand:** Estate HDR (Architectural & Real Estate Post-Production Studio)
- **Live Production URL:** `https://estatehdr.com`
- **Hosting Infrastructure:** Hostinger Business Web Hosting (LiteSpeed Web Server + Cloudflare CDN/WAF)
- **Verified Source Repository Path:** `C:\Users\uzith\Documents\Estate HDR Site`
- **Project Scope Verification:**
  - **This project (`Estate HDR Site`):** Deployed live web application, client portal, order flow, pricing engine, blog CMS, and REST APIs.
  - **Distinct Offline AI Pipeline (`C:\EstateHDR_OfflineAI_Platform`):** Dedicated PyTorch training and bracket fusion inference platform (NOT part of website runtime).
  - **Desktop / Offline Software (`Estate HDR Software` / `estate-management-software`):** Standalone offline desktop utilities (NOT part of website runtime).

---

## 2. Tech Stack & Prerequisites

| Layer | Technology | Details |
|---|---|---|
| **Backend Runtime** | PHP 8.2+ | Vanilla PHP, strict typing where configured, no heavyweight frameworks |
| **Web Server** | LiteSpeed / Apache 2.4+ | Configured via root [`.htaccess`](file:///.htaccess) with rewrite rules & security headers |
| **Frontend Styling** | Tailwind CSS 3.4+ | CDN-loaded + [`assets/css/app.css`](file:///assets/css/app.css) (120Hz spring motion tokens) |
| **Frontend Scripting** | Vanilla JavaScript (ES2022) | [`assets/js/animations.js`](file:///assets/js/animations.js), Lenis smooth scroll, View Transitions |
| **Database Architecture** | Hybrid: Flat-File JSON + MySQL Ready | Primary production engine uses atomic JSON flat-files under [`data/`](file:///data/). SQL schemas available in [`includes/schema.sql`](file:///includes/schema.sql) |
| **Anti-Bot & Security** | Cloudflare Turnstile + SecurityHeaders | Enforced via [`includes/security/SecurityHeaders.php`](file:///includes/security/SecurityHeaders.php) and CSP |

---

## 3. Local Setup & Run Commands

### Recommended (PHP Built-in Server with Local Router)
```bash
# From repository root:
php -S 127.0.0.1:8000 local_router.php
```
Visit `http://127.0.0.1:8000` in your browser. The included [`local_router.php`](file:///local_router.php) emulates Apache/LiteSpeed URL rewrites, routing `/about` to `about.php`, `/portfolio` to `portfolio.php`, and `/api/v1/...` to `api/v1/index.php`.

### Alternative: XAMPP / Apache VirtualHost *(Tested on Windows)*
1. Symlink or copy repository root to `C:\xampp\htdocs\estatehdr`.
2. Ensure `mod_rewrite`, `mod_headers`, and `mod_expires` are enabled in `httpd.conf`.
3. Set `AllowOverride All` for the document root directory.
4. Access via `http://localhost/estatehdr/` or configure local VirtualHost.

---

## 4. Required Environment Variables (.env / Constants)

All production secrets have been replaced with sanitized dummy values. To test external integrations locally, create a `.env` file based on [`.env.example`](file:///.env.example):

```ini
APP_ENV=development
APP_DEBUG=true
APP_URL=http://127.0.0.1:8000

# Cloudflare Turnstile (Test dummy keys pass automatically in test mode)
TURNSTILE_SITE_KEY=0x4AAAAAAAxxxxxxxxxxxxxx
TURNSTILE_SECRET_KEY=0x4AAAAAAAxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Security Signing Secret (Minimum 32 random characters)
FORM_TOKEN_SECRET=your_32_character_cryptographically_secure_secret_key

# SMTP Configuration (Hostinger / Titan / Mailgun)
SMTP_HOST=smtp.hostinger.com
SMTP_PORT=465
SMTP_USER=info@estatehdr.com
SMTP_PASS=your_smtp_password_here
SMTP_SECURE=ssl

# Discord Desk Notifications (Optional)
DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/dummy_id/dummy_token
```

---

## 5. Database Setup & Test/Sandbox Requirements

1. **Flat-File JSON Storage (`data/`):**
   - The application writes and reads JSON arrays in [`data/`](file:///data/).
   - Sanitized, syntactically valid schema templates are pre-packaged:
     - `data/users.json` (Includes demo client login)
     - `data/admin_users.json` (Includes demo admin login: `admin` / `DemoAdmin@2026!`)
     - `data/services.json` (11 core real estate editing services with pricing and FAQs)
     - `data/categories.json` & `data/blogs.json` (Live blog CMS records)
     - `data/pages_seo.json` & `data/seo_settings.json` (SEO metadata repository)
2. **Relational MySQL Alternative (`includes/schema.sql`):**
   - If migrating or connecting to a relational database, import [`includes/schema.sql`](file:///includes/schema.sql) and [`includes/database-schema.sql`](file:///includes/database-schema.sql).

---

## 6. Key Code Paths: SEO, Pricing, and User Journeys

### A. Search Engine Optimization (SEO) & AI Discovery
- **Robots & AI Protocols:** [`robots.php`](file:///robots.php), [`robots.txt`](file:///robots.txt), [`llms.txt`](file:///llms.txt), [`llms-full.txt`](file:///llms-full.txt)
- **Dynamic XML Sitemaps:**
  - Index: [`sitemap_index.php`](file:///sitemap_index.php) / [`sitemap.xml`](file:///sitemap.xml)
  - Pages: [`sitemap-pages.php`](file:///sitemap-pages.php)
  - Services: [`sitemap-services.php`](file:///sitemap-services.php)
  - Blog Posts: [`sitemap-posts.php`](file:///sitemap-posts.php)
  - Portfolio Images: [`sitemap-images.php`](file:///sitemap-images.php)
- **Structured Data / JSON-LD:** Implemented across [`about.php`](file:///about.php), [`team.php`](file:///team.php), [`blog-post.php`](file:///blog-post.php), and [`service.php`](file:///service.php) using EEAT organization & author entities.
- **Canonical & Meta Generator:** [`includes/seo-helper.php`](file:///includes/seo-helper.php) (`renderSeoHeadTags()`).

### B. Pricing Estimator & Service Catalog
- **Interactive Pricing Calculator UI:** [`pricing.php`](file:///pricing.php) & [`includes/pricing-calculator.php`](file:///includes/pricing-calculator.php)
- **Pricing Engine Logic:** [`includes/pricing-engine.php`](file:///includes/pricing-engine.php)
- **Service Definitions & Volume Discount Scales:** [`data/services.json`](file:///data/services.json)

### C. Client Acquisition & Conversion Journey
- **Landing Page:** [`index.php`](file:///index.php) (Hero, Before/After Interactive Sliders, Trust Badges, FAQ)
- **Portfolio Showcase:** [`portfolio.php`](file:///portfolio.php)
- **Client Registration & Onboarding:** [`register.php`](file:///register.php)
- **Authentication & Sessions:** [`login.php`](file:///login.php), [`logout.php`](file:///logout.php), [`includes/auth.php`](file:///includes/auth.php)
- **Order Placement & Upload Pipeline:** [`order-new.php`](file:///order-new.php), [`api/upload-image.php`](file:///api/upload-image.php)
- **Client Management Dashboard:** [`dashboard.php`](file:///dashboard.php), [`order-view.php`](file:///order-view.php), [`billing.php`](file:///billing.php)
- **Contact & Lead Processing:** [`contact.php`](file:///contact.php), [`api/crm-form-submit.php`](file:///api/crm-form-submit.php)

### D. Administrative & Supervisor Workflows
- **Master Admin Portal:** [`admin/index.php`](file:///admin/index.php)
- **Supervisor Job Queue (Watermark vs Final Photos):** [`admin/supervisor-dashboard.php`](file:///admin/supervisor-dashboard.php)
- **Order Processing:** [`admin/orders.php`](file:///admin/orders.php), [`admin/order-view.php`](file:///admin/order-view.php)
- **SEO & Blog Management:** [`admin/posts.php`](file:///admin/posts.php), [`admin/post-edit.php`](file:///admin/post-edit.php), [`admin/seo-sitemap.php`](file:///admin/seo-sitemap.php)

---

## 7. Known Missing Dependencies & Deployment Limitations

1. **LiteSpeed Rewrite Context:**
   - Hostinger utilizes LiteSpeed Web Server. Top-level URL routing MUST maintain explicit `RewriteRule ^portfolio/?$ portfolio.php [L,QSA]` directives in [`.htaccess`](file:///.htaccess). LiteSpeed per-directory execution can fail with generic `%{REQUEST_FILENAME}.php -f` condition checks.
2. **Third-Party CDN Dependencies:**
   - Tailwind CSS CDN and Google Fonts (`Inter`) require an active internet connection.
   - Content Security Policy (CSP) in [`includes/security/SecurityHeaders.php`](file:///includes/security/SecurityHeaders.php) is calibrated to allow CDN scripts, Google Fonts, and Google Tag Manager.
3. **Optimized Media Assets:**
   - Large hero video (`hero.mp4`) and repetitive portfolio images were omitted to satisfy GitHub web upload constraints (< 25MB). Paired sample portfolio photos (1 & 2 before/after) are included so sliders and UI components work out of the box.

---

## 8. Crucial Instruction for Claude

> **DO NOT INVENT PRICING, DISCOUNTS, OR COMMERCIAL PROMISES.**
> - All service prices, bracket packages, turnaround times, and free trial offers are governed by [`data/services.json`](file:///data/services.json) and site leadership.
> - Any suggested modification to pricing algorithms, discounts, checkout logic, or database schemas must be presented as a proposal and requires explicit approval from the site owner before committing or pushing to production.
