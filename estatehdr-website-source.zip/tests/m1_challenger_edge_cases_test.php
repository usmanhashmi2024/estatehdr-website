<?php
/**
 * Milestone M1 Challenger Edge Cases, Boundary Conditions, and Stress Test Suite
 */

error_reporting(E_ALL);
ini_set('display_errors', '1');

// Setup session for tests
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';

$totalPassed = 0;
$totalFailed = 0;
$failures = [];

function check(bool $condition, string $testName, string $details = ''): void {
    global $totalPassed, $totalFailed, $failures;
    if ($condition) {
        $totalPassed++;
        echo "  [PASS] $testName\n";
    } else {
        $totalFailed++;
        $failures[] = "$testName: $details";
        echo "  [FAIL] $testName - $details\n";
    }
}

echo "=================================================================\n";
echo " MILESTONE M1 EMPIRICAL EDGE CASE & BOUNDARY STRESS TEST SUITE\n";
echo "=================================================================\n\n";

// =========================================================================
// 1. DATE FILTERS & TIME BOUNDARY CONDITIONS
// =========================================================================
echo "=== 1. Testing Date Filters & Edge Timestamps (filterVisitorSessions) ===\n";

$fixedNow = strtotime('2026-08-25 15:00:00');
$today = '2026-08-25';
$yesterday = '2026-08-24';
$eightDaysAgo = '2026-08-17';
$fortyDaysAgo = '2026-07-16';

$mockVisitors = [
    'v_today' => [
        'visitor_id' => 'v_today',
        'date' => $today,
        'last_seen_ts' => $fixedNow - 30,
        'hits' => 5,
        'time_spent' => 120,
        'ip' => '192.168.1.1',
        'country' => 'United States',
        'city' => 'Austin',
        'device' => 'Desktop',
        'browser' => 'Chrome',
        'referrer' => 'https://google.com',
        'current_page' => '/services/hdr-photo-editing'
    ],
    'v_yesterday' => [
        'visitor_id' => 'v_yesterday',
        'date' => $yesterday,
        'last_seen_ts' => $fixedNow - 86400,
        'hits' => 2,
        'time_spent' => 60,
        'ip' => '192.168.1.2',
        'country' => 'United Kingdom',
        'city' => 'London',
        'device' => 'Mobile',
        'browser' => 'Safari',
        'referrer' => 'Direct Visit',
        'current_page' => '/pricing.php'
    ],
    'v_7days' => [
        'visitor_id' => 'v_7days',
        'date' => '2026-08-20',
        'last_seen_ts' => $fixedNow - (5 * 86400),
        'hits' => 10,
        'time_spent' => 300,
        'ip' => '192.168.1.3',
        'country' => 'Canada',
        'city' => 'Toronto',
        'device' => 'Tablet',
        'browser' => 'Edge',
        'referrer' => 'https://facebook.com',
        'current_page' => '/'
    ],
    'v_old' => [
        'visitor_id' => 'v_old',
        'date' => $fortyDaysAgo,
        'last_seen_ts' => $fixedNow - (40 * 86400),
        'hits' => 1,
        'time_spent' => 10,
        'ip' => '192.168.1.4',
        'country' => 'Australia',
        'city' => 'Sydney',
        'device' => 'Desktop',
        'browser' => 'Firefox',
        'referrer' => 'Direct Visit',
        'current_page' => '/contact.php'
    ],
    'v_malformed' => [
        // Missing date, invalid time_spent, missing IP, etc.
        'visitor_id' => 'v_malformed',
        'first_seen' => '2026-08-25 10:00:00',
        'time_spent' => 'not_a_number',
        'hits' => -5,
        'country' => null,
        'city' => null
    ]
];

// Test empty visitor array
$emptyRes = filterVisitorSessions([], 'today', '', '', $fixedNow);
check($emptyRes['total_sessions'] === 0 && $emptyRes['unique_ips_count'] === 0 && $emptyRes['avg_seconds'] === 0, "Empty visitors array handled cleanly");

// Test 'today' filter (should match v_today and v_malformed fallback to first_seen today)
$todayRes = filterVisitorSessions($mockVisitors, 'today', '', '', $fixedNow);
check($todayRes['total_sessions'] === 2, "Today filter matched correct count (2)", "Got " . $todayRes['total_sessions']);
check(isset($todayRes['filtered_visitors']['v_today']), "Today filter includes v_today");
check(isset($todayRes['filtered_visitors']['v_malformed']), "Malformed visitor with first_seen today included");

// Test 'yesterday' filter
$yestRes = filterVisitorSessions($mockVisitors, 'yesterday', '', '', $fixedNow);
check($yestRes['total_sessions'] === 1 && isset($yestRes['filtered_visitors']['v_yesterday']), "Yesterday filter matched exactly v_yesterday");

// Test '7days' filter (should match v_today, v_yesterday, v_7days, v_malformed)
$sevenRes = filterVisitorSessions($mockVisitors, '7days', '', '', $fixedNow);
check($sevenRes['total_sessions'] === 4, "7days filter matched 4 sessions", "Got " . $sevenRes['total_sessions']);

// Test '30days' filter
$thirtyRes = filterVisitorSessions($mockVisitors, '30days', '', '', $fixedNow);
check($thirtyRes['total_sessions'] === 4 && !isset($thirtyRes['filtered_visitors']['v_old']), "30days filter excludes v_old (40 days ago)");

// Test 'month' filter
$monthRes = filterVisitorSessions($mockVisitors, 'month', '', '', $fixedNow);
check($monthRes['total_sessions'] === 4, "Month filter matched 2026-08 records");

// Test 'custom' valid range
$customRes = filterVisitorSessions($mockVisitors, 'custom', '2026-08-19', '2026-08-24', $fixedNow);
check($customRes['total_sessions'] === 2 && isset($customRes['filtered_visitors']['v_yesterday']) && isset($customRes['filtered_visitors']['v_7days']), "Custom date range matched correct window");

// Test 'custom' with inverted start > end (should return 0)
$invertedRes = filterVisitorSessions($mockVisitors, 'custom', '2026-08-25', '2026-08-01', $fixedNow);
check($invertedRes['total_sessions'] === 0, "Inverted custom range gracefully returns 0 sessions");

// Test 'custom' with empty end date (open-ended onwards)
$openEndRes = filterVisitorSessions($mockVisitors, 'custom', '2026-08-24', '', $fixedNow);
check($openEndRes['total_sessions'] === 3, "Open-ended custom start matched all sessions on or after start");

// Test breakdowns & aggregation metrics
check($todayRes['devices']['Desktop'] >= 1, "Device breakdown counted Desktop");
check($todayRes['countries']['United States'] === 1, "Country breakdown counted United States");
check($todayRes['cities']['Austin'] === 1, "City breakdown counted Austin");
check($todayRes['pages']['/services/hdr-photo-editing'] === 1, "Pages breakdown counted target URL");

// Test 10,000 generated visitors for memory and performance
$largeVisitorMap = [];
for ($i = 0; $i < 10000; $i++) {
    $largeVisitorMap["vis_$i"] = [
        'visitor_id' => "vis_$i",
        'date' => ($i % 2 === 0) ? $today : $yesterday,
        'last_seen_ts' => $fixedNow - ($i * 10),
        'hits' => ($i % 5) + 1,
        'time_spent' => ($i % 120),
        'ip' => "10.0." . ($i % 255) . "." . (($i * 3) % 255),
        'country' => ($i % 3 === 0) ? 'United States' : 'United Kingdom',
        'city' => ($i % 2 === 0) ? 'New York' : 'London',
        'device' => ($i % 2 === 0) ? 'Desktop' : 'Mobile',
        'browser' => 'Chrome',
        'referrer' => 'Direct Visit',
        'current_page' => '/services/hdr'
    ];
}
$t0 = microtime(true);
$largeRes = filterVisitorSessions($largeVisitorMap, 'today', '', '', $fixedNow);
$perfTime = microtime(true) - $t0;
check($largeRes['total_sessions'] === 5000, "10,000 records processed correctly (5,000 today)");
check($perfTime < 0.2, "10,000 records filtered under 200ms (took " . round($perfTime * 1000, 2) . "ms)");

// =========================================================================
// 2. 3-STATE PRESENCE ENGINE BOUNDARY TESTING
// =========================================================================
echo "\n=== 2. Testing 3-State Presence Engine (calculateLivePresenceStats) ===\n";

$presenceTests = [
    'v_exact_0' => ['visitor_id' => 'v_exact_0', 'last_seen_ts' => $fixedNow],                 // delta = 0 -> Active
    'v_exact_60' => ['visitor_id' => 'v_exact_60', 'last_seen_ts' => $fixedNow - 60],          // delta = 60 -> Active
    'v_exact_61' => ['visitor_id' => 'v_exact_61', 'last_seen_ts' => $fixedNow - 61],          // delta = 61 -> Idle
    'v_exact_180' => ['visitor_id' => 'v_exact_180', 'last_seen_ts' => $fixedNow - 180],       // delta = 180 -> Idle
    'v_exact_181' => ['visitor_id' => 'v_exact_181', 'last_seen_ts' => $fixedNow - 181],       // delta = 181 -> Offline
    'v_future' => ['visitor_id' => 'v_future', 'last_seen_ts' => $fixedNow + 500],             // delta < 0 -> max(0, -500) = 0 -> Active
    'v_chat_active' => ['visitor_id' => 'v_chat_active', 'last_seen_ts' => $fixedNow - 200],    // delta = 200 (<= 300) + active chat -> Chatting
    'v_chat_expired_vis' => ['visitor_id' => 'v_chat_expired_vis', 'last_seen_ts' => $fixedNow - 301] // delta = 301 (>300) + active chat -> Offline
];

$presenceChats = [
    'v_chat_active' => [
        'session_id' => 'CHAT-ACT',
        'status' => 'active',
        'last_active_ts' => $fixedNow - 50
    ],
    'v_chat_expired_vis' => [
        'session_id' => 'CHAT-EXP',
        'status' => 'active',
        'last_active_ts' => $fixedNow - 10
    ]
];

$presRes = calculateLivePresenceStats($presenceTests, $presenceChats, $fixedNow);
check($presRes['active_count'] === 3, "Active count is 3 (v_exact_0, v_exact_60, v_future)", "Got " . $presRes['active_count']);
check($presRes['idle_count'] === 2, "Idle count is 2 (v_exact_61, v_exact_180)", "Got " . $presRes['idle_count']);
check($presRes['chatting_count'] === 1, "Chatting count is 1 (v_chat_active)", "Got " . $presRes['chatting_count']);
check($presRes['offline_count'] === 2, "Offline count is 2 (v_exact_181, v_chat_expired_vis)", "Got " . $presRes['offline_count']);
check($presRes['online_now'] === 4, "Online now is 4 (active 3 + chatting 1)", "Got " . $presRes['online_now']);
check($presRes['total_tracked'] === 8, "Total tracked is 8");

// Empty check
$emptyPres = calculateLivePresenceStats([], [], $fixedNow);
check($emptyPres['online_now'] === 0 && $emptyPres['total_tracked'] === 0, "Empty visitors/chats returns zeros");

// =========================================================================
// 3. OMNICHANNEL CHAT & FRT KPIS
// =========================================================================
echo "\n=== 3. Testing Omnichannel Chat & FRT KPIs (calculateChatKpis) ===\n";

$mockChatsAll = [
    'c1' => [
        'session_id' => 'c1',
        'channel' => 'webchat',
        'has_unread_for_agent' => true,
        'last_active_ts' => $fixedNow - 100,
        'messages' => [
            ['sender' => 'user', 'ts' => $fixedNow - 200],
            ['sender' => 'agent', 'ts' => $fixedNow - 170] // 30s response
        ]
    ],
    'c2' => [
        'session_id' => 'c2',
        'channel' => 'WhatsApp',
        'has_unread_for_agent' => false,
        'last_active_ts' => $fixedNow - 500,
        'messages' => [
            ['sender' => 'user', 'ts' => $fixedNow - 500],
            ['sender' => 'agent', 'ts' => $fixedNow - 450] // 50s response
        ]
    ],
    'c3' => [
        'session_id' => 'c3',
        'channel' => 'email',
        'has_unread_for_agent' => true,
        'status' => 'active',
        'last_active_ts' => $fixedNow - 4000, // > 3600 but status is 'active' -> active chat
        'messages' => [
            ['sender' => 'user', 'ts' => $fixedNow - 4000] // No agent response yet
        ]
    ],
    'c4' => [
        'session_id' => 'c4',
        'channel' => 'sms',
        'has_unread_for_agent' => false,
        'status' => 'closed',
        'last_active_ts' => $fixedNow - 50000,
        'messages' => [
            ['sender' => 'agent', 'ts' => $fixedNow - 50000], // Agent spoke first
            ['sender' => 'user', 'ts' => $fixedNow - 49000]
        ]
    ]
];

$chatKpis = calculateChatKpis($mockChatsAll, 'all', $fixedNow);
check($chatKpis['total_conversations'] === 4, "Total conversations counted 4");
check($chatKpis['unread_alerts_count'] === 2, "Unread alerts counted 2 (c1, c3)");
check($chatKpis['active_chats_now'] === 3, "Active chats counted 3 (c1, c2, c3 active status)");
check($chatKpis['channel_breakdown']['webchat'] === 1, "Channel webchat counted 1");
check($chatKpis['channel_breakdown']['whatsapp'] === 1, "Channel whatsapp counted 1 (case-insensitive)");
check($chatKpis['channel_breakdown']['email'] === 1, "Channel email counted 1");
check($chatKpis['channel_breakdown']['sms'] === 1, "Channel sms counted 1");
check($chatKpis['frt_sample_size'] === 2, "FRT sample size is 2 (c1: 30s, c2: 50s)");
check($chatKpis['avg_frt_seconds'] === 40, "Average FRT is 40s ((30+50)/2)");
check($chatKpis['avg_frt_formatted'] === '40s', "Average FRT formatted as 40s");

// Empty chat fallback test
$emptyChatKpis = calculateChatKpis([], 'all', $fixedNow);
check($emptyChatKpis['total_conversations'] === 0, "Empty chats returns 0 conversations");
check($emptyChatKpis['avg_frt_seconds'] === 42, "Empty chats returns studio benchmark FRT (42s)");

// =========================================================================
// 4. CSAT & SLA RATINGS
// =========================================================================
echo "\n=== 4. Testing CSAT & SLA Rating Calculations (calculateCsatKpi) ===\n";

// Empty fallback to benchmark
$emptyCsat = calculateCsatKpi([], []);
check($emptyCsat['csat_percentage'] === 98.4, "Empty ratings fallback to 98.4%");
check($emptyCsat['is_benchmark'] === true, "is_benchmark is true on empty");

// Mixed ratings from chats and tickets
$csatChats = [
    ['rating' => 5],
    ['rating' => 4],
    ['rating' => 3],
    ['rating' => 'invalid_string'],
    ['rating' => 0], // out of range (< 1.0)
    ['rating' => 10] // out of range (> 5.0)
];
$csatTickets = [
    ['satisfaction_score' => 5],
    ['satisfaction_score' => 5]
];
// Valid ratings: 5, 4, 3, 5, 5 (Total 5 ratings: 4 are >= 4.0 -> 80.0%, Avg = 4.4)
$csatRes = calculateCsatKpi($csatChats, $csatTickets);
check($csatRes['sample_count'] === 5, "Sample count filtered to 5 valid ratings", "Got " . $csatRes['sample_count']);
check($csatRes['csat_percentage'] === 80.0, "CSAT percentage calculated 80.0%", "Got " . $csatRes['csat_percentage']);
check($csatRes['csat_average'] === 4.4, "CSAT average calculated 4.4", "Got " . $csatRes['csat_average']);
check($csatRes['is_benchmark'] === false, "is_benchmark is false when valid samples exist");

// =========================================================================
// 5. TICKET KPIS & SLA BREACH DETECTION
// =========================================================================
echo "\n=== 5. Testing Ticket KPIs & SLA Breaches (calculateTicketKpis) ===\n";

$mockTickets = [
    't_urgent_breached' => [
        'id' => 'T-1',
        'status' => 'open',
        'priority' => 'urgent',
        'first_response_due_at' => date('Y-m-d H:i:s', $fixedNow - 600), // Due 10m ago
        'first_responded_at' => null
    ],
    't_high_approaching' => [
        'id' => 'T-2',
        'status' => 'in_progress',
        'priority' => 'high',
        'first_response_due_at' => date('Y-m-d H:i:s', $fixedNow - 300),
        'first_responded_at' => date('Y-m-d H:i:s', $fixedNow - 350), // Responded in time
        'resolution_due_at' => date('Y-m-d H:i:s', $fixedNow + 1200), // Due in 20m (< 30m -> approaching breach)
        'resolved_at' => null
    ],
    't_resolved_past_due' => [
        'id' => 'T-3',
        'status' => 'resolved',
        'priority' => 'urgent',
        'resolution_due_at' => date('Y-m-d H:i:s', $fixedNow - 3600),
        'resolved_at' => date('Y-m-d H:i:s', $fixedNow - 4000)
    ]
];

$tKpis = calculateTicketKpis($mockTickets, $fixedNow);
check($tKpis['total_tickets'] === 3, "Total tickets counted 3");
check($tKpis['open_tickets_count'] === 2, "Open tickets counted 2 (resolved excluded)");
check($tKpis['urgent_count'] === 1, "Urgent open count is 1");
check($tKpis['high_count'] === 1, "High open count is 1");
check($tKpis['breached_count'] === 1, "Breached count is 1 (t_urgent_breached)");
check($tKpis['approaching_breach_count'] === 1, "Approaching breach count is 1 (t_high_approaching)");

// Empty tickets test
$emptyTKpis = calculateTicketKpis([], $fixedNow);
check($emptyTKpis['total_tickets'] === 0 && $emptyTKpis['open_tickets_count'] === 0 && $emptyTKpis['breached_count'] === 0, "Empty tickets handled with 0s");

// =========================================================================
// 6. LEAD & CRM PIPELINE KPIS (DIV-BY-ZERO SAFETY)
// =========================================================================
echo "\n=== 6. Testing Lead & CRM Pipeline KPIs (calculateLeadKpis) ===\n";

// Test zero division safety
$emptyLeadKpis = calculateLeadKpis([], []);
check($emptyLeadKpis['total_leads'] === 0, "Empty leads/contacts total 0");
check($emptyLeadKpis['conversion_rate_pct'] === 0.0, "Conversion rate on zero leads is 0.0% (no div-by-zero error)");

$mockLeads = [
    ['id' => 'L-1', 'status' => 'delivered'], // won
    ['id' => 'L-2', 'status' => 'pending'],   // new (active)
    ['id' => 'L-3', 'status' => 'contacted'], // contacted (active)
    ['id' => 'L-4', 'status' => 'lost']       // lost
];
$mockContacts = [
    ['id' => 'C-1', 'stage' => 'qualified'],  // qualified (active)
    ['id' => 'C-2', 'stage' => 'won']         // won
];
// Total = 6, Won = 2 (delivered + won) -> 33.3%, Active = 3 (pending + contacted + qualified)
$leadKpis = calculateLeadKpis($mockLeads, $mockContacts);
check($leadKpis['total_leads'] === 6, "Total leads + contacts counted 6");
check($leadKpis['active_leads_count'] === 3, "Active leads counted 3");
check($leadKpis['pipeline_breakdown']['won'] === 2, "Won count is 2");
check($leadKpis['pipeline_breakdown']['new'] === 1, "New count is 1");
check($leadKpis['pipeline_breakdown']['contacted'] === 1, "Contacted count is 1");
check($leadKpis['pipeline_breakdown']['qualified'] === 1, "Qualified count is 1");
check($leadKpis['pipeline_breakdown']['lost'] === 1, "Lost count is 1");
check($leadKpis['conversion_rate_pct'] === 33.3, "Conversion rate calculated 33.3% ((2/6)*100)");

// =========================================================================
// 7. DURATION FORMATTER STRESS
// =========================================================================
echo "\n=== 7. Testing formatDurationHelper Edge Cases ===\n";
check(formatDurationHelper(0) === '0s', "formatDurationHelper(0) -> '0s'");
check(formatDurationHelper(-10) === '0s', "formatDurationHelper(-10) -> '0s'");
check(formatDurationHelper(45) === '45s', "formatDurationHelper(45) -> '45s'");
check(formatDurationHelper(60) === '1m 0s', "formatDurationHelper(60) -> '1m 0s'");
check(formatDurationHelper(125) === '2m 5s', "formatDurationHelper(125) -> '2m 5s'");
check(formatDurationHelper(3600) === '1h 0m', "formatDurationHelper(3600) -> '1h 0m'");
check(formatDurationHelper(7325) === '2h 2m', "formatDurationHelper(7325) -> '2h 2m'");

// =========================================================================
// 8. SAVELEAD DUAL SIGNATURE STRESS
// =========================================================================
echo "\n=== 8. Testing saveLead Dual Signature Robustness ===\n";

$savedLeadsBackup = getLeads();

// 1. Positional call with special characters
$posLead = saveLead(
    "O'Connor & Sons <HDR>",
    'oconnor@example.com',
    '+1 (555) 019-2834',
    'Virtual Staging / Dusk HDR',
    'https://drive.google.com/drive/folders/test?id=1&name=O\'Connor',
    'Please enhance with warm dusk & fireplace glow "quoted text"'
);
check(isset($posLead['id']) && $posLead['name'] === "O'Connor & Sons <HDR>", "Positional saveLead preserved special chars");

// 2. Associative array call with missing optional fields
$arrLead = saveLead([
    'name' => 'Dr. Jane Smith',
    'email' => 'jane.smith@realtygroup.com'
]);
check(isset($arrLead['id']) && $arrLead['name'] === 'Dr. Jane Smith' && $arrLead['email'] === 'jane.smith@realtygroup.com', "Array saveLead with minimum fields created valid record");

// 3. Associative array call with extra unexpected fields
$arrLeadExtra = saveLead([
    'name' => 'Alex Turner',
    'email' => 'alex@turnerestates.co.uk',
    'phone' => '+44 20 7946 0912',
    'custom_crm_tag' => 'VIP_BROKER',
    'lead_score' => 85
]);
check($arrLeadExtra['name'] === 'Alex Turner', "Array saveLead with extra fields handled cleanly");

// Cleanup test leads
saveLeads($savedLeadsBackup);

// =========================================================================
// 9. ADMIN/LIVE-VISITORS.PHP RBAC & FULL RENDER VERIFICATION
// =========================================================================
echo "\n=== 9. Testing admin/live-visitors.php Execution & RBAC ===\n";

// Verify unauthenticated access protection
// Unset session admin privileges
unset($_SESSION['is_admin']);
unset($_SESSION['admin_user']);
unset($_SESSION['user']);

// We test requireManagerOrAdmin in a separate sub-process to avoid exit() terminating this test
$phpBin = 'C:\\xampp\\php\\php.exe';
$scriptCmd = "\"$phpBin\" -r \"session_start(); require_once 'includes/config.php'; require_once 'includes/auth.php'; require_once 'includes/db.php'; require_once 'includes/admin-header.php'; requireManagerOrAdmin(); echo 'SHOULD_NOT_REACH_HERE';\"";
$unauthOutput = shell_exec($scriptCmd);
check(!str_contains((string)$unauthOutput, 'SHOULD_NOT_REACH_HERE'), "Unauthenticated access prevented by requireManagerOrAdmin redirect");

// Now test full rendering with admin session under error_reporting(E_ALL)
$_SESSION['is_admin'] = true;
$_SESSION['admin_user'] = [
    'id' => 'adm_super',
    'name' => 'Command Center Tester',
    'email' => 'super@estatehdr.com',
    'roles' => ['owner', 'super_admin']
];

ob_start();
require __DIR__ . '/../admin/live-visitors.php';
$adminHtml = ob_get_clean();

check(str_contains($adminHtml, 'id="tabOverview"'), "Tab 1: Overview rendered");
check(str_contains($adminHtml, 'id="tabRadar"'), "Tab 2: Radar rendered");
check(str_contains($adminHtml, 'id="tabInbox"'), "Tab 3: Inbox rendered");
check(str_contains($adminHtml, 'id="tabCrm"'), "Tab 4: CRM rendered");
check(str_contains($adminHtml, 'id="tabTriggers"'), "Tab 5: Triggers rendered");
check(str_contains($adminHtml, 'id="tabTickets"'), "Tab 6: Tickets rendered");

check(str_contains($adminHtml, 'Active Online'), "KPI Card 1: Active Online rendered");
check(str_contains($adminHtml, 'Total Traffic'), "KPI Card 2: Total Traffic rendered");
check(str_contains($adminHtml, 'Avg Dwell Time'), "KPI Card 3: Avg Dwell Time rendered");
check(str_contains($adminHtml, 'Omnichannel'), "KPI Card 4: Omnichannel FRT rendered");
check(str_contains($adminHtml, 'CSAT Rating'), "KPI Card 5: CSAT Rating rendered");
check(str_contains($adminHtml, 'Tickets &amp; Leads') || str_contains($adminHtml, 'Tickets & Leads'), "KPI Card 6: Tickets & Leads rendered");

check(str_contains($adminHtml, 'function switchCommandTab'), "switchCommandTab JS function present");
check(str_contains($adminHtml, 'function playNotificationChime'), "Web Audio API notification chime present");
check(str_contains($adminHtml, 'function pollAdminLiveChat'), "Live chat polling JS present");

// =========================================================================
// SUMMARY & VERDICT
// =========================================================================
echo "\n=================================================================\n";
echo " TEST RUN SUMMARY\n";
echo "=================================================================\n";
echo "Total Checks: " . ($totalPassed + $totalFailed) . "\n";
echo "Passed:       $totalPassed\n";
echo "Failed:       $totalFailed\n";

if ($totalFailed > 0) {
    echo "\nFailures:\n";
    foreach ($failures as $f) {
        echo " - $f\n";
    }
    exit(1);
} else {
    echo "\n>>> ALL CHALLENGER EDGE CASES AND BOUNDARY CHECKS PASSED <<<\n";
    exit(0);
}
