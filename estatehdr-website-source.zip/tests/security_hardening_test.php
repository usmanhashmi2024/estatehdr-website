<?php
/**
 * Estate HDR — Comprehensive Automated Security Test Suite & Penetration Simulation
 * Validates Honeypot Traps, Bot Timing, Spam Scoring, Rate Limiting, MIME Guard, SVG Sanitizer, and CSRF.
 */

declare(strict_types=1);

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/security/bootstrap.php';

use EstateHDR\Security\SecurityConfig;
use EstateHDR\Security\SpamDetector;
use EstateHDR\Security\RateLimiter;
use EstateHDR\Security\AntiBotProvider;
use EstateHDR\Security\Validator;
use EstateHDR\Security\FileUploadGuard;
use EstateHDR\Security\SecurityHeaders;
use EstateHDR\Security\SecurityLogger;

$testsPassed = 0;
$testsFailed = 0;
$results = [];

function assertTest(string $testName, bool $condition, string $detail = '') {
    global $testsPassed, $testsFailed, $results;
    if ($condition) {
        $testsPassed++;
        $results[] = "[PASS] {$testName} - {$detail}";
        echo "\033[32m[PASS]\033[0m {$testName} " . ($detail ? "({$detail})" : "") . "\n";
    } else {
        $testsFailed++;
        $results[] = "[FAIL] {$testName} - {$detail}";
        echo "\033[31m[FAIL]\033[0m {$testName} " . ($detail ? "({$detail})" : "") . "\n";
    }
}

echo "===============================================================\n";
echo " Estate HDR Security & Anti-Bot Hardening Test Suite\n";
echo "===============================================================\n\n";

// ── Test 1: Honeypot Trap Detection ───────────────────────────
$botPayloadWithHoneypot = [
    'name' => 'Automated Bot',
    'email' => 'bot@spammer.org',
    'website_url_hp' => 'http://spam-link.com', // Sprung trap
    'cloud_link' => 'https://drive.google.com/test'
];
$hpResult = SpamDetector::checkHoneypots($botPayloadWithHoneypot);
assertTest('Honeypot Detection', $hpResult === true, 'Detected populated website_url_hp honeypot field');

$cleanPayload = [
    'name' => 'Craig Westerman',
    'email' => 'craig@agency.com',
    'website_url_hp' => '',
    'cloud_link' => 'https://drive.google.com/test'
];
$hpClean = SpamDetector::checkHoneypots($cleanPayload);
assertTest('Honeypot Clean Submission', $hpClean === false, 'Ignored empty honeypot field');

// ── Test 2: Request Timing & Velocity Check ──────────────────
$timeToken = SpamDetector::generateTimeToken();
$timeCheck = SpamDetector::validateTimeToken($timeToken);
// Should fail with < 3s when checked instantly
assertTest('Velocity Bot Detection', $timeCheck['valid'] === false, 'Blocked instant bot submission (< 3s)');

// Test with forged HMAC
$forgedToken = base64_encode(time() . ':fake_hmac_signature');
$forgeCheck = SpamDetector::validateTimeToken($forgedToken);
assertTest('Forged Time Token Rejection', $forgeCheck['valid'] === false, 'Rejected invalid HMAC signature');

// ── Test 3: SEO Link Farm & Spam Keyword Analyzer ─────────────
$spamCasinoPayload = [
    'name' => 'Slot Gacor 88',
    'email' => 'seo@marketingbot.com',
    'message' => 'Check our slot88 online casino betting bonus http://slotgacor.top and win big!',
    'cloud_link' => 'https://drive.google.com/test'
];
$spamAnalysis = SpamDetector::analyzeSubmission($spamCasinoPayload);
assertTest('Casino / Gambling Spam Detection', $spamAnalysis['is_spam'] === true && $spamAnalysis['score'] >= 50, "Risk score: {$spamAnalysis['score']}");

$spamSeoPayload = [
    'name' => 'SEO Outreach',
    'email' => 'backlinks@rankings.xyz',
    'message' => 'We offer guest post outreach and high da pbn backlinks for real estate ranking',
    'cloud_link' => 'https://drive.google.com/test'
];
$seoAnalysis = SpamDetector::analyzeSubmission($spamSeoPayload);
assertTest('SEO Link Farm Outreach Detection', $seoAnalysis['is_spam'] === true, "Risk score: {$seoAnalysis['score']}");

// ── Test 4: Disposable / Burner Email Blocker ─────────────────
$burnerEmails = ['test@mailinator.com', 'user@10minutemail.com', 'spam@tempmail.com', 'alex@guerrillamail.com'];
$burnerBlocked = true;
foreach ($burnerEmails as $bEmail) {
    if (!SpamDetector::isDisposableEmail($bEmail)) {
        $burnerBlocked = false;
        break;
    }
}
assertTest('Disposable Email Domain Blocklist', $burnerBlocked, 'Successfully identified burner domains');

$legitEmail = 'craig@cbre-realty.com';
assertTest('Legit Email Domain Pass', !SpamDetector::isDisposableEmail($legitEmail), 'Allowed legitimate corporate domain');

// ── Test 5: Sliding-Window Rate Limiter ───────────────────────
$testIp = '198.51.100.' . rand(10, 200);
$limitReached = false;
for ($i = 0; $i < 7; $i++) {
    $res = RateLimiter::check('trial_request', $testIp);
    if (!$res['allowed']) {
        $limitReached = true;
        break;
    }
}
assertTest('Sliding Window Rate Limiter', $limitReached === true, 'Throttled requests exceeding limit of 5 per 15m');

// ── Test 6: Input Validation & Sanitization ───────────────────
$xssInput = [
    'name' => 'Alex <script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">alert("XSS")</script>',
    'email' => 'alex@example.com',
    'phone' => '+44 (770) 606-8176',
    'cloud_link' => 'https://drive.google.com/drive/folders/123xyz',
    'message' => 'Clean note with <b>bold</b> text'
];
$valResult = Validator::validateLeadSubmission($xssInput, true);
assertTest('XSS Sanitization', $valResult['valid'] === true && !str_contains($valResult['sanitized']['name'], '<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">'), 'Stripped dangerous HTML tags');

// ── Test 7: SVG Sanitization against Script & XXE Injection ──
$maliciousSvg = <<<SVG
<svg xmlns="http://www.w3.org/2000/svg">
  <script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">alert(document.cookie);</script>
  <circle cx="50" cy="50" r="40" onload="alert('pwned')"/>
  <a href="javascript:alert(1)"><text x="10" y="20">Click</text></a>
</svg>
SVG;
$sanitizedSvg = FileUploadGuard::sanitizeSvg($maliciousSvg);
$svgSafe = !str_contains($sanitizedSvg, '<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">') && !str_contains($sanitizedSvg, 'onload') && !str_contains($sanitizedSvg, 'javascript:');
assertTest('SVG XSS / Event Handler Sanitization', $svgSafe, 'Neutralized script tags and onload handlers');

// ── Test 8: CSP Security Headers Generation ───────────────────
$csp = SecurityHeaders::buildCspPolicy();
$cspValid = str_contains($csp, 'challenges.cloudflare.com') && str_contains($csp, 'cdn.tailwindcss.com') && str_contains($csp, 'object-src \'none\'');
assertTest('Content Security Policy (CSP) Directives', $cspValid, 'Verified Turnstile and Tailwind CDN compatibility');

// ── Test 9: Structured Security Event Logging ─────────────────
SecurityLogger::log('test_security_audit', 'INFO', 'Security hardening verification event', ['test_key' => 'verified']);
$logFile = DATA_PATH . 'security/security_events.jsonl';
$logExists = file_exists($logFile) && filesize($logFile) > 0;
assertTest('Structured Security Logger (JSONL)', $logExists, 'Recorded telemetry to data/security/security_events.jsonl');

// ── Test 10: SSRF & Private IP / Metadata Protection ──────────
$ssrfAttackUrls = [
    'http://127.0.0.1:8080/admin',
    'http://localhost/secret',
    'http://169.254.169.254/latest/meta-data/',
    'http://192.168.1.1/router',
    'http://10.0.0.1/internal'
];
$allSsrfBlocked = true;
foreach ($ssrfAttackUrls as $badUrl) {
    if (Validator::validateCloudLink($badUrl)) {
        $allSsrfBlocked = false;
        break;
    }
}
assertTest('SSRF & Internal Cloud Metadata Defense', $allSsrfBlocked, 'Blocked localhost, 169.254.169.254 & private IP ranges');

$validDriveUrl = 'https://drive.google.com/drive/folders/1A2B3C4D5E6F';
assertTest('Legitimate Public Cloud Link Pass', Validator::validateCloudLink($validDriveUrl), 'Allowed genuine Google Drive link');

// ── Test 11: Session Fingerprint Tamper Detection ─────────────
$realUa = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) EstateHDR-Agent';
$_SERVER['HTTP_USER_AGENT'] = $realUa;
loginUser(['id' => 'CL-TEST', 'name' => 'Test User', 'email' => 'test@user.com']);
$validSession = isLoggedIn();

// Simulate session hijacking by altering User-Agent in attacker environment
$_SERVER['HTTP_USER_AGENT'] = 'Hacker-Kali-Linux-Attacker-Tool/1.0';
$hijackedSession = isLoggedIn(); // Should detect mismatch, destroy session, and return false

assertTest('Session Hijacking & Fingerprint Shield', $validSession === true && $hijackedSession === false, 'Detected altered User-Agent and immediately terminated hijacked session');

echo "\n===============================================================\n";
echo " Test Results: {$testsPassed} Passed, {$testsFailed} Failed\n";
echo "===============================================================\n";

if ($testsFailed > 0) {
    exit(1);
}
exit(0);
