<?php
/**
 * Milestone M1 Adversarial & Boundary Stress Test Suite
 * Estate HDR Visitor Intelligence Hub Transformation
 *
 * Executes empirical boundary tests, mathematical edge cases, concurrency stress,
 * and multi-state dashboard rendering.
 */

// Enable strict error reporting
error_reporting(E_ALL);
ini_set('display_errors', '1');

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';

$totalPassed = 0;
$totalFailed = 0;

function runTest(string $description, callable $fn) {
    global $totalPassed, $totalFailed;
    try {
        $fn();
        echo "  [PASS] $description\n";
        $totalPassed++;
    } catch (Throwable $e) {
        echo "  [FAIL] $description: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine() . "\n";
        $totalFailed++;
    }
}

echo "====================================================================\n";
echo "ESTATE HDR - MILESTONE M1 ADVERSARIAL & BOUNDARY TEST SUITE\n";
echo "====================================================================\n\n";

// ─────────────────────────────────────────────────────────────────
// SECTION 1: PRESENCE ENGINE BOUNDARY TIMESTAMP TESTS
// ─────────────────────────────────────────────────────────────────
echo "--- Section 1: Presence Engine Boundary & Anomaly Tests ---\n";

$baseNow = 1700000000;

runTest("Presence: delta = 0s (exact now) -> Active", function() use ($baseNow) {
    $visitors = ['v0' => ['visitor_id' => 'v0', 'last_seen_ts' => $baseNow]];
    $res = calculateLivePresenceStats($visitors, [], $baseNow);
    if ($res['active_count'] !== 1 || $res['idle_count'] !== 0 || $res['offline_count'] !== 0 || $res['online_now'] !== 1) {
        throw new Exception("Expected active=1, got " . json_encode($res));
    }
});

runTest("Presence: delta = 59s -> Active", function() use ($baseNow) {
    $visitors = ['v59' => ['visitor_id' => 'v59', 'last_seen_ts' => $baseNow - 59]];
    $res = calculateLivePresenceStats($visitors, [], $baseNow);
    if ($res['active_count'] !== 1 || $res['idle_count'] !== 0 || $res['offline_count'] !== 0) {
        throw new Exception("Expected active=1, got " . json_encode($res));
    }
});

runTest("Presence: delta = 60s (exact active boundary) -> Active", function() use ($baseNow) {
    $visitors = ['v60' => ['visitor_id' => 'v60', 'last_seen_ts' => $baseNow - 60]];
    $res = calculateLivePresenceStats($visitors, [], $baseNow);
    if ($res['active_count'] !== 1 || $res['idle_count'] !== 0 || $res['offline_count'] !== 0) {
        throw new Exception("Expected active=1 at 60s, got " . json_encode($res));
    }
});

runTest("Presence: delta = 61s (exact idle threshold) -> Idle", function() use ($baseNow) {
    $visitors = ['v61' => ['visitor_id' => 'v61', 'last_seen_ts' => $baseNow - 61]];
    $res = calculateLivePresenceStats($visitors, [], $baseNow);
    if ($res['active_count'] !== 0 || $res['idle_count'] !== 1 || $res['offline_count'] !== 0 || $res['online_now'] !== 0) {
        throw new Exception("Expected idle=1 at 61s, got " . json_encode($res));
    }
});

runTest("Presence: delta = 179s -> Idle", function() use ($baseNow) {
    $visitors = ['v179' => ['visitor_id' => 'v179', 'last_seen_ts' => $baseNow - 179]];
    $res = calculateLivePresenceStats($visitors, [], $baseNow);
    if ($res['active_count'] !== 0 || $res['idle_count'] !== 1 || $res['offline_count'] !== 0) {
        throw new Exception("Expected idle=1 at 179s, got " . json_encode($res));
    }
});

runTest("Presence: delta = 180s (exact idle boundary) -> Idle", function() use ($baseNow) {
    $visitors = ['v180' => ['visitor_id' => 'v180', 'last_seen_ts' => $baseNow - 180]];
    $res = calculateLivePresenceStats($visitors, [], $baseNow);
    if ($res['active_count'] !== 0 || $res['idle_count'] !== 1 || $res['offline_count'] !== 0) {
        throw new Exception("Expected idle=1 at 180s, got " . json_encode($res));
    }
});

runTest("Presence: delta = 181s (exact offline threshold) -> Offline", function() use ($baseNow) {
    $visitors = ['v181' => ['visitor_id' => 'v181', 'last_seen_ts' => $baseNow - 181]];
    $res = calculateLivePresenceStats($visitors, [], $baseNow);
    if ($res['active_count'] !== 0 || $res['idle_count'] !== 0 || $res['offline_count'] !== 1 || $res['online_now'] !== 0) {
        throw new Exception("Expected offline=1 at 181s, got " . json_encode($res));
    }
});

runTest("Presence: delta = 300s (no chat) -> Offline", function() use ($baseNow) {
    $visitors = ['v300' => ['visitor_id' => 'v300', 'last_seen_ts' => $baseNow - 300]];
    $res = calculateLivePresenceStats($visitors, [], $baseNow);
    if ($res['offline_count'] !== 1 || $res['online_now'] !== 0) {
        throw new Exception("Expected offline=1 at 300s, got " . json_encode($res));
    }
});

runTest("Presence: delta = 300s + Active Chat (chat active 200s ago) -> Chatting", function() use ($baseNow) {
    $visitors = ['vc' => ['visitor_id' => 'vc', 'last_seen_ts' => $baseNow - 300]];
    $chats = ['vc' => ['visitor_id' => 'vc', 'status' => 'active', 'last_active_ts' => $baseNow - 200]];
    $res = calculateLivePresenceStats($visitors, $chats, $baseNow);
    if ($res['chatting_count'] !== 1 || $res['online_now'] !== 1 || $res['offline_count'] !== 0) {
        throw new Exception("Expected chatting=1, online_now=1, got " . json_encode($res));
    }
});

runTest("Presence: delta = 301s + Active Chat -> Offline (visitor abandoned connection)", function() use ($baseNow) {
    $visitors = ['vc_off' => ['visitor_id' => 'vc_off', 'last_seen_ts' => $baseNow - 301]];
    $chats = ['vc_off' => ['visitor_id' => 'vc_off', 'status' => 'active', 'last_active_ts' => $baseNow - 200]];
    $res = calculateLivePresenceStats($visitors, $chats, $baseNow);
    if ($res['chatting_count'] !== 0 || $res['offline_count'] !== 1 || $res['online_now'] !== 0) {
        throw new Exception("Expected offline=1 at delta 301s, got " . json_encode($res));
    }
});

runTest("Presence: Future Timestamp (client clock skew: ts = now + 120s) -> Clamped to Active", function() use ($baseNow) {
    $visitors = ['v_future' => ['visitor_id' => 'v_future', 'last_seen_ts' => $baseNow + 120]];
    $res = calculateLivePresenceStats($visitors, [], $baseNow);
    if ($res['active_count'] !== 1 || $res['online_now'] !== 1) {
        throw new Exception("Expected future ts clamped to active, got " . json_encode($res));
    }
});

runTest("Presence: Missing last_seen_ts with string last_seen -> Parsed correctly", function() use ($baseNow) {
    $dateStr = date('Y-m-d H:i:s', $baseNow - 40);
    $visitors = ['v_str' => ['visitor_id' => 'v_str', 'last_seen' => $dateStr]];
    $res = calculateLivePresenceStats($visitors, [], $baseNow);
    if ($res['active_count'] !== 1) {
        throw new Exception("Expected active=1 from string last_seen, got " . json_encode($res));
    }
});

runTest("Presence: Missing / Malformed timestamp -> Fallback to Offline safely", function() use ($baseNow) {
    $visitors = [
        'v_null' => ['visitor_id' => 'v_null'],
        'v_junk' => ['visitor_id' => 'v_junk', 'last_seen' => 'invalid-date-format', 'last_seen_ts' => null]
    ];
    $res = calculateLivePresenceStats($visitors, [], $baseNow);
    if ($res['offline_count'] !== 2 || $res['total_tracked'] !== 2) {
        throw new Exception("Expected offline=2, got " . json_encode($res));
    }
});

runTest("Presence: Empty Visitors Array -> All 0 counts without notices", function() use ($baseNow) {
    $res = calculateLivePresenceStats([], [], $baseNow);
    if ($res['online_now'] !== 0 || $res['total_tracked'] !== 0) {
        throw new Exception("Expected all 0s, got " . json_encode($res));
    }
});


// ─────────────────────────────────────────────────────────────────
// SECTION 2: FIRST RESPONSE TIME (FRT) STRESS MATRIX
// ─────────────────────────────────────────────────────────────────
echo "\n--- Section 2: First Response Time (FRT) Stress Matrix ---\n";

runTest("FRT: Empty chats array -> Baseline Studio Default 42s", function() {
    $res = calculateChatKpis([]);
    if ($res['avg_frt_seconds'] !== 42 || $res['frt_sample_size'] !== 0 || $res['avg_frt_formatted'] !== '42s') {
        throw new Exception("Expected 42s fallback, got " . json_encode($res));
    }
});

runTest("FRT: Chat with user message only (agent not responded yet) -> Excluded from sample", function() use ($baseNow) {
    $chats = [
        'c1' => [
            'visitor_id' => 'c1',
            'channel' => 'webchat',
            'messages' => [
                ['sender' => 'user', 'text' => 'Hello?', 'ts' => $baseNow - 50]
            ]
        ]
    ];
    $res = calculateChatKpis($chats, 'all', $baseNow);
    if ($res['frt_sample_size'] !== 0 || $res['avg_frt_seconds'] !== 42) {
        throw new Exception("Expected sample_size=0, got " . json_encode($res));
    }
});

runTest("FRT: Chat with proactive agent greeting only -> Excluded from sample", function() use ($baseNow) {
    $chats = [
        'c1' => [
            'visitor_id' => 'c1',
            'channel' => 'webchat',
            'messages' => [
                ['sender' => 'agent', 'text' => 'Hi! How can I help?', 'ts' => $baseNow - 100]
            ]
        ]
    ];
    $res = calculateChatKpis($chats, 'all', $baseNow);
    if ($res['frt_sample_size'] !== 0 || $res['avg_frt_seconds'] !== 42) {
        throw new Exception("Expected sample_size=0, got " . json_encode($res));
    }
});

runTest("FRT: Instant response (0s delta) -> Calculated as 0s", function() use ($baseNow) {
    $chats = [
        'c_inst' => [
            'visitor_id' => 'c_inst',
            'channel' => 'webchat',
            'messages' => [
                ['sender' => 'user', 'text' => 'Fast inquiry', 'ts' => $baseNow - 30],
                ['sender' => 'agent', 'text' => 'Instant response', 'ts' => $baseNow - 30]
            ]
        ]
    ];
    $res = calculateChatKpis($chats, 'all', $baseNow);
    if ($res['frt_sample_size'] !== 1 || $res['avg_frt_seconds'] !== 0 || $res['avg_frt_formatted'] !== '0s') {
        throw new Exception("Expected 0s FRT, got " . json_encode($res));
    }
});

runTest("FRT: Multiple user messages before first agent response -> Measured from first user message", function() use ($baseNow) {
    $chats = [
        'c_multi_u' => [
            'visitor_id' => 'c_multi_u',
            'channel' => 'webchat',
            'messages' => [
                ['sender' => 'user', 'text' => 'Msg 1', 'ts' => $baseNow - 100], // firstUserTs
                ['sender' => 'user', 'text' => 'Msg 2', 'ts' => $baseNow - 80],
                ['sender' => 'user', 'text' => 'Msg 3', 'ts' => $baseNow - 60],
                ['sender' => 'agent', 'text' => 'Agent Reply', 'ts' => $baseNow - 45] // 55s diff
            ]
        ]
    ];
    $res = calculateChatKpis($chats, 'all', $baseNow);
    if ($res['frt_sample_size'] !== 1 || $res['avg_frt_seconds'] !== 55 || $res['avg_frt_formatted'] !== '55s') {
        throw new Exception("Expected 55s FRT, got " . json_encode($res));
    }
});

runTest("FRT: Multiple agent messages after user -> Measured to first agent response only", function() use ($baseNow) {
    $chats = [
        'c_multi_a' => [
            'visitor_id' => 'c_multi_a',
            'channel' => 'webchat',
            'messages' => [
                ['sender' => 'user', 'text' => 'Inquiry', 'ts' => $baseNow - 100], // firstUserTs
                ['sender' => 'agent', 'text' => 'First reply', 'ts' => $baseNow - 85], // 15s diff
                ['sender' => 'agent', 'text' => 'Followup', 'ts' => $baseNow - 50]
            ]
        ]
    ];
    $res = calculateChatKpis($chats, 'all', $baseNow);
    if ($res['frt_sample_size'] !== 1 || $res['avg_frt_seconds'] !== 15 || $res['avg_frt_formatted'] !== '15s') {
        throw new Exception("Expected 15s FRT, got " . json_encode($res));
    }
});

runTest("FRT: Out-of-order timestamps (corrupted data: agent ts < user ts) -> Ignored safely", function() use ($baseNow) {
    $chats = [
        'c_corrupt' => [
            'visitor_id' => 'c_corrupt',
            'channel' => 'webchat',
            'messages' => [
                ['sender' => 'user', 'text' => 'Inquiry', 'ts' => $baseNow - 10],
                ['sender' => 'agent', 'text' => 'Past reply', 'ts' => $baseNow - 100] // invalid order
            ]
        ]
    ];
    $res = calculateChatKpis($chats, 'all', $baseNow);
    if ($res['frt_sample_size'] !== 0 || $res['avg_frt_seconds'] !== 42) {
        throw new Exception("Expected negative diff ignored, got " . json_encode($res));
    }
});

runTest("FRT: Outlier > 24 hours (86400s) -> Excluded from average", function() use ($baseNow) {
    $chats = [
        'c_outlier' => [
            'visitor_id' => 'c_outlier',
            'channel' => 'webchat',
            'messages' => [
                ['sender' => 'user', 'text' => 'Ancient inquiry', 'ts' => $baseNow - 200000],
                ['sender' => 'agent', 'text' => 'Late reply', 'ts' => $baseNow - 1000] // diff > 86400
            ]
        ]
    ];
    $res = calculateChatKpis($chats, 'all', $baseNow);
    if ($res['frt_sample_size'] !== 0) {
        throw new Exception("Expected >24h diff excluded, got " . json_encode($res));
    }
});

runTest("FRT: Multi-conversation average calculation (10s, 30s, 80s -> avg 40s)", function() use ($baseNow) {
    $chats = [
        'c1' => [
            'visitor_id' => 'c1', 'channel' => 'webchat',
            'messages' => [
                ['sender' => 'user', 'ts' => $baseNow - 100],
                ['sender' => 'agent', 'ts' => $baseNow - 90] // diff 10s
            ]
        ],
        'c2' => [
            'visitor_id' => 'c2', 'channel' => 'whatsapp',
            'messages' => [
                ['sender' => 'user', 'ts' => $baseNow - 200],
                ['sender' => 'agent', 'ts' => $baseNow - 170] // diff 30s
            ]
        ],
        'c3' => [
            'visitor_id' => 'c3', 'channel' => 'email',
            'messages' => [
                ['sender' => 'user', 'ts' => $baseNow - 300],
                ['sender' => 'agent', 'ts' => $baseNow - 220] // diff 80s
            ]
        ]
    ];
    $res = calculateChatKpis($chats, 'all', $baseNow);
    if ($res['frt_sample_size'] !== 3 || $res['avg_frt_seconds'] !== 40 || $res['avg_frt_formatted'] !== '40s') {
        throw new Exception("Expected avg 40s, got " . json_encode($res));
    }
    if ($res['channel_breakdown']['webchat'] !== 1 || $res['channel_breakdown']['whatsapp'] !== 1 || $res['channel_breakdown']['email'] !== 1) {
        throw new Exception("Channel breakdown mismatch: " . json_encode($res['channel_breakdown']));
    }
});


// ─────────────────────────────────────────────────────────────────
// SECTION 3: CSAT SATISFACTION FALLBACKS & BOUND TESTS
// ─────────────────────────────────────────────────────────────────
echo "\n--- Section 3: CSAT Satisfaction Fallbacks & Bound Tests ---\n";

runTest("CSAT: Empty chats & tickets -> 98.4% studio benchmark default", function() {
    $res = calculateCsatKpi([], []);
    if ($res['csat_percentage'] !== 98.4 || $res['csat_average'] !== 4.9 || $res['is_benchmark'] !== true || $res['sample_count'] !== 0) {
        throw new Exception("Expected benchmark default, got " . json_encode($res));
    }
});

runTest("CSAT: Invalid ratings (0, -1, 6, 'five', null) -> Ignored, fallback to benchmark", function() {
    $chats = [
        ['rating' => 0],
        ['rating' => -2],
        ['rating' => 6],
        ['rating' => 'excellent'],
        ['rating' => null]
    ];
    $tickets = [
        ['satisfaction_score' => 0],
        ['satisfaction_score' => 10],
        ['satisfaction_score' => 'bad']
    ];
    $res = calculateCsatKpi($chats, $tickets);
    if ($res['is_benchmark'] !== true || $res['sample_count'] !== 0) {
        throw new Exception("Expected invalid ratings filtered out, got " . json_encode($res));
    }
});

runTest("CSAT: Full spectrum ratings [1.0, 2.0, 3.0, 4.0, 5.0] -> 40.0% CSAT, 3.0 avg", function() {
    $chats = [
        ['rating' => 1.0],
        ['rating' => 2.0],
        ['rating' => 3.0]
    ];
    $tickets = [
        ['satisfaction_score' => 4.0],
        ['satisfaction_score' => 5.0]
    ];
    $res = calculateCsatKpi($chats, $tickets);
    if ($res['sample_count'] !== 5 || $res['csat_percentage'] !== 40.0 || $res['csat_average'] !== 3.0 || $res['is_benchmark'] !== false) {
        throw new Exception("Expected CSAT 40.0%, avg 3.0, got " . json_encode($res));
    }
});

runTest("CSAT: 100% positive ratings -> 100.0% CSAT, 5.0 stars", function() {
    $chats = [
        ['rating' => 5.0],
        ['rating' => 5.0]
    ];
    $tickets = [
        ['satisfaction_score' => 5.0]
    ];
    $res = calculateCsatKpi($chats, $tickets);
    if ($res['csat_percentage'] !== 100.0 || $res['csat_average'] !== 5.0) {
        throw new Exception("Expected 100.0%, got " . json_encode($res));
    }
});

runTest("CSAT: 0% positive ratings (all 1-star) -> 0.0% CSAT, 1.0 stars", function() {
    $chats = [['rating' => 1.0], ['rating' => 1.0]];
    $res = calculateCsatKpi($chats, []);
    if ($res['csat_percentage'] !== 0.0 || $res['csat_average'] !== 1.0) {
        throw new Exception("Expected 0.0%, got " . json_encode($res));
    }
});


// ─────────────────────────────────────────────────────────────────
// SECTION 4: SUPPORT TICKETING & SLA KPI TESTS
// ─────────────────────────────────────────────────────────────────
echo "\n--- Section 4: Support Ticketing & SLA KPI Tests ---\n";

runTest("Tickets: Empty tickets array -> All 0s safely", function() use ($baseNow) {
    $res = calculateTicketKpis([], $baseNow);
    if ($res['total_tickets'] !== 0 || $res['open_tickets_count'] !== 0 || $res['breached_count'] !== 0) {
        throw new Exception("Expected 0s, got " . json_encode($res));
    }
});

runTest("Tickets: SLA Breach Detection (overdue first response / resolution)", function() use ($baseNow) {
    $tickets = [
        // Ticket 1: Open, overdue first response -> Breached
        't1' => [
            'id' => 'TCK-1',
            'status' => 'open',
            'priority' => 'urgent',
            'first_response_due_at' => date('Y-m-d H:i:s', $baseNow - 600), // 10 mins ago
            'first_responded_at' => null
        ],
        // Ticket 2: In progress, overdue resolution -> Breached
        't2' => [
            'id' => 'TCK-2',
            'status' => 'in_progress',
            'priority' => 'high',
            'first_response_due_at' => date('Y-m-d H:i:s', $baseNow - 3600),
            'first_responded_at' => date('Y-m-d H:i:s', $baseNow - 3500),
            'resolution_due_at' => date('Y-m-d H:i:s', $baseNow - 300), // 5 mins ago
            'resolved_at' => null
        ],
        // Ticket 3: In progress, resolution due in 15 mins (<30m) -> Approaching Breach
        't3' => [
            'id' => 'TCK-3',
            'status' => 'in_progress',
            'priority' => 'normal',
            'first_response_due_at' => date('Y-m-d H:i:s', $baseNow - 3600),
            'first_responded_at' => date('Y-m-d H:i:s', $baseNow - 3500),
            'resolution_due_at' => date('Y-m-d H:i:s', $baseNow + 900), // 15 mins in future
            'resolved_at' => null
        ],
        // Ticket 4: Closed / Resolved ticket with past due -> NOT counted as open or breached
        't4' => [
            'id' => 'TCK-4',
            'status' => 'resolved',
            'priority' => 'urgent',
            'first_response_due_at' => date('Y-m-d H:i:s', $baseNow - 5000),
            'first_responded_at' => null,
            'resolved_at' => date('Y-m-d H:i:s', $baseNow - 1000)
        ]
    ];

    $res = calculateTicketKpis($tickets, $baseNow);
    if ($res['total_tickets'] !== 4) throw new Exception("Expected total_tickets=4");
    if ($res['open_tickets_count'] !== 3) throw new Exception("Expected open_tickets_count=3, got " . $res['open_tickets_count']);
    if ($res['urgent_count'] !== 1) throw new Exception("Expected urgent_count=1 (open urgent only), got " . $res['urgent_count']);
    if ($res['high_count'] !== 1) throw new Exception("Expected high_count=1, got " . $res['high_count']);
    if ($res['breached_count'] !== 2) throw new Exception("Expected breached_count=2, got " . $res['breached_count']);
    if ($res['approaching_breach_count'] !== 1) throw new Exception("Expected approaching_breach_count=1, got " . $res['approaching_breach_count']);
});


// ─────────────────────────────────────────────────────────────────
// SECTION 5: CRM & LEAD PIPELINE KPI TESTS
// ─────────────────────────────────────────────────────────────────
echo "\n--- Section 5: CRM & Lead Pipeline KPI Tests ---\n";

runTest("Leads: Empty leads & contacts -> 0 totals and 0.0% conversion rate", function() {
    $res = calculateLeadKpis([], []);
    if ($res['total_leads'] !== 0 || $res['active_leads_count'] !== 0 || $res['conversion_rate_pct'] !== 0.0) {
        throw new Exception("Expected 0s, got " . json_encode($res));
    }
});

runTest("Leads: Pipeline Stage Distribution & Conversion Rate Math", function() {
    $leads = [
        ['id' => 'L1', 'status' => 'new'],
        ['id' => 'L2', 'status' => 'pending'],
        ['id' => 'L3', 'status' => 'contacted'],
        ['id' => 'L4', 'status' => 'qualified'],
        ['id' => 'L5', 'status' => 'delivered'], // delivered counts as won
        ['id' => 'L6', 'status' => 'lost'],
        ['id' => 'L7', 'status' => 'unknown_custom'] // fallback to new
    ];
    $contacts = [
        ['id' => 'C1', 'stage' => 'won'],
        ['id' => 'C2', 'stage' => 'qualified']
    ];

    $res = calculateLeadKpis($leads, $contacts);
    // Total = 7 leads + 2 contacts = 9
    if ($res['total_leads'] !== 9) throw new Exception("Expected total_leads=9, got " . $res['total_leads']);
    // Won = L5 (delivered) + C1 (won) = 2
    if ($res['pipeline_breakdown']['won'] !== 2) throw new Exception("Expected won=2, got " . $res['pipeline_breakdown']['won']);
    // Conversion rate = (2 / 9) * 100 = 22.2%
    if ($res['conversion_rate_pct'] !== 22.2) throw new Exception("Expected conversion_rate=22.2%, got " . $res['conversion_rate_pct']);
    // Pending samples: $status === 'pending' || $status === 'new' -> L1 and L2 = 2
    if ($res['trial_samples_pending'] !== 2) throw new Exception("Expected pending=2, got " . $res['trial_samples_pending']);
    // Delivered samples = L5 = 1
    if ($res['trial_samples_delivered'] !== 1) throw new Exception("Expected delivered=1, got " . $res['trial_samples_delivered']);
});


// ─────────────────────────────────────────────────────────────────
// SECTION 6: DURATION FORMATTER EDGE CASES
// ─────────────────────────────────────────────────────────────────
echo "\n--- Section 6: Duration Formatter Edge Cases ---\n";

$durationTests = [
    [-10, '0s'],
    [0, '0s'],
    [1, '1s'],
    [59, '59s'],
    [60, '1m 0s'],
    [61, '1m 1s'],
    [125, '2m 5s'],
    [3599, '59m 59s'],
    [3600, '1h 0m'],
    [3665, '1h 1m'],
    [86400, '24h 0m']
];

foreach ($durationTests as [$input, $expected]) {
    runTest("Duration Format: $input s -> '$expected'", function() use ($input, $expected) {
        $actual = formatDurationHelper($input);
        if ($actual !== $expected) {
            throw new Exception("Expected '$expected', got '$actual'");
        }
    });
}


// ─────────────────────────────────────────────────────────────────
// SECTION 7: CONCURRENCY & ATOMIC PERSISTENCE UNDER LOAD
// ─────────────────────────────────────────────────────────────────
echo "\n--- Section 7: Concurrency & Atomic Persistence Under Load ---\n";

runTest("Atomic Storage: Rapid 50-iteration write-read integrity test", function() {
    $tempFile = DATA_PATH . 'test_stress_' . bin2hex(random_bytes(4)) . '.json';
    $data = ['iteration' => 0, 'history' => []];

    for ($i = 1; $i <= 50; $i++) {
        $data['iteration'] = $i;
        $data['history'][] = "Step $i - " . microtime(true);
        $ok = atomicWriteJson($tempFile, $data);
        if (!$ok) throw new Exception("atomicWriteJson failed on iteration $i");

        $readBack = atomicReadJson($tempFile);
        if (($readBack['iteration'] ?? null) !== $i || count($readBack['history'] ?? []) !== $i) {
            throw new Exception("atomicReadJson mismatch on iteration $i");
        }
    }

    // Ensure temp swap files are cleaned up in the data directory
    $orphans = glob($tempFile . '.*.tmp');
    if (!empty($orphans)) {
        foreach ($orphans as $o) @unlink($o);
        throw new Exception("Orphaned .tmp files found: " . implode(', ', $orphans));
    }

    @unlink($tempFile);
});

runTest("Atomic Storage: Non-existent nested directory auto-creation", function() {
    $nestedFile = DATA_PATH . 'nested_test_' . uniqid() . '/sub/test.json';
    $data = ['nested' => true];
    $ok = atomicWriteJson($nestedFile, $data);
    if (!$ok) throw new Exception("atomicWriteJson failed to auto-create directory");
    $read = readJson($nestedFile);
    if (!isset($read['nested'])) throw new Exception("Failed to read back nested file");

    @unlink($nestedFile);
    @rmdir(dirname($nestedFile));
    @rmdir(dirname(dirname($nestedFile)));
});


// ─────────────────────────────────────────────────────────────────
// SECTION 8: ADMIN DASHBOARD (live-visitors.php) 4 DATA STATE ARCHETYPES
// (Executed via isolated PHP CLI process to avoid in-memory redeclaration conflicts)
// ─────────────────────────────────────────────────────────────────
echo "\n--- Section 8: Admin Dashboard (live-visitors.php) 4 Data State Archetypes ---\n";

function executeDashboardInSubprocess(array $stateFiles): string {
    $backup = [];
    $dataFiles = [
        'visitors.json', 'analytics_history.json', 'live_chats.json',
        'leads.json', 'contacts.json', 'tickets.json',
        'chat_automations.json', 'widget_settings.json', 'knowledge_base.json'
    ];

    // Backup current files
    foreach ($dataFiles as $df) {
        $p = DATA_PATH . $df;
        $backup[$df] = file_exists($p) ? readJson($p) : [];
    }

    // Write test state files
    foreach ($stateFiles as $df => $content) {
        atomicWriteJson(DATA_PATH . $df, $content);
    }

    $runnerCode = <<<'PHP'
<?php
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE);
ini_set('display_errors', '1');
if (session_status() === PHP_SESSION_NONE) { session_start(); }
$_SESSION['is_admin'] = true;
$_SESSION['admin_user'] = [
    'id'    => 'adm-test-chal',
    'name'  => 'Challenger Admin',
    'email' => 'challenger@estatehdr.com',
    'roles' => ['owner', 'super_admin']
];
require __DIR__ . '/../admin/live-visitors.php';
PHP;

    $runnerFile = __DIR__ . '/_temp_dashboard_runner.php';
    file_put_contents($runnerFile, $runnerCode);

    $phpBin = 'C:\\xampp\\php\\php.exe';
    $output = [];
    $ret = 0;
    exec("\"$phpBin\" \"$runnerFile\"", $output, $ret);
    @unlink($runnerFile);

    // Restore original files
    foreach ($backup as $df => $content) {
        atomicWriteJson(DATA_PATH . $df, $content);
    }

    $html = implode("\n", $output);
    if ($ret !== 0) {
        throw new Exception("Dashboard execution failed with exit code $ret: " . substr($html, 0, 300));
    }

    return $html;
}

runTest("Dashboard State A: Empty / Fresh Install (0 records across all stores)", function() {
    $emptyState = [
        'visitors.json'         => [],
        'analytics_history.json'=> [],
        'live_chats.json'       => [],
        'leads.json'            => [],
        'contacts.json'         => [],
        'tickets.json'          => [],
        'chat_automations.json' => [],
        'widget_settings.json'  => [],
        'knowledge_base.json'   => []
    ];

    $html = executeDashboardInSubprocess($emptyState);

    // Verify all 6 tab buttons and containers exist
    if (!str_contains($html, 'id="btnTabOverview"')) throw new Exception("btnTabOverview missing");
    if (!str_contains($html, 'id="btnTabRadar"')) throw new Exception("btnTabRadar missing");
    if (!str_contains($html, 'id="btnTabInbox"')) throw new Exception("btnTabInbox missing");
    if (!str_contains($html, 'id="btnTabCrm"')) throw new Exception("btnTabCrm missing");
    if (!str_contains($html, 'id="btnTabTriggers"')) throw new Exception("btnTabTriggers missing");
    if (!str_contains($html, 'id="btnTabTickets"')) throw new Exception("btnTabTickets missing");

    if (!str_contains($html, 'id="tabOverview"')) throw new Exception("tabOverview missing");
    if (!str_contains($html, 'id="tabRadar"')) throw new Exception("tabRadar missing");
    if (!str_contains($html, 'id="tabInbox"')) throw new Exception("tabInbox missing");
    if (!str_contains($html, 'id="tabCrm"')) throw new Exception("tabCrm missing");
    if (!str_contains($html, 'id="tabTriggers"')) throw new Exception("tabTriggers missing");
    if (!str_contains($html, 'id="tabTickets"')) throw new Exception("tabTickets missing");

    // Verify 6 KPI cards
    if (!str_contains($html, 'Active Online')) throw new Exception("KPI Card 1 missing");
    if (!str_contains($html, 'Total Traffic')) throw new Exception("KPI Card 2 missing");
    if (!str_contains($html, 'Avg Dwell Time')) throw new Exception("KPI Card 3 missing");
    if (!str_contains($html, 'Omnichannel')) throw new Exception("KPI Card 4 missing");
    if (!str_contains($html, 'CSAT Rating')) throw new Exception("KPI Card 5 missing");
    if (!str_contains($html, 'Tickets &amp; Leads')) throw new Exception("KPI Card 6 missing");

    // Check empty state fallback labels
    if (!str_contains($html, 'No active telemetry events recorded yet.')) throw new Exception("Stream empty label missing");
    if (!str_contains($html, 'No live conversations yet.')) throw new Exception("Inbox empty label missing");
});

runTest("Dashboard State B: Boundary Presence State (exact timestamps 0s, 60s, 61s, 180s, 181s)", function() {
    $now = time();
    $boundaryVisitors = [
        'v_0s'   => ['visitor_id' => 'v_0s', 'last_seen_ts' => $now, 'hits' => 2, 'time_spent' => 20, 'ip' => '10.0.0.1', 'city' => 'London', 'country' => 'UK', 'current_page' => '/'],
        'v_60s'  => ['visitor_id' => 'v_60s', 'last_seen_ts' => $now - 60, 'hits' => 1, 'time_spent' => 45, 'ip' => '10.0.0.2', 'city' => 'Manchester', 'country' => 'UK', 'current_page' => '/services/hdr-photo-editing'],
        'v_61s'  => ['visitor_id' => 'v_61s', 'last_seen_ts' => $now - 61, 'hits' => 3, 'time_spent' => 90, 'ip' => '10.0.0.3', 'city' => 'Sydney', 'country' => 'Australia', 'current_page' => '/pricing.php'],
        'v_180s' => ['visitor_id' => 'v_180s', 'last_seen_ts' => $now - 180, 'hits' => 4, 'time_spent' => 150, 'ip' => '10.0.0.4', 'city' => 'Toronto', 'country' => 'Canada', 'current_page' => '/portfolio.php'],
        'v_181s' => ['visitor_id' => 'v_181s', 'last_seen_ts' => $now - 181, 'hits' => 5, 'time_spent' => 300, 'ip' => '10.0.0.5', 'city' => 'Austin', 'country' => 'USA', 'current_page' => '/contact.php']
    ];

    $html = executeDashboardInSubprocess(['visitors.json' => $boundaryVisitors]);
    
    // v_0s and v_60s should be data-state="active"
    if (!str_contains($html, 'data-state="active"')) throw new Exception("Active presence row missing");
    // v_61s and v_180s should be data-state="idle"
    if (!str_contains($html, 'data-state="idle"')) throw new Exception("Idle presence row missing");
    // v_181s should be data-state="recent"
    if (!str_contains($html, 'data-state="recent"')) throw new Exception("Recent presence row missing");
});

runTest("Dashboard State C: Saturated High-Load State (Populated Across All Entities)", function() {
    $now = time();
    $satVisitors = [];
    for ($i = 1; $i <= 30; $i++) {
        $satVisitors["v_sat_$i"] = [
            'visitor_id'   => "v_sat_$i",
            'ip'           => "192.168.1.$i",
            'city'         => $i % 2 === 0 ? 'Miami' : 'Chicago',
            'country'      => 'USA',
            'current_page' => $i % 3 === 0 ? '/pricing.php' : '/services/virtual-staging',
            'page_title'   => 'Virtual Staging',
            'time_spent'   => $i * 15,
            'hits'         => $i,
            'last_seen_ts' => $now - ($i * 10),
            'date'         => date('Y-m-d')
        ];
    }

    $satChats = [
        'v_sat_1' => [
            'visitor_id' => 'v_sat_1',
            'city' => 'Miami',
            'channel' => 'webchat',
            'status' => 'active',
            'has_unread_for_agent' => true,
            'last_active_ts' => $now - 5,
            'messages' => [
                ['sender' => 'user', 'text' => 'Need 20 HDR images retouched today', 'ts' => $now - 40],
                ['sender' => 'agent', 'text' => 'We can process them in 12h rush!', 'ts' => $now - 10]
            ]
        ],
        'v_sat_2' => [
            'visitor_id' => 'v_sat_2',
            'city' => 'Chicago',
            'channel' => 'whatsapp',
            'status' => 'active',
            'last_active_ts' => $now - 30,
            'messages' => [
                ['sender' => 'user', 'text' => 'WhatsApp inquiry about pricing', 'ts' => $now - 120],
                ['sender' => 'agent', 'text' => 'Starts at $0.80/photo', 'ts' => $now - 90]
            ]
        ]
    ];

    $satLeads = [
        ['id' => 'LD-1', 'name' => 'John Real Estate', 'email' => 'john@realty.com', 'status' => 'new', 'service' => 'HDR Retouching'],
        ['id' => 'LD-2', 'name' => 'Sarah Staging', 'email' => 'sarah@staging.com', 'status' => 'contacted', 'service' => 'Virtual Staging'],
        ['id' => 'LD-3', 'name' => 'Mike Brokerage', 'email' => 'mike@broker.com', 'status' => 'qualified', 'service' => 'Full Floorplans'],
        ['id' => 'LD-4', 'name' => 'Emma Studio', 'email' => 'emma@studio.com', 'status' => 'delivered', 'service' => 'Day to Dusk']
    ];

    $satTickets = [
        [
            'id' => 'TCK-9901',
            'subject' => 'Grass enhancement artifact',
            'requester_name' => 'David Miller',
            'requester_email' => 'david@miller.com',
            'department' => 'Photo Editing QA',
            'priority' => 'urgent',
            'status' => 'open',
            'first_response_due_at' => date('Y-m-d H:i:s', $now - 100),
            'first_responded_at' => null
        ]
    ];

    $html = executeDashboardInSubprocess([
        'visitors.json'   => $satVisitors,
        'live_chats.json' => $satChats,
        'leads.json'      => $satLeads,
        'tickets.json'    => $satTickets
    ]);

    if (!str_contains($html, 'John Real Estate')) throw new Exception("Lead John missing");
    if (!str_contains($html, 'TCK-9901')) throw new Exception("Ticket TCK-9901 missing");
    if (!str_contains($html, 'We can process them in 12h rush!')) throw new Exception("Latest chat preview snippet missing");
    if (!str_contains($html, 'Miami')) throw new Exception("City Miami missing");
});

runTest("Dashboard State D: Malformed / Partial Data State", function() {
    $malformedVisitors = [
        'v_bad1' => ['visitor_id' => 'v_bad1'], // Missing everything
        'v_bad2' => ['visitor_id' => 'v_bad2', 'current_page' => null, 'ip' => null, 'time_spent' => 'not-a-number'],
        'v_bad3' => ['visitor_id' => 'v_bad3', 'current_page' => '/service.php?slug=hdr-photo-editing&ref=123']
    ];

    $html = executeDashboardInSubprocess(['visitors.json' => $malformedVisitors]);
    if (!str_contains($html, 'v_bad1')) throw new Exception("v_bad1 row missing");
    if (!str_contains($html, 'Hdr Photo Editing Service')) throw new Exception("Clean URL formatting for service.php slug failed");
});


// ─────────────────────────────────────────────────────────────────
// SUMMARY
// ─────────────────────────────────────────────────────────────────
echo "\n====================================================================\n";
echo "TEST RESULTS: $totalPassed PASSED, $totalFailed FAILED\n";
echo "====================================================================\n";

if ($totalFailed > 0) {
    exit(1);
} else {
    exit(0);
}
