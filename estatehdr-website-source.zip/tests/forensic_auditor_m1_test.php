<?php
/**
 * Independent Forensic Audit Test Suite for Milestone M1
 * Executes deep empirical verification of concurrency, atomic storage, presence logic, KPI math, and security.
 */

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/saas-db.php';

$results = [
    'checks_total' => 0,
    'checks_passed' => 0,
    'checks_failed' => 0,
    'details' => []
];

function recordCheck(string $name, bool $passed, string $msg = '') {
    global $results;
    $results['checks_total']++;
    if ($passed) {
        $results['checks_passed']++;
        $results['details'][] = "[PASS] {$name}" . ($msg ? " - {$msg}" : '');
        echo "  [PASS] {$name}" . ($msg ? " - {$msg}" : '') . "\n";
    } else {
        $results['checks_failed']++;
        $results['details'][] = "[FAIL] {$name} - {$msg}";
        echo "  [FAIL] {$name} - {$msg}\n";
    }
}

echo "=======================================================\n";
echo "FORENSIC INTEGRITY AUDIT — MILESTONE M1\n";
echo "=======================================================\n\n";

// ── 1. CONCURRENCY & ATOMIC WRITE INTEGRITY ─────────────────
echo "--- 1. Atomic Storage & Concurrency Tests ---\n";
$tempTestFile = DATA_PATH . 'forensic_test_' . uniqid() . '.json';

// Test 1.1: Basic write & read
$testData = ['status' => 'ok', 'auditor' => 'teamwork_preview_auditor_m1_1', 'val' => 42, 'nested' => ['a' => 1, 'b' => [2, 3]]];
$writeOk = atomicWriteJson($tempTestFile, $testData);
$readData = atomicReadJson($tempTestFile);
recordCheck("Atomic Write & Read Integrity", $writeOk && $readData === $testData, "Written and read JSON structures match exactly");

// Test 1.2: Atomic replacement without corrupting concurrent reads
$successCount = 0;
for ($i = 0; $i < 50; $i++) {
    $readData['iteration'] = $i;
    $readData['hash'] = md5((string)$i);
    if (atomicWriteJson($tempTestFile, $readData)) {
        $verify = atomicReadJson($tempTestFile);
        if ($verify['iteration'] === $i && $verify['hash'] === md5((string)$i)) {
            $successCount++;
        }
    }
}
recordCheck("50 Rapid Atomic Overwrites", $successCount === 50, "50/50 consecutive atomic updates persisted without corruption");

// Test 1.3: Non-existent file read
$emptyRead = atomicReadJson(DATA_PATH . 'non_existent_file_' . uniqid() . '.json');
recordCheck("Non-Existent File Read Safety", is_array($emptyRead) && empty($emptyRead), "Returns safe empty array for non-existent file");

// Test 1.4: Special characters and Unicode safety
$unicodeData = ['greeting' => 'こんにちは', 'emoji' => '🚀✨🇬🇧', 'quotes' => 'He said "Hello" & \'Goodbye\'', 'slashes' => 'path/to/resource\\test'];
atomicWriteJson($tempTestFile, $unicodeData);
$unicodeRead = atomicReadJson($tempTestFile);
recordCheck("Unicode & Special Char Preservation", $unicodeRead === $unicodeData, "Exact preservation of UTF-8, emojis, quotes, and slashes");
@unlink($tempTestFile);

// ── 2. PRESENCE CALCULATION EMPIRICAL TESTING ───────────────
echo "\n--- 2. Presence & 3-State Logic Empirical Verification ---\n";
$tNow = 1700000000;

$testVisitors = [
    'v_active' => ['visitor_id' => 'v_active', 'last_seen_ts' => $tNow - 30], // 30s ago -> active
    'v_idle'   => ['visitor_id' => 'v_idle',   'last_seen_ts' => $tNow - 120], // 120s ago -> idle
    'v_chat'   => ['visitor_id' => 'v_chat',   'last_seen_ts' => $tNow - 200], // 200s ago + active chat -> chatting
    'v_off'    => ['visitor_id' => 'v_off',    'last_seen_ts' => $tNow - 400], // 400s ago -> offline
    'v_stale_chat' => ['visitor_id' => 'v_stale_chat', 'last_seen_ts' => $tNow - 350], // 350s delta (>300s limit) -> offline even if chat exists
];
$testChats = [
    'v_chat' => ['status' => 'active', 'last_active_ts' => $tNow - 100],
    'v_stale_chat' => ['status' => 'active', 'last_active_ts' => $tNow - 100]
];

$presStats = calculateLivePresenceStats($testVisitors, $testChats, $tNow);
recordCheck("3-State Active Count", $presStats['active_count'] === 1, "Expected 1 active, got {$presStats['active_count']}");
recordCheck("3-State Idle Count", $presStats['idle_count'] === 1, "Expected 1 idle, got {$presStats['idle_count']}");
recordCheck("3-State Chatting Count", $presStats['chatting_count'] === 1, "Expected 1 chatting, got {$presStats['chatting_count']}");
recordCheck("3-State Offline Count", $presStats['offline_count'] === 2, "Expected 2 offline, got {$presStats['offline_count']}");
recordCheck("3-State Online Now Total", $presStats['online_now'] === 2, "Expected 2 online (active + chatting), got {$presStats['online_now']}");

// ── 3. SESSION FILTERING & AGGREGATION TESTING ─────────────
echo "\n--- 3. Session Filtering & Breakdowns Verification ---\n";
$sessionVisitors = [
    's1' => ['visitor_id' => 's1', 'date' => date('Y-m-d', $tNow), 'ip' => '10.0.0.1', 'country' => 'United States', 'city' => 'New York', 'device' => 'Desktop', 'browser' => 'Chrome', 'referrer' => 'Google', 'current_page' => '/pricing.php', 'hits' => 4, 'time_spent' => 180, 'last_seen_ts' => $tNow],
    's2' => ['visitor_id' => 's2', 'date' => date('Y-m-d', $tNow), 'ip' => '10.0.0.2', 'country' => 'United Kingdom', 'city' => 'London', 'device' => 'Mobile', 'browser' => 'Safari', 'referrer' => 'Direct', 'current_page' => '/services/hdr', 'hits' => 2, 'time_spent' => 60, 'last_seen_ts' => $tNow - 50],
    's3' => ['visitor_id' => 's3', 'date' => date('Y-m-d', $tNow - 86400), 'ip' => '10.0.0.1', 'country' => 'United States', 'city' => 'New York', 'device' => 'Desktop', 'browser' => 'Chrome', 'referrer' => 'Google', 'current_page' => '/pricing.php', 'hits' => 1, 'time_spent' => 30, 'last_seen_ts' => $tNow - 86400]
];

$todayFilter = filterVisitorSessions($sessionVisitors, 'today', '', '', $tNow);
recordCheck("Date Range Filter 'today'", $todayFilter['total_sessions'] === 2, "Expected 2 sessions today, got {$todayFilter['total_sessions']}");
recordCheck("Unique IPs Count 'today'", $todayFilter['unique_ips_count'] === 2, "Expected 2 unique IPs, got {$todayFilter['unique_ips_count']}");
recordCheck("Total Hits Aggregation", $todayFilter['total_hits'] === 6, "Expected 6 hits (4+2), got {$todayFilter['total_hits']}");
recordCheck("Avg Duration Calculation", $todayFilter['avg_seconds'] === 120, "Expected 120s avg ((180+60)/2), got {$todayFilter['avg_seconds']}");
recordCheck("Country Breakdown", ($todayFilter['countries']['United States'] ?? 0) === 1 && ($todayFilter['countries']['United Kingdom'] ?? 0) === 1, "Countries aggregated properly");

// ── 4. CHAT KPIS & FIRST RESPONSE TIME (FRT) TESTING ───────
echo "\n--- 4. Chat KPIs & FRT Math Verification ---\n";
$frtChats = [
    'c1' => [
        'status' => 'active',
        'channel' => 'webchat',
        'has_unread_for_agent' => true,
        'last_active_ts' => $tNow - 300,
        'messages' => [
            ['sender' => 'user', 'ts' => $tNow - 200, 'text' => 'Hello'],
            ['sender' => 'agent', 'ts' => $tNow - 170, 'text' => 'Hi there!'] // 30s FRT
        ]
    ],
    'c2' => [
        'status' => 'closed',
        'channel' => 'whatsapp',
        'has_unread_for_agent' => false,
        'last_active_ts' => $tNow - 5000,
        'messages' => [
            ['sender' => 'user', 'ts' => $tNow - 4000, 'text' => 'Pricing?'],
            ['sender' => 'agent', 'ts' => $tNow - 3950, 'text' => '$0.80'] // 50s FRT
        ]
    ]
];
$frtResult = calculateChatKpis($frtChats, 'all', $tNow);
recordCheck("Active Chats Count", $frtResult['active_chats_now'] === 1, "Expected 1 active chat within 1h/active status, got {$frtResult['active_chats_now']}");
recordCheck("Unread Alerts Count", $frtResult['unread_alerts_count'] === 1, "Expected 1 unread alert, got {$frtResult['unread_alerts_count']}");
recordCheck("FRT Average Math", $frtResult['avg_frt_seconds'] === 40, "Expected 40s avg ((30+50)/2), got {$frtResult['avg_frt_seconds']}");
recordCheck("FRT Formatted String", $frtResult['avg_frt_formatted'] === '40s', "Expected '40s', got {$frtResult['avg_frt_formatted']}");

// ── 5. CSAT & TICKET KPIS TESTING ──────────────────────────
echo "\n--- 5. CSAT & Ticket SLA Verification ---\n";
$csatChats = [
    ['rating' => 5.0],
    ['rating' => 4.0],
    ['rating' => 3.0],
    ['rating' => 5.0]
];
$csatTickets = [
    ['satisfaction_score' => 5.0]
];
// Total: 5 ratings: 5, 4, 3, 5, 5 -> 4 positive (>=4.0) out of 5 -> 80.0%, avg = (5+4+3+5+5)/5 = 4.4
$csatRes = calculateCsatKpi($csatChats, $csatTickets);
recordCheck("CSAT Positive Percentage", $csatRes['csat_percentage'] === 80.0, "Expected 80.0%, got {$csatRes['csat_percentage']}%");
recordCheck("CSAT Average Rating", $csatRes['csat_average'] === 4.4, "Expected 4.4, got {$csatRes['csat_average']}");

// Ticket SLA breach test
$testTickets = [
    [
        'id' => 'T1',
        'status' => 'open',
        'priority' => 'urgent',
        'first_response_due_at' => date('c', $tNow - 100), // Due in past, not responded
        'first_responded_at' => null,
        'resolution_due_at' => date('c', $tNow + 3600),
        'resolved_at' => null
    ],
    [
        'id' => 'T2',
        'status' => 'resolved',
        'priority' => 'high',
        'first_response_due_at' => date('c', $tNow - 500),
        'first_responded_at' => date('c', $tNow - 600),
        'resolution_due_at' => date('c', $tNow - 200),
        'resolved_at' => date('c', $tNow - 300)
    ]
];
$ticketRes = calculateTicketKpis($testTickets, $tNow);
recordCheck("Open Tickets Count", $ticketRes['open_tickets_count'] === 1, "Expected 1 open ticket, got {$ticketRes['open_tickets_count']}");
recordCheck("Urgent Priority Count", $ticketRes['urgent_count'] === 1, "Expected 1 urgent ticket, got {$ticketRes['urgent_count']}");
recordCheck("SLA Breach Detection", $ticketRes['breached_count'] === 1, "T1 breached first response SLA, got {$ticketRes['breached_count']} breaches");

// ── 6. LEAD KPIS & PIPELINE TESTING ─────────────────────────
echo "\n--- 6. Lead CRM & Pipeline Verification ---\n";
$testLeads = [
    ['status' => 'new'],
    ['status' => 'contacted'],
    ['status' => 'qualified'],
    ['status' => 'delivered'] // Won
];
$testContacts = [
    ['stage' => 'won']
];
$leadRes = calculateLeadKpis($testLeads, $testContacts);
recordCheck("Total Leads & Contacts", $leadRes['total_leads'] === 5, "Expected 5 total, got {$leadRes['total_leads']}");
recordCheck("Active Leads (New, Contacted, Qualified)", $leadRes['active_leads_count'] === 3, "Expected 3 active leads, got {$leadRes['active_leads_count']}");
recordCheck("Won Leads Count", $leadRes['pipeline_breakdown']['won'] === 2, "Expected 2 won leads, got {$leadRes['pipeline_breakdown']['won']}");
recordCheck("Conversion Rate Math", $leadRes['conversion_rate_pct'] === 40.0, "Expected 40.0% ((2/5)*100), got {$leadRes['conversion_rate_pct']}%");

// ── 7. STATIC FORENSIC SCAN FOR SHORTCUTS OR BYPASSES ───────
echo "\n--- 7. Static Code Forensic Checks ---\n";
$m1Files = [
    'includes/db.php',
    'admin/live-visitors.php',
    'api/visitor-ping.php',
    'api/chat-live.php',
    'api/chat-bot.php',
    'includes/auth.php',
    'includes/saas-db.php'
];

$facadeViolations = [];
foreach ($m1Files as $fileRel) {
    $fullPath = __DIR__ . '/../' . $fileRel;
    $content = file_get_contents($fullPath);
    
    // Check for hardcoded test bypass flags or mock constants
    if (preg_match('/\b(MOCK_DATA|FAKE_STATE|BYPASS_AUTH|HARDCODED_TEST_PASS)\b/i', $content, $m)) {
        $facadeViolations[] = "{$fileRel}: Found suspicious token {$m[0]}";
    }
    // Check for dummy return stubs in core functions
    if (preg_match('/function\s+atomicWriteJson[^{]*\{\s*return\s+true;\s*\}/i', $content)) {
        $facadeViolations[] = "{$fileRel}: atomicWriteJson is a dummy stub!";
    }
}
recordCheck("Zero Mock Flags or Facades Detected", empty($facadeViolations), empty($facadeViolations) ? "All scanned files contain genuine logic" : implode('; ', $facadeViolations));

// ── 8. RBAC ACCESS ENFORCEMENT VERIFICATION ─────────────────
echo "\n--- 8. Security & RBAC Enforcement Verification ---\n";
$_SESSION = [];
// Unauthenticated state
$isLogged = isAdminLoggedIn();
recordCheck("Unauthenticated Admin Guard", !$isLogged, "Unauthenticated session correctly identified as logged out");

// Manager role check
loginAdmin('manager@estatehdr.com', 'Test Manager', 'manager', ['manager']);
$isMgr = isManager();
$isOwn = isOwner();
recordCheck("Manager RBAC Role Recognition", $isMgr && !$isOwn, "Manager identified with manager rights and without owner rights");

// Cleanup
logoutAdmin();

echo "\n=======================================================\n";
echo "SUMMARY: {$results['checks_passed']} / {$results['checks_total']} CHECKS PASSED\n";
if ($results['checks_failed'] === 0) {
    echo "VERDICT: CLEAN — Zero integrity violations detected.\n";
} else {
    echo "VERDICT: INTEGRITY VIOLATION — {$results['checks_failed']} checks failed!\n";
}
echo "=======================================================\n";
