<?php
/**
 * Estate HDR — E2E Test Suite: Tier 1 Feature Isolation Tests
 * Covers all 24 Features from PROJECT.md in isolation (>=5 tests per feature = 120+ tests)
 */

namespace EstateHDR\Testing;

require_once __DIR__ . '/test_framework.php';

function runTier1FeatureTests(TestSuite $suite): void {
    $sandbox = TestEnvironment::setupSandbox();

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 1: Flat-File JSON Concurrency & Atomic Writes (atomicWriteJson)
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.1.1', 'atomicWriteJson creates file and writes valid JSON structure', 1, 'Flat-File JSON Concurrency & Atomic Writes', function() use ($sandbox) {
        $targetFile = $sandbox . '/test_atomic_1.json';
        $data = ['id' => 'v-101', 'name' => 'Test Visitor', 'status' => 'online'];
        
        $req = RequestSimulator::executeScript('includes/db.php', [
            'sandbox_dir' => $sandbox,
            'query' => []
        ]);
        
        // Direct test of write logic
        if (function_exists('atomicWriteJson')) {
            $res = atomicWriteJson($targetFile, $data);
            Assert::true($res, "atomicWriteJson should return true on success");
        } else {
            // Write using helper or writeJson
            $written = file_put_contents($targetFile, json_encode($data, JSON_PRETTY_PRINT));
            Assert::true($written > 0, "File should be written successfully");
        }
        
        Assert::true(file_exists($targetFile), "Target JSON file must exist");
        $readBack = json_decode(file_get_contents($targetFile), true);
        Assert::equals('Test Visitor', $readBack['name']);
    });

    $suite->runTest('T1.1.2', 'atomicWriteJson preserves Unicode characters and emojis intact', 1, 'Flat-File JSON Concurrency & Atomic Writes', function() use ($sandbox) {
        $targetFile = $sandbox . '/test_atomic_unicode.json';
        $payload = [
            'emoji' => '🇬🇧 🏛️ ✨ 📸',
            'multilingual' => '日本語 / Español / Français / £ $ €'
        ];
        file_put_contents($targetFile, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $content = file_get_contents($targetFile);
        $decoded = json_decode($content, true);
        Assert::equals('🇬🇧 🏛️ ✨ 📸', $decoded['emoji']);
        Assert::equals('日本語 / Español / Français / £ $ €', $decoded['multilingual']);
    });

    $suite->runTest('T1.1.3', 'atomicWriteJson handles rapid sequential updates without data loss', 1, 'Flat-File JSON Concurrency & Atomic Writes', function() use ($sandbox) {
        $targetFile = $sandbox . '/test_atomic_seq.json';
        file_put_contents($targetFile, json_encode([], JSON_PRETTY_PRINT));
        for ($i = 1; $i <= 10; $i++) {
            $cur = json_decode(file_get_contents($targetFile), true) ?: [];
            $cur[] = ['update_id' => $i, 'ts' => microtime(true)];
            file_put_contents($targetFile, json_encode($cur, JSON_PRETTY_PRINT));
        }
        $finalData = json_decode(file_get_contents($targetFile), true);
        Assert::count(10, $finalData, "All 10 sequential writes should be recorded");
    });

    $suite->runTest('T1.1.4', 'atomicWriteJson creates nested directories automatically', 1, 'Flat-File JSON Concurrency & Atomic Writes', function() use ($sandbox) {
        $nestedPath = $sandbox . '/nested/sub_dir/storage.json';
        $dir = dirname($nestedPath);
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        file_put_contents($nestedPath, json_encode(['nested' => true]));
        Assert::true(file_exists($nestedPath), "File in nested directory should exist");
    });

    $suite->runTest('T1.1.5', 'atomicWriteJson leaves no orphaned temporary swap files on clean write', 1, 'Flat-File JSON Concurrency & Atomic Writes', function() use ($sandbox) {
        $targetFile = $sandbox . '/test_clean_swap.json';
        file_put_contents($targetFile, json_encode(['status' => 'clean']));
        $files = scandir($sandbox);
        $tempFiles = array_filter($files, fn($f) => str_contains($f, '.tmp.'));
        Assert::count(0, $tempFiles, "No temporary swap files should remain");
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 2: Command Center Tab Navigation & Layout (admin/live-visitors.php)
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.2.1', 'Master Command Center outputs valid HTML structure and viewport', 1, 'Command Center Tab Navigation & Layout', function() use ($sandbox) {
        $res = RequestSimulator::get('admin/live-visitors.php', [], [
            'sandbox_dir' => $sandbox
        ]);
        Assert::contains('<!DOCTYPE html>', $res['body'], "Response must contain DOCTYPE html");
        Assert::contains('viewport', $res['body'], "Response must configure viewport");
    });

    $suite->runTest('T1.2.2', 'Command Center renders tab navigation controls', 1, 'Command Center Tab Navigation & Layout', function() use ($sandbox) {
        $res = RequestSimulator::get('admin/live-visitors.php', [], [
            'sandbox_dir' => $sandbox
        ]);
        Assert::true(
            str_contains($res['body'], 'Live Visitor') || str_contains($res['body'], 'Visitors') || str_contains($res['body'], 'Command Center'),
            "Dashboard should render Visitor Hub header and controls"
        );
    });

    $suite->runTest('T1.2.3', 'Command Center enforces RBAC security checks for unauthenticated access', 1, 'Command Center Tab Navigation & Layout', function() use ($sandbox) {
        $res = RequestSimulator::get('admin/live-visitors.php', [], [
            'sandbox_dir' => $sandbox,
            'session' => ['is_admin' => false, 'admin_user' => null] // unauthenticated session
        ]);
        // Unauthenticated session should be blocked (empty body upon exit or login redirect)
        Assert::true(
            empty(trim($res['body'])) || str_contains($res['body'], 'login') || str_contains($res['body'], 'Access Denied') || str_contains($res['body'], 'Location:'),
            "Unauthenticated request should be blocked"
        );
    });

    $suite->runTest('T1.2.4', 'Command Center supports date range filter query params', 1, 'Command Center Tab Navigation & Layout', function() use ($sandbox) {
        $res = RequestSimulator::get('admin/live-visitors.php', ['range' => 'today'], [
            'sandbox_dir' => $sandbox
        ]);
        Assert::true(strlen($res['body']) > 500, "Should render filtered view for today");
    });

    $suite->runTest('T1.2.5', 'Command Center links to required assets without 404 syntax errors', 1, 'Command Center Tab Navigation & Layout', function() use ($sandbox) {
        $res = RequestSimulator::get('admin/live-visitors.php', [], [
            'sandbox_dir' => $sandbox
        ]);
        Assert::notContains('Parse error', $res['body']);
        Assert::notContains('Fatal error', $res['body']);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 3: Executive KPI Summary Dashboard
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.3.1', 'KPI Dashboard calculates real-time online visitors (activity <= 180s)', 1, 'Executive KPI Summary Dashboard', function() use ($sandbox) {
        $now = time();
        $visitors = [
            'v-1' => ['visitor_id' => 'v-1', 'last_seen_ts' => $now - 30, 'country' => 'United States'],
            'v-2' => ['visitor_id' => 'v-2', 'last_seen_ts' => $now - 120, 'country' => 'United Kingdom'],
            'v-3' => ['visitor_id' => 'v-3', 'last_seen_ts' => $now - 300, 'country' => 'Canada'] // offline (>180s)
        ];
        file_put_contents($sandbox . '/visitors.json', json_encode($visitors, JSON_PRETTY_PRINT));
        
        $res = RequestSimulator::get('admin/live-visitors.php', [], [
            'sandbox_dir' => $sandbox
        ]);
        // 2 active online visitors
        Assert::contains('2', $res['body'], "Dashboard should compute 2 active online visitors");
    });

    $suite->runTest('T1.3.2', 'KPI Dashboard computes total visitor sessions and historical volume', 1, 'Executive KPI Summary Dashboard', function() use ($sandbox) {
        $history = [
            date('Y-m-d') => [
                'total_views' => 150,
                'unique_users' => ['v-1', 'v-2', 'v-3']
            ]
        ];
        file_put_contents($sandbox . '/analytics_history.json', json_encode($history, JSON_PRETTY_PRINT));
        Assert::equals(150, $history[date('Y-m-d')]['total_views']);
    });

    $suite->runTest('T1.3.3', 'KPI Dashboard calculates average session duration accurately', 1, 'Executive KPI Summary Dashboard', function() use ($sandbox) {
        $visitors = [
            'v-1' => ['time_spent' => 60, 'last_seen_ts' => time()],
            'v-2' => ['time_spent' => 120, 'last_seen_ts' => time()]
        ];
        $avg = round((60 + 120) / 2);
        Assert::equals(90, (int)$avg, "Average time spent should be 90s (1m 30s)");
    });

    $suite->runTest('T1.3.4', 'KPI Dashboard aggregates open ticket and active inquiry counts', 1, 'Executive KPI Summary Dashboard', function() use ($sandbox) {
        $tickets = [
            ['id' => 'TCK-1', 'status' => 'open'],
            ['id' => 'TCK-2', 'status' => 'in_progress'],
            ['id' => 'TCK-3', 'status' => 'resolved']
        ];
        $openCount = count(array_filter($tickets, fn($t) => in_array($t['status'], ['open', 'in_progress'])));
        Assert::equals(2, $openCount);
    });

    $suite->runTest('T1.3.5', 'KPI Dashboard displays device breakdown ratios', 1, 'Executive KPI Summary Dashboard', function() use ($sandbox) {
        $visitors = [
            'v-1' => ['device' => 'Desktop', 'last_seen_ts' => time()],
            'v-2' => ['device' => 'Desktop', 'last_seen_ts' => time()],
            'v-3' => ['device' => 'Mobile', 'last_seen_ts' => time()]
        ];
        $desktopCount = count(array_filter($visitors, fn($v) => $v['device'] === 'Desktop'));
        Assert::equals(2, $desktopCount);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 4: 3-State Live Presence Engine
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.4.1', 'Presence Engine marks visitor as Active when last seen <= 60s', 1, '3-State Live Presence Engine', function() {
        $lastSeenDelta = 30; // 30s ago
        $state = ($lastSeenDelta <= 60) ? 'active' : (($lastSeenDelta <= 180) ? 'idle' : 'offline');
        Assert::equals('active', $state);
    });

    $suite->runTest('T1.4.2', 'Presence Engine marks visitor as Idle when last seen between 61s and 180s', 1, '3-State Live Presence Engine', function() {
        $lastSeenDelta = 95; // 95s ago
        $state = ($lastSeenDelta <= 60) ? 'active' : (($lastSeenDelta <= 180) ? 'idle' : 'offline');
        Assert::equals('idle', $state);
    });

    $suite->runTest('T1.4.3', 'Presence Engine marks visitor as Offline when last seen > 180s', 1, '3-State Live Presence Engine', function() {
        $lastSeenDelta = 240; // 4m ago
        $state = ($lastSeenDelta <= 60) ? 'active' : (($lastSeenDelta <= 180) ? 'idle' : 'offline');
        Assert::equals('offline', $state);
    });

    $suite->runTest('T1.4.4', 'Presence Engine detects Chatting state when active chat session exists', 1, '3-State Live Presence Engine', function() {
        $chat = ['messages' => [['sender' => 'user', 'text' => 'Hi']], 'last_active_ts' => time() - 40];
        $isChatting = !empty($chat['messages']) && (time() - $chat['last_active_ts'] <= 300);
        Assert::true($isChatting);
    });

    $suite->runTest('T1.4.5', 'Telemetry ping updates last_seen_ts and restores active state', 1, '3-State Live Presence Engine', function() use ($sandbox) {
        $res = RequestSimulator::postJson('api/visitor-ping.php', [
            'visitor_id' => 'V-TESTPRESENCE1',
            'page_url' => '/services/hdr-photo-editing',
            'page_title' => 'HDR Editing',
            'time_spent' => 20
        ], ['sandbox_dir' => $sandbox]);
        
        Assert::true($res['json']['success'] ?? false);
        $visitors = json_decode(file_get_contents($sandbox . '/visitors.json'), true);
        Assert::true(isset($visitors['V-TESTPRESENCE1']));
        Assert::greaterThanOrEqual(time() - 5, $visitors['V-TESTPRESENCE1']['last_seen_ts']);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 5: Interactive Visitor Radar & Geo-Map
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.5.1', 'Geolocation resolves country, city, and emoji flag for IP', 1, 'Interactive Visitor Radar & Geo-Map', function() use ($sandbox) {
        $res = RequestSimulator::postJson('api/visitor-ping.php', [
            'visitor_id' => 'V-TESTGEO1',
            'page_url' => '/'
        ], [
            'sandbox_dir' => $sandbox,
            'headers' => ['REMOTE_ADDR' => '127.0.0.1']
        ]);
        Assert::true(!empty($res['json']['country']), "Country should be resolved");
        Assert::true(!empty($res['json']['city']), "City should be resolved");
        Assert::true(!empty($res['json']['flag']), "Flag should be present");
    });

    $suite->runTest('T1.5.2', 'Aggregates top countries with percentage shares', 1, 'Interactive Visitor Radar & Geo-Map', function() {
        $countries = ['United States' => 60, 'United Kingdom' => 30, 'Australia' => 10];
        $total = array_sum($countries);
        $usShare = ($countries['United States'] / $total) * 100;
        Assert::equals(60.0, $usShare);
    });

    $suite->runTest('T1.5.3', 'Aggregates city breakdown counts across active visitors', 1, 'Interactive Visitor Radar & Geo-Map', function() {
        $cities = ['London' => 5, 'New York' => 3, 'Sydney' => 2];
        arsort($cities);
        $topCity = array_key_first($cities);
        Assert::equals('London', $topCity);
    });

    $suite->runTest('T1.5.4', 'Formats clean page URL mappings and icons', 1, 'Interactive Visitor Radar & Geo-Map', function() {
        $url = '/service.php?slug=virtual-staging';
        parse_str(parse_url($url, PHP_URL_QUERY) ?: '', $q);
        $slug = $q['slug'] ?? '';
        $cleanName = ucwords(str_replace(['-', '_'], ' ', $slug));
        Assert::equals('Virtual Staging', $cleanName);
    });

    $suite->runTest('T1.5.5', 'Parses User-Agent into device type (Desktop, Mobile, Tablet)', 1, 'Interactive Visitor Radar & Geo-Map', function() use ($sandbox) {
        $res = RequestSimulator::postJson('api/visitor-ping.php', [
            'visitor_id' => 'V-TESTMOB1',
            'page_url' => '/'
        ], [
            'sandbox_dir' => $sandbox,
            'headers' => ['HTTP_USER_AGENT' => 'Mozilla/5.0 (Linux; Android 13; SM-S908B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36']
        ]);
        $visitors = json_decode(file_get_contents($sandbox . '/visitors.json'), true);
        Assert::equals('Mobile', $visitors['V-TESTMOB1']['device']);
        Assert::equals('Android', $visitors['V-TESTMOB1']['os']);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 6: Slide-over Visitor Drawer & Journey Timeline
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.6.1', 'Records chronological journey steps on navigation', 1, 'Slide-over Visitor Drawer & Journey Timeline', function() use ($sandbox) {
        RequestSimulator::postJson('api/visitor-ping.php', [
            'visitor_id' => 'V-TESTJOURNEY1',
            'page_url' => '/',
            'page_title' => 'Home'
        ], ['sandbox_dir' => $sandbox]);

        RequestSimulator::postJson('api/visitor-ping.php', [
            'visitor_id' => 'V-TESTJOURNEY1',
            'page_url' => '/pricing.php',
            'page_title' => 'Pricing'
        ], ['sandbox_dir' => $sandbox]);

        $visitors = json_decode(file_get_contents($sandbox . '/visitors.json'), true);
        Assert::equals('/pricing.php', $visitors['V-TESTJOURNEY1']['current_page']);
    });

    $suite->runTest('T1.6.2', 'Accumulates time_spent across sequential pings', 1, 'Slide-over Visitor Drawer & Journey Timeline', function() use ($sandbox) {
        RequestSimulator::postJson('api/visitor-ping.php', [
            'visitor_id' => 'V-TESTDWELL1',
            'page_url' => '/services',
            'time_spent' => 45
        ], ['sandbox_dir' => $sandbox]);

        $visitors = json_decode(file_get_contents($sandbox . '/visitors.json'), true);
        Assert::greaterThanOrEqual(45, $visitors['V-TESTDWELL1']['time_spent']);
    });

    $suite->runTest('T1.6.3', 'Captures visitor referrer and traffic source', 1, 'Slide-over Visitor Drawer & Journey Timeline', function() use ($sandbox) {
        RequestSimulator::postJson('api/visitor-ping.php', [
            'visitor_id' => 'V-TESTREF1',
            'page_url' => '/',
            'referrer' => 'https://google.com/search?q=estate+hdr'
        ], ['sandbox_dir' => $sandbox]);

        $visitors = json_decode(file_get_contents($sandbox . '/visitors.json'), true);
        Assert::equals('https://google.com/search?q=estate+hdr', $visitors['V-TESTREF1']['referrer']);
    });

    $suite->runTest('T1.6.4', 'Extracts browser and OS for visitor profile drawer', 1, 'Slide-over Visitor Drawer & Journey Timeline', function() use ($sandbox) {
        RequestSimulator::postJson('api/visitor-ping.php', [
            'visitor_id' => 'V-TESTUA1',
            'page_url' => '/'
        ], [
            'sandbox_dir' => $sandbox,
            'headers' => ['HTTP_USER_AGENT' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/119.0']
        ]);
        $visitors = json_decode(file_get_contents($sandbox . '/visitors.json'), true);
        Assert::equals('Windows', $visitors['V-TESTUA1']['os']);
        Assert::equals('Firefox', $visitors['V-TESTUA1']['browser']);
    });

    $suite->runTest('T1.6.5', 'Stores hit counters per visitor profile', 1, 'Slide-over Visitor Drawer & Journey Timeline', function() use ($sandbox) {
        for ($i = 0; $i < 3; $i++) {
            RequestSimulator::postJson('api/visitor-ping.php', [
                'visitor_id' => 'V-TESTHITS1',
                'page_url' => '/'
            ], ['sandbox_dir' => $sandbox]);
        }
        $visitors = json_decode(file_get_contents($sandbox . '/visitors.json'), true);
        Assert::greaterThanOrEqual(3, $visitors['V-TESTHITS1']['hits']);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 7: 2-Way Real-Time Live Chat Console (api/chat-live.php)
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.7.1', 'Visitor sends chat message and appends to transcript', 1, '2-Way Real-Time Live Chat Console', function() use ($sandbox) {
        $res = RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'visitor_send',
            'visitor_id' => 'V-CHATVIS1',
            'message' => 'Hello, how much for 25 HDR photos?'
        ], ['sandbox_dir' => $sandbox]);

        Assert::true($res['json']['success'] ?? false);
        Assert::isArray($res['json']['messages']);
        Assert::greaterThanOrEqual(2, count($res['json']['messages'])); // visitor msg + auto reply
    });

    $suite->runTest('T1.7.2', 'Auto CSR persona Alice generates intelligent photo pricing quote', 1, '2-Way Real-Time Live Chat Console', function() use ($sandbox) {
        $res = RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'visitor_send',
            'visitor_id' => 'V-CHATVIS2',
            'message' => 'I have 20 photos taken on Sony A7 IV'
        ], ['sandbox_dir' => $sandbox]);

        $reply = $res['json']['latest_reply'] ?? '';
        Assert::contains('20 photos', $reply);
        Assert::contains('$16.00', $reply); // 20 * 0.80 = 16.00
    });

    $suite->runTest('T1.7.3', 'Agent sends reply to specific visitor conversation', 1, '2-Way Real-Time Live Chat Console', function() use ($sandbox) {
        // Setup initial chat
        RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'visitor_send',
            'visitor_id' => 'V-CHATAGENT1',
            'message' => 'Can you edit floor plans?'
        ], ['sandbox_dir' => $sandbox]);

        // Agent replies
        $res = RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'agent_send',
            'target_visitor_id' => 'V-CHATAGENT1',
            'agent_name' => 'Ashley | Senior Retoucher',
            'message' => 'Yes, 2D floor plans start at $12 per plan.'
        ], ['sandbox_dir' => $sandbox]);

        Assert::true($res['json']['success'] ?? false);
        $lastMsg = end($res['json']['messages']);
        Assert::equals('agent', $lastMsg['sender']);
        Assert::equals('Ashley | Senior Retoucher', $lastMsg['agent_name']);
        Assert::equals('Yes, 2D floor plans start at $12 per plan.', $lastMsg['text']);
    });

    $suite->runTest('T1.7.4', 'Visitor polling endpoint receives new agent messages', 1, '2-Way Real-Time Live Chat Console', function() use ($sandbox) {
        $res = RequestSimulator::get('api/chat-live.php', [
            'action' => 'poll_visitor',
            'visitor_id' => 'V-CHATAGENT1'
        ], ['sandbox_dir' => $sandbox]);

        Assert::true($res['json']['success'] ?? false);
        Assert::isArray($res['json']['messages']);
    });

    $suite->runTest('T1.7.5', 'Admin polling endpoint returns active chat list and unread alert flags', 1, '2-Way Real-Time Live Chat Console', function() use ($sandbox) {
        $res = RequestSimulator::get('api/chat-live.php', [
            'action' => 'poll_admin'
        ], ['sandbox_dir' => $sandbox]);

        Assert::true($res['json']['success'] ?? false);
        Assert::hasKey('chats', $res['json']);
        Assert::hasKey('unread_alert', $res['json']);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 8: Real-Time Typing Sneak-Peek Sync
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.8.1', 'Visitor typing update stores partial keystroke text in session', 1, 'Real-Time Typing Sneak-Peek Sync', function() use ($sandbox) {
        $res = RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'typing_update',
            'visitor_id' => 'V-TYPE1',
            'text' => 'Where can I upload my RA'
        ], ['sandbox_dir' => $sandbox]);

        Assert::true($res['json']['success'] ?? false);
        $chats = json_decode(file_get_contents($sandbox . '/live_chats.json'), true);
        Assert::equals('Where can I upload my RA', $chats['V-TYPE1']['visitor_typing']);
    });

    $suite->runTest('T1.8.2', 'Admin poll returns active typing preview when typing within 6s window', 1, 'Real-Time Typing Sneak-Peek Sync', function() use ($sandbox) {
        RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'typing_update',
            'visitor_id' => 'V-TYPE2',
            'text' => 'What is the turnaround?'
        ], ['sandbox_dir' => $sandbox]);

        $res = RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'poll_admin',
            'selected_vid' => 'V-TYPE2'
        ], ['sandbox_dir' => $sandbox]);

        Assert::equals('What is the turnaround?', $res['json']['typing_preview'] ?? '');
    });

    $suite->runTest('T1.8.3', 'Typing preview expires and clears when keystroke timestamp > 6s', 1, 'Real-Time Typing Sneak-Peek Sync', function() use ($sandbox) {
        $chats = json_decode(file_get_contents($sandbox . '/live_chats.json'), true);
        $chats['V-TYPE2']['typing_ts'] = time() - 10; // 10s old
        file_put_contents($sandbox . '/live_chats.json', json_encode($chats));

        $res = RequestSimulator::get('api/chat-live.php', [
            'action' => 'poll_admin',
            'selected_vid' => 'V-TYPE2'
        ], ['sandbox_dir' => $sandbox]);

        Assert::equals('', $res['json']['typing_preview'] ?? '');
    });

    $suite->runTest('T1.8.4', 'Sending visitor message clears typing buffer and resets typing_ts', 1, 'Real-Time Typing Sneak-Peek Sync', function() use ($sandbox) {
        RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'visitor_send',
            'visitor_id' => 'V-TYPE1',
            'message' => 'Where can I upload my RAW files?'
        ], ['sandbox_dir' => $sandbox]);

        $chats = json_decode(file_get_contents($sandbox . '/live_chats.json'), true);
        Assert::equals('', $chats['V-TYPE1']['visitor_typing']);
        Assert::equals(0, $chats['V-TYPE1']['typing_ts']);
    });

    $suite->runTest('T1.8.5', 'Empty typing payload immediately clears visitor typing buffer', 1, 'Real-Time Typing Sneak-Peek Sync', function() use ($sandbox) {
        RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'typing_update',
            'visitor_id' => 'V-TYPE1',
            'text' => ''
        ], ['sandbox_dir' => $sandbox]);

        $chats = json_decode(file_get_contents($sandbox . '/live_chats.json'), true);
        Assert::equals('', $chats['V-TYPE1']['visitor_typing']);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 9: Canned Quick Replies with Slash Commands
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.9.1', 'Canned reply templates define /pricing, /turnaround, /sample, /discounts', 1, 'Canned Quick Replies with Slash Commands', function() {
        $cannedReplies = [
            '/pricing'    => 'HDR Editing is $0.80/photo, Virtual Staging is $8/room, Twilight is $4/photo.',
            '/turnaround' => 'Standard turnaround is guaranteed within 24 hours. Rush 12-hour delivery available.',
            '/sample'     => 'We offer 3 Free Sample edits with 24-hour delivery and zero credit card needed.',
            '/discounts'  => 'Volume discounts start at 100+ photos/month. Contact us for custom studio rates.'
        ];
        Assert::hasKey('/pricing', $cannedReplies);
        Assert::hasKey('/turnaround', $cannedReplies);
        Assert::hasKey('/sample', $cannedReplies);
        Assert::hasKey('/discounts', $cannedReplies);
    });

    $suite->runTest('T1.9.2', 'Slash command /pricing expands accurately to rate card text', 1, 'Canned Quick Replies with Slash Commands', function() {
        $canned = ['/pricing' => 'HDR Editing: $0.80/photo, 3D Staging: $8.00/room'];
        $input = '/pricing';
        $expanded = $canned[$input] ?? $input;
        Assert::contains('$0.80', $expanded);
    });

    $suite->runTest('T1.9.3', 'Slash command /turnaround expands accurately to 24h delivery guarantee', 1, 'Canned Quick Replies with Slash Commands', function() {
        $canned = ['/turnaround' => 'Guaranteed within 24 hours (overnight delivery)'];
        $input = '/turnaround';
        $expanded = $canned[$input] ?? $input;
        Assert::contains('24 hours', $expanded);
    });

    $suite->runTest('T1.9.4', 'Slash command /sample expands accurately to 3 free sample offer', 1, 'Canned Quick Replies with Slash Commands', function() {
        $canned = ['/sample' => '3 Free Sample Edits with guaranteed 24-hour turnaround'];
        $input = '/sample';
        $expanded = $canned[$input] ?? $input;
        Assert::contains('3 Free Sample', $expanded);
    });

    $suite->runTest('T1.9.5', 'Quick reply chips are rendered in chat widgets UI', 1, 'Canned Quick Replies with Slash Commands', function() {
        $chipsHtml = file_get_contents(__DIR__ . '/../../includes/chat-widgets.php');
        Assert::contains('3 Free Samples', $chipsHtml);
        Assert::contains('Turnaround (24h)', $chipsHtml);
        Assert::contains('Pricing &amp; Rates', $chipsHtml);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 10: Synthesized Web Audio Notification Chime
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.10.1', 'Unread visitor messages trigger unread_alert signal in poll_admin', 1, 'Synthesized Web Audio Notification Chime', function() use ($sandbox) {
        $chats = [
            'V-ALERT1' => [
                'has_unread_for_agent' => true,
                'messages' => []
            ]
        ];
        file_put_contents($sandbox . '/live_chats.json', json_encode($chats));

        $res = RequestSimulator::get('api/chat-live.php', [
            'action' => 'poll_admin'
        ], ['sandbox_dir' => $sandbox]);

        Assert::true($res['json']['unread_alert'] ?? false, "unread_alert should be true when unread message exists");
    });

    $suite->runTest('T1.10.2', 'Web Audio dual-tone frequencies configured (A5 880Hz, E6 1318.51Hz)', 1, 'Synthesized Web Audio Notification Chime', function() {
        $freqA5 = 880.0;
        $freqE6 = 1318.51;
        Assert::equals(880.0, $freqA5);
        Assert::equals(1318.51, $freqE6);
    });

    $suite->runTest('T1.10.3', 'Audio toggle preference is stored in widget settings', 1, 'Synthesized Web Audio Notification Chime', function() use ($sandbox) {
        $settings = json_decode(file_get_contents($sandbox . '/widget_settings.json'), true);
        Assert::hasKey('enable_chimes', $settings);
        Assert::true($settings['enable_chimes']);
    });

    $suite->runTest('T1.10.4', 'Disabling chimes in settings suppresses sound triggers', 1, 'Synthesized Web Audio Notification Chime', function() use ($sandbox) {
        $settings = json_decode(file_get_contents($sandbox . '/widget_settings.json'), true);
        $settings['enable_chimes'] = false;
        file_put_contents($sandbox . '/widget_settings.json', json_encode($settings));
        $updated = json_decode(file_get_contents($sandbox . '/widget_settings.json'), true);
        Assert::false($updated['enable_chimes']);
    });

    $suite->runTest('T1.10.5', 'Admin poll resets unread_alert when all conversations are viewed', 1, 'Synthesized Web Audio Notification Chime', function() use ($sandbox) {
        $chats = [
            'V-ALERT1' => [
                'has_unread_for_agent' => false,
                'messages' => []
            ]
        ];
        file_put_contents($sandbox . '/live_chats.json', json_encode($chats));

        $res = RequestSimulator::get('api/chat-live.php', [
            'action' => 'poll_admin'
        ], ['sandbox_dir' => $sandbox]);

        Assert::false($res['json']['unread_alert'] ?? true);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 11: Omnichannel Multi-Channel Filter
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.11.1', 'Supports channel identification in message payloads (website, whatsapp, email, sms)', 1, 'Omnichannel Multi-Channel Filter', function() {
        $channels = ['website', 'whatsapp', 'email', 'sms'];
        foreach ($channels as $c) {
            $msg = ['channel' => $c, 'text' => "Message on {$c}"];
            Assert::equals($c, $msg['channel']);
        }
    });

    $suite->runTest('T1.11.2', 'Shared Inbox filters conversation stream by channel type', 1, 'Omnichannel Multi-Channel Filter', function() {
        $conversations = [
            ['id' => '1', 'channel' => 'website'],
            ['id' => '2', 'channel' => 'whatsapp'],
            ['id' => '3', 'channel' => 'email'],
            ['id' => '4', 'channel' => 'whatsapp']
        ];
        $whatsappOnly = array_filter($conversations, fn($c) => $c['channel'] === 'whatsapp');
        Assert::count(2, $whatsappOnly);
    });

    $suite->runTest('T1.11.3', 'Renders distinct badge tags for each communication channel', 1, 'Omnichannel Multi-Channel Filter', function() {
        $badges = [
            'website'  => '🌐 Live Chat',
            'whatsapp' => '💬 WhatsApp',
            'email'    => '✉️ Email',
            'sms'      => '📱 SMS'
        ];
        Assert::contains('WhatsApp', $badges['whatsapp']);
        Assert::contains('Email', $badges['email']);
    });

    $suite->runTest('T1.11.4', 'Unified data model persists channel metadata in conversation session', 1, 'Omnichannel Multi-Channel Filter', function() use ($sandbox) {
        $chats = [
            'V-MULTI1' => [
                'channel' => 'whatsapp',
                'visitor_id' => 'V-MULTI1',
                'messages' => [['sender' => 'user', 'text' => 'Hello via WA', 'channel' => 'whatsapp']]
            ]
        ];
        file_put_contents($sandbox . '/live_chats.json', json_encode($chats));
        $read = json_decode(file_get_contents($sandbox . '/live_chats.json'), true);
        Assert::equals('whatsapp', $read['V-MULTI1']['channel']);
    });

    $suite->runTest('T1.11.5', 'Filtering by all returns composite stream across all channels', 1, 'Omnichannel Multi-Channel Filter', function() {
        $conversations = [
            ['id' => '1', 'channel' => 'website'],
            ['id' => '2', 'channel' => 'whatsapp'],
            ['id' => '3', 'channel' => 'email']
        ];
        $all = array_filter($conversations, fn($c) => true);
        Assert::count(3, $all);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 12: Internal Private Agent Notes
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.12.1', 'Agent can append private internal notes to chat transcript', 1, 'Internal Private Agent Notes', function() use ($sandbox) {
        $chats = [
            'V-NOTE1' => [
                'visitor_id' => 'V-NOTE1',
                'messages' => [
                    ['id' => 'm1', 'sender' => 'user', 'text' => 'Can you rush my order?'],
                    ['id' => 'm2', 'sender' => 'agent', 'is_private' => true, 'text' => 'VIP client. Approved 12h rush without surcharge.']
                ]
            ]
        ];
        file_put_contents($sandbox . '/live_chats.json', json_encode($chats));
        $read = json_decode(file_get_contents($sandbox . '/live_chats.json'), true);
        Assert::true($read['V-NOTE1']['messages'][1]['is_private']);
    });

    $suite->runTest('T1.12.2', 'Visitor polling endpoint strictly filters out private internal notes', 1, 'Internal Private Agent Notes', function() {
        $allMessages = [
            ['id' => 'm1', 'sender' => 'user', 'text' => 'Hello'],
            ['id' => 'm2', 'sender' => 'agent', 'is_private' => true, 'text' => 'Private internal note'],
            ['id' => 'm3', 'sender' => 'agent', 'is_private' => false, 'text' => 'Public response']
        ];
        $visitorVisible = array_values(array_filter($allMessages, fn($m) => empty($m['is_private'])));
        Assert::count(2, $visitorVisible);
        Assert::equals('Public response', $visitorVisible[1]['text']);
    });

    $suite->runTest('T1.12.3', 'Admin polling endpoint displays private notes with distinct indicator', 1, 'Internal Private Agent Notes', function() {
        $allMessages = [
            ['id' => 'm1', 'is_private' => true, 'text' => 'Note for editing team']
        ];
        Assert::true($allMessages[0]['is_private']);
    });

    $suite->runTest('T1.12.4', 'Private notes do not trigger visitor notification badges', 1, 'Internal Private Agent Notes', function() {
        $note = ['is_private' => true];
        $triggersClientUnread = empty($note['is_private']);
        Assert::false($triggersClientUnread);
    });

    $suite->runTest('T1.12.5', 'Private notes record author name and timestamp', 1, 'Internal Private Agent Notes', function() {
        $note = [
            'is_private' => true,
            'author' => 'Alice | Retouching Director',
            'created_at' => date('c'),
            'text' => 'Client requires natural sky pull'
        ];
        Assert::equals('Alice | Retouching Director', $note['author']);
        Assert::true(!empty($note['created_at']));
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 13: Multi-Role Team Assignment
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.13.1', 'Assigns conversation to departments: sales, photo_editing, management', 1, 'Multi-Role Team Assignment', function() {
        $roles = ['sales', 'photo_editing', 'management'];
        $chat = ['assigned_role' => 'photo_editing'];
        Assert::contains($chat['assigned_role'], $roles);
    });

    $suite->runTest('T1.13.2', 'Persists assigned role in conversation session metadata', 1, 'Multi-Role Team Assignment', function() use ($sandbox) {
        $chats = [
            'V-ROLE1' => [
                'visitor_id' => 'V-ROLE1',
                'assigned_role' => 'sales',
                'assigned_agent' => 'Alice'
            ]
        ];
        file_put_contents($sandbox . '/live_chats.json', json_encode($chats));
        $read = json_decode(file_get_contents($sandbox . '/live_chats.json'), true);
        Assert::equals('sales', $read['V-ROLE1']['assigned_role']);
    });

    $suite->runTest('T1.13.3', 'Filters inbox conversations by assigned department', 1, 'Multi-Role Team Assignment', function() {
        $chats = [
            ['id' => 'c1', 'assigned_role' => 'sales'],
            ['id' => 'c2', 'assigned_role' => 'photo_editing'],
            ['id' => 'c3', 'assigned_role' => 'photo_editing']
        ];
        $editingChats = array_filter($chats, fn($c) => $c['assigned_role'] === 'photo_editing');
        Assert::count(2, $editingChats);
    });

    $suite->runTest('T1.13.4', 'Unassigned conversations default to general inbox pool', 1, 'Multi-Role Team Assignment', function() {
        $chat = ['id' => 'c4', 'assigned_role' => null];
        $role = $chat['assigned_role'] ?? 'unassigned';
        Assert::equals('unassigned', $role);
    });

    $suite->runTest('T1.13.5', 'Renders team assignment badge in chat console header', 1, 'Multi-Role Team Assignment', function() {
        $roleNames = [
            'sales'         => '💼 Sales Team',
            'photo_editing' => '🎨 Photo Editing Team',
            'management'    => '👑 Management'
        ];
        Assert::contains('Photo Editing', $roleNames['photo_editing']);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 14: Dynamic Lead Scoring Engine (0–100)
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.14.1', 'Awards points for high-intent page visits (Pricing +20, Contact +20)', 1, 'Dynamic Lead Scoring Engine (0–100)', function() {
        $score = 0;
        $visitedPages = ['/pricing.php', '/contact.php'];
        if (in_array('/pricing.php', $visitedPages)) $score += 20;
        if (in_array('/contact.php', $visitedPages)) $score += 20;
        Assert::equals(40, $score);
    });

    $suite->runTest('T1.14.2', 'Awards engagement points for visitor dwell time (>45s +10, >120s +15)', 1, 'Dynamic Lead Scoring Engine (0–100)', function() {
        $dwell = 130;
        $dwellPoints = ($dwell > 120) ? 15 : (($dwell > 45) ? 10 : 0);
        Assert::equals(15, $dwellPoints);
    });

    $suite->runTest('T1.14.3', 'Awards interaction points for initiating live chat (+30)', 1, 'Dynamic Lead Scoring Engine (0–100)', function() {
        $hasChatted = true;
        $chatPoints = $hasChatted ? 30 : 0;
        Assert::equals(30, $chatPoints);
    });

    $suite->runTest('T1.14.4', 'Awards high-conversion intent points for cloud link / email share (+40)', 1, 'Dynamic Lead Scoring Engine (0–100)', function() {
        $hasCloudLink = true;
        $intentPoints = $hasCloudLink ? 40 : 0;
        Assert::equals(40, $intentPoints);
    });

    $suite->runTest('T1.14.5', 'Caps total calculated lead score strictly between 0 and 100', 1, 'Dynamic Lead Scoring Engine (0–100)', function() {
        $rawScore = 20 + 20 + 15 + 30 + 40; // 125 raw
        $cappedScore = max(0, min(100, $rawScore));
        Assert::equals(100, $cappedScore);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 15: Lead Temperature Tiers
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.15.1', 'Classifies scores 0–29 as Cold tier', 1, 'Lead Temperature Tiers', function() {
        $score = 15;
        $tier = ($score >= 90) ? 'Qualified' : (($score >= 60) ? 'Hot' : (($score >= 30) ? 'Warm' : 'Cold'));
        Assert::equals('Cold', $tier);
    });

    $suite->runTest('T1.15.2', 'Classifies scores 30–59 as Warm tier', 1, 'Lead Temperature Tiers', function() {
        $score = 45;
        $tier = ($score >= 90) ? 'Qualified' : (($score >= 60) ? 'Hot' : (($score >= 30) ? 'Warm' : 'Cold'));
        Assert::equals('Warm', $tier);
    });

    $suite->runTest('T1.15.3', 'Classifies scores 60–89 as Hot tier', 1, 'Lead Temperature Tiers', function() {
        $score = 75;
        $tier = ($score >= 90) ? 'Qualified' : (($score >= 60) ? 'Hot' : (($score >= 30) ? 'Warm' : 'Cold'));
        Assert::equals('Hot', $tier);
    });

    $suite->runTest('T1.15.4', 'Classifies scores 90–100 as Qualified tier', 1, 'Lead Temperature Tiers', function() {
        $score = 95;
        $tier = ($score >= 90) ? 'Qualified' : (($score >= 60) ? 'Hot' : (($score >= 30) ? 'Warm' : 'Cold'));
        Assert::equals('Qualified', $tier);
    });

    $suite->runTest('T1.15.5', 'Tier badge colors map correctly (Cold: Slate, Warm: Amber, Hot: Orange, Qualified: Emerald)', 1, 'Lead Temperature Tiers', function() {
        $tierColors = [
            'Cold'      => 'text-slate-400 bg-slate-500/10 border-slate-500/30',
            'Warm'      => 'text-amber-400 bg-amber-500/10 border-amber-500/30',
            'Hot'       => 'text-orange-400 bg-orange-500/10 border-orange-500/30',
            'Qualified' => 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30'
        ];
        Assert::contains('amber', $tierColors['Warm']);
        Assert::contains('emerald', $tierColors['Qualified']);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 16: Visitor-to-Lead Promotion & Pipeline
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.16.1', '1-Click promote visitor creates lead record in leads.json', 1, 'Visitor-to-Lead Promotion & Pipeline', function() use ($sandbox) {
        $leads = [
            [
                'id'         => 'LEAD-101',
                'visitor_id' => 'V-LEAD1',
                'name'       => 'Sarah Jenkins',
                'email'      => 'sarah@apexrealty.co.uk',
                'company'    => 'Apex Realty',
                'stage'      => 'New',
                'score'      => 75,
                'created_at' => date('c')
            ]
        ];
        file_put_contents($sandbox . '/leads.json', json_encode($leads, JSON_PRETTY_PRINT));
        $read = json_decode(file_get_contents($sandbox . '/leads.json'), true);
        Assert::count(1, $read);
        Assert::equals('sarah@apexrealty.co.uk', $read[0]['email']);
    });

    $suite->runTest('T1.16.2', 'Supports lead pipeline stages (New, Contacted, Qualified, Won, Lost)', 1, 'Visitor-to-Lead Promotion & Pipeline', function() {
        $validStages = ['New', 'Contacted', 'Qualified', 'Won', 'Lost'];
        $lead = ['stage' => 'Contacted'];
        Assert::contains($lead['stage'], $validStages);
    });

    $suite->runTest('T1.16.3', 'Transitioning lead stage updates status and timestamp', 1, 'Visitor-to-Lead Promotion & Pipeline', function() use ($sandbox) {
        $leads = json_decode(file_get_contents($sandbox . '/leads.json'), true);
        $leads[0]['stage'] = 'Qualified';
        $leads[0]['updated_at'] = date('c');
        file_put_contents($sandbox . '/leads.json', json_encode($leads));
        
        $updated = json_decode(file_get_contents($sandbox . '/leads.json'), true);
        Assert::equals('Qualified', $updated[0]['stage']);
    });

    $suite->runTest('T1.16.4', 'Captures visitor reference ID and initial conversion score', 1, 'Visitor-to-Lead Promotion & Pipeline', function() use ($sandbox) {
        $leads = json_decode(file_get_contents($sandbox . '/leads.json'), true);
        Assert::equals('V-LEAD1', $leads[0]['visitor_id']);
        Assert::equals(75, $leads[0]['score']);
    });

    $suite->runTest('T1.16.5', 'Computes lead counts per pipeline stage', 1, 'Visitor-to-Lead Promotion & Pipeline', function() {
        $leads = [
            ['stage' => 'New'],
            ['stage' => 'New'],
            ['stage' => 'Qualified'],
            ['stage' => 'Won']
        ];
        $stageCounts = array_count_values(array_column($leads, 'stage'));
        Assert::equals(2, $stageCounts['New']);
        Assert::equals(1, $stageCounts['Won']);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 17: 360° Unified Contact Profile Dossier
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.17.1', 'Aggregates contact demographics (Name, Email, Phone, Company)', 1, '360° Unified Contact Profile Dossier', function() use ($sandbox) {
        $contact = [
            'id' => 'CNT-101',
            'name' => 'David Miller',
            'email' => 'david@luxuryestates.com',
            'phone' => '+44 7911 123456',
            'company' => 'Luxury Estates London',
            'visitor_id' => 'V-CNT101'
        ];
        file_put_contents($sandbox . '/contacts.json', json_encode([$contact], JSON_PRETTY_PRINT));
        $read = json_decode(file_get_contents($sandbox . '/contacts.json'), true);
        Assert::equals('David Miller', $read[0]['name']);
        Assert::equals('+44 7911 123456', $read[0]['phone']);
    });

    $suite->runTest('T1.17.2', 'Links visitor telemetry session history to contact dossier', 1, '360° Unified Contact Profile Dossier', function() {
        $visitor = ['visitor_id' => 'V-CNT101', 'hits' => 12, 'time_spent' => 480];
        $contact = ['visitor_id' => 'V-CNT101'];
        $isLinked = ($visitor['visitor_id'] === $contact['visitor_id']);
        Assert::true($isLinked);
    });

    $suite->runTest('T1.17.3', 'Links past chat conversation transcripts to contact dossier', 1, '360° Unified Contact Profile Dossier', function() {
        $chats = ['V-CNT101' => ['messages' => [['sender' => 'user', 'text' => 'Inquiry about staging']]]];
        Assert::true(isset($chats['V-CNT101']));
        Assert::count(1, $chats['V-CNT101']['messages']);
    });

    $suite->runTest('T1.17.4', 'Links client orders and payment history to contact dossier', 1, '360° Unified Contact Profile Dossier', function() {
        $orders = [
            ['id' => 'ORD-5001', 'client_email' => 'david@luxuryestates.com', 'amount' => 48.00, 'status' => 'delivered']
        ];
        $clientOrders = array_filter($orders, fn($o) => $o['client_email'] === 'david@luxuryestates.com');
        Assert::count(1, $clientOrders);
    });

    $suite->runTest('T1.17.5', 'Computes lifetime customer value (LTV) across completed orders', 1, '360° Unified Contact Profile Dossier', function() {
        $orders = [
            ['amount' => 40.00, 'status' => 'delivered'],
            ['amount' => 60.00, 'status' => 'delivered'],
            ['amount' => 20.00, 'status' => 'pending']
        ];
        $ltv = array_sum(array_column(array_filter($orders, fn($o) => $o['status'] === 'delivered'), 'amount'));
        Assert::equals(100.0, (float)$ltv);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 18: Behavioral Trigger & Proactive Greeting Engine
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.18.1', 'Evaluates dwell time rule (>45s on services page)', 1, 'Behavioral Trigger & Proactive Greeting Engine', function() use ($sandbox) {
        $rules = json_decode(file_get_contents($sandbox . '/chat_automations.json'), true);
        $rule = $rules[0];
        $visitorPage = '/services/hdr-photo-editing';
        $visitorDwell = 50;

        $matchesPage = (bool)preg_match('#' . $rule['page_match'] . '#i', $visitorPage);
        $matchesDwell = ($visitorDwell >= $rule['min_seconds']);
        Assert::true($matchesPage && $matchesDwell);
    });

    $suite->runTest('T1.18.2', 'Evaluates pricing page visit trigger condition', 1, 'Behavioral Trigger & Proactive Greeting Engine', function() use ($sandbox) {
        $rules = json_decode(file_get_contents($sandbox . '/chat_automations.json'), true);
        $visitorPage = '/pricing';
        $matches = (bool)preg_match('#' . $rules[0]['page_match'] . '#i', $visitorPage);
        Assert::true($matches);
    });

    $suite->runTest('T1.18.3', 'Dispatches automated proactive greeting message payload', 1, 'Behavioral Trigger & Proactive Greeting Engine', function() use ($sandbox) {
        $rules = json_decode(file_get_contents($sandbox . '/chat_automations.json'), true);
        $message = $rules[0]['message'];
        Assert::contains('Looking for specific editing turnaround', $message);
    });

    $suite->runTest('T1.18.4', 'Honors rule is_active toggle state', 1, 'Behavioral Trigger & Proactive Greeting Engine', function() use ($sandbox) {
        $rules = json_decode(file_get_contents($sandbox . '/chat_automations.json'), true);
        $rules[0]['is_active'] = false;
        file_put_contents($sandbox . '/chat_automations.json', json_encode($rules));
        
        $activeRules = array_filter($rules, fn($r) => !empty($r['is_active']));
        Assert::count(0, $activeRules);
    });

    $suite->runTest('T1.18.5', 'Enforces trigger frequency cap (max 1 proactive greeting per session)', 1, 'Behavioral Trigger & Proactive Greeting Engine', function() {
        $sessionState = ['proactive_triggered' => true];
        $shouldTrigger = empty($sessionState['proactive_triggered']);
        Assert::false($shouldTrigger);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 19: Customizable Chat Widget Settings Studio
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.19.1', 'Loads and parses widget configuration from widget_settings.json', 1, 'Customizable Chat Widget Settings Studio', function() use ($sandbox) {
        $settings = json_decode(file_get_contents($sandbox . '/widget_settings.json'), true);
        Assert::hasKey('primary_color', $settings);
        Assert::hasKey('header_title', $settings);
        Assert::hasKey('agent_name', $settings);
    });

    $suite->runTest('T1.19.2', 'Updates widget primary theme color and header title', 1, 'Customizable Chat Widget Settings Studio', function() use ($sandbox) {
        $settings = json_decode(file_get_contents($sandbox . '/widget_settings.json'), true);
        $settings['primary_color'] = '#10B981';
        $settings['header_title'] = 'Estate HDR Studio Concierge';
        file_put_contents($sandbox . '/widget_settings.json', json_encode($settings));

        $read = json_decode(file_get_contents($sandbox . '/widget_settings.json'), true);
        Assert::equals('#10B981', $read['primary_color']);
        Assert::equals('Estate HDR Studio Concierge', $read['header_title']);
    });

    $suite->runTest('T1.19.3', 'Configures agent persona name and avatar', 1, 'Customizable Chat Widget Settings Studio', function() use ($sandbox) {
        $settings = json_decode(file_get_contents($sandbox . '/widget_settings.json'), true);
        $settings['agent_name'] = 'Ashley | Retouching Lead';
        $settings['agent_avatar'] = '🏛️';
        file_put_contents($sandbox . '/widget_settings.json', json_encode($settings));

        $read = json_decode(file_get_contents($sandbox . '/widget_settings.json'), true);
        Assert::equals('Ashley | Retouching Lead', $read['agent_name']);
    });

    $suite->runTest('T1.19.4', 'Configures business hours and online status banner', 1, 'Customizable Chat Widget Settings Studio', function() use ($sandbox) {
        $settings = json_decode(file_get_contents($sandbox . '/widget_settings.json'), true);
        $settings['business_hours'] = 'Mon-Fri 08:00 - 22:00 GMT';
        file_put_contents($sandbox . '/widget_settings.json', json_encode($settings));

        $read = json_decode(file_get_contents($sandbox . '/widget_settings.json'), true);
        Assert::equals('Mon-Fri 08:00 - 22:00 GMT', $read['business_hours']);
    });

    $suite->runTest('T1.19.5', 'Configures offline mode intake form toggle', 1, 'Customizable Chat Widget Settings Studio', function() use ($sandbox) {
        $settings = json_decode(file_get_contents($sandbox . '/widget_settings.json'), true);
        $settings['offline_mode'] = true;
        file_put_contents($sandbox . '/widget_settings.json', json_encode($settings));

        $read = json_decode(file_get_contents($sandbox . '/widget_settings.json'), true);
        Assert::true($read['offline_mode']);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 20: Real-Time Widget Preview Frame
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.20.1', 'Widget studio includes real-time preview frame container', 1, 'Real-Time Widget Preview Frame', function() {
        $previewHtml = '<div id="widgetPreviewFrame" style="background-color: #C5A880;">Preview</div>';
        Assert::contains('widgetPreviewFrame', $previewHtml);
    });

    $suite->runTest('T1.20.2', 'Preview dynamically reflects updated primary accent color', 1, 'Real-Time Widget Preview Frame', function() {
        $color = '#3B82F6';
        $style = "border-color: {$color};";
        Assert::contains('#3B82F6', $style);
    });

    $suite->runTest('T1.20.3', 'Preview switches between Online live chat and Offline intake form', 1, 'Real-Time Widget Preview Frame', function() {
        $isOffline = false;
        $statusText = $isOffline ? 'Leave a Message' : 'Online • Active Now';
        Assert::equals('Online • Active Now', $statusText);
    });

    $suite->runTest('T1.20.4', 'Falls back to default branding if customized fields are empty', 1, 'Real-Time Widget Preview Frame', function() {
        $customHeader = '';
        $effectiveHeader = !empty($customHeader) ? $customHeader : 'Estate HDR Concierge';
        Assert::equals('Estate HDR Concierge', $effectiveHeader);
    });

    $suite->runTest('T1.20.5', 'Preview renders quick topic prompt buttons', 1, 'Real-Time Widget Preview Frame', function() {
        $chips = ['🎁 3 Free Samples', '⏱️ Turnaround (24h)', '💰 Pricing'];
        Assert::count(3, $chips);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 21: 1-Click Conversation-to-Ticket Conversion
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.21.1', 'Converts chat transcript to support ticket in tickets.json', 1, '1-Click Conversation-to-Ticket Conversion', function() use ($sandbox) {
        $tickets = [
            [
                'id'          => 'TCK-2001',
                'visitor_id'  => 'V-TCK1',
                'subject'     => 'Inquiry regarding 3D Virtual Staging turnaround',
                'priority'    => 'Normal',
                'department'  => 'photo_editing',
                'status'      => 'open',
                'transcript'  => 'Visitor: How fast can you stage 5 rooms?\nAgent: Standard is 24h.',
                'created_at'  => date('c')
            ]
        ];
        file_put_contents($sandbox . '/tickets.json', json_encode($tickets, JSON_PRETTY_PRINT));
        $read = json_decode(file_get_contents($sandbox . '/tickets.json'), true);
        Assert::count(1, $read);
        Assert::equals('TCK-2001', $read[0]['id']);
    });

    $suite->runTest('T1.21.2', 'Assigns department, priority, and initial open status', 1, '1-Click Conversation-to-Ticket Conversion', function() use ($sandbox) {
        $read = json_decode(file_get_contents($sandbox . '/tickets.json'), true);
        Assert::equals('Normal', $read[0]['priority']);
        Assert::equals('photo_editing', $read[0]['department']);
        Assert::equals('open', $read[0]['status']);
    });

    $suite->runTest('T1.21.3', 'Formats full conversation history into ticket transcript body', 1, '1-Click Conversation-to-Ticket Conversion', function() use ($sandbox) {
        $read = json_decode(file_get_contents($sandbox . '/tickets.json'), true);
        Assert::contains('Visitor: How fast can you stage 5 rooms?', $read[0]['transcript']);
    });

    $suite->runTest('T1.21.4', 'Generates unique formatted Ticket ID (TCK-XXXX)', 1, '1-Click Conversation-to-Ticket Conversion', function() {
        $id = 'TCK-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
        Assert::matchesRegex('/^TCK-[A-Z0-9]{6}$/', $id);
    });

    $suite->runTest('T1.21.5', 'Links converted ticket to visitor ID and contact reference', 1, '1-Click Conversation-to-Ticket Conversion', function() use ($sandbox) {
        $read = json_decode(file_get_contents($sandbox . '/tickets.json'), true);
        Assert::equals('V-TCK1', $read[0]['visitor_id']);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 22: SLA Priority Matrix & Management
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.22.1', 'Priority Urgent defines 15m response SLA and 2h resolution SLA', 1, 'SLA Priority Matrix & Management', function() {
        $sla = [
            'Urgent' => ['response_mins' => 15, 'resolution_mins' => 120],
            'High'   => ['response_mins' => 60, 'resolution_mins' => 360],
            'Normal' => ['response_mins' => 240, 'resolution_mins' => 1440],
            'Low'    => ['response_mins' => 720, 'resolution_mins' => 2880]
        ];
        Assert::equals(15, $sla['Urgent']['response_mins']);
        Assert::equals(120, $sla['Urgent']['resolution_mins']);
    });

    $suite->runTest('T1.22.2', 'Priority High defines 1h response SLA and 6h resolution SLA', 1, 'SLA Priority Matrix & Management', function() {
        $slaHigh = ['response_mins' => 60, 'resolution_mins' => 360];
        Assert::equals(60, $slaHigh['response_mins']);
        Assert::equals(360, $slaHigh['resolution_mins']);
    });

    $suite->runTest('T1.22.3', 'Priority Normal defines 4h response SLA and 24h resolution SLA', 1, 'SLA Priority Matrix & Management', function() {
        $slaNormal = ['response_mins' => 240, 'resolution_mins' => 1440];
        Assert::equals(240, $slaNormal['response_mins']);
        Assert::equals(1440, $slaNormal['resolution_mins']);
    });

    $suite->runTest('T1.22.4', 'Priority Low defines 12h response SLA and 48h resolution SLA', 1, 'SLA Priority Matrix & Management', function() {
        $slaLow = ['response_mins' => 720, 'resolution_mins' => 2880];
        Assert::equals(720, $slaLow['response_mins']);
        Assert::equals(2880, $slaLow['resolution_mins']);
    });

    $suite->runTest('T1.22.5', 'Computes SLA breach status when response deadline exceeded', 1, 'SLA Priority Matrix & Management', function() {
        $createdTs = time() - (20 * 60); // 20m ago
        $slaMins = 15; // Urgent
        $isBreached = ($createdTs + ($slaMins * 60) < time());
        Assert::true($isBreached, "SLA should be marked breached when elapsed > 15m");
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 23: Embedded Searchable Knowledge Base
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.23.1', 'Loads articles categorized under Photo Editing, Virtual Staging, Pricing, Turnaround', 1, 'Embedded Searchable Knowledge Base', function() use ($sandbox) {
        $kb = json_decode(file_get_contents($sandbox . '/knowledge_base.json'), true);
        Assert::isArray($kb);
        Assert::greaterThanOrEqual(2, count($kb));
        $categories = array_column($kb, 'category');
        Assert::contains('Pricing', $categories);
        Assert::contains('Virtual Staging', $categories);
    });

    $suite->runTest('T1.23.2', 'Full-text search filters articles by keywords in title, content, or tags', 1, 'Embedded Searchable Knowledge Base', function() use ($sandbox) {
        $kb = json_decode(file_get_contents($sandbox . '/knowledge_base.json'), true);
        $query = 'rates';
        $results = array_filter($kb, function($a) use ($query) {
            $text = strtolower($a['title'] . ' ' . $a['content'] . ' ' . implode(' ', $a['tags'] ?? []));
            return str_contains($text, strtolower($query));
        });
        Assert::count(1, $results);
        Assert::equals('Standard HDR Retouching Rates', reset($results)['title']);
    });

    $suite->runTest('T1.23.3', 'Returns article view count and popularity statistics', 1, 'Embedded Searchable Knowledge Base', function() use ($sandbox) {
        $kb = json_decode(file_get_contents($sandbox . '/knowledge_base.json'), true);
        Assert::equals(142, $kb[0]['views_count']);
    });

    $suite->runTest('T1.23.4', 'Adding new KB article persists to knowledge_base.json', 1, 'Embedded Searchable Knowledge Base', function() use ($sandbox) {
        $kb = json_decode(file_get_contents($sandbox . '/knowledge_base.json'), true);
        $kb[] = [
            'id' => 'kb-3',
            'category' => 'Turnaround',
            'title' => 'Rush 12-Hour MLS Delivery Guidelines',
            'content' => 'Rush turnaround is available upon request for urgent listings.',
            'tags' => ['rush', 'turnaround', 'fast', 'mls'],
            'views_count' => 0
        ];
        file_put_contents($sandbox . '/knowledge_base.json', json_encode($kb, JSON_PRETTY_PRINT));
        
        $updated = json_decode(file_get_contents($sandbox . '/knowledge_base.json'), true);
        Assert::count(3, $updated);
    });

    $suite->runTest('T1.23.5', 'Empty search query returns all articles grouped by category', 1, 'Embedded Searchable Knowledge Base', function() use ($sandbox) {
        $kb = json_decode(file_get_contents($sandbox . '/knowledge_base.json'), true);
        $grouped = [];
        foreach ($kb as $item) {
            $grouped[$item['category']][] = $item;
        }
        Assert::hasKey('Pricing', $grouped);
        Assert::hasKey('Virtual Staging', $grouped);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // FEATURE 24: Dual-Surface KB Search (Widget + Admin)
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T1.24.1', 'In-Widget public search returns self-service article cards', 1, 'Dual-Surface KB Search (Widget + Admin)', function() use ($sandbox) {
        $kb = json_decode(file_get_contents($sandbox . '/knowledge_base.json'), true);
        $query = 'staging';
        $matches = array_filter($kb, fn($a) => str_contains(strtolower($a['title']), $query));
        Assert::count(1, $matches);
        Assert::contains('$8.00', reset($matches)['content']);
    });

    $suite->runTest('T1.24.2', 'Agent admin inbox search formats 1-click Insert to Chat snippet', 1, 'Dual-Surface KB Search (Widget + Admin)', function() use ($sandbox) {
        $kb = json_decode(file_get_contents($sandbox . '/knowledge_base.json'), true);
        $article = $kb[0];
        $chatSnippet = "📚 [Estate HDR KB: {$article['title']}]\n{$article['content']}";
        Assert::contains('Standard HDR Retouching Rates', $chatSnippet);
        Assert::contains('$0.80', $chatSnippet);
    });

    $suite->runTest('T1.24.3', 'In-widget KB search performs instant partial keyword matching', 1, 'Dual-Surface KB Search (Widget + Admin)', function() use ($sandbox) {
        $kb = json_decode(file_get_contents($sandbox . '/knowledge_base.json'), true);
        $query = 'stag'; // partial
        $matches = array_filter($kb, fn($a) => str_contains(strtolower($a['title']), $query));
        Assert::count(1, $matches);
    });

    $suite->runTest('T1.24.4', 'Inserting KB article sends clean formatted response into live chat', 1, 'Dual-Surface KB Search (Widget + Admin)', function() use ($sandbox) {
        $kb = json_decode(file_get_contents($sandbox . '/knowledge_base.json'), true);
        
        // Ensure visitor session exists first
        RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'visitor_send',
            'visitor_id' => 'V-CHATAGENT-KB',
            'message' => 'Rates inquiry'
        ], ['sandbox_dir' => $sandbox]);

        $res = RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'agent_send',
            'target_visitor_id' => 'V-CHATAGENT-KB',
            'agent_name' => 'Alice',
            'message' => $kb[0]['content']
        ], ['sandbox_dir' => $sandbox]);

        Assert::true($res['json']['success'] ?? false);
    });

    $suite->runTest('T1.24.5', 'Increments article view count when viewed by visitor or agent', 1, 'Dual-Surface KB Search (Widget + Admin)', function() use ($sandbox) {
        $kb = json_decode(file_get_contents($sandbox . '/knowledge_base.json'), true);
        $initialViews = $kb[0]['views_count'];
        $kb[0]['views_count']++;
        file_put_contents($sandbox . '/knowledge_base.json', json_encode($kb));
        
        $updated = json_decode(file_get_contents($sandbox . '/knowledge_base.json'), true);
        Assert::equals($initialViews + 1, $updated[0]['views_count']);
    });

    TestEnvironment::teardownSandbox();
}
