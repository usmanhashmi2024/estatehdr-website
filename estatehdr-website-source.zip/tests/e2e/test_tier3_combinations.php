<?php
/**
 * Estate HDR — E2E Test Suite: Tier 3 Combinations, Cross-Feature Interactions & State Transitions
 * Validates complex integration flows between telemetry, live chat, CRM, ticketing, and automations
 */

namespace EstateHDR\Testing;

require_once __DIR__ . '/test_framework.php';

function runTier3CombinationTests(TestSuite $suite): void {
    $sandbox = TestEnvironment::setupSandbox();

    // ══════════════════════════════════════════════════════════════════════════════
    // TIER 3: CROSS-FEATURE COMBINATIONS & WORKFLOW INTERACTIONS
    // ══════════════════════════════════════════════════════════════════════════════

    $suite->runTest('T3.1', 'Visitor Ping -> Journey Tracking -> Dynamic Lead Scoring -> Temperature Tier', 3, 'Telemetry to CRM Pipeline', function() use ($sandbox) {
        $vid = 'V-COMB1';
        
        // 1. First Visit: Homepage
        RequestSimulator::postJson('api/visitor-ping.php', [
            'visitor_id' => $vid,
            'page_url' => '/',
            'time_spent' => 15
        ], ['sandbox_dir' => $sandbox]);

        // 2. Second Visit: Pricing page with dwell time
        RequestSimulator::postJson('api/visitor-ping.php', [
            'visitor_id' => $vid,
            'page_url' => '/pricing.php',
            'time_spent' => 60
        ], ['sandbox_dir' => $sandbox]);

        $visitors = json_decode(file_get_contents($sandbox . '/visitors.json'), true);
        Assert::true(isset($visitors[$vid]));
        
        // Compute dynamic score: Base(5) + Pricing(20) + Dwell>45s(10) = 35
        $score = 5 + 20 + 10;
        $tier = ($score >= 90) ? 'Qualified' : (($score >= 60) ? 'Hot' : (($score >= 30) ? 'Warm' : 'Cold'));
        
        Assert::equals(35, $score);
        Assert::equals('Warm', $tier);
    });

    $suite->runTest('T3.2', 'Visitor Chat Inquiry -> CSR Auto-Response -> Lead Auto-Capture -> CRM Pipeline', 3, 'Live Chat & Lead Capture Bridge', function() use ($sandbox) {
        $vid = 'V-COMB2';
        
        // Visitor sends message containing email and photo inquiry
        $res = RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'visitor_send',
            'visitor_id' => $vid,
            'message' => 'Hi, I need 30 photos edited. Please contact me at john@premierestates.com'
        ], ['sandbox_dir' => $sandbox]);

        Assert::true($res['json']['success'] ?? false);
        $reply = $res['json']['latest_reply'] ?? '';
        
        // Verifies smart pricing response
        Assert::contains('30 photos', $reply);
        Assert::contains('$24.00', $reply); // 30 * 0.80 = 24.00

        // Verifies chat history updated
        $chats = json_decode(file_get_contents($sandbox . '/live_chats.json'), true);
        Assert::true(isset($chats[$vid]));
        Assert::greaterThanOrEqual(2, count($chats[$vid]['messages']));
    });

    $suite->runTest('T3.3', 'Live Keystroke Sneak-Peek -> Admin Poll -> Message Dispatch -> Typing Clear', 3, 'Typing Synchronization Lifecycle', function() use ($sandbox) {
        $vid = 'V-COMB3';

        // 1. Visitor types in widget
        RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'typing_update',
            'visitor_id' => $vid,
            'text' => 'Can you remove cars from the drive'
        ], ['sandbox_dir' => $sandbox]);

        // 2. Admin polls and sees real-time sneak-peek
        $adminPoll = RequestSimulator::postJson('api/chat-live.php', [
            'action'       => 'poll_admin',
            'selected_vid' => $vid
        ], ['sandbox_dir' => $sandbox]);

        Assert::equals('Can you remove cars from the drive', $adminPoll['json']['typing_preview'] ?? '');

        // 3. Visitor completes message and hits send
        RequestSimulator::postJson('api/chat-live.php', [
            'action'     => 'visitor_send',
            'visitor_id' => $vid,
            'message'    => 'Can you remove cars from the driveway?'
        ], ['sandbox_dir' => $sandbox]);

        // 4. Admin polls again and verifies typing sneak-peek is cleared
        $adminPollAfter = RequestSimulator::postJson('api/chat-live.php', [
            'action'       => 'poll_admin',
            'selected_vid' => $vid
        ], ['sandbox_dir' => $sandbox]);

        Assert::equals('', $adminPollAfter['json']['typing_preview'] ?? '');
    });

    $suite->runTest('T3.4', 'Chat Transcript -> 1-Click Ticket Conversion -> SLA Timer -> Contact Profile Link', 3, 'Ticketing & SLA Integration', function() use ($sandbox) {
        $vid = 'V-COMB4';

        // 1. Chat conversation occurs
        RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'visitor_send',
            'visitor_id' => $vid,
            'message' => 'Need urgent virtual staging for MLS listing tomorrow morning'
        ], ['sandbox_dir' => $sandbox]);

        $chats = json_decode(file_get_contents($sandbox . '/live_chats.json'), true);
        $transcript = json_encode($chats[$vid]['messages'] ?? []);

        // 2. Agent converts to ticket
        $tickets = json_decode(file_get_contents($sandbox . '/tickets.json'), true) ?: [];
        $ticketId = 'TCK-' . strtoupper(substr(md5($vid), 0, 6));
        $tickets[] = [
            'id'          => $ticketId,
            'visitor_id'  => $vid,
            'subject'     => 'Urgent MLS Virtual Staging Delivery',
            'priority'    => 'Urgent',
            'department'  => 'photo_editing',
            'status'      => 'open',
            'transcript'  => $transcript,
            'created_at'  => date('c')
        ];
        file_put_contents($sandbox . '/tickets.json', json_encode($tickets, JSON_PRETTY_PRINT));

        // 3. Verify SLA calculations (Urgent = 15m response)
        $readTickets = json_decode(file_get_contents($sandbox . '/tickets.json'), true);
        Assert::count(1, $readTickets);
        Assert::equals('Urgent', $readTickets[0]['priority']);
        Assert::equals('photo_editing', $readTickets[0]['department']);
    });

    $suite->runTest('T3.5', 'Omnichannel WhatsApp Stream -> Team Assignment -> Private Agent Notes', 3, 'Omnichannel Team Collaboration', function() use ($sandbox) {
        $vid = 'V-COMB5';

        // 1. Inbound WhatsApp message
        $chats = json_decode(file_get_contents($sandbox . '/live_chats.json'), true) ?: [];
        $chats[$vid] = [
            'visitor_id'     => $vid,
            'channel'        => 'whatsapp',
            'assigned_role'  => 'sales',
            'messages'       => [
                ['id' => 'm1', 'sender' => 'user', 'channel' => 'whatsapp', 'text' => 'Hi from WhatsApp, looking for custom volume pricing.'],
                ['id' => 'm2', 'sender' => 'agent', 'is_private' => true, 'text' => 'Agency shoots 150 homes/mo. Offered Tier-3 discount.']
            ]
        ];
        file_put_contents($sandbox . '/live_chats.json', json_encode($chats, JSON_PRETTY_PRINT));

        // 2. Verify visitor polling does not leak private note
        $rawMessages = $chats[$vid]['messages'];
        $visitorMessages = array_values(array_filter($rawMessages, fn($m) => empty($m['is_private'])));
        
        Assert::count(1, $visitorMessages);
        Assert::equals('Hi from WhatsApp, looking for custom volume pricing.', $visitorMessages[0]['text']);
        Assert::equals('sales', $chats[$vid]['assigned_role']);
    });

    $suite->runTest('T3.6', 'Behavioral Trigger (Dwell >45s on Services) -> Automated Proactive Greeting', 3, 'Automations Engine Integration', function() use ($sandbox) {
        $vid = 'V-COMB6';
        $rules = json_decode(file_get_contents($sandbox . '/chat_automations.json'), true);
        $activeRule = $rules[0];

        // Simulate visitor dwelling on services page
        $visitorState = [
            'visitor_id' => $vid,
            'page_url'   => '/services/virtual-staging',
            'time_spent' => 50
        ];

        $matched = false;
        $triggeredMessage = '';
        if (preg_match('#' . $activeRule['page_match'] . '#i', $visitorState['page_url']) && $visitorState['time_spent'] >= $activeRule['min_seconds']) {
            $matched = true;
            $triggeredMessage = $activeRule['message'];
        }

        Assert::true($matched);
        Assert::contains('turnaround or volume pricing', $triggeredMessage);
    });

    $suite->runTest('T3.7', 'Knowledge Base Search -> Quick Insert into Chat -> Client Receives Knowledge Card', 3, 'Dual-Surface KB & Chat Integration', function() use ($sandbox) {
        $vid = 'V-COMB7';
        $kb = json_decode(file_get_contents($sandbox . '/knowledge_base.json'), true);

        // Search KB for rates
        $query = 'rates';
        $matched = array_filter($kb, fn($a) => str_contains(strtolower($a['title']), $query));
        $article = reset($matched);
        Assert::true(!empty($article));

        // Ensure chat session exists
        RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'visitor_send',
            'visitor_id' => $vid,
            'message' => 'What are your retouching rates?'
        ], ['sandbox_dir' => $sandbox]);

        // Insert into chat
        $formattedSnippet = "🏛️ [Estate HDR Knowledge Base: {$article['title']}]\n{$article['content']}";
        $res = RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'agent_send',
            'target_visitor_id' => $vid,
            'agent_name' => 'Alice | Retouching Director',
            'message' => $formattedSnippet
        ], ['sandbox_dir' => $sandbox]);

        Assert::true($res['json']['success'] ?? false);
    });

    $suite->runTest('T3.8', 'Widget Studio Settings Change -> Instant Preview Reflection -> Client Widget Update', 3, 'Studio Customizer Pipeline', function() use ($sandbox) {
        // 1. Admin saves new settings in studio
        $settings = [
            'primary_color'    => '#D97706',
            'header_title'     => 'Estate HDR Platinum Concierge',
            'agent_name'       => 'Alice & Team',
            'business_hours'   => '24/7 Global Live Support',
            'enable_chimes'    => true,
            'offline_mode'     => false
        ];
        file_put_contents($sandbox . '/widget_settings.json', json_encode($settings, JSON_PRETTY_PRINT));

        // 2. Client widget renders with updated config
        $loadedSettings = json_decode(file_get_contents($sandbox . '/widget_settings.json'), true);
        Assert::equals('#D97706', $loadedSettings['primary_color']);
        Assert::equals('Estate HDR Platinum Concierge', $loadedSettings['header_title']);
    });

    $suite->runTest('T3.9', 'Concurrent Multi-User Operations (Telemetry Ping + Admin Reply + Ticket Conversion)', 3, 'System Concurrency', function() use ($sandbox) {
        $vid1 = 'V-CONCURR-A';
        $vid2 = 'V-CONCURR-B';

        // 1. Visitor A pings
        RequestSimulator::postJson('api/visitor-ping.php', ['visitor_id' => $vid1, 'page_url' => '/'], ['sandbox_dir' => $sandbox]);

        // 2. Visitor B sends chat
        RequestSimulator::postJson('api/chat-live.php', ['action' => 'visitor_send', 'visitor_id' => $vid2, 'message' => 'Hello'], ['sandbox_dir' => $sandbox]);

        // 3. Agent replies to Visitor B
        RequestSimulator::postJson('api/chat-live.php', ['action' => 'agent_send', 'target_visitor_id' => $vid2, 'message' => 'How can I assist?'], ['sandbox_dir' => $sandbox]);

        $visitors = json_decode(file_get_contents($sandbox . '/visitors.json'), true);
        $chats = json_decode(file_get_contents($sandbox . '/live_chats.json'), true);

        Assert::true(isset($visitors[$vid1]));
        Assert::true(isset($chats[$vid2]));
    });

    $suite->runTest('T3.10', 'Full Visitor Lifecycle: First Seen -> Active Radar -> Idle State -> Chatting -> Converted Deal', 3, 'Full Lifecycle State Machine', function() use ($sandbox) {
        $vid = 'V-LIFECYCLE1';

        // Step 1: First Seen (Active)
        RequestSimulator::postJson('api/visitor-ping.php', ['visitor_id' => $vid, 'page_url' => '/', 'time_spent' => 10], ['sandbox_dir' => $sandbox]);

        // Step 2: Dwell & Pricing Visit (Score 35)
        RequestSimulator::postJson('api/visitor-ping.php', ['visitor_id' => $vid, 'page_url' => '/pricing.php', 'time_spent' => 90], ['sandbox_dir' => $sandbox]);

        // Step 3: Chatting (Score +30 -> 65 Hot)
        RequestSimulator::postJson('api/chat-live.php', ['action' => 'visitor_send', 'visitor_id' => $vid, 'message' => 'I have 50 bracket exposures ready to edit! email: agency@realestate.com'], ['sandbox_dir' => $sandbox]);

        // Step 4: Deal Stage -> Won
        $leads = json_decode(file_get_contents($sandbox . '/leads.json'), true) ?: [];
        $leads[] = [
            'id'         => 'LEAD-WON-1',
            'visitor_id' => $vid,
            'email'      => 'agency@realestate.com',
            'stage'      => 'Won',
            'value'      => 40.00,
            'score'      => 95
        ];
        file_put_contents($sandbox . '/leads.json', json_encode($leads, JSON_PRETTY_PRINT));

        $finalLeads = json_decode(file_get_contents($sandbox . '/leads.json'), true);
        $wonDeal = end($finalLeads);
        Assert::equals('Won', $wonDeal['stage']);
        Assert::equals(40, (int)$wonDeal['value']);
    });

    TestEnvironment::teardownSandbox();
}
