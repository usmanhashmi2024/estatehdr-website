<?php
/**
 * Estate HDR — E2E Test Framework & Assertion Core
 * Zero-dependency PHP CLI Test Framework for Opaque-Box E2E Testing
 */

namespace EstateHDR\Testing;

class AssertionException extends \Exception {
    protected $expected;
    protected $actual;

    public function __construct(string $message, $expected = null, $actual = null) {
        parent::__construct($message);
        $this->expected = $expected;
        $this->actual = $actual;
    }

    public function getExpected() { return $this->expected; }
    public function getActual() { return $this->actual; }
}

class Assert {
    public static function true($actual, string $message = ''): void {
        if ($actual !== true) {
            $msg = $message ?: "Expected true, got " . var_export($actual, true);
            throw new AssertionException($msg, true, $actual);
        }
    }

    public static function false($actual, string $message = ''): void {
        if ($actual !== false) {
            $msg = $message ?: "Expected false, got " . var_export($actual, true);
            throw new AssertionException($msg, false, $actual);
        }
    }

    public static function equals($expected, $actual, string $message = ''): void {
        if ($expected !== $actual) {
            $expStr = is_scalar($expected) ? var_export($expected, true) : json_encode($expected);
            $actStr = is_scalar($actual) ? var_export($actual, true) : json_encode($actual);
            $msg = $message ?: "Expected {$expStr}, got {$actStr}";
            throw new AssertionException($msg, $expected, $actual);
        }
    }

    public static function notEquals($expected, $actual, string $message = ''): void {
        if ($expected === $actual) {
            $valStr = is_scalar($expected) ? var_export($expected, true) : json_encode($expected);
            $msg = $message ?: "Expected value NOT to equal {$valStr}";
            throw new AssertionException($msg, "not " . $valStr, $valStr);
        }
    }

    public static function greaterThanOrEqual($expectedMin, $actual, string $message = ''): void {
        if ($actual < $expectedMin) {
            $msg = $message ?: "Expected >= {$expectedMin}, got {$actual}";
            throw new AssertionException($msg, ">= {$expectedMin}", $actual);
        }
    }

    public static function lessThanOrEqual($expectedMax, $actual, string $message = ''): void {
        if ($actual > $expectedMax) {
            $msg = $message ?: "Expected <= {$expectedMax}, got {$actual}";
            throw new AssertionException($msg, "<= {$expectedMax}", $actual);
        }
    }

    public static function contains($needle, $haystack, string $message = ''): void {
        if (is_string($haystack)) {
            if (!str_contains($haystack, (string)$needle)) {
                $needleStr = var_export($needle, true);
                $snippet = strlen($haystack) > 120 ? substr($haystack, 0, 120) . '...' : $haystack;
                $msg = $message ?: "String does not contain {$needleStr}. Got: " . var_export($snippet, true);
                throw new AssertionException($msg, "contains {$needleStr}", $haystack);
            }
        } elseif (is_array($haystack)) {
            if (!in_array($needle, $haystack, true)) {
                $needleStr = var_export($needle, true);
                $msg = $message ?: "Array does not contain value {$needleStr}";
                throw new AssertionException($msg, "array contains {$needleStr}", $haystack);
            }
        } else {
            throw new AssertionException("Haystack must be string or array");
        }
    }

    public static function notContains($needle, $haystack, string $message = ''): void {
        if (is_string($haystack)) {
            if (str_contains($haystack, (string)$needle)) {
                $needleStr = var_export($needle, true);
                $msg = $message ?: "String contains forbidden needle {$needleStr}";
                throw new AssertionException($msg, "not contains {$needleStr}", $haystack);
            }
        } elseif (is_array($haystack)) {
            if (in_array($needle, $haystack, true)) {
                $needleStr = var_export($needle, true);
                $msg = $message ?: "Array contains forbidden value {$needleStr}";
                throw new AssertionException($msg, "not contains {$needleStr}", $haystack);
            }
        }
    }

    public static function matchesRegex(string $pattern, string $subject, string $message = ''): void {
        if (!preg_match($pattern, $subject)) {
            $msg = $message ?: "Subject does not match pattern {$pattern}";
            throw new AssertionException($msg, $pattern, $subject);
        }
    }

    public static function isArray($actual, string $message = ''): void {
        if (!is_array($actual)) {
            $msg = $message ?: "Expected array, got " . gettype($actual);
            throw new AssertionException($msg, 'array', gettype($actual));
        }
    }

    public static function hasKey($key, array $array, string $message = ''): void {
        if (!array_key_exists($key, $array)) {
            $msg = $message ?: "Array missing expected key " . var_export($key, true);
            throw new AssertionException($msg, "has key '{$key}'", array_keys($array));
        }
    }

    public static function count(int $expectedCount, $countable, string $message = ''): void {
        $actualCount = is_countable($countable) ? count($countable) : 0;
        if ($actualCount !== $expectedCount) {
            $msg = $message ?: "Expected count {$expectedCount}, got {$actualCount}";
            throw new AssertionException($msg, $expectedCount, $actualCount);
        }
    }

    public static function isJson(string $string, string $message = ''): array {
        $decoded = json_decode($string, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            $msg = $message ?: "String is not valid JSON (" . json_last_error_msg() . "): " . substr($string, 0, 100);
            throw new AssertionException($msg, 'valid JSON', $string);
        }
        return $decoded;
    }

    public static function fail(string $message = 'Explicit test failure'): void {
        throw new AssertionException($message);
    }
}

class TestResult {
    public string $id;
    public string $name;
    public int $tier;
    public string $feature;
    public string $status; // 'PASS', 'FAIL', 'SKIP'
    public float $durationMs;
    public ?string $errorMessage;
    public ?string $trace;

    public function __construct(string $id, string $name, int $tier, string $feature, string $status = 'PASS', float $durationMs = 0.0, ?string $errorMessage = null, ?string $trace = null) {
        $this->id = $id;
        $this->name = $name;
        $this->tier = $tier;
        $this->feature = $feature;
        $this->status = $status;
        $this->durationMs = $durationMs;
        $this->errorMessage = $errorMessage;
        $this->trace = $trace;
    }
}

class TestEnvironment {
    private static ?string $sandboxDir = null;
    private static string $originalDataDir;
    private static string $rootDir;

    public static function init(): void {
        self::$rootDir = realpath(__DIR__ . '/../../') ?: (__DIR__ . '/../../');
        self::$originalDataDir = self::$rootDir . '/data';
    }

    public static function getRootDir(): string {
        if (!isset(self::$rootDir)) self::init();
        return self::$rootDir;
    }

    public static function setupSandbox(): string {
        self::init();
        $id = uniqid('test_sb_', true);
        $sandbox = self::$rootDir . '/data/' . $id;
        if (!is_dir($sandbox)) {
            mkdir($sandbox, 0777, true);
        }

        // Copy clean initial template files
        $fixtures = [
            'visitors.json'         => [],
            'live_chats.json'       => [],
            'leads.json'            => [],
            'contacts.json'         => [],
            'tickets.json'          => [],
            'chat_automations.json' => [
                [
                    'id'          => 'rule-1',
                    'name'        => 'Pricing Page Intent',
                    'page_match'  => '/services/|pricing',
                    'min_seconds' => 45,
                    'action'      => 'proactive_chat',
                    'message'     => '👋 Looking for specific editing turnaround or volume pricing? Let Alice know!',
                    'is_active'   => true
                ]
            ],
            'widget_settings.json'  => [
                'primary_color'    => '#C5A880',
                'header_title'     => 'Estate HDR Concierge',
                'agent_name'       => 'Alice | Retouching Director',
                'business_hours'   => '24/7 Global Live Support',
                'enable_chimes'    => true,
                'offline_mode'     => false
            ],
            'knowledge_base.json'   => [
                [
                    'id'          => 'kb-1',
                    'category'    => 'Pricing',
                    'title'       => 'Standard HDR Retouching Rates',
                    'slug'        => 'standard-hdr-retouching-rates',
                    'content'     => 'Estate HDR provides professional hand-blended bracket editing at $0.80 per photo with 24-hour turnaround.',
                    'tags'        => ['pricing', 'rates', 'cost', 'hdr'],
                    'views_count' => 142
                ],
                [
                    'id'          => 'kb-2',
                    'category'    => 'Virtual Staging',
                    'title'       => '3D Virtual Staging Styles and Pricing',
                    'slug'        => 'virtual-staging-styles-pricing',
                    'content'     => '3D photorealistic furniture staging is $8.00 per room with Scandinavian, Contemporary, and Luxury styling.',
                    'tags'        => ['staging', 'furniture', 'virtual'],
                    'views_count' => 98
                ]
            ],
            'analytics_history.json'=> []
        ];

        foreach ($fixtures as $filename => $initialData) {
            file_put_contents($sandbox . '/' . $filename, json_encode($initialData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }

        self::$sandboxDir = $sandbox;
        return $sandbox;
    }

    public static function getSandboxDir(): ?string {
        return self::$sandboxDir;
    }

    public static function teardownSandbox(): void {
        if (self::$sandboxDir && is_dir(self::$sandboxDir)) {
            self::recursiveRemoveDir(self::$sandboxDir);
            self::$sandboxDir = null;
        }
    }

    public static function recursiveRemoveDir(string $dir): void {
        if (!is_dir($dir)) return;
        $files = array_diff(scandir($dir), ['.', '..']);
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            is_dir($path) ? self::recursiveRemoveDir($path) : @unlink($path);
        }
        @rmdir($dir);
    }
}

class RequestSimulator {
    private static ?string $phpBinary = null;

    public static function getPhpBinary(): string {
        if (self::$phpBinary !== null) return self::$phpBinary;

        // 1. Check PHP_BINARY constant
        if (defined('PHP_BINARY') && PHP_BINARY && file_exists(PHP_BINARY) && !is_dir(PHP_BINARY)) {
            self::$phpBinary = PHP_BINARY;
            return self::$phpBinary;
        }

        // 2. Common Windows paths
        $candidates = [
            'C:\\xampp\\php\\php.exe',
            'C:\\tools\\php\\php.exe',
            'C:\\php\\php.exe',
            'C:\\laragon\\bin\\php\\php-8.2.12-Win32-vs16-x64\\php.exe',
            'php'
        ];

        foreach ($candidates as $cand) {
            if (file_exists($cand)) {
                self::$phpBinary = $cand;
                return self::$phpBinary;
            }
        }

        self::$phpBinary = 'php';
        return self::$phpBinary;
    }

    public static function executeScript(string $relativePath, array $options = []): array {
        $rootDir = TestEnvironment::getRootDir();
        $targetScript = realpath($rootDir . '/' . ltrim($relativePath, '/\\'));
        if (!$targetScript || !file_exists($targetScript)) {
            return [
                'status'  => 500,
                'body'    => "Script not found: {$relativePath}",
                'json'    => null,
                'headers' => []
            ];
        }

        $method = strtoupper($options['method'] ?? 'GET');
        $queryParams = $options['query'] ?? [];
        $postData = $options['post'] ?? [];
        $jsonBody = $options['json_body'] ?? null;
        $headers = $options['headers'] ?? [];
        $cookies = $options['cookies'] ?? [];
        $session = $options['session'] ?? [
            'is_admin'              => true,
            'ehdr_admin_logged_in'  => true,
            'admin_user' => [
                'id'    => 'adm-1',
                'name'  => 'Master Administrator',
                'email' => 'admin@estatehdr.com',
                'role'  => 'super_admin',
                'roles' => ['owner', 'super_admin']
            ]
        ];
        $sandboxDir = $options['sandbox_dir'] ?? TestEnvironment::getSandboxDir();

        // Create bootstrap wrapper script
        $wrapperCode = '<?php' . "\n";
        $wrapperCode .= 'error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);' . "\n";
        $wrapperCode .= 'ini_set("display_errors", "0");' . "\n";

        // Setup custom Sandbox path constant / override if provided
        if ($sandboxDir) {
            $escapedSandbox = addslashes($sandboxDir . '/');
            $wrapperCode .= 'if (!defined("DATA_PATH")) define("DATA_PATH", "' . $escapedSandbox . '");' . "\n";
        }

        // Setup Simulated Superglobals
        $wrapperCode .= 'if (session_status() === PHP_SESSION_NONE) { @session_start(); }' . "\n";
        $wrapperCode .= '$_SESSION = ' . var_export($session, true) . ';' . "\n";
        $wrapperCode .= '$_SERVER["REQUEST_METHOD"] = ' . var_export($method, true) . ';' . "\n";
        $wrapperCode .= '$_SERVER["PHP_SELF"] = ' . var_export('/' . ltrim(str_replace('\\', '/', $relativePath), '/'), true) . ';' . "\n";
        $wrapperCode .= '$_SERVER["SCRIPT_NAME"] = ' . var_export('/' . ltrim(str_replace('\\', '/', $relativePath), '/'), true) . ';' . "\n";
        $wrapperCode .= '$_SERVER["REMOTE_ADDR"] = ' . var_export($headers['REMOTE_ADDR'] ?? '127.0.0.1', true) . ';' . "\n";
        $wrapperCode .= '$_SERVER["HTTP_USER_AGENT"] = ' . var_export($headers['HTTP_USER_AGENT'] ?? 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0', true) . ';' . "\n";
        $wrapperCode .= '$_SERVER["HTTP_REFERER"] = ' . var_export($headers['HTTP_REFERER'] ?? 'https://estatehdr.com/', true) . ';' . "\n";

        foreach ($headers as $k => $v) {
            $wrapperCode .= '$_SERVER[' . var_export($k, true) . '] = ' . var_export($v, true) . ';' . "\n";
        }

        $wrapperCode .= '$_GET = ' . var_export($queryParams, true) . ';' . "\n";
        $wrapperCode .= '$_POST = ' . var_export($postData, true) . ';' . "\n";
        $wrapperCode .= '$_COOKIE = ' . var_export($cookies, true) . ';' . "\n";

        // If JSON input is provided, simulate php://input via stream filter or variable injection
        if ($jsonBody !== null) {
            $rawJson = is_string($jsonBody) ? $jsonBody : json_encode($jsonBody);
            $wrapperCode .= '
            // Stream wrapper for php://input
            class SimulatedInputStream {
                var $position = 0;
                var $data = ' . var_export($rawJson, true) . ';
                function stream_open($path, $mode, $options, &$opened_path) { return true; }
                function stream_read($count) {
                    $ret = substr($this->data, $this->position, $count);
                    $this->position += strlen($ret);
                    return $ret;
                }
                function stream_write($data) { return 0; }
                function stream_tell() { return $this->position; }
                function stream_eof() { return $this->position >= strlen($this->data); }
                function stream_stat() { return []; }
            }
            if (in_array("php", stream_get_wrappers())) {
                stream_wrapper_unregister("php");
            }
            stream_wrapper_register("php", "SimulatedInputStream");
            ';
        }

        // Include the target script and catch output
        $escapedTarget = addslashes($targetScript);
        $wrapperCode .= '
        ob_start();
        try {
            require ' . var_export($targetScript, true) . ';
        } catch (\Throwable $e) {
            echo "RUNTIME_EXCEPTION: " . $e->getMessage();
        }
        $output = ob_get_clean();
        echo "___EHDR_OUTPUT_DELIMITER___" . $output;
        ';

        $tempScript = tempnam(sys_get_temp_dir(), 'ehdr_test_');
        file_put_contents($tempScript, $wrapperCode);

        $phpBin = self::getPhpBinary();
        $cmd = escapeshellarg($phpBin) . ' ' . escapeshellarg($tempScript);

        $process = proc_open($cmd, [
            0 => ['pipe', 'r'],
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w']
        ], $pipes, $rootDir);

        $stdout = '';
        $stderr = '';

        if (is_resource($process)) {
            fclose($pipes[0]);
            $stdout = stream_get_contents($pipes[1]);
            fclose($pipes[1]);
            $stderr = stream_get_contents($pipes[2]);
            fclose($pipes[2]);
            $exitCode = proc_close($process);
        }

        @unlink($tempScript);

        // Parse delimiter
        $body = $stdout;
        if (str_contains($stdout, '___EHDR_OUTPUT_DELIMITER___')) {
            $parts = explode('___EHDR_OUTPUT_DELIMITER___', $stdout, 2);
            $body = $parts[1] ?? '';
        }

        $decodedJson = json_decode(trim($body), true);

        return [
            'status'   => 200,
            'body'     => $body,
            'json'     => $decodedJson,
            'stderr'   => $stderr
        ];
    }

    public static function postJson(string $scriptPath, array $body, array $options = []): array {
        $options['method'] = 'POST';
        $options['json_body'] = $body;
        return self::executeScript($scriptPath, $options);
    }

    public static function get(string $scriptPath, array $query = [], array $options = []): array {
        $options['method'] = 'GET';
        $options['query'] = $query;
        return self::executeScript($scriptPath, $options);
    }
}

class TestSuite {
    private string $name;
    private array $results = [];

    public function __construct(string $name) {
        $this->name = $name;
    }

    public function runTest(string $id, string $name, int $tier, string $feature, callable $fn): TestResult {
        $start = microtime(true);
        try {
            $fn();
            $duration = (microtime(true) - $start) * 1000.0;
            $result = new TestResult($id, $name, $tier, $feature, 'PASS', $duration);
        } catch (AssertionException $e) {
            $duration = (microtime(true) - $start) * 1000.0;
            $result = new TestResult($id, $name, $tier, $feature, 'FAIL', $duration, $e->getMessage(), $e->getTraceAsString());
        } catch (\Throwable $e) {
            $duration = (microtime(true) - $start) * 1000.0;
            $result = new TestResult($id, $name, $tier, $feature, 'FAIL', $duration, 'Unexpected ' . get_class($e) . ': ' . $e->getMessage(), $e->getTraceAsString());
        }

        $this->results[] = $result;
        return $result;
    }

    public function getResults(): array {
        return $this->results;
    }

    public function getName(): string {
        return $this->name;
    }
}
