<?php
/**
 * Estate HDR — Master E2E Test Runner CLI
 * Usage:
 *   php tests/e2e/run_tests.php
 *   php tests/e2e/run_tests.php --tier=1
 *   php tests/e2e/run_tests.php --filter="Lead Scoring"
 */

namespace EstateHDR\Testing;

require_once __DIR__ . '/test_framework.php';
require_once __DIR__ . '/test_tier1_features.php';
require_once __DIR__ . '/test_tier2_boundaries.php';
require_once __DIR__ . '/test_tier3_combinations.php';
require_once __DIR__ . '/test_tier4_scenarios.php';

// CLI Colors
class ConsoleColor {
    public static function green(string $str): string { return "\033[32m{$str}\033[0m"; }
    public static function red(string $str): string { return "\033[31m{$str}\033[0m"; }
    public static function yellow(string $str): string { return "\033[33m{$str}\033[0m"; }
    public static function cyan(string $str): string { return "\033[36m{$str}\033[0m"; }
    public static function bold(string $str): string { return "\033[1m{$str}\033[0m"; }
    public static function dim(string $str): string { return "\033[2m{$str}\033[0m"; }
}

// Parse CLI Options
$options = getopt('', ['tier:', 'filter:', 'json', 'help']);
if (isset($options['help'])) {
    echo "Estate HDR E2E Test Runner\n";
    echo "Options:\n";
    echo "  --tier=1|2|3|4    Run only specific tier\n";
    echo "  --filter=pattern  Filter tests by name, ID, or feature\n";
    echo "  --json            Output results as JSON\n";
    exit(0);
}

$selectedTier = isset($options['tier']) ? (int)$options['tier'] : null;
$filterPattern = $options['filter'] ?? null;
$isJsonOutput = isset($options['json']);

if (!$isJsonOutput) {
    echo "\n" . ConsoleColor::bold(ConsoleColor::cyan("════════════════════════════════════════════════════════════════════════════════")) . "\n";
    echo "  " . ConsoleColor::bold("🏛️  ESTATE HDR — VISITOR INTELLIGENCE HUB E2E TEST SUITE") . "\n";
    echo "  " . ConsoleColor::dim("PHP Version: " . PHP_VERSION . " | Platform: " . PHP_OS_FAMILY) . "\n";
    echo ConsoleColor::bold(ConsoleColor::cyan("════════════════════════════════════════════════════════════════════════════════")) . "\n\n";
}

$totalStart = microtime(true);
$allResults = [];
$tierSummaries = [];

$tiersToRun = [
    1 => ['name' => 'Tier 1: Feature Isolation (Features 1–24)', 'runner' => 'runTier1FeatureTests'],
    2 => ['name' => 'Tier 2: Boundary, Edge Cases & Stress', 'runner' => 'runTier2BoundaryTests'],
    3 => ['name' => 'Tier 3: Cross-Feature Integration & Concurrency', 'runner' => 'runTier3CombinationTests'],
    4 => ['name' => 'Tier 4: Real-World Operational Scenarios', 'runner' => 'runTier4ScenarioTests']
];

foreach ($tiersToRun as $tierNum => $tierInfo) {
    if ($selectedTier !== null && $selectedTier !== $tierNum) {
        continue;
    }

    if (!$isJsonOutput) {
        echo ConsoleColor::bold(ConsoleColor::yellow("▶ Running {$tierInfo['name']}")) . "\n";
    }

    $suite = new TestSuite($tierInfo['name']);
    $runnerFn = __NAMESPACE__ . '\\' . $tierInfo['runner'];
    
    $tierStart = microtime(true);
    $runnerFn($suite);
    $tierDuration = (microtime(true) - $tierStart) * 1000.0;

    $results = $suite->getResults();
    $passed = 0;
    $failed = 0;

    foreach ($results as $res) {
        if ($filterPattern !== null) {
            $match = str_contains(strtolower($res->id), strtolower($filterPattern)) ||
                     str_contains(strtolower($res->name), strtolower($filterPattern)) ||
                     str_contains(strtolower($res->feature), strtolower($filterPattern));
            if (!$match) continue;
        }

        $allResults[] = $res;

        if ($res->status === 'PASS') {
            $passed++;
            if (!$isJsonOutput) {
                $timeStr = sprintf("%6.1fms", $res->durationMs);
                echo "  " . ConsoleColor::green("✓ [PASS]") . " " . ConsoleColor::dim("[{$res->id}]") . " {$res->name} " . ConsoleColor::dim("({$timeStr})") . "\n";
            }
        } else {
            $failed++;
            if (!$isJsonOutput) {
                echo "  " . ConsoleColor::red("✗ [FAIL]") . " " . ConsoleColor::bold("[{$res->id}]") . " {$res->name}\n";
                if ($res->errorMessage) {
                    echo "      " . ConsoleColor::red("↳ Error: {$res->errorMessage}") . "\n";
                }
            }
        }
    }

    $tierSummaries[$tierNum] = [
        'name'     => $tierInfo['name'],
        'total'    => $passed + $failed,
        'passed'   => $passed,
        'failed'   => $failed,
        'duration' => $tierDuration
    ];

    if (!$isJsonOutput) {
        echo "\n";
    }
}

$totalDuration = (microtime(true) - $totalStart) * 1000.0;
$totalTests = count($allResults);
$totalPassed = count(array_filter($allResults, fn($r) => $r->status === 'PASS'));
$totalFailed = count(array_filter($allResults, fn($r) => $r->status === 'FAIL'));

if ($isJsonOutput) {
    echo json_encode([
        'total_tests'    => $totalTests,
        'passed'         => $totalPassed,
        'failed'         => $totalFailed,
        'duration_ms'    => $totalDuration,
        'tier_summaries' => $tierSummaries,
        'results'        => $allResults
    ], JSON_PRETTY_PRINT);
} else {
    echo ConsoleColor::bold(ConsoleColor::cyan("════════════════════════════════════════════════════════════════════════════════")) . "\n";
    echo "  " . ConsoleColor::bold("📊 TEST EXECUTION SUMMARY") . "\n";
    echo ConsoleColor::bold(ConsoleColor::cyan("────────────────────────────────────────────────────────────────────────────────")) . "\n";
    
    foreach ($tierSummaries as $num => $summary) {
        $statusIcon = $summary['failed'] === 0 ? ConsoleColor::green("✓ PASS") : ConsoleColor::red("✗ FAIL");
        $durStr = sprintf("%7.2fms", $summary['duration']);
        echo sprintf("  Tier %d: %-52s | %3d Tests | %s (%s)\n", $num, $summary['name'], $summary['total'], $statusIcon, $durStr);
    }
    
    echo ConsoleColor::bold(ConsoleColor::cyan("────────────────────────────────────────────────────────────────────────────────")) . "\n";
    echo sprintf("  TOTAL: %d Tests Executed across %d Tiers in %.2fms\n", $totalTests, count($tierSummaries), $totalDuration);
    
    if ($totalFailed === 0) {
        echo "  " . ConsoleColor::bold(ConsoleColor::green("STATUS: ALL {$totalTests} TESTS PASSED (100% SUCCESS)")) . "\n";
    } else {
        echo "  " . ConsoleColor::bold(ConsoleColor::red("STATUS: {$totalFailed} TESTS FAILED")) . "\n";
    }
    echo ConsoleColor::bold(ConsoleColor::cyan("════════════════════════════════════════════════════════════════════════════════")) . "\n\n";
}

exit($totalFailed === 0 ? 0 : 1);
