<?php
/**
 * Estate HDR — E2E Test Suite: Tier 4 End-to-End Operational Scenarios
 * Validates complete multi-step real-world workflows for customers, CSRs, editors, and administrators
 */

namespace EstateHDR\Testing;

require_once __DIR__ . '/test_framework.php';

function runTier4ScenarioTests(TestSuite $suite): void {
    $sandbox = TestEnvironment::setupSandbox();

    // ══════════════════════════════════════════════════════════════════════════════
    // SCENARIO 1: New Real Estate Agency Lead Acquisition & Sales Qualification
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T4.1', 'Scenario 1: Agency Lead Acquisition (Dwell -> Trigger -> Sneak-Peek -> Quote -> Hot Lead)', 4, 'Full Workflow Scenarios', function() use ($sandbox) {
        $vid = 'V-SCENARIO-AGENCY-101';

        // 1. Visitor lands on site and browses services
        RequestSimulator::postJson('api/visitor-ping.php', [
            'visitor_id' => $vid,
            'page_url'   => '/services/hdr-photo-editing',
            'page_title' => 'Professional HDR Photo Retouching',
            'time_spent' => 50,
            'referrer'   => 'https://google.com'
        ], ['sandbox_dir' => $sandbox]);

        // 2. Behavioral trigger identifies high dwell on services
        $rules = json_decode(file_get_contents($sandbox . '/chat_automations.json'), true);
        $triggeredRule = $rules[0];
        Assert::contains('turnaround or volume pricing', $triggeredRule['message']);

        // 3. Visitor begins typing in widget
        RequestSimulator::postJson('api/chat-live.php', [
            'action'     => 'typing_update',
            'visitor_id' => $vid,
            'text'       => 'We have 40 photos per listing, shot on Nikon Z7'
        ], ['sandbox_dir' => $sandbox]);

        // 4. Admin console observes keystroke sneak-peek
        $adminPoll = RequestSimulator::postJson('api/chat-live.php', [
            'action'       => 'poll_admin',
            'selected_vid' => $vid
        ], ['sandbox_dir' => $sandbox]);
        Assert::equals('We have 40 photos per listing, shot on Nikon Z7', $adminPoll['json']['typing_preview'] ?? '');

        // 5. Visitor submits message with email
        $chatRes = RequestSimulator::postJson('api/chat-live.php', [
            'action'     => 'visitor_send',
            'visitor_id' => $vid,
            'message'    => 'We have 40 photos per listing, shot on Nikon Z7 RAW brackets. Contact: broker@kensingtonrealty.co.uk'
        ], ['sandbox_dir' => $sandbox]);

        Assert::true($chatRes['json']['success'] ?? false);
        $reply = $chatRes['json']['latest_reply'] ?? '';
        Assert::contains('40 photos', $reply);
        Assert::contains('$32.00', $reply); // 40 * 0.80 = 32.00
        Assert::contains('Nikon', $reply);

        // 6. Lead is promoted into CRM pipeline as Hot tier
        $leads = json_decode(file_get_contents($sandbox . '/leads.json'), true) ?: [];
        $leadRecord = [
            'id'         => 'LEAD-SCENARIO-1',
            'visitor_id' => $vid,
            'name'       => 'Kensington Realty Broker',
            'email'      => 'broker@kensingtonrealty.co.uk',
            'company'    => 'Kensington Luxury Realty',
            'stage'      => 'Qualified',
            'score'      => 85,
            'tier'       => 'Hot',
            'notes'      => 'High volume account: ~40 photos/week. Shot on Nikon Z7 RAW brackets.'
        ];
        $leads[] = $leadRecord;
        file_put_contents($sandbox . '/leads.json', json_encode($leads, JSON_PRETTY_PRINT));

        // 7. Verification: CRM Contact Record exists and is Qualified
        $finalLeads = json_decode(file_get_contents($sandbox . '/leads.json'), true);
        Assert::greaterThanOrEqual(1, count($finalLeads));
        $promotedLead = end($finalLeads);
        Assert::equals('Qualified', $promotedLead['stage']);
        Assert::equals('Hot', $promotedLead['tier']);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // SCENARIO 2: High-Urgency Order Escalation & SLA Ticket Resolution
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T4.2', 'Scenario 2: High-Urgency Order Escalation (Urgent Alert -> Ticket -> 15m SLA -> Resolution)', 4, 'Full Workflow Scenarios', function() use ($sandbox) {
        $vid = 'V-SCENARIO-URGENT-202';

        // 1. Client sends urgent message
        RequestSimulator::postJson('api/chat-live.php', [
            'action'     => 'visitor_send',
            'visitor_id' => $vid,
            'message'    => 'URGENT: MLS listing goes live in 2 hours! Need amendment on Order ORD-5042 window pull.'
        ], ['sandbox_dir' => $sandbox]);

        // 2. Admin polls and detects unread alert chime
        $adminPoll = RequestSimulator::get('api/chat-live.php', [
            'action' => 'poll_admin'
        ], ['sandbox_dir' => $sandbox]);
        Assert::true($adminPoll['json']['unread_alert'] ?? false);

        // 3. Agent converts to Urgent Support Ticket
        $ticketId = 'TCK-URGENT-5042';
        $tickets = json_decode(file_get_contents($sandbox . '/tickets.json'), true) ?: [];
        $tickets[] = [
            'id'          => $ticketId,
            'visitor_id'  => $vid,
            'order_id'    => 'ORD-5042',
            'subject'     => 'Urgent Window Pull Amendment for ORD-5042',
            'priority'    => 'Urgent',
            'sla_mins'    => 15,
            'department'  => 'photo_editing',
            'status'      => 'in_progress',
            'created_at'  => date('c')
        ];
        file_put_contents($sandbox . '/tickets.json', json_encode($tickets, JSON_PRETTY_PRINT));

        // 4. Editing Team resolves ticket and updates client
        foreach ($tickets as &$t) {
            if ($t['id'] === $ticketId) {
                $t['status'] = 'resolved';
                $t['resolved_at'] = date('c');
                $t['resolution_notes'] = 'Window bracket re-masked in Photoshop. Clean view restored.';
            }
        }
        file_put_contents($sandbox . '/tickets.json', json_encode($tickets, JSON_PRETTY_PRINT));

        $finalTickets = json_decode(file_get_contents($sandbox . '/tickets.json'), true);
        Assert::equals('resolved', $finalTickets[0]['status']);
        Assert::equals(15, $finalTickets[0]['sla_mins']);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // SCENARIO 3: In-Widget Knowledge Base Self-Service Resolution
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T4.3', 'Scenario 3: KB Self-Service (Visitor searches staging -> Reads rates -> View count increments)', 4, 'Full Workflow Scenarios', function() use ($sandbox) {
        $kb = json_decode(file_get_contents($sandbox . '/knowledge_base.json'), true);
        $initialViews = $kb[1]['views_count']; // Virtual Staging article

        // 1. Search KB in widget
        $query = 'Virtual Staging';
        $matches = array_filter($kb, fn($a) => str_contains($a['title'], $query));
        Assert::count(1, $matches);

        // 2. Article read & view incremented
        $kb[1]['views_count']++;
        file_put_contents($sandbox . '/knowledge_base.json', json_encode($kb, JSON_PRETTY_PRINT));

        $updatedKB = json_decode(file_get_contents($sandbox . '/knowledge_base.json'), true);
        Assert::equals($initialViews + 1, $updatedKB[1]['views_count']);
        Assert::contains('$8.00 per room', $updatedKB[1]['content']);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // SCENARIO 4: Omnichannel Multi-Department Collaboration
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T4.4', 'Scenario 4: Omnichannel WhatsApp Hand-off (Inbound WA -> Sales Triage -> Photo Editing -> Private Note -> Reply)', 4, 'Full Workflow Scenarios', function() use ($sandbox) {
        $vid = 'V-SCENARIO-WA-404';

        // 1. Inbound WhatsApp message
        $chats = json_decode(file_get_contents($sandbox . '/live_chats.json'), true) ?: [];
        $chats[$vid] = [
            'visitor_id'     => $vid,
            'channel'        => 'whatsapp',
            'assigned_role'  => 'sales',
            'messages'       => [
                ['id' => 'm1', 'sender' => 'user', 'channel' => 'whatsapp', 'text' => 'Hello, can you do virtual twilight on day photos?']
            ]
        ];

        // 2. Sales triages and hands off to Photo Editing team with internal note
        $chats[$vid]['assigned_role'] = 'photo_editing';
        $chats[$vid]['messages'][] = [
            'id'         => 'm2',
            'sender'     => 'agent',
            'is_private' => true,
            'agent_name' => 'Alice | Sales Lead',
            'text'       => 'Client has 8 exterior daytime photos. Please confirm turnaround for twilight conversions.'
        ];

        // 3. Photo Editing specialist replies to client
        $chats[$vid]['messages'][] = [
            'id'         => 'm3',
            'sender'     => 'agent',
            'is_private' => false,
            'agent_name' => 'Martin | Lead Retoucher',
            'text'       => 'Yes absolutely! Day-to-Dusk Virtual Twilight is $4.00 per photo with glowing windows and warm landscape lighting within 24h.'
        ];
        file_put_contents($sandbox . '/live_chats.json', json_encode($chats, JSON_PRETTY_PRINT));

        // 4. Verify client view isolates private notes
        $finalChat = json_decode(file_get_contents($sandbox . '/live_chats.json'), true)[$vid];
        $clientVisible = array_values(array_filter($finalChat['messages'], fn($m) => empty($m['is_private'])));

        Assert::count(2, $clientVisible);
        Assert::equals('Martin | Lead Retoucher', $clientVisible[1]['agent_name']);
        Assert::equals('photo_editing', $finalChat['assigned_role']);
    });

    // ══════════════════════════════════════════════════════════════════════════════
    // SCENARIO 5: Executive Management & Daily Analytics Reporting Cycle
    // ══════════════════════════════════════════════════════════════════════════════
    $suite->runTest('T4.5', 'Scenario 5: Executive Analytics Reporting (Multi-Country Radar -> KPI Cards -> Historical Bucket)', 4, 'Full Workflow Scenarios', function() use ($sandbox) {
        $visitors = [
            'V-REP-1' => ['visitor_id' => 'V-REP-1', 'country' => 'United States', 'city' => 'New York', 'device' => 'Desktop', 'time_spent' => 120, 'last_seen_ts' => time() - 20],
            'V-REP-2' => ['visitor_id' => 'V-REP-2', 'country' => 'United Kingdom', 'city' => 'London', 'device' => 'Desktop', 'time_spent' => 90, 'last_seen_ts' => time() - 40],
            'V-REP-3' => ['visitor_id' => 'V-REP-3', 'country' => 'Australia', 'city' => 'Sydney', 'device' => 'Mobile', 'time_spent' => 60, 'last_seen_ts' => time() - 50],
            'V-REP-4' => ['visitor_id' => 'V-REP-4', 'country' => 'Canada', 'city' => 'Toronto', 'device' => 'Desktop', 'time_spent' => 180, 'last_seen_ts' => time() - 80]
        ];
        file_put_contents($sandbox . '/visitors.json', json_encode($visitors, JSON_PRETTY_PRINT));

        // Aggregate KPI Summary
        $activeCount = count(array_filter($visitors, fn($v) => (time() - $v['last_seen_ts']) <= 180));
        $avgTimeSpent = round(array_sum(array_column($visitors, 'time_spent')) / count($visitors));
        $countryCounts = array_count_values(array_column($visitors, 'country'));
        $deviceCounts = array_count_values(array_column($visitors, 'device'));

        Assert::equals(4, $activeCount);
        Assert::equals(113, (int)$avgTimeSpent); // (120+90+60+180)/4 = 112.5 -> 113
        Assert::equals(1, $countryCounts['United States']);
        Assert::equals(3, $deviceCounts['Desktop']);
        Assert::equals(1, $deviceCounts['Mobile']);
    });

    TestEnvironment::teardownSandbox();
}
