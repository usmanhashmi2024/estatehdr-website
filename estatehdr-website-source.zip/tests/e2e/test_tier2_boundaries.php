<?php
/**
 * Estate HDR — E2E Test Suite: Tier 2 Boundary, Corner Cases & Input Validation
 * Tests resilience against extreme inputs, concurrency stress, XSS/injection, and edge conditions
 */

namespace EstateHDR\Testing;

require_once __DIR__ . '/test_framework.php';

function runTier2BoundaryTests(TestSuite $suite): void {
    $sandbox = TestEnvironment::setupSandbox();

    // ══════════════════════════════════════════════════════════════════════════════
    // TIER 2: BOUNDARY & CORNER CASES
    // ══════════════════════════════════════════════════════════════════════════════

    $suite->runTest('T2.1', 'Extreme concurrent write stress test (25 rapid sequential operations)', 2, 'Concurrency & Stress', function() use ($sandbox) {
        $dataFile = $sandbox . '/stress_test.json';
        file_put_contents($dataFile, json_encode(['count' => 0, 'items' => []]));

        for ($i = 1; $i <= 25; $i++) {
            $current = json_decode(file_get_contents($dataFile), true) ?: ['count' => 0, 'items' => []];
            $current['count']++;
            $current['items'][] = "item_{$i}";
            file_put_contents($dataFile, json_encode($current, JSON_PRETTY_PRINT));
        }

        $final = json_decode(file_get_contents($dataFile), true);
        Assert::equals(25, $final['count']);
        Assert::count(25, $final['items']);
    });

    $suite->runTest('T2.2', 'Malformed / corrupted JSON payload gracefully handled by visitor-ping', 2, 'Malformed Inputs', function() use ($sandbox) {
        $res = RequestSimulator::executeScript('api/visitor-ping.php', [
            'sandbox_dir' => $sandbox,
            'method' => 'POST',
            'json_body' => '{ malformed_json: true, missing_quotes }'
        ]);
        // Endpoint should execute without throwing fatal error
        Assert::notContains('Fatal error', $res['body']);
        Assert::notContains('Parse error', $res['body']);
    });

    $suite->runTest('T2.3', 'Oversized chat message payload (50KB string with Unicode and emojis)', 2, 'Extreme Payloads', function() use ($sandbox) {
        $largeString = str_repeat('🏢 Estate HDR Photo Retouching 📸 ', 1000); // ~40KB
        $res = RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'visitor_send',
            'visitor_id' => 'V-OVERSIZED1',
            'message' => $largeString
        ], ['sandbox_dir' => $sandbox]);

        Assert::true($res['json']['success'] ?? false);
        $chats = json_decode(file_get_contents($sandbox . '/live_chats.json'), true);
        Assert::true(isset($chats['V-OVERSIZED1']));
    });

    $suite->runTest('T2.4', 'XSS injection payloads in visitor name, chat message, and ticket subject', 2, 'Security & Sanitization', function() use ($sandbox) {
        $xssPayload = '<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">alert("XSS")</script><img src=x onerror=alert(1)>';
        $res = RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'visitor_send',
            'visitor_id' => 'V-XSS1',
            'message' => $xssPayload
        ], ['sandbox_dir' => $sandbox]);

        Assert::true($res['json']['success'] ?? false);
        // Ensure backend doesn't crash
        $chats = json_decode(file_get_contents($sandbox . '/live_chats.json'), true);
        Assert::true(!empty($chats['V-XSS1']));
    });

    $suite->runTest('T2.5', 'SQL and shell meta-character injection resilience in search and chat', 2, 'Security & Sanitization', function() use ($sandbox) {
        $sqlPayload = "' OR '1'='1' -- ; DROP TABLE users; \n `whoami` $(calc.exe)";
        $res = RequestSimulator::postJson('api/chat-live.php', [
            'action' => 'visitor_send',
            'visitor_id' => 'V-SQL1',
            'message' => $sqlPayload
        ], ['sandbox_dir' => $sandbox]);

        Assert::true($res['json']['success'] ?? false);
        Assert::notContains('syntax error', strtolower($res['body']));
    });

    $suite->runTest('T2.6', 'Missing / empty visitor_id auto-generates persistent unique visitor ID', 2, 'Edge Cases', function() use ($sandbox) {
        $res = RequestSimulator::postJson('api/visitor-ping.php', [
            'visitor_id' => '',
            'page_url' => '/'
        ], ['sandbox_dir' => $sandbox]);

        Assert::true(!empty($res['json']['visitor_id']));
        Assert::matchesRegex('/^V-[a-z0-9]+$/i', $res['json']['visitor_id']);
    });

    $suite->runTest('T2.7', 'IPv6 and private internal network IP address fallback handling', 2, 'Network & Geolocation', function() use ($sandbox) {
        $ips = ['::1', '127.0.0.1', '192.168.1.100', '10.0.0.1', '172.16.0.5'];
        foreach ($ips as $ip) {
            $res = RequestSimulator::postJson('api/visitor-ping.php', [
                'visitor_id' => 'V-IPTEST-' . md5($ip),
                'page_url' => '/'
            ], [
                'sandbox_dir' => $sandbox,
                'headers' => ['REMOTE_ADDR' => $ip]
            ]);
            Assert::true($res['json']['success'] ?? false);
            Assert::true(!empty($res['json']['country']));
        }
    });

    $suite->runTest('T2.8', 'Negative and extreme dwell time values are clamped cleanly', 2, 'Boundary Conditions', function() use ($sandbox) {
        // Negative time
        $res = RequestSimulator::postJson('api/visitor-ping.php', [
            'visitor_id' => 'V-TIMENEG1',
            'page_url' => '/',
            'time_spent' => -300
        ], ['sandbox_dir' => $sandbox]);
        Assert::true($res['json']['success'] ?? false);

        // Extreme time (10 million seconds)
        $res2 = RequestSimulator::postJson('api/visitor-ping.php', [
            'visitor_id' => 'V-TIMEMAX1',
            'page_url' => '/',
            'time_spent' => 10000000
        ], ['sandbox_dir' => $sandbox]);
        Assert::true($res2['json']['success'] ?? false);
    });

    $suite->runTest('T2.9', 'Lead score boundary clamping strictly enforces [0, 100]', 2, 'Boundary Conditions', function() {
        $calculateScore = function($points) {
            return max(0, min(100, $points));
        };
        Assert::equals(0, $calculateScore(-50));
        Assert::equals(0, $calculateScore(0));
        Assert::equals(100, $calculateScore(100));
        Assert::equals(100, $calculateScore(9999));
    });

    $suite->runTest('T2.10', 'Unknown / invalid communication channel falls back to website safely', 2, 'Channel Resiliency', function() {
        $validChannels = ['website', 'whatsapp', 'email', 'sms'];
        $inputChannel = 'telegram_bot_unknown';
        $resolvedChannel = in_array($inputChannel, $validChannels) ? $inputChannel : 'website';
        Assert::equals('website', $resolvedChannel);
    });

    $suite->runTest('T2.11', 'Unknown SLA priority defaults gracefully to Normal', 2, 'SLA Boundaries', function() {
        $validPriorities = ['Urgent', 'High', 'Normal', 'Low'];
        $inputPriority = 'SuperUrgentCriticalEmergency';
        $resolvedPriority = in_array($inputPriority, $validPriorities) ? $inputPriority : 'Normal';
        Assert::equals('Normal', $resolvedPriority);
    });

    $suite->runTest('T2.12', 'Future typing timestamps or negative timestamps expire safely', 2, 'Typing Sync Boundaries', function() {
        $nowTs = time();
        $futureTypingTs = $nowTs + 3600; // 1 hour in future
        $isTypingValid = ($nowTs - $futureTypingTs >= 0) && ($nowTs - $futureTypingTs <= 6);
        Assert::false($isTypingValid);
    });

    $suite->runTest('T2.13', 'Updating non-existent ticket ID handles missing key without crash', 2, 'Ticketing Boundaries', function() use ($sandbox) {
        $tickets = json_decode(file_get_contents($sandbox . '/tickets.json'), true);
        $targetId = 'TCK-NONEXISTENT-999';
        $found = false;
        foreach ($tickets as &$t) {
            if ($t['id'] === $targetId) {
                $t['status'] = 'closed';
                $found = true;
                break;
            }
        }
        Assert::false($found);
    });

    $suite->runTest('T2.14', 'Knowledge base handles whitespace-only and special symbol search queries', 2, 'KB Boundaries', function() use ($sandbox) {
        $kb = json_decode(file_get_contents($sandbox . '/knowledge_base.json'), true);
        $queries = ['', '   ', '!!!???###', '///\\'];
        foreach ($queries as $q) {
            $trimmed = trim($q);
            $results = empty($trimmed) ? $kb : array_filter($kb, fn($a) => str_contains($a['title'], $trimmed));
            Assert::isArray($results);
        }
    });

    $suite->runTest('T2.15', 'Pruning logic caps storage at 1000 visitors while preserving newest', 2, 'Storage Capacity', function() use ($sandbox) {
        $visitors = [];
        $now = time();
        for ($i = 1; $i <= 1050; $i++) {
            $vid = "V-PRUNE-{$i}";
            $visitors[$vid] = [
                'visitor_id'   => $vid,
                'last_seen_ts' => $now - (1050 - $i), // newer index has newer timestamp
                'status'       => 'online'
            ];
        }
        // Prune logic
        if (count($visitors) > 1000) {
            uasort($visitors, fn($a, $b) => ($b['last_seen_ts'] ?? 0) <=> ($a['last_seen_ts'] ?? 0));
            $visitors = array_slice($visitors, 0, 1000, true);
        }

        Assert::count(1000, $visitors);
        Assert::true(isset($visitors['V-PRUNE-1050']), "Newest visitor must be preserved");
        Assert::false(isset($visitors['V-PRUNE-1']), "Oldest visitor must be pruned");
    });

    $suite->runTest('T2.16', 'Zero-division prevention in KPI metrics when visitor store is empty', 2, 'KPI Math Safety', function() use ($sandbox) {
        file_put_contents($sandbox . '/visitors.json', json_encode([]));
        $res = RequestSimulator::get('admin/live-visitors.php', [], [
            'sandbox_dir' => $sandbox,
            'session' => ['admin_logged' => true, 'admin_role' => 'super_admin']
        ]);
        Assert::notContains('Division by zero', $res['body']);
    });

    $suite->runTest('T2.17', 'Duplicate email lead promotion updates existing lead or tags accurately', 2, 'CRM Boundaries', function() use ($sandbox) {
        $leads = [
            ['id' => 'LEAD-1', 'email' => 'client@estateagency.com', 'hits' => 1]
        ];
        $incoming = ['email' => 'client@estateagency.com'];
        
        $found = false;
        foreach ($leads as &$l) {
            if (strtolower($l['email']) === strtolower($incoming['email'])) {
                $l['hits']++;
                $found = true;
                break;
            }
        }
        Assert::true($found);
        Assert::equals(2, $leads[0]['hits']);
    });

    $suite->runTest('T2.18', 'Directory traversal prevention in page slug requests', 2, 'Security & Sanitization', function() {
        $dirtySlug = '../../../../etc/passwd';
        $sanitized = preg_replace('/[^a-z0-9\-_]/i', '', $dirtySlug);
        Assert::notContains('/', $sanitized);
        Assert::notContains('..', $sanitized);
        Assert::equals('etcpasswd', $sanitized);
    });

    $suite->runTest('T2.19', 'Rapid typing keystroke burst simulation does not corrupt JSON', 2, 'Typing Sync Stress', function() use ($sandbox) {
        $sampleText = "I need urgent retouching for 50 images with sky replacement";
        for ($len = 1; $len <= strlen($sampleText); $len += 5) {
            $partial = substr($sampleText, 0, $len);
            RequestSimulator::postJson('api/chat-live.php', [
                'action' => 'typing_update',
                'visitor_id' => 'V-BURST1',
                'text' => $partial
            ], ['sandbox_dir' => $sandbox]);
        }
        $chats = json_decode(file_get_contents($sandbox . '/live_chats.json'), true);
        Assert::true(!empty($chats['V-BURST1']['visitor_typing']));
    });

    $suite->runTest('T2.20', 'Widget hex color sanitizer strips invalid characters and scripts', 2, 'Widget Studio Boundaries', function() {
        $sanitizeColor = function($hex) {
            $clean = preg_replace('/[^0-9A-Fa-f#]/', '', $hex);
            if (!preg_match('/^#[0-9A-Fa-f]{3,6}$/', $clean)) {
                return '#C5A880'; // fallback
            }
            return $clean;
        };

        Assert::equals('#10B981', $sanitizeColor('#10B981'));
        Assert::equals('#C5A880', $sanitizeColor('javascript:alert(1)'));
        Assert::equals('#C5A880', $sanitizeColor('red; background:url(evil.com)'));
    });

    TestEnvironment::teardownSandbox();
}
