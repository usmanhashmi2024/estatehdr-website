<?php
/**
 * Milestone M1 Verification Test Suite
 * Tests Concurrency, Atomic Storage, Presence Calculation, KPI Aggregation, APIs, and Admin Command Center
 */

// Start session before any output
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

echo "=== 1. Linting & Syntax Check ===\n";
$phpBin = 'C:\\xampp\\php\\php.exe';
$files = [
    'includes/db.php',
    'api/visitor-ping.php',
    'api/chat-live.php',
    'api/chat-bot.php',
    'includes/auth.php',
    'includes/saas-db.php',
    'admin/live-visitors.php'
];

foreach ($files as $f) {
    $path = __DIR__ . '/../' . $f;
    if (!file_exists($path)) {
        die("FAIL: File not found: $path\n");
    }
    $output = [];
    $ret = 0;
    exec("\"$phpBin\" -l \"$path\"", $output, $ret);
    assert($ret === 0, "Syntax error in $f: " . implode("\n", $output));
    echo "  [OK] $f syntax valid\n";
}

echo "\n=== 2. Testing Concurrency & Atomic Storage ===\n";
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';

$testFile = DATA_PATH . 'test_concurrency_' . uniqid() . '.json';
$payload = ['test' => true, 'timestamp' => microtime(true), 'items' => range(1, 100)];

$res = atomicWriteJson($testFile, $payload);
assert($res === true, "atomicWriteJson returned false");
$read = readJson($testFile);
assert($read['test'] === true && count($read['items']) === 100, "readJson data mismatch");

// Concurrent simulation test: 20 rapid sequential/interleaved writes
for ($i = 0; $i < 20; $i++) {
    $read['items'][] = $i;
    $res = writeJson($testFile, $read);
    assert($res === true, "Rapid write failed at iteration $i");
}
$finalRead = readJson($testFile);
assert(count($finalRead['items']) === 120, "Final count expected 120, got " . count($finalRead['items']));
@unlink($testFile);
echo "  [OK] atomicWriteJson & readJson passed concurrency stress test.\n";

echo "\n=== 3. Testing saveLead Signature Flexibility ===\n";
$lead1 = saveLead('Positional Test Client', 'pos@example.com', '+1234567890', 'HDR Retouching', 'https://drive.google.com/test1', 'Test instructions');
assert($lead1['name'] === 'Positional Test Client' && $lead1['email'] === 'pos@example.com', "Positional saveLead failed");

$lead2 = saveLead([
    'name'       => 'Array Test Client',
    'email'      => 'arr@example.com',
    'phone'      => '+9876543210',
    'source'     => 'live_chat',
    'notes'      => 'Inquired via live chat',
    'cloud_link' => 'https://dropbox.com/test2'
]);
assert($lead2['name'] === 'Array Test Client' && $lead2['email'] === 'arr@example.com', "Array saveLead failed");
echo "  [OK] saveLead supports both positional and associative array arguments.\n";

// Cleanup test leads from leads.json
$leads = getLeads();
$leads = array_values(array_filter($leads, fn($l) => !in_array($l['email'] ?? '', ['pos@example.com', 'arr@example.com'])));
saveLeads($leads);

echo "\n=== 4. Testing Presence & KPI Helpers ===\n";
$mockVisitors = [
    'v1' => ['visitor_id' => 'v1', 'last_seen_ts' => time() - 20, 'date' => date('Y-m-d'), 'time_spent' => 120, 'hits' => 3, 'ip' => '1.1.1.1', 'country' => 'UK', 'city' => 'London', 'device' => 'Desktop', 'browser' => 'Chrome', 'referrer' => 'Direct', 'current_page' => '/services/hdr'],
    'v2' => ['visitor_id' => 'v2', 'last_seen_ts' => time() - 90, 'date' => date('Y-m-d'), 'time_spent' => 45, 'hits' => 1, 'ip' => '2.2.2.2', 'country' => 'US', 'city' => 'New York', 'device' => 'Mobile', 'browser' => 'Safari', 'referrer' => 'Google', 'current_page' => '/pricing.php'],
    'v3' => ['visitor_id' => 'v3', 'last_seen_ts' => time() - 300, 'date' => date('Y-m-d'), 'time_spent' => 200, 'hits' => 5, 'ip' => '3.3.3.3', 'country' => 'CA', 'city' => 'Toronto', 'device' => 'Desktop', 'browser' => 'Edge', 'referrer' => 'Direct', 'current_page' => '/']
];
$mockChats = [
    'v1' => [
        'session_id' => 'CHAT-1',
        'visitor_id' => 'v1',
        'status' => 'active',
        'last_active_ts' => time() - 10,
        'messages' => [
            ['sender' => 'user', 'text' => 'Hi', 'ts' => time() - 100],
            ['sender' => 'agent', 'text' => 'Hello!', 'ts' => time() - 60]
        ]
    ]
];

$presence = calculateLivePresenceStats($mockVisitors, $mockChats, time());
assert($presence['chatting_count'] === 1, "Chatting count mismatch");
assert($presence['idle_count'] === 1, "Idle count mismatch");
assert($presence['online_now'] === 1, "Online now mismatch");
echo "  [OK] calculateLivePresenceStats correctly classified 3-state presence (Active, Idle, Chatting).\n";

$sessionStats = filterVisitorSessions($mockVisitors, 'today', '', '', time());
assert($sessionStats['total_sessions'] === 3, "Total sessions mismatch");
assert($sessionStats['unique_ips_count'] === 3, "Unique IPs mismatch");
assert($sessionStats['avg_seconds'] > 0, "Avg seconds calculation mismatch");
echo "  [OK] filterVisitorSessions aggregated sessions, dwell time, and breakdowns accurately.\n";

$chatKpis = calculateChatKpis($mockChats, 'all', time());
assert($chatKpis['total_conversations'] === 1, "Total chats mismatch");
assert($chatKpis['avg_frt_seconds'] === 40, "FRT expected 40s (100-60), got " . $chatKpis['avg_frt_seconds']);
echo "  [OK] calculateChatKpis measured First Response Time ($chatKpis[avg_frt_formatted]) accurately.\n";

$csat = calculateCsatKpi($mockChats, []);
assert(isset($csat['csat_formatted']), "CSAT calculation mismatch");
echo "  [OK] calculateCsatKpi produced valid CSAT ($csat[csat_formatted]).\n";

$ticketKpis = calculateTicketKpis([], time());
assert($ticketKpis['total_tickets'] === 0 && $ticketKpis['open_tickets_count'] === 0, "Ticket KPIs mismatch");
echo "  [OK] calculateTicketKpis verified.\n";

$leadKpis = calculateLeadKpis([], []);
assert($leadKpis['total_leads'] === 0, "Lead KPIs mismatch");
echo "  [OK] calculateLeadKpis verified.\n";

echo "\n=== 5. Testing API Endpoint Execution ===\n";
// Test visitor ping write
$vid = 'V-TESTPING';
$visitorsFile = DATA_PATH . 'visitors.json';
$visData = readJson($visitorsFile);
$visData[$vid] = [
    'visitor_id'   => $vid,
    'ip'           => '127.0.0.1',
    'country'      => 'United Kingdom',
    'country_code' => 'GB',
    'city'         => 'London',
    'flag'         => '🇬🇧',
    'isp'          => 'Localhost',
    'device'       => 'Desktop',
    'os'           => 'Windows',
    'browser'      => 'Chrome',
    'first_seen'   => date('Y-m-d H:i:s'),
    'date'         => date('Y-m-d'),
    'last_seen'    => date('Y-m-d H:i:s'),
    'last_seen_ts' => time(),
    'current_page' => '/services/hdr-photo-editing',
    'page_title'   => 'HDR Photo Editing',
    'referrer'     => 'https://google.com',
    'time_spent'   => 35,
    'hits'         => 1,
    'status'       => 'online'
];
atomicWriteJson($visitorsFile, $visData);
$savedVis = readJson($visitorsFile);
assert(isset($savedVis[$vid]), "Visitor ping write failed");
// Clean up test visitor
unset($savedVis[$vid]);
atomicWriteJson($visitorsFile, $savedVis);
echo "  [OK] Visitor ping telemetry persistence verified.\n";

echo "\n=== 6. Testing admin/live-visitors.php Execution ===\n";
// Simulate manager/admin session
$_SESSION['is_admin'] = true;
$_SESSION['admin_user'] = [
    'id'    => 'adm-test',
    'name'  => 'Admin Test',
    'email' => 'admin@estatehdr.com',
    'roles' => ['owner', 'super_admin']
];

ob_start();
require __DIR__ . '/../admin/live-visitors.php';
$html = ob_get_clean();

assert(str_contains($html, 'Command Center &amp; Visitor Intelligence Hub'), "Header title not found in HTML");
assert(str_contains($html, 'tabOverview') && str_contains($html, 'tabRadar') && str_contains($html, 'tabInbox') && str_contains($html, 'tabCrm') && str_contains($html, 'tabTriggers') && str_contains($html, 'tabTickets'), "6 Tabs not found in HTML");
assert(str_contains($html, 'Active Online') && str_contains($html, 'Total Traffic') && str_contains($html, 'Avg Dwell Time') && str_contains($html, 'Omnichannel') && str_contains($html, 'CSAT Rating') && str_contains($html, 'Tickets &amp; Leads'), "6 Executive KPI cards not found in HTML");
assert(str_contains($html, 'switchCommandTab'), "switchCommandTab JS not found in HTML");
assert(str_contains($html, 'playNotificationChime'), "playNotificationChime JS not found in HTML");
assert(str_contains($html, 'pollAdminLiveChat'), "pollAdminLiveChat JS not found in HTML");

echo "  [OK] admin/live-visitors.php rendered all 6 tabs, 6 KPI cards, and JS event engine without errors.\n";

echo "\n============================================\n";
echo "ALL MILESTONE M1 VERIFICATION TESTS PASSED!\n";
echo "============================================\n";
