<?php
/**
 * Milestone M1 Empirical Concurrency & Stress Test Harness
 * 
 * Tests atomicWriteJson and atomicReadJson under true parallel multiprocess hammering.
 * Spawns multiple concurrent PHP worker processes to simulate live high-traffic web traffic.
 */

// If invoked as a worker child process:
if (isset($argv[1]) && $argv[1] === '--worker') {
    $mode       = $argv[2]; // 'writer' or 'reader'
    $workerId   = (int)$argv[3];
    $iterations = (int)$argv[4];
    $targetFile = $argv[5];
    $logFile    = $argv[6];

    require_once __DIR__ . '/../includes/config.php';
    require_once __DIR__ . '/../includes/db.php';

    $errors = [];
    $reads = 0;
    $writes = 0;
    $corruptions = 0;
    $zeroBytes = 0;

    for ($i = 0; $i < $iterations; $i++) {
        if ($mode === 'writer') {
            $data = [
                'worker_id' => $workerId,
                'iteration' => $i,
                'timestamp' => microtime(true),
                'random_payload' => bin2hex(random_bytes(256)),
                'sequence' => range(1, 50),
                'checksum' => md5($workerId . '_' . $i)
            ];
            $ok = atomicWriteJson($targetFile, $data);
            if ($ok) {
                $writes++;
            } else {
                $errors[] = "Write failed at worker $workerId iter $i";
            }
            usleep(rand(500, 3000)); // 0.5ms - 3ms jitter
        } elseif ($mode === 'reader') {
            $read = atomicReadJson($targetFile);
            $reads++;
            if (!empty($read)) {
                if (!isset($read['worker_id']) || !isset($read['iteration']) || !isset($read['checksum'])) {
                    $corruptions++;
                    $errors[] = "Corrupt payload read at worker $workerId iter $i: " . json_encode($read);
                } else {
                    $expectedMd5 = md5($read['worker_id'] . '_' . $read['iteration']);
                    if ($read['checksum'] !== $expectedMd5) {
                        $corruptions++;
                        $errors[] = "Checksum mismatch at worker $workerId iter $i";
                    }
                }
            } else {
                // If file exists but read returned empty array, verify if file is 0 bytes or locked
                if (file_exists($targetFile) && filesize($targetFile) === 0) {
                    $zeroBytes++;
                    $errors[] = "Zero-byte file detected at worker $workerId iter $i";
                }
            }
            usleep(rand(200, 2000)); // 0.2ms - 2ms jitter
        }
    }

    $result = [
        'worker_id'   => $workerId,
        'mode'        => $mode,
        'writes'      => $writes,
        'reads'       => $reads,
        'corruptions' => $corruptions,
        'zero_bytes'  => $zeroBytes,
        'errors'      => $errors
    ];

    file_put_contents($logFile, json_encode($result));
    exit(count($errors) === 0 ? 0 : 1);
}

// =========================================================================
// Main Test Orchestrator
// =========================================================================

echo "=================================================================\n";
echo " MILESTONE M1 EMPIRICAL MULTIPROCESS CONCURRENCY STRESS TEST\n";
echo "=================================================================\n\n";

$phpBin = 'C:\\xampp\\php\\php.exe';
if (!file_exists($phpBin)) {
    die("FAIL: PHP binary not found at $phpBin\n");
}

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';

$testDir = DATA_PATH . 'stress_test_' . uniqid() . '/';
if (!is_dir($testDir)) {
    mkdir($testDir, 0755, true);
}
$targetFile = $testDir . 'concurrent_store.json';

// Initialize with valid initial state
atomicWriteJson($targetFile, [
    'worker_id' => 0,
    'iteration' => 0,
    'timestamp' => microtime(true),
    'random_payload' => 'initialization_seed',
    'sequence' => range(1, 10),
    'checksum' => md5('0_0')
]);

$numWriters = 6;
$numReaders = 6;
$writeIterations = 60; // 6 * 60 = 360 writes
$readIterations = 120; // 6 * 120 = 720 reads

echo "Launching $numWriters parallel writers ($writeIterations ops each) and $numReaders parallel readers ($readIterations ops each)...\n";
echo "Total expected concurrent operations: " . (($numWriters * $writeIterations) + ($numReaders * $readIterations)) . "\n";

$processes = [];
$logFiles = [];

$startTime = microtime(true);

// Spawn Writers
for ($w = 1; $w <= $numWriters; $w++) {
    $logFile = $testDir . "writer_{$w}.log";
    $logFiles[] = $logFile;
    $cmd = "\"$phpBin\" \"" . __FILE__ . "\" --worker writer $w $writeIterations \"$targetFile\" \"$logFile\"";
    $descriptors = [
        0 => ["pipe", "r"],
        1 => ["pipe", "w"],
        2 => ["pipe", "w"]
    ];
    $proc = proc_open($cmd, $descriptors, $pipes);
    if (is_resource($proc)) {
        $processes[] = ['proc' => $proc, 'pipes' => $pipes, 'id' => "Writer-$w", 'log' => $logFile];
    } else {
        die("FAIL: Could not spawn writer process $w\n");
    }
}

// Spawn Readers
for ($r = 1; $r <= $numReaders; $r++) {
    $logFile = $testDir . "reader_{$r}.log";
    $logFiles[] = $logFile;
    $cmd = "\"$phpBin\" \"" . __FILE__ . "\" --worker reader $r $readIterations \"$targetFile\" \"$logFile\"";
    $descriptors = [
        0 => ["pipe", "r"],
        1 => ["pipe", "w"],
        2 => ["pipe", "w"]
    ];
    $proc = proc_open($cmd, $descriptors, $pipes);
    if (is_resource($proc)) {
        $processes[] = ['proc' => $proc, 'pipes' => $pipes, 'id' => "Reader-$r", 'log' => $logFile];
    } else {
        die("FAIL: Could not spawn reader process $r\n");
    }
}

// Wait for all child processes to complete
$totalWrites = 0;
$totalReads = 0;
$totalCorruptions = 0;
$totalZeroBytes = 0;
$allErrors = [];

foreach ($processes as $p) {
    $stdout = stream_get_contents($p['pipes'][1]);
    $stderr = stream_get_contents($p['pipes'][2]);
    fclose($p['pipes'][0]);
    fclose($p['pipes'][1]);
    fclose($p['pipes'][2]);
    $exitCode = proc_close($p['proc']);

    if (file_exists($p['log'])) {
        $logContent = json_decode(file_get_contents($p['log']), true);
        if ($logContent) {
            $totalWrites += $logContent['writes'] ?? 0;
            $totalReads += $logContent['reads'] ?? 0;
            $totalCorruptions += $logContent['corruptions'] ?? 0;
            $totalZeroBytes += $logContent['zero_bytes'] ?? 0;
            if (!empty($logContent['errors'])) {
                $allErrors = array_merge($allErrors, $logContent['errors']);
            }
        }
    }

    if ($exitCode !== 0 || !empty($stderr)) {
        $allErrors[] = "Process {$p['id']} exited with code $exitCode. stderr: $stderr";
    }
}

$elapsedTime = microtime(true) - $startTime;

echo "\n--- Concurrency Execution Results ---\n";
echo "Duration: " . round($elapsedTime, 3) . "s (" . round(($totalWrites + $totalReads) / max(0.001, $elapsedTime), 1) . " ops/sec)\n";
echo "Successful Writes: $totalWrites / " . ($numWriters * $writeIterations) . "\n";
echo "Successful Reads:  $totalReads / " . ($numReaders * $readIterations) . "\n";
echo "Corrupted Reads:   $totalCorruptions\n";
echo "0-Byte Reads:      $totalZeroBytes\n";
echo "Total Errors:      " . count($allErrors) . "\n";

// Check for orphaned temporary files
$tmpFiles = glob($testDir . '*.tmp*');
$orphanedTmpCount = count($tmpFiles);
echo "Orphaned .tmp Files in Directory: $orphanedTmpCount\n";

// Final file integrity check
$finalContent = atomicReadJson($targetFile);
$finalValid = is_array($finalContent) && isset($finalContent['checksum']);
echo "Final File State Valid: " . ($finalValid ? "YES" : "NO") . "\n";

// Test large payload atomic write/read (5 MB)
echo "\n--- Testing Large Payload Concurrency (5MB) ---\n";
$largeArray = [];
for ($i = 0; $i < 10000; $i++) {
    $largeArray["item_$i"] = [
        'id' => $i,
        'title' => "High-resolution real estate photo rendering item $i",
        'tags' => ['hdr', 'flambient', 'virtual-staging', 'sky-replacement'],
        'metadata' => [
            'camera' => 'Sony A7R V',
            'lens' => '16-35mm GM II',
            'iso' => 100,
            'brackets' => [-2, -1, 0, 1, 2]
        ]
    ];
}
$largeFile = $testDir . 'large_payload.json';
$largeWriteOk = atomicWriteJson($largeFile, $largeArray);
$largeSize = file_exists($largeFile) ? round(filesize($largeFile) / (1024 * 1024), 2) : 0;
$largeRead = atomicReadJson($largeFile);
$largeReadOk = (count($largeRead) === 10000);

echo "Large file written ({$largeSize} MB): " . ($largeWriteOk ? "OK" : "FAIL") . "\n";
echo "Large file verified (10,000 items):   " . ($largeReadOk ? "OK" : "FAIL") . "\n";

// Unicode & Special Character Encoding Stress
echo "\n--- Testing Unicode, Emoji, and Special Characters ---\n";
$unicodePayload = [
    'emojis' => '🏠📸✨🌟🔥🇬🇧🇺🇸🇨🇦🇯🇵',
    'multilingual' => [
        'japanese' => '高品質不動産写真編集サービス',
        'arabic' => 'خدمات تحرير الصور العقارية الاحترافية',
        'hindi' => 'रियल एस्टेट फोटो संपादन',
        'russian' => 'Профессиональная обработка фото недвижимости'
    ],
    'special_chars' => '<script nonce="<?= \EstateHDR\Security\SecurityHeaders::nonce() ?>">alert("XSS")</script>&quot;\'`\\//\n\r\t',
    'nested_quotes' => 'He said: "It\'s \\"amazing\\"!"'
];
$unicodeFile = $testDir . 'unicode_test.json';
$uWriteOk = atomicWriteJson($unicodeFile, $unicodePayload);
$uRead = atomicReadJson($unicodeFile);
$uMatch = ($uRead === $unicodePayload);

echo "Unicode payload write: " . ($uWriteOk ? "OK" : "FAIL") . "\n";
echo "Unicode payload match: " . ($uMatch ? "OK" : "FAIL") . "\n";

// Cleanup test folder
foreach (glob($testDir . '*') as $f) {
    @unlink($f);
}
@rmdir($testDir);

echo "\n--- Summary ---\n";
if ($totalCorruptions === 0 && $totalZeroBytes === 0 && count($allErrors) === 0 && $orphanedTmpCount === 0 && $largeReadOk && $uMatch) {
    echo ">>> MULTIPROCESS CONCURRENCY & ATOMIC STORAGE: ALL EMPIRICAL CHECKS PASSED <<<\n";
    exit(0);
} else {
    echo ">>> MULTIPROCESS CONCURRENCY STRESS: FAILURES DETECTED <<<\n";
    print_r($allErrors);
    exit(1);
}
